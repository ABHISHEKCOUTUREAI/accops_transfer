import json
import logging
from typing import Any, Coroutine

from fastapi import Request, Response
from starlette.middleware.base import BaseHTTPMiddleware, RequestResponseEndpoint

logger = logging.getLogger("fast-fashion")
stream_handler = logging.StreamHandler()
stream_handler.setLevel(logging.DEBUG)
stream_handler.setFormatter(
    logging.Formatter("%(asctime)s %(message)s [%(pathname)s:%(lineno)d] \n")
)
logging.basicConfig(format="%(asctime)s %(message)s")


# Write redis middleware  to get and set data
class CacheMiddleware(BaseHTTPMiddleware):
    def __init__(self, app, redis_db):
        super().__init__(app)
        self.redis_db = redis_db
        self.excluded_paths = [
            "/docs",
            "/openapi.json",
            "/fast-fashion/docs",
            "/fast-fashion/openapi.json",
            "most-searched-trends"
        ]

    async def dispatch(
        self, request: Request, call_next: RequestResponseEndpoint
    ) -> Coroutine[Any, Any, Response]:
        print("Dispatching")
        path = request.scope["path"]
        if path in self.excluded_paths:
            print(f"Skipping cache for excluded path: {path}")
            return await call_next(request)
        redis_db = self.redis_db

        form = await request.body()

        body_content = form.decode("utf-8")
        cache_key = f"{request.method}:{request.url}:{json.dumps(body_content)}"
        if await redis_db.get(cache_key) is not None:
            print("Found cache")
            result = (await redis_db.get(cache_key)).decode("utf-8")
            return Response(
                content=result,
                media_type="application/json",
                headers={"Content-Type": "application/json"},
            )
        print("No cache found")

        res = await call_next(request)
        if res.status_code != 200:
            return res

        response_content = (
            b"".join([chunk async for chunk in res.body_iterator])
        ).decode("utf-8")
        await redis_db.set(cache_key, response_content)
        logging.info(f"Setting cache for {cache_key}")
        print("Setting cache")
        return Response(
            content=response_content,
            media_type="application/json",
            headers={"Content-Type": "application/json"},
        )
