import json
from datetime import datetime

from db import redis_db
from fastapi import APIRouter, Depends
from fastapi.responses import JSONResponse
from models import (
    AjioBrickDetails,
    AjioBrickDetailsV2,
    AjioProductAttributesV2,
    AttributeQueryParams,
    AttributeResponse,
    BrickImages,
    CategoryQueryParams,
    FilterQuery,
    L2Images,
    MostSearchedAttributes,
    ProductQueryParams,
    SearchBrickDetailsV2,
    SearchParams,
    SearchProductAttributesV2,
    SearchQueriesTrendsV2,
    SearchQueryInteractedProductsV2,
    SearchTrendsRequest,
)
from sqlalchemy import and_, func, select
from static import INTERNAL_SERVER_ERROR, setup_logging
from utils import (
    build_filter_condition,
    construct_filtered_query,
    create_request_api_contract_ajio,
    execute_attributes_query,
    execute_category_query,
    execute_products_query,
    get_v2_filters,
    load_attributes_images,
    psql_execute_single,
)

BestSellerAPIContractRouter = APIRouter(tags=["V2-API"])


@BestSellerAPIContractRouter.get("/products")
async def get_bestseller_products(
    query_params: ProductQueryParams = Depends(),
    logger=Depends(setup_logging),
):
    try:
        result = await execute_products_query(query_params=query_params)
        return result
    except Exception as e:
        logger.error(e, exc_info=True)
        return JSONResponse(content={"error": INTERNAL_SERVER_ERROR}, status_code=500)


@BestSellerAPIContractRouter.get("/category")
async def get_category(
    query_params: CategoryQueryParams = Depends(),
    logger=Depends(setup_logging),
):
    try:
        if query_params.category is None:
            # load the category images
            query = select(L2Images.l2name, L2Images.productid, L2Images.imgcode).where(
                L2Images.l1name == query_params.gender
            )

            result = await psql_execute_single(query)

            result = [
                {"category": row[0], "id": row[1], "imgcode": row[2]} for row in result
            ]
            return result
        else:
            query = select(
                BrickImages.brickname,
                BrickImages.productid,
                BrickImages.imgcode,
            ).where(
                and_(
                    BrickImages.l1name == query_params.gender,
                    BrickImages.l2name == query_params.category,
                )
            )

            result = await psql_execute_single(query)
            result = [
                {"brickname": row[0], "productid": row[1], "imgcode": row[2]}
                for row in result
            ]

            return result

    except Exception as e:
        logger.error(e, exc_info=True)
        return JSONResponse(content={"error": INTERNAL_SERVER_ERROR}, status_code=500)


@BestSellerAPIContractRouter.get("/attributes")
async def get_bestseller_attributes(
    query_params: AttributeQueryParams = Depends(),
    logger=Depends(setup_logging),
):
    try:
        attributes_images = await redis_db.get("attributes_images")
        if attributes_images:
            attributes_images = json.loads(attributes_images)
        else:
            await load_attributes_images()
            attributes_images = await redis_db.get("attributes_images")
            attributes_images = json.loads(attributes_images)

        if (
            query_params.gender is None
            or query_params.category is None
            or query_params.brickname is None
        ):
            return JSONResponse(
                "Please provide gender, category and brickname", status_code=400
            )

        result = await execute_attributes_query(query_params, attributes_images)
        return result
    except Exception as e:
        logger.error(e, exc_info=True)
        return JSONResponse(content={"error": INTERNAL_SERVER_ERROR}, status_code=500)


@BestSellerAPIContractRouter.get("/most-searched-trends")
async def get_most_searched_trends(
    query_params: SearchTrendsRequest = Depends(),
    logger=Depends(setup_logging),
):
    try:
        offset = (query_params.page - 1) * query_params.page_size
        if query_params.search_query is None:
            trends_query = (
                select(
                    SearchQueriesTrendsV2.search_query,
                    SearchQueriesTrendsV2.total_clicks_across_all_products_for_query,
                    SearchQueriesTrendsV2.search_distribution_across_weeks,
                    SearchQueriesTrendsV2.last_searched_date,
                )
                .where(
                    SearchQueriesTrendsV2.num_past_days == query_params.num_days.value,
                )
                .order_by(
                    SearchQueriesTrendsV2.total_clicks_across_all_products_for_query.desc()
                )
                .offset(offset)
                .limit(query_params.page_size)
            )
            trends_data = await psql_execute_single(trends_query)
            return [
                {
                    "name": row[0],
                    "total_clicks": row[1],
                    "search_distribution": {
                        "divisions": len(row[2]),
                        "data": row[2],
                    },
                    "last_searched_timestamp": datetime.strftime(row[3], "%Y-%m-%d"),
                }
                for row in trends_data
            ]
        else:
            search_query_interacted_products_query = (
                select(
                    SearchQueryInteractedProductsV2.productid,
                    SearchQueryInteractedProductsV2.clicks_product,
                )
                .where(
                    SearchQueryInteractedProductsV2.search_query
                    == query_params.search_query,
                    SearchQueryInteractedProductsV2.num_past_days
                    == query_params.num_days.value,
                )
                .cte("search_query_interacted_products_query")
            )
            condition = []
            if query_params.brickname is not None:
                condition.append(
                    SearchBrickDetailsV2.brickname == query_params.brickname
                )
            if query_params.category is not None:
                condition.append(SearchBrickDetailsV2.l2name == query_params.category)
            if query_params.gender is not None:
                condition.append(SearchBrickDetailsV2.l1name == query_params)
            brick_details_query = (
                select(
                    SearchBrickDetailsV2.similargrouplevel,
                )
                .where(and_(*condition))
                .cte("brick_details_query")
            )

            product_details_query = select(
                SearchProductAttributesV2.similargrouplevel,
                SearchProductAttributesV2.productid,
                SearchProductAttributesV2.title,
                SearchProductAttributesV2.brandname,
                SearchProductAttributesV2.mrp,
                SearchProductAttributesV2.imgcode,
                SearchProductAttributesV2.price,
            ).cte("product_details_query")

            filtered_products_query = (
                select(
                    product_details_query.c.productid,
                    product_details_query.c.title,
                    product_details_query.c.brandname,
                    product_details_query.c.mrp,
                    product_details_query.c.imgcode,
                    product_details_query.c.price,
                )
                .join(
                    brick_details_query,
                    product_details_query.c.similargrouplevel
                    == brick_details_query.c.similargrouplevel,
                )
                .cte("filtered_products_query")
            )
            product_details = (
                (
                    select(
                        search_query_interacted_products_query.c.productid,
                        filtered_products_query.c.title,
                        filtered_products_query.c.brandname,
                        filtered_products_query.c.mrp,
                        filtered_products_query.c.imgcode,
                        filtered_products_query.c.price,
                    ).join(
                        filtered_products_query,
                        search_query_interacted_products_query.c.productid
                        == filtered_products_query.c.productid,
                    )
                )
                .order_by(
                    search_query_interacted_products_query.c.clicks_product.desc()
                )
                .offset(offset)
                .limit(query_params.page_size)
            )

            product_data = await psql_execute_single(product_details)
            return [
                {
                    "productid": row[0],
                    "title": row[1],
                    "brandname": row[2],
                    "mrp": row[3],
                    "imgcode": row[4],
                    "price": row[5],
                }
                for row in product_data
            ]
    except Exception as e:
        logger.error(e, exc_info=True)
        return JSONResponse(content={"error": INTERNAL_SERVER_ERROR}, status_code=500)


@BestSellerAPIContractRouter.get(
    "/most-searched-attributes",
    response_model=list[AttributeResponse],
)
async def get_most_searched_attributes(
    query_params: SearchParams = Depends(),
    logger=Depends(setup_logging),
):
    try:
        query_params.num_days = query_params.num_days.value
        brick_condition = []
        if query_params.gender is not None:
            brick_condition.append(SearchBrickDetailsV2.l1name == query_params.gender)
        if query_params.category is not None:
            brick_condition.append(SearchBrickDetailsV2.l2name == query_params.category)
        if query_params.brickname is not None:
            brick_condition.append(
                SearchBrickDetailsV2.brickname == query_params.brickname
            )
        brick_query = (
            select(SearchBrickDetailsV2.similargrouplevel)
            .where(and_(*brick_condition))
            .cte("brick_query")
        )
        if query_params.attribute == "all":
            most_searched_query = select(
                MostSearchedAttributes.similargrouplevel,
                MostSearchedAttributes.attribute_name,
                MostSearchedAttributes.attribute_value,
                MostSearchedAttributes.clicks,
            ).cte("most_searched_query")
        else:
            most_searched_query = (
                select(
                    MostSearchedAttributes.similargrouplevel,
                    MostSearchedAttributes.attribute_name,
                    MostSearchedAttributes.attribute_value,
                    MostSearchedAttributes.clicks,
                )
                .where(MostSearchedAttributes.attribute_name == query_params.attribute)
                .cte("most_searched_query")
            )

        if len(brick_condition) > 0:
            most_searched_query = (
                select(
                    most_searched_query.c.attribute_name,
                    most_searched_query.c.attribute_value,
                    most_searched_query.c.clicks,
                )
                .join(
                    brick_query,
                    most_searched_query.c.similargrouplevel
                    == brick_query.c.similargrouplevel,
                )
                .cte("filtered_most_searched_query")
            )

        most_searched_query = (
            select(
                most_searched_query.c.attribute_name,
                most_searched_query.c.attribute_value,
                func.sum(most_searched_query.c.clicks).label("total_clicks"),
            )
            .group_by(
                most_searched_query.c.attribute_name,
                most_searched_query.c.attribute_value,
            )
            .cte("grouped_most_searched_query")
        )

        ranked = select(
            most_searched_query.c.attribute_name,
            most_searched_query.c.attribute_value,
            (
                (
                    most_searched_query.c.total_clicks
                    / func.sum(most_searched_query.c.total_clicks).over(
                        partition_by=most_searched_query.c.attribute_name
                    )
                )
                * 100
            ).label("pecentage"),
            func.rank()
            .over(
                partition_by=most_searched_query.c.attribute_name,
                order_by=most_searched_query.c.total_clicks.desc(),
            )
            .label("rank"),
        ).select_from(most_searched_query)

        offset = (query_params.page - 1) * query_params.page_size
        offset_condition = []
        if (
            query_params.attribute != "all"
            and query_params.num_attribute_fields is not None
        ):
            offset_condition = [ranked.c.rank < query_params.num_attribute_fields]
        else:
            offset_condition = [
                ranked.c.rank <= offset + query_params.page_size,
                ranked.c.rank > offset,
            ]
        # Select the top elements within each partition based on pagination
        most_searched_attributes_query = select(
            ranked.c.attribute_name,
            ranked.c.attribute_value,
            func.round(ranked.c.pecentage, 2),
        ).where(and_(*offset_condition))

        data = await psql_execute_single(most_searched_attributes_query)

        response = {}
        for row in data:
            if row[0] in response.keys():
                response[row[0]].append({"name": row[1], "percentage": row[2]})
            else:
                response[row[0]] = [{"name": row[1], "percentage": row[2]}]
        final_response = []
        for key in response.keys():
            final_response.append({"attribute_key": key, "distribution": response[key]})

        if len(final_response) > 0 and query_params.attribute != "all":
            final_response[0]["distribution"].append(
                {
                    "name": "others",
                    "percentage": round(
                        100.0
                        - float(
                            sum(
                                d["percentage"]
                                for d in final_response[0]["distribution"]
                            )
                        ),
                        2,
                    ),
                }
            )
        return final_response

    except Exception as e:
        logger.error(e, exc_info=True)
        return JSONResponse(content={"error": INTERNAL_SERVER_ERROR}, status_code=500)


@BestSellerAPIContractRouter.get("/filters")
async def get_api_contract_filters(
    query_params: FilterQuery = Depends(),
    logger=Depends(setup_logging),
):
    try:
        result = await get_v2_filters(query_params=query_params)
        return result
    except Exception as e:
        logger.error(e, exc_info=True)
        return JSONResponse(content={"error": INTERNAL_SERVER_ERROR}, status_code=500)
