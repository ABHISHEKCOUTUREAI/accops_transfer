import asyncio
import json
from datetime import datetime
from typing import Callable

from db import check_in_redis, psql_execute_multiple, psql_execute_single, redis_db
from models import (
    AjioBestSellers,
    AjioBrickDetails,
    AjioBrickDetailsV2,
    AjioDemographicDetails,
    AjioDemographicDetailsV2,
    AjioNationalROS,
    AjioProductAttributeCombination,
    AjioProductAttributes,
    AjioProductAttributesV2,
    AjioSearchQueriesTopInteractedProducts,
    AttributeQueryParams,
    BestsellersAjio,
    Calenderyearmonthweekinfo,
    PastDaysMetadata,
    ProductQueryParams,
    SearchParams,
    SearchTrendsRequest,
    TrendsBestSellers,
    TrendsStoreDetails,
)
from sqlalchemy import Numeric, and_, case, cast, func, or_, select
from sqlalchemy.dialects.postgresql import aggregate_order_by
from static import REDIS_WRITE_ERROR

from .common_utils import (
    build_filter_condition,
    construct_filtered_query,
)

api_contract_search_attributes = [
    "brandname",
    "colorfamily",
    "fabrictype",
    "materialtype",
    "pattern",
    "sleevelength",
    "styletype",
    "occasion",
    "bodytype",
    "fit",
    "distress",
    "traditionalweave",
    "neckline",
    "hemline",
]


product_attribute_filters = [
    "colorfamily",
    "fabrictype",
    "materialtype",
    "pattern",
    "sleevelength",
    "brandname",
    "occasion",
    "bodytype",
    "fit",
    "distress",
    "traditionalweave",
    "neckline",
    "hemline",
    "styletype",
]


def _select(table, condition, columns: list):
    """
    Args:
        table: sqlalchemy model
        condition: list of conditions
        columns: list of column names
    Returns:
        sqlalchemy query
    """
    return select(*[getattr(table, column) for column in columns]).where(
        and_(*condition)
    )


def form_condition(table, filters: dict) -> list:
    """
    Args:
        table: sqlalchemy model
        filters: dict (key: column name, value: value to filter)
    Returns:
        list of conditions

    """
    condition = []
    for key, value in filters.items():
        if value is None:
            continue
        elif isinstance(value, list):
            condition.append(getattr(table, key).in_(value))
        else:
            condition.append(getattr(table, key) == value)
    return condition


def check_demographic_filter(query_params):
    if (
        query_params.zone
        or query_params.state
        or query_params.district
        or query_params.city
        or query_params.pincode
    ):
        return True
    return False


async def get_similargrouplevel(query_params):
    brick_condition = form_condition(
        AjioBrickDetailsV2,
        {
            "l1name": query_params.gender,
            "l2name": query_params.category,
            "brickname": query_params.brickname,
        },
    )

    brick_query = _select(AjioBrickDetailsV2, brick_condition, ["similargrouplevel"])

    result = await psql_execute_single(brick_query)

    if len(result) == 0:
        raise ValueError("No data found for the given filters")

    return result[0][0]


async def create_attributes_query(query_params: AttributeQueryParams):
    similargrouplevel = await get_similargrouplevel(query_params)

    if check_demographic_filter(query_params):
        bestsellers_condition = form_condition(
            BestsellersAjio,
            {
                "num_past_days": query_params.num_days.value,
                "similargrouplevel": similargrouplevel,
            },
        )
        bestsellers_query = _select(
            BestsellersAjio,
            bestsellers_condition,
            ["productid", "pincode", "sold_quantity"],
        ).cte("bestsellers_query")

        demographic_condition = form_condition(
            AjioDemographicDetailsV2,
            {
                "zone": query_params.zone,
                "state": query_params.state,
                "districtsname": query_params.district,
                "city": query_params.city,
                "pincode": query_params.pincode,
            },
        )
        demographic_query = _select(
            AjioDemographicDetailsV2, demographic_condition, ["pincode"]
        ).cte("demographic_query")

        sold_quantity_query = (
            select(
                bestsellers_query.c.productid,
                func.sum(bestsellers_query.c.sold_quantity).label("sold_quantity"),
            )
            .join(
                demographic_query,
                demographic_query.c.pincode == bestsellers_query.c.pincode,
            )
            .group_by(bestsellers_query.c.productid)
            .cte("sold_quantity_query")
        )

    else:
        condition = form_condition(
            AjioNationalROS,
            {
                "num_past_days": query_params.num_days.value,
                "similargrouplevel": similargrouplevel,
            },
        )
        sold_quantity_query = _select(
            AjioNationalROS,
            condition,
            ["productid", "sold_quantity"],
        ).cte("sold_quantity_query")

    if query_params.attribute == "all":
        filters = {"similargrouplevel": similargrouplevel}
    else:
        filters = {
            "similargrouplevel": similargrouplevel,
            "attribute_name": query_params.attribute,
        }

    attribute_combination_condition = form_condition(
        AjioProductAttributeCombination, filters
    )

    attribute_combination_query = _select(
        AjioProductAttributeCombination,
        attribute_combination_condition,
        ["productid", "attribute_name", "attribute_value"],
    ).cte("attribute_combination_query")

    attribute_sold_query = (
        select(
            attribute_combination_query.c.attribute_name,
            attribute_combination_query.c.attribute_value,
            func.sum(sold_quantity_query.c.sold_quantity).label("sold_quantity"),
        )
        .join(
            sold_quantity_query,
            sold_quantity_query.c.productid == attribute_combination_query.c.productid,
        )
        .group_by(
            attribute_combination_query.c.attribute_name,
            attribute_combination_query.c.attribute_value,
        )
        .cte("attribute_sold_query")
    )

    query = select(
        attribute_sold_query.c.attribute_name,
        attribute_sold_query.c.attribute_value,
        func.rank()
        .over(
            partition_by=attribute_sold_query.c.attribute_name,
            order_by=attribute_sold_query.c.sold_quantity.desc(),
        )
        .label("rank"),
    ).cte("query")

    start = (query_params.page - 1) * query_params.page_size
    end = start + query_params.page_size

    query = select(query.c.attribute_name, query.c.attribute_value).where(
        and_(query.c.rank > start, query.c.rank <= end)
    )

    return query


async def execute_attributes_query(
    query_params: AttributeQueryParams, attributes_images
):
    query = await create_attributes_query(query_params)
    results = await psql_execute_single(query)
    response = {}

    for row in results:
        if row[0] not in response:
            response[row[0]] = {"attribute": row[0], "values": []}
        metadata = attributes_images.get(row[0]).get(row[1])
        response[row[0]]["values"].append(
            {
                "name": row[1],
                "imgcode": metadata["imgcode"],
                "id": metadata["productid"],
            }
        )

    return [value for _, value in response.items()]


def form_brick_query(query_params):
    brick_condition = form_condition(
        AjioBrickDetailsV2,
        {
            "l1name": query_params.gender,
            "l2name": query_params.category,
            "brickname": query_params.brickname,
        },
    )

    brick_query = _select(
        AjioBrickDetailsV2, brick_condition, ["similargrouplevel"]
    ).cte("brick_query")

    return brick_query, brick_condition


def form_attribute_query(query_params, columns: list):
    product_filters = {}
    for attribute in product_attribute_filters:
        if getattr(query_params, attribute):
            values = []
            for value in getattr(query_params, attribute).split(","):
                if value.strip():
                    values.append(value)

            product_filters[attribute] = values

    attribute_condition = form_condition(AjioProductAttributesV2, product_filters)

    if query_params.min_price is not None:
        attribute_condition.append(
            AjioProductAttributesV2.mrp >= query_params.min_price
        )
    if query_params.max_price is not None:
        attribute_condition.append(
            AjioProductAttributesV2.mrp <= query_params.max_price
        )

    attribute_query = _select(
        AjioProductAttributesV2, attribute_condition, columns
    ).cte("attribute_query")
    return attribute_query, attribute_condition


def form_demographic_query(query_params):
    demographic_condition = form_condition(
        AjioDemographicDetailsV2,
        {
            "zone": query_params.zone,
            "state": query_params.state,
            "city": query_params.city,
            "districtsname": query_params.district,
            "pincode": query_params.pincode,
        },
    )
    demographic_query = _select(
        AjioDemographicDetailsV2, demographic_condition, ["pincode"]
    ).cte("demographic_query")

    return demographic_query


async def create_ajio_ros_query_from_national_ros(query_params: ProductQueryParams):
    """
    This function creates the query for ajio_ros from national_ros table when no demography filter is present

    Args:
        query_params: ProductQueryParams
    Returns:
        sqlalchemy query
    """
    base_condition = form_condition(
        AjioNationalROS, {"num_past_days": query_params.num_days.value}
    )

    base_columns = ["productid", "similargrouplevel", "ros"]
    brick_query, brick_condition = form_brick_query(query_params)
    attribute_query, _ = form_attribute_query(
        query_params,
        ["productid", "mrp", "brandname", "title", "imgcode", "similargrouplevel"],
    )
    base_query = (_select(AjioNationalROS, base_condition, base_columns)).cte(
        "base_query"
    )

    if len(brick_condition) > 0:
        base_query = (
            select(base_query.c.productid, base_query.c.ros)
            .join(
                brick_query,
                brick_query.c.similargrouplevel == base_query.c.similargrouplevel,
            )
            .cte("filtered_query")
        )

    final_query = select(
        base_query.c.productid,
        attribute_query.c.title,
        attribute_query.c.brandname,
        attribute_query.c.mrp,
        base_query.c.ros.label("ajio_weekly_ros"),
        attribute_query.c.imgcode,
    ).join(
        attribute_query,
        attribute_query.c.productid == base_query.c.productid,
    )

    return final_query


async def create_ajio_ros_query(query_params: ProductQueryParams):
    """
    Args:
        query_params: ProductQueryParams
    Returns:
        sqlalchemy query
    """
    base_condition = form_condition(
        BestsellersAjio, {"num_past_days": query_params.num_days.value}
    )
    base_query = _select(
        BestsellersAjio,
        base_condition,
        [
            "productid",
            "pincode",
            "similargrouplevel",
            "sold_quantity",
            "healthy_live_days",
        ],
    ).cte("base_query")
    brick_query, brick_condition = form_brick_query(query_params)
    attribute_query, attribute_condition = form_attribute_query(
        query_params, ["productid", "mrp", "brandname", "title", "imgcode"]
    )
    demographic_query = form_demographic_query(query_params)
    base_query = (
        select(
            base_query.c.productid,
            base_query.c.similargrouplevel,
            base_query.c.sold_quantity,
            base_query.c.healthy_live_days,
        )
        .join(
            demographic_query,
            demographic_query.c.pincode == base_query.c.pincode,
        )
        .cte("demographic_filtered_query")
    )

    if len(brick_condition) > 0:
        base_query = (
            select(
                base_query.c.productid,
                base_query.c.sold_quantity,
                base_query.c.healthy_live_days,
            )
            .join(
                brick_query,
                brick_query.c.similargrouplevel == base_query.c.similargrouplevel,
            )
            .cte("brick_filtered_base_query")
        )
        # attribute_query = (
        #     select(
        #         attribute_query.c.productid,
        #         attribute_query.c.mrp,
        #         attribute_query.c.brandname,
        #         attribute_query.c.title,
        #         attribute_query.c.imgcode,
        #     )
        #     .join(
        #         base_query,
        #         base_query.c.productid == attribute_query.c.productid,
        #     )
        #     .cte("attribute_filtered_query")
        # )

    if len(attribute_condition) > 0:
        base_query = (
            select(
                base_query.c.productid,
                base_query.c.sold_quantity,
                base_query.c.healthy_live_days,
            )
            .join(
                attribute_query,
                attribute_query.c.productid == base_query.c.productid,
            )
            .cte("attribute_filtered_base_query")
        )

    query = (
        select(
            base_query.c.productid,
            (
                func.sum(base_query.c.sold_quantity)
                / func.avg(base_query.c.healthy_live_days)
            ).label("ajio_weekly_ros"),
        )
        .join(
            attribute_query,
            attribute_query.c.productid == base_query.c.productid,
        )
        .group_by(base_query.c.productid)
        .cte("query")
    )

    final_query = select(
        query.c.productid,
        attribute_query.c.title,
        attribute_query.c.brandname,
        attribute_query.c.mrp,
        query.c.ajio_weekly_ros,
        attribute_query.c.imgcode,
    ).join(
        attribute_query,
        attribute_query.c.productid == query.c.productid,
    )

    return final_query


async def execute_products_query(query_params: ProductQueryParams) -> list:
    """
    combines and executes the queries to get the bestseller products
    """

    if check_demographic_filter(query_params):
        ajio_ros_query = await create_ajio_ros_query(query_params)
    else:
        ajio_ros_query = await create_ajio_ros_query_from_national_ros(query_params)

    ajio_ros_query = ajio_ros_query.cte("ajio_ros_query")

    ajio_ros_query = (
        select(ajio_ros_query)
        .order_by(ajio_ros_query.c.ajio_weekly_ros.desc())
        .limit(query_params.page_size)
        .offset((query_params.page - 1) * query_params.page_size)
    )

    result = await psql_execute_single(ajio_ros_query)

    result = [
        {
            "item_id": row[0],
            "title": row[1],
            "brandname": row[2],
            "price": row[3],
            "ajio_weekly_ros": row[4],
            # "trends_weekly_ros": row[5] if row[5] is not None else 0,
            "image_code": row[5],
        }
        for row in result
    ]
    return result


async def create_request_api_contract_ajio(query_params: ProductQueryParams):
    request_data = {
        "nested_data": {
            "duration": {"month": [], "quarter": []},
            "demographic": {
                "zone": [],
                "state": [],
                "city": [],
                "district": [],
                "pincode": [],
            },
            "attributes": {
                "styletype": [],
                "neckline": [],
                "pattern": [],
                "fabric_type": [],
                "sleeve": [],
                "fit": [],
                "color": [],
                "brand": [],
                "occasion": [],
                "bodytype": [],
                "materialtype": [],
                "distress": [],
                "traditionalweave": [],
                "hemline": [],
            },
            "brick_filters": {"l1_name": [], "l2_name": [], "brick_name": []},
        },
        "page_no": query_params.page,
        "page_count": query_params.page_size,
        "sort_param": query_params.sort_attribute,
        "sort_type": query_params.sort_order,
    }
    # Append demography filters
    if query_params.zone:
        request_data["nested_data"]["demographic"]["zone"].append(query_params.zone)
    if query_params.state:
        request_data["nested_data"]["demographic"]["state"].append(query_params.state)
    if query_params.city:
        request_data["nested_data"]["demographic"]["city"].append(query_params.city)
    if query_params.pincode:
        request_data["nested_data"]["demographic"]["pincode"].append(
            query_params.pincode
        )
    if query_params.gender:
        request_data["nested_data"]["brick_filters"]["l1_name"].append(
            query_params.gender
        )
    if query_params.category:
        request_data["nested_data"]["brick_filters"]["l2_name"].append(
            query_params.category
        )

    # Append attribute key and value
    if query_params.attribute_key and query_params.attribute_value:
        if query_params.attribute_key in request_data["nested_data"]["attributes"]:
            request_data["nested_data"]["attributes"][
                query_params.attribute_key
            ].append(query_params.attribute_value)
        else:
            request_data["nested_data"]["attributes"][query_params.attribute_key] = [
                query_params.attribute_value
            ]
    return request_data


async def create_request_api_contract_filters(query_params: SearchParams):
    request_data = {
        "nested_data": {
            "duration": {"month": [], "quarter": []},
            "demography": {"zone": [], "state": [], "city": [], "district": []},
            "attributes": {
                "styletype": [],
                "neckline": [],
                "pattern": [],
                "fabric_type": [],
                "sleeve": [],
                "fit": [],
                "color": [],
                "brand": [],
                "occasion": [],
                "bodytype": [],
                "materialtype": [],
                "distress": [],
                "traditionalweave": [],
                "hemline": [],
            },
            "brick_filters": {"l1_name": [], "l2_name": [], "brick_name": []},
        }
    }
    # Append demography filters
    if query_params.zone:
        request_data["nested_data"]["demography"]["zone"].append(query_params.zone)
    if query_params.state:
        request_data["nested_data"]["demography"]["state"].append(query_params.state)
    if query_params.city:
        request_data["nested_data"]["demography"]["city"].append(query_params.city)

    # Append brand name
    if query_params.brandname:
        request_data["nested_data"]["attributes"]["brand"].append(
            query_params.brandname
        )
    return request_data


async def create_request_api_contract_trends(query_params: ProductQueryParams):
    request_data = {
        "nested_data": {
            "duration": {"month": [], "quarter": []},
            "demography": {
                "zone": [],
                "state": [],
                "city": [],
                "district": [],
            },
            "attributes": {
                "styletype": [],
                "neckline": [],
                "pattern": [],
                "fabric_type": [],
                "sleeve": [],
                "fit": [],
                "color": [],
                "brand": [],
            },
            "store_filters": {"pincode": [], "store_id": []},
            "category": {
                "category_family": [],
                "category_class": [],
                "category": [],
            },
        },
        "page_no": query_params.page,
        "page_count": query_params.page_size,
        "sort_param": query_params.sort_attribute,
        "sort_type": query_params.sort_order,
    }
    # Append demography filters
    if query_params.zone:
        request_data["nested_data"]["demography"]["zone"].append(query_params.zone)
    if query_params.state:
        request_data["nested_data"]["demography"]["state"].append(query_params.state)
    if query_params.city:
        request_data["nested_data"]["demography"]["city"].append(query_params.city)

    # Append attribute key and value
    if query_params.attribute_key and query_params.attribute_value:
        if query_params.attribute_key in request_data["nested_data"]["attributes"]:
            request_data["nested_data"]["attributes"][
                query_params.attribute_key
            ].append(query_params.attribute_value)
        else:
            request_data["nested_data"]["attributes"][query_params.attribute_key] = [
                query_params.attribute_value
            ]

    return request_data


async def create_most_searched_attributes_query(
    query_params, attribute, start_week, latest_week
):
    # Combine conditions efficiently
    brick_conditions = []
    if query_params.category is not None:
        brick_conditions.append(AjioBrickDetails.l2name == query_params.category)
    if query_params.brickname is not None:
        brick_conditions.append(AjioBrickDetails.brickname == query_params.brickname)

    # Build the main query with joins and conditions
    search_query = (
        select(
            getattr(AjioProductAttributes, attribute),
            func.sum(AjioSearchQueriesTopInteractedProducts.sum_session_counts).label(
                "total_searches"
            ),
        )
        .join(
            AjioProductAttributes,
            AjioSearchQueriesTopInteractedProducts.productid
            == AjioProductAttributes.productid,
        )
        .join(
            AjioBrickDetails,
            AjioProductAttributes.similargrouplevel
            == AjioBrickDetails.similargrouplevel,
        )
        .where(
            and_(
                *brick_conditions,
                AjioSearchQueriesTopInteractedProducts.week_of_year.between(
                    start_week, latest_week + 1
                ),
            )
        )
        .group_by(
            getattr(AjioProductAttributes, attribute),
        )
        .order_by(
            func.sum(AjioSearchQueriesTopInteractedProducts.sum_session_counts).desc()
        )
        .limit(query_params.page_size)
        .offset(query_params.page_size * (query_params.page - 1))
    )

    return search_query


async def calculate_time_delta():
    cache_key = "min_max_week"
    cached_data = await redis_db.get(cache_key)
    if not cached_data:
        week_query = select(
            func.max(AjioSearchQueriesTopInteractedProducts.week_of_year)
        )
        week_result = await psql_execute_single(week_query)
        max_week = week_result[0][0]

        # Query to select the minimum week from the database
        min_week_query = select(
            func.min(AjioSearchQueriesTopInteractedProducts.week_of_year)
        )
        min_week_result = await psql_execute_single(min_week_query)
        min_week = min_week_result[0][0]

        await redis_db.set(cache_key, json.dumps([min_week, max_week]))

    print("time-delta loaded")


async def create_most_searched_filters(query_params: SearchParams):
    # Combine conditions efficiently
    brick_conditions = []
    if query_params.category is not None:
        brick_conditions.append(AjioBrickDetails.l2name == query_params.category)
    if query_params.brickname is not None:
        brick_conditions.append(AjioBrickDetails.brickname == query_params.brickname)

    demographic_conditions = []
    if query_params.city is not None:
        demographic_conditions.append(AjioDemographicDetails.city == query_params.city)
    if query_params.state is not None:
        demographic_conditions.append(
            AjioDemographicDetails.state == query_params.state
        )

    return brick_conditions, demographic_conditions


async def create_bestseller_attribute_query(
    query_params: AttributeQueryParams, attribute, week
):
    query = (
        select(
            getattr(AjioProductAttributes, attribute),
            func.sum(
                case(
                    (
                        AjioBestSellers.week_of_year == week,
                        AjioBestSellers.sold_quantity_in_a_week,
                    ),
                    else_=0,
                )
            ).label("current_week_sales"),
            func.sum(
                case(
                    (
                        AjioBestSellers.week_of_year == week - 1,
                        AjioBestSellers.sold_quantity_in_a_week,
                    ),
                    else_=0,
                )
            ).label("previous_week_sales"),
        )
        .join(
            AjioBrickDetails,
            AjioBrickDetails.similargrouplevel
            == AjioProductAttributes.similargrouplevel,
        )
        .join(
            AjioBestSellers,
            AjioBestSellers.productid == AjioProductAttributes.productid,
        )
        .where(
            AjioBrickDetails.l2name == query_params.category,
            getattr(AjioProductAttributes, attribute) != "nan",
            or_(
                AjioBestSellers.week_of_year == week,
                AjioBestSellers.week_of_year == week - 1,
            ),
        )
        .group_by(getattr(AjioProductAttributes, attribute))
        .limit(query_params.page_size)
        .offset((query_params.page - 1) * query_params.page_size)
    )

    return query


def create_bestseller_query(model, duration: int, demographic_column: str):
    return (
        select(
            model.productid,
            getattr(model, demographic_column),
            model.sold_quantity,
            model.healthy_live_days,
        )
        .where(model.num_past_days == duration)
        .cte()
    )

    # Use bestseller_query_ajio and bestseller_query_trends as needed


async def api_contract_ajio_bestseller_query(
    request_data_ajio, query_params: ProductQueryParams
):
    ajio_bestseller_query = create_bestseller_query(
        BestsellersAjio, query_params.num_days.value, "pincode"
    )

    # trends_bestseller_query = create_bestseller_query(
    #     BestsellersTrends, query_params.num_days.value, "store_id"
    # )

    demographic_filter = await build_filter_condition(
        request_filters=request_data_ajio, filter_flag="demographic", type="ajio"
    )

    demographic_query = await construct_filtered_query(
        AjioDemographicDetails, demographic_filter, ["pincode"]
    )

    brick_filter = await build_filter_condition(
        request_filters=request_data_ajio, filter_flag="brick", type="ajio"
    )
    brick_query = await construct_filtered_query(
        AjioBrickDetails, brick_filter, ["similargrouplevel"]
    )
    attribute_filter = await build_filter_condition(
        request_filters=request_data_ajio, filter_flag="products", type="ajio"
    )

    if query_params.min_mrp is not None and query_params.max_mrp is not None:
        mrp_condition = AjioProductAttributes.mrp.between(
            query_params.min_mrp, query_params.max_mrp
        )
        attribute_filter.append(mrp_condition)

    attribute_query = await construct_filtered_query(
        AjioProductAttributes,
        attribute_filter,
        ["productid", "similargrouplevel"],
    )

    ajio_ros_query = (
        select(
            ajio_bestseller_query.c.productid,
            (
                func.sum(ajio_bestseller_query.c.sold_quantity)
                / func.avg(ajio_bestseller_query.c.healthy_live_days)
            ).label("weekly_rate_of_sale"),
        )
        .join(
            demographic_query,
            demographic_query.c.pincode == ajio_bestseller_query.c.pincode,
        )
        .join(
            attribute_query,
            attribute_query.c.productid == ajio_bestseller_query.c.productid,
        )
        .join(
            brick_query,
            brick_query.c.similargrouplevel == attribute_query.c.similargrouplevel,
        )
        .group_by(ajio_bestseller_query.c.productid)
        .cte("ajio_ros_query")
    )

    breakpoint()

    # trends_ros_query = (
    #     select(
    #         trends_bestseller_query.c.productid,
    #         func.sum(trends_bestseller_query.c.sold_quantity)
    #         / func.avg(trends_bestseller_query.c.healthy_live_days),
    #     )
    #     .join(
    #         demographic_query,
    #         demographic_query.c.pincode == trends_bestseller_query.c.pincode,
    #     )
    #     .join(
    #         attribute_query,
    #         attribute_query.c.productid == trends_bestseller_query.c.productid,
    #     )
    #     .join(
    #         brick_query,
    #         brick_query.c.similargrouplevel == attribute_query.c.similargrouplevel,
    #     )
    #     .cte("trends_ros_query")
    # )

    attribute_filter = await build_filter_condition(
        request_filters=request_data_ajio, filter_flag="products", type="ajio"
    )
    attribute_query = await construct_filtered_query(
        AjioProductAttributes,
        attribute_filter,
        ["productid", "title", "imgcode", "brandname", "similargrouplevel"],
    )

    # join all the query and then sort trim
    bestseller_query = select(
        ajio_ros_query.c.productid,
        attribute_query.c.title,
        attribute_query.c.brandname,
        # attribute_query.c.mrp,
        ajio_ros_query.c.weekly_rate_of_sale,
        attribute_query.c.imgcode,
    ).join(
        attribute_query,
        attribute_query.c.productid == ajio_ros_query.c.productid,
    )

    return bestseller_query


async def api_contract_trends_bestseller_query(request_data_trends):
    (
        bestseller_filter_trends,
        store_filter_trends,
        calender_filter_trends,
    ) = await asyncio.gather(
        build_filter_condition(
            type="trends",
            request_filters=request_data_trends,
            filter_flag="bestsellers",
        ),
        build_filter_condition(
            type="trends",
            request_filters=request_data_trends,
            filter_flag="store_filters",
        ),
        build_filter_condition(
            type="calender",
            request_filters=request_data_trends,
            filter_flag="calender",
        ),
    )

    bestseller_query = (
        select(
            TrendsBestSellers.itemid,
            TrendsBestSellers.week_of_year,
            TrendsBestSellers.year,
            TrendsBestSellers.store_id,
            TrendsBestSellers.sold_quantity_in_a_week,
        )
        .where(and_(*bestseller_filter_trends))
        .cte()
    )

    store_query = (
        select(
            TrendsStoreDetails.store_id,
        )
        .where(and_(*store_filter_trends))
        .cte()
    )

    calender_query = (
        select(
            Calenderyearmonthweekinfo.week_of_year,
            Calenderyearmonthweekinfo.year,
            func.sum(Calenderyearmonthweekinfo.num_days_in_week).label(
                "total_days_count_across_week"
            ),
        )
        .where(and_(*calender_filter_trends))
        .group_by(
            Calenderyearmonthweekinfo.week_of_year, Calenderyearmonthweekinfo.year
        )
        .cte()
    )

    ros_query = (
        select(
            bestseller_query.c.itemid,
            bestseller_query.c.week_of_year,
            bestseller_query.c.year,
            func.sum(bestseller_query.c.sold_quantity_in_a_week).label(
                "sold_quantity_across_each_week"
            ),
        )
        .join(store_query, store_query.c.store_id == bestseller_query.c.store_id)
        .group_by(
            bestseller_query.c.itemid,
            bestseller_query.c.week_of_year,
            bestseller_query.c.year,
        )
        .cte()
    )

    # join ros and calender query
    ros_query = (
        select(
            ros_query.c.itemid,
            ros_query.c.year,
            ros_query.c.sold_quantity_across_each_week,
            calender_query.c.total_days_count_across_week,
        )
        .join(
            calender_query,
            and_(
                calender_query.c.week_of_year == ros_query.c.week_of_year,
                calender_query.c.year == ros_query.c.year,
            ),
        )
        .cte()
    )

    trends_query = select(
        ros_query.c.itemid,
        ros_query.c.year,
        func.round(
            cast(
                (
                    (
                        func.sum(ros_query.c.sold_quantity_across_each_week)
                        / func.sum(ros_query.c.total_days_count_across_week)
                    )
                    * 7
                ),
                Numeric,
            ),
            2,
        ).label("weekly_rate_of_sale"),
    ).group_by(ros_query.c.itemid, ros_query.c.year)

    return trends_query


async def execute_category_query(
    query_params: ProductQueryParams, category_images
) -> list:
    query = select(
        AjioBrickDetails.l2name.distinct(),
    ).where(AjioBrickDetails.l1name == query_params.gender)
    result = await psql_execute_single(query)

    # join the query l2name with the category_images to create final response
    result = [
        {
            "category": row[0],
            "id": category_images.get(row[0], {}).get("id", ""),
            "imgcode": category_images.get(row[0], {}).get("imgcode", ""),
        }
        for row in result
    ]
    return result


async def execute_most_searched_trends_query(
    query_params: SearchTrendsRequest, min_week, max_week
) -> list:
    brick_conditions = []
    if query_params.category is not None:
        brick_conditions.append(AjioBrickDetails.l2name == query_params.category)
    if query_params.brickname is not None:
        brick_conditions.append(AjioBrickDetails.brickname == query_params.brickname)

    no_of_weeks = query_params.num_days // 7
    start_week = max_week - no_of_weeks + 1
    # Ensure the starting week is not earlier than the minimum week present
    if start_week < min_week:
        start_week = min_week

    page = query_params.page
    page_size = query_params.page_size

    search_query = (
        select(
            AjioSearchQueriesTopInteractedProducts.normalized_search_term,
            AjioSearchQueriesTopInteractedProducts.week_of_year,
            func.sum(AjioSearchQueriesTopInteractedProducts.sum_session_counts).label(
                "total_searches"
            ),
        )
        .join(
            AjioProductAttributes,
            AjioSearchQueriesTopInteractedProducts.productid
            == AjioProductAttributes.productid,
        )
        .join(
            AjioBrickDetails,
            AjioProductAttributes.similargrouplevel
            == AjioBrickDetails.similargrouplevel,
            isouter=True,
        )
        .group_by(
            AjioSearchQueriesTopInteractedProducts.normalized_search_term,
            AjioSearchQueriesTopInteractedProducts.week_of_year,
        )
        .where(
            *brick_conditions,
            AjioSearchQueriesTopInteractedProducts.week_of_year.between(
                start_week, max_week + 1
            ),
        )
    ).cte()

    # Aggregated query with json_agg
    aggregated_query = (
        select(
            search_query.c.normalized_search_term,
            func.json_agg(
                aggregate_order_by(
                    func.json_build_object(
                        "week_no",
                        search_query.c.week_of_year,
                        "total_searches",
                        search_query.c.total_searches,
                    ),
                    search_query.c.week_of_year,
                )
            ).label("searches_ordered"),
            func.sum(search_query.c.total_searches).label("total_searches"),
        )
        .group_by(search_query.c.normalized_search_term)
        .order_by(func.sum(search_query.c.total_searches).desc())
        .limit(page_size)
        .offset((page - 1) * page_size)
    )

    last_searched_timestamp_query = (
        select(
            AjioSearchQueriesTopInteractedProducts.normalized_search_term,
            func.max(AjioSearchQueriesTopInteractedProducts.week_of_year).label(
                "last_searched_timestamp"
            ),
        ).group_by(AjioSearchQueriesTopInteractedProducts.normalized_search_term)
    ).cte()

    final_query = (
        select(
            aggregated_query.c.normalized_search_term,
            aggregated_query.c.searches_ordered,
            aggregated_query.c.total_searches,
            last_searched_timestamp_query.c.last_searched_timestamp,
        )
        .join(
            last_searched_timestamp_query,
            aggregated_query.c.normalized_search_term
            == last_searched_timestamp_query.c.normalized_search_term,
        )
        .order_by(aggregated_query.c.total_searches.desc())
    )

    result = await psql_execute_single(final_query)
    current_week = datetime.now().isocalendar()[1]
    result = [
        {
            "name": row[0],
            "last_searched_timestamp": (current_week - row[3]) * 7,
            "search_distribution": {
                "divisions": max_week - start_week + 1,
                "data": [
                    {entry["week_no"]: entry["total_searches"] for entry in row[1]}.get(
                        week, 0
                    )
                    for week in range(start_week, max_week + 1)
                ],
            },
            "total_searches": row[2],
        }
        for row in result
    ]
    return result


async def execute_most_searched_attributes_query(
    query_params: SearchParams, min_week, max_week
) -> dict:
    no_of_weeks = query_params.num_days // 7
    start_week = max_week - no_of_weeks + 1
    # Ensure the starting week is not earlier than the minimum week present
    if start_week < min_week:
        start_week = min_week

    # create a list of queries for each attribute
    if query_params.attribute == "all":
        query_list = [
            await create_most_searched_attributes_query(
                query_params, attribute, start_week, max_week
            )
            for attribute in api_contract_search_attributes
        ]

        results = await psql_execute_multiple(query_list)

        data = []
        for result in results:
            count = 0
            for row in result:
                count += row[1]
            response = {
                "attribute": api_contract_search_attributes[results.index(result)],
                "distribution": [
                    {"name": row[0], "percentage": round(((row[1] * 100) / count), 2)}
                    for row in result
                ],
            }
            data.append(response)

    else:
        query = await create_most_searched_attributes_query(
            query_params, query_params.attribute, start_week, max_week
        )

        results = await psql_execute_single(query)

        count = 0
        for row in results:
            count += row[1]
        data = {
            "attribute": query_params.attribute,
            "distribution": [
                {"name": row[0], "percentage": round(((row[1] * 100) / count), 2)}
                for row in results
            ],
        }

    return data


async def get_v2_products_filters(query_params):
    product_params = [
        "brandname",
        "fabrictype",
        "sleevelength",
        "fit",
        "colorfamily",
        "pattern",
        "neckline",
        "styletype",
        "hemline",
        "traditionalweave",
        "distress",
        "materialtype",
        "bodytype",
        "occasion",
        "mrp",
    ]

    product_filters = []

    # Iterate over product parameters and build filters
    for param in product_params:
        value = getattr(query_params, param, None)
        if value:
            product_filters.append(getattr(AjioProductAttributesV2, param) == value)

    if query_params.min_price is not None:
        product_filters.append(AjioProductAttributesV2.mrp >= query_params.min_price)
    if query_params.max_price is not None:
        product_filters.append(AjioProductAttributesV2.mrp <= query_params.max_price)

    product_query = (
        select(
            AjioProductAttributesV2.productid,
        )
        .where(and_(*product_filters))
        .cte()
    )

    mrp_query = select(
        func.max(AjioProductAttributesV2.mrp), func.min(AjioProductAttributesV2.mrp)
    ).where(and_(*product_filters))

    product_combination_query = (
        select(
            AjioProductAttributeCombination.attribute_name,
            AjioProductAttributeCombination.attribute_value,
            AjioProductAttributeCombination.similargrouplevel,
        )
        .join(
            product_query,
            product_query.c.productid == AjioProductAttributeCombination.productid,
        )
        .cte()
    )

    brick_filters = form_condition(
        AjioBrickDetailsV2,
        {
            "l1name": query_params.gender,
            "l2name": query_params.category,
            "brickname": query_params.brickname,
        },
    )
    brick_query = await construct_filtered_query(
        AjioBrickDetailsV2, list(brick_filters), ["similargrouplevel"]
    )

    final_product_query = (
        select(
            product_combination_query.c.attribute_name,
            product_combination_query.c.attribute_value,
        )
        .group_by(
            product_combination_query.c.attribute_name,
            product_combination_query.c.attribute_value,
        )
        .join(
            brick_query,
            brick_query.c.similargrouplevel
            == product_combination_query.c.similargrouplevel,
        )
    ).cte()

    final_product_query = select(
        final_product_query.c.attribute_name,
        func.array_agg(final_product_query.c.attribute_value).label("attribute_values"),
    ).group_by(final_product_query.c.attribute_name)

    query_list = [final_product_query, mrp_query]
    result = await psql_execute_multiple(query_list)

    response = {}
    for row in result[0]:
        response[row[0]] = row[1]

    response["price"] = {"max_price": result[1][0][0], "min_price": result[1][0][1]}

    return response


async def get_v2_bricks_filters(query_params):
    brick_filters = form_condition(
        AjioBrickDetailsV2,
        {
            "l1name": query_params.gender,
            "l2name": query_params.category,
            "brickname": query_params.brickname,
        },
    )

    brick_columns = ["l1name", "l2name", "brickname"]
    query_list = []
    for column in brick_columns:
        brick_query = await construct_filtered_query(
            AjioBrickDetailsV2, list(brick_filters), distinct_column=column
        )
        query_list.append(brick_query)

    result = await psql_execute_multiple(query_list)

    response = {}
    for index, column in enumerate(brick_columns):
        response[column] = [row[0] for row in result[index]]
    return response


async def get_v2_demographic_filters(query_params):
    demographic_filters = form_condition(
        AjioDemographicDetailsV2,
        {
            "zone": query_params.zone,
            "state": query_params.state,
            "city": query_params.city,
            "pincode": query_params.pincode,
        },
    )

    demography_columns = ["zone", "state", "city", "districtsname", "pincode"]
    query_list = []
    for column in demography_columns:
        demographic_query = await construct_filtered_query(
            AjioDemographicDetailsV2, list(demographic_filters), distinct_column=column
        )
        query_list.append(demographic_query)

    result = await psql_execute_multiple(query_list)

    response = {}
    for index, column in enumerate(demography_columns):
        response[column] = [row[0] for row in result[index]]
    return response


async def get_v2_duration_filters():
    duration_query = select(
        PastDaysMetadata.start_date,
        PastDaysMetadata.end_date,
        PastDaysMetadata.num_past_days,
    )

    result = await psql_execute_single(duration_query)

    response = []
    for row in result:
        response.append(
            {
                "start_date": row[0].date(),
                "end_date": row[1].date(),
                "num_past_days": row[2],
            }
        )
    return response


async def get_v2_filters(query_params):
    # List of methods to call
    methods: list[Callable] = [
        get_v2_duration_filters,
        lambda: get_v2_bricks_filters(query_params),
        lambda: get_v2_demographic_filters(query_params),
        lambda: get_v2_products_filters(query_params),
    ]

    # Call each method and gather results
    results = await asyncio.gather(*(method() for method in methods))

    duration_result, brick_result, demographic_result, product_result = results

    # List of keys and their display names
    attributes_dict = [
        ("duration", "duration", "Duration", duration_result),
        ("l1name", "l1name", "L1 Name", brick_result.get("l1name", [])),
        ("l2name", "l2name", "L2 Name", brick_result.get("l2name", [])),
        ("brickname", "brickname", "Brick Name", brick_result.get("brickname", [])),
        ("zone", "zone", "Zone", demographic_result.get("zone", [])),
        ("state", "state", "State", demographic_result.get("state", [])),
        ("city", "city", "City", demographic_result.get("city", [])),
        (
            "district",
            "district",
            "District",
            demographic_result.get("districtsname", []),
        ),
        ("pincode", "pincode", "Pincode", demographic_result.get("pincode", [])),
        (
            "colorfamily",
            "colorfamily",
            "Color Family",
            product_result.get("colorfamily", []),
        ),
        (
            "fabrictype",
            "fabrictype",
            "Fabric Type",
            product_result.get("fabrictype", []),
        ),
        ("neckline", "neckline", "Neckline", product_result.get("neckline", [])),
        ("occasion", "occasion", "Occasion", product_result.get("occasion", [])),
        ("pattern", "pattern", "Pattern", product_result.get("pattern", [])),
        ("styletype", "styletype", "Style Type", product_result.get("styletype", [])),
        (
            "sleevelength",
            "sleevelength",
            "Sleeve Length",
            product_result.get("sleevelength", []),
        ),
        ("fit", "fit", "Fit", product_result.get("fit", [])),
        ("hemline", "hemline", "Hemline", product_result.get("hemline", [])),
        (
            "traditionalweave",
            "traditionalweave",
            "Traditional Weave",
            product_result.get("traditionalweave", []),
        ),
        ("distress", "distress", "Distress", product_result.get("distress", [])),
        (
            "materialtype",
            "materialtype",
            "Material Type",
            product_result.get("materialtype", []),
        ),
        ("bodytype", "bodytype", "Body Type", product_result.get("bodytype", [])),
        (
            "Price",
            "price",
            "PRICE",
            {
                "max_price": product_result.get("price", {}).get("max_price"),
                "min_price": product_result.get("price", {}).get("min_price"),
            }
            if product_result.get("price")
            else None,
        ),
    ]

    # Construct the combined result using a loop
    combined_result = {}
    for key, name, display_name, values in attributes_dict:
        if values:
            combined_result[key] = {
                "name": name,
                "displayName": display_name,
                "values": values,
            }

    return combined_result


async def execute_most_searched_trends_service(query_params):
    cache_key = (
        f"api_contract_most_searched_trends{json.dumps(query_params.model_dump())}"
    )
    cached_data = await check_in_redis(cache_key)

    if cached_data:
        data = json.loads(cached_data)
        current_week = datetime.now().isocalendar()[1]
        for item in data:
            item["last_searched_timestamp"] = (
                current_week - item["last_searched_timestamp"]
            ) * 7

        return data
    cache_key_min_max = "min_max_week"
    min_max_week = await redis_db.get(cache_key_min_max)
    if min_max_week:
        min_week, max_week = json.loads(min_max_week)
    else:
        await calculate_time_delta()
        min_max_week = await redis_db.get(cache_key_min_max)
        min_week, max_week = json.loads(min_max_week)

    result = await execute_most_searched_trends_query(
        query_params=query_params,
        min_week=min_week,
        max_week=max_week,
    )
    try:
        await redis_db.set(cache_key, json.dumps(result, default=str))
    except Exception as e:
        print(REDIS_WRITE_ERROR, e)

    return result
