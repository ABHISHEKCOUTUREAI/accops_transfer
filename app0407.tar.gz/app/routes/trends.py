from fastapi import APIRouter, Depends
from fastapi.responses import JSONResponse
from static import setup_logging
from utils import (
    get_attributes_bestsellers_trends,
    get_statewise_sales_trends,
    get_trends_bestseller_month_level,
    get_trends_bestseller_week_level,
    get_trends_filters_service,
)

TrendsRouter = APIRouter(tags=["Trends"])


@TrendsRouter.post("/trends-filters")
async def get_trends_filters(
    request_data: dict,
    logger=Depends(setup_logging),
):
    try:
        return await get_trends_filters_service(request_data)
    except Exception as e:
        logger.error(e, exc_info=True)
        return JSONResponse(content={"error": "Internal Server Error"}, status_code=500)


@TrendsRouter.post("/bestsellers-products-trends")
async def bestsellers_products_trends(
    request_data: dict,
    logger=Depends(setup_logging),
):
    try:
        if request_data.get("nested_data", {}).get("duration", {}).get("week"):
            result = await get_trends_bestseller_week_level(request_data)
        else:
            result = await get_trends_bestseller_month_level(request_data)

        return result
    except Exception as e:
        logger.error(e, exc_info=True)
        return JSONResponse(content={"error": "Internal Server Error"}, status_code=500)


@TrendsRouter.post("/statewise-sales-trends")
async def get_statewise_sales(
    request_data: dict,
    logger=Depends(setup_logging),
):
    try:
        return await get_statewise_sales_trends(request_data)
    except Exception as e:
        logger.error(e, exc_info=True)
        return JSONResponse(content={"error": "Internal Server Error"}, status_code=500)


@TrendsRouter.post("/fabric-bestsellers-trends")
async def get_fabric_bestsellers_trends(
    request_data: dict,
    logger=Depends(setup_logging),
):
    try:
        result = await get_attributes_bestsellers_trends(
            request_data,
            "fabrictype",
        )
        return result
    except Exception as e:
        logger.error(e, exc_info=True)
        return JSONResponse(content={"error": "Internal Server Error"}, status_code=500)


@TrendsRouter.post("/brandnames-bestsellers-trends")
async def brandnames_bestsellers_trends(
    request_data: dict,
    logger=Depends(setup_logging),
):
    try:
        result = await get_attributes_bestsellers_trends(
            request_data,
            "brandname",
        )
        return result
    except Exception as e:
        logger.error(e, exc_info=True)
        return JSONResponse(content={"error": "Internal Server Error"}, status_code=500)


@TrendsRouter.post("/neckline-bestsellers-trends")
async def neckline_bestsellers_trends(
    request_data: dict,
    logger=Depends(setup_logging),
):
    try:
        result = await get_attributes_bestsellers_trends(
            request_data,
            "neckline",
        )
        return result
    except Exception as e:
        logger.error(e, exc_info=True)
        return JSONResponse(content={"error": "Internal Server Error"}, status_code=500)


@TrendsRouter.post("/styletype-bestsellers-trends")
async def styletype_bestsellers_trends(
    request_data: dict,
    logger=Depends(setup_logging),
):
    try:
        result = await get_attributes_bestsellers_trends(
            request_data,
            "styletype",
        )
        return result
    except Exception as e:
        logger.error(e, exc_info=True)
        return JSONResponse(content={"error": "Internal Server Error"}, status_code=500)


@TrendsRouter.post("/sleevelength-bestsellers-trends")
async def sleevelength_bestsellers_trends(
    request_data: dict,
    logger=Depends(setup_logging),
):
    try:
        result = await get_attributes_bestsellers_trends(
            request_data,
            "sleeve",
        )

        return result
    except Exception as e:
        logger.error(e, exc_info=True)
        return JSONResponse(content={"error": "Internal Server Error"}, status_code=500)


@TrendsRouter.post("/pattern-bestsellers-trends")
async def pattern_bestsellers_trends(
    request_data: dict,
    logger=Depends(setup_logging),
):
    try:
        result = await get_attributes_bestsellers_trends(
            request_data,
            "pattern",
        )

        return result
    except Exception as e:
        logger.error(e, exc_info=True)
        return JSONResponse(content={"error": "Internal Server Error"}, status_code=500)


@TrendsRouter.post("/color-bestsellers-trends")
async def color_bestsellers_trends(
    request_data: dict,
    logger=Depends(setup_logging),
):
    try:
        result = await get_attributes_bestsellers_trends(
            request_data,
            "primarycolor",
        )

        return result
    except Exception as e:
        logger.error(e, exc_info=True)
        return JSONResponse(content={"error": "Internal Server Error"}, status_code=500)
