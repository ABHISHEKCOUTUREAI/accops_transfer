import json

from db import redis_db
from fastapi import APIRouter, Depends
from fastapi.responses import JSONResponse
from models import (
    AttributeQueryParams,
    CategoryQueryParams,
    FilterQuery,
    ProductQueryParams,
    SearchParams,
    SearchTrends,
)
from static import setup_logging
from utils import (
    calculate_time_delta,
    execute_attribute_query,
    execute_category_query,
    execute_filters_query,
    execute_most_searched_attributes_query,
    execute_most_searched_trends_service,
    execute_products_query,
    load_attributes_images,
    load_category_images,
)

BestSellerAPIContractRouter = APIRouter(tags=["API Contract"])


@BestSellerAPIContractRouter.get("/products")
async def get_bestseller_products(
    query_params: ProductQueryParams = Depends(),
    logger=Depends(setup_logging),
):
    try:
        result = await execute_products_query(query_params=query_params)
        return result
    except Exception as e:
        logger.error(e, exc_info=True)
        return JSONResponse(content={"error": "Internal Server Error"}, status_code=500)


@BestSellerAPIContractRouter.get("/category")
async def get_category(
    query_params: CategoryQueryParams = Depends(),
    logger=Depends(setup_logging),
):
    try:
        # load the category images
        category_images = await redis_db.get("category_images")
        if category_images:
            category_images = json.loads(category_images)
        else:
            await load_category_images()
            category_images = await redis_db.get("category_images")
            category_images = json.loads(category_images)

        result = await execute_category_query(
            query_params=query_params, category_images=category_images
        )

        return result

    except Exception as e:
        logger.error(e, exc_info=True)
        return JSONResponse(content={"error": "Internal Server Error"}, status_code=500)


@BestSellerAPIContractRouter.get("/attributes")
async def get_bestseller_attributes(
    query_params: AttributeQueryParams = Depends(),
    logger=Depends(setup_logging),
):
    try:
        # get attributes images
        attributes_images = await redis_db.get("attributes_images")
        if attributes_images:
            attributes_images = json.loads(attributes_images)
        else:
            await load_attributes_images()
            attributes_images = await redis_db.get("attributes_images")
            attributes_images = json.loads(attributes_images)

        result = await execute_attribute_query(
            query_params=query_params, attributes_images=attributes_images
        )

        return result
    except Exception as e:
        logger.error(e, exc_info=True)
        return JSONResponse(content={"error": "Internal Server Error"}, status_code=500)


@BestSellerAPIContractRouter.get("/most-searched-trends")
async def get_most_searched_trends(
    query_params: SearchTrends = Depends(),
    logger=Depends(setup_logging),
):
    try:
        result = await execute_most_searched_trends_service(query_params=query_params)
        return result
    except Exception as e:
        logger.error(e, exc_info=True)
        return JSONResponse(content={"error": "Internal Server Error"}, status_code=500)


@BestSellerAPIContractRouter.get("/most-searched-attributes")
async def get_most_searched_attributes(
    query_params: SearchParams = Depends(),
    logger=Depends(setup_logging),
):
    try:
        # start_week, latest_week = await calculate_time_delta(query_params)
        cache_key_min_max = "min_max_week"
        min_max_week = await redis_db.get(cache_key_min_max)
        if min_max_week:
            min_week, max_week = json.loads(min_max_week)
        else:
            await calculate_time_delta()
            min_max_week = await redis_db.get(cache_key_min_max)
            min_week, max_week = json.loads(min_max_week)

        data = await execute_most_searched_attributes_query(
            query_params=query_params, min_week=min_week, max_week=max_week
        )

        return data
    except Exception as e:
        logger.error(e, exc_info=True)
        return JSONResponse(content={"error": "Internal Server Error"}, status_code=500)


@BestSellerAPIContractRouter.get("/filters")
async def get_api_contract_filters(
    query_params: FilterQuery = Depends(),
    logger=Depends(setup_logging),
):
    try:
        result = await execute_filters_query(query_params=query_params)
        return result
    except Exception as e:
        logger.error(e, exc_info=True)
        return JSONResponse(content={"error": "Internal Server Error"}, status_code=500)
