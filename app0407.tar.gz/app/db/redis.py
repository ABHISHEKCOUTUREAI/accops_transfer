from redis import asyncio as aioredis
from settings import settings

try:
    redis_url = (
        f"redis://{settings.redis_service}:{settings.redis_port}/{settings.redis_db}"
    )
    redis_db = aioredis.from_url(redis_url)
    print("Connected to Redis")
except Exception as e:
    print(f"Error connecting to Redis: {e}")
    redis_db = None


async def set_redis_state(flush_db: bool = settings.redis_state):
    if flush_db:
        await redis_db.flushdb()
        print("Redis state set to initial state")
    else:
        print("Redis state retained")


async def flush_redis_key(key: str):
    try:
        keys = await redis_db.keys(f"{key}*")
        if keys:
            # Ensure keys are passed as separate arguments using the * operator
            await redis_db.delete(*keys)
            print(f"Deleted keys starting with {key}")
        else:
            print(f"No keys found starting with {key}")
    except Exception as e:
        print(f"An error occurred: {e}")


async def check_in_redis(cache_key):
    try:
        cached_data = await redis_db.get(cache_key)
    except Exception as e:
        print("Not connected to redis: ", e)
        cached_data = None

    return cached_data


async def ping_redis():
    try:
        ping = await redis_db.ping()
        if ping:
            print("Redis is up and running")
        else:
            print("Redis is not running")
    except Exception as e:
        print("Not connected to redis: ", e)

    try:
        await redis_db.set(name="test-key", value="test-value")
        print("Key value set in redis")
    except Exception as e:
        print("Not able to set in redis: ", e)

    try:
        value = await redis_db.get("test-key")
        print("Key value retrieved from redis: ", value)
    except Exception as e:
        print("Not able to get from redis: ", e)
