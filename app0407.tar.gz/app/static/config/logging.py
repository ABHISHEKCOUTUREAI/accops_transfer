import logging
import time

logger = logging.getLogger("fast-fashion")
stream_handler = logging.StreamHandler()
stream_handler.setLevel(logging.DEBUG)
stream_handler.setFormatter(
    logging.Formatter("%(asctime)s %(message)s [%(pathname)s:%(lineno)d] \n")
)
logger.addHandler(stream_handler)
logging.getLogger().info("This prints the stack", stack_info=True)

# Log an error message with the error number and file number
logging.basicConfig(
    format="%(asctime)s %(message)s {%(pathname)s:%(lineno)d} \n",  # Include '\n' for line break
    filename="app.log",
    encoding="utf-8",
    level=logging.DEBUG,
)


def setup_logging():
    return logger


def log_function_duration(func):
    def wrapper(*args, **kwargs):
        start_time = time.time()
        result = func(*args, **kwargs)
        duration = time.time() - start_time
        logging.info(f"Function {func.__name__} took {duration} seconds to execute")
        return result
    return wrapper
