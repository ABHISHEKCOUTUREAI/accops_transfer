from models import (
    AjioBestSellers,
    AjioBestSellersMonth,
    AjioBestsellersMonthDenormalised,
    AjioBestSellersWeek,
    AjioBrickDetails,
    AjioDemographicDetails,
    AjioProductAttributes,
    AjioSearchQueriesTopInteractedProducts,
    Calenderyearmonthweekinfo,
    SearchInteractions,
    TrendsBestSellers,
    TrendsBestSellersMonth,
    TrendsBestSellersWeek,
    TrendsBrickDetails,
    TrendsProductAttributes,
    TrendsStoreDetails,
)

from .constants import (
    AJIO_BESTSELLERS_CSV,
    AJIO_BESTSELLERS_MONTH_CSV,
    AJIO_BESTSELLERS_WEEK_CSV,
    AJIO_BRICK_DETAILS_CSV,
    AJIO_DEMOGRAPHIC_DETAILS_CSV,
    AJIO_PRODUCT_ATTRIBUTES_CSV,
    AJIO_SEARCH_QUERIES_TOP_INTERACTED_PRODUCTS_CSV,
    CALENDER_DATA_CSV,
    TRENDS_BESTSELLERS_CSV,
    TRENDS_BESTSELLERS_MONTH_CSV,
    TRENDS_BESTSELLERS_WEEK_CSV,
    TRENDS_BRICK_DETAILS_CSV,
    TRENDS_PRODUCT_ATTRIBUTES_CSV,
    TRENDS_STORE_DETAILS_CSV,
)

data_upload_table_mapping = {
    "ajio_bestsellers": (AjioBestSellers, AJIO_BESTSELLERS_CSV),
    "ajio_best_sellers_week": (AjioBestSellersWeek, AJIO_BESTSELLERS_WEEK_CSV),
    "ajio_best_sellers_month": (AjioBestSellersMonth, AJIO_BESTSELLERS_MONTH_CSV),
    "ajio_brick_details": (AjioBrickDetails, AJIO_BRICK_DETAILS_CSV),
    "ajio_demographic_details": (AjioDemographicDetails, AJIO_DEMOGRAPHIC_DETAILS_CSV),
    "ajio_product_attributes": (AjioProductAttributes, AJIO_PRODUCT_ATTRIBUTES_CSV),
    "ajio_search_queries_top_interacted_products": (
        AjioSearchQueriesTopInteractedProducts,
        AJIO_SEARCH_QUERIES_TOP_INTERACTED_PRODUCTS_CSV,
    ),
    "trends_bestsellers": (TrendsBestSellers, TRENDS_BESTSELLERS_CSV),
    "trends_best_sellers_week": (TrendsBestSellersWeek, TRENDS_BESTSELLERS_WEEK_CSV),
    "trends_best_sellers_month": (TrendsBestSellersMonth, TRENDS_BESTSELLERS_MONTH_CSV),
    "trends_brick_details": (TrendsBrickDetails, TRENDS_BRICK_DETAILS_CSV),
    "trends_product_attributes": (
        TrendsProductAttributes,
        TRENDS_PRODUCT_ATTRIBUTES_CSV,
    ),
    "calender_data": (Calenderyearmonthweekinfo, CALENDER_DATA_CSV),
    "trends_store_details": (TrendsStoreDetails, TRENDS_STORE_DETAILS_CSV),
    "search_interactions": (SearchInteractions, None),
    "all": [
        (AjioBestSellers, AJIO_BESTSELLERS_CSV),
        (AjioBestSellersWeek, AJIO_BESTSELLERS_WEEK_CSV),
        (AjioBestSellersMonth, AJIO_BESTSELLERS_MONTH_CSV),
        (AjioBrickDetails, AJIO_BRICK_DETAILS_CSV),
        (AjioDemographicDetails, AJIO_DEMOGRAPHIC_DETAILS_CSV),
        (AjioProductAttributes, AJIO_PRODUCT_ATTRIBUTES_CSV),
        (
            AjioSearchQueriesTopInteractedProducts,
            AJIO_SEARCH_QUERIES_TOP_INTERACTED_PRODUCTS_CSV,
        ),
        (TrendsBestSellers, TRENDS_BESTSELLERS_CSV),
        (TrendsBestSellersWeek, TRENDS_BESTSELLERS_WEEK_CSV),
        (TrendsBestSellersMonth, TRENDS_BESTSELLERS_MONTH_CSV),
        (TrendsBrickDetails, TRENDS_BRICK_DETAILS_CSV),
        (TrendsProductAttributes, TRENDS_PRODUCT_ATTRIBUTES_CSV),
        (TrendsStoreDetails, TRENDS_STORE_DETAILS_CSV),
        (Calenderyearmonthweekinfo, CALENDER_DATA_CSV),
        (SearchInteractions, None),
    ],
}


request_column_model_map = {
    "month": {
        "model": {
            "ajio": AjioBestSellers,
            "trends": TrendsBestSellers,
            "ajio-search": AjioSearchQueriesTopInteractedProducts,
            "ajio-month": AjioBestSellersMonth,
            "ajio_month_normalised": AjioBestsellersMonthDenormalised,
        },
        "column": "month_of_year",
    },
    "week": {
        "model": {
            "ajio-search": AjioSearchQueriesTopInteractedProducts,
            "ajio": AjioBestSellersWeek,
            "trends": TrendsBestSellersWeek,
        },
        "column": "week_of_year",
    },
    "search_type": {
        "model": {"ajio-search": AjioSearchQueriesTopInteractedProducts},
        "column": "search_type",
    },
    "search_query": {
        "model": {"ajio-search": AjioSearchQueriesTopInteractedProducts},
        "column": "normalized_search_term",
    },
    "quarter": {
        "model": {"ajio": AjioBestSellers, "trends": TrendsBestSellers},
        "column": "quarter_of_year",
    },
    "zone": {
        "model": {
            "ajio": AjioDemographicDetails,
            "trends": TrendsStoreDetails,
            "ajio_month_normalised": AjioBestsellersMonthDenormalised,
        },
        "column": "zone",
    },
    "zone_desc": {
        "model": {"trends": TrendsStoreDetails},
        "column": "zone_desc",
    },
    "state": {
        "model": {
            "ajio": AjioDemographicDetails,
            "trends": TrendsStoreDetails,
            "ajio_month_normalised": AjioBestsellersMonthDenormalised,
        },
        "column": "state",
    },
    "city": {
        "model": {
            "ajio": AjioDemographicDetails,
            "trends": TrendsStoreDetails,
            "ajio_month_normalised": AjioBestsellersMonthDenormalised,
        },
        "column": "city",
    },
    "pincode": {
        "model": {
            "ajio": AjioDemographicDetails,
            "trends": TrendsStoreDetails,
            "ajio_month_normalised": AjioBestsellersMonthDenormalised,
        },
        "column": "pincode",
    },
    "district": {
        "model": {
            "ajio": AjioDemographicDetails,
            "trends": TrendsStoreDetails,
            "ajio_month_normalised": AjioBestsellersMonthDenormalised,
        },
        "column": "districtsname",
    },
    "brandname": {
        "model": {
            "ajio": AjioProductAttributes,
            "trends": TrendsProductAttributes,
            "ajio-search": AjioProductAttributes,
            "ajio_month_normalised": AjioBestsellersMonthDenormalised,
        },
        "column": "brandname",
    },
    "styletype": {
        "model": {
            "ajio": AjioProductAttributes,
            "trends": TrendsProductAttributes,
            "ajio_month_normalised": AjioBestsellersMonthDenormalised,
        },
        "column": "styletype",
    },
    "neckline": {
        "model": {
            "ajio": AjioProductAttributes,
            "trends": TrendsProductAttributes,
            "ajio_month_normalised": AjioBestsellersMonthDenormalised,
        },
        "column": "neckline",
    },
    "pattern": {
        "model": {
            "ajio": AjioProductAttributes,
            "trends": TrendsProductAttributes,
            "ajio_month_normalised": AjioBestsellersMonthDenormalised,
        },
        "column": "pattern",
    },
    "fabrictype": {
        "model": {
            "ajio": AjioProductAttributes,
            "trends": TrendsProductAttributes,
            "ajio_month_normalised": AjioBestsellersMonthDenormalised,
        },
        "column": "fabrictype",
    },
    "sleevelength": {
        "model": {
            "ajio": AjioProductAttributes,
            "trends": TrendsProductAttributes,
            "ajio_month_normalised": AjioBestsellersMonthDenormalised,
        },
        "column": "sleevelength",
    },
    "fit": {
        "model": {
            "ajio": AjioProductAttributes,
            "trends": TrendsProductAttributes,
            "ajio_month_normalised": AjioBestsellersMonthDenormalised,
        },
        "column": "fit",
    },
    "colorfamily": {
        "model": {
            "ajio": AjioProductAttributes,
            "trends": TrendsProductAttributes,
            "ajio_month_normalised": AjioBestsellersMonthDenormalised,
        },
        "column": "colorfamily",
    },
    "l1_name": {
        "model": {
            "ajio": AjioBrickDetails,
            "ajio-search": AjioBrickDetails,
            "ajio_month_normalised": AjioBestsellersMonthDenormalised,
        },
        "column": "l1name",
    },
    "l2_name": {
        "model": {
            "ajio": AjioBrickDetails,
            "ajio-search": AjioBrickDetails,
            "ajio_month_normalised": AjioBestsellersMonthDenormalised,
        },
        "column": "l2name",
    },
    "brick_name": {
        "model": {
            "ajio": AjioBrickDetails,
            "ajio-search": AjioBrickDetails,
            "ajio_month_normalised": AjioBestsellersMonthDenormalised,
        },
        "column": "brickname",
    },
    "occasion": {
        "model": {
            "ajio": AjioProductAttributes,
            "ajio_month_normalised": AjioBestsellersMonthDenormalised,
        },
        "column": "occasion",
    },
    "bodytype": {
        "model": {
            "ajio": AjioProductAttributes,
            "ajio_month_normalised": AjioBestsellersMonthDenormalised,
        },
        "column": "bodytype",
    },
    "materialtype": {
        "model": {
            "ajio": AjioProductAttributes,
            "ajio_month_normalised": AjioBestsellersMonthDenormalised,
        },
        "column": "materialtype",
    },
    "distress": {
        "model": {
            "ajio": AjioProductAttributes,
            "ajio_month_normalised": AjioBestsellersMonthDenormalised,
        },
        "column": "distress",
    },
    "traditionalweave": {
        "model": {
            "ajio": AjioProductAttributes,
            "ajio_month_normalised": AjioBestsellersMonthDenormalised,
        },
        "column": "traditionalweave",
    },
    "hemline": {
        "model": {
            "ajio": AjioProductAttributes,
            "ajio_month_normalised": AjioBestsellersMonthDenormalised,
        },
        "column": "hemline",
    },
    "store_id": {"model": {"trends": TrendsBestSellers}, "column": "store_id"},
    "category": {"model": {"trends": TrendsBrickDetails}, "column": "brickname"},
    "category_class": {
        "model": {"trends": TrendsBrickDetails},
        "column": "mh_class_desc",
    },
    "category_family": {
        "model": {"trends": TrendsBrickDetails},
        "column": "mh_family_desc",
    },
}


indian_states = {
    "Jammu and Kashmir": {"statecode": "JK", "zone": "North"},
    "andhra pradesh": {"statecode": "AP", "zone": "South"},
    "arunachal pradesh": {"statecode": "AR", "zone": "East"},
    "assam": {"statecode": "AS", "zone": "East"},
    "bihar": {"statecode": "BR", "zone": "East"},
    "chhattisgarh": {"statecode": "CT", "zone": "West"},
    "goa": {"statecode": "GA", "zone": "West"},
    "gujarat": {"statecode": "GJ", "zone": "West"},
    "haryana": {"statecode": "HR", "zone": "North"},
    "himachal pradesh": {"statecode": "HP", "zone": "North"},
    "jharkhand": {"statecode": "JH", "zone": "East"},
    "karnataka": {"statecode": "KA", "zone": "South"},
    "kerala": {"statecode": "KL", "zone": "South"},
    "madhya pradesh": {"statecode": "MP", "zone": "West"},
    "maharashtra": {"statecode": "MH", "zone": "West"},
    "manipur": {"statecode": "MN", "zone": "East"},
    "meghalaya": {"statecode": "ML", "zone": "East"},
    "mizoram": {"statecode": "MZ", "zone": "East"},
    "nagaland": {"statecode": "NL", "zone": "East"},
    "odisha": {"statecode": "OR", "zone": "East"},
    "punjab": {"statecode": "PB", "zone": "North"},
    "rajasthan": {"statecode": "RJ", "zone": "North"},
    "sikkim": {"statecode": "SK", "zone": "East"},
    "tamil nadu": {"statecode": "TN", "zone": "South"},
    "telangana": {"statecode": "TG", "zone": "South"},
    "tripura": {"statecode": "TR", "zone": "East"},
    "uttar pradesh": {"statecode": "UP", "zone": "North"},
    "uttarakhand": {"statecode": "UT", "zone": "North"},
    "west bengal": {"statecode": "WB", "zone": "East"},
    "andaman and nicobar islands": {"statecode": "AN", "zone": "South"},
    "chandigarh": {"statecode": "CH", "zone": "North"},
    "dadra and nagar haveli and daman and diu": {"statecode": "DN", "zone": "West"},
    "delhi": {"statecode": "DL", "zone": "North"},
    "lakshadweep": {"statecode": "LD", "zone": "South"},
    "puducherry": {"statecode": "PY", "zone": "South"},
}

month_mapping = {
    1: "January",
    2: "February",
    3: "March",
    4: "April",
    5: "May",
    6: "June",
    7: "July",
    8: "August",
    9: "September",
    10: "October",
    11: "November",
    12: "December",
}

reverse_month_mapping = {
    "January": 1,
    "February": 2,
    "March": 3,
    "April": 4,
    "May": 5,
    "June": 6,
    "July": 7,
    "August": 8,
    "September": 9,
    "October": 10,
    "November": 11,
    "December": 12,
}

filter_flag_model_map = {
    "duration": {
        "ajio-search": AjioSearchQueriesTopInteractedProducts,

    },
    "search": {"ajio-search": AjioSearchQueriesTopInteractedProducts},
    "bestsellers": {"ajio": AjioBestSellers, "trends": TrendsBestSellers},
    "demographic": {"ajio": AjioDemographicDetails, "trends": TrendsStoreDetails},
    "brick": {
        "ajio": AjioBrickDetails,
        "trends": TrendsStoreDetails,
        "ajio-search": AjioBrickDetails,
    },
    "attributes": {
        "ajio-search": AjioProductAttributes,
        "ajio": AjioProductAttributes,
        "trends": TrendsProductAttributes,
    },
    "products": {"ajio": AjioProductAttributes, "trends": TrendsProductAttributes},
    "store_filters": {"trends": TrendsStoreDetails},
    "category": {"trends": TrendsBrickDetails},
    "bestsellers_week": {"ajio": AjioBestSellersWeek, "trends": TrendsBestSellersWeek},
    "bestsellers_month": {
        "ajio": AjioBestSellersMonth,
        "trends": TrendsBestSellersMonth,
    },
    "calender": {"calender": Calenderyearmonthweekinfo},
    "bestsellers_month_denormalised": {
        "ajio_month_normalised": AjioBestsellersMonthDenormalised,
    },
}


product_columns = [
    "styletype",
    "neckline",
    "pattern",
    "fabrictype",
    "sleevelength",
    "fit",
    "colorfamily",
    "occasion",
    "bodytype",
    "materialtype",
    "distress",
    "traditionalweave",
    "hemline",
]

column_to_attribute_ajio_filter = {
    "styletype": 0,
    "neckline": 1,
    "pattern": 2,
    "fabrictype": 3,
    "sleevelength": 4,
    "fit": 5,
    "colorfamily": 6,
    "brandname": 7,
    "occasion": 8,
    "bodytype": 9,
    "materialtype": 10,
    "distress": 11,
    "traditionalweave": 12,
    "hemline": 13,
}
