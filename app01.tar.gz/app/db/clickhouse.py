
from clickhouse_sqlalchemy import (
    engines,
    get_declarative_base,
    make_session,
)
from sqlalchemy import (
    ARRAY,
    BigInteger,
    Column,
    Float,
    Index,
    Integer,
    MetaData,
    PrimaryKeyConstraint,
    String,
    create_engine,
)
from sqlalchemy.ext.asyncio import AsyncSession, create_async_engine
from sqlalchemy.orm import sessionmaker

CLICKHOUSE_ASYNC_URL = "clickhouse+asynch://default:password@localhost/ftfdb"


clickhouse_async_engine = create_async_engine(
    CLICKHOUSE_ASYNC_URL,
    connect_args={"compression": True},
    echo=True,
    pool_size=20,
    max_overflow=10,
)

# Create an asynchronous session factory
async_session_factory = sessionmaker(
    bind=clickhouse_async_engine, class_=AsyncSession, expire_on_commit=False
)

async def clickhouse_execute(query):
    async with async_session_factory() as session:
        try:
            result = await session.execute(query)
            return result.fetchall()
        except Exception as e:
            print("Error in fetching data: ", e)
            raise e
        


session = make_session(clickhouse_async_engine)
metadata = MetaData()
Base = get_declarative_base(metadata=metadata)





# SYNC ENGINE FOR CLICKHOUSE

CLICKHOUSE_SYNC_URL = "clickhouse://default:password@localhost/ftfdb"
clickhouse_sync_engine = create_engine(CLICKHOUSE_SYNC_URL)


class AjioBestSellers(Base):
    __tablename__ = "ajio_bestsellers_pincodes_top500"
    year = Column(Integer, primary_key=True)
    month_of_year = Column(Integer, primary_key=True)
    quarter_of_year = Column(Integer)
    week_of_year = Column(Integer, primary_key=True)
    pincode = Column(String, primary_key=True)
    productid = Column(String, primary_key=True)
    mrp = Column(Float)
    availablequantity_in_a_week = Column(BigInteger)
    sold_quantity_in_a_week = Column(BigInteger)


    __table_args__ = (
        engines.MergeTree("year", ("year", "month_of_year")),
        PrimaryKeyConstraint(
            "year", "month_of_year", "week_of_year", "pincode", "productid"
        ),
    )


class AjioBestSellersMonth(Base):
    __tablename__ = "ajio_bestsellers_month_level"
    year = Column(Integer, primary_key=True)
    quarter_of_year = Column(Integer)
    month_of_year = Column(Integer, primary_key=True)
    pincode = Column(String, primary_key=True)
    productid = Column(String, primary_key=True)
    sold_quantity_in_a_month = Column(BigInteger)
    healthy_live_days_in_a_month = Column(Integer)

    __table_args__ = (
        engines.MergeTree("year", ("year", "month_of_year")),
        PrimaryKeyConstraint("year", "month_of_year", "pincode", "productid"),
        # Index("idx_ajio_bestsellers_month_month", "month_of_year", dialect="clickhouse"),
        # Index("idx_ajio_bestsellers_month_pincode", "pincode", dialect="clickhouse"),
        # Index("idx_ajio_bestsellers_month_productid", "productid", dialect="clickhouse"),
    )

AjioBestSellersMonth.__table__.create(bind=clickhouse_sync_engine, checkfirst=True)

# write a script to load the data to the table from the csv file
# use the below command to load the data
# clickhouse-client --query="INSERT INTO ajio_bestsellers_month_level FORMAT CSV" < /path/to/csv/file.csv

class AjioBestSellersWeek(Base):
    __tablename__ = "ajio_bestsellers_recent_week_level"
    year = Column(Integer, primary_key=True)
    week_of_year = Column(Integer, primary_key=True)
    pincode = Column(String, primary_key=True)
    productid = Column(String, primary_key=True)
    start_date = Column(String)
    end_date = Column(String)
    sold_quantity_in_a_week = Column(BigInteger)
    healthy_live_days_in_a_week = Column(Integer)

    __table_args__ = (
        PrimaryKeyConstraint("year", "week_of_year", "pincode", "productid"),
        engines.MergeTree("year", ("year", "week_of_year")),
        # Index("idx_ajio_bestsellers_week_week", "week_of_year"),
        # Index("idx_ajio_bestsellers_week_pincode", "pincode"),
        # Index("idx_ajio_bestsellers_week_productid", "productid"),
    )

AjioBestSellersWeek.__table__.create(bind=clickhouse_sync_engine, checkfirst=True)


class AjioProductAttributes(Base):
    __tablename__ = "ajio_product_attributes"
    productid = Column(String, primary_key=True)
    similargrouplevel = Column(String, primary_key=True)
    colorfamily = Column(String)
    fabrictype = Column(String)
    materialtype = Column(String)
    pattern = Column(String)
    sleevelength = Column(String)
    brandname = Column(String)
    occasion = Column(String)
    bodytype = Column(String)
    fit = Column(String)
    distress = Column(String)
    traditionalweave = Column(String)
    neckline = Column(String)
    hemline = Column(String)
    styletype = Column(String)
    title = Column(String)
    imgcode = Column(String)
    mrp = Column(Float)

    __table_args__ = (
        PrimaryKeyConstraint("productid", "similargrouplevel"),
        engines.MergeTree("productid", ("productid", "similargrouplevel")),
        # Index("idx_ajio_product_attributes_similargrouplevel", "similargrouplevel"),
        # Index("idx_ajio_product_attributes_productid", "productid"),
        # Index("idx_ajio_product_attributes_brandname", "brandname"),
        # Index("idx_ajio_product_attributes_fabrictype", "fabrictype"),
    )

AjioProductAttributes.__table__.create(bind=clickhouse_sync_engine, checkfirst=True)


class AjioBrickDetails(Base):
    __tablename__ = "ajio_brick_details"
    similargrouplevel = Column(String, primary_key=True)
    l1name = Column(String)
    l2name = Column(String)
    brickname = Column(String)

    __table_args__ = (
        PrimaryKeyConstraint("similargrouplevel"),
        engines.MergeTree("similargrouplevel", ("similargrouplevel")),
        # Index("idx_ajio_brick_details_similargrouplevel", "similargrouplevel"),
    )

AjioBrickDetails.__table__.create(bind=clickhouse_sync_engine, checkfirst=True)


class AjioDemographicDetails(Base):
    __tablename__ = "ajio_demographic_details"
    pincode = Column(String, primary_key=True)
    state = Column(String)
    city = Column(String)
    districtsname = Column(String)
    zone = Column(String)

    __table_args__ = (
        PrimaryKeyConstraint("pincode"),
        engines.MergeTree("pincode", ("pincode")),
        # Index("idx_ajio_demographic_details_pincode", "pincode"),
        # Index("idx_ajio_demographic_details_zone", "zone"),
    )

AjioDemographicDetails.__table__.create(bind=clickhouse_sync_engine, checkfirst=True)


class AjioSearchQueriesTopInteractedProducts(Base):
    __tablename__ = "ajio_search_queries_top_interacted_products"
    year = Column(Integer, primary_key=True)
    month_of_year = Column(Integer, primary_key=True)
    week_of_year = Column(Integer, primary_key=True)
    search_type = Column(String, primary_key=True)
    normalized_search_term = Column(String, primary_key=True)
    productid = Column(String, primary_key=True)
    sum_session_counts = Column(BigInteger)
    impressions_product = Column(BigInteger)
    clicks_product = Column(BigInteger)
    total_clicks_query = Column(BigInteger)

    __table_args__ = (
        PrimaryKeyConstraint(
            "year",
            "month_of_year",
            "week_of_year",
            "search_type",
            "normalized_search_term",
            "productid",
        ),
        engines.MergeTree(
            "year", ("year", "month_of_year", "week_of_year", "search_type")
        ),
        # Index("idx_ajio_search_queries_top_interacted_products_month", "month_of_year"),
        # Index("idx_ajio_search_queries_top_interacted_products_week", "week_of_year"),
        # Index(
        #     "idx_ajio_search_queries_top_normalized_search_term",
        #     "normalized_search_term",
        # ),
    )

AjioSearchQueriesTopInteractedProducts.__table__.create(bind=clickhouse_sync_engine, checkfirst=True)


class TrendsBestSellers(Base):
    __tablename__ = "trends_bestsellers_storeids_zonelevel_top100"
    year = Column(Integer, primary_key=True)
    quarter_of_year = Column(Integer)
    month_of_year = Column(Integer, primary_key=True)
    week_of_year = Column(Integer, primary_key=True)
    itemid = Column(String, primary_key=True)
    store_id = Column(String, primary_key=True)
    sold_quantity_in_a_week = Column(BigInteger)
    availablequantity_in_a_week = Column(BigInteger)

    __table_args__ = (
        PrimaryKeyConstraint(
            "year", "month_of_year", "week_of_year", "itemid", "store_id"
        ),
        engines.MergeTree("year", ("year", "month_of_year")),
        # Index("idx_trends_bestsellers_month", "month_of_year"),
        # Index("idx_trends_bestsellers_week", "week_of_year"),
        # Index("idx_trends_bestsellers_itemid", "itemid"),
        # Index("idx_trends_bestsellers_store_id", "store_id"),
    )

TrendsBestSellers.__table__.create(bind=clickhouse_sync_engine, checkfirst=True)




class TrendsBestSellersMonth(Base):
    __tablename__ = "trends_bestsellers_month_level"
    year = Column(Integer, primary_key=True)
    quarter_of_year = Column(Integer)
    month_of_year = Column(Integer, primary_key=True)
    store_id = Column(String, primary_key=True)
    itemid = Column(String, primary_key=True)
    sold_quantity_in_a_month = Column(BigInteger)
    healthy_live_days_in_a_month = Column(Integer)

    __table_args__ = (
        PrimaryKeyConstraint("year", "month_of_year", "store_id", "itemid"),
        engines.MergeTree("year", ("year", "month_of_year")),
        # Index("idx_trends_bestsellers_month_month", "month_of_year"),
        # Index("idx_trends_bestsellers_month_store_id", "store_id"),
        # Index("idx_trends_bestsellers_month_itemid", "itemid"),
    )

TrendsBestSellersMonth.__table__.create(bind=clickhouse_sync_engine, checkfirst=True)





class TrendsBestSellersWeek(Base):
    __tablename__ = "trends_bestsellers_recent_week_level"
    year = Column(Integer, primary_key=True)
    week_of_year = Column(Integer, primary_key=True)
    store_id = Column(String, primary_key=True)
    itemid = Column(String, primary_key=True)
    start_date = Column(String)
    end_date = Column(String)
    sold_quantity_in_a_week = Column(BigInteger)
    healthy_live_days_in_a_week = Column(Integer)

    __table_args__ = (
        PrimaryKeyConstraint("year", "week_of_year", "store_id", "itemid"),
        engines.MergeTree("year", ("year", "week_of_year")),
        # Index("idx_trends_bestsellers_week_week", "week_of_year"),
        # Index("idx_trends_bestsellers_week_store_id", "store_id"),
        # Index("idx_trends_bestsellers_week_itemid", "itemid"),
    )


class TrendsProductAttributes(Base):
    __tablename__ = "trends_product_attributes"
    itemid = Column(String, primary_key=True)
    similargrouplevel = Column(String)
    primarycolor = Column(String)
    fabrictype = Column(String)
    materialtype = Column(String)
    pattern = Column(String)
    sleeve = Column(String)
    fit = Column(String)
    neckline = Column(String)
    styletype = Column(String)
    fashion_grade_description = Column(String)
    mrp = Column(Float)
    brandname = Column(String)
    imgcode = Column(String)
    extension = Column(String)
    mrp = Column(Float)

    __table_args__ = (
        PrimaryKeyConstraint("itemid", "similargrouplevel"),
        Index("idx_trends_product_attributes_similargrouplevel", "similargrouplevel"),
        Index("idx_trends_product_attributes_itemid", "itemid"),
        Index("idx_trends_product_attributes_brandname", "brandname"),
        Index("idx_trends_product_attributes_fabrictype", "fabrictype"),
    )


class TrendsStoreDetails(Base):
    __tablename__ = "trendsstoredetails"
    store_id = Column(String, primary_key=True)
    pin_code = Column(String)
    format_cd = Column(String)
    format_desc = Column(String)
    city = Column(String)
    region = Column(String)
    location = Column(String)
    store_short_name = Column(String)
    store_area = Column(String)
    state = Column(String)
    zone_desc = Column(String)
    store_class_desc = Column(String)
    districtsname = Column(String)

    __table_args__ = (
        PrimaryKeyConstraint("store_id"),
        Index("idx_trendsstoredetails_store_id", "store_id"),
        Index("idx_trendsstoredetails_zone_desc", "zone_desc"),
        Index("idx_trendsstoredetails_state", "state"),
    )


class TrendsBrickDetails(Base):
    __tablename__ = "trendsbrickdetails"
    similargrouplevel = Column(String, primary_key=True)
    mh_family_desc = Column(String)
    mh_class_desc = Column(String)
    brickname = Column(String)

    __table_args__ = (
        PrimaryKeyConstraint("similargrouplevel"),
        Index("idx_trendsbrickdetails_similargrouplevel", "similargrouplevel"),
    )


class SearchInteractions(Base):
    __tablename__ = "search_interactions"
    id = Column(Integer, primary_key=True, auto_increment=True)
    category = Column(String)
    related_top_searches = Column(String)
    number_of_top_searches = Column(Integer)
    related_rising_searches = Column(String)
    number_of_rising_searches = Column(Integer)

    __table_args__ = (Index("idx_search_interactions_category", "category"),)


class Calenderyearmonthweekinfo(Base):
    __tablename__ = "calendaryearmonthweekinfo"
    year = Column(Integer, primary_key=True)
    month_of_year = Column(Integer, primary_key=True)
    quarter_of_year = Column(Integer)
    week_of_year = Column(Integer, primary_key=True)
    list_of_dates_in_the_week = Column(ARRAY(String))  # Use ARRAY type
    num_days_in_week = Column(Integer, nullable=False)

    __table_args__ = (
        PrimaryKeyConstraint("year", "month_of_year", "week_of_year"),
        Index("idx_calendaryearmonthweekinfo_month", "month_of_year"),
        Index("idx_calendaryearmonthweekinfo_week", "week_of_year"),
    )







# async def create_tables():
#     async with clickhouse_engine.begin() as conn:
#         await conn.run_sync(Base.metadata.create_all)
