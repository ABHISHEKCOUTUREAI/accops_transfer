from db import flush_redis_key, psql_session, set_redis_state
from fastapi import APIRouter, Depends
from models import SearchInteractions
from static import data_upload_table_mapping
from utils import load_corpus, load_google_search_interactions

DBRouter = APIRouter(
    tags=["DB Utils"],
    responses={404: {"description": "Not found"}},
)


async def process_table(table, postgres_db, gcs_bucket_name, gcs_file_name):
    return await load_corpus(
        table[0],
        table[1],
        postgres_db,
        gcs_bucket_name=gcs_bucket_name,
        gcs_file_name=gcs_file_name,
    )


async def process_all_tables(postgres_db, gcs_bucket_name, gcs_file_name):
    results = []
    for table in data_upload_table_mapping["all"]:
        if table[0] == SearchInteractions:
            results.append(await load_google_search_interactions(table[0], postgres_db))
        else:
            results.append(
                await process_table(table, postgres_db, gcs_bucket_name, gcs_file_name)
            )

    for result in results:
        if result.status_code != 200:
            return result
    return {"message": "All tables loaded successfully"}


@DBRouter.get("/update-db")
async def update_db(
    table_name: str,
    gcs_bucket_name: str = None,
    gcs_file_name: str = None,
    postgres_db=Depends(psql_session),
):
    if table_name in data_upload_table_mapping:
        if table_name == "search_interactions":
            return await load_google_search_interactions(
                data_upload_table_mapping[table_name][0], postgres_db
            )
        elif table_name == "all":
            return await process_all_tables(postgres_db, gcs_bucket_name, gcs_file_name)
        else:
            return await process_table(
                data_upload_table_mapping[table_name],
                postgres_db,
                gcs_bucket_name,
                gcs_file_name,
            )
    else:
        return {"message": "Invalid table name"}


@DBRouter.get("/flush-redis")
async def flush_redis(key_prefix: str):
    if key_prefix == "all":
        await set_redis_state(flush_db=True)
        return {"message": "Redis flushed successfully"}
    else:
        await flush_redis_key(key_prefix)
        return {
            "message": f"Redis keys starting with {key_prefix} flushed successfully"
        }
