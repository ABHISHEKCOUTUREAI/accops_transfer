import json

from db import check_in_redis, psql_execute_single, redis_db
from fastapi import APIRouter
from models import (
    AjioBestSellersMonth,
    AjioBestSellersWeek,
    AjioDemographicDetails,
)
from sqlalchemy import func, select
from static import REDIS_CONNECT_ERROR, REDIS_WRITE_ERROR, indian_states
from utils import (
    get_ajio_bestseller_month_level,
    get_ajio_bestseller_week_level,
    get_ajio_filters_service,
    get_attributes_bestsellers_ajio,
)

AjioRouter = APIRouter(
    tags=["Ajio"],
    responses={404: {"description": "Not found"}},
)


@AjioRouter.post("/ajio-filters")
async def get_ajio_filters(
    request_data: dict,
):
    return await get_ajio_filters_service(request_data, caching_flag=False)


@AjioRouter.post("/bestsellers-products-ajio")
async def bestseller_ajio(request_data: dict):
    cache_key = f"sale_trends_ajio_{json.dumps(request_data)}"
    cached_data = await check_in_redis(cache_key)
    if cached_data:
        return json.loads(cached_data)

    if request_data.get("nested_data", {}).get("duration", {}).get("week"):
        result = await get_ajio_bestseller_week_level(request_data)
    else:
        result = await get_ajio_bestseller_month_level(request_data)

    try:
        await redis_db.set(cache_key, json.dumps(result, default=str))
    except Exception as e:
        print(REDIS_WRITE_ERROR, e)

    return result


@AjioRouter.post("/statewise-sales-ajio")
async def get_statewise_sales(
    request_data: dict,
):
    cache_key = f"statewise_sales_{json.dumps(request_data)}"
    try:
        cached_data = await redis_db.get(cache_key)
    except Exception as e:
        print(REDIS_CONNECT_ERROR, e)
        cached_data = None
    if cached_data:
        return json.loads(cached_data)

    # Determine which schema to use based on the presence of 'week' in the request data
    if request_data.get("nested_data", {}).get("duration", {}).get("week"):
        best_sellers_schema = AjioBestSellersWeek
        quantity_column = AjioBestSellersWeek.sold_quantity_in_a_week
    else:
        best_sellers_schema = AjioBestSellersMonth
        quantity_column = AjioBestSellersMonth.sold_quantity_in_a_month

    # Now, use the selected schema in your query
    sold_in_week_query = (
        select(
            AjioDemographicDetails.state,
            func.sum(quantity_column).label("quantity"),
        )
        .join(
            AjioDemographicDetails,
            AjioDemographicDetails.pincode == best_sellers_schema.pincode,
        )
        .group_by(
            AjioDemographicDetails.state,
        )
    )

    maps_rows_state = await psql_execute_single(sold_in_week_query)

    map_data = [
        {
            "state": row[0],
            "statecode": indian_states.get(row[0].lower(), {}).get(
                "statecode", "Not Found"
            ),
            "quantity_sold": row[1],
        }
        for row in maps_rows_state
    ]

    try:
        await redis_db.set(cache_key, json.dumps(map_data, default=str))
    except Exception as e:
        print(REDIS_WRITE_ERROR, e)

    return map_data


@AjioRouter.post("/fabric-bestsellers-ajio")
async def get_fabric_bestsellers_ajio(
    request_data: dict,
):
    cache_key = f"fabric_bestsellers_ajio_{json.dumps(request_data)}"
    try:
        cached_data = await redis_db.get(cache_key)
    except Exception as e:
        print(REDIS_CONNECT_ERROR, e)
        cached_data = None

    if cached_data:
        return json.loads(cached_data)

    result = await get_attributes_bestsellers_ajio(
        request_data,
        attribute="fabrictype",
    )

    try:
        await redis_db.set(cache_key, json.dumps(result, default=str))
    except Exception as e:
        print(REDIS_WRITE_ERROR, e)

    return result


@AjioRouter.post("/brandnames-bestsellers-ajio")
async def brandnames_bestsellers_ajio(
    request_data: dict,
):
    cache_key = f"brandnames_bestsellers_ajio_{json.dumps(request_data)}"
    try:
        cached_data = await redis_db.get(cache_key)
    except Exception as e:
        print(REDIS_CONNECT_ERROR, e)
        cached_data = None

    if cached_data:
        return json.loads(cached_data)

    result = await get_attributes_bestsellers_ajio(
        request_data,
        attribute="brandname",
    )

    try:
        await redis_db.set(cache_key, json.dumps(result, default=str))
    except Exception as e:
        print(REDIS_WRITE_ERROR, e)

    return result


@AjioRouter.post("/styletype-bestsellers-ajio")
async def styletype_bestsellers_ajio(
    request_data: dict,
):
    cache_key = f"styletype_bestsellers_ajio_{json.dumps(request_data)}"
    try:
        cached_data = await redis_db.get(cache_key)
    except Exception as e:
        print(REDIS_CONNECT_ERROR, e)
        cached_data = None

    if cached_data:
        return json.loads(cached_data)

    result = await get_attributes_bestsellers_ajio(
        request_data,
        attribute="styletype",
    )

    try:
        await redis_db.set(cache_key, json.dumps(result, default=str))
    except Exception as e:
        print(REDIS_WRITE_ERROR, e)

    return result


@AjioRouter.post("/neckline-bestsellers-ajio")
async def neckline_bestsellers_ajio(
    request_data: dict,
):
    cache_key = f"neckline_bestsellers_ajio_{json.dumps(request_data)}"
    try:
        cached_data = await redis_db.get(cache_key)
    except Exception as e:
        print(REDIS_CONNECT_ERROR, e)
        cached_data = None

    if cached_data:
        return json.loads(cached_data)

    result = await get_attributes_bestsellers_ajio(
        request_data,
        attribute="neckline",
    )

    try:
        await redis_db.set(cache_key, json.dumps(result, default=str))
    except Exception as e:
        print(REDIS_WRITE_ERROR, e)

    return result


@AjioRouter.post("/pattern-bestsellers-ajio")
async def pattern_bestsellers_ajio(
    request_data: dict,
):
    cache_key = f"pattern_bestsellers_ajio_{json.dumps(request_data)}"
    try:
        cached_data = await redis_db.get(cache_key)
    except Exception as e:
        print(REDIS_CONNECT_ERROR, e)
        cached_data = None

    if cached_data:
        return json.loads(cached_data)

    result = await get_attributes_bestsellers_ajio(
        request_data,
        attribute="pattern",
    )

    try:
        await redis_db.set(cache_key, json.dumps(result, default=str))
    except Exception as e:
        print(REDIS_WRITE_ERROR, e)
    return result


@AjioRouter.post("/color-bestsellers-ajio")
async def color_bestsellers_ajio(
    request_data: dict,
):
    cache_key = f"color_bestsellers_ajio_{json.dumps(request_data)}"
    try:
        cached_data = await redis_db.get(cache_key)
    except Exception as e:
        print(REDIS_CONNECT_ERROR, e)
        cached_data = None

    if cached_data:
        return json.loads(cached_data)

    result = await get_attributes_bestsellers_ajio(
        request_data,
        attribute="colorfamily",
    )

    try:
        await redis_db.set(cache_key, json.dumps(result, default=str))
    except Exception as e:
        print(REDIS_WRITE_ERROR, e)

    return result


@AjioRouter.post("/sleevelength-bestsellers-ajio")
async def sleevelength_bestsellers_ajio(
    request_data: dict,
):
    cache_key = f"sleevelength_bestsellers_ajio_{json.dumps(request_data)}"
    try:
        cached_data = await redis_db.get(cache_key)
    except Exception as e:
        print(REDIS_CONNECT_ERROR, e)
        cached_data = None

    if cached_data:
        return json.loads(cached_data)

    result = await get_attributes_bestsellers_ajio(
        request_data,
        attribute="sleevelength",
    )

    try:
        await redis_db.set(cache_key, json.dumps(result, default=str))
    except Exception as e:
        print(REDIS_WRITE_ERROR, e)

    return result
