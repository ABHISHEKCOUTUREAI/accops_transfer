import asyncio
import json

from db import psql_execute_single, redis_db, psql_execute_multiple
from sqlalchemy.dialects.postgresql import aggregate_order_by
from models import (
    AjioBestSellers,
    AjioBrickDetails,
    AjioDemographicDetails,
    AjioProductAttributes,
    AjioSearchQueriesTopInteractedProducts,
    AttributeQueryParams,
    Calenderyearmonthweekinfo,
    ProductQueryParams,
    SearchParams,
    SearchTrends,
    TrendsBestSellers,
    TrendsStoreDetails,
)
from datetime import datetime
from sqlalchemy import Numeric, and_, case, cast, func, or_, select
from static import month_mapping

from .common_utils import (
    build_filter_condition,
    select_filter_subquery,
    sort_and_paginate,
)

api_contract_search_attributes = [
    "brandname",
    "colorfamily",
    "fabrictype",
    "materialtype",
    "pattern",
    "sleevelength",
    "styletype",
    "occasion",
    "bodytype",
    "fit",
    "distress",
    "traditionalweave",
    "neckline",
    "hemline",
]


fields_info = [
    ("quarter", "Quarter", 1),
    ("month", "Month", 0, month_mapping),
    ("zone", "Zone", 2),
    ("state", "State", 3),
    ("city", "City", 4),
    ("district", "District", 5),
    ("gender", "Gender", 6),
    ("category", "Category", 7),
    ("brick_name", "Brick Name", 8),
    ("styletype", "Style Type", 9),
    ("neckline", "Neckline", 10),
    ("pattern", "Pattern", 11),
    ("fabric_type", "Fabric Type", 12),
    ("sleeve", "Sleeve", 13),
    ("fit", "Fit", 14),
    ("color", "Color", 15),
    ("brand", "Brand", 16),
    ("occasion", "Occasion", 17),
    ("bodytype", "Body Type", 18),
    ("materialtype", "Material Type", 19),
    ("distress", "Distress", 20),
    ("traditionalweave", "Traditional Weave", 21),
    ("hemline", "Hemline", 22),
]


async def create_request_api_contract_ajio(query_params: ProductQueryParams):
    request_data = {
        "nested_data": {
            "duration": {"month": [], "quarter": []},
            "demographic": {
                "zone": [],
                "state": [],
                "city": [],
                "district": [],
                "pincode": [],
            },
            "attributes": {
                "styletype": [],
                "neckline": [],
                "pattern": [],
                "fabric_type": [],
                "sleeve": [],
                "fit": [],
                "color": [],
                "brand": [],
                "occasion": [],
                "bodytype": [],
                "materialtype": [],
                "distress": [],
                "traditionalweave": [],
                "hemline": [],
            },
            "brick_filters": {"l1_name": [], "l2_name": [], "brick_name": []},
        },
        "page_no": query_params.page,
        "page_count": query_params.page_size,
        "sort_param": query_params.sort_attribute,
        "sort_type": query_params.sort_order,
    }
    # Append demography filters
    if query_params.zone:
        request_data["nested_data"]["demographic"]["zone"].append(query_params.zone)
    if query_params.state:
        request_data["nested_data"]["demographic"]["state"].append(query_params.state)
    if query_params.city:
        request_data["nested_data"]["demographic"]["city"].append(query_params.city)
    if query_params.pincode:
        request_data["nested_data"]["demographic"]["pincode"].append(
            query_params.pincode
        )
    if query_params.gender:
        request_data["nested_data"]["brick_filters"]["l1_name"].append(
            query_params.gender
        )
    if query_params.category:
        request_data["nested_data"]["brick_filters"]["l2_name"].append(
            query_params.category
        )

    # Append attribute key and value
    if query_params.attribute_key and query_params.attribute_value:
        if query_params.attribute_key in request_data["nested_data"]["attributes"]:
            request_data["nested_data"]["attributes"][
                query_params.attribute_key
            ].append(query_params.attribute_value)
        else:
            request_data["nested_data"]["attributes"][query_params.attribute_key] = [
                query_params.attribute_value
            ]
    return request_data


async def create_request_api_contract_filters(query_params: SearchParams):
    request_data = {
        "nested_data": {
            "duration": {"month": [], "quarter": []},
            "demography": {"zone": [], "state": [], "city": [], "district": []},
            "attributes": {
                "styletype": [],
                "neckline": [],
                "pattern": [],
                "fabric_type": [],
                "sleeve": [],
                "fit": [],
                "color": [],
                "brand": [],
                "occasion": [],
                "bodytype": [],
                "materialtype": [],
                "distress": [],
                "traditionalweave": [],
                "hemline": [],
            },
            "brick_filters": {"l1_name": [], "l2_name": [], "brick_name": []},
        }
    }
    # Append demography filters
    if query_params.zone:
        request_data["nested_data"]["demography"]["zone"].append(query_params.zone)
    if query_params.state:
        request_data["nested_data"]["demography"]["state"].append(query_params.state)
    if query_params.city:
        request_data["nested_data"]["demography"]["city"].append(query_params.city)

    # Append brand name
    if query_params.brandname:
        request_data["nested_data"]["attributes"]["brand"].append(
            query_params.brandname
        )
    return request_data


async def create_request_api_contract_trends(query_params: ProductQueryParams):
    request_data = {
        "nested_data": {
            "duration": {"month": [], "quarter": []},
            "demography": {
                "zone": [],
                "state": [],
                "city": [],
                "district": [],
            },
            "attributes": {
                "styletype": [],
                "neckline": [],
                "pattern": [],
                "fabric_type": [],
                "sleeve": [],
                "fit": [],
                "color": [],
                "brand": [],
            },
            "store_filters": {"pincode": [], "store_id": []},
            "category": {
                "category_family": [],
                "category_class": [],
                "category": [],
            },
        },
        "page_no": query_params.page,
        "page_count": query_params.page_size,
        "sort_param": query_params.sort_attribute,
        "sort_type": query_params.sort_order,
    }
    # Append demography filters
    if query_params.zone:
        request_data["nested_data"]["demography"]["zone"].append(query_params.zone)
    if query_params.state:
        request_data["nested_data"]["demography"]["state"].append(query_params.state)
    if query_params.city:
        request_data["nested_data"]["demography"]["city"].append(query_params.city)

    # Append attribute key and value
    if query_params.attribute_key and query_params.attribute_value:
        if query_params.attribute_key in request_data["nested_data"]["attributes"]:
            request_data["nested_data"]["attributes"][
                query_params.attribute_key
            ].append(query_params.attribute_value)
        else:
            request_data["nested_data"]["attributes"][query_params.attribute_key] = [
                query_params.attribute_value
            ]

    return request_data


async def create_most_searched_attributes_query(
    query_params, attribute, start_week, latest_week
):
    # Combine conditions efficiently
    brick_conditions = []
    if query_params.category is not None:
        brick_conditions.append(AjioBrickDetails.l2name == query_params.category)
    if query_params.brickname is not None:
        brick_conditions.append(AjioBrickDetails.brickname == query_params.brickname)

    # Build the main query with joins and conditions
    search_query = (
        select(
            getattr(AjioProductAttributes, attribute),
            func.sum(AjioSearchQueriesTopInteractedProducts.sum_session_counts).label(
                "total_searches"
            ),
        )
        .join(
            AjioProductAttributes,
            AjioSearchQueriesTopInteractedProducts.productid
            == AjioProductAttributes.productid,
        )
        .join(
            AjioBrickDetails,
            AjioProductAttributes.similargrouplevel
            == AjioBrickDetails.similargrouplevel,
        )
        .where(
            and_(
                *brick_conditions,
                AjioSearchQueriesTopInteractedProducts.week_of_year.between(
                    start_week, latest_week + 1
                ),
            )
        )
        .group_by(
            getattr(AjioProductAttributes, attribute),
        )
        .order_by(
            func.sum(AjioSearchQueriesTopInteractedProducts.sum_session_counts).desc()
        )
        .limit(query_params.page_size)
        .offset(query_params.page_size * (query_params.page - 1))
    )

    return search_query


async def calculate_time_delta():
    cache_key = "min_max_week"
    cached_data = await redis_db.get(cache_key)
    if not cached_data:
        week_query = select(
            func.max(AjioSearchQueriesTopInteractedProducts.week_of_year)
        )
        week_result = await psql_execute_single(week_query)
        max_week = week_result[0][0]

        # Query to select the minimum week from the database
        min_week_query = select(
            func.min(AjioSearchQueriesTopInteractedProducts.week_of_year)
        )
        min_week_result = await psql_execute_single(min_week_query)
        min_week = min_week_result[0][0]

        await redis_db.set(cache_key, json.dumps([min_week, max_week]))

    print("time-delta loaded")


async def create_most_searched_filters(query_params: SearchParams):
    # Combine conditions efficiently
    brick_conditions = []
    if query_params.category is not None:
        brick_conditions.append(AjioBrickDetails.l2name == query_params.category)
    if query_params.brickname is not None:
        brick_conditions.append(AjioBrickDetails.brickname == query_params.brickname)

    demographic_conditions = []
    if query_params.city is not None:
        demographic_conditions.append(AjioDemographicDetails.city == query_params.city)
    if query_params.state is not None:
        demographic_conditions.append(
            AjioDemographicDetails.state == query_params.state
        )

    return brick_conditions, demographic_conditions


async def create_bestseller_attribute_query(
    query_params: AttributeQueryParams, attribute, week
):
    query = (
        select(
            getattr(AjioProductAttributes, attribute),
            func.sum(
                case(
                    (
                        AjioBestSellers.week_of_year == week,
                        AjioBestSellers.sold_quantity_in_a_week,
                    ),
                    else_=0,
                )
            ).label("current_week_sales"),
            func.sum(
                case(
                    (
                        AjioBestSellers.week_of_year == week - 1,
                        AjioBestSellers.sold_quantity_in_a_week,
                    ),
                    else_=0,
                )
            ).label("previous_week_sales"),
        )
        .join(
            AjioBrickDetails,
            AjioBrickDetails.similargrouplevel
            == AjioProductAttributes.similargrouplevel,
        )
        .join(
            AjioBestSellers,
            AjioBestSellers.productid == AjioProductAttributes.productid,
        )
        .where(
            AjioBrickDetails.l2name == query_params.category,
            getattr(AjioProductAttributes, attribute) != "nan",
            or_(
                AjioBestSellers.week_of_year == week,
                AjioBestSellers.week_of_year == week - 1,
            ),
        )
        .group_by(getattr(AjioProductAttributes, attribute))
        .limit(query_params.page_size)
        .offset((query_params.page - 1) * query_params.page_size)
    )

    return query


async def api_contract_ajio_bestseller_query(
    request_data_ajio, query_params: ProductQueryParams
):
    (
        bestseller_filter,
        demographic_filter,
        attribute_filter,
        brick_filter,
        calender_filter,
    ) = await asyncio.gather(
        build_filter_condition(
            request_filters=request_data_ajio, filter_flag="bestsellers", type="ajio"
        ),
        build_filter_condition(
            request_filters=request_data_ajio, filter_flag="demographic", type="ajio"
        ),
        build_filter_condition(
            request_filters=request_data_ajio, filter_flag="attributes", type="ajio"
        ),
        build_filter_condition(
            request_filters=request_data_ajio, filter_flag="brick", type="ajio"
        ),
        build_filter_condition(
            request_filters=request_data_ajio,
            filter_flag="calender",
            type="calender",
        ),
    )

    bestseller_query = (
        select(
            AjioBestSellers.productid,
            AjioBestSellers.week_of_year,
            AjioBestSellers.year,
            AjioBestSellers.mrp,
            AjioBestSellers.sold_quantity_in_a_week,
            AjioBestSellers.pincode,
        )
        .where(and_(*bestseller_filter))
        .cte()
    )

    demographic_query = (
        select(
            AjioDemographicDetails.pincode,
        )
        .where(and_(*demographic_filter))
        .cte()
    )

    calender_query = (
        select(
            Calenderyearmonthweekinfo.year,
            Calenderyearmonthweekinfo.week_of_year,
            func.sum(Calenderyearmonthweekinfo.num_days_in_week).label(
                "total_days_count_across_week"
            ),
        )
        .where(and_(*calender_filter))
        .group_by(
            Calenderyearmonthweekinfo.year,
            Calenderyearmonthweekinfo.week_of_year,
        )
        .cte()
    )

    ros_query = (
        select(
            bestseller_query.c.productid,
            bestseller_query.c.week_of_year,
            bestseller_query.c.year,
            func.avg(bestseller_query.c.mrp).label("mrp"),
            func.sum(bestseller_query.c.sold_quantity_in_a_week).label(
                "sold_quantity_across_each_week"
            ),
        )
        .join(
            demographic_query, demographic_query.c.pincode == bestseller_query.c.pincode
        )
        .group_by(
            bestseller_query.c.productid,
            bestseller_query.c.week_of_year,
            bestseller_query.c.year,
        )
        .cte()
    )

    # join ros and calender query
    ros_query = (
        select(
            ros_query.c.productid,
            ros_query.c.year,
            ros_query.c.mrp,
            ros_query.c.sold_quantity_across_each_week,
            calender_query.c.total_days_count_across_week,
        )
        .join(
            calender_query,
            and_(
                ros_query.c.week_of_year == calender_query.c.week_of_year,
                ros_query.c.year == calender_query.c.year,
            ),
        )
        .cte()
    )

    ros_query = (
        select(
            ros_query.c.productid,
            ros_query.c.year,
            func.sum(ros_query.c.sold_quantity_across_each_week).label(
                "total_qty_sold"
            ),
            func.round(cast(func.avg(ros_query.c.mrp), Numeric), 2).label("mrp"),
            func.round(
                cast(
                    (
                        (
                            func.sum(ros_query.c.sold_quantity_across_each_week)
                            / func.sum(ros_query.c.total_days_count_across_week)
                        )
                        * 7
                    ),
                    Numeric,
                ),
                2,
            ).label("weekly_rate_of_sale"),
        )
        .group_by(ros_query.c.productid, ros_query.c.year)
        .cte()
    )

    mrp_condition = True
    if query_params.min_mrp is not None and query_params.max_mrp is not None:
        mrp_condition = and_(
            ros_query.c.mrp >= query_params.min_mrp,
            ros_query.c.mrp <= query_params.max_mrp,
        )

    ros_query = (
        select(
            ros_query.c.productid,
            ros_query.c.total_qty_sold,
            ros_query.c.mrp,
            ros_query.c.weekly_rate_of_sale,
        )
        .where(mrp_condition)
        .cte()
    )

    product_query = (
        select(
            AjioProductAttributes.productid,
            AjioProductAttributes.similargrouplevel,
            AjioProductAttributes.title,
            AjioProductAttributes.brandname,
            AjioProductAttributes.imgcode,
        )
        .where(and_(*attribute_filter))
        .cte()
    )

    brick_query = (
        select(
            AjioBrickDetails.similargrouplevel,
        )
        .where(and_(*brick_filter))
        .cte()
    )

    ajio_query = (
        select(
            product_query.c.productid,
            product_query.c.title,
            product_query.c.brandname,
            product_query.c.imgcode,
            ros_query.c.total_qty_sold,
            ros_query.c.mrp,
            ros_query.c.weekly_rate_of_sale,
        )
        .join(ros_query, ros_query.c.productid == product_query.c.productid)
        .join(
            brick_query,
            brick_query.c.similargrouplevel == product_query.c.similargrouplevel,
        )
    )

    ajio_query = await sort_and_paginate(
        ajio_query, request_data_ajio, default_sort_param="weekly_rate_of_sale"
    )

    return ajio_query


async def api_contract_trends_bestseller_query(request_data_trends):
    (
        bestseller_filter_trends,
        store_filter_trends,
        calender_filter_trends,
    ) = await asyncio.gather(
        build_filter_condition(
            type="trends",
            request_filters=request_data_trends,
            filter_flag="bestsellers",
        ),
        build_filter_condition(
            type="trends",
            request_filters=request_data_trends,
            filter_flag="store_filters",
        ),
        build_filter_condition(
            type="calender",
            request_filters=request_data_trends,
            filter_flag="calender",
        ),
    )

    bestseller_query = (
        select(
            TrendsBestSellers.itemid,
            TrendsBestSellers.week_of_year,
            TrendsBestSellers.year,
            TrendsBestSellers.store_id,
            TrendsBestSellers.sold_quantity_in_a_week,
        )
        .where(and_(*bestseller_filter_trends))
        .cte()
    )

    store_query = (
        select(
            TrendsStoreDetails.store_id,
        )
        .where(and_(*store_filter_trends))
        .cte()
    )

    calender_query = (
        select(
            Calenderyearmonthweekinfo.week_of_year,
            Calenderyearmonthweekinfo.year,
            func.sum(Calenderyearmonthweekinfo.num_days_in_week).label(
                "total_days_count_across_week"
            ),
        )
        .where(and_(*calender_filter_trends))
        .group_by(
            Calenderyearmonthweekinfo.week_of_year, Calenderyearmonthweekinfo.year
        )
        .cte()
    )

    ros_query = (
        select(
            bestseller_query.c.itemid,
            bestseller_query.c.week_of_year,
            bestseller_query.c.year,
            func.sum(bestseller_query.c.sold_quantity_in_a_week).label(
                "sold_quantity_across_each_week"
            ),
        )
        .join(store_query, store_query.c.store_id == bestseller_query.c.store_id)
        .group_by(
            bestseller_query.c.itemid,
            bestseller_query.c.week_of_year,
            bestseller_query.c.year,
        )
        .cte()
    )

    # join ros and calender query
    ros_query = (
        select(
            ros_query.c.itemid,
            ros_query.c.year,
            ros_query.c.sold_quantity_across_each_week,
            calender_query.c.total_days_count_across_week,
        )
        .join(
            calender_query,
            and_(
                calender_query.c.week_of_year == ros_query.c.week_of_year,
                calender_query.c.year == ros_query.c.year,
            ),
        )
        .cte()
    )

    trends_query = select(
        ros_query.c.itemid,
        ros_query.c.year,
        func.round(
            cast(
                (
                    (
                        func.sum(ros_query.c.sold_quantity_across_each_week)
                        / func.sum(ros_query.c.total_days_count_across_week)
                    )
                    * 7
                ),
                Numeric,
            ),
            2,
        ).label("weekly_rate_of_sale"),
    ).group_by(ros_query.c.itemid, ros_query.c.year)

    return trends_query


async def get_v2_filters_query(request_data):
    (
        duration_filter,
        demography_filter,
        brick_filter,
        product_filter,
    ) = await asyncio.gather(
        build_filter_condition(request_filters=request_data, filter_flag="bestsellers"),
        build_filter_condition(request_filters=request_data, filter_flag="demographic"),
        build_filter_condition(request_filters=request_data, filter_flag="brick"),
        build_filter_condition(request_filters=request_data, filter_flag="products"),
    )
    print("Duration fileter", duration_filter, flush=True)
    duration_columns = [
        "month_of_year",
        "quarter_of_year",
        "productid",
        "pincode",
    ]
    demography_columns = ["zone", "state", "city", "districtsname", "pincode"]
    brick_columns = ["l1name", "l2name", "brickname", "similargrouplevel"]
    product_columns = [
        "productid",
        "styletype",
        "neckline",
        "pattern",
        "fabrictype",
        "sleevelength",
        "fit",
        "colorfamily",
        "brandname",
        "occasion",
        "bodytype",
        "materialtype",
        "distress",
        "traditionalweave",
        "hemline",
        "similargrouplevel",
    ]

    (
        duration_query,
        demographic_query,
        brick_query,
        product_query,
    ) = await asyncio.gather(
        select_filter_subquery(
            AjioBestSellers, list(duration_filter), duration_columns
        ),
        select_filter_subquery(
            AjioDemographicDetails, list(demography_filter), demography_columns
        ),
        select_filter_subquery(AjioBrickDetails, list(brick_filter), brick_columns),
        select_filter_subquery(
            AjioProductAttributes, list(product_filter), product_columns
        ),
    )
    print("duration_query:", duration_query, flush=True)
    # join all 4 queries to get the final result
    query = (
        select(
            duration_query.c.month_of_year,
            duration_query.c.quarter_of_year,
            demographic_query.c.zone,
            demographic_query.c.state,
            demographic_query.c.city,
            demographic_query.c.districtsname,
            brick_query.c.l1name,
            brick_query.c.l2name,
            brick_query.c.brickname,
            product_query.c.styletype,
            product_query.c.neckline,
            product_query.c.pattern,
            product_query.c.fabrictype,
            product_query.c.sleevelength,
            product_query.c.fit,
            product_query.c.colorfamily,
            product_query.c.brandname,
            product_query.c.occasion,
            product_query.c.bodytype,
            product_query.c.materialtype,
            product_query.c.distress,
            product_query.c.traditionalweave,
            product_query.c.hemline,
        )
        .join(
            demographic_query, demographic_query.c.pincode == duration_query.c.pincode
        )
        .join(product_query, product_query.c.productid == duration_query.c.productid)
        .join(
            brick_query,
            brick_query.c.similargrouplevel == product_query.c.similargrouplevel,
        )
    )

    return query


async def execute_products_query(query_params: ProductQueryParams) -> list:
    """
    combines and executes the queries to get the bestseller products
    """
    request_data_ajio = await create_request_api_contract_ajio(query_params)
    ajio_query = await api_contract_ajio_bestseller_query(
        request_data_ajio, query_params
    )

    request_data_trends = await create_request_api_contract_trends(query_params)
    trends_query = await api_contract_trends_bestseller_query(request_data_trends)

    # Combine both the queries
    ajio_query = ajio_query.cte()
    trends_query = trends_query.cte()

    sort_order = query_params.sort_order
    if sort_order == "asc":
        order_by_clause = ajio_query.c.weekly_rate_of_sale.asc()
    else:
        order_by_clause = ajio_query.c.weekly_rate_of_sale.desc()
    query = (
        select(
            ajio_query.c.productid,
            ajio_query.c.title,
            ajio_query.c.brandname,
            ajio_query.c.mrp,
            ajio_query.c.weekly_rate_of_sale.label("ajio_weekly_ros"),
            trends_query.c.weekly_rate_of_sale.label("trends_weekly_ros"),
            ajio_query.c.imgcode,
        )
        .join(
            trends_query,
            ajio_query.c.productid == trends_query.c.itemid,
            isouter=True,
        )
        .order_by(order_by_clause)
    )

    result = await psql_execute_single(query)

    result = [
        {
            "item_id": row[0],
            "title": row[1],
            "brand_name": row[2],
            "mrp": row[3],
            "ajio_weekly_ros": row[4],
            "trends_weekly_ros": row[5] if row[5] is not None else 0,
            "image_code": row[6],
        }
        for row in result
    ]
    return result


async def execute_category_query(query_params: ProductQueryParams, category_images) -> list:
    query = select(
        AjioBrickDetails.l2name.distinct(),
    ).where(AjioBrickDetails.l1name == query_params.gender)
    result = await psql_execute_single(query)

    # join the query l2name with the category_images to create final response
    result = [
        {
            "category": row[0],
            "id": category_images.get(row[0], {}).get("id", ""),
            "imgcode": category_images.get(row[0], {}).get("imgcode", ""),
        }
        for row in result
    ]
    return result


async def execute_attribute_query(query_params: AttributeQueryParams, attributes_images) -> list:
    week = query_params.week
    if week is None:
        week_query = select(func.max(AjioBestSellers.week_of_year))
        week_result = await psql_execute_single(week_query)
        week = week_result[0][0]
    # Build main query
    if (
        query_params.attribute == "all"
        or query_params.attribute not in api_contract_search_attributes
    ):
        query_list = [
            await create_bestseller_attribute_query(query_params, attribute, week)
            for attribute in api_contract_search_attributes
        ]

        # Execute the main query
        results = await psql_execute_multiple(query_list)
        processed_result = []
        for result in results:
            response = {
                "attribute": api_contract_search_attributes[results.index(result)],
                "values": [
                    {
                        "name": row[0],
                        "current_sales": round(row[1], 2),
                        "previous_sales": round(row[2], 2),
                        "precentage_change": round(
                            ((row[1] - row[2]) * 100) / row[2], 2
                        )
                        if row[2] != 0
                        else 0,
                        "id": attributes_images.get(
                            api_contract_search_attributes[results.index(result)], {}
                        )
                        .get(row[0])
                        .get("productid"),
                        "imgcode": attributes_images.get(
                            api_contract_search_attributes[results.index(result)], {}
                        )
                        .get(row[0])
                        .get("imgcode"),
                    }
                    for row in result
                ],
            }
            processed_result.append(response)

    else:
        query = await create_bestseller_attribute_query(
            query_params, query_params.attribute, week
        )

        result = await psql_execute_single(query)

        # Process the result
        processed_result = [
            {
                "attribute": query_params.attribute,
                "values": [
                    {
                        "name": row[0],
                        "current_sales": round(row[1], 2),
                        "previous_sales": round(row[2], 2),
                        "precentage_change": round(
                            ((row[1] - row[2]) * 100) / row[2], 2
                        )
                        if row[2] != 0
                        else 0,
                        "id": attributes_images.get(query_params.attribute)
                        .get(row[0])
                        .get("productid"),
                        "imgcode": attributes_images.get(query_params.attribute)
                        .get(row[0])
                        .get("imgcode"),
                    }
                    for row in result
                ],
            }
        ]
    return processed_result


async def execute_most_searched_trends_query(query_params: SearchTrends, min_week, max_week) -> list:
    brick_conditions = []
    if query_params.category is not None:
        brick_conditions.append(AjioBrickDetails.l2name == query_params.category)
    if query_params.brickname is not None:
        brick_conditions.append(AjioBrickDetails.brickname == query_params.brickname)


    no_of_weeks = query_params.num_days // 7
    start_week = max_week - no_of_weeks + 1
    # Ensure the starting week is not earlier than the minimum week present
    if start_week < min_week:
        start_week = min_week

    page = query_params.page
    page_size = query_params.page_size

    search_query = (
        select(
            AjioSearchQueriesTopInteractedProducts.normalized_search_term,
            AjioSearchQueriesTopInteractedProducts.week_of_year,
            func.sum(AjioSearchQueriesTopInteractedProducts.sum_session_counts).label(
                "total_searches"
            ),
        )
        .join(
            AjioProductAttributes,
            AjioSearchQueriesTopInteractedProducts.productid
            == AjioProductAttributes.productid,
        )
        .join(
            AjioBrickDetails,
            AjioProductAttributes.similargrouplevel
            == AjioBrickDetails.similargrouplevel,
            isouter=True,
        )
        .group_by(
            AjioSearchQueriesTopInteractedProducts.normalized_search_term,
            AjioSearchQueriesTopInteractedProducts.week_of_year,
        )
        .where(
            *brick_conditions,
            AjioSearchQueriesTopInteractedProducts.week_of_year.between(
                start_week, max_week + 1
            ),
        )
    ).cte()

    # Aggregated query with json_agg
    aggregated_query = (
        select(
            search_query.c.normalized_search_term,
            func.json_agg(
                aggregate_order_by(
                    func.json_build_object(
                        "week_no",
                        search_query.c.week_of_year,
                        "total_searches",
                        search_query.c.total_searches,
                    ),
                    search_query.c.week_of_year,
                )
            ).label("searches_ordered"),
            func.sum(search_query.c.total_searches).label("total_searches"),
        )
        .group_by(search_query.c.normalized_search_term)
        .order_by(func.sum(search_query.c.total_searches).desc())
        .limit(page_size)
        .offset((page - 1) * page_size)
    )

    last_searched_timestamp_query = (
        select(
            AjioSearchQueriesTopInteractedProducts.normalized_search_term,
            func.max(AjioSearchQueriesTopInteractedProducts.week_of_year).label(
                "last_searched_timestamp"
            ),
        ).group_by(AjioSearchQueriesTopInteractedProducts.normalized_search_term)
    ).cte()

    final_query = (
        select(
            aggregated_query.c.normalized_search_term,
            aggregated_query.c.searches_ordered,
            aggregated_query.c.total_searches,
            last_searched_timestamp_query.c.last_searched_timestamp,
        )
        .join(
            last_searched_timestamp_query,
            aggregated_query.c.normalized_search_term
            == last_searched_timestamp_query.c.normalized_search_term,
        )
        .order_by(aggregated_query.c.total_searches.desc())
    )

    result = await psql_execute_single(final_query)
    current_week = datetime.now().isocalendar()[1]
    result = [
        {
            "name": row[0],
            "last_searched_timestamp": (current_week - row[3]) * 7,
            "search_distribution": {
                "divisions": max_week - start_week + 1,
                "data": [
                    {entry["week_no"]: entry["total_searches"] for entry in row[1]}.get(
                        week, 0
                    )
                    for week in range(start_week, max_week + 1)
                ],
            },
            "total_searches": row[2],
        }
        for row in result
    ]
    return result


async def execute_most_searched_attributes_query(query_params: SearchParams, min_week, max_week) -> dict:
    no_of_weeks = query_params.num_days // 7
    start_week = max_week - no_of_weeks + 1
    # Ensure the starting week is not earlier than the minimum week present
    if start_week < min_week:
        start_week = min_week

    # create a list of queries for each attribute
    if query_params.attribute == "all":
        query_list = [
            await create_most_searched_attributes_query(
                query_params, attribute, start_week, max_week
            )
            for attribute in api_contract_search_attributes
        ]

        results = await psql_execute_multiple(query_list)

        data = []
        for result in results:
            count = 0
            for row in result:
                count += row[1]
            response = {
                "attribute": api_contract_search_attributes[results.index(result)],
                "distribution": [
                    {"name": row[0], "percentage": round(((row[1] * 100) / count), 2)}
                    for row in result
                ],
            }
            data.append(response)

    else:
        query = await create_most_searched_attributes_query(
            query_params, query_params.attribute, start_week, max_week
        )

        results = await psql_execute_single(query)

        count = 0
        for row in results:
            count += row[1]
        data = {
            "attribute": query_params.attribute,
            "distribution": [
                {"name": row[0], "percentage": round(((row[1] * 100) / count), 2)}
                for row in results
            ],
        }

    return data


async def execute_filters_query(query_params: SearchParams) -> dict:
    request_data = await create_request_api_contract_filters(query_params)

    filter_query = await get_v2_filters_query(request_data)
    print(filter_query, flush=True)
    result = await psql_execute_single(filter_query)

    # Define a list of tuples with field information: (name, displayName, index)
    response = {}

    # Iterate over the fields_info to populate the response dictionary
    for field in fields_info:
        name, display_name, index = field[:3]
        # Use mapping if provided, otherwise use the value directly
        if len(field) == 4:
            mapping = field[3]
            values = {
                mapping[val[index]]: mapping[val[index]]
                for val in result
                if val[index] != "nan" and val[index] is not None
            }
        else:
            values = {
                val[index]: val[index]
                for val in result
                if val[index] != "nan" and val[index] is not None
            }
        response[name] = {"name": name, "displayName": display_name, "values": values}
    return response