from fastapi import APIRouter, Form, Depends, UploadFile, File
from ..models import AssortmentOutput
from sqlalchemy import and_, select, func, distinct, case, desc, asc
from .common import get_postgres_db
import json
from app.db import redis_db
import pandas as pd
from typing import Optional
from fastapi.responses import JSONResponse
from asyncio import gather


L2L3 = APIRouter(prefix="/couture/assortment", tags=["L2L3"])



@L2L3.post("/l2l3", operation_id="fetch-l2l3")  
async def fetch_l2l3(
    request_csv: Optional[UploadFile] = File(None),
    region_type: str = Form(None),
    region_name: str = Form(None),
    postgres_db = Depends(get_postgres_db),
):

    request_df = None
    if request_csv is not None:
        request_df = pd.read_csv(request_csv.file)
        if request_df.empty:
            return JSONResponse(
                content={"message": "Request data is empty."}, status_code=200
            )  
    else:   
        cache_key = f"l2l3:{region_type}:{region_name}"
        response = await redis_db.get(cache_key)
        if response:
            print('l2l3', cache_key)
            result = json.loads(response)
            return result


    condition = [] 
    if region_type == "Zone" and region_name is not None:
        condition.append(AssortmentOutput.zone == region_name)
    elif region_type == "State" and region_name is not None:
        condition.append(AssortmentOutput.state == region_name)
    elif region_type == "City" and region_name is not None:
        condition.append(AssortmentOutput.city == region_name)
    elif region_type == "Branch" and region_name is not None:
        condition.append(AssortmentOutput.br_code == region_name)

   
    l2_assort_comp_query = (
        select(
            AssortmentOutput.sap_id,
            AssortmentOutput.br_code,
            AssortmentOutput.L2.label("L2"),
            func.count(distinct(AssortmentOutput.sap_id)).label("COUNT_DISTINCT(sap_id)")
        )
        .where(
            and_(*condition, AssortmentOutput.exist_in_model_output == 1)
        )
        .group_by(AssortmentOutput.L2, AssortmentOutput.sap_id, AssortmentOutput.br_code)
        .order_by(func.count(distinct(AssortmentOutput.sap_id)).desc())
    )

    l2_assort_dist_miss_query = (
        select(
            AssortmentOutput.sap_id,
            AssortmentOutput.br_code,
            AssortmentOutput.L2.label("L2"),
            func.count(distinct(AssortmentOutput.sap_id)).label("COUNT_DISTINCT(sap_id)")
        )
        .where(
            and_(*condition, AssortmentOutput.exist_in_model_output == 0, AssortmentOutput.is_sold == 1)
        )
        .group_by(AssortmentOutput.L2, AssortmentOutput.sap_id, AssortmentOutput.br_code)
        .order_by(func.count(distinct(AssortmentOutput.sap_id)).desc())
    )

    l3_assort_comp_query = (
        select(
            AssortmentOutput.sap_id,
            AssortmentOutput.br_code,
            AssortmentOutput.L3.label("L3"),
            func.count(distinct(AssortmentOutput.sap_id)).label("COUNT_DISTINCT(sap_id)")
        )
        .where(
            and_(*condition, AssortmentOutput.exist_in_model_output == 1)
        )
        .group_by(AssortmentOutput.L3, AssortmentOutput.sap_id, AssortmentOutput.br_code)
        .order_by(func.count(distinct(AssortmentOutput.sap_id)).desc())
    )

    l3_assort_dist_miss_query = (
        select(
            AssortmentOutput.sap_id,
            AssortmentOutput.br_code,
            AssortmentOutput.L3.label("L3"),
            func.count(distinct(AssortmentOutput.sap_id)).label("COUNT_DISTINCT(sap_id)")
        )
        .where(
            and_(*condition, AssortmentOutput.exist_in_model_output == 0, AssortmentOutput.is_sold == 1)
        )
        .group_by(AssortmentOutput.L3, AssortmentOutput.sap_id, AssortmentOutput.br_code)
        .order_by(func.count(distinct(AssortmentOutput.sap_id)).desc())
    )


    queries = [postgres_db.fetch_all(query) for query in [l2_assort_comp_query, l2_assort_dist_miss_query, l3_assort_comp_query, l3_assort_dist_miss_query]]
    result = await gather(*queries)
    l2_assort_comp, l2_assort_dist_miss, l3_assort_comp, l3_assort_dist_miss = result

    l2_assort_comp  = [dict(row) for row in l2_assort_comp]
    l2_assort_dist_miss = [dict(row) for row in l2_assort_dist_miss]
    l3_assort_comp = [dict(row) for row in l3_assort_comp]
    l3_assort_dist_miss = [dict(row) for row in l3_assort_dist_miss]


    if request_df is not None:
        l2_assort_comp_df = pd.DataFrame(l2_assort_comp)
        l2_assort_dist_miss_df = pd.DataFrame(l2_assort_dist_miss)
        l3_assort_comp_df = pd.DataFrame(l3_assort_comp)
        l3_assort_dist_miss_df = pd.DataFrame(l3_assort_dist_miss)

        l2_assort_comp_merged_df = pd.merge(l2_assort_comp_df, request_df, on=["sap_id", "br_code"], how="left")
        l2_assort_comp_merged_df = l2_assort_comp_merged_df[["L2", "COUNT_DISTINCT(sap_id)"]]

        l2_assort_dist_miss_merged_df = pd.merge(l2_assort_dist_miss_df, request_df, on=["sap_id", "br_code"], how="left")
        l2_assort_dist_miss_merged_df = l2_assort_dist_miss_merged_df[["L2", "COUNT_DISTINCT(sap_id)"]]

        l3_assort_comp_merged_df = pd.merge(l3_assort_comp_df, request_df, on=["sap_id", "br_code"], how="left")
        l3_assort_comp_merged_df = l3_assort_comp_merged_df[["L3", "COUNT_DISTINCT(sap_id)"]]

        l3_assort_dist_miss_merged_df = pd.merge(l3_assort_dist_miss_df, request_df, on=["sap_id", "br_code"], how="left")
        l3_assort_dist_miss_merged_df = l3_assort_dist_miss_merged_df[["L3", "COUNT_DISTINCT(sap_id)"]]


        l2_assort_comp = l2_assort_comp_merged_df.to_dict(orient="records")
        l2_assort_dist_miss = l2_assort_dist_miss_merged_df.to_dict(orient="records")
        l3_assort_comp = l3_assort_comp_merged_df.to_dict(orient="records")
        l3_assort_dist_miss = l3_assort_dist_miss_merged_df.to_dict(orient="records")
  
    # Convert the query results to a list of dictionaries
    result = {
        'l2_assort_comp': [dict(row) for row in l2_assort_comp[:10]],
        'l2_assort_dist_miss': [dict(row) for row in l2_assort_dist_miss[:10]],
        'l3_assort_comp': [dict(row) for row in l3_assort_comp[:10]],
        'l3_assort_dist_miss': [dict(row) for row in l3_assort_dist_miss[:10]]
    }
  
    if request_csv is None:
        serialized_data = json.dumps(result)
        await redis_db.set(cache_key, serialized_data)

    return result


@L2L3.post("/l2l3-table", operation_id="fetch-l2l3-table")
async def fetch_l2l3_table(
    region_type: str = Form(None),
    region_name: str = Form(None),
    page_no_l2: int = Form(1),
    page_count_l2: int = Form(100),
    sort_param_l2: str = Form("COUNT_DISTINCT_COMP(sap_id)"),
    sort_type_l2: str = Form("desc"),
    page_no_l3: int = Form(1),
    page_count_l3: int = Form(100),
    sort_param_l3: str = Form("COUNT_DISTINCT_COMP(sap_id)"),
    sort_type_l3: str = Form("desc"),
    postgres_db=Depends(get_postgres_db),
):
    cache_key = f"l2l3:{region_type}:{region_name}:{page_no_l2}:{page_count_l2}:{sort_param_l2}:{sort_type_l2}:{page_no_l3}:{page_count_l3}:{sort_param_l3}:{sort_type_l3}"
    response = await redis_db.get(cache_key)
    if response:
        print("l2l3", cache_key)
        result = json.loads(response)
        return result

    condition = []
    if region_type == "Zone" and region_name is not None:
        condition.append(AssortmentOutput.zone == region_name)
    elif region_type == "State" and region_name is not None:
        condition.append(AssortmentOutput.state == region_name)
    elif region_type == "City" and region_name is not None:
        condition.append(AssortmentOutput.city == region_name)
    elif region_type == "Branch" and region_name is not None:
        condition.append(AssortmentOutput.br_code == region_name)

    # sort and limit the query results
    order_by_clause_l2 = (desc(f"{sort_param_l2}") if sort_type_l2 == "desc" else asc(f"{sort_param_l2}")) 
    offset_l2 = (page_no_l2 - 1) * page_count_l2

    l2_assort_comp_query = (
        select(
            [
                AssortmentOutput.L2,
                func.count(distinct(case([(and_(*condition, AssortmentOutput.exist_in_model_output == 1), AssortmentOutput.sap_id)]))).label("COUNT_DISTINCT_MISS(sap_id)"),
                func.count(distinct(case([(and_(*condition, AssortmentOutput.exist_in_model_output == 0, AssortmentOutput.is_sold == 1), AssortmentOutput.sap_id)]))).label("COUNT_DISTINCT_COMP(sap_id)"),
                case(
                    [
                        (
                            func.count(distinct(case([(and_(*condition, AssortmentOutput.exist_in_model_output == 1), AssortmentOutput.sap_id)]))) != 0,
                            func.count(distinct(case([(and_(*condition, AssortmentOutput.exist_in_model_output == 0, AssortmentOutput.is_sold == 1), AssortmentOutput.sap_id)]))) / func.count(distinct(case([(and_(*condition, AssortmentOutput.exist_in_model_output == 1), AssortmentOutput.sap_id)]))),
                        ),
                        (
                            func.count(distinct(case([(and_(*condition, AssortmentOutput.exist_in_model_output == 1), AssortmentOutput.sap_id)]))) == 0,
                            0,  # or any default value you prefer when the denominator is zero
                        ),
                    ]
                ).label("Ratio")
            ]
        )
        .group_by(AssortmentOutput.L2)
        .order_by(order_by_clause_l2)
        # .limit(page_count_l2)
        # .offset(offset_l2)
    )

    l2_count_query = select(
        [func.count().label("l2_count")]).select_from(l2_assort_comp_query)
    l2_table_count = await postgres_db.fetch_val(l2_count_query)

    l2_assort_comp_query = l2_assort_comp_query.limit(page_count_l2).offset(offset_l2)  # limit and offset should be applied after the group by clause


    # sort and limit the query results
    order_by_clause_l3 = (desc(f"{sort_param_l3}") if sort_type_l3 == "desc" else asc(f"{sort_param_l3}")) 
    offset_l3 = (page_no_l3 - 1) * page_count_l3


    l3_assort_comp_query = (
        select(
            [
                AssortmentOutput.L3,
                func.count(distinct(case([(and_(*condition, AssortmentOutput.exist_in_model_output == 1), AssortmentOutput.sap_id)]))).label("COUNT_DISTINCT_MISS(sap_id)"),
                func.count(distinct(case([(and_(*condition, AssortmentOutput.exist_in_model_output == 0, AssortmentOutput.is_sold == 1), AssortmentOutput.sap_id)]))).label("COUNT_DISTINCT_COMP(sap_id)"),
                case(
                    [
                        (
                            func.count(distinct(case([(and_(*condition, AssortmentOutput.exist_in_model_output == 1), AssortmentOutput.sap_id)]))) != 0,
                            func.count(distinct(case([(and_(*condition, AssortmentOutput.exist_in_model_output == 0, AssortmentOutput.is_sold == 1), AssortmentOutput.sap_id)]))) / func.count(distinct(case([(and_(*condition, AssortmentOutput.exist_in_model_output == 1), AssortmentOutput.sap_id)]))),
                        ),
                        (
                            func.count(distinct(case([(and_(*condition, AssortmentOutput.exist_in_model_output == 1), AssortmentOutput.sap_id)]))) == 0,
                            0,  # or any default value you prefer when the denominator is zero
                        ),
                    ]
                ).label("Ratio")
            ]
        )
        .group_by(AssortmentOutput.L3)
        .order_by(order_by_clause_l3)
        # .limit(page_count_l3)
        # .offset(offset_l3)
    )


    l3_count_query = select(
        [func.count().label("l3_count")]).select_from(l3_assort_comp_query)
    l3_table_count = await postgres_db.fetch_val(l3_count_query)

    l3_assort_comp_query = l3_assort_comp_query.limit(page_count_l3).offset(offset_l3)  # limit and offset should be applied after the group by clause

    queries = [
        postgres_db.fetch_all(query)
        for query in [l2_assort_comp_query, l3_assort_comp_query]
    ]
    result = await gather(*queries)
    l2_table, l3_table = result
    result_dict = {}
    result_dict["l2_count"] = l2_table_count
    result_dict["l3_count"] = l3_table_count
    result_dict["l2_table"] = []
    result_dict["l3_table"] = []


    for row in l2_table:
        count_distinct_miss = row["COUNT_DISTINCT_MISS(sap_id)"]
        ratio = round(row["COUNT_DISTINCT_COMP(sap_id)"] / count_distinct_miss if count_distinct_miss != 0 else 0, 2)
        result_dict["l2_table"].append({**dict(row), "Ratio": ratio})

    for row in l3_table:
        count_distinct_miss = row["COUNT_DISTINCT_MISS(sap_id)"]
        ratio = round(row["COUNT_DISTINCT_COMP(sap_id)"] / count_distinct_miss if count_distinct_miss != 0 else 0, 2)
        result_dict["l3_table"].append({**dict(row), "Ratio": ratio})

       
    serialized_data = json.dumps(result_dict)
    await redis_db.set(cache_key, serialized_data)

    return result_dict
