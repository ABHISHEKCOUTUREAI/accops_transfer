from fastapi import APIRouter, Form, Depends
from ..models import AssortmentOutput, Product
from sqlalchemy import and_, select, or_, func, distinct, desc, asc, cast, Numeric
import  json
import csv
from ..utils import build_condition
from fastapi.responses import StreamingResponse
from io import StringIO
from .common import get_postgres_db
from app.db import redis_db
from app.utils import decimal_serializer

newproduct = APIRouter(prefix="/couture/assortment", tags=["new-products"])


@newproduct.post("/new-products", operation_id="fetch-products-info")  
async def fetch_new_products(
    region_type: str = Form(None),
    region_name: str = Form(None),
    L0: str = Form(None),
    L1: str = Form(None),
    L2: str = Form(None),
    L3: str = Form(None),
    flag: bool  = Form(True),
    page_no: int = Form(1),
    page_size: int = Form(100),
    sort_param: str = Form("num_qty_sold"),
    bounce_sort_param: str = Form("item_name"),
    sort_type: str = Form("desc"),
    bounce_sort_type: str = Form("desc"),
    postgres_db = Depends(get_postgres_db),

):
    cache_key = f"new-products:{region_type}:{region_name}:{L0}:{L1}:{L2}:{L3}:{flag}:{page_no}:{sort_param}:{sort_type}:{bounce_sort_param}:{bounce_sort_type}"
    response = await redis_db.get(cache_key)
    if response:
        result = json.loads(response)
        print('new-products', cache_key)
        return result
    
    # Build the filter 
    condition = build_condition(region_type, region_name, L0, L1, L2, L3)
 
    # 1. new_product
    new_product_condition = and_(*condition, AssortmentOutput.is_new_product == 1, AssortmentOutput.exist_in_model_output==1)

    product_query = (
        select([
            AssortmentOutput.sap_id,
            AssortmentOutput.item_name,
            Product.mrp.label("mrp"),
            func.round(func.sum(cast(AssortmentOutput.total_amount, Numeric)), 2).label('total_amount'),
            func.round(func.sum(cast(AssortmentOutput.total_margin, Numeric)), 2).label('total_margin'),
            func.round(func.sum(cast(AssortmentOutput.num_qty_sold, Numeric)), 2).label('num_qty_sold'),
        ])
        .join(Product, AssortmentOutput.sap_id == Product.sap_id)
        .where(new_product_condition)
        .group_by(AssortmentOutput.sap_id, AssortmentOutput.item_name, Product.mrp)  # Add more columns if needed
    )

    # Dynamically adjust the order_by clause based on sorting_parameter and sorting_type
    if sort_param == "num_qty_sold":
        order_by_clause = desc("num_qty_sold") if sort_type == "desc" else asc(AssortmentOutput.num_qty_sold)
    elif sort_param == "total_amount":
        order_by_clause = desc("total_amount") if sort_type == "desc" else asc("total_amount")
    elif sort_param == "total_margin":
        order_by_clause = desc("total_margin") if sort_type == "desc" else asc("total_margin")
    elif sort_param == "sap_id":
        order_by_clause = desc("sap_id") if sort_type == "desc" else asc("sap_id")
    elif sort_param == "item_name":
        order_by_clause = desc("item_name") if sort_type == "desc" else asc("item_name")    
    else:
        order_by_clause = desc("num_qty_sold")

    product_query = product_query.order_by(order_by_clause)
    
    if flag:
        offset = (page_no - 1) * page_size
        product_query = product_query.limit(page_size).offset(offset)

    product_rows = await postgres_db.fetch_all(product_query)
    product_result = [dict(rows) for rows in product_rows] 
   
    product_count_query = select([func.count()]).select_from(AssortmentOutput).where(new_product_condition)
    product_count = await postgres_db.fetch_val(product_count_query)
    
    # 2.new_product_bounce
    new_product_bounce_condition = and_(
        *condition,
        AssortmentOutput.is_new_product==1, 
        AssortmentOutput.exist_in_bounce_data==1, 
        AssortmentOutput.is_sold!=1
        )
    
    bounce_query = (
        select(
            distinct(AssortmentOutput.sap_id),
            AssortmentOutput.item_name.label("item_name"),
            AssortmentOutput.L3.label("L3"),
        )
        .where(new_product_bounce_condition)
    )

    # Dynamically adjust the order_by clause based on sorting_parameter and sorting_type
    if bounce_sort_param == "L3":
        order_by_clause = desc(AssortmentOutput.L3) if bounce_sort_type == "desc" else asc(AssortmentOutput.L3)
    elif bounce_sort_param == "sap_id":
        order_by_clause = desc(AssortmentOutput.sap_id) if bounce_sort_type == "desc" else asc(AssortmentOutput.sap_id)
    elif bounce_sort_param == "item_name":
        order_by_clause = desc(AssortmentOutput.item_name) if bounce_sort_type == "desc" else asc(AssortmentOutput.item_name)    
    else:
        order_by_clause = desc(AssortmentOutput.item_name)

    bounce_query = bounce_query.order_by(order_by_clause)

    if flag:
        offset = (page_no - 1) * 100
        bounce_query = bounce_query.limit(100).offset(offset)
  
    bounce_rows = await postgres_db.fetch_all(bounce_query)
    bounce_result = [dict(rows) for rows in bounce_rows]

    bounce_count_query =  select([func.count()]).select_from(AssortmentOutput).where(new_product_bounce_condition)
    bounce_count = await postgres_db.fetch_val(bounce_count_query)

    # Process the data and add it to the result dictionary
    response = {"product_result": [], "product_count": 0, "bounce_result":[], "bounce_count":0}
    response['product_result'] = product_result
    response['product_count'] = product_count
    response['bounce_result'] = bounce_result
    response['bounce_count'] = bounce_count

    # Serialize the data using the custom serializer
    serialized_data = json.dumps(response, default=decimal_serializer)
    if flag:
        await redis_db.set(cache_key, serialized_data)
    return response


@newproduct.post("/new-product-stats", operation_id="fetch-new-product-stats")    
async def fetch_new_products_stats(
    region_type: str = Form(None),
    region_name: str = Form(None),
    L0: str = Form(None),
    L1: str = Form(None),
    L2: str = Form(None),
    L3: str = Form(None),
    postgres_db = Depends(get_postgres_db),
):
    cache_key = f"new-product-stats:{region_type}:{region_name}:{L0}:{L1}:{L2}:{L3}"
    response = await redis_db.get(cache_key)
    if response:
        print('new-product-stats', cache_key)
        result = json.loads(response)
        return result   
    
    # Build the filter 
    condition = build_condition(region_type, region_name, L0, L1, L2, L3)  


    # total products recommended
    total_products_query = (
        select([func.count(distinct(AssortmentOutput.sap_id))])
        .where(and_(*condition, AssortmentOutput.exist_in_model_output == 1)
    ))
    total_products_recommended = await postgres_db.fetch_val(total_products_query)

    # New Product recomendation
    new_product_recommendation_query = (
        select([func.count(distinct(AssortmentOutput.sap_id))])
        .where(and_(*condition, AssortmentOutput.is_new_product == 1, AssortmentOutput.exist_in_model_output == 1)
    ))
    new_product_recommendation = await postgres_db.fetch_val(new_product_recommendation_query)


    # New product hit-rate
    new_product_hit_rate_query = select([func.count(distinct(AssortmentOutput.sap_id))]).select_from(AssortmentOutput).where(and_(*condition,  AssortmentOutput.is_new_product ==1, AssortmentOutput.exist_in_model_output == 1, or_(AssortmentOutput.is_sold == 1 , AssortmentOutput.exist_in_bounce_data == 1 )))
    new_product_hit_rate = await postgres_db.fetch_val(new_product_hit_rate_query)


    # Total demand
    total_demand_query = select([func.count(distinct(AssortmentOutput.sap_id))]).select_from(AssortmentOutput).where(and_(*condition, or_(AssortmentOutput.is_sold == 1, AssortmentOutput.exist_in_bounce_data == 1)))
    total_demand = await postgres_db.fetch_val(total_demand_query)

    # currently explained demand
    curr_explained_demand_query = select([func.count(distinct(AssortmentOutput.sap_id))]).select_from(AssortmentOutput).where(and_(*condition,  AssortmentOutput.is_sold == 1))
    curr_explained_demand = await postgres_db.fetch_val(curr_explained_demand_query)

    # Demand explained by recomandation
    demand_explained_by_recommandation_query = select([func.count(distinct(AssortmentOutput.sap_id))]).select_from(AssortmentOutput).where(and_(*condition, AssortmentOutput.exist_in_model_output ==1, or_(AssortmentOutput.is_sold == 1, AssortmentOutput.exist_in_bounce_data == 1)))
    demand_explained_by_recommandation = await postgres_db.fetch_val(demand_explained_by_recommandation_query)


    results = {}


    results["fraction_new_products"] = round((new_product_recommendation / total_products_recommended) * 100, 2) if total_products_recommended != 0 else 0

    results["new_product_hit_rate"] = round((new_product_hit_rate / new_product_recommendation) * 100, 2) if new_product_recommendation != 0 else 0

    results["total_demand"] = round(total_demand, 2)

    results["current_explained_demand"] = round(curr_explained_demand, 2)

    results["demand_explained_by_reccomendation"] = round(demand_explained_by_recommandation, 2)

    results["demand_currently_explained_percent"] = round((curr_explained_demand / total_demand) * 100, 2) if total_demand != 0 else 0

    results["demand_explained_reccomendation_percent"] = round((demand_explained_by_recommandation / total_demand) * 100, 2) if total_demand != 0 else 0

    results["improvement_factor"] = round(demand_explained_by_recommandation / curr_explained_demand, 2) if curr_explained_demand != 0 else 0


    serialized_data = json.dumps(results)
    await redis_db.set(cache_key, serialized_data)
    return results


@newproduct.post("/new-products-csv", operation_id="fetch-products-csv")  
async def fetch_new_products_csv(
    region_type: str = Form(None),
    region_name: str = Form(None),
    L0: str = Form(None),
    L1: str = Form(None),
    L2: str = Form(None),
    L3: str = Form(None),
    sort_param: str = Form("num_qty_sold"),
    sort_type: str = Form("desc"),
    postgres_db = Depends(get_postgres_db)
):
    
    # Build the filter 
    condition = build_condition(region_type, region_name, L0, L1, L2, L3)
 
    # 1. new_product
    new_product_condition = and_(*condition, AssortmentOutput.is_new_product == 1)

    product_query = select(
        AssortmentOutput.sap_id,
        AssortmentOutput.item_name,
        func.round(cast(AssortmentOutput.total_amount, Numeric), 2).label('total_amount'), 
        func.round(cast(AssortmentOutput.total_margin, Numeric), 2).label('total_margin'),
        func.round(cast(AssortmentOutput.num_qty_sold, Numeric), 2).label('num_qty_sold'),
    ).where(new_product_condition)
    
    # Dynamically adjust the order_by clause based on sorting_parameter and sorting_type
    if sort_param == "num_qty_sold":
        order_by_clause = desc(AssortmentOutput.num_qty_sold) if sort_type == "desc" else asc(AssortmentOutput.num_qty_sold)
    elif sort_param == "total_amount":
        order_by_clause = desc(AssortmentOutput.total_amount) if sort_type == "desc" else asc(AssortmentOutput.total_amount)
    elif sort_param == "total_margin":
        order_by_clause = desc(AssortmentOutput.total_margin) if sort_type == "desc" else asc(AssortmentOutput.total_margin)
    elif sort_param == "sap_id":
        order_by_clause = desc(AssortmentOutput.sap_id) if sort_type == "desc" else asc(AssortmentOutput.sap_id)
    elif sort_param == "item_name":
        order_by_clause = desc(AssortmentOutput.item_name) if sort_type == "desc" else asc(AssortmentOutput.item_name)    
    else:
        order_by_clause = desc(AssortmentOutput.num_qty_sold)

    product_query = product_query.order_by(order_by_clause)
    

    product_rows = await postgres_db.fetch_all(product_query)
    product_result = [dict(rows) for rows in product_rows] 
   
    if product_result:
        # Create a CSV string
        csv_content = StringIO()
        csv_writer = csv.DictWriter(csv_content, fieldnames=product_result[0].keys())
        csv_writer.writeheader()
        csv_writer.writerows(product_result)

        # Convert the CSV string to bytes
        csv_bytes = csv_content.getvalue().encode("utf-8")

        # Return the response as a streaming response with content type "text/csv"
        return StreamingResponse(iter([csv_bytes]), media_type="text/csv", headers={"Content-Disposition": "attachment;filename=products.csv"})
    else:
        # If there are no rows, return an empty response
        return StreamingResponse(iter([]), media_type="text/csv", headers={"Content-Disposition": "attachment;filename=products.csv"})


@newproduct.post("/new-products-bounce-csv", operation_id="fetch-bounce-csv")  
async def fetch_new_products_bounce_csv(
    region_type: str = Form(None),
    region_name: str = Form(None),
    L0: str = Form(None),
    L1: str = Form(None),
    L2: str = Form(None),
    L3: str = Form(None),
    bounce_sort_param: str = Form("item_name"),
    bounce_sort_type: str = Form("desc"),
    postgres_db = Depends(get_postgres_db)
):
    
    # Build the filter 
    condition = build_condition(region_type, region_name, L0, L1, L2, L3)
 

    # 2.new_product_bounce
    new_product_bounce_condition = and_(
        *condition,
        AssortmentOutput.is_new_product==1, 
        AssortmentOutput.exist_in_bounce_data==1, 
        AssortmentOutput.is_sold!=1
        )
    
    bounce_query = (
        select(
            AssortmentOutput.sap_id.label("sap_id"),
            AssortmentOutput.item_name.label("item_name"),
            AssortmentOutput.L3.label("L3"),
        )
        .where(new_product_bounce_condition)
        .group_by(
        AssortmentOutput.sap_id, 
        AssortmentOutput.item_name, 
        AssortmentOutput.L3
        )
    )

    # Dynamically adjust the order_by clause based on sorting_parameter and sorting_type
    if bounce_sort_param == "L3":
        order_by_clause = desc(AssortmentOutput.L3) if bounce_sort_type == "desc" else asc(AssortmentOutput.L3)
    elif bounce_sort_param == "sap_id":
        order_by_clause = desc(AssortmentOutput.sap_id) if bounce_sort_type == "desc" else asc(AssortmentOutput.sap_id)
    elif bounce_sort_param == "item_name":
        order_by_clause = desc(AssortmentOutput.item_name) if bounce_sort_type == "desc" else asc(AssortmentOutput.item_name)    
    else:
        order_by_clause = desc(AssortmentOutput.item_name)

    bounce_query = bounce_query.order_by(order_by_clause)

  
    bounce_rows = await postgres_db.fetch_all(bounce_query)
    bounce_result = [dict(rows) for rows in bounce_rows]

    if bounce_result:
        # Create a CSV string
        csv_content = StringIO()
        csv_writer = csv.DictWriter(csv_content, fieldnames=bounce_result[0].keys())
        csv_writer.writeheader()
        csv_writer.writerows(bounce_result)

        # Convert the CSV string to bytes
        csv_bytes = csv_content.getvalue().encode("utf-8")

        # Return the response as a streaming response with content type "text/csv"
        return StreamingResponse(iter([csv_bytes]), media_type="text/csv", headers={"Content-Disposition": "attachment;filename=products.csv"})
    else:
        # If there are no rows, return an empty response
        return StreamingResponse(iter([]), media_type="text/csv", headers={"Content-Disposition": "attachment;filename=products.csv"})

