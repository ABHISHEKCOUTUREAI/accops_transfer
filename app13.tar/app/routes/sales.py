from fastapi import APIRouter, Form, Depends
from ..models import  Orders, Product, Store, AiocdAnalysisSales, IQVIASales, MSAAllCats
from sqlalchemy import func, select, and_, asc, desc, cast, Numeric
import calendar
import  datetime
import json
from app.db import redis_db
from .common import get_postgres_db
from app.utils import decimal_serializer
from collections import defaultdict 

sales = APIRouter(prefix="/couture/assortment", tags=["sales"])



@sales.post("/past-sales", operation_id="fetch-past-sales")   
async def fetch_past_salse(
    region_type: str = Form(None), 
    region_name: str = Form(None),
    L0: str = Form(None),
    L1: str = Form(None),
    L2: str = Form(None),
    L3: str = Form(None),
    postgres_db = Depends(get_postgres_db),
):
    cache_key = f"past-sales:{region_type}:{region_name}:{L0}:{L1}:{L2}:{L3}"
    response = await redis_db.get(cache_key)
    if response:
        result = json.loads(response)
        return result
    
    # Check if region_type and region_name are provided
    if region_type is None and region_name is None:
        # Fetch all br_codes without any conditions
        store_query = select(Store.br_code)
    else:
        # Query the Store table to retrieve br_code based on region_type and region_name
        store_query = select(Store.br_code).where(
            (Store.zone == region_name) if region_type == "Zone" else
            (Store.state == region_name) if region_type == "State" else
            (Store.city == region_name)  if region_type == "City" else
            (Store.br_code == region_name) 
        )

    # Build the filter 
    condition = []
    if L0 is not None:
        condition.append(Product.L0 == L0)
    if L1 is not None:
        condition.append(Product.L1 == L1)
    if L2 is not None:
        condition.append(Product.L2 == L2)
    if L3 is not None:
        condition.append(Product.L3 == L3)  

    br_codes = [row[0] for row in await postgres_db.fetch_all(store_query)]
    # br_codes = ["TNJ3"]
    

    sales_query = select(
    Orders.tran_date,
    Product.L0,
    func.sum(Orders.total_revenue).label('total_revenue'),
    func.sum(Orders.quantity_sold).label('units_sold'),
    func.sum(Orders.total_cost).label('total_cost'),
    ).join(
        Orders,
        Product.sap_id == Orders.sap_id
    ).where(
        and_(
        Orders.br_code.in_(br_codes),
        *condition  # Include category_conditions
    )
    ).group_by(
        Orders.tran_date, Product.L0
    )
    
    sales = await postgres_db.fetch_all(sales_query)
 

    # Process the results
    sales_result = {}
    for record in sales:
        date = record["tran_date"].date()  
        month_number = date.month
        month = calendar.month_name[month_number] 
        year = date.year
        month_year = month + " " + str(year)
 
        L0 = record["L0"]
        total_revenue = record["total_revenue"]
        units_sold = record["units_sold"]
        total_cost = record["total_cost"]

        if month_year not in sales_result:
            sales_result[month_year] = []
        # Check if the L0 exists in the current month_year data
        l0_found = False
        for item in sales_result[month_year]:
            if item["L0"] == L0:
                # Add the revenue to the existing L0
                item["total_revenue"] += round(total_revenue, 2)
                item["units_sold"] += round(units_sold, 2)
                item["total_margin"] += round((total_cost - total_revenue), 2)
                l0_found = True
                break

        # If the L0 doesn't exist in the current month_year data, add it
        if not l0_found:
            sales_result[month_year].append({"L0": L0, "total_revenue": round(total_revenue, 2), "units_sold": round(units_sold, 2), "total_margin": round(total_cost, 2) })


    # Sort the results chronologically by month and year
    sorted_sales_result = dict(sorted(sales_result.items(), key=lambda x: datetime.datetime.strptime(x[0], "%B %Y")))
   
    serialized_data = json.dumps(sorted_sales_result)
    await redis_db.set(cache_key, serialized_data)
    return sorted_sales_result
    

@sales.post("/aiocd-sales", operation_id="fetch-aiocd-sales")   
async def fetch_aiocd_sales(
    ranking_level: str = Form(None),
    L0: str = Form(None),
    L1: str = Form(None),
    L2: str = Form(None),
    L3: str = Form(None),
    sap_id: str  = Form(None),
    page_no: int = Form(1),
    page_size: int = Form(100),
    sort_param: str = Form("revenue"),
    sort_type: str = Form("desc"),
    flag: bool = Form(True),
    postgres_db = Depends(get_postgres_db)
):
    cache_key = f"aiocd-sales:{ranking_level}:{L0}:{L1}:{L2}:{L3}:{page_no}:{sort_param}:{sort_type}:{flag}"
    response = await redis_db.get(cache_key)
    if response:
        result = json.loads(response)
        return result
    
    condition = []
    if L0 is not None:
        condition.append(AiocdAnalysisSales.L0 == L0)
    if L1 is not None:
        condition.append(AiocdAnalysisSales.L1 == L1)
    if L2 is not None:
        condition.append(AiocdAnalysisSales.L2 == L2)
    if L3 is not None:
        condition.append(AiocdAnalysisSales.L3 == L3)  
    if ranking_level is not None:
        condition.append(AiocdAnalysisSales.ranking_level == ranking_level)  
    if sap_id is not None:
        condition.append(AiocdAnalysisSales.sap_id == sap_id)       

    # Dynamically adjust the order_by clause based on sort_param and sort_type
    sort_column = getattr(AiocdAnalysisSales, sort_param, AiocdAnalysisSales.revenue)
    order_by_clause = desc(sort_column) if sort_type == "desc" else asc(sort_column)

    aiocd_sales_query = select(
            AiocdAnalysisSales.L0,
            AiocdAnalysisSales.L1,
            AiocdAnalysisSales.L2,
            AiocdAnalysisSales.L3,
            AiocdAnalysisSales.sap_id,
            AiocdAnalysisSales.item_name,
            func.round(cast(AiocdAnalysisSales.aiocd_revenue, Numeric), 2).label('aiocd_revenue'),
            func.round(cast(AiocdAnalysisSales.revenue, Numeric), 2).label('revenue'),
            func.round(cast(AiocdAnalysisSales.fraction_revenue, Numeric), 4).label('fraction_revenue'),
            AiocdAnalysisSales.level_rank,
            AiocdAnalysisSales.aiocd_level_rank
    ).where(and_(*condition)).order_by(order_by_clause)
        
    
    if flag:
        offset = (page_no - 1) * page_size
        aiocd_sales_query = aiocd_sales_query.limit(page_size).offset(offset)

    aiocd_sales_rows = await postgres_db.fetch_all(aiocd_sales_query)
    aiocd_sales_result = [dict(rows) for rows in aiocd_sales_rows] 
   
    
    aiocd_sales_query =  select([func.count()]).select_from(AiocdAnalysisSales).where(and_(*condition))
    aiocd_sales_count = await postgres_db.fetch_val(aiocd_sales_query)
   
    response = {
        'aiocd_sales_result': aiocd_sales_result,
        'aiocd_sales_count': aiocd_sales_count
    }
   
    serialized_data = json.dumps(response, default=decimal_serializer)
    await redis_db.set(cache_key, serialized_data)
    return response


@sales.post("/iqvia-sales", operation_id="fetch-iqvia-sales")   
async def fetch_iqvia_sales(
    ranking_level: str = Form(None),
    L0: str = Form(None),
    L1: str = Form(None),
    L2: str = Form(None),
    L3: str = Form(None),
    sap_id: str  = Form(None),
    page_no: int = Form(1),
    page_size: int = Form(100),
    sort_param: str = Form("revenue"),
    sort_type: str = Form("desc"),
    flag: bool = Form(True),
    postgres_db = Depends(get_postgres_db)
):
    cache_key = f"iqvia-sales:{ranking_level}:{L0}:{L1}:{L2}:{L3}:{page_no}:{sort_param}:{sort_type}:{flag}"
    response = await redis_db.get(cache_key)
    if response:
        result = json.loads(response)
        return result
    
    condition = []
    if L0 is not None:
        condition.append(IQVIASales.L0 == L0)
    if L1 is not None:
        condition.append(IQVIASales.L1 == L1)
    if L2 is not None:
        condition.append(IQVIASales.L2 == L2)
    if L3 is not None:
        condition.append(IQVIASales.L3 == L3)  
    if ranking_level is not None:
        condition.append(IQVIASales.ranking_level == ranking_level)  
    if sap_id is not None:
        condition.append(IQVIASales.sap_id == sap_id)  
        

    # Dynamically adjust the order_by clause based on sort_param and sort_type
    sort_column = getattr(IQVIASales, sort_param, IQVIASales.revenue)
    order_by_clause = desc(sort_column) if sort_type == "desc" else asc(sort_column)

    iqvia_sales_query = select(
            IQVIASales.L0,
            IQVIASales.L1,
            IQVIASales.L2,
            IQVIASales.L3,
            IQVIASales.sap_id,
            IQVIASales.item_name,
            func.round(cast(IQVIASales.iqvia_revenue, Numeric), 2).label('iqvia_revenue'),
            func.round(cast(IQVIASales.revenue, Numeric), 2).label('revenue'),
            func.round(cast(IQVIASales.fraction_revenue, Numeric), 4).label('fraction_revenue'),
            IQVIASales.level_rank,
            IQVIASales.iqvia_level_rank
    ).where(and_(*condition)).order_by(order_by_clause)
        
    
    if flag:
        offset = (page_no - 1) * page_size
        iqvia_sales_query = iqvia_sales_query.limit(page_size).offset(offset)

    iqvia_sales_rows = await postgres_db.fetch_all(iqvia_sales_query)
    iqvia_sales_results = [dict(rows) for rows in iqvia_sales_rows] 

    iqvia_sales_query =  select([func.count()]).select_from(IQVIASales).where(and_(*condition))
    iqvia_sales_count = await postgres_db.fetch_val(iqvia_sales_query)
    
    response = {
        'iqvia_sales_results': iqvia_sales_results,
        'iqvia_sales_count': iqvia_sales_count
    }

   
    serialized_data = json.dumps(response, default=decimal_serializer)
    await redis_db.set(cache_key, serialized_data)
    return response
  

@sales.get("/sales-filters", operation_id="fetch-filters-sales")   
async def fetch_filters_sales(
    postgres_db = Depends(get_postgres_db)
):

    cache_key = "fetch-filters-sales"
    response =   await redis_db.get(cache_key)
    if response:
        print('Hit', cache_key)
        result = json.loads(response)
        return result
    
    query = select(
        MSAAllCats.ranking_level,
        MSAAllCats.L0,
        MSAAllCats.L1,
        MSAAllCats.L2,
        MSAAllCats.L3,
        MSAAllCats.sap_id,
    ).order_by(MSAAllCats.ranking_level) 
    rows = await postgres_db.fetch_all(query)
    
    
    # Organize data into a nested dictionary
    filters_data =  defaultdict(lambda: defaultdict(lambda: defaultdict(lambda: defaultdict(lambda: defaultdict(dict)))))

    for row in rows:
        ranking_level = row[0]
        L0 = row[1]
        L1 = row[2]
        L2 = row[3]
        L3 = row[4]
        sap_id = row[5]

        # Check if all L0, L1, L2, L3 are not empty or "nan" before adding the entry
        if all(value and (value.lower() == '' or  value.lower()) == "nan" for value in [L0, L1, L2, L3]):
            continue
        filters_data[ranking_level][L0][L1][L2][L3][sap_id] = {}

    response =  {
        'filters': filters_data
    }
    serialized_data = json.dumps(response)
    await redis_db.set(cache_key, serialized_data)
    return response





