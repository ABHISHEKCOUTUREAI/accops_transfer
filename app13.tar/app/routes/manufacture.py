from fastapi import APIRouter, Form, Depends, UploadFile, File
from ..models import Orders, AssortmentOutput
from .common import get_postgres_db
from sqlalchemy import func, select, and_
from ..utils import build_condition
from app.db import redis_db
import json
from typing import Optional
import pandas as pd
from fastapi.responses import JSONResponse

manufacture = APIRouter(prefix="/couture/assortment", tags=["manufacture"])


@manufacture.post("/mfac-revenue", operation_id="fetch-brand-revenue")   # done
async def fetch_brand_revenue(
    region_type: str = Form(None),
    region_name: str = Form(None),
    L0: str = Form(None),
    L1: str = Form(None),
    L2: str = Form(None),
    L3: str = Form(None),
    mfac_name: str = Form(None),
    brand_name: str = Form(None),
    postgres_db = Depends(get_postgres_db)
):
    cache_key = f"mfac-revenue:{region_type}:{region_name}:{L0}:{L1}:{L2}:{L3}:{mfac_name}:{brand_name}"
    response = await redis_db.get(cache_key)
    if response:
        print('mfac-revenue', cache_key)
        result = json.loads(response)
        return result
    
    # Build the filter 
    condition = build_condition(region_type, region_name, L0, L1, L2, L3, mfac_name, brand_name)  
    
    product_query = select(AssortmentOutput.sap_id).where(and_(*condition))
    
    product_query = product_query.subquery()

    last_year_dates_query = select(
        Orders.tran_date
    ).distinct().order_by(
        Orders.tran_date.desc()
    ).limit(365).subquery()

    last_year_orders_query = select(Orders).select_from(Orders).join(
        last_year_dates_query,
        Orders.tran_date == last_year_dates_query.c.tran_date
    ).subquery()

    # Query the Orders table to calculate total revenue, total cost, and num orders
    orders_query = select(
        func.sum(last_year_orders_query.c.total_revenue).label("total_revenue"),
        func.sum(last_year_orders_query.c.total_cost).label("total_cost"),
        func.sum(last_year_orders_query.c.num_orders).label("num_orders"),
        func.sum(last_year_orders_query.c.quantity_sold).label("unit_sold")
    ).join(
        product_query,
        last_year_orders_query.c.sap_id == product_query.c.sap_id
    )

    revenue_data = await postgres_db.fetch_one(orders_query)

    if revenue_data:
        result = {
            "total_sales": round(revenue_data["total_revenue"], 2) if revenue_data["total_revenue"] is not None else 0,
            "total_orders": round(revenue_data["num_orders"], 2) if revenue_data["num_orders"] is not None  else 0,
            "total_units_sold": round(revenue_data["unit_sold"], 2) if revenue_data["unit_sold"] is not None  else 0,
            "total_margin": round(revenue_data["total_revenue"] - revenue_data["total_cost"], 2) if (revenue_data["total_cost"] is not None  and revenue_data["total_revenue"] is not None ) else 0,
        }
    else:
        result = {}

    serialized_data = json.dumps(result, default=str)
    await redis_db.set(cache_key, serialized_data)
    return result



@manufacture.post("/top-mfac-brand", operation_id="fetch-top-mfac-brands")
async def fetch_top_mfac_brands(
    request_csv: Optional[UploadFile] = File(None),
    region_type: str = Form(None),
    region_name: str = Form(None),
    L0: str = Form(None),
    L1: str = Form(None),
    L2: str = Form(None),
    L3: str = Form(None),
    mfac_name: str = Form(None),
    brand_name: str = Form(None),
    postgres_db = Depends(get_postgres_db)
):
    condition = build_condition(region_type, region_name, L0, L1, L2, L3)

    request_df = None
    if request_csv is not None:
        request_df = pd.read_csv(request_csv.file)
        if request_df.empty:
            return JSONResponse(
                content={"message": "Request data is empty."}, status_code=200
            )  
    else:      
        cache_key = f"top-mfac-brands:{region_type}:{region_name}:{L0}:{L1}:{L2}:{L3}:{mfac_name}:{brand_name}"
        response =  await redis_db.get(cache_key)
        if response:
            print('top-mfac-brands', cache_key)
            result = json.loads(response)
            return result
    

    query = select(
        AssortmentOutput.L0,
        AssortmentOutput.mfac_name,
        AssortmentOutput.brand_name,
        AssortmentOutput.sap_id,
        AssortmentOutput.br_code,
        func.sum(AssortmentOutput.total_amount_train).label("total_amount_train")
    ).where(
        and_(*condition)
    ).group_by(AssortmentOutput.L0, AssortmentOutput.mfac_name, AssortmentOutput.brand_name, AssortmentOutput.sap_id, AssortmentOutput.br_code)


    data = await postgres_db.fetch_all(query)
    rows = [dict(row) for row in data]
    if request_df is not None:
        result_df = pd.DataFrame(rows)
        if result_df.empty:
            return JSONResponse(content=[], status_code=200)
        else:
            merged_df = pd.merge(result_df, request_df, on=["sap_id", "br_code"], how="left")
            rows = merged_df.to_dict(orient="records")
    # Initialize the result dictionary
    result = {'mfac': {}, 'brand': {}}

    for record in rows:
        if record["mfac_name"] and record["brand_name"] and record["L0"] and record["total_amount_train"]:
            mfac_name = record["mfac_name"]
            brand_name = record["brand_name"]
            l0_name = record["L0"]
            total_amount_train = record["total_amount_train"]

            # Initialize mfac entry if not present
            if mfac_name not in result['mfac']:
                result['mfac'][mfac_name] = {"total": 0}

            # Initialize brand entry if not present
            if brand_name not in result['brand']:
                result['brand'][brand_name] = {"total": 0}

            # Initialize L0 entry if not present
            if l0_name not in result['mfac'][mfac_name]:
                result['mfac'][mfac_name][l0_name] = 0

            if l0_name not in result['brand'][brand_name]:
                result['brand'][brand_name][l0_name] = 0

            # Update the values
            result['mfac'][mfac_name][l0_name] += int(total_amount_train)
            result['brand'][brand_name][l0_name] += int(total_amount_train)

            result['mfac'][mfac_name]["total"] += int(total_amount_train)
            result['brand'][brand_name]["total"] += int(total_amount_train)

    # Sort and limit based on total revenue in descending order
    result['mfac'] = dict(sorted(result['mfac'].items(), key=lambda item: item[1]["total"], reverse=True))
    result['mfac'] = dict(list(result['mfac'].items())[:10])

    result['brand'] = dict(sorted(result['brand'].items(), key=lambda item: item[1]["total"], reverse=True))
    result['brand'] = dict(list(result['brand'].items())[:10])

    if request_csv is None:
        serialized_data = json.dumps(result)
        await redis_db.set(cache_key, serialized_data)

    return result
