from pydantic_settings import BaseSettings

class Settings(BaseSettings):

    postgres_user: str
    postgres_password: str
    postgres_db: str
    postgres_service: str
    redis_service: str
    redis_db_str: str
    uvicorn_workers: str

    @property
    def redis_db(self):
        return int(self.redis_db_str)
    
    class Config:
        env_file = ".env"

settings = Settings()