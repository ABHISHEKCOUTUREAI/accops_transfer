from fastapi.middleware.cors import CORSMiddleware
from fastapi.openapi.utils import get_openapi
from sqlalchemy.ext.declarative import declarative_base
from starlette.requests import Request
from app.auth_commons.src.dependencies import UserDependency
from fastapi import FastAPI, Depends
from app.auth_commons.src.schemas import  Token
from fastapi.security import OAuth2PasswordRequestForm
from app.db import PostgresDatabase
from contextlib import asynccontextmanager
from starlette.middleware.base import BaseHTTPMiddleware, RequestResponseEndpoint
from app.startup import load_aiocd_analysis, load_assortment_output, load_product, load_store, load_bounce, load_orders, load_inventory, load_probability, load_aiocd_sales, load_iqvia_sales, load_msa_all_cats, load_new_store_assortment
from app.settings import settings

@asynccontextmanager
async def lifespan(app: FastAPI):
   
    print(
        "================================ Starting up ================================================="
    )
    app.state.db = PostgresDatabase(settings)
    app.state.db.create_tables()
    await app.state.db.connect()
    # await load_aiocd_analysis(postgres_db=app.state.db.database)
    # await load_assortment_output(postgres_db=app.state.db.database)
    # await load_product(postgres_db=app.state.db.database)
    # await load_store(postgres_db=app.state.db.database)
    # await load_bounce(postgres_db=app.state.db.database)
    # await load_orders(postgres_db=app.state.db.database)
    # await load_inventory(postgres_db=app.state.db.database)
    # await load_probability(postgres_db=app.state.db.database)
    # await load_aiocd_sales(postgres_db=app.state.db.database)
    # await load_iqvia_sales(postgres_db=app.state.db.database)
    # await load_msa_all_cats(postgres_db=app.state.db.database)
    # await load_new_store_assortment(postgres_db=app.state.db.database)



    # Add other startup items here
    print("Loading Completed !")
    yield

    print(
        "================================ Shutting down ================================================="
    )




app = FastAPI(
    title="assortment-api",
    docs_url="/docs",
    redoc_url=None,
    lifespan=lifespan,
    root_path='/assortment-backend'
)




def custom_openapi():
    if app.openapi_schema:
        return app.openapi_schema
    openapi_schema = get_openapi(
        title=app.title, version=app.version, routes=app.routes
    )
    app.openapi_schema = openapi_schema
    return app.openapi_schema


app.openapi = custom_openapi

Base = declarative_base()

# # Write redis middleware  to get and set data
# class RedisMiddleware(BaseHTTPMiddleware):
#     def __init__(self, app, redis_db):
#         super().__init__(app)
#         self.redis_db = redis_db
#         self.excluded_paths = ['/couture/assortment/new-products-bounce-csv', '/couture/assortment/new-products-csv', '/couture/assortment/hit_and_miss', '/couture/assortment/hit-miss-csv', '/couture/assortment/probability-csv']
#     async def dispatch(self, request: Request, call_next: RequestResponseEndpoint) -> Coroutine[Any, Any, Response]:
#         print("Dispatching")
#         path = request.scope['path']
#         if path in self.excluded_paths:
#             print(f"Skipping cache for excluded path: {path}")
#             return await call_next(request)
#         redis_db = self.redis_db
#         form = await request.form()
#         cache_key = f"{request.method}:{request.url}:{str(sorted(dict(form).items()))}"
#         if await redis_db.get(cache_key) is not None:
#             print("Found cache")
#             result = (await redis_db.get(cache_key)).decode('utf-8')
#             return StreamingResponse(content=result, media_type="application/json", headers={'Content-Type': 'application/json'})
#         print("No cache found")
    
#         res = await call_next(request)
#         response_content =(b"".join([chunk async for chunk in res.body_iterator])).decode('utf-8')
#         await redis_db.set(cache_key, response_content)
#         return StreamingResponse(content=response_content, media_type="application/json", headers={'Content-Type': 'application/json'})


# app.add_middleware(RedisMiddleware, redis_db=redis_db)
# Add the Middleware to the app
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)



# Add it to auth directory to get JWT token (Login Router)
user_dependency = UserDependency()
# app.add_middleware(AuthenticationMiddleware, user_dependency=user_dependency)


@app.post(
    "/auth/token", response_model=Token, summary="Authenticate via JWT Bearer scheme"
)
async def get_access_token(
    request: Request, form_data: OAuth2PasswordRequestForm = Depends()
):
    return await user_dependency.login_for_access_token(request, form_data)



