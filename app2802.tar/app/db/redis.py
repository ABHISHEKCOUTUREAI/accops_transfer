
from redis import asyncio as aioredis
from app.settings import settings

redis_db = aioredis.from_url(f'redis://{settings.postgres_service}:6379/2')