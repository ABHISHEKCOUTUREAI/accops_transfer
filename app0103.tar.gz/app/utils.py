
from .models import AssortmentOutput, Product
from decimal import Decimal
from sqlalchemy import func, select, asc, desc, cast, Numeric



def build_condition(region_type=None, region_name=None, L0=None, L1=None, L2=None, L3=None, mfac_name=None, brand=None):
    
    condition = []

    if region_type == "Zone":
        condition.append(AssortmentOutput.zone == region_name)
    elif region_type == "State":
        condition.append(AssortmentOutput.state == region_name)
    elif region_type == "City":
        condition.append(AssortmentOutput.city == region_name)
    elif region_type == "Branch":
        condition.append(AssortmentOutput.br_code == region_name)

    if L0 is not None:
        condition.append(AssortmentOutput.L0 == L0)
    if L1 is not None:
        condition.append(AssortmentOutput.L1 == L1)
    if L2 is not None:
        condition.append(AssortmentOutput.L2 == L2)
    if L3 is not None:
        condition.append(AssortmentOutput.L3 == L3)

    if mfac_name is not None:
        condition.append(AssortmentOutput.mfac_name == mfac_name)
    if brand is not None:
        condition.append(AssortmentOutput.brand_name == brand)

    return condition


def decimal_serializer(obj):
    if isinstance(obj, Decimal):
        return str(obj)
    raise TypeError("Object of type {} is not JSON serializable".format(type(obj).__name__))

def order_clause_store_assortment(sort_param, sort_type):
    if sort_param == "num_qty_sold":
        order_by_clause = (desc("num_qty_sold") if sort_type == "desc" else asc("num_qty_sold"))
    elif sort_param == "total_amount":
        order_by_clause = (desc("total_amount") if sort_type == "desc" else asc("total_amount"))
    elif sort_param == "total_margin":
        order_by_clause = (desc("total_margin") if sort_type == "desc" else asc("total_margin"))
    elif sort_param == "sap_id":
        order_by_clause = desc("sap_id") if sort_type == "desc" else asc("sap_id")
    elif sort_param == "item_name":
        order_by_clause = desc("item_name") if sort_type == "desc" else asc("item_name")
    elif sort_param == "min_qty":
        order_by_clause = desc("min_qty") if sort_type == "desc" else asc("min_qty")
    elif sort_param == "max_qty":
        order_by_clause = desc("max_qty") if sort_type == "desc" else asc("max_qty")
    elif sort_param == "L0":
        order_by_clause = desc("L0") if sort_type == "desc" else asc("L0")
    elif sort_param == "L1":
        order_by_clause = desc("L1") if sort_type == "desc" else asc("L1")
    elif sort_param == "L2":
        order_by_clause = desc("L2") if sort_type == "desc" else asc("L2")
    elif sort_param == "L3":
        order_by_clause = desc("L3") if sort_type == "desc" else asc("L3")
    elif sort_param == "molecule":
        order_by_clause = desc("molecule") if sort_type == "desc" else asc("molecule")
    elif sort_param == "mrp":
        order_by_clause = desc("mrp").nullslast() if sort_type == "desc" else asc("mrp")
    elif sort_param == "num_stores_product_part_of_assortment":
        order_by_clause = desc("num_stores_product_part_of_assortment") if sort_type == "desc" else asc("num_stores_product_part_of_assortment")
    else:
        order_by_clause = desc("num_qty_sold")
    return order_by_clause

def form_store_assortment_query(model, region_type, region_name):
    # Filter the region type first
    if region_type == "State":
        query = select([model]).where(model.state == region_name).subquery()
    else:
        query = select([model]).where(model.city == region_name).subquery()

    # Join on Product to get the item name, mrp, and L0, L1, L2, L3
    query = (
        select (
            [
                query.c.sap_id.label('sap_id'),
                query.c.br_code.label('br_code'),
                Product.item_name.label('item_name'),
                Product.L0.label('L0'),
                Product.L1.label('L1'),
                Product.L2.label('L2'),
                Product.L3.label('L3'),
                Product.mfac_name.label('mfac_name'),
                Product.brand_name.label('brand_name'),
                Product.molecule.label('molecule'),
                func.round(cast(Product.mrp, Numeric), 2).label('mrp'),
                func.round(cast(query.c.min_qty, Numeric), 2).label('min_qty'),
                func.round(cast(query.c.max_qty, Numeric), 2).label('max_qty'),
                func.round(cast(query.c.num_qty_sold, Numeric), 2).label('num_qty_sold'),
                func.round(cast(query.c.total_amount, Numeric), 2).label('total_amount'),
                func.round(cast(query.c.total_margin, Numeric), 2).label('total_margin'),
                query.c.num_stores_product_part_of_assortment.label('num_stores_product_part_of_assortment')
            ]
        ).join(Product, query.c.sap_id == Product.sap_id)
    ).subquery()

    return query
