import csv
from io import StringIO
import pandas as pd
from fastapi import APIRouter, File, Form, UploadFile, Depends
from fastapi.responses import JSONResponse, StreamingResponse
from sqlalchemy import  and_, asc, desc, func, join,  select
from .common import get_postgres_db
from ..models import AssortmentOutput, Probability
from ..utils import build_condition


custom_assortment = APIRouter(prefix="/couture/assortment", tags=["custom_assortment"])



# @custom_assortment.post("/probability", operation_id="fetch-probability")
# async def fetch_probability(
#     request_csv: UploadFile = File(
#     ...
#     ),  # Request csv file with schema sap_id,br_code,min_qty,max_qty
#     region_type: str = Form(None),
#     region_name: str = Form(None),
#     L0: str = Form(None),
#     L1: str = Form(None),
#     L2: str = Form(None),
#     L3: str = Form(None),
#     page_no: int = Form(1),
#     page_size: int = Form(100),
#     sort_type: str = Form("desc"),
#     sort_param: str = Form("probability"),
#     postgres_db=Depends(get_postgres_db),
# ):
#     # request.csv
#     if not request_csv.filename.endswith(".csv"):
#         return JSONResponse(
#             content={"error": "Invalid file format. Please upload a CSV file."},
#             status_code=400,
#         )
#     request_df = pd.read_csv(request_csv.file)
#     if request_df.empty:
#         return JSONResponse(
#             content={"message": "Request data is empty."}, status_code=200
#         )

#     # Build the filter
#     condition = build_condition(region_type, region_name, L0, L1, L2, L3)
    
#     sap_ids = request_df.sap_id.tolist()
#     condition.append(AssortmentOutput.sap_id.in_(sap_ids))

#     br_codes = request_df.br_code.tolist()
#     condition.append(AssortmentOutput.br_code.in_(br_codes))

#     # Adjust the batch size as needed
#     offset = (page_no - 1) * page_size
#     query = (
#         select(
#             [
#                 AssortmentOutput.sap_id,
#                 AssortmentOutput.item_name,
#                 AssortmentOutput.br_code,
#                 Probability.probability,
#             ]
#         )
#         .select_from(
#             join(
#                 AssortmentOutput,
#                 Probability,
#                 AssortmentOutput.sap_id == Probability.sap_id,
#             )
#         )
#         .where(and_(*condition))
#         .offset(offset)
#         .limit(page_size)
#     )

    
#     # Dynamically adjust the order_by clause based on sorting_parameter and sorting_type
#     if sort_param == "probability":
#         order_by_clause = (
#             desc(Probability.probability)
#             if sort_type == "desc"
#             else asc(Probability.probability)
#         )
#     elif sort_param == "sap_id":
#         order_by_clause = (
#             desc(AssortmentOutput.sap_id)
#             if sort_type == "desc"
#             else asc(AssortmentOutput.sap_id)
#         )
#     elif sort_param == "item_name":
#         order_by_clause = (
#             desc(AssortmentOutput.item_name)
#             if sort_type == "desc"
#             else asc(AssortmentOutput.item_name)
#         )
#     elif sort_param == "br_code":
#         order_by_clause = (
#             desc(AssortmentOutput.br_code)
#             if sort_type == "desc"
#             else asc(AssortmentOutput.br_code)
#         )
#     else:
#         order_by_clause = desc(Probability.Probability)

#     query = query.order_by(order_by_clause)

#     result = await postgres_db.fetch_all(query)
#     result_dicts = [dict(record) for record in result]


#     total_count_query = (
#         select([func.count()])
#         .select_from(
#             join(
#                 AssortmentOutput,
#                 Probability,
#                 AssortmentOutput.sap_id == Probability.sap_id,
#             )
#         )
#         .where(and_(*condition))
#     )
#     total_count = await postgres_db.fetch_val(total_count_query)
#     # breakpoint()

#     if not result_dicts:
#         return JSONResponse(content=[], status_code=200)

#     return {"total_count": total_count, "data": result_dicts}

@custom_assortment.post("/probability", operation_id="fetch-probability")
async def fetch_probability(
    request_csv: UploadFile = File(
        ...
    ),  # Request csv file with schema sap_id,br_code,min_qty,max_qty
    region_type: str = Form(None),
    region_name: str = Form(None),
    L0: str = Form(None),
    L1: str = Form(None),
    L2: str = Form(None),
    L3: str = Form(None),
    page_no: int = Form(1),
    page_size: int = Form(100),
    sort_type: str = Form("desc"),
    sort_param: str = Form("probability"),
    postgres_db=Depends(get_postgres_db),
):
    # request.csv
    if not request_csv.filename.endswith(".csv"):
        return JSONResponse(
            content={"error": "Invalid file format. Please upload a CSV file."},
            status_code=400,
        )
    request_df = pd.read_csv(request_csv.file)
    if request_df.empty:
        return JSONResponse(
            content={"message": "Request data is empty."}, status_code=200
        )

    # Build the filter
    condition = build_condition(region_type, region_name, L0, L1, L2, L3)

    # Adjust the batch size as needed
    offset = (page_no - 1) * page_size
    query = (
        select(
            [
                AssortmentOutput.sap_id,
                AssortmentOutput.item_name,
                AssortmentOutput.br_code,
                Probability.probability,
            ]
        )
        .select_from(
            join(
                AssortmentOutput,
                Probability,
                AssortmentOutput.sap_id == Probability.sap_id,
            )
        )
        .where(and_(*condition))
        .offset(offset)
        .limit(page_size)
    )

    # Dynamically adjust the order_by clause based on sorting_parameter and sorting_type
    if sort_param == "probability":
        order_by_clause = (
            desc(Probability.probability)
            if sort_type == "desc"
            else asc(Probability.probability)
        )
    elif sort_param == "sap_id":
        order_by_clause = (
            desc(AssortmentOutput.sap_id)
            if sort_type == "desc"
            else asc(AssortmentOutput.sap_id)
        )
    elif sort_param == "item_name":
        order_by_clause = (
            desc(AssortmentOutput.item_name)
            if sort_type == "desc"
            else asc(AssortmentOutput.item_name)
        )
    elif sort_param == "br_code":
        order_by_clause = (
            desc(AssortmentOutput.br_code)
            if sort_type == "desc"
            else asc(AssortmentOutput.br_code)
        )
    else:
        order_by_clause = desc(Probability.Probability)

    query = query.order_by(order_by_clause)

    result = await postgres_db.fetch_all(query)
    result_dicts = [dict(record) for record in result]

    total_count_query = (
        select([func.count()])
        .select_from(
            join(
                AssortmentOutput,
                Probability,
                AssortmentOutput.sap_id == Probability.sap_id,
            )
        )
        .where(and_(*condition))
    )
    total_count = await postgres_db.fetch_val(total_count_query)

    result_df = pd.DataFrame(result_dicts)

    if not result_dicts:
        return JSONResponse(content=[], status_code=200)

    # Merge the result_df with request_df on 'sap_id' and 'br_code'
    merged_df = pd.merge(result_df, request_df, on=["sap_id", "br_code"], how="left")
    merged_df = merged_df[["sap_id", "item_name", "br_code", "probability"]]
    paginated_result = merged_df.to_dict(orient="records")

    return {"total_count": total_count, "data": paginated_result}


@custom_assortment.post("/probability-csv", operation_id="fetch-probability")
async def fetch_probability_csv(
    request_csv: UploadFile = File(
        ...
    ),  # Request csv file with schema sap_id,br_code,min_qty,max_qty
    region_type: str = Form(None),
    region_name: str = Form(None),
    L0: str = Form(None),
    L1: str = Form(None),
    L2: str = Form(None),
    L3: str = Form(None),
    sort_type: str = Form("desc"),
    sort_param: str = Form("probability"),
    postgres_db=Depends(get_postgres_db),
):


    if not request_csv.filename.endswith(".csv"):
        return JSONResponse(
            content={"error": "Invalid file format. Please upload a CSV file."},
            status_code=400,
        )
    request_df = pd.read_csv(request_csv.file)
    if request_df.empty:
        return JSONResponse(
            content={"message": "Request data is empty."}, status_code=200
        )

    condition = build_condition(region_type, region_name, L0, L1, L2, L3)

    sap_ids = request_df.sap_id.tolist()
    condition.append(AssortmentOutput.sap_id.in_(sap_ids))

    br_codes = request_df.br_code.tolist()
    condition.append(AssortmentOutput.br_code.in_(br_codes))

    query = (
        select(
            [
                AssortmentOutput.sap_id,
                AssortmentOutput.item_name,
                AssortmentOutput.br_code,
                Probability.probability,
            ]
        )
        .select_from(
            join(
                AssortmentOutput,
                Probability,
                AssortmentOutput.sap_id == Probability.sap_id,
            )
        )
        .where(and_(*condition))
        .limit(2000)
    )

    # Dynamically adjust the order_by clause based on sorting_parameter and sorting_type
    if sort_param == "probability":
        order_by_clause = (
            desc(Probability.probability)
            if sort_type == "desc"
            else asc(Probability.probability)
        )
    elif sort_param == "sap_id":
        order_by_clause = (
            desc(AssortmentOutput.sap_id)
            if sort_type == "desc"
            else asc(AssortmentOutput.sap_id)
        )
    elif sort_param == "item_name":
        order_by_clause = (
            desc(AssortmentOutput.item_name)
            if sort_type == "desc"
            else asc(AssortmentOutput.item_name)
        )
    elif sort_param == "br_code":
        order_by_clause = (
            desc(AssortmentOutput.br_code)
            if sort_type == "desc"
            else asc(AssortmentOutput.br_code)
        )
    else:
        order_by_clause = desc(Probability.Probability)

    query = query.order_by(order_by_clause)

    result = await postgres_db.fetch_all(query)
    result_dicts = [dict(record) for record in result]

    result_df = pd.DataFrame(result_dicts)

    if not result_dicts:
        return JSONResponse(content=[], status_code=200)

    paginated_result = result_df.to_dict(orient="records")

    if paginated_result:
        # Create a CSV string
        csv_content = StringIO()
        csv_writer = csv.DictWriter(csv_content, fieldnames=paginated_result[0].keys())
        csv_writer.writeheader()
        csv_writer.writerows(paginated_result[:1000])

        # Convert the CSV string to bytes
        csv_bytes = csv_content.getvalue().encode("utf-8")

        # Return the response as a streaming response with content type "text/csv"
        return StreamingResponse(
            iter([csv_bytes]),
            media_type="text/csv",
            headers={"Content-Disposition": "attachment;filename=response.csv"},
        )
    else:
        # If there are no rows, return an empty response
        return StreamingResponse(
            iter([]),
            media_type="text/csv",
            headers={"Content-Disposition": "attachment;filename=products.csv"},
        )
