import csv
import math
from collections import defaultdict
from io import StringIO
import pandas as pd
from fastapi import APIRouter, File, Form, UploadFile, Depends
from fastapi.responses import  StreamingResponse
from sqlalchemy import  and_, asc, case, cast, desc, func, join, or_, select, Integer
from .common import get_postgres_db
from ..models import AssortmentOutput,  Product
from ..utils import build_condition
from app.db import redis_db
from typing import List, Optional
import json

prediction = APIRouter(prefix="/couture/assortment", tags=["prediction"])


def group_hit_and_miss(query):
    query = (
        (
            select(
                [
                    query.c.sap_id,
                    query.c.item_name,
                    query.c.L0,
                    query.c.L3,
                    query.c.mrp,
                    query.c.molecule,
                    func.sum(query.c.curr_inv).label("current_inventory"),
                    func.sum(query.c.min_qty).label("min_qty"),
                    func.sum(query.c.max_qty).label("max_qty"),
                    cast(func.sum(query.c.num_qty_sold), Integer).label('num_qty_sold'),
                    func.sum(query.c.total_amount).label("total_amount"),
                    func.sum(query.c.total_margin).label("total_margin"),
                ]
            )
        )
        .group_by(
            query.c.sap_id, query.c.item_name, query.c.mrp, query.c.L0, query.c.L3, query.c.molecule
        )
        .subquery()
    )

    new_query = select(
        [
            query,
            case(
                [
                    (
                        query.c.current_inventory < query.c.min_qty,
                        query.c.min_qty - query.c.current_inventory,
                    ),
                    (
                        (query.c.current_inventory < query.c.max_qty)
                        & (query.c.current_inventory >= query.c.min_qty),
                        0,
                    ),
                    (
                        query.c.current_inventory >= query.c.max_qty,
                        query.c.max_qty - query.c.current_inventory,
                    ),
                ]
            ).label("minimum_replenishment"),
            # status_label
            case(
                [
                    (
                        (query.c.current_inventory == 0) & (query.c.min_qty > 0),
                        "0_new",
                    ),
                    (
                        (query.c.current_inventory > 0) & (query.c.current_inventory <  query.c.min_qty),
                        "1_replenish",
                    ),
                    (
                        (query.c.current_inventory > 0) & (query.c.current_inventory >= query.c.min_qty) & (query.c.current_inventory <= query.c.max_qty),
                        "2_no_replenishment",
                    ),
                    (
                        (query.c.current_inventory == 0) & (query.c.max_qty == 0),
                        "8_dead",
                    ),
                    (
                        (query.c.current_inventory > query.c.max_qty),
                        "9_excess",
                    ),
                    # else 'unidentified
                ],
                
            ).label("status_label"),
        ]
    )



    return new_query


@prediction.post("/hit-and-miss", operation_id="fetch-products-info")
async def fetch_hit_and_miss(
    request_csv: Optional[UploadFile] = File(None),
    region_type: str = Form(None),
    region_name: str = Form(None),
    L0: str = Form(None),
    L1: str = Form(None),
    L2: str = Form(None),
    L3: str = Form(None),
    mfac_name: str = Form(None),
    brand_name: str = Form(None),
    page_no: int = Form(1),
    page_count: int = Form(100),
    sort_param: str = Form("num_qty_sold"),
    sort_type: str = Form("desc"),
    filter_params: List[str] = Form([]),
    molecule: str = Form(None),
    filter_type: str = Form(None),
    postgres_db=Depends(get_postgres_db),
):

    condition = build_condition(
        region_type, region_name, L0, L1, L2, L3, mfac_name, brand=brand_name
    )
    if request_csv is not None:
        request_df = pd.read_csv(request_csv.file)
        if not request_df.empty:
            sap_ids = request_df.sap_id.tolist()
            condition.append(AssortmentOutput.sap_id.in_(sap_ids))
            br_codes = request_df.br_code.tolist()
            condition.append(AssortmentOutput.br_code.in_(br_codes))
    else:  
        cache_key = f"hit-and-miss:{region_type}:{region_name}:{L0}:{L1}:{L2}:{L3}:{mfac_name}:{brand_name}:{page_no}:{page_count}:{sort_param}:{sort_type}:{filter_params}:{molecule}:{filter_type}"
        response = await redis_db.get(cache_key)
        if response:
            print('hit-and-miss', cache_key)
            result = json.loads(response)
            return result
    


    query = select([AssortmentOutput]).where(and_(*condition)).subquery()
    # update query to filter by molecule
    if molecule:
        query = (
            select([query, Product.mrp, Product.molecule.label('molecule')])
            .select_from(join(query, Product, query.c.sap_id == Product.sap_id))
            .where(Product.molecule.ilike(f"{molecule}%"))
            .subquery()
        )
    else:
        query = (
            select([query, Product.mrp, Product.molecule.label('molecule')])
            .select_from(join(query, Product, query.c.sap_id == Product.sap_id))
            .subquery()
        )

    hit_query = select([query]).where(
        and_(query.c.exist_in_model_output == 1, query.c.is_sold == 1)
    )

    miss_query = select([query]).where(
        and_(query.c.exist_in_model_output == 0, query.c.is_sold == 1)
    )

    assortment_query = select([query]).where(
        and_(query.c.exist_in_model_output == 1)
    )

    hit_query = group_hit_and_miss(hit_query.subquery())
    miss_query = group_hit_and_miss(miss_query.subquery())
    assortment_query = group_hit_and_miss(assortment_query.subquery())


    if filter_params and filter_type:
        if filter_type == "status_label":
            assortment_query = assortment_query.subquery()
            #filter params is an array. check if status_label is in filter_params
            assortment_query = select([assortment_query]).where(assortment_query.c.status_label.in_(filter_params))
            # assortment_query = assortment_query.where(query.c.status_label == filter_type)
        
    hit_count_query = select([func.count().label("hit_count")]).select_from(hit_query)
    miss_count_query = select([func.count().label("miss_count")]).select_from(miss_query)
    assortment_count_query = select([func.count().label("assortment_count")]).select_from(assortment_query)

    # count rows where query.status_label = '0_new'
    new_count_query = select([func.count().label("new_count")]).select_from(assortment_query).where(assortment_query.c.status_label == '0_new')
    new_count = await postgres_db.fetch_val(new_count_query)

    # count rows where query.status_label = '1_replenish'
    replenish_count_query = select([func.count().label("replenish_count")]).select_from(assortment_query).where(assortment_query.c.status_label == '1_replenish')
    replenish_count = await postgres_db.fetch_val(replenish_count_query)

    # count rows where query.status_label = '2_no_replenishment'
    no_replenishment_count_query = select([func.count().label("optimal")]).select_from(assortment_query).where(assortment_query.c.status_label == '2_no_replenishment')
    optimal_count = await postgres_db.fetch_val(no_replenishment_count_query)

    # count rows where query.status_label = '8_dead'
    # dead_count_query = select([func.count().label("dead_count")]).select_from(assortment_query).where(assortment_query.c.status_label == '8_dead')
    # dead_count = await postgres_db.fetch_val(dead_count_query)

    # count rows where query.status_label = '9_excess'
    excess_count_query = select([func.count().label("excess_count")]).select_from(assortment_query).where(assortment_query.c.status_label == '9_excess')
    excess_count = await postgres_db.fetch_val(excess_count_query)


    hit_count = await postgres_db.fetch_val(hit_count_query)
    miss_count = await postgres_db.fetch_val(miss_count_query)
    assortment_count = await postgres_db.fetch_val(assortment_count_query)

    # Dynamically adjust the order_by clause based on sorting_parameter and sorting_type
    if sort_param == "num_qty_sold":
        order_by_clause = (
            desc("num_qty_sold") if sort_type == "desc" else asc("num_qty_sold")
        )
    elif sort_param == "total_amount":
        order_by_clause = (
            desc("total_amount") if sort_type == "desc" else asc("total_amount")
        )
    elif sort_param == "total_margin":
        order_by_clause = (
            desc("total_margin") if sort_type == "desc" else asc("total_margin")
        )
    elif sort_param == "sap_id":
        order_by_clause = desc("sap_id") if sort_type == "desc" else asc("sap_id")
    elif sort_param == "item_name":
        order_by_clause = desc("item_name") if sort_type == "desc" else asc("item_name")
    elif sort_param == "min_qty":
        order_by_clause = desc("min_qty") if sort_type == "desc" else asc("min_qty")
    elif sort_param == "max_qty":
        order_by_clause = desc("max_qty") if sort_type == "desc" else asc("max_qty")
    elif sort_param == "L0":
        order_by_clause = desc("L0") if sort_type == "desc" else asc("L0")
    elif sort_param == "L3":
        order_by_clause = desc("L3") if sort_type == "desc" else asc("L3")
    elif sort_param == "mrp":
        order_by_clause = desc("mrp").nullslast() if sort_type == "desc" else asc("mrp")
    elif sort_param == "num_stores_product_part_of_assortment":
        order_by_clause = (
            desc("num_stores_product_part_of_assortment")
            if sort_type == "desc"
            else asc("num_stores_product_part_of_assortment")
        )
    elif sort_param == "current_inventory":
        order_by_clause = (
            desc("current_inventory")
            if sort_type == "desc"
            else asc("current_inventory")
        )
    elif sort_param == "minimum_replenishment":
        order_by_clause = (
            desc("minimum_replenishment")
            if sort_type == "desc"
            else asc("minimum_replenishment")
        )
    elif sort_param == "status_label":
        order_by_clause = (
            desc("status_label") if sort_type == "desc" else asc("status_label")
        )
    elif sort_param == "molecule":
        order_by_clause = desc("molecule") if sort_type == "desc" else asc("molecule")
    else:
        order_by_clause = desc("num_qty_sold")

    hit_query = hit_query.order_by(order_by_clause)
    miss_query = miss_query.order_by(order_by_clause)
    assortment_query = assortment_query.order_by(order_by_clause)
  
    offset = (page_no - 1) * page_count
    hit_query = hit_query.limit(page_count).offset(offset)
    miss_query = miss_query.limit(page_count).offset(offset)
    assortment_query = assortment_query.limit(page_count).offset(offset)

    hit_rows = await postgres_db.fetch_all(hit_query)
    hits = [dict(rows) for rows in hit_rows]
    for hit in hits:
        hit["total_amount"] = (
            round(hit["total_amount"], 2) if hit["total_amount"] is not None else None
        )
        hit["total_margin"] = (
            round(hit["total_margin"], 2) if hit["total_margin"] is not None else None
        )

    # Misses
    miss_rows = await postgres_db.fetch_all(miss_query)
    misses = [dict(rows) for rows in miss_rows]
    for miss in misses:
        miss["total_amount"] = (
            round(miss["total_amount"], 2) if miss["total_amount"] is not None else None
        )
        miss["total_margin"] = (
            round(miss["total_margin"], 2) if miss["total_margin"] is not None else None
        )

    # Assortment
    assortment_rows = await postgres_db.fetch_all(assortment_query)
    assortment = [dict(rows) for rows in assortment_rows]
    for assort in assortment:
        assort["total_amount"] = (
            round(assort["total_amount"], 2)
            if assort["total_amount"] is not None
            else None
        )
        assort["total_margin"] = (
            round(assort["total_margin"], 2)
            if assort["total_margin"] is not None
            else None
        )

    result = {
        "assortment": [],
        "hits": [],
        "misses": [],
        "hit_count": 0,
        "miss_count": 0,
        "assortment_count": 0,
        'new_count': 0,
        'replenish_count': 0,
        'optimal_count': 0,
        # 'dead_count': 0,
        'excess_count': 0
    }


    result["hits"] = hits
    result["misses"] = misses
    result["assortment"] = assortment
    result["hit_count"] = hit_count
    result["miss_count"] = miss_count
    result["assortment_count"] = assortment_count
    result['new_count'] = new_count
    result['replenish_count'] = replenish_count
    result['optimal_count'] = optimal_count
    # result['dead_count'] = dead_count
    result['excess_count'] = excess_count

    if request_csv is None:  
        serialized_data = json.dumps(result, default=str)
        await redis_db.set(cache_key, serialized_data)

    return result


@prediction.post("/hit-miss-csv", operation_id="fetch-hit-miss-csv")  # done
async def fetch_hit_and_miss_csv(
    request_csv: Optional[UploadFile] = File(None),  
    region_type: str = Form(None),
    region_name: str = Form(None),
    L0: str = Form(None),
    L1: str = Form(None),
    L2: str = Form(None),
    L3: str = Form(None),
    sort_param: str = Form("num_qty_sold"),
    sort_type: str = Form("desc"),
    csv_flag: str = Form("recommended"),
    postgres_db=Depends(get_postgres_db),
):
    # Build the filter
    condition = build_condition(region_type, region_name, L0, L1, L2, L3)
    if request_csv is not None:
        request_df = pd.read_csv(request_csv.file)
        if not request_df.empty:
            sap_ids = request_df.sap_id.tolist()
            condition.append(AssortmentOutput.sap_id.in_(sap_ids))
            br_codes = request_df.br_code.tolist()
            condition.append(AssortmentOutput.br_code.in_(br_codes))


    query = (
        select(
            AssortmentOutput.sap_id,
            AssortmentOutput.item_name.label("Item Name"),
            Product.molecule,
            AssortmentOutput.total_amount,
            AssortmentOutput.total_margin,
            AssortmentOutput.num_qty_sold.label("qty_sold"),
            AssortmentOutput.min_qty,
            AssortmentOutput.max_qty,
            AssortmentOutput.aiocd_sales_2022,
            AssortmentOutput.iqvia_revenue.label("iqvia_east_JanToJun2023"),
            AssortmentOutput.num_bounce_train.label("qty_bounce_train"),
            AssortmentOutput.num_bounce_test.label("qty_bounce_test"),
            AssortmentOutput.det_cogs_amt.label("br_cogs_amt"),
            AssortmentOutput.qty_sold_online,
            AssortmentOutput.L0,
            AssortmentOutput.L1,
            AssortmentOutput.L2,
            AssortmentOutput.L3,
            AssortmentOutput.br_code.label("Branch Code"),
            AssortmentOutput.num_qty_sold_train.label("qty_sold_train"),
            Product.mrp,
        )
        .select_from(AssortmentOutput)
        .join(Product, AssortmentOutput.sap_id == Product.sap_id)
    )

    # Dynamically adjust the order_by clause based on sorting_parameter and sorting_type
    if sort_param == "num_qty_sold":
        order_by_clause = (
            desc(AssortmentOutput.num_qty_sold)
            if sort_type == "desc"
            else asc(AssortmentOutput.num_qty_sold)
        )
    elif sort_param == "total_amount":
        order_by_clause = (
            desc(AssortmentOutput.total_amount)
            if sort_type == "desc"
            else asc(AssortmentOutput.total_amount)
        )
    elif sort_param == "total_margin":
        order_by_clause = (
            desc(AssortmentOutput.total_margin)
            if sort_type == "desc"
            else asc(AssortmentOutput.total_margin)
        )
    elif sort_param == "sap_id":
        order_by_clause = (
            desc(AssortmentOutput.sap_id)
            if sort_type == "desc"
            else asc(AssortmentOutput.sap_id)
        )
    elif sort_param == "item_name":
        order_by_clause = (
            desc(AssortmentOutput.item_name)
            if sort_type == "desc"
            else asc(AssortmentOutput.item_name)
        )
    elif sort_param == "min_qty":
        order_by_clause = (
            desc(AssortmentOutput.min_qty)
            if sort_type == "desc"
            else asc(AssortmentOutput.min_qty)
        )
    elif sort_param == "max_qty":
        order_by_clause = (
            desc(AssortmentOutput.max_qty)
            if sort_type == "desc"
            else asc(AssortmentOutput.max_qty)
        )
    elif sort_param == "mrp":
        order_by_clause = desc(Product.mrp) if sort_type == "desc" else asc(Product.mrp)
    elif sort_param == "num_stores_product_part_of_assortment":
        order_by_clause = (
            desc("num_stores_product_part_of_assortment")
            if sort_type == "desc"
            else asc("num_stores_product_part_of_assortment")
        )
    elif sort_param == "current_inventory":
        order_by_clause = (
            desc("current_inventory")
            if sort_type == "desc"
            else asc("current_inventory")
        )
    elif sort_param == "minimum_replenishment":
        order_by_clause = (
            desc("minimum_replenishment")
            if sort_type == "desc"
            else asc("minimum_replenishment")
        )
    elif sort_param == "molecule":
        order_by_clause = desc(Product.molecule) if sort_type == "desc" else asc(Product.molecule)
    else:
        order_by_clause = desc(AssortmentOutput.num_qty_sold)

    query = query.order_by(order_by_clause)

    # Hits
    if csv_flag == "hits":
        hit_condition = and_(
            *condition,
            AssortmentOutput.exist_in_model_output == 1,
            AssortmentOutput.is_sold == 1,
        )
        hit_query = query.where(hit_condition)

        hit_rows = await postgres_db.fetch_all(hit_query)
        result = [dict(rows) for rows in hit_rows]
        for hit in result:
            hit["total_amount"] = (
                round(hit["total_amount"], 2)
                if hit["total_amount"] is not None
                else None
            )
            hit["total_margin"] = (
                round(hit["total_margin"], 2)
                if hit["total_margin"] is not None
                else None
            )
            hit["br_cogs_amt"] = (
                round(hit["br_cogs_amt"], 2) if hit["br_cogs_amt"] is not None else None
            )

    # Misses
    elif csv_flag == "misses":
        miss_condition = and_(
            *condition,
            AssortmentOutput.exist_in_model_output == 0,
            AssortmentOutput.is_sold == 1,
        )
        miss_query = query.where(miss_condition)

        miss_rows = await postgres_db.fetch_all(miss_query)
        result = [dict(rows) for rows in miss_rows]
        for miss in result:
            miss["total_amount"] = (
                round(miss["total_amount"], 2)
                if miss["total_amount"] is not None
                else None
            )
            miss["total_margin"] = (
                round(miss["total_margin"], 2)
                if miss["total_margin"] is not None
                else None
            )
            miss["br_cogs_amt"] = (
                round(miss["br_cogs_amt"], 2)
                if miss["br_cogs_amt"] is not None
                else None
            )

    # Assortment
    else:
        assortment_condition = and_(
            *condition, AssortmentOutput.exist_in_model_output == 1
        )
        assortment_query = query.where(assortment_condition)

        assortment_rows = await postgres_db.fetch_all(assortment_query)
        result = [dict(rows) for rows in assortment_rows]
        for assort in result:
            assort["total_amount"] = (
                round(assort["total_amount"], 2)
                if assort["total_amount"] is not None
                else None
            )
            assort["total_margin"] = (
                round(assort["total_margin"], 2)
                if assort["total_margin"] is not None
                else None
            )
            assort["qty_sold_train"] = (
                round(assort["qty_sold_train"], 2)
                if assort["qty_sold_train"] is not None
                else None
            )
            assort["br_cogs_amt"] = (
                round(assort["br_cogs_amt"], 2)
                if assort["br_cogs_amt"] is not None
                else None
            )
    


    if result:
        # Create a CSV string
        csv_content = StringIO()
        csv_writer = csv.DictWriter(csv_content, fieldnames=result[0].keys())
        csv_writer.writeheader()
        csv_writer.writerows(result)

        # Convert the CSV string to bytes
        csv_bytes = csv_content.getvalue().encode("utf-8")

        # Return the response as a streaming response with content type "text/csv"
        return StreamingResponse(
            iter([csv_bytes]),
            media_type="text/csv",
            headers={"Content-Disposition": "attachment;filename=response.csv"},
        )
    else:
        # If there are no rows, return an empty response
        return StreamingResponse(
            iter([]),
            media_type="text/csv",
            headers={"Content-Disposition": "attachment;filename=products.csv"},
        )


@prediction.post("/margin-buckets", operation_id="fetch-margin-buckets")  # done
async def fetch_margin_buckets(
    region_type: str = Form(None),
    region_name: str = Form(None),
    L0: str = Form(None),
    L1: str = Form(None),
    L2: str = Form(None),
    L3: str = Form(None),
    postgres_db=Depends(get_postgres_db),
):

    # Build the filter
    condition = build_condition(region_type, region_name, L0, L1, L2, L3)
    # Hits
    hit_condition = and_(
        *condition,
        AssortmentOutput.exist_in_model_output == 1,
        AssortmentOutput.is_sold == 1,
    )
    miss_condition = and_(
        *condition,
        AssortmentOutput.exist_in_model_output == 0,
        AssortmentOutput.is_sold == 1,
    )
    base_margin_query = select(
        [
            # Calculate the derived 'margin' column with a case statement to handle division by zero
            case(
                [
                    (
                        AssortmentOutput.total_amount - AssortmentOutput.total_margin
                        != 0,
                        (
                            AssortmentOutput.total_margin
                            / (
                                AssortmentOutput.total_amount
                                - AssortmentOutput.total_margin
                            )
                        )
                        * 100,
                    )
                ],
                else_=0,
            ).label("margin")
        ]
    )

    hit_query = base_margin_query.where(hit_condition)
    miss_query = base_margin_query.where(miss_condition)

    hit_ranges = await postgres_db.fetch_all(hit_query)
    miss_ranges = await postgres_db.fetch_all(miss_query)
    hit_bucket = defaultdict(int)
    miss_bucket = defaultdict(int)

    for row in hit_ranges:
        hit_bucket[math.ceil(row["margin"] / 5)] += 1
    for row in miss_ranges:
        miss_bucket[math.ceil(row["margin"] / 5)] += 1

    hit_bucket_list = []
    miss_bucket_list = []
    for bucket_index in range(21):
        hit_bucket_list.append(hit_bucket[bucket_index])
        miss_bucket_list.append(miss_bucket[bucket_index])

    return {"hit_bucket": hit_bucket_list, "miss_bucket": miss_bucket_list}


# Take a csv file with fields br_code, sap_id, min_qty, max_qty as column names
@prediction.post("/bulk-assortment", operation_id="fetch-bulk-assortment")
async def fetch_bulk_assortment(
    region_type: str = Form(None),
    region_name: str = Form(None),
    file: UploadFile = File(...),
    postgres_db=Depends(get_postgres_db),
):
    # read csv file
    csv_data = pd.read_csv(file.file)

    # get column names
    column_names = csv_data.columns.tolist()

    # get index of column name sap_id
    sap_id_index = column_names.index("sap_id")

    # get index of column name br_code
    # br_code_index = column_names.index("br_code")

    tuple_list = []
    # create  list of tuples of form (br_code, sap_id)
    # for index, row in csv_data.iterrows():
    #     tuple_list.append((row[br_code_index], row[sap_id_index]))
    for index, row in csv_data.iterrows():
        tuple_list.append(row[sap_id_index])
    # breakpoint()

    region_conditions = []
    if region_type == "Zone":
        region_conditions.append(AssortmentOutput.zone == region_name)
    elif region_type == "State":
        region_conditions.append(AssortmentOutput.state == region_name)
    elif region_type == "City":
        region_conditions.append(AssortmentOutput.city == region_name)
    elif region_type == "Branch":
        region_conditions.append(AssortmentOutput.br_code == region_name)

    br_sap_conditions = [
        AssortmentOutput.sap_id == int(sap_id) for sap_id in tuple_list
    ]
    # breakpoint()

    query = select(
        # AssortmentOutput.br_code,
        AssortmentOutput.sap_id,
        AssortmentOutput.item_name,
        # AssortmentOutput.total_amount,
        func.sum(AssortmentOutput.total_amount).label(
            "total_amount"
        ),  # Actual past sales
        func.sum(AssortmentOutput.total_margin).label(
            "total_margin"
        ),  # Actual past margin
        func.sum(AssortmentOutput.num_qty_sold).label("num_qty_sold"),
        func.sum(AssortmentOutput.total_amount_train).label("total_amount_train"),
        func.sum(AssortmentOutput.total_margin_train).label("total_margin_train"),
        func.sum(AssortmentOutput.num_qty_sold_train).label("num_qty_sold_train"),
        # AssortmentOutput.total_margin,    # Actual past margin
        # AssortmentOutput.num_qty_sold ,
        # AssortmentOutput.total_amount_train,
        # AssortmentOutput.total_margin_train,
        # AssortmentOutput.exist_in_model_output,
        # AssortmentOutput.is_sold,
    )
    query = query.group_by(
        AssortmentOutput.sap_id,
        AssortmentOutput.item_name,
    )
    if br_sap_conditions:
        query = query.filter(or_(*br_sap_conditions))

    if region_conditions:
        query = query.where(or_(*region_conditions))

    rows = await postgres_db.fetch_all(query)
    return rows
