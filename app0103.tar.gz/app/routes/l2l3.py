from fastapi import APIRouter, Form, Depends, UploadFile, File
from ..models import AssortmentOutput
from sqlalchemy import and_, select, func, distinct
from .common import get_postgres_db
import json
from app.db import redis_db
import pandas as pd
from typing import Optional



L2L3 = APIRouter(prefix="/couture/assortment", tags=["L2L3"])



@L2L3.post("/l2l3", operation_id="fetch-l2l3")  
async def fetch_l2l3(
    request_csv: Optional[UploadFile] = File(None),
    region_type: str = Form(None),
    region_name: str = Form(None),
    postgres_db = Depends(get_postgres_db),
):

    condition = [] 
    if region_type == "Zone" and region_name is not None:
        condition.append(AssortmentOutput.zone == region_name)
    elif region_type == "State" and region_name is not None:
        condition.append(AssortmentOutput.state == region_name)
    elif region_type == "City" and region_name is not None:
        condition.append(AssortmentOutput.city == region_name)
    elif region_type == "Branch" and region_name is not None:
        condition.append(AssortmentOutput.br_code == region_name)

    if request_csv is not None:
        request_df = pd.read_csv(request_csv.file)
        if not request_df.empty:
            sap_ids = request_df.sap_id.tolist()
            condition.append(AssortmentOutput.sap_id.in_(sap_ids))
            br_codes = request_df.br_code.tolist()
            condition.append(AssortmentOutput.br_code.in_(br_codes))
    else:   
        cache_key = f"l2l3:{region_type}:{region_name}"
        response = await redis_db.get(cache_key)
        if response:
            print('l2l3', cache_key)
            result = json.loads(response)
            return result

   
    l2_assort_comp_query = (
        select(
            AssortmentOutput.L2.label("L2"),
            func.count(distinct(AssortmentOutput.sap_id)).label("COUNT_DISTINCT(sap_id)")
        )
        .where(
            and_(*condition, AssortmentOutput.exist_in_model_output == 1)
        )
        .group_by(AssortmentOutput.L2)
        .order_by(func.count(distinct(AssortmentOutput.sap_id)).desc())
        .limit(10)
    )

    l2_assort_comp = await postgres_db.fetch_all(l2_assort_comp_query)

    l2_assort_dist_miss_query = (
        select(
            AssortmentOutput.L2.label("L2"),
            func.count(distinct(AssortmentOutput.sap_id)).label("COUNT_DISTINCT(sap_id)")
        )
        .where(
            and_(*condition, AssortmentOutput.exist_in_model_output == 0, AssortmentOutput.is_sold == 1)
        )
        .group_by(AssortmentOutput.L2)
        .order_by(func.count(distinct(AssortmentOutput.sap_id)).desc())
        .limit(10)
    )

    l2_assort_dist_miss = await postgres_db.fetch_all(l2_assort_dist_miss_query)


    l3_assort_comp_query = (
        select(
            AssortmentOutput.L3.label("L3"),
            func.count(distinct(AssortmentOutput.sap_id)).label("COUNT_DISTINCT(sap_id)")
        )
        .where(
            and_(*condition, AssortmentOutput.exist_in_model_output == 1)
        )
        .group_by(AssortmentOutput.L3)
        .order_by(func.count(distinct(AssortmentOutput.sap_id)).desc())
        .limit(10)
    )

    l3_assort_comp = await postgres_db.fetch_all(l3_assort_comp_query)


    l3_assort_dist_miss_query = (
        select(
            AssortmentOutput.L3.label("L3"),
            func.count(distinct(AssortmentOutput.sap_id)).label("COUNT_DISTINCT(sap_id)")
        )
        .where(
            and_(*condition, AssortmentOutput.exist_in_model_output == 0, AssortmentOutput.is_sold == 1)
        )
        .group_by(AssortmentOutput.L3)
        .order_by(func.count(distinct(AssortmentOutput.sap_id)).desc())
        .limit(10)
    )

    l3_assort_dist_miss = await postgres_db.fetch_all(l3_assort_dist_miss_query)

    # Convert the query results to a list of dictionaries
    result = {
        'l2_assort_comp': [dict(row) for row in l2_assort_comp],
        'l2_assort_dist_miss': [dict(row) for row in l2_assort_dist_miss],
        'l3_assort_comp': [dict(row) for row in l3_assort_comp],
        'l3_assort_dist_miss': [dict(row) for row in l3_assort_dist_miss]
    }
    
    if request_csv is None:
        serialized_data = json.dumps(result)
        await redis_db.set(cache_key, serialized_data)

    return result

