from fastapi import APIRouter, Depends
from collections import defaultdict
import asyncio
import json
from sqlalchemy import select, func, and_, cast, Numeric
from models import (
    TrendsBestSellers,
    TrendsBrickDetails,
    TrendsProductAttributes,
    TrendsStoreDetails,
    Calenderyearmonthweekinfo
)
from utils import (
    indian_states,
    month_mapping,
    sort_response_using_cache,
    build_filter_condition,
    get_attributes_bestsellers_trends,
    create_filter_query,
    create_trends_filter_query,
    sort_and_paginate,
)
from db import redis_db, psql_execute_single, psql_execute_multiple, check_in_redis
from static import REDIS_WRITE_ERROR, REDIS_CONNECT_ERROR


async def load_trends_filters_cache():

    
    cache_key = "trends_filters_cache"
    cached_data = await check_in_redis(cache_key)

    if not cached_data:
        
        request_data = {}
        query = await create_trends_filter_query(request_data)

        query_list = await asyncio.gather(
            create_filter_query(query, "month_of_year"),
            create_filter_query(query, "quarter_of_year"),
            create_filter_query(query, "zone_desc"),
            create_filter_query(query, "state"),
            create_filter_query(query, "city"),
            create_filter_query(query, "districtsname"),
            create_filter_query(query, "pin_code"),
            create_filter_query(query, "store_id"),
            create_filter_query(query, "mh_family_desc"),
            create_filter_query(query, "mh_class_desc"),
            create_filter_query(query, "brickname"),
            create_filter_query(query, "styletype"),
            create_filter_query(query, "neckline"),
            create_filter_query(query, "pattern"),
            create_filter_query(query, "fabrictype"),
            create_filter_query(query, "sleeve"),
            create_filter_query(query, "fit"),
            create_filter_query(query, "primarycolor"),
            create_filter_query(query, "brandname"),
        )

        result = await psql_execute_multiple(query_list)

        response = defaultdict(dict)

        response["demographic"] = {
            "zone": [val[0] for val in result[2] if val[0] != "nan"],
            "state": [val[0] for val in result[3] if val[0] != "nan"],
            "city": [val[0] for val in result[4] if val[0] != "nan"],
            "district": [val[0] for val in result[5] if val[0] != "nan"],
        }
        response["category"] = {
            "category_family": [val[0] for val in result[8] if val[0] != "nan"],
            "category_class": [val[0] for val in result[9] if val[0] != "nan"],
            "category": [val[0] for val in result[10] if val[0] != "nan"],
        }
        response["attributes"] = {
            "styletype": [val[0] for val in result[11] if val[0] != "nan"],
            "neckline": [val[0] for val in result[12] if val[0] != "nan"],
            "pattern": [val[0] for val in result[13] if val[0] != "nan"],
            "fabric_type": [val[0] for val in result[14] if val[0] != "nan"],
            "sleeve": [val[0] for val in result[15] if val[0] != "nan"],
            "fit": [val[0] for val in result[16] if val[0] != "nan"],
            "color": [val[0] for val in result[17] if val[0] != "nan"],
            "brand": [val[0] for val in result[18] if val[0] != "nan"],
        }
        response["store_filters"] = {
            "pincode": [val[0] for val in result[6] if val[0] != "nan"],
            "store_id": [val[0] for val in result[7] if val[0] != "nan"],
        }
        response["duration"] = {
            "month": [month_mapping[val[0]] for val in result[0] if val[0] != "nan"],
            "quarter": [str(val[0]) for val in result[1] if val[0] != "nan"],
        }

        try:
            await redis_db.set(cache_key, json.dumps(response, default=str))
        except Exception as e:
            print(REDIS_WRITE_ERROR, e)

    print("Trends-filters-cache loaded")



TrendsRouter = APIRouter(
    prefix="/couture/fast-fashion",
    tags=["Trends"],
    responses={404: {"description": "Not found"}},
)


@TrendsRouter.post("/trends-filters-structure")
async def get_filters_structure(request_data: dict):

    cache_key = "trends_filters_cache"
    cached_data = await check_in_redis(cache_key)
    if cached_data:
        return json.loads(cached_data)
    else:
        await load_trends_filters_cache()
        cached_data = await check_in_redis(cache_key)
        return json.loads(cached_data)




@TrendsRouter.post("/trends-filters")
async def get_trends_filters(request_data: dict):

    initial_filter_flag = request_data.get("initial_filter_flag")

    if initial_filter_flag == 'true':
        cache_key = "trends_filters_cache"
        cached_data = await check_in_redis(cache_key)
        if cached_data:
            return json.loads(cached_data)
        return cached_data

    cache_key = f"trends_filters{json.dumps(request_data)}"
    cached_data = await check_in_redis(cache_key)

    if cached_data:
        return json.loads(cached_data)

    query = await create_trends_filter_query(request_data)

    result = (await psql_execute_single(query))

    response = {
        "demographic": {
            "zone": list(set([val[2] for val in result if val[2] != "nan"])),
            "state": list(set([val[3] for val in result if val[3] != "nan"])),
            "city": list(set([val[4] for val in result if val[4] != "nan"])),
            "district": list(set([val[5] for val in result if val[5] != "nan"])),
        },
        "category": {
            "category_family": list(set([val[8] for val in result if val[8] != "nan"])),
            "category_class": list(set([val[9] for val in result if val[9] != "nan"])),
            "category": list(set([val[10] for val in result if val[10] != "nan"])),
        },
        "attributes": {
            "styletype": list(set([val[11] for val in result if val[11] != "nan"])),
            "neckline": list(set([val[12] for val in result if val[12] != "nan"])),
            "pattern": list(set([val[13] for val in result if val[13] != "nan"])),
            "fabric_type": list(set([val[14] for val in result if val[14] != "nan"])),
            "sleeve": list(set([val[15] for val in result if val[15] != "nan"])),
            "fit": list(set([val[16] for val in result if val[16] != "nan"])),
            "color": list(set([val[17] for val in result if val[17] != "nan"])),
            "brand": list(set([val[18] for val in result if val[18] != "nan"])),
        },
        "store_filters": {
            "pincode": list(set([val[6] for val in result if val[6] != "nan"])),
            "store_id": list(set([val[7] for val in result if val[7] != "nan"])),
        },
        "duration": {
            "month": list(
                set([month_mapping[val[0]] for val in result if val[0] != "nan"])
            ),
            "quarter": list(set([str(val[1]) for val in result if val[1] != "nan"])),
        },
    }

    cache_response = await check_in_redis("trends_filters_cache")
    if cache_response:
        cache_response = json.loads(cache_response)
    else:
        cache_response = defaultdict(dict)

    # Sort the response using the cache_response
    response = await sort_response_using_cache(response, cache_response)

    try:
        await redis_db.set(cache_key, json.dumps(response, default=str))
    except Exception as e:
        print(REDIS_WRITE_ERROR, e)

    return response


@TrendsRouter.post("/bestsellers-products-trends")
async def bestsellers_products_trends(
    request_data: dict,
):
    
    cache_key = f"bestsellers-products-trends-{json.dumps(request_data)}"
    try:
        cached_data = await check_in_redis(cache_key)
    except Exception as e:
        print(REDIS_CONNECT_ERROR, e)
        cached_data = None 
    if cached_data:
        return json.loads(cached_data)

    (
        bestseller_filter,
        product_filter,
        store_filter,
        brick_filter,
        calender_filter
    ) = await asyncio.gather(
        build_filter_condition(
            type="trends", request_filters=request_data, filter_flag="bestsellers"
        ),
        build_filter_condition(
            type="trends", request_filters=request_data, filter_flag="products"
        ),
        build_filter_condition(
            type="trends", request_filters=request_data, filter_flag="store_filters"
        ),
        build_filter_condition(
            type="trends", request_filters=request_data, filter_flag="category"
        ),
        build_filter_condition(
            type="calender", request_filters=request_data, filter_flag="calender"
        ),
    )

    bestseller_query = (
        select(
            TrendsBestSellers.itemid,
            TrendsBestSellers.week_of_year,
            TrendsBestSellers.year,
            TrendsBestSellers.store_id,
            TrendsBestSellers.sold_quantity_in_a_week,
        )
        .where(and_(*bestseller_filter))
        .subquery()
    )

    store_query = (
        select(
            TrendsStoreDetails.store_id,
        )
        .where(and_(*store_filter))
        .subquery()
    )

    calender_query = (
        select(
            Calenderyearmonthweekinfo.week_of_year,
            Calenderyearmonthweekinfo.year,
            func.sum(Calenderyearmonthweekinfo.num_days_in_week).label("total_days_count_across_week"),
        ).where(
            and_(*calender_filter)
        ).group_by(
            Calenderyearmonthweekinfo.week_of_year, Calenderyearmonthweekinfo.year
        ).subquery()
    )

    ros_query = (
        select(
            bestseller_query.c.itemid,
            bestseller_query.c.week_of_year,
            bestseller_query.c.year,
            func.sum(bestseller_query.c.sold_quantity_in_a_week).label("sold_quantity_across_each_week"),
        ).join(
            store_query, 
            store_query.c.store_id == bestseller_query.c.store_id
        ).group_by(
            bestseller_query.c.itemid,
            bestseller_query.c.week_of_year,
            bestseller_query.c.year
        ).subquery()
    )

    # join ros and calender query
    ros_query = (
        select(
            ros_query.c.itemid,
            ros_query.c.year,
            ros_query.c.sold_quantity_across_each_week,
            calender_query.c.total_days_count_across_week,
        ).join(
            calender_query,
            and_(
                calender_query.c.week_of_year == ros_query.c.week_of_year,
                calender_query.c.year == ros_query.c.year
            )
        ).subquery()
    )

    ros_query = select(
        ros_query.c.itemid,
        ros_query.c.year,
        func.sum(ros_query.c.sold_quantity_across_each_week).label("total_sold_quantity"),
        func.round(cast(((func.sum(ros_query.c.sold_quantity_across_each_week)/func.sum(ros_query.c.total_days_count_across_week))*7), Numeric), 2).label("weekly_rate_of_sale"),
    ).group_by(
        ros_query.c.itemid,
        ros_query.c.year
    ).subquery()


    product_query = (
        select(
            TrendsProductAttributes.itemid,
            TrendsProductAttributes.brandname,
            TrendsProductAttributes.styletype,
            TrendsProductAttributes.primarycolor,
            TrendsProductAttributes.pattern,
            TrendsProductAttributes.fabrictype,
            TrendsProductAttributes.materialtype,
            TrendsProductAttributes.sleeve,
            TrendsProductAttributes.fit,
            TrendsProductAttributes.neckline,
            TrendsProductAttributes.imgcode,
            TrendsProductAttributes.extension,
            TrendsProductAttributes.mrp,
            TrendsProductAttributes.similargrouplevel,
        )
        .where(and_(*product_filter))
        .subquery()
    )

    brick_query = (
        select(
            TrendsBrickDetails.mh_family_desc,
            TrendsBrickDetails.mh_class_desc,
            TrendsBrickDetails.brickname,
            TrendsBrickDetails.similargrouplevel,
        )
        .where(and_(*brick_filter))
        .subquery()
    )

    query = (
        select(
            product_query.c.itemid,
            product_query.c.brandname,
            product_query.c.styletype,
            product_query.c.primarycolor,
            product_query.c.pattern,
            product_query.c.fabrictype,
            product_query.c.materialtype,
            product_query.c.sleeve,
            product_query.c.fit,
            product_query.c.neckline,
            product_query.c.imgcode,
            product_query.c.extension,
            brick_query.c.mh_family_desc,
            brick_query.c.mh_class_desc,
            brick_query.c.brickname,
            product_query.c.mrp,
            ros_query.c.total_sold_quantity,
            ros_query.c.weekly_rate_of_sale,
        )
        .join(ros_query, ros_query.c.itemid == product_query.c.itemid)
        .join(
            brick_query,
            brick_query.c.similargrouplevel == product_query.c.similargrouplevel,
        )
    )
    # count the total number of rows
    total_count_query = select(func.count()).select_from(query)
    bestseller_query = await sort_and_paginate(
        query, request_data, "weekly_rate_of_sale"
    )

    query_list = [bestseller_query, total_count_query]

    result = await psql_execute_multiple(query_list)
    result = {
        "total_count": result[1][0][0],
        "rows": [
            {
                "itemid": row[0],
                "brandname": row[1],
                "styletype": row[2],
                "primarycolor": row[3],
                "pattern": row[4],
                "fabrictype": row[5],
                "materialtype": row[6],
                "sleeve": row[7],
                "fit": row[8],
                "neckline": row[9],
                "imgcode": row[10],
                "extension": row[11],
                "mh_family_desc": row[12],
                "mh_class_desc": row[13],
                "brickname": row[14],
                "mrp": float(row[15]),
                "total_qty": float(row[16]),
                "weekly_rate_of_sale": float(row[17]),
            }
            for row in result[0]
        ],
    }


    try:
        await redis_db.set(cache_key, json.dumps(result, default=str))
    except Exception as e:
        print(REDIS_WRITE_ERROR, e)

    return result


@TrendsRouter.post("/statewise-sales-trends")
async def get_statewise_sales(request_data: dict,):
    cache_key = f"statewise-sales-{json.dumps(request_data)}"
    try:
        cached_data = await check_in_redis(cache_key)
    except Exception as e:
        print(REDIS_CONNECT_ERROR, e)
        cached_data = None 
    if cached_data:
        return json.loads(cached_data)

    sold_in_week_query = (
        select(
            TrendsStoreDetails.state,
            func.sum(TrendsBestSellers.sold_quantity_in_a_week).label("quantity"),
        )
        .join(
            TrendsBestSellers, TrendsStoreDetails.store_id == TrendsBestSellers.store_id
        )
        .group_by(TrendsStoreDetails.state)
    )

    maps_rows_state = (await psql_execute_single(sold_in_week_query))
    map_data = [
        {
            "state": row[0],
            "statecode": indian_states.get(row[0].lower(), {}).get(
                "statecode", "Not Found"
            ),
            "quantity_sold": float(row[1]),
        }
        for row in maps_rows_state
    ]

    try:
        await redis_db.set(cache_key, json.dumps(map_data, default=str))
    except Exception as e:
        print(REDIS_WRITE_ERROR, e)

    return map_data


@TrendsRouter.post("/fabric-bestsellers-trends")
async def get_fabric_bestsellers_trends(
    request_data: dict,
):
    cache_key = f"fabric-bestsellers-trends-{json.dumps(request_data)}"
    try:
        cached_data = await check_in_redis(cache_key)
    except Exception as e:
        print(REDIS_CONNECT_ERROR, e)
        cached_data = None 
    if cached_data:
        return json.loads(cached_data)

    result = await get_attributes_bestsellers_trends(
        request_data, "fabrictype",
    )

    try:
        await redis_db.set(cache_key, json.dumps(result, default=str))
    except Exception as e:
        print(REDIS_WRITE_ERROR, e)

    return result


@TrendsRouter.post("/brandnames-bestsellers-trends")
async def brandnames_bestsellers_trends(
    request_data: dict,
):
    cache_key = f"brandnames-bestsellers-trends-{json.dumps(request_data)}"
    try:
        cached_data = await check_in_redis(cache_key)
    except Exception as e:
        print(REDIS_CONNECT_ERROR, e)
        cached_data = None 
    if cached_data:
        return json.loads(cached_data)

    result = await get_attributes_bestsellers_trends(
        request_data, "brandname",
    )

    try:
        await redis_db.set(cache_key, json.dumps(result, default=str))
    except Exception as e:
        print(REDIS_WRITE_ERROR, e)

    return result


@TrendsRouter.post("/neckline-bestsellers-trends")
async def neckline_bestsellers_trends(
    request_data: dict,
):
    cache_key = f"neckline-bestsellers-trends-{json.dumps(request_data)}"
    try:
        cached_data = await check_in_redis(cache_key)
    except Exception as e:
        print(REDIS_CONNECT_ERROR, e)
        cached_data = None 
    if cached_data:
        return json.loads(cached_data)

    result = await get_attributes_bestsellers_trends(
        request_data, "neckline",
    )

    try:
        await redis_db.set(cache_key, json.dumps(result, default=str))
    except Exception as e:
        print(REDIS_WRITE_ERROR, e)

    return result


@TrendsRouter.post("/styletype-bestsellers-trends")
async def styletype_bestsellers_trends(
    request_data: dict,
):
    cache_key = f"styletype-bestsellers-trends-{json.dumps(request_data)}"
    try:
        cached_data = await check_in_redis(cache_key)
    except Exception as e:
        print(REDIS_CONNECT_ERROR, e)
        cached_data = None 
    if cached_data:
        return json.loads(cached_data)

    result = await get_attributes_bestsellers_trends(
        request_data, "styletype",
    )

    try:
        await redis_db.set(cache_key, json.dumps(result, default=str))
    except Exception as e:
        print(REDIS_WRITE_ERROR, e)

    return result


@TrendsRouter.post("/sleevelength-bestsellers-trends")
async def sleevelength_bestsellers_trends(
    request_data: dict,
):
    cache_key = f"sleevelength-bestsellers-trends-{json.dumps(request_data)}"
    try:
        cached_data = await check_in_redis(cache_key)
    except Exception as e:
        print(REDIS_CONNECT_ERROR, e)
        cached_data = None 
    if cached_data:
        return json.loads(cached_data)

    result = await get_attributes_bestsellers_trends(
        request_data, "sleeve",
    )

    try:
        await redis_db.set(cache_key, json.dumps(result, default=str))
    except Exception as e:
        print(REDIS_WRITE_ERROR, e)

    return result


@TrendsRouter.post("/pattern-bestsellers-trends")
async def pattern_bestsellers_trends(
    request_data: dict,
):
    cache_key = f"pattern-bestsellers-trends-{json.dumps(request_data)}"
    try:
        cached_data = await check_in_redis(cache_key)
    except Exception as e:
        print(REDIS_CONNECT_ERROR, e)
        cached_data = None 
    if cached_data:
        return json.loads(cached_data)

    result = await get_attributes_bestsellers_trends(
        request_data, "pattern",
    )

    try:
        await redis_db.set(cache_key, json.dumps(result, default=str))
    except Exception as e:
        print(REDIS_WRITE_ERROR, e)

    return result


@TrendsRouter.post("/color-bestsellers-trends")
async def color_bestsellers_trends(
    request_data: dict,
):
    cache_key = f"color-bestsellers-trends-{json.dumps(request_data)}"
    cached_data = await check_in_redis(cache_key)
    try:
        cached_data = await check_in_redis(cache_key)
    except Exception as e:
        print(REDIS_CONNECT_ERROR, e)
        cached_data = None 
    if cached_data:
        return json.loads(cached_data)

    result = await get_attributes_bestsellers_trends(
        request_data, "primarycolor",
    )

    try:
        await redis_db.set(cache_key, json.dumps(result, default=str))
    except Exception as e:
        print(REDIS_WRITE_ERROR, e)

    return result
