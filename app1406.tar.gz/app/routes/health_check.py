from fastapi import APIRouter

HealthCheckRouter = APIRouter(
    prefix="/couture/fast-fashion",
    tags=["HealthCheck"],
    responses={404: {"description": "Not found"}},
)


@HealthCheckRouter.get("/_healthz")
async def healthz():
    return {"success": True}


@HealthCheckRouter.get("/_readyz")
async def readyz():
    return {"success": True}
