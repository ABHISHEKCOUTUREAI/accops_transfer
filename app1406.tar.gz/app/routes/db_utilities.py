from fastapi import APIRouter, Depends
from models import (
    AjioBestSellers,
    AjioBrickDetails,
    AjioDemographicDetails,
    AjioProductAttributes,
    AjioSearchQueriesTopInteractedProducts,
    TrendsBestSellers,
    TrendsBrickDetails,
    TrendsProductAttributes,
    TrendsStoreDetails,
    SearchInteractions,
    Calenderyearmonthweekinfo,
)
from utils import insert_into_db, load_google_search_interactions
from db import set_redis_state, flush_redis_key, psql_session, psql_execute_single
from static import (
    AJIO_BESTSELLERS_CSV,
    AJIO_BRICK_DETAILS_CSV,
    AJIO_DEMOGRAPHIC_DETAILS_CSV,
    AJIO_PRODUCT_ATTRIBUTES_CSV,
    AJIO_SEARCH_QUERIES_TOP_INTERACTED_PRODUCTS_CSV,
    TRENDS_BESTSELLERS_CSV,
    TRENDS_BRICK_DETAILS_CSV,
    TRENDS_PRODUCT_ATTRIBUTES_CSV,
    TRENDS_STORE_DETAILS_CSV,
    CALENDER_DATA_CSV,
    combined_search_terms_weeks
)
from sqlalchemy import text



DBRouter = APIRouter(
    prefix="/couture/fast-fashion",
    tags=["DB Utils"],
    responses={404: {"description": "Not found"}},
)

data_upload_table_mapping = {
        "ajio_bestsellers": (AjioBestSellers, AJIO_BESTSELLERS_CSV),
        "ajio_brick_details": (AjioBrickDetails, AJIO_BRICK_DETAILS_CSV),
        "ajio_demographic_details": (AjioDemographicDetails, AJIO_DEMOGRAPHIC_DETAILS_CSV),
        "ajio_product_attributes": (AjioProductAttributes, AJIO_PRODUCT_ATTRIBUTES_CSV),
        "ajio_search_queries_top_interacted_products": (AjioSearchQueriesTopInteractedProducts, AJIO_SEARCH_QUERIES_TOP_INTERACTED_PRODUCTS_CSV),
        "trends_bestsellers": (TrendsBestSellers, TRENDS_BESTSELLERS_CSV),
        "trends_brick_details": (TrendsBrickDetails, TRENDS_BRICK_DETAILS_CSV),
        "trends_product_attributes": (TrendsProductAttributes, TRENDS_PRODUCT_ATTRIBUTES_CSV),
        "trends_store_details": (TrendsStoreDetails, TRENDS_STORE_DETAILS_CSV),
        "calender_data": (Calenderyearmonthweekinfo, CALENDER_DATA_CSV),
        "search_interactions": (SearchInteractions, None),
        "all": [
            (AjioBestSellers, AJIO_BESTSELLERS_CSV),
            (AjioBrickDetails, AJIO_BRICK_DETAILS_CSV),
            (AjioDemographicDetails, AJIO_DEMOGRAPHIC_DETAILS_CSV),
            (AjioProductAttributes, AJIO_PRODUCT_ATTRIBUTES_CSV),
            (AjioSearchQueriesTopInteractedProducts, AJIO_SEARCH_QUERIES_TOP_INTERACTED_PRODUCTS_CSV),
            (TrendsBestSellers, TRENDS_BESTSELLERS_CSV),
            (TrendsBrickDetails, TRENDS_BRICK_DETAILS_CSV),
            (TrendsProductAttributes, TRENDS_PRODUCT_ATTRIBUTES_CSV),
            (TrendsStoreDetails, TRENDS_STORE_DETAILS_CSV),
            (Calenderyearmonthweekinfo, CALENDER_DATA_CSV),
        ],
    }


def process_table(table, postgres_db, gcs_bucket_name, gcs_file_name):
    return insert_into_db(
        table[0],
        table[1],
        postgres_db,
        gcs_bucket_name=gcs_bucket_name,
        gcs_file_name=gcs_file_name,
    )



async def process_all_tables(postgres_db, gcs_bucket_name):
    tasks = []
    for table in data_upload_table_mapping["all"]:
        tasks.append(
            process_table(
                table,
                postgres_db,
                gcs_bucket_name,
                table[1],
            )
        )
    for task in tasks:
        result = await task
        if result.status_code != 200:
            return result
    return {"message": "All tables loaded successfully"}


@DBRouter.get("/update-db")
async def update_db(
    table_name: str,
    gcs_bucket_name: str = None,
    gcs_file_name: str = None,
    postgres_db=Depends(psql_session),
):
    if table_name in data_upload_table_mapping:
        if table_name == "search_interactions":
            return await load_google_search_interactions(data_upload_table_mapping[table_name][0], postgres_db)
        elif table_name == "all":
            return await process_all_tables(postgres_db, gcs_bucket_name)
        else:
            return await process_table(
                data_upload_table_mapping[table_name],
                postgres_db,
                gcs_bucket_name,
                data_upload_table_mapping[table_name][1],
            )
    else:
        return {"message": "Invalid table name"}



@DBRouter.get("/flush-redis")
async def flush_redis(key_prefix: str):
    if key_prefix == "all":
        await set_redis_state(flush_db=True)
        return {"message": "Redis flushed successfully"}
    else:
        await flush_redis_key(key_prefix)
        return {
            "message": f"Redis keys starting with {key_prefix} flushed successfully"
        }



@DBRouter.get("/create-view")
async def create_view(
    view_name: str,
    postgres_db=Depends(psql_session),
):
    try:
        # Drop the view if it already exists
        drop_query = text(f"DROP MATERIALIZED VIEW IF EXISTS {view_name} CASCADE;")
        await postgres_db.execute(drop_query)
        print(f"View '{view_name}' dropped successfully")
 
        # Create the view
        await postgres_db.execute(combined_search_terms_weeks)
        return {"message": f"View '{view_name}' created successfully"}
    
    except Exception as e:
        return {"message": f"View {view_name} creation failed: {str(e)}"}