from fastapi import APIRouter
import json
import asyncio
from collections import defaultdict
from sqlalchemy import select, func, and_, cast, Numeric
from models import (
    AjioBestSellers,
    AjioProductAttributes,
    AjioDemographicDetails,
    AjioBrickDetails,
    Calenderyearmonthweekinfo
)
from db import redis_db, psql_execute_single, psql_execute_multiple, check_in_redis
from utils import (
    month_mapping,
    indian_states,
    create_ajio_filters_query,
    get_attributes_bestsellers_ajio,
    sort_response_using_cache,
    create_filter_query,
    build_filter_condition,
    sort_and_paginate,
)
from static import REDIS_WRITE_ERROR, REDIS_CONNECT_ERROR
from datetime import datetime
AjioRouter = APIRouter(
    prefix="/couture/fast-fashion",
    tags=["Ajio"],
    responses={404: {"description": "Not found"}},
)

async def load_ajio_cached_filters():
    cache_key = "ajio_filters_cache"
    cached_data = await check_in_redis(cache_key)
    if not  cached_data:

        request_data = {}
        query = await create_ajio_filters_query(request_data)

        # crate a list and push all queries there
        query_list = await asyncio.gather(
            create_filter_query(query, parameter="zone"),
            create_filter_query(query, parameter="state"),
            create_filter_query(query, parameter="city"),
            create_filter_query(query, parameter="districtsname"),
            create_filter_query(query, parameter="l1name"),
            create_filter_query(query, parameter="l2name"),
            create_filter_query(query, parameter="brickname"),
            create_filter_query(query, parameter="styletype"),
            create_filter_query(query, parameter="neckline"),
            create_filter_query(query, parameter="pattern"),
            create_filter_query(query, parameter="fabrictype"),
            create_filter_query(query, parameter="sleevelength"),
            create_filter_query(query, parameter="fit"),
            create_filter_query(query, parameter="colorfamily"),
            create_filter_query(query, parameter="brandname"),
            create_filter_query(query, parameter="occasion"),
            create_filter_query(query, parameter="bodytype"),
            create_filter_query(query, parameter="materialtype"),
            create_filter_query(query, parameter="distress"),
            create_filter_query(query, parameter="traditionalweave"),
            create_filter_query(query, parameter="hemline"),
            create_filter_query(query, parameter="month_of_year"),
            create_filter_query(query, parameter="quarter_of_year"),
        )

        result = await psql_execute_multiple(query_list)

        response_data = defaultdict(dict)
        response_data["demographic"] = {
            "zone": [val[0] for val in result[0] if val[0] != "nan"],
            "state": [val[0] for val in result[1] if val[0] != "nan"],
            "city": [val[0] for val in result[2] if val[0] != "nan"],
            "district": [val[0] for val in result[3] if val[0] != "nan"],
        }
        response_data["brick_filters"] = {
            "l1_name": [val[0] for val in result[4] if val[0] != "nan"],
            "l2_name": [val[0] for val in result[5] if val[0] != "nan"],
            "brick_name": [val[0] for val in result[6] if val[0] != "nan"],
        }
        response_data["attributes"] = {
            "styletype": [val[0] for val in result[7] if val[0] != "nan"],
            "neckline": [val[0] for val in result[8] if val[0] != "nan"],
            "pattern": [val[0] for val in result[9] if val[0] != "nan"],
            "fabrictype": [val[0] for val in result[10] if val[0] != "nan"],
            "sleeve": [val[0] for val in result[11] if val[0] != "nan"],
            "fit": [val[0] for val in result[12] if val[0] != "nan"],
            "color": [val[0] for val in result[13] if val[0] != "nan"],
            "brandname": [val[0] for val in result[14] if val[0] != "nan"],
            "occasion": [val[0] for val in result[15] if val[0] != "nan"],
            "bodytype": [val[0] for val in result[16] if val[0] != "nan"],
            "materialtype": [val[0] for val in result[17] if val[0] != "nan"],
            "distress": [val[0] for val in result[18] if val[0] != "nan"],
            "traditionalweave": [val[0] for val in result[19] if val[0] != "nan"],
            "hemline": [val[0] for val in result[20] if val[0] != "nan"],
        }
        response_data["duration"] = {
            "month": [month_mapping[val[0]] for val in result[21] if val[0] != "nan"],
            "quarter": [str(val[0]) for val in result[22] if val[0] != "nan"],
        }

        try:
            await redis_db.set(cache_key, json.dumps(response_data, default=str))
        except Exception as e:
            print(REDIS_WRITE_ERROR, e)

    print("Ajio-filter-cache loaded ")



@AjioRouter.post("/ajio-filters-structure")
async def get_filters_structure(request_data: dict):


        cache_key = "ajio_filters_cache"
        cached_data = await check_in_redis(cache_key)
        if cached_data:
            return json.loads(cached_data)
        else:
            await load_ajio_cached_filters()
            cached_data = await check_in_redis(cache_key)
            return json.loads(cached_data)




@AjioRouter.post("/ajio-filters")
async def get_ajio_filters(
    request_data: dict,
    api_contract_flag: bool = False,
):
   
    cache_key = f"ajio_filters{json.dumps(request_data)}"
    cached_data = await check_in_redis(cache_key)
    if cached_data:
        return json.loads(cached_data)
    
    time1 = datetime.now()
    query = await create_ajio_filters_query(request_data)

    time2 = datetime.now()
    print(f"Time: {time2} - Query created in {time2-time1}")

    if api_contract_flag:
        return query
    

    result = (await psql_execute_single(query))

    time3 = datetime.now()
    print(f"Time: {time3} - Query executed in {time3-time2}")

    response = {
        "demographic": {
            "zone": list(set([val[2] for val in result if val[2] != "nan" and val[2] is not None])),
            "state": list(set([val[3] for val in result if val[3] != "nan" and val[3] is not None])),
            "city": list(set([val[4] for val in result if val[4] != "nan" and val[4] is not None])),
            "district": list(set([val[5] for val in result if val[5] != "nan" and val[5] is not None])),
        },
        "brick_filters": {
            "l1_name": list(set([val[6] for val in result if val[6] != "nan" and val[6] is not None])),
            "l2_name": list(set([val[7] for val in result if val[7] != "nan" and val[7] is not None])),
            "brick_name": list(set([val[8] for val in result if val[8] != "nan" and val[8] is not None])),
        },
        "attributes": {
            "styletype": list(set([val[9] for val in result if val[9] != "nan" and val[9] is not None])),
            "neckline": list(set([val[10] for val in result if val[10] != "nan" and val[10] is not None])),
            "pattern": list(set([val[11] for val in result if val[11] != "nan" and val[11] is not None])),
            "fabrictype": list(set([val[12] for val in result if val[12] != "nan" and val[12] is not None])),
            "sleeve": list(set([val[13] for val in result if val[13] != "nan" and val[13] is not None])),
            "fit": list(set([val[14] for val in result if val[14] != "nan" and val[14] is not None])),
            "color": list(set([val[15] for val in result if val[15] != "nan" and val[15] is not None])),
            "brandname": list(set([val[16] for val in result if val[16] != "nan" and val[16] is not None])),
            "occasion": list(set([val[17] for val in result if val[17] != "nan" and val[17] is not None])),
            "bodytype": list(set([val[18] for val in result if val[18] != "nan" and val[18] is not None])),
            "materialtype": list(set([val[19] for val in result if val[19] != "nan" and val[19] is not None])),
            "distress": list(set([val[20] for val in result if val[20] != "nan" and val[20] is not None])),
            "traditionalweave": list(
                set([val[21] for val in result if val[21] != "nan" and val[21] is not None])
            ),
            "hemline": list(set([val[22] for val in result if val[22] != "nan" and val[22] is not None])),
        },
        "duration": {
            "month": list(
                set([month_mapping[val[0]] for val in result if val[0] != "nan" and val[0] is not None])
            ),
            "quarter": list(set([str(val[1]) for val in result if val[1] != "nan" and val[1] is not None])),
        },
    }

    time4 = datetime.now()
    print(f"Time: {time4} - Response created in {time4-time3}")

    cache_response = await check_in_redis("ajio_filters_cache")
    if cache_response:
        cache_response = json.loads(cache_response)
    else:
        cache_response = defaultdict(dict)

    # Sort the response using the cache_response
    response = await sort_response_using_cache(response, cache_response)
    time5 = datetime.now()
    print(f"Time: {time5} - Response sorted in {time5-time4}")

    try:
        await redis_db.set(cache_key, json.dumps(response, default=str))
    except Exception as e:
        print(REDIS_WRITE_ERROR, e)

    return response




@AjioRouter.post("/bestsellers-products-ajio")
async def bestseller_ajio(request_data: dict):

    cache_key = f"sale_trends_ajio_{json.dumps(request_data)}"
    cached_data = await check_in_redis(cache_key)
    if cached_data:
        return json.loads(cached_data)

    (
        bestseller_filter,
        demographic_filter,
        product_filter,
        brick_filter,
        calender_filter,
    ) = await asyncio.gather(
        build_filter_condition(request_filters=request_data, filter_flag="bestsellers"),
        build_filter_condition(request_filters=request_data, filter_flag="demographic"),
        build_filter_condition(request_filters=request_data, filter_flag="products"),
        build_filter_condition(request_filters=request_data, filter_flag="brick"),
        build_filter_condition(request_filters=request_data, filter_flag="calender", type="calender"),
    )

    bestseller_query = (
        select(
            AjioBestSellers.productid,
            AjioBestSellers.week_of_year,
            AjioBestSellers.year,
            AjioBestSellers.mrp,
            AjioBestSellers.sold_quantity_in_a_week,
            AjioBestSellers.pincode,
        )
        .where(and_(*bestseller_filter))
        .subquery()
    )


    demographic_query = (
        select(
            AjioDemographicDetails.pincode,
        )
        .where(and_(*demographic_filter))
        .subquery()
    )


    calender_query = select(
        Calenderyearmonthweekinfo.year,
        Calenderyearmonthweekinfo.week_of_year,
        func.sum(Calenderyearmonthweekinfo.num_days_in_week).label("total_days_count_across_week"),
    ).where(and_(*calender_filter)
    ).group_by(
        Calenderyearmonthweekinfo.year,
        Calenderyearmonthweekinfo.week_of_year,
    ).subquery()



    ros_query = (
        select(
            bestseller_query.c.productid,
            bestseller_query.c.week_of_year,
            bestseller_query.c.year,
            func.avg(bestseller_query.c.mrp).label("mrp"),
            func.sum(bestseller_query.c.sold_quantity_in_a_week).label("sold_quantity_across_each_week"),
        )
        .join(
            demographic_query, demographic_query.c.pincode == bestseller_query.c.pincode
        )
        .group_by(
            bestseller_query.c.productid,
            bestseller_query.c.week_of_year,
            bestseller_query.c.year,
        )
        .subquery()
    )

    # join ros and calender query
    ros_query = select(
            ros_query.c.productid,
            ros_query.c.year,
            ros_query.c.mrp,
            ros_query.c.sold_quantity_across_each_week,
            calender_query.c.total_days_count_across_week,
        ).join(
            calender_query,
            and_(
                ros_query.c.week_of_year == calender_query.c.week_of_year,
                ros_query.c.year == calender_query.c.year,
            ),
        ).subquery()

    ros_query = select(
            ros_query.c.productid,
            ros_query.c.year,
            func.sum(ros_query.c.sold_quantity_across_each_week).label("total_qty_sold"),
            func.round(cast(func.avg(ros_query.c.mrp), Numeric), 2).label("mrp"),
            func.round(cast(((func.sum(ros_query.c.sold_quantity_across_each_week)/func.sum(ros_query.c.total_days_count_across_week))*7), Numeric), 2).label("weekly_rate_of_sale"),
        ).group_by(
            ros_query.c.productid,
            ros_query.c.year
        ).subquery()
    

    product_query = (
        select(
            AjioProductAttributes.productid,
            AjioProductAttributes.similargrouplevel,
            AjioProductAttributes.title,
            AjioProductAttributes.brandname,
            AjioProductAttributes.imgcode,
            AjioProductAttributes.styletype,
            AjioProductAttributes.colorfamily,
            AjioProductAttributes.pattern,
            AjioProductAttributes.neckline,
        )
        .where(and_(*product_filter))
        .subquery()
    )

    brick_query = (
        select(
            AjioBrickDetails.similargrouplevel,
            AjioBrickDetails.l1name,
            AjioBrickDetails.l2name,
            AjioBrickDetails.brickname,
        )
        .where(and_(*brick_filter))
        .subquery()
    )


    query = (
        select(
            product_query.c.productid,
            product_query.c.title,
            product_query.c.brandname,
            product_query.c.imgcode,
            product_query.c.styletype,
            product_query.c.colorfamily,
            product_query.c.pattern,
            product_query.c.neckline,
            brick_query.c.l1name,
            brick_query.c.l2name,
            brick_query.c.brickname,
            ros_query.c.total_qty_sold,
            ros_query.c.mrp,
            ros_query.c.weekly_rate_of_sale,
        )
        .join(ros_query, ros_query.c.productid == product_query.c.productid)
        .join(
            brick_query,
            brick_query.c.similargrouplevel == product_query.c.similargrouplevel,
        )
    )
    
    # count the total number of rows
    total_count_query = select(func.count()).select_from(query)
    query = await sort_and_paginate(
        query, request_data, default_sort_param="weekly_rate_of_sale"
    )

    query_list = [query, total_count_query]

    result = await psql_execute_multiple(query_list)

    result = {
        "total_count": result[1][0][0],
        "rows": [
            {
                "productid": row[0],
                "title": row[1],
                "brandname": row[2],
                "imgcode": row[3],
                "styletype": row[4],
                "colorfamily": row[5],
                "pattern": row[6],
                "neckline": row[7],
                "l1name": row[8],
                "l2name": row[9],
                "brickname": row[10],
                "total_qty_sold": row[11],
                "mrp": row[12],
                "weekly_rate_of_sale": row[13],
            }
            for row in result[0]
        ],
    }

    try:
        await redis_db.set(cache_key, json.dumps(result, default=str))
    except Exception as e:
        print(REDIS_WRITE_ERROR, e)

    return result


@AjioRouter.post("/statewise-sales-ajio")
async def get_statewise_sales(request_data: dict,):
    cache_key = f"statewise_sales_{json.dumps(request_data)}"
    try:
        cached_data = await redis_db.get(cache_key)
    except Exception as e:
        print(REDIS_CONNECT_ERROR, e)
        cached_data = None
    if cached_data:
        return json.loads(cached_data)

    sold_in_week_query = (
        select(
            AjioDemographicDetails.state,
            func.sum(AjioBestSellers.sold_quantity_in_a_week).label("quantity"),
        )
        .join(
            AjioDemographicDetails,
            AjioDemographicDetails.pincode == AjioBestSellers.pincode,
        )
        .group_by(
            AjioDemographicDetails.state,
        )
    )

    maps_rows_state = (await psql_execute_single(sold_in_week_query))

    map_data = [
        {
            "state": row[0],
            "statecode": indian_states.get(row[0].lower(), {}).get(
                "statecode", "Not Found"
            ),
            "quantity_sold": row[1],
        }
        for row in maps_rows_state
    ]

    try:
        await redis_db.set(cache_key, json.dumps(map_data, default=str))
    except Exception as e:
        print(REDIS_WRITE_ERROR, e)

    return map_data


@AjioRouter.post("/fabric-bestsellers-ajio")
async def get_fabric_bestsellers_ajio(
    request_data: dict,
):
    cache_key = f"fabric_bestsellers_ajio_{json.dumps(request_data)}"
    try:
        cached_data = await redis_db.get(cache_key)
    except Exception as e:
        print(REDIS_CONNECT_ERROR, e)
        cached_data = None

    if cached_data:
        return json.loads(cached_data)

    result = await get_attributes_bestsellers_ajio(
        request_data, attribute="fabrictype", 
    )

    try:
        await redis_db.set(cache_key, json.dumps(result, default=str))
    except Exception as e:
        print(REDIS_WRITE_ERROR, e)

    return result


@AjioRouter.post("/brandnames-bestsellers-ajio")
async def brandnames_bestsellers_ajio(
    request_data: dict,
):
    cache_key = f"brandnames_bestsellers_ajio_{json.dumps(request_data)}"
    try:
        cached_data = await redis_db.get(cache_key)
    except Exception as e:
        print(REDIS_CONNECT_ERROR, e)
        cached_data = None

    if cached_data:
        return json.loads(cached_data)

    result = await get_attributes_bestsellers_ajio(
        request_data, attribute="brandname", 
    )

    try:
        await redis_db.set(cache_key, json.dumps(result, default=str))
    except Exception as e:
        print(REDIS_WRITE_ERROR, e)

    return result


@AjioRouter.post("/styletype-bestsellers-ajio")
async def styletype_bestsellers_ajio(
    request_data: dict,
):
    cache_key = f"styletype_bestsellers_ajio_{json.dumps(request_data)}"
    try:
        cached_data = await redis_db.get(cache_key)
    except Exception as e:
        print(REDIS_CONNECT_ERROR, e)
        cached_data = None

    if cached_data:
        return json.loads(cached_data)

    result = await get_attributes_bestsellers_ajio(
        request_data, attribute="styletype", 
    )

    try:
        await redis_db.set(cache_key, json.dumps(result, default=str))
    except Exception as e:
        print(REDIS_WRITE_ERROR, e)

    return result


@AjioRouter.post("/neckline-bestsellers-ajio")
async def neckline_bestsellers_ajio(
    request_data: dict,
):
    cache_key = f"neckline_bestsellers_ajio_{json.dumps(request_data)}"
    try:
        cached_data = await redis_db.get(cache_key)
    except Exception as e:
        print(REDIS_CONNECT_ERROR, e)
        cached_data = None

    if cached_data:
        return json.loads(cached_data)

    result = await get_attributes_bestsellers_ajio(
        request_data, attribute="neckline", 
    )

    try:
        await redis_db.set(cache_key, json.dumps(result, default=str))
    except Exception as e:
        print(REDIS_WRITE_ERROR, e)

    return result


@AjioRouter.post("/pattern-bestsellers-ajio")
async def pattern_bestsellers_ajio(
    request_data: dict,
):
    cache_key = f"pattern_bestsellers_ajio_{json.dumps(request_data)}"
    try:
        cached_data = await redis_db.get(cache_key)
    except Exception as e:
        print(REDIS_CONNECT_ERROR, e)
        cached_data = None

    if cached_data:
        return json.loads(cached_data)

    result = await get_attributes_bestsellers_ajio(
        request_data, attribute="pattern", 
    )

    try:
        await redis_db.set(cache_key, json.dumps(result, default=str))
    except Exception as e:
        print(REDIS_WRITE_ERROR, e)
    return result


@AjioRouter.post("/color-bestsellers-ajio")
async def color_bestsellers_ajio(request_data: dict,):
    cache_key = f"color_bestsellers_ajio_{json.dumps(request_data)}"
    try:
        cached_data = await redis_db.get(cache_key)
    except Exception as e:
        print(REDIS_CONNECT_ERROR, e)
        cached_data = None

    if cached_data:
        return json.loads(cached_data)

    result = await get_attributes_bestsellers_ajio(
        request_data, attribute="colorfamily", 
    )

    try:
        await redis_db.set(cache_key, json.dumps(result, default=str))
    except Exception as e:
        print(REDIS_WRITE_ERROR, e)

    return result


@AjioRouter.post("/sleevelength-bestsellers-ajio")
async def sleevelength_bestsellers_ajio(
    request_data: dict,
):
    cache_key = f"sleevelength_bestsellers_ajio_{json.dumps(request_data)}"
    try:
        cached_data = await redis_db.get(cache_key)
    except Exception as e:
        print(REDIS_CONNECT_ERROR, e)
        cached_data = None

    if cached_data:
        return json.loads(cached_data)

    result = await get_attributes_bestsellers_ajio(
        request_data, attribute="sleevelength", 
    )

    try:
        await redis_db.set(cache_key, json.dumps(result, default=str))
    except Exception as e:
        print(REDIS_WRITE_ERROR, e)

    return result
