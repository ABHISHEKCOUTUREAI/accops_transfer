from collections import defaultdict
from sqlalchemy import select, func, desc, asc, and_
from decimal import Decimal
from db import redis_db, psql_execute_single
import json
from models import (
    AjioSearchQueriesTopInteractedProducts,
    AjioBestSellers,
    AjioDemographicDetails,
    AjioBrickDetails,
    AjioProductAttributes,
    TrendsBestSellers,
    TrendsStoreDetails,
    TrendsProductAttributes,
    TrendsBrickDetails,
    Calenderyearmonthweekinfo,
    request_column_model_map,
)




indian_states = {
    "Jammu and Kashmir": {"statecode": "JK", "zone": "North"},
    "andhra pradesh": {"statecode": "AP", "zone": "South"},
    "arunachal pradesh": {"statecode": "AR", "zone": "East"},
    "assam": {"statecode": "AS", "zone": "East"},
    "bihar": {"statecode": "BR", "zone": "East"},
    "chhattisgarh": {"statecode": "CT", "zone": "West"},
    "goa": {"statecode": "GA", "zone": "West"},
    "gujarat": {"statecode": "GJ", "zone": "West"},
    "haryana": {"statecode": "HR", "zone": "North"},
    "himachal pradesh": {"statecode": "HP", "zone": "North"},
    "jharkhand": {"statecode": "JH", "zone": "East"},
    "karnataka": {"statecode": "KA", "zone": "South"},
    "kerala": {"statecode": "KL", "zone": "South"},
    "madhya pradesh": {"statecode": "MP", "zone": "West"},
    "maharashtra": {"statecode": "MH", "zone": "West"},
    "manipur": {"statecode": "MN", "zone": "East"},
    "meghalaya": {"statecode": "ML", "zone": "East"},
    "mizoram": {"statecode": "MZ", "zone": "East"},
    "nagaland": {"statecode": "NL", "zone": "East"},
    "odisha": {"statecode": "OR", "zone": "East"},
    "punjab": {"statecode": "PB", "zone": "North"},
    "rajasthan": {"statecode": "RJ", "zone": "North"},
    "sikkim": {"statecode": "SK", "zone": "East"},
    "tamil nadu": {"statecode": "TN", "zone": "South"},
    "telangana": {"statecode": "TG", "zone": "South"},
    "tripura": {"statecode": "TR", "zone": "East"},
    "uttar pradesh": {"statecode": "UP", "zone": "North"},
    "uttarakhand": {"statecode": "UT", "zone": "North"},
    "west bengal": {"statecode": "WB", "zone": "East"},
    "andaman and nicobar islands": {"statecode": "AN", "zone": "South"},
    "chandigarh": {"statecode": "CH", "zone": "North"},
    "dadra and nagar haveli and daman and diu": {"statecode": "DN", "zone": "West"},
    "delhi": {"statecode": "DL", "zone": "North"},
    "lakshadweep": {"statecode": "LD", "zone": "South"},
    "puducherry": {"statecode": "PY", "zone": "South"},
}

month_mapping = {
    1: "January",
    2: "February",
    3: "March",
    4: "April",
    5: "May",
    6: "June",
    7: "July",
    8: "August",
    9: "September",
    10: "October",
    11: "November",
    12: "December",
}

reverse_month_mapping = {
    "January": 1,
    "February": 2,
    "March": 3,
    "April": 4,
    "May": 5,
    "June": 6,
    "July": 7,
    "August": 8,
    "September": 9,
    "October": 10,
    "November": 11,
    "December": 12,
}

filter_flag_model_map = {
    "duration": {
        "ajio-search": AjioSearchQueriesTopInteractedProducts,
    },
    "search": {"ajio-search": AjioSearchQueriesTopInteractedProducts},
    "bestsellers": {"ajio": AjioBestSellers, "trends": TrendsBestSellers},
    "demographic": {"ajio": AjioDemographicDetails, "trends": TrendsStoreDetails},
    "brick": {
        "ajio": AjioBrickDetails,
        "trends": TrendsStoreDetails,
        "ajio-search": AjioBrickDetails,
    },
    "attributes": {
        "ajio-search": AjioProductAttributes,
        "ajio": AjioProductAttributes,
        "trends": TrendsProductAttributes,
    },
    
    "products": {"ajio": AjioProductAttributes, "trends": TrendsProductAttributes},
    "store_filters": {"trends": TrendsStoreDetails},
    "category": {"trends": TrendsBrickDetails},
    "calender": {"calender": Calenderyearmonthweekinfo}
}


async def create_filter_query(query, parameter):
    if parameter == "month_of_year":
        order_by_clause = query.c[parameter].desc()
    else:
        order_by_clause = func.count(query.c[parameter]).desc()

    query = (
        select(query.c[parameter])
        .group_by(query.c[parameter])
        .order_by(order_by_clause)
    ).where(query.c[parameter] is not None)
    return query


async def sort_and_paginate(query, request_data, default_sort_param):
    # sort and limit the query results
    sort_param = request_data.get("sort_param")
    if not sort_param:
        sort_param = default_sort_param
    if sort_param  == 'ajio_weekly_ros':
        sort_param = 'weekly_rate_of_sale'
    sort_type = request_data.get("sort_type")
    if not sort_type:
        sort_type = "desc"
    order_by_clause = (
        desc(f"{sort_param}") if sort_type == "desc" else asc(f"{sort_param}")
    )
    page_no = request_data.get("page_no", 1)
    page_count = request_data.get("page_count", 100)
    offset = (page_no - 1) * page_count

    query = query.order_by(order_by_clause).limit(page_count).offset(offset)

    return query


def decimal_serializer(obj):
    if isinstance(obj, Decimal):
        return str(obj)
    raise TypeError(
        "Object of type {} is not JSON serializable".format(type(obj).__name__)
    )


async def set_response_in_redis(cache_key, result):
    # Serialize the data using the custom serializer
    serialized_data = json.dumps(result, default=str)
    try:
        await redis_db.set(cache_key, serialized_data)
    except Exception as e:
        print("Not connected to redis: ", e)


async def build_filter_condition(
    filter_flag: str = "",
    request_filters: dict = defaultdict(dict),
    type: str = "ajio",
) -> dict | list:
    request_filters = request_filters.get("nested_data", {})
    response_filters = {
        "duration": [],
        "search": [],
        "attributes": [],
        "bestsellers": [],
        "demographic": [],
        "brick": [],
        "store_filters": [],
        "category": [],
        "products": [],
        "calender":[]
    }
    # breakpoint()
    for structure_key, structure_value in request_filters.items():
        for key, values in structure_value.items():
            if key == "month":
                if values and (request_column_model_map[key]["column"] in filter_flag_model_map[filter_flag][type].__dict__):
                    month_values = [reverse_month_mapping[val] for val in values]
                    response_filters[filter_flag].append(
                        filter_flag_model_map[filter_flag][type].__dict__[
                            request_column_model_map[key]["column"]
                        ].in_(month_values)
                    )
            elif key == "quarter":
                if values and (request_column_model_map[key]["column"] in filter_flag_model_map[filter_flag][type].__dict__):
                    response_filters[filter_flag].append(
                        filter_flag_model_map[filter_flag][type].__dict__[
                            request_column_model_map[key]["column"]
                        ].in_(list(map(int, values)))
                    )
            else:
                if values and (request_column_model_map[key]["column"] in filter_flag_model_map[filter_flag][type].__dict__):
                    response_filters[filter_flag].append(
                        filter_flag_model_map[filter_flag][type].__dict__[
                            request_column_model_map[key]["column"]
                        ].in_(values)
                    )

            if values and (request_column_model_map[key]["column"] in filter_flag_model_map[filter_flag][type].__dict__):
                response_filters[filter_flag].append(
                    filter_flag_model_map[filter_flag][type].__dict__[
                        request_column_model_map[key]["column"]
                    ] is not None
                )

    return response_filters[filter_flag]


async def select_filter_subquery(model, filters: list = [], columns: list = []):
    query = (
        select(*[model.__dict__[column] for column in columns])
        .where(
            and_(*filters, *[model.__dict__[column] is not  None for column in columns])
        )
        .subquery()
    )

    return query


async def sort_by_cache(response_list, cache_list):
    """
    Sort response_list based on the order of elements in cache_list.
    Elements not in cache_list will appear at the end in their original order.
    """
    cache_index = {val: idx for idx, val in enumerate(cache_list)}
    response_list.sort(key=lambda x: cache_index.get(x, float("inf")))
    return response_list


async def sort_response_using_cache(response, cache_response):
    for key, value in response.items():
        if key in cache_response:
            for key1, value1 in response[key].items():
                if key1 in cache_response[key]:
                    response[key][key1] = await sort_by_cache(
                        response[key][key1], cache_response[key][key1]
                    )  # Ensure key is string

    return response
