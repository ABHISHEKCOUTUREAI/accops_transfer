from fastapi.responses import JSONResponse
import pandas as pd
import os
import json
from static import REDIS_WRITE_ERROR
from sqlalchemy import insert, text
import asyncpg
from models import (
    AjioBestSellers,
    AjioBrickDetails,
    AjioDemographicDetails,
    AjioProductAttributes,
    TrendsBestSellers,
    TrendsBrickDetails,
    TrendsProductAttributes,
    TrendsStoreDetails,
)
from sqlalchemy import select, func, literal_column
from db import psql_execute_single, redis_db
from .api_contract_utils import api_contract_search_attributes

csv_folder = os.path.join(os.getcwd(), "../corpus/new_data/")


async def load_google_search_interactions(model, postgres_db = None):
    try:
        # Truncate the table before inserting new data
        await postgres_db.execute(
            text(f"TRUNCATE TABLE {model.__table__.name} RESTART IDENTITY")
        )
        print(f"Truncated {model.__table__.name}")
    except Exception as e:
        raise e
    

    try:
        folder_path = os.path.join(csv_folder, "../category_related")

        
        # List all CSV files in the specified folder
        csv_files = [f for f in os.listdir(folder_path) if f.endswith(".csv")]
        for files in csv_files:
            if files in [
                "Sports, Games & Equipment.csv",
                "Handbags.csv",
                "Dupatta Set.csv",
                "Anklets.csv",
                "Boxers.csv",
                "Casual Shoes.csv",
                "Jackets.csv",
            ]:
                continue
            print(f"Loading data from file '{files}'")

            df = pd.read_csv(folder_path + "/" + files, skiprows=2)

            # Initialize lists to store extracted data
            data_records = []

            # Process each row in the DataFrame
            flag = 0
            for related_name, related_number in df.iterrows():
                if related_name == "RISING":
                    flag = 1
                    continue

                category = files.split(".")[
                    0
                ]  # Assuming category name based on file name
                related_name_str = str(related_name)
                if flag == 0:
                    if isinstance(related_number["TOP"], str):
                        top_searches = 1
                    else:
                        top_searches = int(related_number["TOP"])

                    data_records.append(
                        {
                            "category": category,
                            "related_top_searches": related_name_str,
                            "number_of_top_searches": top_searches,
                            "related_rising_searches": None,
                            "number_of_rising_searches": None,
                        }
                    )
                elif flag == 1:
                    if isinstance(related_number["TOP"], str):
                        rising_searches = 100
                    else:
                        rising_searches = int(related_number["TOP"])

                    data_records[-1]["related_rising_searches"] = related_name_str
                    data_records[-1]["number_of_rising_searches"] = rising_searches

            # Create DataFrame from extracted data records

            df_processed = pd.DataFrame(data_records)

            # Fill NaN values with appropriate defaults
            df_processed = df_processed.fillna(
                {"number_of_top_searches": 0, "number_of_rising_searches": 0}
            )

            # Convert number_of_top_searches and number_of_rising_searches columns to integers
            df_processed["number_of_top_searches"] = df_processed[
                "number_of_top_searches"
            ].astype(int)
            df_processed["number_of_rising_searches"] = df_processed[
                "number_of_rising_searches"
            ].astype(int)

            # Insert data into the database
            await postgres_db.execute(
                insert(model).values(df_processed.to_dict(orient="records"))
            )
            print(
                f"Data loaded for category '{category}' in {model.__table__.name} with {len(df_processed)} records"
            )
        return JSONResponse(
            status_code=200,
            content={"message": f"Data loaded successfully into {model.__table__.name}"},
        )
    except Exception as e:
        print(e)
        raise e


# loading data to db
async def insert_into_db(
        model, 
        file_name, 
        postgres_db,
        batch_size=1000,
        gcs_bucket_name=None,
        gcs_file_name=None,
):
    
    try:
        truncate_statement = text(f"TRUNCATE TABLE {model.__tablename__}")
        await postgres_db.execute(truncate_statement)
        print(f"Truncated {model.__tablename__}")
    except Exception as e:
        raise e

    try:
        # Load the CSV file into a DataFrame

        if gcs_bucket_name and gcs_file_name:
            csv_file_path = f"gs://{gcs_bucket_name}/{gcs_file_name}"
        else:
            csv_file_path = os.path.join(csv_folder, file_name)

        if model == AjioBrickDetails:
            batch_size = 1
        for batch_number, chunk in enumerate(
            pd.read_csv(csv_file_path, chunksize=batch_size, sep=",", index_col=False),
            start=1,
        ):
            try:
                if model == AjioBestSellers:
                    chunk["year"] = chunk["year"].astype(int)
                    chunk["quarter_of_year"] = chunk["quarter_of_year"].astype(int)
                    chunk["month_of_year"] = chunk["month_of_year"].astype(int)
                    chunk["week_of_year"] = chunk["week_of_year"].astype(int)
                    chunk["pincode"] = chunk["pincode"].astype(str)
                    chunk["productid"] = chunk["productid"].astype(str)
                    chunk["mrp"] = chunk["mrp"].astype(float)
                    chunk["availablequantity_in_a_week"] = chunk[
                        "availablequantity_in_a_week"
                    ].astype(int)
                    chunk["sold_quantity_in_a_week"] = chunk[
                        "sold_quantity_in_a_week"
                    ].astype(int)
                if model == AjioProductAttributes:
                    chunk["productid"] = chunk["productid"].astype(str)
                    chunk["similargrouplevel"] = chunk["similargrouplevel"].astype(str)
                    chunk["colorfamily"] = chunk["colorfamily"].astype(str)
                    chunk["fabrictype"] = chunk["fabrictype"].astype(str)
                    chunk["materialtype"] = chunk["materialtype"].astype(str)
                    chunk["pattern"] = chunk["pattern"].astype(str)
                    chunk["sleevelength"] = chunk["sleevelength"].astype(str)
                    chunk["brandname"] = chunk["brandname"].astype(str)
                    chunk["occasion"] = chunk["occasion"].astype(str)
                    chunk["bodytype"] = chunk["bodytype"].astype(str)
                    chunk["fit"] = chunk["fit"].astype(str)
                    chunk["distress"] = chunk["distress"].astype(str)
                    chunk["traditionalweave"] = chunk["traditionalweave"].astype(str)
                    chunk["neckline"] = chunk["neckline"].astype(str)
                    chunk["hemline"] = chunk["hemline"].astype(str)
                    chunk["styletype"] = chunk["styletype"].astype(str)
                    chunk["title"] = chunk["title"].astype(str)
                    chunk["catalogid"] = chunk["catalogid"].astype(str)
                    chunk["imgcode"] = chunk["imgcode"].astype(str)
                if model == AjioBrickDetails:

                    chunk["similargrouplevel"] = chunk["similargrouplevel"].astype(str)
                    chunk["l1name"] = chunk["l1name"].astype(str)
                    chunk["l2name"] = chunk["l2name"].astype(str)
                    chunk["brickname"] = chunk["brickname"].astype(str)
                if model == AjioDemographicDetails:
                    chunk["pincode"] = chunk["pincode"].astype(str)
                    chunk["state"] = chunk["state"].astype(str)
                    chunk["city"] = chunk["city"].astype(str)
                    chunk["districtsname"] = chunk["districtsname"].astype(str)
                    chunk["zone"] = chunk["zone"].astype(str)
                if model == TrendsBestSellers:
                    chunk["year"] = chunk["year"].astype(float).fillna(0).astype(int)
                    chunk["quarter_of_year"] = (
                        chunk["quarter_of_year"].astype(float).fillna(0).astype(int)
                    )
                    chunk["month_of_year"] = (
                        chunk["month_of_year"].astype(float).fillna(0).astype(int)
                    )
                    chunk["week_of_year"] = (
                        chunk["week_of_year"].astype(float).fillna(0).astype(int)
                    )
                    chunk["itemid"] = chunk["itemid"].astype(str)
                    chunk["store_id"] = chunk["store_id"].astype(str)
                    chunk["sold_quantity_in_a_week"] = (
                        chunk["sold_quantity_in_a_week"]
                        .astype(float)
                        .fillna(0)
                        .astype(int)
                    )
                    chunk["availablequantity_in_a_week"] = (
                        chunk["availablequantity_in_a_week"]
                        .astype(float)
                        .fillna(0)
                        .astype(int)
                    )
                if model == TrendsProductAttributes:
                    chunk["itemid"] = chunk["itemid"].astype(str)
                    chunk["similargrouplevel"] = chunk["similargrouplevel"].astype(str)
                    chunk["primarycolor"] = chunk["primarycolor"].astype(str)
                    chunk["fabrictype"] = chunk["fabrictype"].astype(str)
                    chunk["materialtype"] = chunk["materialtype"].astype(str)
                    chunk["pattern"] = chunk["pattern"].astype(str)
                    chunk["sleeve"] = chunk["sleeve"].astype(str)
                    chunk["fit"] = chunk["fit"].astype(str)
                    chunk["neckline"] = chunk["neckline"].astype(str)
                    chunk["styletype"] = chunk["styletype"].astype(str)
                    chunk["fashion_grade_description"] = chunk[
                        "fashion_grade_description"
                    ].astype(str)
                    chunk["mrp"] = chunk["mrp"].astype(float)
                    chunk["imgcode"] = chunk["imgcode"].astype(str)
                    chunk["brandname"] = chunk["brandname"].astype(str)
                    chunk["extension"] = chunk["extension"].astype(str)
                if model == TrendsBrickDetails:
                    chunk["similargrouplevel"] = chunk["similargrouplevel"].astype(str)
                    chunk["mh_family_desc"] = chunk["mh_family_desc"].astype(str)
                    chunk["mh_class_desc"] = chunk["mh_class_desc"].astype(str)
                    chunk["brickname"] = chunk["brickname"].astype(str)
                if model == TrendsStoreDetails:
                    chunk["store_id"] = chunk["store_id"].astype(str)
                    chunk["pin_code"] = chunk["pin_code"].astype(str)
                    chunk["format_cd"] = chunk["format_cd"].astype(str)
                    chunk["format_desc"] = chunk["format_desc"].astype(str)
                    chunk["city"] = chunk["city"].astype(str)
                    chunk["region"] = chunk["region"].astype(str)
                    chunk["location"] = chunk["location"].astype(str)
                    chunk["store_short_name"] = chunk["store_short_name"].astype(str)
                    chunk["store_area"] = chunk["store_area"].astype(str)
                    chunk["state"] = chunk["state"].astype(str)
                    chunk["zone_desc"] = chunk["zone_desc"].astype(str)
                    chunk["store_class_desc"] = chunk["store_class_desc"].astype(str)
                    chunk["districtsname"] = chunk["districtsname"].astype(str)
                await postgres_db.execute(
                    insert(model).values(chunk.to_dict(orient="records"))
                )
                print(f"Batch {batch_number} loaded for {model.__tablename__}")
            except asyncpg.exceptions.UniqueViolationError:
                continue
        print(f"{model.__tablename__} loaded successfully")
        return JSONResponse(
            status_code=200,
            content={"message": f"Data loaded successfully into {model.__tablename__}"},
        )
    except Exception as e:
        print(e)
        print("failed to load data into: ", model.__tablename__)
        return JSONResponse(
            status_code=500,
            content={"message": f"Failed to load data into {model.__tablename__}"},
        )



async def load_attributes_images():
    try:
        cache_key = "attributes_images"
        cached_data = await redis_db.get(cache_key)
    except Exception as e:
        print(REDIS_WRITE_ERROR, e)
    
    if not cached_data:
        DATA = {}
        for attribute in api_contract_search_attributes:
            window_cte = (
                select(
                    getattr(AjioProductAttributes, attribute),
                    AjioProductAttributes.productid,
                    AjioProductAttributes.imgcode,
                    func.row_number()
                    .over(
                        partition_by=getattr(AjioProductAttributes, attribute),
                        order_by=literal_column("1"),  # Can adjust this ordering as needed
                    )
                    .label("row_num"),
                )
            ).cte()

            window_query = (
                select(
                    getattr(window_cte.c, attribute),
                    window_cte.c.productid,
                    window_cte.c.imgcode,
                ).where(window_cte.c.row_num == 1)
            )

            result = await psql_execute_single(window_query)

            # save for each attribute and row[0] there is a list of productids and imgcodes
            if attribute not in DATA:
                DATA[attribute] = {}
            
            for row in result:
                attr_value = row[0]
                productid = row[1]
                imgcode = row[2]
                
                DATA[attribute][attr_value] = {"productid": productid, "imgcode": imgcode}
 
                
            

        try:
            cache_key = "attributes_images"
            await redis_db.set(cache_key, json.dumps(DATA, default=str))
        except Exception as e:
            print(REDIS_WRITE_ERROR, e)
        # also store the data in a json file
        try:
            json_file_path = os.path.join(os.getcwd(), "static/cached_data/attributes_images.json")
            with open(json_file_path, "w") as f:
                json.dump(DATA, f)
        except Exception as e:
            print("Failed to write attributes images to json file: ", e)

    
    print("attributes-images loaded")



async def load_category_images():
    try:
        cache_key = "category_images"
        cached_data = await redis_db.get(cache_key)
    except Exception as e:
        print(REDIS_WRITE_ERROR, e)
    
    if not cached_data:
    
        subquery = (
            select(
                AjioBrickDetails.l2name,
                AjioProductAttributes.productid,
                AjioProductAttributes.imgcode,
                func.row_number()
                .over(
                    partition_by=AjioBrickDetails.l2name,
                    order_by=literal_column("1"),  # Can adjust this ordering as needed
                )
                .label("row_num"),
            )
            .join(
                AjioProductAttributes,
                AjioBrickDetails.similargrouplevel
                == AjioProductAttributes.similargrouplevel,
            )
        ).cte()

        # Select only the first row for each l2name
        query = select(
            subquery.c.l2name, 
            subquery.c.productid, 
            subquery.c.imgcode
        ).where(
            subquery.c.row_num == 1
        )

        result = await psql_execute_single(query)
        result = {
            row[0]: {
                "id": row[1],
                "imgcode": row[2],
            }
            for row in result
        }

        try:
            cache_key = "category_images"
            await redis_db.set(cache_key, json.dumps(result, default=str))
        except Exception as e:
            print(REDIS_WRITE_ERROR, e)
        # also store the data in a json file
        try:
            json_file_path = os.path.join(os.getcwd(), "static/cached_data/category_images.json")
            with open(json_file_path, "w") as f:
                json.dump(result, f)
        except Exception as e:
            print("Failed to write category images to json file: ", e)

    print("category-images loaded")