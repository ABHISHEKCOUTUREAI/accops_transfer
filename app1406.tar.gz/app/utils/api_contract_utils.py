import asyncio

from db import psql_execute_single, redis_db
from models import (
    AjioBestSellers,
    AjioBrickDetails,
    AjioDemographicDetails,
    AjioProductAttributes,
    AjioSearchQueriesTopInteractedProducts,
    AttributeQueryParams,
    Calenderyearmonthweekinfo,
    ProductQueryParams,
    SearchParams,
    TrendsBestSellers,
    TrendsStoreDetails,
)
import json 

from sqlalchemy import Numeric, and_, case, cast, func, or_, select

from .common_utils import build_filter_condition, month_mapping, sort_and_paginate

api_contract_search_attributes = [
    "brandname",
    "colorfamily",
    "fabrictype",
    "materialtype",
    "pattern",
    "sleevelength",
    "styletype",
    "occasion",
    "bodytype",
    "fit",
    "distress",
    "traditionalweave",
    "neckline",
    "hemline",
]


fields_info = [
    ("quarter", "Quarter", 1),
    ("month", "Month", 0, month_mapping),
    ("zone", "Zone", 2),
    ("state", "State", 3),
    ("city", "City", 4),
    ("district", "District", 5),
    ("gender", "Gender", 6),
    ("category", "Category", 7),
    ("brick_name", "Brick Name", 8),
    ("styletype", "Style Type", 9),
    ("neckline", "Neckline", 10),
    ("pattern", "Pattern", 11),
    ("fabric_type", "Fabric Type", 12),
    ("sleeve", "Sleeve", 13),
    ("fit", "Fit", 14),
    ("color", "Color", 15),
    ("brand", "Brand", 16),
    ("occasion", "Occasion", 17),
    ("bodytype", "Body Type", 18),
    ("materialtype", "Material Type", 19),
    ("distress", "Distress", 20),
    ("traditionalweave", "Traditional Weave", 21),
    ("hemline", "Hemline", 22),
]


async def create_request_api_contract_ajio(query_params: ProductQueryParams):
    request_data = {
        "nested_data": {
            "duration": {"month": [], "quarter": []},
            "demographic": {
                "zone": [],
                "state": [],
                "city": [],
                "district": [],
                "pincode": [],
            },
            "attributes": {
                "styletype": [],
                "neckline": [],
                "pattern": [],
                "fabric_type": [],
                "sleeve": [],
                "fit": [],
                "color": [],
                "brand": [],
                "occasion": [],
                "bodytype": [],
                "materialtype": [],
                "distress": [],
                "traditionalweave": [],
                "hemline": [],
            },
            "brick_filters": {"l1_name": [], "l2_name": [], "brick_name": []},
        },
        "page_no": query_params.page,
        "page_count": query_params.page_size,
        "sort_param": query_params.sort_attribute,
        "sort_type": query_params.sort_order,
    }
    # Append demography filters
    if query_params.zone:
        request_data["nested_data"]["demographic"]["zone"].append(query_params.zone)
    if query_params.state:
        request_data["nested_data"]["demographic"]["state"].append(query_params.state)
    if query_params.city:
        request_data["nested_data"]["demographic"]["city"].append(query_params.city)
    if query_params.pincode:
        request_data["nested_data"]["demographic"]["pincode"].append(
            query_params.pincode
        )
    if query_params.gender:
        request_data["nested_data"]["brick_filters"]["l1_name"].append(
            query_params.gender
        )
    if query_params.category:
        request_data["nested_data"]["brick_filters"]["l2_name"].append(
            query_params.category
        )

    # Append attribute key and value
    if query_params.attribute_key and query_params.attribute_value:
        if query_params.attribute_key in request_data["nested_data"]["attributes"]:
            request_data["nested_data"]["attributes"][
                query_params.attribute_key
            ].append(query_params.attribute_value)
        else:
            request_data["nested_data"]["attributes"][query_params.attribute_key] = [
                query_params.attribute_value
            ]
    return request_data


async def create_request_api_contract_filters(query_params: SearchParams):
    request_data = {
        "nested_data": {
            "duration": {"month": [], "quarter": []},
            "demography": {"zone": [], "state": [], "city": [], "district": []},
            "attributes": {
                "styletype": [],
                "neckline": [],
                "pattern": [],
                "fabric_type": [],
                "sleeve": [],
                "fit": [],
                "color": [],
                "brand": [],
                "occasion": [],
                "bodytype": [],
                "materialtype": [],
                "distress": [],
                "traditionalweave": [],
                "hemline": [],
            },
            "brick_filters": {"l1_name": [], "l2_name": [], "brick_name": []},
        }
    }
    # Append demography filters
    if query_params.zone:
        request_data["nested_data"]["demography"]["zone"].append(query_params.zone)
    if query_params.state:
        request_data["nested_data"]["demography"]["state"].append(query_params.state)
    if query_params.city:
        request_data["nested_data"]["demography"]["city"].append(query_params.city)

    # Append brand name
    if query_params.brandname:
        request_data["nested_data"]["attributes"]["brand"].append(
            query_params.brandname
        )
    return request_data


async def create_request_api_contract_trends(query_params: ProductQueryParams):
    request_data = {
        "nested_data": {
            "duration": {"month": [], "quarter": []},
            "demography": {
                "zone": [],
                "state": [],
                "city": [],
                "district": [],
            },
            "attributes": {
                "styletype": [],
                "neckline": [],
                "pattern": [],
                "fabric_type": [],
                "sleeve": [],
                "fit": [],
                "color": [],
                "brand": [],
            },
            "store_filters": {"pincode": [], "store_id": []},
            "category": {
                "category_family": [],
                "category_class": [],
                "category": [],
            },
        },
        "page_no": query_params.page,
        "page_count": query_params.page_size,
        "sort_param": query_params.sort_attribute,
        "sort_type": query_params.sort_order,
    }
    # Append demography filters
    if query_params.zone:
        request_data["nested_data"]["demography"]["zone"].append(query_params.zone)
    if query_params.state:
        request_data["nested_data"]["demography"]["state"].append(query_params.state)
    if query_params.city:
        request_data["nested_data"]["demography"]["city"].append(query_params.city)

    # Append attribute key and value
    if query_params.attribute_key and query_params.attribute_value:
        if query_params.attribute_key in request_data["nested_data"]["attributes"]:
            request_data["nested_data"]["attributes"][
                query_params.attribute_key
            ].append(query_params.attribute_value)
        else:
            request_data["nested_data"]["attributes"][query_params.attribute_key] = [
                query_params.attribute_value
            ]

    return request_data


async def create_most_searched_attributes_query(
    query_params, attribute, start_week, latest_week
):
    # Combine conditions efficiently
    brick_conditions = []
    if query_params.category is not None:
        brick_conditions.append(AjioBrickDetails.l2name == query_params.category)
    if query_params.brickname is not None:
        brick_conditions.append(AjioBrickDetails.brickname == query_params.brickname)

    # Build the main query with joins and conditions
    search_query = (
        select(
            getattr(AjioProductAttributes, attribute),
            func.sum(AjioSearchQueriesTopInteractedProducts.sum_session_counts).label(
                "total_searches"
            ),
        )
        .join(
            AjioProductAttributes,
            AjioSearchQueriesTopInteractedProducts.productid
            == AjioProductAttributes.productid,
        )
        .join(
            AjioBrickDetails,
            AjioProductAttributes.similargrouplevel
            == AjioBrickDetails.similargrouplevel,
        )
        .where(
            and_(
                *brick_conditions,
                AjioSearchQueriesTopInteractedProducts.week_of_year.between(
                    start_week, latest_week + 1
                ),
            )
        )
        .group_by(
            getattr(AjioProductAttributes, attribute),
        )
        .order_by(
            func.sum(AjioSearchQueriesTopInteractedProducts.sum_session_counts).desc()
        )
        .limit(query_params.page_size)
        .offset(query_params.page_size * (query_params.page - 1))
    )

    return search_query


async def calculate_time_delta():
    
    cache_key = "min_max_week"
    cached_data = await redis_db.get(cache_key)
    if not cached_data:

        week_query = select(func.max(AjioSearchQueriesTopInteractedProducts.week_of_year))
        week_result = await psql_execute_single(week_query)
        max_week = week_result[0][0]

        # Query to select the minimum week from the database
        min_week_query = select(func.min(AjioSearchQueriesTopInteractedProducts.week_of_year))
        min_week_result = await psql_execute_single(min_week_query)
        min_week = min_week_result[0][0]

        await redis_db.set(cache_key, json.dumps([min_week, max_week]))
    
    print('time-delta loaded')



async def create_most_searched_filters(query_params: SearchParams):
    # Combine conditions efficiently
    brick_conditions = []
    if query_params.category is not None:
        brick_conditions.append(AjioBrickDetails.l2name == query_params.category)
    if query_params.brickname is not None:
        brick_conditions.append(AjioBrickDetails.brickname == query_params.brickname)

    demographic_conditions = []
    if query_params.city is not None:
        demographic_conditions.append(AjioDemographicDetails.city == query_params.city)
    if query_params.state is not None:
        demographic_conditions.append(
            AjioDemographicDetails.state == query_params.state
        )

    return brick_conditions, demographic_conditions


async def create_bestseller_attribute_query(
    query_params: AttributeQueryParams, attribute, week
):


    query = (
        select(
            getattr(AjioProductAttributes, attribute),
            func.sum(
                case(
                    (
                        AjioBestSellers.week_of_year == week,
                        AjioBestSellers.sold_quantity_in_a_week,
                    ),
                    else_=0,
                )
            ).label("current_week_sales"),
            func.sum(
                case(
                    (
                        AjioBestSellers.week_of_year == week - 1,
                        AjioBestSellers.sold_quantity_in_a_week,
                    ),
                    else_=0,
                )
            ).label("previous_week_sales"),
        )
        .join(
            AjioBrickDetails,
            AjioBrickDetails.similargrouplevel
            == AjioProductAttributes.similargrouplevel,
        )
        .join(
            AjioBestSellers,
            AjioBestSellers.productid == AjioProductAttributes.productid,
        )
        .where(
            AjioBrickDetails.l2name == query_params.category,
            getattr(AjioProductAttributes, attribute) != "nan",
            or_(
                AjioBestSellers.week_of_year == week,
                AjioBestSellers.week_of_year == week - 1,
            ),
        )
        .group_by(getattr(AjioProductAttributes, attribute))
        .limit(query_params.page_size)
        .offset((query_params.page - 1) * query_params.page_size)
    )

    return query


async def api_contract_ajio_bestseller_query(
    request_data_ajio, query_params: ProductQueryParams
):
    (
        bestseller_filter,
        demographic_filter,
        attribute_filter,
        brick_filter,
        calender_filter,
    ) = await asyncio.gather(
        build_filter_condition(
            request_filters=request_data_ajio, filter_flag="bestsellers",
            type="ajio"
        ),
        build_filter_condition(
            request_filters=request_data_ajio, filter_flag="demographic",
            type="ajio"
        ),
        build_filter_condition(
            request_filters=request_data_ajio, filter_flag="attributes",
            type="ajio"
        ),
        build_filter_condition(request_filters=request_data_ajio, filter_flag="brick",
                               type="ajio"),
        build_filter_condition(
            request_filters=request_data_ajio, filter_flag="calender", type="calender",
        ),
    )
    

    bestseller_query = (
        select(
            AjioBestSellers.productid,
            AjioBestSellers.week_of_year,
            AjioBestSellers.year,
            AjioBestSellers.mrp,
            AjioBestSellers.sold_quantity_in_a_week,
            AjioBestSellers.pincode,
        )
        .where(and_(*bestseller_filter))
        .cte()
    )

    demographic_query = (
        select(
            AjioDemographicDetails.pincode,
        )
        .where(and_(*demographic_filter))
        .cte()
    )

    calender_query = (
        select(
            Calenderyearmonthweekinfo.year,
            Calenderyearmonthweekinfo.week_of_year,
            func.sum(Calenderyearmonthweekinfo.num_days_in_week).label(
                "total_days_count_across_week"
            ),
        )
        .where(and_(*calender_filter))
        .group_by(
            Calenderyearmonthweekinfo.year,
            Calenderyearmonthweekinfo.week_of_year,
        )
        .cte()
    )

    ros_query = (
        select(
            bestseller_query.c.productid,
            bestseller_query.c.week_of_year,
            bestseller_query.c.year,
            func.avg(bestseller_query.c.mrp).label("mrp"),
            func.sum(bestseller_query.c.sold_quantity_in_a_week).label(
                "sold_quantity_across_each_week"
            ),
        )
        .join(
            demographic_query, demographic_query.c.pincode == bestseller_query.c.pincode
        )
        .group_by(
            bestseller_query.c.productid,
            bestseller_query.c.week_of_year,
            bestseller_query.c.year,
        )
        .cte()
    )

    # join ros and calender query
    ros_query = (
        select(
            ros_query.c.productid,
            ros_query.c.year,
            ros_query.c.mrp,
            ros_query.c.sold_quantity_across_each_week,
            calender_query.c.total_days_count_across_week,
        )
        .join(
            calender_query,
            and_(
                ros_query.c.week_of_year == calender_query.c.week_of_year,
                ros_query.c.year == calender_query.c.year,
            ),
        )
        .cte()
    )

    ros_query = (
        select(
            ros_query.c.productid,
            ros_query.c.year,
            func.sum(ros_query.c.sold_quantity_across_each_week).label(
                "total_qty_sold"
            ),
            func.round(cast(func.avg(ros_query.c.mrp), Numeric), 2).label("mrp"),
            func.round(
                cast(
                    (
                        (
                            func.sum(ros_query.c.sold_quantity_across_each_week)
                            / func.sum(ros_query.c.total_days_count_across_week)
                        )
                        * 7
                    ),
                    Numeric,
                ),
                2,
            ).label("weekly_rate_of_sale"),
        )
        .group_by(ros_query.c.productid, ros_query.c.year)
        .cte()
    )

    mrp_condition = True
    if query_params.min_mrp is not None and query_params.max_mrp is not None:
        mrp_condition = and_(
            ros_query.c.mrp >= query_params.min_mrp,
            ros_query.c.mrp <= query_params.max_mrp,
        )

    ros_query = (
        select(
            ros_query.c.productid,
            ros_query.c.total_qty_sold,
            ros_query.c.mrp,
            ros_query.c.weekly_rate_of_sale,
        )
        .where(mrp_condition)
        .cte()
    )

    product_query = (
        select(
            AjioProductAttributes.productid,
            AjioProductAttributes.similargrouplevel,
            AjioProductAttributes.title,
            AjioProductAttributes.brandname,
            AjioProductAttributes.imgcode,
        )
        .where(and_(*attribute_filter))
        .cte()
    )

    brick_query = (
        select(
            AjioBrickDetails.similargrouplevel,
        )
        .where(and_(*brick_filter))
        .cte()
    )

    ajio_query = (
        select(
            product_query.c.productid,
            product_query.c.title,
            product_query.c.brandname,
            product_query.c.imgcode,
            ros_query.c.total_qty_sold,
            ros_query.c.mrp,
            ros_query.c.weekly_rate_of_sale,
        )
        .join(ros_query, ros_query.c.productid == product_query.c.productid)
        .join(
            brick_query,
            brick_query.c.similargrouplevel == product_query.c.similargrouplevel,
        )
    )

    ajio_query = await sort_and_paginate(
        ajio_query, request_data_ajio, default_sort_param="weekly_rate_of_sale"
    )

    return ajio_query


async def api_contract_trends_bestseller_query(request_data_trends):
    (
        bestseller_filter_trends,
        store_filter_trends,
        calender_filter_trends,
    ) = await asyncio.gather(
        build_filter_condition(
            type="trends",
            request_filters=request_data_trends,
            filter_flag="bestsellers",
        ),
        build_filter_condition(
            type="trends",
            request_filters=request_data_trends,
            filter_flag="store_filters",
        ),
        build_filter_condition(
            type="calender", 
            request_filters=request_data_trends, 
            filter_flag="calender",
        ),
    )

    bestseller_query = (
        select(
            TrendsBestSellers.itemid,
            TrendsBestSellers.week_of_year,
            TrendsBestSellers.year,
            TrendsBestSellers.store_id,
            TrendsBestSellers.sold_quantity_in_a_week,
        )
        .where(and_(*bestseller_filter_trends))
        .cte()
    )

    store_query = (
        select(
            TrendsStoreDetails.store_id,
        )
        .where(and_(*store_filter_trends))
        .cte()
    )

    calender_query = (
        select(
            Calenderyearmonthweekinfo.week_of_year,
            Calenderyearmonthweekinfo.year,
            func.sum(Calenderyearmonthweekinfo.num_days_in_week).label(
                "total_days_count_across_week"
            ),
        )
        .where(and_(*calender_filter_trends))
        .group_by(
            Calenderyearmonthweekinfo.week_of_year, Calenderyearmonthweekinfo.year
        )
        .cte()
    )

    ros_query = (
        select(
            bestseller_query.c.itemid,
            bestseller_query.c.week_of_year,
            bestseller_query.c.year,
            func.sum(bestseller_query.c.sold_quantity_in_a_week).label(
                "sold_quantity_across_each_week"
            ),
        )
        .join(store_query, store_query.c.store_id == bestseller_query.c.store_id)
        .group_by(
            bestseller_query.c.itemid,
            bestseller_query.c.week_of_year,
            bestseller_query.c.year,
        )
        .cte()
    )

    # join ros and calender query
    ros_query = (
        select(
            ros_query.c.itemid,
            ros_query.c.year,
            ros_query.c.sold_quantity_across_each_week,
            calender_query.c.total_days_count_across_week,
        )
        .join(
            calender_query,
            and_(
                calender_query.c.week_of_year == ros_query.c.week_of_year,
                calender_query.c.year == ros_query.c.year,
            ),
        )
        .cte()
    )

    trends_query = select(
        ros_query.c.itemid,
        ros_query.c.year,
        func.round(
            cast(
                (
                    (
                        func.sum(ros_query.c.sold_quantity_across_each_week)
                        / func.sum(ros_query.c.total_days_count_across_week)
                    )
                    * 7
                ),
                Numeric,
            ),
            2,
        ).label("weekly_rate_of_sale"),
    ).group_by(ros_query.c.itemid, ros_query.c.year)

    return trends_query
