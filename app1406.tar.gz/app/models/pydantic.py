from fastapi import Query
from typing import Optional
from pydantic import BaseModel, Field
from enum import Enum


class ProductQueryParams(BaseModel):
    page: int = Query(1, ge=1)
    page_size: int = Query(100, ge=1)
    gender: Optional[str] = Query(None)
    category: Optional[str] = None
    zone: Optional[str] = None
    state: Optional[str] = None
    city: Optional[str] = None
    pincode: Optional[str] = None
    min_mrp: Optional[int] = Query(None, ge=0)
    max_mrp: Optional[int] = Query(None, ge=0)
    attribute_key: Optional[str] = None
    attribute_value: Optional[str] = None
    sort_attribute: Optional[str] = None
    sort_order: Optional[str] = Query("desc", regex="^(asc|desc)$")



class CategoryQueryParams(BaseModel):
    gender: str = Query('Men')



class AttributeQueryParams(BaseModel):
    page: int = Query(1, ge=1)
    page_size: int = Query(10, ge=1)
    category: Optional[str] = 'Ethnic Wear'
    attribute: Optional[str] = 'all'
    week: Optional[int] = None



# class CategoryEnum(str, Enum):
#     bodysuits = "Bodysuits"
#     bakeware = "Bakeware"
#     mufflers = "Mufflers"
#     socks_and_stockings = "Socks & Stockings"
#     watches = "Watches"
#     baby_gear = "Baby Gear"
#     idols_and_coins = "Idols & Coins"
#     rings = "Rings"
#     shoes = "Shoes"
#     nose_pins = "Nose Pins"
#     jackets_and_shrugs = "Jackets & Shrugs"



class SearchTrends(BaseModel):
    page: int = Query(1, ge=1)
    page_size: int = Query(5, ge=1)
    num_days: Optional[int] = 35
    category: Optional[str] = None
    brickname: Optional[str] = None


class SearchParams(BaseModel):
    page: int = Query(1, ge=1)
    page_size: int = Query(5, ge=1)
    num_days: Optional[int] = 35
    category: Optional[str] = None
    brickname: Optional[str] = None
    attribute: Optional[str] = 'all'
    # city: Optional[str] = None
    # state: Optional[str] = None



class FilterQuery(BaseModel):
    # selected_filter: str
    # pin_code: Optional[str] = None
    # fashion_grade: Optional[str] = None
    brandname: Optional[str] = None
    # store: Optional[str] = None
    city: Optional[str] = None
    state: Optional[str] = None
    zone: Optional[str] = None
    min_mrp: Optional[int] = None
    max_mrp: Optional[int] = None


