from sqlalchemy import Column, String, Float, DateTime, Integer
from sqlalchemy.ext.declarative import declarative_base

Base = declarative_base()


class AiocdAnalysisSales(Base):            
    __tablename__ = "aiocd_sales_analysis"

    id = Column(Integer, primary_key=True, autoincrement=True)
    ranking_level = Column(String)
    L0 = Column(String)
    L1 = Column(String)
    L2 = Column(String)
    L3 = Column(String)
    sap_id = Column(String)   
    item_name = Column(String)
    aiocd_revenue = Column(Float)
    revenue =  Column(Float)       
    fraction_revenue= Column(Float)
    level_rank  = Column(Integer)
    aiocd_level_rank = Column(Integer)


class IQVIASales(Base):
    __tablename__ = "iqvia_sales_analysis"

    id = Column(Integer, primary_key=True, autoincrement=True)
    ranking_level = Column(String)
    L0 = Column(String)
    L1 = Column(String)
    L2 = Column(String)
    L3 = Column(String)
    sap_id = Column(String)   
    item_name = Column(String)
    iqvia_revenue = Column(Float)
    revenue = Column(Float)
    fraction_revenue = Column(Float)
    level_rank = Column(Integer)
    iqvia_level_rank = Column(Integer)


class MSAAllCats(Base):
    __tablename__ = "msa_all_cats"

    id = Column(Integer, primary_key=True, autoincrement=True)
    ranking_level = Column(String)
    L0 = Column(String)
    L1 = Column(String)
    L2 = Column(String)
    L3 = Column(String)
    sap_id = Column(String)   


class AiocdAnalysis(Base):            
    __tablename__ = "aiocd_analysis"

    sap_id = Column(Integer, primary_key=True)
    zone = Column(String)
    state = Column(String)
    city = Column(String)
    br_code = Column(String, primary_key=True)
    month = Column(Integer, primary_key=True)
    overall_rank = Column(Integer)
    rank_molecule = Column(Integer)
    rank_sku_by_sale = Column(Integer)
    NotInInventory = Column(Integer)
    NotSold = Column(Integer)
    Bounced = Column(Integer)
    item_name = Column(String)


class Orders(Base):
    __tablename__ = "date_wise_orders"

    br_code = Column(String, primary_key=True)
    sap_id = Column(Integer, primary_key=True)
    quantity_sold = Column(Float)
    total_revenue = Column(Float)
    total_cost = Column(Float)
    tran_date = Column(DateTime, primary_key=True)
    num_orders = Column(Integer, primary_key=True)


class Bounce(Base):
    __tablename__ = 'date_wise_bounce'

    br_code = Column(String, primary_key=True)
    sap_id = Column(Integer, primary_key=True)
    date = Column(DateTime, primary_key=True)
    number_of_bounce = Column(Float)


class Product(Base):
    __tablename__ = 'product'  

    sap_id = Column(Integer, primary_key=True)
    L0 = Column(String)
    L1 = Column(String)
    L2 = Column(String)
    L3 = Column(String)
    item_name = Column(String)
    brand_name = Column(String, primary_key=True)
    mfac_name = Column(String)
    mrp = Column(Float)
    molecule = Column(String)


class Inventory(Base):
    __tablename__ = "inventory"

    sap_id = Column(Integer, primary_key=True)
    br_code = Column(String, primary_key=True)
    total_stock_value = Column(Float)
    total_stock_quantity = Column(Float)
    date = Column(DateTime, primary_key=True)


class Store(Base):
    __tablename__ = "store"

    br_code = Column(String, primary_key=True)
    zone = Column(String)
    state = Column(String)
    city = Column(String)
    pincode = Column(Integer)


class AssortmentOutput(Base):          
    __tablename__ = "assortment_output"

    sap_id = Column(Integer, primary_key=True)
    br_code = Column(String, primary_key=True)
    exist_in_model_output = Column(Integer, nullable=True)
    exist_in_baseline_output = Column(Integer, nullable=True)
    is_sold = Column(Integer, nullable=True)
    num_qty_sold = Column(Float, nullable=True) 
    zone = Column(String)
    state = Column(String)
    city = Column(String)
    L0 = Column(String)
    L1 = Column(String)
    L2 = Column(String)
    L3 = Column(String)
    item_name = Column(String)
    total_amount = Column(Float, nullable=True)
    total_margin = Column(Float, nullable=True)
    num_qty_sold_train = Column(Float, nullable=True) 
    total_amount_train = Column(Float, nullable=True) 
    total_margin_train = Column(Float, nullable=True)    
    mfac_name = Column(String)
    is_new_product = Column(Integer, nullable=True)
    brand_name  = Column(String)
    exist_in_bounce_data =  Column(Integer, nullable=True)
    min_qty = Column(Integer, nullable=True)
    max_qty = Column(Integer, nullable=True)
    probability = Column(Float, nullable=True)
    AIOCD_Rank = Column(Integer, nullable=True)
    IQVIA_Rank = Column(Integer, nullable=True)
    del_flag = Column(Integer, nullable=True)
    aiocd_sales_2022 = Column(Float)
    iqvia_revenue =  Column(Float)
    num_bounce_train =  Column(Float)
    num_bounce_test =  Column(Float)
    det_cogs_amt =  Column(Float)
    qty_sold_online =  Column(Float)
    del_flag = Column(Integer, server_default='0') 
    curr_inv = Column(Integer, nullable=True)
  


class Probability(Base):
    __tablename__ = "probability"

    br_code = Column(String, primary_key=True)
    sap_id = Column(Integer, primary_key=True)
    probability = Column(Float)

    

class NewStoresAssortment(Base):
    __tablename__ = "new_stores_assortment"

    sap_id = Column(Integer, primary_key=True)
    total_amount = Column(Float)
    total_margin = Column(Float)
    qty_sold = Column(Float)
    min_qty = Column(Integer)
    max_qty = Column(Integer)
    qty_bounce_train = Column(Float)
    qty_bounce_test = Column(Float)
    qty_sold_online = Column(Float)
    br_code = Column(String, primary_key=True)
    qty_sold_train = Column(Float)
    num_stores_product_part_of_assortment = Column(Integer)
    region_type = Column(String, primary_key=True)
    region_name = Column(String)


















