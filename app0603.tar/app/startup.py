import pandas as pd
import os
import numpy as np
from sqlalchemy import insert, text
from app.models import AiocdAnalysis, Orders, Bounce, Product, Inventory, Store, AssortmentOutput, Probability, AiocdAnalysisSales, IQVIASales, MSAAllCats, NewStoresAssortment
from databases import Database
import asyncpg

csv_folder = os.path.join(os.getcwd(),"../corpus_files")


#loading data to db
async def insert_into_db(model, file_name, postgres_db: Database,  batch_size=10):
    try:
        truncate_statement = text(f"TRUNCATE TABLE {model.__tablename__}")
        await postgres_db.execute(truncate_statement)
    except Exception as e:
        raise e
    try:
        # Load the CSV file into a DataFrame
        csv_file_path = os.path.join(csv_folder, file_name)
        for batch_number, chunk in enumerate(pd.read_csv(csv_file_path, chunksize=batch_size), start=1):
            # Handle data-specific conversions
            if file_name == "DateWiseBounce.csv" and 'date' in chunk:
                chunk['date'] = pd.to_datetime(chunk['date'], format='%Y%m%d')
            if file_name == "DateWiseOrders.csv" and 'tran_date' in chunk:
                chunk['tran_date'] = pd.to_datetime(chunk['tran_date'], format='%Y%m%d')
            if file_name == "InventoryData.csv" and 'date' in chunk:
                chunk['date'] = pd.to_datetime(chunk['date'], format='%Y%m%d')
                chunk['total_stock_value'] = chunk['total_stock_value'].str.replace(',', '').astype(float)
            if file_name == 'aiocd_sales.csv' or file_name == 'iqvia_sales.csv' or file_name == 'msa.csv':
                chunk['sap_id'] = chunk['sap_id'].astype(str)
                chunk = chunk.fillna('')
            if file_name == 'AIOCDAnalysis.csv' or file_name == 'assortment.csv':
                chunk['sap_id'] = chunk['sap_id'].astype(int)
            
            chunk = chunk.replace({np.nan: None})

            # # Remove duplicate rows
            # chunk = chunk.drop_duplicates()
            
            try:
                # Insert the current batch into the database
                await postgres_db.execute(insert(model).values(chunk.to_dict(orient="records")))
                print(f"Batch {batch_number} loaded for {model.__tablename__}")
            except asyncpg.exceptions.UniqueViolationError:
                continue
        
        print(f"{model.__tablename__} loaded successfully")
    except Exception as e:
        print(e)
        raise e


async def load_probability(postgres_db: Database):
    print("Loading probability")
    await insert_into_db(Probability, "probability.csv", postgres_db)


async def load_aiocd_analysis(postgres_db: Database):
    print("Loading aiocd_analysis")
    await insert_into_db(AiocdAnalysis, "AIOCDAnalysis.csv", postgres_db)


async def load_bounce(postgres_db: Database):
    print("Loading bounce")
    # file_name = "DateWiseBounce.csv"
    # csv_file_path = os.path.join(csv_folder, file_name)
    # df = pd.read_csv(csv_file_path)
    # df['date'] = pd.to_datetime(df['date'], format='%Y%m%d')
    # df.to_csv(csv_file_path, date_format='%Y%m%d', index=False)
    await insert_into_db(Bounce, "DateWiseBounce.csv", postgres_db)


async def load_orders(postgres_db: Database):
    print("Loading orders")
    # file_name = "DateWiseOrders.csv"
    # csv_file_path = os.path.join(csv_folder, file_name)
    # df = pd.read_csv(csv_file_path)
    # df['tran_date'] = pd.to_datetime(df['tran_date'], format='%Y%m%d')
    # df.to_csv(csv_file_path, date_format='%Y%m%d', index=False)
    await insert_into_db(Orders, "DateWiseOrders.csv", postgres_db)


async def load_inventory(postgres_db: Database):
    print("Loading inventory")
    # file_name = "InventoryData.csv"
    # csv_file_path = os.path.join(csv_folder, file_name)
    # df = pd.read_csv(csv_file_path)
    # df['date'] = pd.to_datetime(df['date'])
    # df.to_csv(csv_file_path, date_format='%Y%m%d', index=False)
    await insert_into_db(Inventory, "InventoryData.csv", postgres_db)


async def load_assortment_output(postgres_db: Database):
    print("Loading assortment")
    await insert_into_db(AssortmentOutput, "AssortmentSample.csv", postgres_db)


async def load_product(postgres_db: Database):
    print("Loading products")
    await insert_into_db(Product,  "productDump.csv", postgres_db)


async def load_store(postgres_db: Database):
    print("Loading store")
    await insert_into_db(Store, "StoreMaster.csv", postgres_db)


async def load_aiocd_sales(postgres_db: Database):
    print("Loading aiocd sales")
    await insert_into_db(AiocdAnalysisSales, "aiocd_sales.csv", postgres_db)


async def load_iqvia_sales(postgres_db: Database):
    print("Loading iqvia sales")
    await insert_into_db(IQVIASales, "iqvia_sales.csv", postgres_db)    


async def load_msa_all_cats(postgres_db: Database):
    print("Loading msa all cats")
    await insert_into_db(MSAAllCats, "msa.csv", postgres_db)    


async def load_new_store_assortment(postgres_db: Database):
    print("Loading new store assortment")
    await insert_into_db(NewStoresAssortment, "NewStoresAssortment.csv", postgres_db)    