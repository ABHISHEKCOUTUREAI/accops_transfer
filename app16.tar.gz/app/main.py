from contextlib import asynccontextmanager

import uvicorn
from db import ping_redis, redis_db, set_redis_state
from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from middleware import CacheMiddleware
from routes import (
    AjioRouter,
    BestSellerAPIContractRouter,
    DBRouter,
    HealthCheckRouter,
    SearchInteractionRouter,
    TopProductQueryRouter,
    TrendsRouter,
)
from settings import settings


@asynccontextmanager
async def lifespan(app: FastAPI):
    await ping_redis()
    if settings.redis_state:
        await set_redis_state(flush_db=True)

    print(
        "================================ Starting up ================================================="
    )
    yield

    print(
        "================================ Shutting down ================================================="
    )


app = FastAPI(
    title="fastfashion-api",
    docs_url="/docs",
    redoc_url=None,
    lifespan=lifespan,
    root_path=settings.root_path,
)


if settings.allow_cors_middleware:
    app.add_middleware(
        CORSMiddleware,
        allow_origins=[settings.allow_origins],
        allow_credentials=settings.allow_credentials,
        allow_methods=[settings.allow_methods],
        allow_headers=[settings.allow_headers],
    )


app.add_middleware(CacheMiddleware, redis_db=redis_db)


@app.get("/")
async def home():
    return {"Welcome to FastFashion API"}


app.include_router(AjioRouter)
app.include_router(TrendsRouter)
app.include_router(HealthCheckRouter)
app.include_router(SearchInteractionRouter)
app.include_router(TopProductQueryRouter)
app.include_router(BestSellerAPIContractRouter)
app.include_router(DBRouter)

if __name__ == "__main__":
    uvicorn.run(app, host="0.0.0.0", port=8000)
