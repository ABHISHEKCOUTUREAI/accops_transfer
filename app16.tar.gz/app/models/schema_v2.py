from enum import Enum as PyEnum

from sqlalchemy import (
    ARRAY,
    BigInteger,
    Column,
    DateTime,
    Float,
    Index,
    Integer,
    String,
)
from sqlalchemy.ext.declarative import declarative_base
from sqlalchemy.schema import PrimaryKeyConstraint

# from postgresql.dialects import ARRAY
Base = declarative_base()


# single source of truth for different time periods
class TimePeriod(PyEnum):
    SEVEN_DAYS = "7"
    FOURTEEN_DAYS = "14"
    TWENTY_EIGHT_DAYS = "28"
    NINETY_ONE_DAYS = "91"


# AJIO


class BestsellersAjio(Base):
    __tablename__ = "v2_ajio_bestsellers"

    similargrouplevel = Column(String)
    productid = Column(String, primary_key=True)
    pincode = Column(String, primary_key=True)
    num_past_days = Column(Integer, primary_key=True)
    sold_quantity = Column(BigInteger)
    healthy_live_days = Column(Integer)

    __table_args__ = (
        Index(f"{__tablename__}_pincode_idx", pincode),
        Index(f"{__tablename__}_productid_idx", productid),
    )


class AjioProductAttributesV2(Base):
    __tablename__ = "v2_ajio_product_attributes"
    productid = Column(String, primary_key=True)
    similargrouplevel = Column(String, primary_key=True)
    colorfamily = Column(String)
    fabrictype = Column(String)
    materialtype = Column(String)
    pattern = Column(String)
    sleevelength = Column(String)
    brandname = Column(String)
    occasion = Column(String)
    bodytype = Column(String)
    fit = Column(String)
    distress = Column(String)
    traditionalweave = Column(String)
    neckline = Column(String)
    hemline = Column(String)
    styletype = Column(String)
    title = Column(String)
    imgcode = Column(String)
    mrp = Column(Float)

    __table_args__ = (
        PrimaryKeyConstraint("productid", "similargrouplevel"),
        Index(f"idx_{__tablename__}_similargrouplevel", "similargrouplevel"),
        Index(f"idx_{__tablename__}_productid", "productid"),
        Index(f"idx_{__tablename__}_brandname", "brandname"),
        Index(f"idx_{__tablename__}_fabrictype", "fabrictype"),
    )


class AjioBrickDetailsV2(Base):
    __tablename__ = "v2_ajio_brick_details"
    similargrouplevel = Column(String, primary_key=True)
    l1name = Column(String)
    l2name = Column(String)
    brickname = Column(String)

    __table_args__ = (
        PrimaryKeyConstraint("similargrouplevel"),
        Index(f"idx_{__tablename__}_similargrouplevel", "similargrouplevel"),
        Index(f"idx_{__tablename__}_l1name", "l1name"),
        Index(f"idx_{__tablename__}_l2name", "l2name"),
        Index(f"idx_{__tablename__}_brickname", "brickname"),
    )


class AjioProductAttributeCombination(Base):
    __tablename__ = "v2_ajio_product_attribute_combinations"
    productid = Column(String, primary_key=True)
    attribute_name = Column(String, primary_key=True)
    attribute_value = Column(String, primary_key=True)
    similargrouplevel = Column(String)

    __table_args__ = (
        PrimaryKeyConstraint("productid", "attribute_name", "attribute_value"),
        Index(f"idx_{__tablename__}_productid", "productid"),
        Index(f"idx_{__tablename__}_similargrouplevel", "similargrouplevel"),
    )


class AjioNationalROS(Base):
    __tablename__ = "v2_ajio_national_ros"
    productid = Column(String, primary_key=True)
    num_past_days = Column(Integer, primary_key=True)
    similargrouplevel = Column(String)
    ros = Column(Float)
    sold_quantity = Column(BigInteger)

    __table_args__ = (
        PrimaryKeyConstraint("productid", "num_past_days"),
        Index(f"idx_{__tablename__}_productid", "productid"),
        Index(f"idx_{__tablename__}_num_past_days", "num_past_days"),
        Index(f"idx_{__tablename__}_similargrouplevel", "similargrouplevel"),
    )


class AjioDemographicDetailsV2(Base):
    __tablename__ = "v2_ajio_demographic_details"
    zone = Column(String)
    state = Column(String)
    districtsname = Column(String)
    city = Column(String)
    pincode = Column(String, primary_key=True)

    __table_args__ = (
        PrimaryKeyConstraint("pincode"),
        Index(f"idx_{__tablename__}_zone", "zone"),
        Index(f"idx_{__tablename__}_state", "state"),
        Index(f"idx_{__tablename__}_districtsname", "districtsname"),
        Index(f"idx_{__tablename__}_city", "city"),
    )


# TRENDS
class BestsellersTrends(Base):
    __tablename__ = "v2_trends_bestsellers"

    similargrouplevel = Column(String)
    productid = Column(String, primary_key=True)
    store_id = Column(String, primary_key=True)
    sold_quantity = Column(BigInteger)
    healthy_live_days = Column(Integer)
    num_past_days = Column(Integer)

    __table_args__ = (
        Index(f"{__tablename__}_store_id_idx", store_id),
        Index(f"{__tablename__}_productid_idx", productid),
    )


class TrendsProductAttributesV2(Base):
    __tablename__ = "v2_trends_product_attributes"
    productid = Column(String, primary_key=True)
    similargrouplevel = Column(String, primary_key=True)
    primarycolor = Column(String)
    fabrictype = Column(String)
    materialtype = Column(String)
    pattern = Column(String)
    sleeve = Column(String)
    fit = Column(String)
    neckline = Column(String)
    styletype = Column(String)
    fashion_grade_description = Column(String)
    mrp = Column(Float)
    brandname = Column(String)
    imgcode = Column(String)
    extension = Column(String)

    __table_args__ = (
        PrimaryKeyConstraint("productid", "similargrouplevel"),
        Index(f"idx_{__tablename__}_similargrouplevel", "similargrouplevel"),
        Index(f"idx_{__tablename__}_productid", "productid"),
    )


class TrendsBrickDetailsV2(Base):
    __tablename__ = "v2_trends_brick_details"
    similargrouplevel = Column(String, primary_key=True)
    mh_family_desc = Column(String)
    mh_class_desc = Column(String)
    brickname = Column(String)

    __table_args__ = (
        Index(f"idx_{__tablename__}_similargrouplevel", "similargrouplevel"),
        Index(f"idx_{__tablename__}_mh_family_desc", "mh_family_desc"),
        Index(f"idx_{__tablename__}_mh_class_desc", "mh_class_desc"),
        Index(f"idx_{__tablename__}_brickname", "brickname"),
    )


class TrendsProductAttributeCombination(Base):
    __tablename__ = "v2_trends_product_attribute_combinations"
    productid = Column(String, primary_key=True)
    attribute_name = Column(String, primary_key=True)
    attribute_value = Column(String, primary_key=True)
    similargrouplevel = Column(String)

    __table_args__ = (
        Index(f"idx_{__tablename__}_productid", "productid"),
        Index(f"idx_{__tablename__}_similargrouplevel", "similargrouplevel"),
    )


class TrendsNationalROS(Base):
    __tablename__ = "v2_trends_national_ros"
    productid = Column(String, primary_key=True)
    num_past_days = Column(Integer, primary_key=True)
    similargrouplevel = Column(String)
    ros = Column(Float)
    sold_quantity = Column(BigInteger)

    __table_args__ = (
        Index(f"idx_{__tablename__}_productid", "productid"),
        Index(f"idx_{__tablename__}_num_past_days", "num_past_days"),
        Index(f"idx_{__tablename__}_similargrouplevel", "similargrouplevel"),
    )


class TrendsStoreDetailsV2(Base):
    __tablename__ = "v2_trends_store_details"
    store_id = Column(String, primary_key=True)
    zone = Column(String)
    state = Column(String)
    districtsname = Column(String)
    city = Column(String)

    __table_args__ = (
        Index(f"idx_{__tablename__}_zone", "zone"),
        Index(f"idx_{__tablename__}_state", "state"),
        Index(f"idx_{__tablename__}_districtsname", "districtsname"),
        Index(f"idx_{__tablename__}_city", "city"),
    )


#  SEARCH
class SearchAttributes(Base):
    __tablename__ = "v2_most_searched_attributes"
    similargrouplevel = Column(String, primary_key=True)
    attribute_name = Column(String, primary_key=True)
    attribute_value = Column(String, primary_key=True)
    num_past_days = Column(Integer, primary_key=True)
    clicks = Column(BigInteger)

    __table_args__ = (
        PrimaryKeyConstraint(
            "similargrouplevel", "attribute_name", "attribute_value", "num_past_days"
        ),
        Index(f"{__tablename__}_similargrouplevel_idx", similargrouplevel),
    )


class SearchQueriesTrendsV2(Base):
    __tablename__ = "v2_search_queries_distributions_counts"
    search_query = Column(String, primary_key=True)
    search_type = Column(String, primary_key=True)
    num_past_days = Column(Integer, primary_key=True)
    last_searched_date = Column(DateTime)
    total_clicks_across_all_products_for_query = Column(BigInteger)
    search_distribution_across_weeks = Column(ARRAY(BigInteger))

    __table_args__ = (
        PrimaryKeyConstraint("search_query", "search_type", "num_past_days"),
        Index(f"{__tablename__}_num_past_days_idx", num_past_days),
        Index(
            f"{__tablename__}_total_clicks_idx",
            total_clicks_across_all_products_for_query,
        ),
    )


class SearchQueryInteractedProductsV2(Base):
    __tablename__ = "v2_search_queries_interacted_products_counts"
    search_query = Column(String, primary_key=True)
    search_type = Column(String, primary_key=True)
    num_past_days = Column(Integer, primary_key=True)
    productid = Column(String, primary_key=True)
    clicks_product = Column(BigInteger)

    __table_args__ = (
        PrimaryKeyConstraint(
            "search_query", "search_type", "num_past_days", "productid"
        ),
        Index(f"{__tablename__}_past_days_query", num_past_days, search_query),
    )


class SearchProductAttributesV2(Base):
    __tablename__ = "v2_search_product_attributes"
    productid = Column(String, primary_key=True)
    similargrouplevel = Column(String, primary_key=True)
    colorfamily = Column(String)
    fabrictype = Column(String)
    materialtype = Column(String)
    pattern = Column(String)
    sleevelength = Column(String)
    brandname = Column(String)
    occasion = Column(String)
    bodytype = Column(String)
    fit = Column(String)
    distress = Column(String)
    traditionalweave = Column(String)
    neckline = Column(String)
    hemline = Column(String)
    styletype = Column(String)
    title = Column(String)
    imgcode = Column(String)
    mrp = Column(Float)

    __table_args__ = (
        PrimaryKeyConstraint("productid", "similargrouplevel"),
        Index(f"idx_{__tablename__}_similargrouplevel", "similargrouplevel"),
        Index(f"idx_{__tablename__}_productid", "productid"),
    )


class SearchBrickDetailsV2(Base):
    __tablename__ = "v2_search_brick_details"
    similargrouplevel = Column(String, primary_key=True)
    l1name = Column(String)
    l2name = Column(String)
    brickname = Column(String)

    __table_args__ = (
        PrimaryKeyConstraint("similargrouplevel"),
        Index(f"idx_{__tablename__}_similargrouplevel", "similargrouplevel"),
    )


# DURATION SCHEMA


class PastDaysMetadata(Base):
    __tablename__ = "v2_past_days_metadata"
    start_date = Column(DateTime)
    end_date = Column(DateTime, primary_key=True)
    num_past_days = Column(Integer)
