import asyncio
import json
from collections import defaultdict

from db import psql_execute_single, redis_db
from models import (
    TrendsBestSellersMonth,
    TrendsBestSellersWeek,
    TrendsBrickDetails,
    TrendsProductAttributes,
    TrendsStoreDetails,
)
from sqlalchemy import Numeric, and_, cast, func, select
from static import indian_states, month_mapping

from .common_utils import (
    build_filter_condition,
    construct_filtered_query,
    sort_and_paginate,
)

# filters utils


def filter_non_null(result, index):
    values = list(
        set(
            val[index]
            for val in result
            if val[index] != "nan" and val[index] is not None
        )
    )
    return sorted(values)


async def calculate_time_delta_week_trends():
    cache_key = "min_max_bestseller_week_trends"
    cached_data = await redis_db.get(cache_key)
    if not cached_data:
        week_query = select(func.max(TrendsBestSellersWeek.week_of_year))
        week_result = await psql_execute_single(week_query)
        max_week = week_result[0][0]

        # Query to select the minimum week from the database
        min_week_query = select(func.min(TrendsBestSellersWeek.week_of_year))
        min_week_result = await psql_execute_single(min_week_query)
        min_week = min_week_result[0][0]

        await redis_db.set(cache_key, json.dumps([min_week, max_week]))

    print("time-delta loaded")


async def create_duration_filter_response_trends(request_data):
    # Determine the appropriate filter flag based on the presence of 'week' in the request data
    if request_data.get("nested_data", {}).get("duration", {}).get("week"):
        duration_filter_flag = "bestsellers_week"
    else:
        duration_filter_flag = "bestsellers_month"

    duration_filter = await build_filter_condition(
        type="trends",
        request_filters=request_data,
        filter_flag=duration_filter_flag,
    )

    if request_data.get("nested_data", {}).get("duration", {}).get("week"):
        duration_query = (
            select(TrendsBestSellersWeek.week_of_year)
            .distinct()
            .where(and_(*duration_filter))
        )
    else:
        duration_query = (
            select(TrendsBestSellersMonth.month_of_year)
            .distinct()
            .where(and_(*duration_filter))
        )

    duration_result = await psql_execute_single(duration_query)

    cache_key_min_max = "min_max_bestseller_week_trends"
    min_max_week = await redis_db.get(cache_key_min_max)
    if min_max_week:
        min_week, max_week = json.loads(min_max_week)
    else:
        await calculate_time_delta_week_trends()
        min_max_week = await redis_db.get(cache_key_min_max)
        min_week, max_week = json.loads(min_max_week)

    if request_data.get("nested_data", {}).get("duration", {}).get("week"):
        return {
            "duration": {
                "months": [],
                "week": list(range(min_week, max_week + 1)),
            }
        }
    else:
        # Sort the month values before mapping them
        sorted_month_values = sorted(
            set(val[0] for val in duration_result if val[0] not in ["nan", None])
        )

        # Map the sorted month values
        mapped_month_values = [month_mapping[month] for month in sorted_month_values]
        return {
            "duration": {
                "month": mapped_month_values,
                "week": list(range(min_week, max_week + 1)),
            }
        }


async def create_demographic_filter_response_trends(request_data):
    demographic_filter = await build_filter_condition(
        type="trends", request_filters=request_data, filter_flag="store_filters"
    )

    demographic_query = select(
        TrendsStoreDetails.zone_desc,
        TrendsStoreDetails.state,
        TrendsStoreDetails.city,
        TrendsStoreDetails.districtsname,
    ).where(and_(*demographic_filter))

    demographic_result = await psql_execute_single(demographic_query)

    return {
        "demographic": {
            "zone_desc": filter_non_null(demographic_result, 0),
            "state": filter_non_null(demographic_result, 1),
            "city": filter_non_null(demographic_result, 2),
            "district": filter_non_null(demographic_result, 3),
        }
    }


async def create_store_filter_response_trends(request_data):
    store_filter = await build_filter_condition(
        type="trends", request_filters=request_data, filter_flag="category"
    )

    store_query = select(
        TrendsStoreDetails.pin_code,
        TrendsStoreDetails.store_id,
    ).where(and_(*store_filter))

    store_result = await psql_execute_single(store_query)

    return {
        "store_filters": {
            "pincode": filter_non_null(store_result, 0),
            "store_id": filter_non_null(store_result, 1),
        }
    }


async def create_attributes_filter_response_trends(request_data):
    attribute_filter = await build_filter_condition(
        type="trends", request_filters=request_data, filter_flag="products"
    )

    category_filter = await build_filter_condition(
        type="trends", request_filters=request_data, filter_flag="category"
    )

    attribute_query = (
        select(
            TrendsProductAttributes.styletype,
            TrendsProductAttributes.neckline,
            TrendsProductAttributes.pattern,
            TrendsProductAttributes.fabrictype,
            TrendsProductAttributes.sleeve,
            TrendsProductAttributes.fit,
            TrendsProductAttributes.primarycolor,
        )
        .join(
            TrendsBrickDetails,
            TrendsBrickDetails.similargrouplevel
            == TrendsProductAttributes.similargrouplevel,
        )
        .where(and_(*attribute_filter, *category_filter))
    )

    attribute_result = await psql_execute_single(attribute_query)

    return {
        "attributes": {
            "styletype": filter_non_null(attribute_result, 0),
            "neckline": filter_non_null(attribute_result, 1),
            "pattern": filter_non_null(attribute_result, 2),
            "fabric_type": filter_non_null(attribute_result, 3),
            "sleeve": filter_non_null(attribute_result, 4),
            "fit": filter_non_null(attribute_result, 5),
            "color": filter_non_null(attribute_result, 6),
        }
    }


async def create_category_filter_response_trends(request_data):
    category_filter = await build_filter_condition(
        type="trends", request_filters=request_data, filter_flag="category"
    )

    category_query = select(
        TrendsBrickDetails.mh_family_desc,
        TrendsBrickDetails.mh_class_desc,
        TrendsBrickDetails.brickname,
    ).where(and_(*category_filter))

    category_result = await psql_execute_single(category_query)

    return {
        "category": {
            "category_family": filter_non_null(category_result, 0),
            "category_class": filter_non_null(category_result, 1),
            "category": filter_non_null(category_result, 2),
        }
    }


async def create_brand_filter_response_trends():
    brand_query = select(
        TrendsProductAttributes.brandname,
    ).distinct()

    result = await psql_execute_single(brand_query)
    response = {
        "brandname": {
            "brandname": [row[0] for row in result if row[0] not in ["nan", None]]
        }
    }
    return response


async def create_trends_filters_response(request_data):
    nested_data = request_data.get("nested_data", {})

    if "duration" in nested_data and nested_data["duration"]:
        result = await create_duration_filter_response_trends(request_data)
    elif "demographic" in nested_data and nested_data["demographic"]:
        result = await create_demographic_filter_response_trends(request_data)
    elif "store_filters" in nested_data and nested_data["store_filters"]:
        result = await create_store_filter_response_trends(request_data)
    elif "attributes" in nested_data and nested_data["attributes"]:
        result = await create_attributes_filter_response_trends(request_data)
    elif "category" in nested_data and nested_data["category"]:
        result = await create_category_filter_response_trends(request_data)
    elif "brandname" in nested_data:
        result = await create_brand_filter_response_trends()
    else:
        result = {}
    return result


async def get_trends_filters_service(
    request_data: dict,
):
    response = await create_trends_filters_response(request_data)

    return response


# bestsellers count utils


async def get_trends_bestsellers_count(request_data: dict):
    if request_data.get("nested_data", {}).get("duration", {}).get("week"):
        bestseller_filter = await build_filter_condition(
            type="trends", request_filters=request_data, filter_flag="bestsellers_week"
        )
        bestseller_query = await construct_filtered_query(
            TrendsBestSellersWeek, bestseller_filter, ["itemid", "districtsname"]
        )
    else:
        bestseller_filter = await build_filter_condition(
            type="trends", request_filters=request_data, filter_flag="bestsellers_month"
        )
        bestseller_query = await construct_filtered_query(
            TrendsBestSellersMonth, bestseller_filter, ["itemid", "districtsname"]
        )

    store_filter = await build_filter_condition(
        type="trends", request_filters=request_data, filter_flag="store_filters"
    )
    store_query = await construct_filtered_query(
        TrendsStoreDetails, store_filter, ["districtsname"]
    )

    product_filter = await build_filter_condition(
        type="trends", request_filters=request_data, filter_flag="products"
    )
    product_query = await construct_filtered_query(
        TrendsProductAttributes, product_filter, ["itemid", "similargrouplevel"]
    )

    brick_filter = await build_filter_condition(
        type="trends", request_filters=request_data, filter_flag="category"
    )
    brick_query = await construct_filtered_query(
        TrendsBrickDetails, brick_filter, ["similargrouplevel"]
    )

    query = (
        select(
            product_query.c.itemid,
        )
        .join(bestseller_query, bestseller_query.c.itemid == product_query.c.itemid)
        .join(
            store_query, store_query.c.districtsname == bestseller_query.c.districtsname
        )
        .join(
            brick_query,
            brick_query.c.similargrouplevel == product_query.c.similargrouplevel,
        )
        .group_by(product_query.c.itemid)
    )

    count_query = select(func.count(query.c.itemid)).select_from(query)
    result = await psql_execute_single(count_query)
    return {"total_count": result[0][0]}


async def create_trends_ros_query(bestseller_query, store_query, metadata):
    ros_query = (
        select(
            bestseller_query.c.itemid,
            getattr(bestseller_query.c, metadata["duration_col"]),
            bestseller_query.c.year,
            func.sum(getattr(bestseller_query.c, metadata["sold_quantity_col"])).label(
                metadata["sold_quantity_col"]
            ),
            func.avg(
                getattr(bestseller_query.c, metadata["healthy_live_days_col"])
            ).label(metadata["healthy_live_days_col"]),
        )
        .join(
            store_query, store_query.c.districtsname == bestseller_query.c.districtsname
        )
        .group_by(
            bestseller_query.c.itemid,
            getattr(bestseller_query.c, metadata["duration_col"]),
            bestseller_query.c.year,
        )
        .cte()
    )

    ros_query = (
        select(
            ros_query.c.itemid,
            ros_query.c.year,
            func.sum(ros_query.c[metadata["sold_quantity_col"]]).label(
                "total_sold_quantity"
            ),
            func.sum(ros_query.c[metadata["healthy_live_days_col"]]).label(
                "total_active_days"
            ),
            func.round(
                cast(
                    (
                        (
                            func.sum(ros_query.c[metadata["sold_quantity_col"]])
                            / func.sum(ros_query.c[metadata["healthy_live_days_col"]])
                        )
                        * 7
                    ),
                    Numeric,
                ),
                2,
            ).label("weekly_rate_of_sale"),
        ).group_by(ros_query.c.itemid, ros_query.c.year)
    ).cte()

    return ros_query


async def create_trends_bestsellers_query(request_data: dict):
    if request_data.get("nested_data", {}).get("duration", {}).get("week"):
        metadata = {
            "model": TrendsBestSellersWeek,
            "filter_flag": "bestsellers_week",
            "duration_col": "week_of_year",
            "sold_quantity_col": "sold_quantity_in_a_week",
            "healthy_live_days_col": "healthy_live_days_in_a_week",
        }
    else:
        metadata = {
            "model": TrendsBestSellersMonth,
            "filter_flag": "bestsellers_month",
            "duration_col": "month_of_year",
            "sold_quantity_col": "sold_quantity_in_a_month",
            "healthy_live_days_col": "healthy_live_days_in_a_month",
        }

    bestseller_filter = await build_filter_condition(
        type="trends", request_filters=request_data, filter_flag=metadata["filter_flag"]
    )
    bestseller_columns = [
        "itemid",
        "year",
        metadata["duration_col"],
        "districtsname",
        metadata["sold_quantity_col"],
        metadata["healthy_live_days_col"],
    ]
    bestseller_query = await construct_filtered_query(
        metadata["model"], bestseller_filter, bestseller_columns
    )

    store_filter = await build_filter_condition(
        type="trends", request_filters=request_data, filter_flag="store_filters"
    )
    store_query = await construct_filtered_query(
        TrendsStoreDetails, store_filter, ["districtsname"]
    )

    ros_query = await create_trends_ros_query(bestseller_query, store_query, metadata)

    product_columns = [
        "itemid",
        "brandname",
        "styletype",
        "primarycolor",
        "pattern",
        "fabrictype",
        "materialtype",
        "sleeve",
        "fit",
        "neckline",
        "imgcode",
        "extension",
        "mrp",
        "similargrouplevel",
    ]
    product_filter = await build_filter_condition(
        type="trends", request_filters=request_data, filter_flag="products"
    )
    product_query = await construct_filtered_query(
        TrendsProductAttributes, product_filter, product_columns
    )

    brick_columns = [
        "mh_family_desc",
        "mh_class_desc",
        "brickname",
        "similargrouplevel",
    ]
    brick_filter = await build_filter_condition(
        type="trends", request_filters=request_data, filter_flag="category"
    )
    brick_query = await construct_filtered_query(
        TrendsBrickDetails, brick_filter, brick_columns
    )

    query = (
        select(
            product_query.c.itemid,
            product_query.c.brandname,
            product_query.c.styletype,
            product_query.c.primarycolor,
            product_query.c.pattern,
            product_query.c.fabrictype,
            product_query.c.materialtype,
            product_query.c.sleeve,
            product_query.c.fit,
            product_query.c.neckline,
            product_query.c.imgcode,
            product_query.c.extension,
            brick_query.c.mh_family_desc,
            brick_query.c.mh_class_desc,
            brick_query.c.brickname,
            product_query.c.mrp,
            ros_query.c.total_sold_quantity,
            ros_query.c.weekly_rate_of_sale,
        )
        .join(ros_query, ros_query.c.itemid == product_query.c.itemid)
        .join(
            brick_query,
            brick_query.c.similargrouplevel == product_query.c.similargrouplevel,
        )
    )

    return query


async def get_trends_bestseller_service(request_data: dict):
    bestseller_query = await create_trends_bestsellers_query(request_data)

    paginated_bestseller_query = await sort_and_paginate(
        bestseller_query, request_data, "weekly_rate_of_sale"
    )

    result = await psql_execute_single(paginated_bestseller_query)

    result = {
        "rows": [
            {
                "itemid": row[0],
                "brandname": row[1],
                "styletype": row[2],
                "primarycolor": row[3],
                "pattern": row[4],
                "fabrictype": row[5],
                "materialtype": row[6],
                "sleeve": row[7],
                "fit": row[8],
                "neckline": row[9],
                "imgcode": row[10],
                "extension": row[11],
                "mh_family_desc": row[12],
                "mh_class_desc": row[13],
                "brickname": row[14],
                "mrp": round(float(row[15]), 2),
                "total_qty": int(row[16]),
                "weekly_rate_of_sale": int(row[17]),
            }
            for row in result
        ],
    }

    return result


# statewise sales trends
async def get_statewise_sales_trends(request_data: dict):
    if request_data.get("nested_data", {}).get("duration", {}).get("week"):
        best_sellers_schema = TrendsBestSellersWeek
        quantity_column = TrendsBestSellersWeek.sold_quantity_in_a_week
    else:
        best_sellers_schema = TrendsBestSellersMonth
        quantity_column = TrendsBestSellersMonth.sold_quantity_in_a_month

    sold_in_week_query = (
        select(
            TrendsStoreDetails.state,
            func.sum(quantity_column).label("quantity"),
        )
        .join(
            TrendsStoreDetails,
            TrendsStoreDetails.districtsname == best_sellers_schema.districtsname,
        )
        .group_by(TrendsStoreDetails.state)
    )

    maps_rows_state = await psql_execute_single(sold_in_week_query)
    map_data = [
        {
            "state": row[0],
            "statecode": indian_states.get(row[0].lower(), {}).get(
                "statecode", "Not Found"
            ),
            "quantity_sold": float(row[1]),
        }
        for row in maps_rows_state
    ]

    return map_data


# attrtibutes utils
async def get_attributes_bestsellers_trends(request_data, attribute: str):
    # Determine which schema to use based on the presence of "week" in the request data
    if request_data.get("nested_data", {}).get("duration", {}).get("week"):
        duration_filter_flag = "bestsellers_week"
        best_sellers_schema = TrendsBestSellersWeek
        quantity_column = TrendsBestSellersWeek.sold_quantity_in_a_week
    else:
        duration_filter_flag = "bestsellers_month"
        best_sellers_schema = TrendsBestSellersMonth
        quantity_column = TrendsBestSellersMonth.sold_quantity_in_a_month

    (
        product_filter,
        brick_filter,
        duration_filter,
        demographic_filter,
    ) = await asyncio.gather(
        build_filter_condition(
            type="trends", request_filters=request_data, filter_flag="products"
        ),
        build_filter_condition(
            type="trends", request_filters=request_data, filter_flag="category"
        ),
        build_filter_condition(
            type="trends",
            request_filters=request_data,
            filter_flag=duration_filter_flag,
        ),
        build_filter_condition(
            type="trends", request_filters=request_data, filter_flag="store_filters"
        ),
    )

    product_query = (
        select(
            getattr(TrendsProductAttributes, attribute),
            TrendsProductAttributes.itemid,
            TrendsProductAttributes.similargrouplevel,
        )
        .where(
            and_(
                *product_filter, getattr(TrendsProductAttributes, attribute) is not None
            )
        )
        .subquery()
    )

    brick_query = (
        select(TrendsBrickDetails.brickname, TrendsBrickDetails.similargrouplevel)
        .where(and_(*brick_filter))
        .subquery()
    )

    sold_in_week_query = (
        select(
            quantity_column.label("quantity_column"),
            best_sellers_schema.itemid,
            best_sellers_schema.districtsname,
        )
        .where(and_(*duration_filter))
        .subquery()
    )

    store_query = (
        select(
            TrendsStoreDetails.districtsname,
        )
        .where(and_(*demographic_filter))
        .subquery()
    )

    # join all three queries
    query = (
        select(
            getattr(product_query.c, attribute),
            brick_query.c.brickname,
            func.sum(sold_in_week_query.c.quantity_column).label("quantity"),
        )
        .join(
            brick_query,
            product_query.c.similargrouplevel == brick_query.c.similargrouplevel,
        )
        .join(sold_in_week_query, product_query.c.itemid == sold_in_week_query.c.itemid)
        .join(
            store_query,
            sold_in_week_query.c.districtsname == store_query.c.districtsname,
        )
        .group_by(
            getattr(product_query.c, attribute),
            brick_query.c.brickname,
        )
        .order_by(func.sum(sold_in_week_query.c.quantity_column).desc())
    )

    rows = await psql_execute_single(query)
    result = defaultdict(dict)
    for row in rows:
        if row[0] and row[0] != "nan":
            result[row[1]][row[0]] = float(row[2])

    return result
