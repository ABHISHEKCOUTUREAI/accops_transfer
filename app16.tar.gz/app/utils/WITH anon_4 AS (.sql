WITH anon_4 AS (
    SELECT
        anon_5.itemid AS itemid,
        anon_5.month_of_year AS month_of_year,
        anon_5.year AS year,
        sum(anon_5.sold_quantity_in_a_month) AS sold_quantity_in_a_month,
        avg(anon_5.healthy_live_days_in_a_month) AS healthy_live_days_in_a_month
    FROM
        (
            SELECT
                trends_bestsellers_month.itemid AS itemid,
                trends_bestsellers_month.year AS year,
                trends_bestsellers_month.month_of_year AS month_of_year,
                trends_bestsellers_month.districtsname AS districtsname,
                trends_bestsellers_month.sold_quantity_in_a_month AS sold_quantity_in_a_month,
                trends_bestsellers_month.healthy_live_days_in_a_month AS healthy_live_days_in_a_month
            FROM
                trends_bestsellers_month
            WHERE
                trends_bestsellers_month.month_of_year IN (2)
                AND trends_bestsellers_month.itemid IS NOT NULL
                AND trends_bestsellers_month.year IS NOT NULL
                AND trends_bestsellers_month.month_of_year IS NOT NULL
                AND trends_bestsellers_month.districtsname IS NOT NULL
                AND trends_bestsellers_month.sold_quantity_in_a_month IS NOT NULL
                AND trends_bestsellers_month.healthy_live_days_in_a_month IS NOT NULL
        ) AS anon_5
        JOIN (
            SELECT
                trends_store_details.districtsname AS districtsname
            FROM
                trends_store_details
            WHERE
                trends_store_details.districtsname IS NOT NULL
        ) AS anon_6 ON anon_6.districtsname = anon_5.districtsname
    GROUP BY
        anon_5.itemid,
        anon_5.month_of_year,
        anon_5.year
),
anon_3 AS (
    SELECT
        anon_4.itemid AS itemid,
        anon_4.year AS year,
        sum(anon_4.sold_quantity_in_a_month) AS total_sold_quantity,
        sum(anon_4.healthy_live_days_in_a_month) AS total_active_days,
        round(
            CAST(
                (
                    sum(anon_4.sold_quantity_in_a_month) / CAST(
                        sum(anon_4.healthy_live_days_in_a_month) AS NUMERIC
                    )
                ) * 7 AS NUMERIC
            ),
            2
        ) AS weekly_rate_of_sale
    FROM
        anon_4
    GROUP BY
        anon_4.itemid,
        anon_4.year
)
SELECT
    anon_1.itemid,
    anon_1.brandname,
    anon_1.styletype,
    anon_1.primarycolor,
    anon_1.pattern,
    anon_1.fabrictype,
    anon_1.materialtype,
    anon_1.sleeve,
    anon_1.fit,
    anon_1.neckline,
    anon_1.imgcode,
    anon_1.extension,
    anon_2.mh_family_desc,
    anon_2.mh_class_desc,
    anon_2.brickname,
    anon_1.mrp,
    anon_3.total_sold_quantity,
    anon_3.weekly_rate_of_sale
FROM
    (
        SELECT
            trends_product_attributes.itemid AS itemid,
            trends_product_attributes.brandname AS brandname,
            trends_product_attributes.styletype AS styletype,
            trends_product_attributes.primarycolor AS primarycolor,
            trends_product_attributes.pattern AS pattern,
            trends_product_attributes.fabrictype AS fabrictype,
            trends_product_attributes.materialtype AS materialtype,
            trends_product_attributes.sleeve AS sleeve,
            trends_product_attributes.fit AS fit,
            trends_product_attributes.neckline AS neckline,
            trends_product_attributes.imgcode AS imgcode,
            trends_product_attributes.extension AS extension,
            trends_product_attributes.mrp AS mrp,
            trends_product_attributes.similargrouplevel AS similargrouplevel
        FROM
            trends_product_attributes
        WHERE
            trends_product_attributes.itemid IS NOT NULL
            AND trends_product_attributes.brandname IS NOT NULL
            AND trends_product_attributes.styletype IS NOT NULL
            AND trends_product_attributes.primarycolor IS NOT NULL
            AND trends_product_attributes.pattern IS NOT NULL
            AND trends_product_attributes.fabrictype IS NOT NULL
            AND trends_product_attributes.materialtype IS NOT NULL
            AND trends_product_attributes.sleeve IS NOT NULL
            AND trends_product_attributes.fit IS NOT NULL
            AND trends_product_attributes.neckline IS NOT NULL
            AND trends_product_attributes.imgcode IS NOT NULL
            AND trends_product_attributes.extension IS NOT NULL
            AND trends_product_attributes.mrp IS NOT NULL
            AND trends_product_attributes.similargrouplevel IS NOT NULL
    ) AS anon_1
    JOIN anon_3 ON anon_3.itemid = anon_1.itemid
    JOIN (
        SELECT
            trendsbrickdetails.mh_family_desc AS mh_family_desc,
            trendsbrickdetails.mh_class_desc AS mh_class_desc,
            trendsbrickdetails.brickname AS brickname,
            trendsbrickdetails.similargrouplevel AS similargrouplevel
        FROM
            trendsbrickdetails
        WHERE
            trendsbrickdetails.mh_family_desc IS NOT NULL
            AND trendsbrickdetails.mh_class_desc IS NOT NULL
            AND trendsbrickdetails.brickname IS NOT NULL
            AND trendsbrickdetails.similargrouplevel IS NOT NULL
    ) AS anon_2 ON anon_2.similargrouplevel = anon_1.similargrouplevel