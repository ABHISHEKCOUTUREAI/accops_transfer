REDIS_WRITE_ERROR = "Error while writing to redis: "
REDIS_CONNECT_ERROR = "Error while connecting to redis: "
AJIO_BESTSELLERS_CSV = "ajio_bestsellers.csv"
AJIO_BESTSELLERS_WEEK_CSV = "ajio_bestsellers_week.csv"
AJIO_BESTSELLERS_MONTH_CSV = "ajio_bestsellers_month.csv"
AJIO_BRICK_DETAILS_CSV = "ajio_brick_details.csv"
AJIO_DEMOGRAPHIC_DETAILS_CSV = "ajio_demographic_details.csv"
AJIO_PRODUCT_ATTRIBUTES_CSV = "ajio_product_attributes.csv"
AJIO_SEARCH_QUERIES_TOP_INTERACTED_PRODUCTS_CSV = (
    "ajio_search_queries_top_interacted_products.csv"
)
TRENDS_BESTSELLERS_CSV = "trends_bestsellers.csv"
TRENDS_BESTSELLERS_WEEK_CSV = "trends_bestsellers_week.csv"
TRENDS_BESTSELLERS_MONTH_CSV = "trends_bestsellers_month.csv"
TRENDS_BRICK_DETAILS_CSV = "trends_brick_details.csv"
TRENDS_PRODUCT_ATTRIBUTES_CSV = "trends_product_attributes.csv"
TRENDS_STORE_DETAILS_CSV = "trends_store_details.csv"
CALENDER_DATA_CSV = "calender_data.csv"
POSTGRES_MAX_CONNECTIONS_ERROR = "Too many connections error: "

INITAL_FILTER_PAYLOAD = {"nested_data": {"duration": {"month": []}}}
INTERNAL_SERVER_ERROR = "Internal Server Error"