from fastapi import APIRouter, Depends
from fastapi.responses import JSONResponse
from static import setup_logging
from utils import (
    get_most_interacted_products_service,
    get_search_interaction_filters_service,
    get_top_interacted_brands_service,
    get_top_interacted_categories_service,
    get_top_interacted_products_service,
    get_top_interacted_queries_service,
    get_top_interacted_titles_service,
    get_top_queries_by_session_service,
    get_top_serch_queries_service,
)

TopProductQueryRouter = APIRouter(tags=["Ajio Search Interactions"])


@TopProductQueryRouter.post("/search-interactions-filters")
async def get_search_interaction_filters(
    request_data: dict,
    logger=Depends(setup_logging),
):
    try:
        return await get_search_interaction_filters_service(request_data)
    except Exception as e:
        logger.error(e, exc_info=True)
        return JSONResponse(content={"error": "Internal Server Error"}, status_code=500)


@TopProductQueryRouter.post("/top-interacted-queries")
async def top_interacted_queries(
    request_data: dict,
    logger=Depends(setup_logging),
):
    try:
        return await get_top_interacted_queries_service(request_data)
    except Exception as e:
        logger.error(e, exc_info=True)
        return JSONResponse(content={"error": "Internal Server Error"}, status_code=500)


@TopProductQueryRouter.post("/top-interacted-categories")
async def top_interacted_categories(
    request_data: dict,
    logger=Depends(setup_logging),
):
    try:
        return await get_top_interacted_categories_service(request_data)
    except Exception as e:
        logger.error(e, exc_info=True)
        return JSONResponse(content={"error": "Internal Server Error"}, status_code=500)


@TopProductQueryRouter.post("/top-interacted-products")
async def top_interacted_products(
    request_data: dict,
    logger=Depends(setup_logging),
):
    try:
        return await get_top_interacted_products_service(request_data)
    except Exception as e:
        logger.error(e, exc_info=True)
        return JSONResponse(content={"error": "Internal Server Error"}, status_code=500)


@TopProductQueryRouter.post("/top-interacted-brands")
async def top_interacted_brands(
    request_data: dict,
    logger=Depends(setup_logging),
):
    try:
        return await get_top_interacted_brands_service(request_data)
    except Exception as e:
        logger.error(e, exc_info=True)
        return JSONResponse(content={"error": "Internal Server Error"}, status_code=500)


@TopProductQueryRouter.post("/top-interacted-product-titles")
async def top_interacted_titles(
    request_data: dict,
    logger=Depends(setup_logging),
):
    try:
        return await get_top_interacted_titles_service(request_data)
    except Exception as e:
        logger.error(e, exc_info=True)
        return JSONResponse(content={"error": "Internal Server Error"}, status_code=500)


@TopProductQueryRouter.post("/top-queries-session")
async def get_top_queries_by_session(
    request_data: dict,
    logger=Depends(setup_logging),
):
    try:
        return await get_top_queries_by_session_service(request_data)
    except Exception as e:
        logger.error(e, exc_info=True)
        return JSONResponse(content={"error": "Internal Server Error"}, status_code=500)


@TopProductQueryRouter.post("/top-search-queries")
async def top_search_queries(
    request_data: dict,
    logger=Depends(setup_logging),
):
    try:
        return await get_top_serch_queries_service(request_data)
    except Exception as e:
        logger.error(e, exc_info=True)
        return JSONResponse(content={"error": "Internal Server Error"}, status_code=500)


@TopProductQueryRouter.post("/most-interacted-products")
async def most_interacted_products(
    request_data: dict,
    logger=Depends(setup_logging),
):
    try:
        return await get_most_interacted_products_service(request_data)
    except Exception as e:
        logger.error(e, exc_info=True)
        return JSONResponse(content={"error": "Internal Server Error"}, status_code=500)
