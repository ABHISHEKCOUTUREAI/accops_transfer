import asyncio
from typing import Callable, Union

from db import psql_execute_multiple, psql_execute_single
from fastapi.responses import JSONResponse
from models import (
    AjioAttributeImages,
    AjioBrickDetailsV2,
    AjioBrickImages,
    AjioDemographicDetailsV2,
    AjioL2Images,
    AjioNationalROS,
    AjioProductAttributeCombination,
    AjioProductAttributesV2,
    AttributeQueryParams,
    BestsellersAjio,
    BestsellersTrends,
    BrickFilters,
    CategoryQueryParams,
    DemographyFilters,
    FilterQuery,
    GlobalBrickDetails,
    GlobalDemographicDetails,
    GlobalProductAttributeCombination,
    PastDaysMetadata,
    ProductAttributeFilters,
    ProductQueryParams,
    TrendsAttributeImages,
    TrendsBrickDetailsV2,
    TrendsBrickImages,
    TrendsL2Images,
    TrendsNationalROS,
    TrendsProductAttributeCombination,
    TrendsProductAttributesV2,
    TrendsStoreDetailsV2,
)
from sqlalchemy import Numeric, and_, cast, func, select
from static import attribute_key_display_mapping, product_attribute_filters

from .common_utils import (
    construct_filtered_query,
)


def split_string_by_comma(string: str) -> list:
    """
    Args:
        string: String to split by comma
    Returns:
        list of strings
    """
    if not string:
        return None
    result = []
    for value in string.split(","):
        if value.strip():
            result.append(value)

    return result


def _select(table, condition, columns: list):
    """
    Args:
        table: sqlalchemy model
        condition: list of conditions
        columns: list of column names
    Returns:
        sqlalchemy query
    """
    return select(*[getattr(table, column) for column in columns]).where(
        and_(*condition)
    )


def form_condition(table, filters: dict) -> list:
    """
    Args:
        table: sqlalchemy model
        filters: dict (key: column name, value: value to filter)
    Returns:
        list of conditions

    """
    condition = []
    for key, value in filters.items():
        if value is None:
            continue
        elif isinstance(value, list):
            condition.append(getattr(table, key).in_(value))
        else:
            condition.append(getattr(table, key) == value)
    return condition


def check_demographic_filter(query_params):
    if (
        query_params.zone
        or query_params.state
        or query_params.district
        or query_params.city
        or query_params.pincode
        or query_params.store_id
    ):
        return True
    return False


async def get_similargrouplevel(
    query_params: BrickFilters,
    table: Union[AjioBrickDetailsV2, TrendsBrickDetailsV2] = AjioBrickDetailsV2,
    filter_columns: list = ["l1name", "l2name", "brickname"],
) -> str:
    """
    Args:
        query_params: Brick Filters
        table: sqlalchemy model (AjioBrickDetailsV2/TrendsBrickDetailsV2)
        filter_columns: list of column
    Returns:
        similargrouplevel
    """
    brick_condition = form_condition(
        table,
        {
            filter_columns[0]: query_params.gender,
            filter_columns[1]: query_params.category,
            filter_columns[2]: query_params.brickname,
        },
    )

    brick_query = _select(table, brick_condition, ["similargrouplevel"])

    result = await psql_execute_single(brick_query)

    if len(result) == 0:
        return None

    return result[0][0]


async def create_attributes_query(
    query_params: AttributeQueryParams,
    attribute_image_query,
    attribute_image_columns: list = ["imgcode", "productid"],
    brick_table: Union[AjioBrickDetailsV2, TrendsBrickDetailsV2] = AjioBrickDetailsV2,
    brick_columns: list = ["l1name", "l2name", "brickname"],
    ros_table: Union[AjioNationalROS, TrendsNationalROS] = AjioNationalROS,
    sales_table: Union[BestsellersAjio, BestsellersTrends] = BestsellersAjio,
    product_attribute_combination_table: Union[
        AjioProductAttributeCombination, TrendsProductAttributeCombination
    ] = AjioProductAttributeCombination,
    demographic_table: Union[
        AjioDemographicDetailsV2, TrendsStoreDetailsV2
    ] = AjioDemographicDetailsV2,
):
    similargrouplevel = await get_similargrouplevel(
        query_params, brick_table, brick_columns
    )

    if not similargrouplevel:
        return None

    if check_demographic_filter(query_params):
        bestsellers_condition = form_condition(
            sales_table,
            {
                "num_past_days": query_params.num_days.value,
                "similargrouplevel": similargrouplevel,
            },
        )
        bestsellers_query = _select(
            sales_table,
            bestsellers_condition,
            ["productid", "pincode", "sold_quantity"],
        ).cte()

        demographic_condition = form_condition(
            demographic_table,
            {
                "zone": split_string_by_comma(query_params.zone),
                "state": split_string_by_comma(query_params.state),
                "districtsname": split_string_by_comma(query_params.district),
                "city": split_string_by_comma(query_params.city),
                "pincode": split_string_by_comma(query_params.pincode),
            },
        )
        demographic_query = _select(
            demographic_table, demographic_condition, ["pincode"]
        ).cte()

        sold_quantity_query = (
            select(
                bestsellers_query.c.productid,
                func.sum(bestsellers_query.c.sold_quantity).label("sold_quantity"),
            )
            .join(
                demographic_query,
                demographic_query.c.pincode == bestsellers_query.c.pincode,
            )
            .group_by(bestsellers_query.c.productid)
            .cte()
        )

    else:
        condition = form_condition(
            ros_table,
            {
                "num_past_days": query_params.num_days.value,
                "similargrouplevel": similargrouplevel,
            },
        )
        sold_quantity_query = _select(
            ros_table,
            condition,
            ["productid", "sold_quantity"],
        ).cte()

    if query_params.attribute == "all":
        filters = {"similargrouplevel": similargrouplevel}
    else:
        filters = {
            "similargrouplevel": similargrouplevel,
            "attribute_name": query_params.attribute,
        }

    attribute_combination_condition = form_condition(
        product_attribute_combination_table, filters
    )

    attribute_combination_query = _select(
        product_attribute_combination_table,
        attribute_combination_condition,
        ["productid", "attribute_name", "attribute_value"],
    ).cte()

    attribute_sold_query = (
        select(
            attribute_combination_query.c.attribute_name,
            attribute_combination_query.c.attribute_value,
            func.sum(sold_quantity_query.c.sold_quantity).label("sold_quantity"),
        )
        .join(
            sold_quantity_query,
            sold_quantity_query.c.productid == attribute_combination_query.c.productid,
        )
        .group_by(
            attribute_combination_query.c.attribute_name,
            attribute_combination_query.c.attribute_value,
        )
        .cte()
    )

    attribute_sold_query = select(
        attribute_sold_query.c.attribute_name,
        attribute_sold_query.c.attribute_value,
        attribute_sold_query.c.sold_quantity,
        *[
            getattr(attribute_image_query.c, column)
            for column in attribute_image_columns
        ],
    ).join(
        attribute_image_query,
        and_(
            attribute_image_query.c.attribute_name
            == attribute_sold_query.c.attribute_name,
            attribute_image_query.c.attribute_value
            == attribute_sold_query.c.attribute_value,
        ),
    )

    if query_params.filter == "both":
        return attribute_sold_query

    attribute_sold_query = attribute_sold_query.cte()

    query = select(
        attribute_sold_query.c.attribute_name,
        attribute_sold_query.c.attribute_value,
        *[
            getattr(attribute_sold_query.c, column)
            for column in attribute_image_columns
        ],
        func.rank()
        .over(
            partition_by=attribute_sold_query.c.attribute_name,
            order_by=attribute_sold_query.c.sold_quantity.desc(),
        )
        .label("rank"),
    ).cte()

    start = (query_params.page - 1) * query_params.page_size
    end = start + query_params.page_size

    query = select(
        query.c.attribute_name,
        query.c.attribute_value,
        *[getattr(query.c, column) for column in attribute_image_columns],
    ).where(and_(query.c.rank > start, query.c.rank <= end))

    return query


async def create_attributes_images_query(
    query_params: AttributeQueryParams,
    images_table: Union[
        AjioAttributeImages, TrendsAttributeImages
    ] = AjioAttributeImages,
    image_table_filter_columns: list = ["l1name", "l2name", "brickname"],
    image_table_select_columns: list = [
        "attribute_name",
        "attribute_value",
        "imgcode",
        "productid",
    ],
):
    condition = form_condition(
        images_table,
        {
            image_table_filter_columns[0]: query_params.gender,
            image_table_filter_columns[1]: query_params.category,
            image_table_filter_columns[2]: query_params.brickname,
        },
    )

    images_query = _select(
        images_table,
        condition,
        image_table_select_columns,
    ).cte()

    return images_query


async def create_ajio_attributes_query(query_params: AttributeQueryParams):
    attribute_image_query = await create_attributes_images_query(
        query_params,
        images_table=AjioAttributeImages,
        image_table_filter_columns=["l1name", "l2name", "brickname"],
        image_table_select_columns=[
            "attribute_name",
            "attribute_value",
            "imgcode",
            "productid",
        ],
    )

    query = await create_attributes_query(
        query_params,
        attribute_image_query,
        attribute_image_columns=["imgcode", "productid"],
        brick_table=AjioBrickDetailsV2,
        brick_columns=["l1name", "l2name", "brickname"],
        ros_table=AjioNationalROS,
        sales_table=BestsellersAjio,
        product_attribute_combination_table=AjioProductAttributeCombination,
        demographic_table=AjioDemographicDetailsV2,
    )

    return query


async def create_trends_attributes_query(query_params: AttributeQueryParams):
    attribute_image_query = await create_attributes_images_query(
        query_params,
        images_table=TrendsAttributeImages,
        image_table_select_columns=[
            "attribute_name",
            "attribute_value",
            "imgcode",
            "productid",
            "extension",
        ],
    )

    query = await create_attributes_query(
        query_params,
        attribute_image_query,
        attribute_image_columns=["imgcode", "productid", "extension"],
        brick_table=TrendsBrickDetailsV2,
        brick_columns=["mh_family_desc", "mh_class_desc", "brickname"],
        sales_table=BestsellersTrends,
        product_attribute_combination_table=TrendsProductAttributeCombination,
        demographic_table=TrendsStoreDetailsV2,
    )

    return query


async def execute_attributes_query(query_params: AttributeQueryParams):
    if query_params.filter == "ajio":
        query = await create_ajio_attributes_query(query_params)
    elif query_params.filter == "trends":
        query = await create_trends_attributes_query(query_params)
    elif query_params.filter == "both":
        ajio_query = await create_ajio_attributes_query(query_params)
        trends_query = await create_trends_attributes_query(query_params)

        ajio_query = ajio_query.cte()
        trends_query = trends_query.cte()

        joined_query = (
            select(
                ajio_query.c.attribute_name,
                ajio_query.c.attribute_value,
                (ajio_query.c.sold_quantity + trends_query.c.sold_quantity).label(
                    "sold_quantity"
                ),
                ajio_query.c.imgcode,
                ajio_query.c.productid,
            )
            .join(
                trends_query,
                and_(
                    ajio_query.c.attribute_name == trends_query.c.attribute_name,
                    ajio_query.c.attribute_value == trends_query.c.attribute_value,
                ),
            )
            .cte()
        )

        # rank it based on the sum of sold quantity
        query = select(
            joined_query.c.attribute_name,
            joined_query.c.attribute_value,
            joined_query.c.imgcode,
            joined_query.c.productid,
            func.rank()
            .over(
                partition_by=joined_query.c.attribute_name,
                order_by=joined_query.c.sold_quantity.desc(),
            )
            .label("rank"),
        ).cte("query")

        start = (query_params.page - 1) * query_params.page_size
        end = start + query_params.page_size

        query = select(
            query.c.attribute_name,
            query.c.attribute_value,
            query.c.imgcode,
            query.c.productid,
        ).where(and_(query.c.rank > start, query.c.rank <= end))

    if query is None:
        return JSONResponse(
            status_code=404,
            content={"error": "No data found for the given filters"},
        )

    results = await psql_execute_single(query)

    response = {}

    for row in results:
        if row[0] not in response:
            response[row[0]] = {"attribute": row[0], "values": []}
        attribute_value = {
            "name": row[1],
            "imgcode": row[2],
            "productid": row[3],
        }
        if query_params.filter == "trends":
            attribute_value["extension"] = row[4]
        response[row[0]]["values"].append(attribute_value)

    return [value for _, value in response.items()]


def form_brick_query(query_params: BrickFilters, table, columns: list):
    """
    Args:
        query_params: Brick Filters
        table: sqlalchemy model
        columns: list of column
    Returns:
        sqlalchemy query, list of conditions
    """
    brick_condition = form_condition(
        table,
        {
            columns[0]: split_string_by_comma(query_params.gender),
            columns[1]: split_string_by_comma(query_params.category),
            columns[2]: split_string_by_comma(query_params.brickname),
        },
    )

    brick_query = _select(table, brick_condition, ["similargrouplevel"]).cte(
        f"brick_query_{table}"
    )

    return brick_query, brick_condition


def form_attribute_query(
    query_params: ProductAttributeFilters,
    table,
    columns: list,
    price_column: str = "price",
):
    """
    Args:
        query_params: ProductQueryParams
        table: Product Attributes sqlalchemy model
        columns: Columns to select from Product Attributes table.
    Returns:
        sqlalchemy query, list of conditions
    """
    product_filters = {}
    for attribute in product_attribute_filters:
        if getattr(query_params, attribute) and (attribute in table.__table__.columns):
            values = []
            for value in getattr(query_params, attribute).split(","):
                if value.strip():
                    values.append(value)

            product_filters[attribute] = values

    attribute_condition = form_condition(table, product_filters)

    if query_params.min_price is not None:
        attribute_condition.append(
            getattr(table, price_column) >= query_params.min_price
        )
    if query_params.max_price is not None:
        attribute_condition.append(
            getattr(table, price_column) <= query_params.max_price
        )

    attribute_query = _select(table, attribute_condition, columns).cte(
        f"attribute_query_{table}"
    )
    return attribute_query, attribute_condition


def form_demographic_query(
    query_params: DemographyFilters, table, select_column: str = "pincode"
):
    """
    Args:
        query_params: ProductQueryParams
        table: Demographic Details sqlalchemy model
        select_column: Column to select from Demographic Details table
    Returns:
        sqlalchemy
    """
    if query_params.store_id:
        if table == TrendsStoreDetailsV2:
            demographic_condition = form_condition(
                table,
                {
                    "zone": split_string_by_comma(query_params.zone),
                    "state": split_string_by_comma(query_params.state),
                    "city": split_string_by_comma(query_params.city),
                    "districtsname": split_string_by_comma(query_params.district),
                    "pincode": split_string_by_comma(query_params.pincode),
                    "store_id": split_string_by_comma(query_params.store_id),
                },
            )
            demographic_query = _select(
                table, demographic_condition, [select_column]
            ).cte(f"demographic_query_{table}")
        else:
            demographic_condition = form_condition(
                table,
                {
                    "zone": split_string_by_comma(query_params.zone),
                    "state": split_string_by_comma(query_params.state),
                    "city": split_string_by_comma(query_params.city),
                    "districtsname": split_string_by_comma(query_params.district),
                    "pincode": split_string_by_comma(query_params.pincode),
                },
            )
            pincode_query = (
                select(TrendsStoreDetailsV2.pincode).where(
                    TrendsStoreDetailsV2.store_id.in_(
                        split_string_by_comma(query_params.store_id)
                    )
                )
            ).cte("pincode_query")
            ajio_demographic_query = (
                select(AjioDemographicDetailsV2.pincode)
                .where(and_(*demographic_condition))
                .cte("ajio_demographic_query")
            )
            demographic_query = (
                select(ajio_demographic_query.c.pincode).join(
                    pincode_query,
                    ajio_demographic_query.c.pincode == pincode_query.c.pincode,
                )
            ).cte(f"demographic_query_{table}")
    else:
        demographic_condition = form_condition(
            table,
            {
                "zone": split_string_by_comma(query_params.zone),
                "state": split_string_by_comma(query_params.state),
                "city": split_string_by_comma(query_params.city),
                "districtsname": split_string_by_comma(query_params.district),
                "pincode": split_string_by_comma(query_params.pincode),
            },
        )
        demographic_query = _select(table, demographic_condition, [select_column]).cte(
            f"demographic_query_{table}"
        )
    return demographic_query


async def create_ros_query_from_national_ros(
    query_params: ProductQueryParams,
    ros_table: Union[AjioNationalROS, TrendsNationalROS] = AjioNationalROS,
    product_table: Union[
        AjioProductAttributesV2, TrendsProductAttributesV2
    ] = AjioProductAttributesV2,
    brick_table: Union[AjioBrickDetailsV2, TrendsStoreDetailsV2] = AjioBrickDetailsV2,
    product_columns: list = [
        "productid",
        "title",
        "brandname",
        "mrp",
        "imgcode",
        "price",
    ],
    brick_filters: list = ["l1name", "l2name", "brickname"],
    ros_label: str = "ajio_weekly_ros",
    price_column: str = "price",
):
    """
    This function creates the query for ajio/trends from national_ros table when no demography filter is present

    Args:
        query_params: ProductQueryParams
        ros_table: ROS Table Model (AjioNationalROS/TrendsNationalROS)
        product_table: Product Attributes Table Model (AjioProductAttributesV2/TrendsProductAttributesV2)
        brick_table: Brick Details Table Model (AjioBrickDetailsV2/TrendsStoreDetailsV2)
        product_columns: Columns to select from Product Attributes Table
        brick_filters: Filters to form the brick query
        ros_label: Label for the ROS column

    Returns:
        sqlalchemy query
    """
    base_condition = form_condition(
        ros_table, {"num_past_days": query_params.num_days.value}
    )

    base_columns = ["productid", "similargrouplevel", "ros"]
    brick_query, brick_condition = form_brick_query(
        query_params, brick_table, brick_filters
    )
    attribute_query, _ = form_attribute_query(
        query_params,
        product_table,
        product_columns,
        price_column,
    )
    base_query = (_select(ros_table, base_condition, base_columns)).cte(
        f"ros_base_query_{ros_table}"
    )

    if len(brick_condition) > 0:
        base_query = (
            select(base_query.c.productid, base_query.c.ros)
            .join(
                brick_query,
                brick_query.c.similargrouplevel == base_query.c.similargrouplevel,
            )
            .cte(f"filtered_query_{ros_table}")
        )

    final_query = select(
        attribute_query,
        func.round(cast(base_query.c.ros, Numeric), 2).label(ros_label),
    ).join(
        attribute_query,
        attribute_query.c.productid == base_query.c.productid,
    )

    return final_query


async def create_ros_query(
    query_params: ProductQueryParams,
    ros_table: Union[BestsellersAjio, BestsellersTrends] = BestsellersAjio,
    demographic_table: Union[
        AjioDemographicDetailsV2, TrendsStoreDetailsV2
    ] = AjioDemographicDetailsV2,
    product_table: Union[
        AjioProductAttributesV2, TrendsProductAttributesV2
    ] = AjioProductAttributesV2,
    brick_table: Union[AjioBrickDetailsV2, TrendsStoreDetailsV2] = AjioBrickDetailsV2,
    ros_columns: list = [
        "productid",
        "pincode",
        "similargrouplevel",
        "sold_quantity",
        "healthy_live_days",
    ],
    product_columns: list = [
        "productid",
        "title",
        "brandname",
        "mrp",
        "imgcode",
        "price",
    ],
    brick_filters: list = ["l1name", "l2name", "brickname"],
    demographic_join_column: str = "pincode",
    ros_label: str = "ajio_weekly_ros",
    price_column: str = "price",
):
    """
    Args:
        query_params: ProductQueryParams
        ros_table: Bestsellers Table Model (BestsellersAjio/BestsellersTrends)
        product_table: Product Attributes Table Model (AjioProductAttributesV2/TrendsProductAttributesV2)
        brick_table: Brick Details Table Model (AjioBrickDetailsV2/TrendsStoreDetailsV2)
        ros_columns: Columns to select from Bestsellers Table
        product_columns: Columns to select from Product Attributes Table
        brick_filters: Filters to form the brick query
        demographic_join_column: Column to join with demographic table
        ros_label: Label for the ROS column
        price_column: Column name for price
    Returns:
        sqlalchemy query
    """
    base_condition = form_condition(
        ros_table, {"num_past_days": query_params.num_days.value}
    )
    base_query = _select(
        ros_table,
        base_condition,
        ros_columns,
    ).cte(f"sold_base_query_{ros_table}")
    brick_query, brick_condition = form_brick_query(
        query_params, brick_table, brick_filters
    )
    attribute_query, attribute_condition = form_attribute_query(
        query_params, product_table, product_columns, price_column
    )
    demographic_query = form_demographic_query(
        query_params, demographic_table, demographic_join_column
    )
    base_query = (
        select(
            base_query.c.productid,
            base_query.c.similargrouplevel,
            base_query.c.sold_quantity,
            base_query.c.healthy_live_days,
        )
        .join(
            demographic_query,
            demographic_query.c[demographic_join_column]
            == base_query.c[demographic_join_column],
        )
        .cte(f"demographic_filtered_query_{demographic_table}")
    )

    if len(brick_condition) > 0:
        base_query = (
            select(
                base_query.c.productid,
                base_query.c.sold_quantity,
                base_query.c.healthy_live_days,
            )
            .join(
                brick_query,
                brick_query.c.similargrouplevel == base_query.c.similargrouplevel,
            )
            .cte(f"brick_filtered_base_query_{brick_table}")
        )

    if len(attribute_condition) > 0:
        base_query = (
            select(
                base_query.c.productid,
                base_query.c.sold_quantity,
                base_query.c.healthy_live_days,
            )
            .join(
                attribute_query,
                attribute_query.c.productid == base_query.c.productid,
            )
            .cte(f"attribute_filtered_base_query_{product_table}")
        )

    query = (
        select(
            base_query.c.productid,
            func.round(
                (
                    func.sum(base_query.c.sold_quantity)
                    * 7
                    / func.avg(base_query.c.healthy_live_days)
                ),
                2,
            ).label(ros_label),
        )
        .join(
            attribute_query,
            attribute_query.c.productid == base_query.c.productid,
        )
        .group_by(base_query.c.productid)
        .cte(f"query_{ros_table}")
    )

    final_query = select(attribute_query, query.c[ros_label]).join(
        attribute_query,
        attribute_query.c.productid == query.c.productid,
    )

    return final_query


async def execute_products_query(query_params: ProductQueryParams) -> list:
    """
    combines and executes the queries to get the bestseller products
    """
    if check_demographic_filter(query_params):
        ajio_ros_query = await create_ros_query(
            query_params,
            ros_table=BestsellersAjio,
            demographic_table=AjioDemographicDetailsV2,
            product_table=AjioProductAttributesV2,
            brick_table=AjioBrickDetailsV2,
            ros_columns=[
                "productid",
                "pincode",
                "similargrouplevel",
                "sold_quantity",
                "healthy_live_days",
            ],
            product_columns=[
                "productid",
                "title",
                "brandname",
                "mrp",
                "imgcode",
                "price",
            ],
            brick_filters=["l1name", "l2name", "brickname"],
            demographic_join_column="pincode",
            ros_label="ajio_weekly_ros",
        )
        trends_ros_query = await create_ros_query(
            query_params,
            ros_table=BestsellersTrends,
            demographic_table=TrendsStoreDetailsV2,
            product_table=TrendsProductAttributesV2,
            brick_table=TrendsBrickDetailsV2,
            ros_columns=[
                "productid",
                "store_id",
                "similargrouplevel",
                "sold_quantity",
                "healthy_live_days",
            ],
            product_columns=["productid", "brandname", "mrp", "imgcode", "extension"],
            brick_filters=["mh_family_desc", "mh_class_desc", "brickname"],
            demographic_join_column="store_id",
            ros_label="trends_weekly_ros",
            price_column="mrp",
        )
    else:
        ajio_ros_query = await create_ros_query_from_national_ros(
            query_params,
            ros_table=AjioNationalROS,
            product_table=AjioProductAttributesV2,
            brick_table=AjioBrickDetailsV2,
            product_columns=[
                "productid",
                "title",
                "brandname",
                "mrp",
                "imgcode",
                "price",
            ],
            brick_filters=["l1name", "l2name", "brickname"],
            ros_label="ajio_weekly_ros",
        )
        trends_ros_query = await create_ros_query_from_national_ros(
            query_params,
            ros_table=TrendsNationalROS,
            product_table=TrendsProductAttributesV2,
            brick_table=TrendsBrickDetailsV2,
            product_columns=["productid", "brandname", "mrp", "imgcode", "extension"],
            brick_filters=["mh_family_desc", "mh_class_desc", "brickname"],
            ros_label="trends_weekly_ros",
            price_column="mrp",
        )

    ajio_ros_query = ajio_ros_query.cte("ajio_ros_query")
    trends_ros_query = trends_ros_query.cte("trends_ros_query")

    if query_params.sort_order == "asc":
        ajio_order = ajio_ros_query.c.ajio_weekly_ros.asc()
        trends_order = trends_ros_query.c.trends_weekly_ros.asc()
    else:
        ajio_order = ajio_ros_query.c.ajio_weekly_ros.desc()
        trends_order = trends_ros_query.c.trends_weekly_ros.desc()

    if query_params.filter == "ajio":
        final_query = (
            select(ajio_ros_query)
            .order_by(ajio_order)
            .limit(query_params.page_size)
            .offset((query_params.page - 1) * query_params.page_size)
        )
        result = await psql_execute_single(final_query)
        return [
            {
                "item_id": row[0],
                "title": row[1],
                "brandname": row[2],
                "mrp": row[3],
                "image_code": row[4],
                "price": row[5],
                "ajio_weekly_ros": row[6],
            }
            for row in result
        ]
    elif query_params.filter == "trends":
        final_query = (
            select(trends_ros_query)
            .order_by(trends_order)
            .limit(query_params.page_size)
            .offset((query_params.page - 1) * query_params.page_size)
        )
        result = await psql_execute_single(final_query)
        return [
            {
                "item_id": row[0],
                "brandname": row[1],
                "mrp": row[2],
                "image_code": row[3],
                "extension": row[4],
                "trends_weekly_ros": row[5],
            }
            for row in result
        ]
    elif query_params.filter == "both":
        final_query = select(ajio_ros_query, trends_ros_query.c.trends_weekly_ros).join(
            trends_ros_query,
            ajio_ros_query.c.productid == trends_ros_query.c.productid,
        )
        if query_params.sort_key == "ajio_weekly_ros":
            final_query = (
                final_query.order_by(ajio_order)
                .limit(query_params.page_size)
                .offset((query_params.page - 1) * query_params.page_size)
            )
        else:
            final_query = (
                final_query.order_by(trends_order)
                .limit(query_params.page_size)
                .offset((query_params.page - 1) * query_params.page_size)
            )
        result = await psql_execute_single(final_query)
        return [
            {
                "item_id": row[0],
                "title": row[1],
                "brandname": row[2],
                "mrp": row[3],
                "image_code": row[4],
                "price": row[5],
                "ajio_weekly_ros": row[6],
                "trends_weekly_ros": row[7],
            }
            for row in result
        ]
    else:
        if query_params.sort_key == "ajio_weekly_ros":
            ajio_ros_query = (
                select(ajio_ros_query)
                .order_by(ajio_order)
                .limit(query_params.page_size)
                .offset((query_params.page - 1) * query_params.page_size)
            ).cte("limited_ajio_ros_query")
            final_query = select(
                ajio_ros_query, trends_ros_query.c.trends_weekly_ros
            ).join(
                trends_ros_query,
                ajio_ros_query.c.productid == trends_ros_query.c.productid,
                isouter=True,
            )
            result = await psql_execute_single(final_query)
            return [
                {
                    "item_id": row[0],
                    "title": row[1],
                    "brandname": row[2],
                    "mrp": row[3],
                    "image_code": row[4],
                    "price": row[5],
                    "ajio_weekly_ros": row[6],
                    "trends_weekly_ros": row[7],
                }
                for row in result
            ]
        elif query_params.sort_key == "trends_weekly_ros":
            trends_ros_query = (
                select(trends_ros_query)
                .order_by(trends_order)
                .limit(query_params.page_size)
                .offset((query_params.page - 1) * query_params.page_size)
            ).cte("limited_trends_ros_query")
            final_query = select(
                trends_ros_query,
                ajio_ros_query.c.ajio_weekly_ros,
            ).join(
                ajio_ros_query,
                ajio_ros_query.c.productid == trends_ros_query.c.productid,
                isouter=True,
            )
            result = await psql_execute_single(final_query)
            return [
                {
                    "item_id": row[0],
                    "brandname": row[1],
                    "mrp": row[2],
                    "image_code": row[3],
                    "extension": row[4],
                    "trends_weekly_ros": row[5],
                    "ajio_weekly_ros": row[6],
                }
                for row in result
            ]


async def get_v2_products_filters(query_params, models):
    
    product_params = [
        "brandname",
        "fabrictype",
        "sleevelength",
        "fit",
        "colorfamily",
        "pattern",
        "neckline",
        "styletype",
        "hemline",
        "traditionalweave",
        "distress",
        "materialtype",
        "bodytype",
        "occasion",
        "mrp"
    ]
    
    trends_product_params = [
        "colorfamily",
        "fabrictype",
        "materialtype",
        "pattern",
        "sleevelength",
        "fit",
        "neckline",
        "styletype",
        "brandname",
    ]

    product_filters = []
    parameters  = trends_product_params if query_params.filter == "trends" else product_params
    # Iterate over product parameters and build filters dynamically
    for param in parameters:
        param_value = getattr(query_params, param, None)
        if param_value:
            product_filters.append(
                and_(
                    models["products"].attribute_name == param,
                    models["products"].attribute_value.in_(param_value.split(",")),
                )
            )


    # TODO:
    # if query_params.min_price is not None:
    #     product_filters.append(AjioProductAttributesV2.mrp >= query_params.min_price)
    # if query_params.max_price is not None:
    #     product_filters.append(AjioProductAttributesV2.mrp <= query_params.max_price)

    product_query = select(
        models["products"].attribute_name,
        models["products"].attribute_value,
        models["products"].similargrouplevel,
    ).where(and_(*product_filters))


    if query_params.filter == "trends":
        brick_filters = form_condition(
            models["bricks"],
            {
                "mh_family_desc": query_params.gender,
                "mh_class_desc": query_params.category,
                "brickname": query_params.brickname,
            },
        )
        mrp_model = TrendsProductAttributesV2
    else:
        brick_filters = form_condition(
            models["bricks"],
            {
                "l1name": query_params.gender,
                "l2name": query_params.category,
                "brickname": query_params.brickname,
            },
        )
        mrp_model = AjioProductAttributesV2

    brick_query = await construct_filtered_query(
        models["bricks"], list(brick_filters), ["similargrouplevel"]
    )


    final_product_query = (
        select(
            product_query.c.attribute_name,
            product_query.c.attribute_value,
        )
        .group_by(
            product_query.c.attribute_name,
            product_query.c.attribute_value,
        )
        .join(
            brick_query,
            brick_query.c.similargrouplevel == product_query.c.similargrouplevel,
        )
    ).cte()

    final_product_query = select(
        final_product_query.c.attribute_name,
        func.array_agg(final_product_query.c.attribute_value).label("attribute_values"),
    ).group_by(final_product_query.c.attribute_name)

    mrp_query = select(func.max(mrp_model.mrp), func.min(mrp_model.mrp))

    # TODO:
    mrp_filter = []


    query_list = [final_product_query, mrp_query]
    result = await psql_execute_multiple(query_list)

    response = {}
    for row in result[0]:
        response[row[0]] = row[1]

    response["price"] = {"max_price": result[1][0][0], "min_price": result[1][0][1]}

    return response


async def get_v2_bricks_filters(query_params, models):
    if query_params.filter == "trends":
        brick_filters = form_condition(
            models["bricks"],
            {
                "mh_family_desc": query_params.gender,
                "mh_class_desc": query_params.category,
                "brickname": query_params.brickname,
            },
        )
        brick_columns = ["mh_family_desc", "mh_class_desc", "brickname"]
    else:
        brick_filters = form_condition(
            models["bricks"],
            {
                "l1name": query_params.gender,
                "l2name": query_params.category,
                "brickname": query_params.brickname,
            },
        )
        brick_columns = ["l1name", "l2name", "brickname"]

    query_list = []
    for column in brick_columns:
        brick_query = await construct_filtered_query(
            models["bricks"], list(brick_filters), distinct_column=column
        )
        query_list.append(brick_query)

    result = await psql_execute_multiple(query_list)

    response = {}
    for index, column in enumerate(brick_columns):
        response[column] = [row[0] for row in result[index]]
    return response


async def get_v2_demographic_filters(query_params, models):
    demographic_filters = form_condition(
        models["demographics"],
        {
            "zone": query_params.zone,
            "state": query_params.state,
            "city": query_params.city,
            "pincode": query_params.pincode,
        },
    )

    demography_columns = ["zone", "state", "city", "districtsname", "pincode"]
    query_list = []
    for column in demography_columns:
        demographic_query = await construct_filtered_query(
            models["demographics"], list(demographic_filters), distinct_column=column
        )
        query_list.append(demographic_query)

    result = await psql_execute_multiple(query_list)

    response = {}
    for index, column in enumerate(demography_columns):
        response[column] = [row[0] for row in result[index]]
    return response


async def get_v2_duration_filters():
    duration_query = select(
        PastDaysMetadata.start_date,
        PastDaysMetadata.end_date,
        PastDaysMetadata.num_past_days,
    )

    result = await psql_execute_single(duration_query)

    response = []
    for row in result:
        response.append(
            {
                "start_date": row[0],
                "end_date": row[1],
                "num_past_days": row[2],
            }
        )
    return response


async def get_v2_filters(query_params: FilterQuery):
    # List of methods to call
    if query_params.filter == "both":
        models = {
            "bricks": GlobalBrickDetails,
            "demographics": GlobalDemographicDetails,
            "products": GlobalProductAttributeCombination,
        }
    elif query_params.filter == "ajio":
        models = {
            "bricks": AjioBrickDetailsV2,
            "demographics": AjioDemographicDetailsV2,
            "products": AjioProductAttributeCombination,
        }
    elif query_params.filter == "trends":
        models = {
            "bricks": TrendsBrickDetailsV2,
            "demographics": TrendsStoreDetailsV2,
            "products": TrendsProductAttributeCombination,
        }

    methods: list[Callable] = [
        get_v2_duration_filters,
        lambda: get_v2_bricks_filters(query_params, models),
        lambda: get_v2_demographic_filters(query_params, models),
        lambda: get_v2_products_filters(query_params, models),
    ]
    # Call each method and gather results
    results = await asyncio.gather(*(method() for method in methods))

    duration_result, brick_result, demographic_result, product_result = results

    # List of attribute values
    attribute_values = {
        "duration": duration_result,
        "l1name": brick_result.get("l1name", []),
        "l2name": brick_result.get("l2name", []),
        "brickname": brick_result.get("brickname", []),
        "zone": demographic_result.get("zone", []),
        "state": demographic_result.get("state", []),
        "city": demographic_result.get("city", []),
        "district": demographic_result.get("districtsname", []),
        "pincode": demographic_result.get("pincode", []),
        "colorfamily": product_result.get("colorfamily", []),
        "fabrictype": product_result.get("fabrictype", []),
        "neckline": product_result.get("neckline", []),
        "occasion": product_result.get("occasion", []),
        "pattern": product_result.get("pattern", []),
        "styletype": product_result.get("styletype", []),
        "sleevelength": product_result.get("sleevelength", []),
        "fit": product_result.get("fit", []),
        "hemline": product_result.get("hemline", []),
        "traditionalweave": product_result.get("traditionalweave", []),
        "distress": product_result.get("distress", []),
        "materialtype": product_result.get("materialtype", []),
        "bodytype": product_result.get("bodytype", []),
        "price": {
            "max_price": product_result.get("price", {}).get("max_price"),
            "min_price": product_result.get("price", {}).get("min_price"),
        }
        if product_result.get("price")
        else None,
    }

    # Construct the combined result using a loop
    combined_result = {}
    for key, display_name in attribute_key_display_mapping.items():
        values = attribute_values.get(key)
        if values:
            combined_result[key] = {
                "name": key,
                "displayName": display_name,
                "values": values,
            }

    return combined_result


async def get_l2_categories(query_params: CategoryQueryParams):
    # load the category images
    if query_params.filter == "ajio":
        query = select(
            AjioL2Images.l2name, AjioL2Images.productid, AjioL2Images.imgcode
        ).where(AjioL2Images.l1name == query_params.gender)
        result = await psql_execute_single(query)

        result = [
            {
                "category": row[0],
                "productid": row[1],
                "imgcode": row[2],
            }
            for row in result
        ]
    else:
        query = select(
            TrendsL2Images.l2name,
            TrendsL2Images.productid,
            TrendsL2Images.imgcode,
            TrendsL2Images.extension,
        ).where(TrendsL2Images.l1name == query_params.gender)
        result = await psql_execute_single(query)

        result = [
            {
                "category": row[0],
                "productid": row[1],
                "imgcode": row[2],
                "extension": row[3],
            }
            for row in result
        ]

    return result


async def get_brick_categories(query_params: CategoryQueryParams):
    if query_params.filter == "ajio":
        query = select(
            AjioBrickImages.brickname,
            AjioBrickImages.productid,
            AjioBrickImages.imgcode,
        ).where(
            and_(
                AjioBrickImages.l1name == query_params.gender,
                AjioBrickImages.l2name == query_params.category,
            )
        )
        result = await psql_execute_single(query)
        result = [
            {"brickname": row[0], "productid": row[1], "imgcode": row[2]}
            for row in result
        ]
    else:
        query = select(
            TrendsBrickImages.brickname,
            TrendsBrickImages.productid,
            TrendsBrickImages.imgcode,
            TrendsBrickDetailsV2.extension,
        ).where(
            and_(
                TrendsBrickImages.l1name == query_params.gender,
                TrendsBrickImages.l2name == query_params.category,
            )
        )
        result = await psql_execute_single(query)
        result = [
            {
                "brickname": row[0],
                "productid": row[1],
                "imgcode": row[2],
                "extension": row[3],
            }
            for row in result
        ]

    return result
