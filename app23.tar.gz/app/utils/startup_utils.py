import json
import os

import asyncpg
import gcsfs
import pandas as pd
from db import (
    psql_execute_single,
    redis_db,
)
from fastapi.responses import JSONResponse
from google.oauth2 import service_account
from models import (
    AjioBestSellers,
    AjioBestSellersMonth,
    AjioBestSellersWeek,
    AjioBrickDetails,
    AjioDemographicDetails,
    AjioProductAttributes,
    AjioSearchQueriesTopInteractedProducts,
    TrendsBestSellers,
    TrendsBestSellersMonth,
    TrendsBestSellersWeek,
    TrendsBrickDetails,
    TrendsProductAttributes,
    TrendsStoreDetails,
    AjioProductAttributesV2,
    AjioBrickDetailsV2,
)
from settings import settings
from sqlalchemy import func, insert, literal_column, select, text, distinct
from static import REDIS_WRITE_ERROR

from static import api_contract_search_attributes

csv_folder = os.path.join(os.getcwd(), settings.corpus_path)

# Load google search interactions data into the database


async def truncate_table(model, postgres_db):
    try:
        truncate_statement = text(f"TRUNCATE TABLE {model.__tablename__}")
        await postgres_db.execute(truncate_statement)
        print(f"Truncated {model.__tablename__}")
    except Exception as e:
        print(f"Failed to truncate {model.__tablename__}")
        raise e


async def process_csv_file(file_name, folder_path, model, postgres_db):
    try:
        print(f"Loading data from file '{file_name}'")

        df = pd.read_csv(os.path.join(folder_path, file_name), skiprows=2)

        data_records = await extract_data_records(df, file_name)

        df_processed = await process_data_records(data_records)

        await insert_into_db(df_processed, model, postgres_db, file_name)

    except Exception as e:
        print(e)
        raise


async def extract_data_records(df, file_name):
    data_records = []
    flag = 0

    for related_name, related_number in df.iterrows():
        if related_name == "RISING":
            flag = 1
            continue

        category = file_name.split(".")[0]
        related_name_str = str(related_name)

        if flag == 0:
            top_searches = (
                1
                if isinstance(related_number["TOP"], str)
                else int(related_number["TOP"])
            )

            data_records.append(
                {
                    "category": category,
                    "related_top_searches": related_name_str,
                    "number_of_top_searches": top_searches,
                    "related_rising_searches": None,
                    "number_of_rising_searches": None,
                }
            )

        elif flag == 1:
            rising_searches = (
                100
                if isinstance(related_number["TOP"], str)
                else int(related_number["TOP"])
            )

            data_records[-1]["related_rising_searches"] = related_name_str
            data_records[-1]["number_of_rising_searches"] = rising_searches

    return data_records


async def process_data_records(data_records):
    df_processed = pd.DataFrame(data_records)
    df_processed = df_processed.fillna(
        {"number_of_top_searches": 0, "number_of_rising_searches": 0}
    )
    df_processed["number_of_top_searches"] = df_processed[
        "number_of_top_searches"
    ].astype(int)
    df_processed["number_of_rising_searches"] = df_processed[
        "number_of_rising_searches"
    ].astype(int)
    return df_processed


async def insert_into_db(df_processed, model, postgres_db, category):
    await postgres_db.execute(
        insert(model).values(df_processed.to_dict(orient="records"))
    )
    print(
        f"Data loaded for category '{category}' in {model.__table__.name} with {len(df_processed)} records"
    )


async def load_google_search_interactions(model, postgres_db=None):
    try:
        await truncate_table(model, postgres_db)

        folder_path = os.path.join(csv_folder, "google_search_interactions")
        csv_files = [f for f in os.listdir(folder_path) if f.endswith(".csv")]

        for file_name in csv_files:
            if file_name in [
                "Sports, Games & Equipment.csv",
                "Handbags.csv",
                "Dupatta Set.csv",
                "Anklets.csv",
                "Boxers.csv",
                "Casual Shoes.csv",
                "Jackets.csv",
            ]:
                continue

            await process_csv_file(file_name, folder_path, model, postgres_db)

        return JSONResponse(
            status_code=200,
            content={
                "message": f"Data loaded successfully into {model.__table__.name}"
            },
        )
    except Exception as e:
        print(e)
        raise e


# load corpus data into the database
async def validate_data(chunk, model):
    if model == AjioBestSellers:
        chunk["year"] = chunk["year"].astype(int)
        chunk["quarter_of_year"] = chunk["quarter_of_year"].astype(int)
        chunk["month_of_year"] = chunk["month_of_year"].astype(int)
        chunk["week_of_year"] = chunk["week_of_year"].astype(int)
        chunk["pincode"] = chunk["pincode"].astype(str)
        chunk["productid"] = chunk["productid"].astype(str)
        chunk["mrp"] = chunk["mrp"].astype(float)
        chunk["availablequantity_in_a_week"] = chunk[
            "availablequantity_in_a_week"
        ].astype(int)
        chunk["sold_quantity_in_a_week"] = chunk["sold_quantity_in_a_week"].astype(int)
    if model == AjioProductAttributes:
        chunk["productid"] = chunk["productid"].astype(str)
        chunk["similargrouplevel"] = chunk["similargrouplevel"].astype(str)
        chunk["colorfamily"] = chunk["colorfamily"].astype(str)
        chunk["fabrictype"] = chunk["fabrictype"].astype(str)
        chunk["materialtype"] = chunk["materialtype"].astype(str)
        chunk["pattern"] = chunk["pattern"].astype(str)
        chunk["sleevelength"] = chunk["sleevelength"].astype(str)
        chunk["brandname"] = chunk["brandname"].astype(str)
        chunk["occasion"] = chunk["occasion"].astype(str)
        chunk["bodytype"] = chunk["bodytype"].astype(str)
        chunk["fit"] = chunk["fit"].astype(str)
        chunk["distress"] = chunk["distress"].astype(str)
        chunk["traditionalweave"] = chunk["traditionalweave"].astype(str)
        chunk["neckline"] = chunk["neckline"].astype(str)
        chunk["hemline"] = chunk["hemline"].astype(str)
        chunk["styletype"] = chunk["styletype"].astype(str)
        chunk["title"] = chunk["title"].astype(str)
        chunk["imgcode"] = chunk["imgcode"].astype(str)
    if model == AjioBrickDetails:
        chunk["similargrouplevel"] = chunk["similargrouplevel"].astype(str)
        chunk["l1name"] = chunk["l1name"].astype(str)
        chunk["l2name"] = chunk["l2name"].astype(str)
        chunk["brickname"] = chunk["brickname"].astype(str)
    if model == AjioDemographicDetails:
        chunk["pincode"] = chunk["pincode"].astype(str)
        chunk["state"] = chunk["state"].astype(str)
        chunk["city"] = chunk["city"].astype(str)
        chunk["districtsname"] = chunk["districtsname"].astype(str)
        chunk["zone"] = chunk["zone"].astype(str)
    if model == TrendsBestSellers:
        chunk["year"] = chunk["year"].astype(float).fillna(0).astype(int)
        chunk["quarter_of_year"] = (
            chunk["quarter_of_year"].astype(float).fillna(0).astype(int)
        )
        chunk["month_of_year"] = (
            chunk["month_of_year"].astype(float).fillna(0).astype(int)
        )
        chunk["week_of_year"] = (
            chunk["week_of_year"].astype(float).fillna(0).astype(int)
        )
        chunk["itemid"] = chunk["itemid"].astype(str)
        chunk["store_id"] = chunk["store_id"].astype(str)
        chunk["sold_quantity_in_a_week"] = (
            chunk["sold_quantity_in_a_week"].astype(float).fillna(0).astype(int)
        )
        chunk["availablequantity_in_a_week"] = (
            chunk["availablequantity_in_a_week"].astype(float).fillna(0).astype(int)
        )
    if model == TrendsProductAttributes:
        chunk["itemid"] = chunk["itemid"].astype(str)
        chunk["similargrouplevel"] = chunk["similargrouplevel"].astype(str)
        chunk["primarycolor"] = chunk["primarycolor"].astype(str)
        chunk["fabrictype"] = chunk["fabrictype"].astype(str)
        chunk["materialtype"] = chunk["materialtype"].astype(str)
        chunk["pattern"] = chunk["pattern"].astype(str)
        chunk["sleeve"] = chunk["sleeve"].astype(str)
        chunk["fit"] = chunk["fit"].astype(str)
        chunk["neckline"] = chunk["neckline"].astype(str)
        chunk["styletype"] = chunk["styletype"].astype(str)
        chunk["fashion_grade_description"] = chunk["fashion_grade_description"].astype(
            str
        )
        chunk["mrp"] = chunk["mrp"].astype(float)
        chunk["imgcode"] = chunk["imgcode"].astype(str)
        chunk["brandname"] = chunk["brandname"].astype(str)
        chunk["extension"] = chunk["extension"].astype(str)
    if model == TrendsBrickDetails:
        chunk["similargrouplevel"] = chunk["similargrouplevel"].astype(str)
        chunk["mh_family_desc"] = chunk["mh_family_desc"].astype(str)
        chunk["mh_class_desc"] = chunk["mh_class_desc"].astype(str)
        chunk["brickname"] = chunk["brickname"].astype(str)
    if model == TrendsStoreDetails:
        chunk["store_id"] = chunk["store_id"].astype(str)
        chunk["pin_code"] = chunk["pin_code"].astype(str)
        chunk["format_cd"] = chunk["format_cd"].astype(str)
        chunk["format_desc"] = chunk["format_desc"].astype(str)
        chunk["city"] = chunk["city"].astype(str)
        chunk["region"] = chunk["region"].astype(str)
        chunk["location"] = chunk["location"].astype(str)
        chunk["store_short_name"] = chunk["store_short_name"].astype(str)
        chunk["store_area"] = chunk["store_area"].astype(str)
        chunk["state"] = chunk["state"].astype(str)
        chunk["zone_desc"] = chunk["zone_desc"].astype(str)
        chunk["store_class_desc"] = chunk["store_class_desc"].astype(str)
        chunk["districtsname"] = chunk["districtsname"].astype(str)
    if model == AjioBestSellersWeek:
        chunk["year"] = chunk["year"].astype(int)
        chunk["week_of_year"] = chunk["week_of_year"].astype(int)
        chunk["pincode"] = chunk["pincode"].astype(str)
        chunk["productid"] = chunk["productid"].astype(str)
        chunk["start_date"] = chunk["start_date"].astype(str)
        chunk["end_date"] = chunk["end_date"].astype(str)
        chunk["sold_quantity_in_a_week"] = chunk["sold_quantity_in_a_week"].astype(int)
        chunk["healthy_live_days_in_a_week"] = chunk[
            "healthy_live_days_in_a_week"
        ].astype(int)
    if model == AjioBestSellersMonth:
        chunk["year"] = chunk["year"].astype(int)
        chunk["quarter_of_year"] = chunk["quarter_of_year"].astype(int)
        chunk["month_of_year"] = chunk["month_of_year"].astype(int)
        chunk["pincode"] = chunk["pincode"].astype(str)
        chunk["productid"] = chunk["productid"].astype(str)
        chunk["sold_quantity_in_a_month"] = chunk["sold_quantity_in_a_month"].astype(
            int
        )
        chunk["healthy_live_days_in_a_month"] = chunk[
            "healthy_live_days_in_a_month"
        ].astype(int)
    if model == TrendsBestSellersWeek:
        chunk["year"] = chunk["year"].astype(float).fillna(0).astype(int)
        chunk["week_of_year"] = (
            chunk["week_of_year"].astype(float).fillna(0).astype(int)
        )
        chunk["store_id"] = chunk["store_id"].astype(str)
        chunk["itemid"] = chunk["itemid"].astype(str)
        chunk["start_date"] = chunk["start_date"].astype(str)
        chunk["end_date"] = chunk["end_date"].astype(str)
        chunk["sold_quantity_in_a_week"] = chunk["sold_quantity_in_a_week"].astype(int)
        chunk["healthy_live_days_in_a_week"] = chunk[
            "healthy_live_days_in_a_week"
        ].astype(int)
    if model == TrendsBestSellersMonth:
        chunk["year"] = chunk["year"].astype(int)
        chunk["quarter_of_year"] = chunk["quarter_of_year"].astype(int)
        chunk["month_of_year"] = chunk["month_of_year"].astype(int)
        chunk["store_id"] = chunk["store_id"].astype(str)
        chunk["itemid"] = chunk["itemid"].astype(str)
        chunk["sold_quantity_in_a_month"] = chunk["sold_quantity_in_a_month"].astype(
            int
        )
        chunk["healthy_live_days_in_a_month"] = chunk[
            "healthy_live_days_in_a_month"
        ].astype(int)

    return chunk


async def load_data(batch_size, f, model, postgres_db):
    for batch_number, chunk in enumerate(
        pd.read_csv(f, chunksize=batch_size, sep=",", index_col=False),
        start=1,
    ):
        try:
            if model == AjioSearchQueriesTopInteractedProducts and batch_number > 2:
                break

            chunk = await validate_data(chunk, model)

            await postgres_db.execute(
                insert(model).values(chunk.to_dict(orient="records"))
            )
            print(f"\rBatch {batch_number} loaded for {model.__tablename__}", end="")

        except asyncpg.exceptions.UniqueViolationError:
            continue

    print(f"\n{model.__tablename__} loaded successfully")

    return JSONResponse(
        status_code=200,
        content={"message": f"Data loaded successfully into {model.__tablename__}"},
    )


async def load_corpus(
    model,
    file_name,
    postgres_db,
    batch_size=settings.data_upload_batch_size,
    gcs_bucket_name=None,
    gcs_file_name=None,
):
    try:
        await truncate_table(model, postgres_db)

        if gcs_bucket_name and gcs_file_name:
            # Create credentials
            print("Loading data from GCS")
            credentials = service_account.Credentials.from_service_account_file(
                settings.service_account_key_file,
                scopes=["https://www.googleapis.com/auth/devstorage.read_only"],
            )
            fs = gcsfs.GCSFileSystem(token=credentials)
            csv_file_path = f"gs://{gcs_bucket_name}/{gcs_file_name}"
            with fs.open(csv_file_path, "r") as f:
                return await load_data(batch_size, f, model, postgres_db)

        else:
            csv_file_path = os.path.join(csv_folder, file_name)
            with open(csv_file_path, "r") as f:
                return await load_data(batch_size, f, model, postgres_db)

    except Exception as e:
        return JSONResponse(
            status_code=500,
            content={
                "message": f"Failed to load data into {model.__tablename__}",
                "error": str(e),
            },
        )


async def load_attributes_images():
    try:
        cache_key = "attributes_images"
        cached_data = await redis_db.get(cache_key)
    except Exception as e:
        print(REDIS_WRITE_ERROR, e)

    if not cached_data:
        DATA = {}
        for attribute in api_contract_search_attributes:
            window_cte = (
                select(
                    getattr(AjioProductAttributesV2, attribute),
                    AjioProductAttributesV2.productid,
                    AjioProductAttributesV2.imgcode,
                    func.row_number()
                    .over(
                        partition_by=getattr(AjioProductAttributesV2, attribute),
                        order_by=literal_column(
                            "1"
                        ),  # Can adjust this ordering as needed
                    )
                    .label("row_num"),
                )
            ).cte()

            window_query = select(
                getattr(window_cte.c, attribute),
                window_cte.c.productid,
                window_cte.c.imgcode,
            ).where(window_cte.c.row_num == 1)

            result = await psql_execute_single(window_query)

            # save for each attribute and row[0] there is a list of productids and imgcodes
            if attribute not in DATA:
                DATA[attribute] = {}

            for row in result:
                attr_value = row[0]
                productid = row[1]
                imgcode = row[2]

                DATA[attribute][attr_value] = {
                    "productid": productid,
                    "imgcode": imgcode,
                }

        try:
            cache_key = "attributes_images"
            await redis_db.set(cache_key, json.dumps(DATA, default=str))
        except Exception as e:
            print(REDIS_WRITE_ERROR, e)

    print("attributes-images loaded")


async def load_category_images():
    try:
        cache_key = "category_images"
        cached_data = await redis_db.get(cache_key)
    except Exception as e:
        print(REDIS_WRITE_ERROR, e)

    if not cached_data:
        subquery = (
            select(
                AjioBrickDetailsV2.l2name,
                AjioProductAttributesV2.productid,
                AjioProductAttributesV2.imgcode,
                func.row_number()
                .over(
                    partition_by=AjioBrickDetailsV2.l2name,
                    order_by=literal_column("1"),  # Can adjust this ordering as needed
                )
                .label("row_num"),
            ).join(
                AjioProductAttributesV2,
                AjioBrickDetailsV2.similargrouplevel
                == AjioProductAttributesV2.similargrouplevel,
            )
        ).cte()

        # Select only the first row for each l2name
        query = select(
            subquery.c.l2name, subquery.c.productid, subquery.c.imgcode
        ).where(subquery.c.row_num == 1)

        result = await psql_execute_single(query)
        result = {
            row[0]: {
                "id": row[1],
                "imgcode": row[2],
            }
            for row in result
        }

        try:
            cache_key = "category_images"
            await redis_db.set(cache_key, json.dumps(result, default=str))
        except Exception as e:
            print(REDIS_WRITE_ERROR, e)

    print("category-images loaded")


async def load_brick_images():
    try:
        cache_key = "brick_images"
        cached_data = await redis_db.get(cache_key)
    except Exception as e:
        print(REDIS_WRITE_ERROR, e)

    if not cached_data:
        query = (
        select(
            distinct(AjioBrickDetailsV2.brickname),
            AjioProductAttributesV2.productid,
            AjioProductAttributesV2.imgcode
        )
        .select_from(AjioBrickDetailsV2)
        .join(
            AjioProductAttributesV2,
            AjioBrickDetailsV2.similargrouplevel == AjioProductAttributesV2.similargrouplevel
        )
        .order_by(AjioBrickDetailsV2.brickname, AjioProductAttributesV2.productid)
    )

        result = await psql_execute_single(query)
        result = {
            row[0]: {
                "id": row[1],
                "imgcode": row[2],
            }
            for row in result
        }

        try:
            cache_key = "brick_images"
            await redis_db.set(cache_key, json.dumps(result, default=str))
        except Exception as e:
            print(REDIS_WRITE_ERROR, e)

    print("brick-images loaded")