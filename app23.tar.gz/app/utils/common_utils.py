import csv
import json
import os
from collections import defaultdict
from decimal import Decimal
from typing import Dict, List, Union

from db import redis_db
from sqlalchemy import and_, asc, desc, func, select
from static import (
    filter_flag_model_map,
    request_column_model_map,
    reverse_month_mapping,
)


async def create_filter_query(query, parameter):
    if parameter == "month_of_year":
        order_by_clause = query.c[parameter].desc()
    else:
        order_by_clause = func.count(query.c[parameter]).desc()

    query = (
        select(query.c[parameter])
        .group_by(query.c[parameter])
        .order_by(order_by_clause)
    )
    return query


async def sort_and_paginate(query, request_data, default_sort_param):
    # sort and limit the query results
    sort_param = request_data.get("sort_param")
    if not sort_param:
        sort_param = default_sort_param
    if sort_param == "ajio_weekly_ros":
        sort_param = "weekly_rate_of_sale"
    sort_type = request_data.get("sort_type")
    if not sort_type:
        sort_type = "desc"
    order_by_clause = (
        desc(f"{sort_param}") if sort_type == "desc" else asc(f"{sort_param}")
    )
    page_no = request_data.get("page_no", 1)
    page_count = request_data.get("page_count", 100)
    offset = (page_no - 1) * page_count

    query = query.order_by(order_by_clause).limit(page_count).offset(offset)

    return query


def decimal_serializer(obj):
    if isinstance(obj, Decimal):
        return str(obj)
    raise TypeError(
        "Object of type {} is not JSON serializable".format(type(obj).__name__)
    )


async def set_response_in_redis(cache_key, result):
    # Serialize the data using the custom serializer
    serialized_data = json.dumps(result, default=str)
    try:
        await redis_db.set(cache_key, serialized_data)
    except Exception as e:
        print("Not connected to redis: ", e)


async def build_filter_condition(
    filter_flag: str = "",
    request_filters: dict = defaultdict(dict),
    type: str = "ajio",
) -> Union[Dict, List]:
    request_filters = request_filters.get("nested_data", {})
    response_filters = {
        "duration": [],
        "search": [],
        "attributes": [],
        "bestsellers": [],
        "demographic": [],
        "brick": [],
        "store_filters": [],
        "category": [],
        "products": [],
        "calender": [],
        "bestsellers_week": [],
        "bestsellers_month": [],
    }

    for structure_key, structure_value in request_filters.items():
        for key, values in structure_value.items():
            if key == "month":
                if values and (
                    request_column_model_map[key]["column"]
                    in filter_flag_model_map[filter_flag][type].__dict__
                ):
                    month_values = [reverse_month_mapping[val] for val in values]
                    response_filters[filter_flag].append(
                        filter_flag_model_map[filter_flag][type]
                        .__dict__[request_column_model_map[key]["column"]]
                        .in_(month_values)
                    )
            elif key == "quarter" or key == "week":
                if values and (
                    request_column_model_map[key]["column"]
                    in filter_flag_model_map[filter_flag][type].__dict__
                ):
                    response_filters[filter_flag].append(
                        filter_flag_model_map[filter_flag][type]
                        .__dict__[request_column_model_map[key]["column"]]
                        .in_(list(map(int, values)))
                    )
            else:
                if values and (
                    request_column_model_map[key]["column"]
                    in filter_flag_model_map[filter_flag][type].__dict__
                ):
                    response_filters[filter_flag].append(
                        filter_flag_model_map[filter_flag][type]
                        .__dict__[request_column_model_map[key]["column"]]
                        .in_(values)
                    )
            if values and (
                request_column_model_map[key]["column"]
                in filter_flag_model_map[filter_flag][type].__dict__
            ):
                response_filters[filter_flag].append(
                    filter_flag_model_map[filter_flag][type].__dict__[
                        request_column_model_map[key]["column"]
                    ]
                    is not None
                )

    return response_filters[filter_flag]


async def construct_filtered_query(
    model, filters: list = [], columns: list = [], distinct_column=None
):
    if distinct_column:
        query = (
            select(getattr(model, distinct_column))
            .distinct()
            .where(and_(*filters, getattr(model, distinct_column).isnot(None)))
        )
    else:
        query = (
            select(*[getattr(model, column) for column in columns])
            .where(
                and_(
                    *filters
                )
            )
            .subquery()
        )

    return query


async def sort_by_cache(response_list, cache_list):
    """
    Sort response_list based on the order of elements in cache_list.
    Elements not in cache_list will appear at the end in their original order.
    """
    cache_index = {val: idx for idx, val in enumerate(cache_list)}
    response_list.sort(key=lambda x: cache_index.get(x, float("inf")))
    return response_list


async def sort_response_using_cache(response, cache_response):
    for key, value in response.items():
        if key in cache_response:
            for key1, value1 in response[key].items():
                if key1 in cache_response[key]:
                    response[key][key1] = await sort_by_cache(
                        response[key][key1], cache_response[key][key1]
                    )  # Ensure key is string

    return response


def create_csv_file(data: List[Dict], file_name: str, folder_path: str) -> str:
    """
    Create a CSV file from the provided data and save it to the specified folder.

    :param data: List of dictionaries containing the data to be written to the CSV file.
    :param file_name: Name of the CSV file to be created.
    :param folder_path: Path to the folder where the CSV file will be saved.
    :return: Path to the created CSV file.
    """
    # Ensure the folder exists
    os.makedirs(folder_path, exist_ok=True)

    # Define the CSV file path
    csv_file_path = os.path.join(folder_path, file_name)

    # Write the data to the CSV file
    with open(csv_file_path, mode="w", newline="") as file:
        writer = csv.writer(file)

        if data:
            # Write the header
            # breakpoint()
            header = data[0].keys()
            writer.writerow(header)

            # Write the data rows
            for row in data:
                writer.writerow(row.values())
