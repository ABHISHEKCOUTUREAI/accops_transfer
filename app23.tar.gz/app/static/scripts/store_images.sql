



WITH subquery AS (
    SELECT
        b.l1name,
        b.l2name,
        p.productid,
        p.imgcode,
        ROW_NUMBER() OVER (PARTITION BY b.l1name, b.l2name ORDER BY 1) AS row_num
    FROM
        v2_ajio_brick_details b
    JOIN
        v2_ajio_product_attributes p
    ON
        b.similargrouplevel = p.similargrouplevel
     WHERE
        p.imgcode IS NOT NULL

)
INSERT INTO v2_ajio_l2_images (l1name, l2name, productid, imgcode)
SELECT
    l1name,
    l2name,
    productid,
    imgcode
FROM
    subquery
WHERE
    row_num = 1;
    





WITH subquery AS (
    SELECT
        b.mh_family_desc,
        b.mh_class_desc,
        p.productid,
        p.imgcode,
        p.extension,
        ROW_NUMBER() OVER (PARTITION BY b.mh_family_desc, b.mh_class_desc ORDER BY 1) AS row_num
    FROM
        v2_trends_brick_details b
    JOIN
        v2_trends_product_attributes p
    ON
        b.similargrouplevel = p.similargrouplevel
    WHERE
        p.imgcode IS NOT NULL
)
INSERT INTO v2_trends_l2_images (l1name, l2name, productid, imgcode, extension)
SELECT
    mh_family_desc,
    mh_class_desc,
    productid,
    imgcode,
    extension
FROM
    subquery
WHERE
    row_num = 1;

    






WITH subquery AS (
WITH subquery AS (
    SELECT
        b.l1name,
        b.l2name,
        b.brickname,
        p.productid,
        p.imgcode,
        ROW_NUMBER() OVER (PARTITION BY b.l1name, b.l2name, b.brickname ORDER BY 1) AS row_num
    FROM
        v2_ajio_brick_details b
    JOIN
        v2_ajio_product_attributes p
    ON
        b.similargrouplevel = p.similargrouplevel
    WHERE
        p.imgcode IS NOT NULL
)
INSERT INTO v2_ajio_brick_images (l1name, l2name, brickname, productid, imgcode)
SELECT
    l1name,
    l2name,
    brickname,
    productid,
    imgcode
FROM
    subquery
WHERE
    row_num = 1;







WITH subquery AS (
    SELECT
        b.mh_family_desc,
        b.mh_class_desc,
        b.brickname,
        p.productid,
        p.imgcode,
        p.extension,
        ROW_NUMBER() OVER (PARTITION BY b.mh_family_desc, b.mh_class_desc, b.brickname ORDER BY 1) AS row_num
    FROM
        v2_trends_brick_details b
    JOIN
        v2_trends_product_attributes p
    ON
        b.similargrouplevel = p.similargrouplevel
    WHERE
        p.imgcode IS NOT NULL
)
INSERT INTO v2_trends_brick_images (l1name, l2name, brickname, productid, imgcode, extension)
SELECT
    mh_family_desc,
    mh_class_desc,
    brickname,
    productid,
    imgcode,
    extension
FROM
    subquery
WHERE
    row_num = 1;
    
    
  
WITH subquery AS (
    SELECT
        b.l1name,
        b.l2name,
        b.brickname,
        apc.attribute_name,
        apc.attribute_value,
        p.productid,
        p.imgcode,
        ROW_NUMBER() OVER (PARTITION BY b.l1name, b.l2name, b.brickname, apc.attribute_name, apc.attribute_value ORDER BY 1) AS row_num
    FROM
        v2_ajio_brick_details b
    JOIN
        v2_ajio_product_attributes p
    ON
        b.similargrouplevel = p.similargrouplevel
    JOIN 
        v2_ajio_product_attribute_combinations apc
    ON 
        apc.productid = p.productid
    WHERE
        p.imgcode IS NOT NULL
)
INSERT INTO v2_ajio_attribute_images (l1name, l2name, brickname, attribute_name, attribute_value, productid, imgcode)
SELECT
    l1name,
    l2name,
    brickname,
    attribute_name,
    attribute_value,
    productid,
    imgcode
FROM
    subquery
WHERE
    row_num = 1;




WITH subquery AS (
    SELECT
        b.mh_family_desc,
        b.mh_class_desc,
        b.brickname,
        apc.attribute_name,
        apc.attribute_value,
        p.productid,
        p.imgcode,
        p.extension,
        ROW_NUMBER() OVER (PARTITION BY b.mh_family_desc, b.mh_class_desc, b.brickname, apc.attribute_name, apc.attribute_value ORDER BY 1) AS row_num
    FROM
        v2_trends_brick_details b
    JOIN
        v2_trends_product_attributes p
    ON
        b.similargrouplevel = p.similargrouplevel
    JOIN 
        v2_trends_product_attribute_combinations apc
    ON 
        apc.productid = p.productid
    WHERE
        p.imgcode IS NOT NULL
)
INSERT INTO v2_trends_attribute_images (l1name, l2name, brickname, attribute_name, attribute_value, productid, imgcode, extension)
SELECT
    mh_family_desc,
    mh_class_desc,
    brickname,
    attribute_name,
    attribute_value,
    productid,
    imgcode,
    extension
FROM
    subquery
WHERE
    row_num = 1;

    