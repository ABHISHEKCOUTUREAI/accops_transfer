from sqlalchemy import (
    ARRAY,
    BigInteger,
    Column,
    Float,
    Index,
    Integer,
    PrimaryKeyConstraint,
    String,
)
from sqlalchemy.ext.declarative import declarative_base

Base = declarative_base()


# AJIO
class AjioBestSellers(Base):
    __tablename__ = "ajio_bestsellers_pincodes_top500"
    year = Column(Integer, primary_key=True)
    month_of_year = Column(Integer, primary_key=True)
    quarter_of_year = Column(Integer)
    week_of_year = Column(Integer, primary_key=True)
    pincode = Column(String, primary_key=True)
    productid = Column(String, primary_key=True)
    mrp = Column(Float)
    availablequantity_in_a_week = Column(BigInteger)
    sold_quantity_in_a_week = Column(BigInteger)

    __table_args__ = (
        PrimaryKeyConstraint(
            "year", "month_of_year", "week_of_year", "pincode", "productid"
        ),
        Index(f"idx_{__tablename__}_month", "month_of_year"),
        Index(f"idx_{__tablename__}_week", "week_of_year"),
        Index(f"idx_{__tablename__}_pincode", "pincode"),
        Index(f"idx_{__tablename__}_productid", "productid"),
    )


class AjioBestSellersMonth(Base):
    __tablename__ = "ajio_bestsellers_month"
    productid = Column(String, primary_key=True)
    year = Column(Integer, primary_key=True)
    month_of_year = Column(Integer, primary_key=True)
    districtsname = Column(String, primary_key=True)
    pincode = Column(String)
    sold_quantity_in_a_month = Column(BigInteger)
    healthy_live_days_in_a_month = Column(Integer)

    __table_args__ = (
        Index(f"idx_{__tablename__}_month_month", "month_of_year"),
        Index(f"idx_{__tablename__}_month_pincode", "pincode"),
        Index(f"idx_{__tablename__}_month_productid", "productid"),
        Index(f"idx_{__tablename__}_month_districtsname", "districtsname"),
    )


class AjioBestSellersWeek(Base):
    __tablename__ = "ajio_bestsellers_week"
    productid = Column(String, primary_key=True)
    year = Column(Integer, primary_key=True)
    week_of_year = Column(Integer, primary_key=True)
    districtsname = Column(String, primary_key=True)
    pincode = Column(String)
    sold_quantity_in_a_week = Column(BigInteger)
    healthy_live_days_in_a_week = Column(Integer)

    __table_args__ = (
        Index(f"idx_{__tablename__}_week_week", "week_of_year"),
        Index(f"idx_{__tablename__}_week_pincode", "pincode"),
        Index(f"idx_{__tablename__}_week_productid", "productid"),
        Index(f"idx_{__tablename__}_week_districtsname", "districtsname"),
    )


class AjioProductAttributes(Base):
    __tablename__ = "ajio_product_attributes"
    productid = Column(String, primary_key=True)
    similargrouplevel = Column(String, primary_key=True)
    colorfamily = Column(String)
    fabrictype = Column(String)
    materialtype = Column(String)
    pattern = Column(String)
    sleevelength = Column(String)
    brandname = Column(String)
    occasion = Column(String)
    bodytype = Column(String)
    fit = Column(String)
    distress = Column(String)
    traditionalweave = Column(String)
    neckline = Column(String)
    hemline = Column(String)
    styletype = Column(String)
    title = Column(String)
    imgcode = Column(String)
    mrp = Column(Float)

    __table_args__ = (
        PrimaryKeyConstraint("productid", "similargrouplevel"),
        Index(f"idx_{__tablename__}_similargrouplevel", "similargrouplevel"),
        Index(f"idx_{__tablename__}_productid", "productid"),
        Index(f"idx_{__tablename__}_brandname", "brandname"),
        Index(f"idx_{__tablename__}_fabrictype", "fabrictype"),
    )


class AjioBrickDetails(Base):
    __tablename__ = "ajio_brick_details"
    similargrouplevel = Column(String, primary_key=True)
    l1name = Column(String)
    l2name = Column(String)
    brickname = Column(String)

    __table_args__ = (
        PrimaryKeyConstraint("similargrouplevel"),
        Index(f"idx_{__tablename__}_similargrouplevel", "similargrouplevel"),
    )


class AjioDemographicDetails(Base):
    __tablename__ = "ajio_demographics"
    pincode = Column(String)
    state = Column(String)
    city = Column(String)
    districtsname = Column(String, primary_key=True)
    zone = Column(String)

    __table_args__ = (
        Index(f"idx_{__tablename__}_pincode", "pincode"),
        Index(f"idx_{__tablename__}_zone", "zone"),
    )


# Trends


class TrendsBestSellers(Base):
    __tablename__ = "trends_bestsellers_storeids_zonelevel_top100"
    year = Column(Integer, primary_key=True)
    quarter_of_year = Column(Integer)
    month_of_year = Column(Integer, primary_key=True)
    week_of_year = Column(Integer, primary_key=True)
    itemid = Column(String, primary_key=True)
    store_id = Column(String, primary_key=True)
    sold_quantity_in_a_week = Column(BigInteger)
    availablequantity_in_a_week = Column(BigInteger)

    __table_args__ = (
        PrimaryKeyConstraint(
            "year", "month_of_year", "week_of_year", "itemid", "store_id"
        ),
        Index(f"idx_{__tablename__}_month", "month_of_year"),
        Index(f"idx_{__tablename__}_week", "week_of_year"),
        Index(f"idx_{__tablename__}_itemid", "itemid"),
        Index(f"idx_{__tablename__}_store_id", "store_id"),
    )


class TrendsBestSellersMonth(Base):
    __tablename__ = "trends_bestsellers_month"
    itemid = Column(String, primary_key=True)
    year = Column(Integer, primary_key=True)
    month_of_year = Column(Integer, primary_key=True)
    districtsname = Column(String, primary_key=True)
    store_id = Column(String)
    sold_quantity_in_a_month = Column(BigInteger)
    healthy_live_days_in_a_month = Column(Integer)

    __table_args__ = (
        Index(f"idx_{__tablename__}_month", "month_of_year"),
        Index(f"idx_{__tablename__}_districtsname", "districtsname"),
        Index(f"idx_{__tablename__}_itemid", "itemid"),
    )


class TrendsBestSellersWeek(Base):
    __tablename__ = "trends_bestsellers_week"
    itemid = Column(String, primary_key=True)
    year = Column(Integer, primary_key=True)
    week_of_year = Column(Integer, primary_key=True)
    districtsname = Column(String, primary_key=True)
    store_id = Column(String)
    sold_quantity_in_a_week = Column(BigInteger)
    healthy_live_days_in_a_week = Column(Integer)

    __table_args__ = (
        Index(f"idx_{__tablename__}_week", "week_of_year"),
        Index(f"idx_{__tablename__}_districtsname", "districtsname"),
        Index(f"idx_{__tablename__}_itemid", "itemid"),
    )


class TrendsProductAttributes(Base):
    __tablename__ = "trends_product_attributes"
    itemid = Column(String, primary_key=True)
    similargrouplevel = Column(String, primary_key=True)
    primarycolor = Column(String)
    fabrictype = Column(String)
    materialtype = Column(String)
    pattern = Column(String)
    sleeve = Column(String)
    fit = Column(String)
    neckline = Column(String)
    styletype = Column(String)
    fashion_grade_description = Column(String)
    mrp = Column(Float)
    brandname = Column(String)
    imgcode = Column(String)
    extension = Column(String)
    mrp = Column(Float)

    __table_args__ = (
        PrimaryKeyConstraint("itemid", "similargrouplevel"),
        Index(f"idx_{__tablename__}_similargrouplevel", "similargrouplevel"),
        Index(f"idx_{__tablename__}_itemid", "itemid"),
        Index(f"idx_{__tablename__}_brandname", "brandname"),
        Index(f"idx_{__tablename__}_fabrictype", "fabrictype"),
    )


class TrendsStoreDetails(Base):
    __tablename__ = "trends_store_details"
    store_id = Column(String)
    city = Column(String)
    state = Column(String)
    zone_desc = Column(String)
    districtsname = Column(String, primary_key=True)

    __table_args__ = (
        Index(f"idx_{__tablename__}_districtsname", "districtsname"),
        Index(f"idx_{__tablename__}_zone_desc", "zone_desc"),
        Index(f"idx_{__tablename__}_state", "state"),
    )


class TrendsBrickDetails(Base):
    __tablename__ = "trendsbrickdetails"
    similargrouplevel = Column(String, primary_key=True)
    mh_family_desc = Column(String)
    mh_class_desc = Column(String)
    brickname = Column(String)

    __table_args__ = (
        PrimaryKeyConstraint("similargrouplevel"),
        Index(f"idx_{__tablename__}_similargrouplevel", "similargrouplevel"),
    )


# AJIO Search Queries


class AjioSearchQueriesTopInteractedProducts(Base):
    __tablename__ = "ajio_search_queries_top_interacted_products"
    year = Column(Integer, primary_key=True)
    month_of_year = Column(Integer, primary_key=True)
    week_of_year = Column(Integer, primary_key=True)
    search_type = Column(String, primary_key=True)
    normalized_search_term = Column(String, primary_key=True)
    productid = Column(String, primary_key=True)
    sum_session_counts = Column(BigInteger)
    impressions_product = Column(BigInteger)
    clicks_product = Column(BigInteger)
    total_clicks_query = Column(BigInteger)

    __table_args__ = (
        PrimaryKeyConstraint(
            "year",
            "month_of_year",
            "week_of_year",
            "search_type",
            "normalized_search_term",
            "productid",
        ),
        Index(f"idx_{__tablename__}_interacted_products_month", "month_of_year"),
        Index(f"idx_{__tablename__}_interacted_products_week", "week_of_year"),
        Index(
            f"idx_{__tablename__}_normalized_search_term",
            "normalized_search_term",
        ),
    )


# Google Search Queries


class SearchInteractions(Base):
    __tablename__ = "search_interactions"
    id = Column(Integer, primary_key=True, autoincrement=True)
    category = Column(String)
    related_top_searches = Column(String)
    number_of_top_searches = Column(Integer)
    related_rising_searches = Column(String)
    number_of_rising_searches = Column(Integer)

    __table_args__ = (Index(f"idx_{__tablename__}_category", "category"),)


class Calenderyearmonthweekinfo(Base):
    __tablename__ = "calendaryearmonthweekinfo"
    year = Column(Integer, primary_key=True)
    month_of_year = Column(Integer, primary_key=True)
    quarter_of_year = Column(Integer)
    week_of_year = Column(Integer, primary_key=True)
    list_of_dates_in_the_week = Column(ARRAY(String))  # Use ARRAY type
    num_days_in_week = Column(Integer, nullable=False)

    __table_args__ = (
        PrimaryKeyConstraint("year", "month_of_year", "week_of_year"),
        Index(f"idx_{__tablename__}_month", "month_of_year"),
        Index(f"idx_{__tablename__}_week", "week_of_year"),
    )
