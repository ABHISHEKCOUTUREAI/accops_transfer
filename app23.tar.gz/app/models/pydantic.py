# define a enum to restrict the query parameter to only [7, 14, 28, 91]
from enum import Enum
from typing import Optional

from fastapi import Query
from pydantic import BaseModel


class NumDays(int, Enum):
    WEEK = 7
    TWO_WEEKS = 14
    MONTH = 28
    QUARTER = 91


class PastDays(BaseModel):
    num_days: Optional[NumDays] = Query(
        NumDays.MONTH, description="Number of days for the search period"
    )


class Pagination(BaseModel):
    page: int = Query(1, ge=1)
    page_size: int = Query(10, ge=1)


class Sort(BaseModel):
    sort_key: Optional[str] = None
    sort_order: Optional[str] = Query("desc", regex="^(asc|desc)$")


class DemographyFilters(BaseModel):
    zone: Optional[str] = None
    state: Optional[str] = None
    district: Optional[str] = None
    city: Optional[str] = None
    pincode: Optional[str] = None
    store_id: Optional[str] = None


class BrickFilters(BaseModel):
    gender: Optional[str] = None
    category: Optional[str] = None
    brickname: Optional[str] = None


class ProductAttributeFilters(BaseModel):
    colorfamily: Optional[str] = None
    fabrictype: Optional[str] = None
    materialtype: Optional[str] = None
    pattern: Optional[str] = None
    sleevelength: Optional[str] = None
    brandname: Optional[str] = None
    occasion: Optional[str] = None
    bodytype: Optional[str] = None
    fit: Optional[str] = None
    distress: Optional[str] = None
    traditionalweave: Optional[str] = None
    neckline: Optional[str] = None
    hemline: Optional[str] = None
    styletype: Optional[str] = None
    min_price: Optional[int] = Query(None, ge=0)
    max_price: Optional[int] = Query(None, ge=0)


class AttributeResponseChiild(BaseModel):
    name: str
    percentage: float


class AttributeResponse(BaseModel):
    attribute_key: str
    distribution: list[AttributeResponseChiild]


class ProductQueryParams(
    ProductAttributeFilters, BrickFilters, DemographyFilters, Sort, Pagination, PastDays
):
    sort_key: Optional[str] = "ajio_weekly_ros"
    filter: Optional[str] = None


class CategoryQueryParams(BaseModel):
    gender: str = Query("men")
    category: Optional[str] = None
    filter: str = Query("ajio", regex="^(ajio|trends)$")


class AttributeQueryParams(DemographyFilters, Pagination, PastDays):
    gender: str
    category: str
    brickname: str
    filter: Optional[str] = "ajio"
    attribute: Optional[str] = "all"


class SearchTrendsRequest(BrickFilters, PastDays, Pagination):
    search_query: Optional[str] = None


class SearchParams(BrickFilters, PastDays, Pagination):
    page_size: int = Query(5, ge=1)
    attribute: Optional[str] = "all"
    num_attribute_fields: Optional[int] = None


class FilterQuery(ProductAttributeFilters, DemographyFilters, BrickFilters):
    pass
