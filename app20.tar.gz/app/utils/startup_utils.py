import asyncio
import json
import os
from collections import defaultdict

import asyncpg
import pandas as pd
from db import (
    check_in_redis,
    psql_execute_multiple,
    psql_execute_single,
    redis_db,
    psql_execute,
)
from fastapi.responses import JSONResponse
from models import (
    AjioBestSellers,
    AjioBrickDetails,
    AjioDemographicDetails,
    AjioProductAttributes,
    TrendsBestSellers,
    TrendsBrickDetails,
    TrendsProductAttributes,
    TrendsStoreDetails,
)
from settings import settings
from sqlalchemy import func, insert, literal_column, select, text
from static import REDIS_WRITE_ERROR, view_creation_mapping, month_mapping

from .ajio_interaction_utils import create_search_interaction_filter_query
from .ajio_utils import create_ajio_filters_query
from .api_contract_utils import api_contract_search_attributes
from .common_utils import create_filter_query

from .trends_utils import create_trends_filter_query

csv_folder = os.path.join(os.getcwd(), settings.corpus_path)

# Load google search interactions data into the database


async def truncate_table(model, postgres_db):
    try:
        truncate_statement = text(f"TRUNCATE TABLE {model.__tablename__}")
        await postgres_db.execute(truncate_statement)
        print(f"Truncated {model.__tablename__}")
    except Exception as e:
        print(f"Failed to truncate {model.__tablename__}")
        raise e


async def process_csv_file(file_name, folder_path, model, postgres_db):
    try:
        print(f"Loading data from file '{file_name}'")

        df = pd.read_csv(os.path.join(folder_path, file_name), skiprows=2)

        data_records = await extract_data_records(df, file_name)

        df_processed = await process_data_records(data_records)

        await insert_into_db(df_processed, model, postgres_db, file_name)

    except Exception as e:
        print(e)
        raise


async def extract_data_records(df, file_name):
    data_records = []
    flag = 0

    for related_name, related_number in df.iterrows():
        if related_name == "RISING":
            flag = 1
            continue

        category = file_name.split(".")[0]
        related_name_str = str(related_name)

        if flag == 0:
            top_searches = (
                1
                if isinstance(related_number["TOP"], str)
                else int(related_number["TOP"])
            )

            data_records.append(
                {
                    "category": category,
                    "related_top_searches": related_name_str,
                    "number_of_top_searches": top_searches,
                    "related_rising_searches": None,
                    "number_of_rising_searches": None,
                }
            )

        elif flag == 1:
            rising_searches = (
                100
                if isinstance(related_number["TOP"], str)
                else int(related_number["TOP"])
            )

            data_records[-1]["related_rising_searches"] = related_name_str
            data_records[-1]["number_of_rising_searches"] = rising_searches

    return data_records


async def process_data_records(data_records):
    df_processed = pd.DataFrame(data_records)
    df_processed = df_processed.fillna(
        {"number_of_top_searches": 0, "number_of_rising_searches": 0}
    )
    df_processed["number_of_top_searches"] = df_processed[
        "number_of_top_searches"
    ].astype(int)
    df_processed["number_of_rising_searches"] = df_processed[
        "number_of_rising_searches"
    ].astype(int)
    return df_processed


async def insert_into_db(df_processed, model, postgres_db, category):
    await postgres_db.execute(
        insert(model).values(df_processed.to_dict(orient="records"))
    )
    print(
        f"Data loaded for category '{category}' in {model.__table__.name} with {len(df_processed)} records"
    )


async def load_google_search_interactions(model, postgres_db=None):
    try:
        await truncate_table(model, postgres_db)

        folder_path = os.path.join(csv_folder, "google_search_interactions")
        csv_files = [f for f in os.listdir(folder_path) if f.endswith(".csv")]

        for file_name in csv_files:
            if file_name in [
                "Sports, Games & Equipment.csv",
                "Handbags.csv",
                "Dupatta Set.csv",
                "Anklets.csv",
                "Boxers.csv",
                "Casual Shoes.csv",
                "Jackets.csv",
            ]:
                continue

            await process_csv_file(file_name, folder_path, model, postgres_db)

        return JSONResponse(
            status_code=200,
            content={
                "message": f"Data loaded successfully into {model.__table__.name}"
            },
        )
    except Exception as e:
        print(e)
        raise e


# load corpus data into the database
async def validate_data(chunk, model):
    if model == AjioBestSellers:
        chunk["year"] = chunk["year"].astype(int)
        chunk["quarter_of_year"] = chunk["quarter_of_year"].astype(int)
        chunk["month_of_year"] = chunk["month_of_year"].astype(int)
        chunk["week_of_year"] = chunk["week_of_year"].astype(int)
        chunk["pincode"] = chunk["pincode"].astype(str)
        chunk["productid"] = chunk["productid"].astype(str)
        chunk["mrp"] = chunk["mrp"].astype(float)
        chunk["availablequantity_in_a_week"] = chunk[
            "availablequantity_in_a_week"
        ].astype(int)
        chunk["sold_quantity_in_a_week"] = chunk["sold_quantity_in_a_week"].astype(int)
    if model == AjioProductAttributes:
        chunk["productid"] = chunk["productid"].astype(str)
        chunk["similargrouplevel"] = chunk["similargrouplevel"].astype(str)
        chunk["colorfamily"] = chunk["colorfamily"].astype(str)
        chunk["fabrictype"] = chunk["fabrictype"].astype(str)
        chunk["materialtype"] = chunk["materialtype"].astype(str)
        chunk["pattern"] = chunk["pattern"].astype(str)
        chunk["sleevelength"] = chunk["sleevelength"].astype(str)
        chunk["brandname"] = chunk["brandname"].astype(str)
        chunk["occasion"] = chunk["occasion"].astype(str)
        chunk["bodytype"] = chunk["bodytype"].astype(str)
        chunk["fit"] = chunk["fit"].astype(str)
        chunk["distress"] = chunk["distress"].astype(str)
        chunk["traditionalweave"] = chunk["traditionalweave"].astype(str)
        chunk["neckline"] = chunk["neckline"].astype(str)
        chunk["hemline"] = chunk["hemline"].astype(str)
        chunk["styletype"] = chunk["styletype"].astype(str)
        chunk["title"] = chunk["title"].astype(str)
        chunk["catalogid"] = chunk["catalogid"].astype(str)
        chunk["imgcode"] = chunk["imgcode"].astype(str)
    if model == AjioBrickDetails:
        chunk["similargrouplevel"] = chunk["similargrouplevel"].astype(str)
        chunk["l1name"] = chunk["l1name"].astype(str)
        chunk["l2name"] = chunk["l2name"].astype(str)
        chunk["brickname"] = chunk["brickname"].astype(str)
    if model == AjioDemographicDetails:
        chunk["pincode"] = chunk["pincode"].astype(str)
        chunk["state"] = chunk["state"].astype(str)
        chunk["city"] = chunk["city"].astype(str)
        chunk["districtsname"] = chunk["districtsname"].astype(str)
        chunk["zone"] = chunk["zone"].astype(str)
    if model == TrendsBestSellers:
        chunk["year"] = chunk["year"].astype(float).fillna(0).astype(int)
        chunk["quarter_of_year"] = (
            chunk["quarter_of_year"].astype(float).fillna(0).astype(int)
        )
        chunk["month_of_year"] = (
            chunk["month_of_year"].astype(float).fillna(0).astype(int)
        )
        chunk["week_of_year"] = (
            chunk["week_of_year"].astype(float).fillna(0).astype(int)
        )
        chunk["itemid"] = chunk["itemid"].astype(str)
        chunk["store_id"] = chunk["store_id"].astype(str)
        chunk["sold_quantity_in_a_week"] = (
            chunk["sold_quantity_in_a_week"].astype(float).fillna(0).astype(int)
        )
        chunk["availablequantity_in_a_week"] = (
            chunk["availablequantity_in_a_week"].astype(float).fillna(0).astype(int)
        )
    if model == TrendsProductAttributes:
        chunk["itemid"] = chunk["itemid"].astype(str)
        chunk["similargrouplevel"] = chunk["similargrouplevel"].astype(str)
        chunk["primarycolor"] = chunk["primarycolor"].astype(str)
        chunk["fabrictype"] = chunk["fabrictype"].astype(str)
        chunk["materialtype"] = chunk["materialtype"].astype(str)
        chunk["pattern"] = chunk["pattern"].astype(str)
        chunk["sleeve"] = chunk["sleeve"].astype(str)
        chunk["fit"] = chunk["fit"].astype(str)
        chunk["neckline"] = chunk["neckline"].astype(str)
        chunk["styletype"] = chunk["styletype"].astype(str)
        chunk["fashion_grade_description"] = chunk["fashion_grade_description"].astype(
            str
        )
        chunk["mrp"] = chunk["mrp"].astype(float)
        chunk["imgcode"] = chunk["imgcode"].astype(str)
        chunk["brandname"] = chunk["brandname"].astype(str)
        chunk["extension"] = chunk["extension"].astype(str)
    if model == TrendsBrickDetails:
        chunk["similargrouplevel"] = chunk["similargrouplevel"].astype(str)
        chunk["mh_family_desc"] = chunk["mh_family_desc"].astype(str)
        chunk["mh_class_desc"] = chunk["mh_class_desc"].astype(str)
        chunk["brickname"] = chunk["brickname"].astype(str)
    if model == TrendsStoreDetails:
        chunk["store_id"] = chunk["store_id"].astype(str)
        chunk["pin_code"] = chunk["pin_code"].astype(str)
        chunk["format_cd"] = chunk["format_cd"].astype(str)
        chunk["format_desc"] = chunk["format_desc"].astype(str)
        chunk["city"] = chunk["city"].astype(str)
        chunk["region"] = chunk["region"].astype(str)
        chunk["location"] = chunk["location"].astype(str)
        chunk["store_short_name"] = chunk["store_short_name"].astype(str)
        chunk["store_area"] = chunk["store_area"].astype(str)
        chunk["state"] = chunk["state"].astype(str)
        chunk["zone_desc"] = chunk["zone_desc"].astype(str)
        chunk["store_class_desc"] = chunk["store_class_desc"].astype(str)
        chunk["districtsname"] = chunk["districtsname"].astype(str)

    return chunk


async def load_corpus(
    model,
    file_name,
    postgres_db,
    batch_size=1000,
    gcs_bucket_name=None,
    gcs_file_name=None,
):
    try:
        await truncate_table(model, postgres_db)
        if gcs_bucket_name and gcs_file_name:
            csv_file_path = f"gs://{gcs_bucket_name}/{gcs_file_name}"
        else:
            csv_file_path = os.path.join(csv_folder, file_name)

        if model == AjioBrickDetails:
            batch_size = 1

        for batch_number, chunk in enumerate(
            pd.read_csv(csv_file_path, chunksize=batch_size, sep=",", index_col=False),
            start=1,
        ):
            try:
                chunk = await validate_data(chunk, model)

                await postgres_db.execute(
                    insert(model).values(chunk.to_dict(orient="records"))
                )
                print(
                    f"\rBatch {batch_number} loaded for {model.__tablename__}", end=""
                )

            except asyncpg.exceptions.UniqueViolationError:
                continue

        print(f"{model.__tablename__} loaded successfully")

        return JSONResponse(
            status_code=200,
            content={"message": f"Data loaded successfully into {model.__tablename__}"},
        )

    except Exception as e:
        print(e)
        print("failed to load data into: ", model.__tablename__)
        return JSONResponse(
            status_code=500,
            content={"message": f"Failed to load data into {model.__tablename__}"},
        )


async def load_ajio_cached_filters():
    print("Loading Ajio filters")

    async def filter_non_null(values):
        values  = [val[0] for val in values if val[0] != "nan" and val[0] is not None]
        return sorted(values)

    async def format_response(result):
        async def build_section(keys):
            return {key: await filter_non_null(result[idx]) for idx, key in keys}

        response_data = defaultdict(dict)

        response_data["demographic"] = await build_section(
            [(0, "zone"), (1, "state"), (2, "city"), (3, "district")]
        )
        response_data["brick_filters"] = await build_section(
            [(4, "l1_name"), (5, "l2_name"), (6, "brick_name")]
        )
        response_data["attributes"] = await build_section(
            [
                (7, "styletype"),
                (8, "neckline"),
                (9, "pattern"),
                (10, "fabrictype"),
                (11, "sleeve"),
                (12, "fit"),
                (13, "color"),
                (14, "brandname"),
                (15, "occasion"),
                (16, "bodytype"),
                (17, "materialtype"),
                (18, "distress"),
                (19, "traditionalweave"),
                (20, "hemline"),
            ]
        )
        response_data["duration"] = {
            "month": [
                month_mapping[val[0]]
                for val in result[21]
                if val[0] != "nan" and val[0] is not None
            ],
            "quarter": [
                str(val[0])
                for val in result[22]
                if val[0] != "nan" and val[0] is not None
            ],
        }

        return response_data

    cache_key = "ajio_filters_cache"
    cached_data = await check_in_redis(cache_key)
    if not cached_data:
        request_data = {}
        query = await create_ajio_filters_query(request_data)

        # crate a list and push all queries there
        parameters = [
            "zone",
            "state",
            "city",
            "districtsname",
            "l1name",
            "l2name",
            "brickname",
            "styletype",
            "neckline",
            "pattern",
            "fabrictype",
            "sleevelength",
            "fit",
            "colorfamily",
            "brandname",
            "occasion",
            "bodytype",
            "materialtype",
            "distress",
            "traditionalweave",
            "hemline",
            "month_of_year",
            "quarter_of_year",
        ]

        query_list = await asyncio.gather(
            *(create_filter_query(query, parameter=param) for param in parameters)
        )
        result = await psql_execute_multiple(query_list)

        response_data = await format_response(result)
        try:
            await redis_db.set(cache_key, json.dumps(response_data, default=str))
        except Exception as e:
            print(REDIS_WRITE_ERROR, e)

    print("Ajio filter loaded")


async def load_trends_filters_cache():
    print("Loading Trends filters")

    async def filter_non_null(values):
        return [val[0] for val in values if val[0] != "nan" and val[0] is not None]

    async def format_response(result):
        async def build_section(keys):
            return {key: await filter_non_null(result[idx]) for idx, key in keys}

        response = defaultdict(dict)

        response["demographic"] = await build_section(
            [(2, "zone"), (3, "state"), (4, "city"), (5, "district")]
        )
        response["category"] = await build_section(
            [(8, "category_family"), (9, "category_class"), (10, "category")]
        )
        response["attributes"] = await build_section(
            [
                (11, "styletype"),
                (12, "neckline"),
                (13, "pattern"),
                (14, "fabric_type"),
                (15, "sleeve"),
                (16, "fit"),
                (17, "color"),
                (18, "brand"),
            ]
        )
        response["store_filters"] = await build_section(
            [(6, "pincode"), (7, "store_id")]
        )

        response["duration"] = {
            "month": [
                month_mapping[val[0]]
                for val in result[0]
                if val[0] != "nan" and val[0] is not None
            ],
            "quarter": [
                str(val[0])
                for val in result[1]
                if val[0] != "nan" and val[0] is not None
            ],
        }

        return response

    cache_key = "trends_filters_cache"
    cached_data = await check_in_redis(cache_key)

    if not cached_data:
        request_data = {}
        query = await create_trends_filter_query(request_data)

        parameters = [
            "month_of_year",
            "quarter_of_year",
            "zone_desc",
            "state",
            "city",
            "districtsname",
            "pin_code",
            "store_id",
            "mh_family_desc",
            "mh_class_desc",
            "brickname",
            "styletype",
            "neckline",
            "pattern",
            "fabrictype",
            "sleeve",
            "fit",
            "primarycolor",
            "brandname",
        ]

        query_list = await asyncio.gather(
            *(create_filter_query(query, parameter=param) for param in parameters)
        )
        result = await psql_execute_multiple(query_list)

        response_data = await format_response(result)

        try:
            await redis_db.set(cache_key, json.dumps(response_data, default=str))
        except Exception as e:
            print(REDIS_WRITE_ERROR, e)

    print("Trends-filters-cache loaded")


async def load_cached_search_interaction_filters():
    print("Loading Ajio-search-interaction-filters")
    cache_key = "search_interaction_filters_cache"
    cached_data = await check_in_redis(cache_key)

    if not cached_data:
        request_data = {}

        query = await create_search_interaction_filter_query(request_data)

        query_list = await asyncio.gather(
            create_filter_query(query, "month_of_year"),
            create_filter_query(query, "week_of_year"),
            create_filter_query(query, "search_type"),
            create_filter_query(query, "normalized_search_term"),
            create_filter_query(query, "l1name"),
            create_filter_query(query, "l2name"),
            create_filter_query(query, "brickname"),
            create_filter_query(query, "brandname"),
        )

        result = await psql_execute_multiple(query_list)

        response = defaultdict(dict)
        response["brick_filters"] = {
            "l1_name": [val[0] for val in result[4]],
            "l2_name": [val[0] for val in result[5]],
            "brick_name": [val[0] for val in result[6]],
        }
        response["attributes"] = {"brandname": [val[0] for val in result[7]]}
        response["search_filters"] = {
            "search_type": [val[0] for val in result[2]],
            "search_query": [val[0] for val in result[3]],
        }
        response["duration"] = {
            "month": [month_mapping[val[0]] for val in result[0]],
            "week": [str(val[0]) for val in result[1]],
        }

        try:
            await redis_db.set(cache_key, json.dumps(response, default=str))
        except Exception as e:
            print(REDIS_WRITE_ERROR, e)

    print("Ajio-search-interaction-filters loaded")


async def load_attributes_images():
    try:
        cache_key = "attributes_images"
        cached_data = await redis_db.get(cache_key)
    except Exception as e:
        print(REDIS_WRITE_ERROR, e)

    if not cached_data:
        DATA = {}
        for attribute in api_contract_search_attributes:
            window_cte = (
                select(
                    getattr(AjioProductAttributes, attribute),
                    AjioProductAttributes.productid,
                    AjioProductAttributes.imgcode,
                    func.row_number()
                    .over(
                        partition_by=getattr(AjioProductAttributes, attribute),
                        order_by=literal_column(
                            "1"
                        ),  # Can adjust this ordering as needed
                    )
                    .label("row_num"),
                )
            ).cte()

            window_query = select(
                getattr(window_cte.c, attribute),
                window_cte.c.productid,
                window_cte.c.imgcode,
            ).where(window_cte.c.row_num == 1)

            result = await psql_execute_single(window_query)

            # save for each attribute and row[0] there is a list of productids and imgcodes
            if attribute not in DATA:
                DATA[attribute] = {}

            for row in result:
                attr_value = row[0]
                productid = row[1]
                imgcode = row[2]

                DATA[attribute][attr_value] = {
                    "productid": productid,
                    "imgcode": imgcode,
                }

        try:
            cache_key = "attributes_images"
            await redis_db.set(cache_key, json.dumps(DATA, default=str))
        except Exception as e:
            print(REDIS_WRITE_ERROR, e)

    print("attributes-images loaded")


async def load_category_images():
    try:
        cache_key = "category_images"
        cached_data = await redis_db.get(cache_key)
    except Exception as e:
        print(REDIS_WRITE_ERROR, e)

    if not cached_data:
        subquery = (
            select(
                AjioBrickDetails.l2name,
                AjioProductAttributes.productid,
                AjioProductAttributes.imgcode,
                func.row_number()
                .over(
                    partition_by=AjioBrickDetails.l2name,
                    order_by=literal_column("1"),  # Can adjust this ordering as needed
                )
                .label("row_num"),
            ).join(
                AjioProductAttributes,
                AjioBrickDetails.similargrouplevel
                == AjioProductAttributes.similargrouplevel,
            )
        ).cte()

        # Select only the first row for each l2name
        query = select(
            subquery.c.l2name, subquery.c.productid, subquery.c.imgcode
        ).where(subquery.c.row_num == 1)

        result = await psql_execute_single(query)
        result = {
            row[0]: {
                "id": row[1],
                "imgcode": row[2],
            }
            for row in result
        }

        try:
            cache_key = "category_images"
            await redis_db.set(cache_key, json.dumps(result, default=str))
        except Exception as e:
            print(REDIS_WRITE_ERROR, e)

    print("category-images loaded")


async def create_views():
    try:
        for view_sql in view_creation_mapping["all"]:
            await psql_execute(view_sql)
        print("All views created successfully")
    except Exception as e:
        print(f"View creation failed: {str(e)}")
