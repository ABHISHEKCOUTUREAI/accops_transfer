import asyncio
from collections import defaultdict
import json

from db import psql_execute_single, check_in_redis, redis_db
from models import (
    TrendsBestSellers,
    TrendsBrickDetails,
    TrendsProductAttributes,
    TrendsStoreDetails,
)
from sqlalchemy import and_, func, select
from static import month_mapping, REDIS_WRITE_ERROR

from .common_utils import build_filter_condition, select_filter_subquery


async def get_trends_filters_service(
        request_data: dict,
        caching_flag: bool = False,
    ):

    cache_key = f"trends_filters{json.dumps(request_data)}"
    cached_data = await check_in_redis(cache_key)
    if cached_data:
        return json.loads(cached_data)
    
    query = await create_trends_filter_query(request_data)
    result = await psql_execute_single(query)
    response = await create_trends_filters_response(result)


    try:
        await redis_db.set(cache_key, json.dumps(response, default=str))
    except Exception as e:
        print(REDIS_WRITE_ERROR, e)
    
    if caching_flag:
        print("Trends filters loaded successfully")
    else:   
        return response


async def create_trends_filters_response(result):

    def filter_non_null(result, index):
        values =  list(set(val[index] for val in result if val[index] != "nan" and val[index] is not None))
        return sorted(values)

    
    categories = {
        "demographic": {
            "zone_desc": 2,
            "state": 3,
            "city": 4,
            "district": 5
        },
        "category": {
            "category_family": 8,
            "category_class": 9,
            "category": 10
        },
        "attributes": {
            "styletype": 11,
            "neckline": 12,
            "pattern": 13,
            "fabric_type": 14,
            "sleeve": 15,
            "fit": 16,
            "color": 17,
            "brand": 18
        },
        "store_filters": {
            "pincode": 6,
            "store_id": 7
        }
    }

    response = {category: {key: filter_non_null(result, idx) for key, idx in keys.items()}
                for category, keys in categories.items()}

    response["duration"] = {
        "month": list({month_mapping[val[0]] for val in result if val[0] != "nan" and val[0] is not None}),
        "quarter": list({str(val[1]) for val in result if val[1] != "nan" and val[1] is not None})
    }

    return response


async def get_attributes_bestsellers_trends(request_data, attribute: str):
    (
        product_filter,
        brick_filter,
        duration_filter,
        demographic_filter,
    ) = await asyncio.gather(
        build_filter_condition(
            type="trends", request_filters=request_data, filter_flag="products"
        ),
        build_filter_condition(
            type="trends", request_filters=request_data, filter_flag="category"
        ),
        build_filter_condition(
            type="trends", request_filters=request_data, filter_flag="bestsellers"
        ),
        build_filter_condition(
            type="trends", request_filters=request_data, filter_flag="store_filters"
        ),
    )

    product_query = (
        select(
            getattr(TrendsProductAttributes, attribute),
            TrendsProductAttributes.itemid,
            TrendsProductAttributes.similargrouplevel,
        )
        .where(
            and_(
                *product_filter, getattr(TrendsProductAttributes, attribute) is not None
            )
        )
        .subquery()
    )

    brick_query = (
        select(TrendsBrickDetails.brickname, TrendsBrickDetails.similargrouplevel)
        .where(and_(*brick_filter))
        .subquery()
    )

    sold_in_week_query = (
        select(
            TrendsBestSellers.sold_quantity_in_a_week,
            TrendsBestSellers.itemid,
            TrendsBestSellers.store_id,
        )
        .where(and_(*duration_filter))
        .subquery()
    )

    store_query = (
        select(
            TrendsStoreDetails.store_id,
        )
        .where(and_(*demographic_filter))
        .subquery()
    )

    # join all three queries
    query = (
        select(
            getattr(product_query.c, attribute),
            brick_query.c.brickname,
            func.sum(sold_in_week_query.c.sold_quantity_in_a_week).label("quantity"),
        )
        .join(
            brick_query,
            product_query.c.similargrouplevel == brick_query.c.similargrouplevel,
        )
        .join(sold_in_week_query, product_query.c.itemid == sold_in_week_query.c.itemid)
        .join(store_query, sold_in_week_query.c.store_id == store_query.c.store_id)
        .group_by(
            getattr(product_query.c, attribute),
            brick_query.c.brickname,
        )
        .order_by(func.sum(sold_in_week_query.c.sold_quantity_in_a_week).desc())
    )

    rows = await psql_execute_single(query)
    result = defaultdict(dict)
    for row in rows:
        if row[0] and row[0] != 'nan':
            result[row[1]][row[0]] = float(row[2])

    return result


async def create_trends_filter_query(request_data):
    duration_filter, store_filter, brick_filter, product_filter = await asyncio.gather(
        build_filter_condition(
            type="trends", request_filters=request_data, filter_flag="bestsellers"
        ),
        build_filter_condition(
            type="trends", request_filters=request_data, filter_flag="store_filters"
        ),
        build_filter_condition(
            type="trends", request_filters=request_data, filter_flag="category"
        ),
        build_filter_condition(
            type="trends", request_filters=request_data, filter_flag="products"
        ),

    )
    # breakpoint()

    duration_columns = ["month_of_year", "quarter_of_year", "itemid", "store_id"]
    store_columns = [
        "zone_desc",
        "state",
        "city",
        "districtsname",
        "pin_code",
        "store_id",
    ]
    brick_columns = [
        "mh_family_desc",
        "mh_class_desc",
        "brickname",
        "similargrouplevel",
    ]
    product_columns = [
        "similargrouplevel",
        "itemid",
        "styletype",
        "neckline",
        "pattern",
        "fabrictype",
        "sleeve",
        "fit",
        "primarycolor",
        "brandname",
    ]

    duration_query, store_query, brick_query, product_query = await asyncio.gather(
        select_filter_subquery(
            TrendsBestSellers, list(duration_filter), duration_columns
        ),
        select_filter_subquery(TrendsStoreDetails, list(store_filter), store_columns),
        select_filter_subquery(TrendsBrickDetails, list(brick_filter), brick_columns),
        select_filter_subquery(
            TrendsProductAttributes, list(product_filter), product_columns
        ),
    )

    query = (
        select(
            duration_query.c.month_of_year,
            duration_query.c.quarter_of_year,
            store_query.c.zone_desc,
            store_query.c.state,
            store_query.c.city,
            store_query.c.districtsname,
            store_query.c.pin_code,
            store_query.c.store_id,
            brick_query.c.mh_family_desc,
            brick_query.c.mh_class_desc,
            brick_query.c.brickname,
            product_query.c.styletype,
            product_query.c.neckline,
            product_query.c.pattern,
            product_query.c.fabrictype,
            product_query.c.sleeve,
            product_query.c.fit,
            product_query.c.primarycolor,
            product_query.c.brandname,
        )
        .join(store_query, duration_query.c.store_id == store_query.c.store_id)
        .join(product_query, product_query.c.itemid == duration_query.c.itemid)
        .join(
            brick_query,
            brick_query.c.similargrouplevel == product_query.c.similargrouplevel,
        )
    )

    return query
