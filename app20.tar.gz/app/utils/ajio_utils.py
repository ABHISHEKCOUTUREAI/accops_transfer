import asyncio
import json
from collections import defaultdict
from sqlalchemy import select, func, and_
from models import (
    AjioBestSellers,
    AjioProductAttributes,
    AjioDemographicDetails,
    AjioBrickDetails,
)
from .common_utils import build_filter_condition, select_filter_subquery
from db import psql_execute_single, check_in_redis, redis_db
from static import month_mapping, REDIS_WRITE_ERROR




async def get_ajio_filters_service(
    request_data: dict,
    api_contract_flag: bool = False,
    caching_flag: bool = False,
):
    cache_key = f"ajio_filters{json.dumps(request_data)}"
    cached_data = await check_in_redis(cache_key)
    if cached_data and not api_contract_flag:
        return json.loads(cached_data)

    query = await create_ajio_filters_query(request_data)

    if api_contract_flag:
        return query

    result = await psql_execute_single(query)

    response = await create_ajio_filters_response(result)

    try:
        await redis_db.set(cache_key, json.dumps(response, default=str))
    except Exception as e:
        print(REDIS_WRITE_ERROR, e)
  
    if caching_flag:
       print("Ajio filters loaded successfully")
    else:
        return response



async def create_ajio_filters_response(result):

    async def filter_values(result, index):
        values = list({val[index] for val in result if val[index] not in ["nan", None]})
        return sorted(values)


    async def create_demographic_section(result):
        return {
            "zone": await filter_values(result, 2),
            "state": await filter_values(result, 3),
            "city": await filter_values(result, 4),
            "district": await filter_values(result, 5),
        }

    async def create_brick_filters_section(result):
        return {
            "l1_name": await filter_values(result, 6),
            "l2_name": await filter_values(result, 7),
            "brick_name": await filter_values(result, 8),
        }

    async def create_attributes_section(result):
        return {
            "styletype": await filter_values(result, 9),
            "brandname": await filter_values(result, 16),
            "fabrictype": await filter_values(result, 12),
            "neckline": await filter_values(result, 10),
            "pattern": await filter_values(result, 11),
            "sleeve": await filter_values(result, 13),
            "fit": await filter_values(result, 14),
            "color": await filter_values(result, 15),
            "occasion": await filter_values(result, 17),
            "bodytype": await filter_values(result, 18),
            "materialtype": await filter_values(result, 19),
            "distress": await filter_values(result, 20),
            "traditionalweave": await filter_values(result, 21),
            "hemline": await filter_values(result, 22),
        }

    async def create_duration_section(result):
        return {
            "month": list({month_mapping[val[0]] for val in result if val[0] not in ["nan", None]}),
            "quarter": list({str(val[1]) for val in result if val[1] not in ["nan", None]}),
        }

 
    tasks = [
        create_demographic_section(result),
        create_brick_filters_section(result),
        create_attributes_section(result),
        create_duration_section(result)
    ]

    responses = await asyncio.gather(*tasks)
    
    return {
        "demographic": responses[0],
        "brick_filters": responses[1],
        "attributes": responses[2],
        "duration": responses[3]
    }



async def get_attributes_bestsellers_ajio(request_data, attribute: str):
    (
        product_filter,
        brick_filter,
        demographic_filter,
        bestseller_filter,
    ) = await asyncio.gather(
        build_filter_condition(request_filters=request_data, filter_flag="products"),
        build_filter_condition(request_filters=request_data, filter_flag="brick"),
        build_filter_condition(request_filters=request_data, filter_flag="demographic"),
        build_filter_condition(request_filters=request_data, filter_flag="bestsellers"),
    )

    product_query = (
        select(
            AjioProductAttributes.__dict__[attribute],
            AjioProductAttributes.productid,
            AjioProductAttributes.similargrouplevel,
        )
        .where(
            and_(*product_filter, AjioProductAttributes.__dict__[attribute].isnot(None))
        )
        .subquery()
    )

    brick_query = (
        select(AjioBrickDetails.brickname, AjioBrickDetails.similargrouplevel)
        .where(and_(*brick_filter))
        .subquery()
    )

    sold_in_week_query = (
        select(
            AjioBestSellers.sold_quantity_in_a_week,
            AjioBestSellers.productid,
            AjioBestSellers.pincode,
        )
        .where(and_(*bestseller_filter))
        .subquery()
    )

    demographic_query = (
        select(
            AjioDemographicDetails.pincode,
        )
        .where(and_(*demographic_filter))
        .subquery()
    )

    query = (
        select(
            product_query.c[attribute],
            brick_query.c.brickname,
            func.sum(sold_in_week_query.c.sold_quantity_in_a_week).label("quantity"),
        )
        .join(
            brick_query,
            product_query.c.similargrouplevel == brick_query.c.similargrouplevel,
        )
        .join(
            sold_in_week_query,
            product_query.c.productid == sold_in_week_query.c.productid,
        )
        .join(
            demographic_query,
            demographic_query.c.pincode == sold_in_week_query.c.pincode,
        )
        .group_by(
            product_query.c[attribute],
            brick_query.c.brickname,
        )
        .order_by(func.sum(sold_in_week_query.c.sold_quantity_in_a_week).desc())
    )

    rows = await psql_execute_single(query)

    result = defaultdict(dict)
    for row in rows:
        if row[0] and row[0] != 'nan':
            result[row[1]][row[0]] = float(row[2])

    return result


async def create_ajio_filters_query(request_data):
    (
        duration_filter,
        demography_filter,
        brick_filter,
        product_filter,
    ) = await asyncio.gather(
        build_filter_condition(request_filters=request_data, filter_flag="bestsellers"),
        build_filter_condition(request_filters=request_data, filter_flag="demographic"),
        build_filter_condition(request_filters=request_data, filter_flag="brick"),
        build_filter_condition(request_filters=request_data, filter_flag="products"),
    )

    duration_columns = [
        "month_of_year",
        "quarter_of_year",
        "productid",
        "pincode",
    ]
    demography_columns = ["zone", "state", "city", "districtsname", "pincode"]
    brick_columns = ["l1name", "l2name", "brickname", "similargrouplevel"]
    product_columns = [
        "productid",
        "styletype",
        "neckline",
        "pattern",
        "fabrictype",
        "sleevelength",
        "fit",
        "colorfamily",
        "brandname",
        "occasion",
        "bodytype",
        "materialtype",
        "distress",
        "traditionalweave",
        "hemline",
        "similargrouplevel",
    ]

    (
        duration_query,
        demographic_query,
        brick_query,
        product_query,
    ) = await asyncio.gather(
        select_filter_subquery(
            AjioBestSellers, list(duration_filter), duration_columns
        ),
        select_filter_subquery(
            AjioDemographicDetails, list(demography_filter), demography_columns
        ),
        select_filter_subquery(AjioBrickDetails, list(brick_filter), brick_columns),
        select_filter_subquery(
            AjioProductAttributes, list(product_filter), product_columns
        ),
    )

    # join all 4 queries to get the final result
    query = (
        select(
            duration_query.c.month_of_year,
            duration_query.c.quarter_of_year,
            demographic_query.c.zone,
            demographic_query.c.state,
            demographic_query.c.city,
            demographic_query.c.districtsname,
            brick_query.c.l1name,
            brick_query.c.l2name,
            brick_query.c.brickname,
            product_query.c.styletype,
            product_query.c.neckline,
            product_query.c.pattern,
            product_query.c.fabrictype,
            product_query.c.sleevelength,
            product_query.c.fit,
            product_query.c.colorfamily,
            product_query.c.brandname,
            product_query.c.occasion,
            product_query.c.bodytype,
            product_query.c.materialtype,
            product_query.c.distress,
            product_query.c.traditionalweave,
            product_query.c.hemline,
        )
        .join(
            demographic_query, demographic_query.c.pincode == duration_query.c.pincode
        )
        .join(product_query, product_query.c.productid == duration_query.c.productid)
        .join(
            brick_query,
            brick_query.c.similargrouplevel == product_query.c.similargrouplevel,
        )
    )

    return query
