from sqlalchemy import select
from collections import defaultdict
import asyncio
import json
from models import (
    AjioBrickDetails,
    AjioProductAttributes,
    AjioSearchQueriesTopInteractedProducts,
)
from db import psql_execute_single, check_in_redis, redis_db
from static import month_mapping, REDIS_WRITE_ERROR

from .common_utils import build_filter_condition, select_filter_subquery




async def build_search_interaction_filters_response(result):

    response = {
        "brick_filters": {
            "l1_name": sorted(list(set([row[4] for row in result if row[4] != "nan" and row[4] is not None]))),
            "l2_name": sorted(list(set([row[5] for row in result if row[5] != "nan" and row[5] is not None]))),
            "brick_name": sorted(list(set([row[6] for row in result if row[6] != "nan" and row[6] is not None]))),
        },
        "attributes": {
            "brandname": sorted(list(set([row[7] for row in result if row[7] != "nan" and row[7] is not None]))),
        },
        "search_filters": {
            "search_type": sorted(list(set([row[2] for row in result if row[2] != "nan" and row[2] is not None]))),
            "search_query": sorted(list(set([row[3] for row in result if row[3] != "nan" and row[3] is not None]))),
        },
        "duration": {
            "month": sorted(list(set([month_mapping[row[0]] for row in result if row[0] != "nan" and row[0] is not None]))),
            "week": sorted(list(set([str(row[1]) for row in result if row[1] != "nan" and row[1] is not None]))),
        },
    }

    return response



async def create_search_interaction_filter_query(request_data):
    duration_filter, brick_filter, product_filter = await asyncio.gather(
        build_filter_condition(
            filter_flag="duration", request_filters=request_data, type="ajio-search"
        ),
        build_filter_condition(
            filter_flag="brick", request_filters=request_data, type="ajio-search"
        ),
        build_filter_condition(
            filter_flag="attributes", request_filters=request_data, type="ajio-search"
        ),
    )

    duration_columns = [
        "month_of_year",
        "week_of_year",
        "search_type",
        "normalized_search_term",
        "productid",
    ]
    brick_columns = ["l1name", "l2name", "brickname", "similargrouplevel"]
    product_columns = ["productid", "brandname", "similargrouplevel"]

    duration_search_query, brick_query, product_attributes_query = await asyncio.gather(
        select_filter_subquery(
            AjioSearchQueriesTopInteractedProducts, list(duration_filter), duration_columns
        ),
        select_filter_subquery(AjioBrickDetails, list(brick_filter), brick_columns),
        select_filter_subquery(
            AjioProductAttributes, list(product_filter), product_columns
        ),
    )

    query = (
        select(
            duration_search_query.c.month_of_year,
            duration_search_query.c.week_of_year,
            duration_search_query.c.search_type,
            duration_search_query.c.normalized_search_term,
            brick_query.c.l1name,
            brick_query.c.l2name,
            brick_query.c.brickname,
            product_attributes_query.c.brandname,
        )
        .join(
            product_attributes_query,
            duration_search_query.c.productid == product_attributes_query.c.productid,
        )
        .join(
            brick_query,
            brick_query.c.similargrouplevel == product_attributes_query.c.similargrouplevel,
        )
    )
    return query



async def get_search_interaction_filters_service(
        request_data: dict,
        caching_flag: bool = False,
):
    cache_key = f"search_interaction_filters:{json.dumps(request_data)}"
    cached_data = await check_in_redis(cache_key)
    if cached_data:
        return json.loads(cached_data)  
       
    query = await create_search_interaction_filter_query(request_data)
    result = await psql_execute_single(query)
    response = await build_search_interaction_filters_response(result)


    try:
        await redis_db.set(cache_key, json.dumps(response, default=str))
    except Exception as e:
        print(REDIS_WRITE_ERROR, e)

    if caching_flag:
       print("Ajio-Search-Interaction filters loaded successfully")
    else:
        return response






