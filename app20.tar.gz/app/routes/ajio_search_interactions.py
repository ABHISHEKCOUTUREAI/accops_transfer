import asyncio
import json
from collections import defaultdict

from db import check_in_redis, psql_execute_multiple, psql_execute_single, redis_db
from fastapi import APIRouter
from models import (
    AjioBrickDetails,
    AjioProductAttributes,
    AjioSearchQueriesTopInteractedProducts,
)
from settings import settings
from sqlalchemy import and_, func, select
from static import REDIS_WRITE_ERROR
from utils import (
    build_filter_condition,
    sort_and_paginate,
    get_search_interaction_filters_service
)

TopProductQueryRouter = APIRouter(
    prefix=settings.api_prefix,
    tags=["Ajio Search Interactions"],
    responses={404: {"description": "Not found"}},
)



@TopProductQueryRouter.post("/search-interactions-filters")
async def get_search_interaction_filters(
    request_data: dict,
):
    
    return await get_search_interaction_filters_service(request_data, caching_flag = False)



@TopProductQueryRouter.post("/top-interacted-queries")
async def top_interacted_queries(
    request_data: dict,
):
    cache_key = f"top_interacted_queries_:{json.dumps(request_data)}"
    cached_data = await check_in_redis(cache_key)
    if cached_data:
        return json.loads(cached_data)

    duration_filter, search_filter, brick_filter, product_filter = await asyncio.gather(
        build_filter_condition(
            filter_flag="duration", request_filters=request_data, type="ajio-search"
        ),
        build_filter_condition(
            filter_flag="search", request_filters=request_data, type="ajio-search"
        ),
        build_filter_condition(
            filter_flag="brick", request_filters=request_data, type="ajio-search"
        ),
        build_filter_condition(
            filter_flag="attributes", request_filters=request_data, type="ajio-search"
        ),
    )

    queries_filter = list(duration_filter) + list(search_filter)

    query = select(
        AjioSearchQueriesTopInteractedProducts.normalized_search_term,
        AjioSearchQueriesTopInteractedProducts.productid,
        AjioSearchQueriesTopInteractedProducts.total_clicks_query,
    ).where(and_(*queries_filter))

    brick_query = (
        select(AjioBrickDetails.similargrouplevel).where(and_(*brick_filter)).subquery()
    )

    product_attributes_query = (
        select(AjioProductAttributes.productid, AjioProductAttributes.similargrouplevel)
        .where(and_(*product_filter))
        .subquery()
    )

    query = (
        select(
            query.c.normalized_search_term,
            func.sum(query.c.total_clicks_query).label("total_clicks_query"),
        )
        .join(
            product_attributes_query,
            query.c.productid == product_attributes_query.c.productid,
        )
        .join(
            brick_query,
            brick_query.c.similargrouplevel
            == product_attributes_query.c.similargrouplevel,
        )
        .group_by(
            query.c.normalized_search_term,
        )
    )

    total_count_query = select(func.count()).select_from(query)
    query = await sort_and_paginate(query, request_data, "total_clicks_query")
    query_list = [total_count_query, query]

    result = await psql_execute_multiple(query_list)

    result = {
        "total_count": result[0][0][0],
        "rows": [
            {"normalized_search_term": row[0], "total_clicks_query": row[1]}
            for row in result[1]
        ],
    }

    try:
        await redis_db.set(cache_key, json.dumps(result, default=str))
    except Exception as e:
        print(REDIS_WRITE_ERROR, e)

    return result


@TopProductQueryRouter.post("/top-interacted-categories")
async def top_interacted_categories(
    request_data: dict,
):
    cache_key = f"top_interacted_categories_:{json.dumps(request_data)}"
    cached_data = await check_in_redis(cache_key)
    if cached_data:
        return json.loads(cached_data)

    duration_filter, search_filter, brick_filter, product_filter = await asyncio.gather(
        build_filter_condition(
            filter_flag="duration", request_filters=request_data, type="ajio-search"
        ),
        build_filter_condition(
            filter_flag="search", request_filters=request_data, type="ajio-search"
        ),
        build_filter_condition(
            filter_flag="brick", request_filters=request_data, type="ajio-search"
        ),
        build_filter_condition(
            filter_flag="attributes", request_filters=request_data, type="ajio-search"
        ),
    )

    categories_filter = list(duration_filter) + list(search_filter)
    query = select(
        AjioSearchQueriesTopInteractedProducts.productid,
        AjioSearchQueriesTopInteractedProducts.total_clicks_query,
    ).where(and_(*categories_filter))

    brick_query = (
        select(
            AjioBrickDetails.l1name,
            AjioBrickDetails.l2name,
            AjioBrickDetails.brickname,
            AjioBrickDetails.similargrouplevel,
        )
        .where(and_(*brick_filter))
        .subquery()
    )

    product_attributes_query = (
        select(AjioProductAttributes.productid, AjioProductAttributes.similargrouplevel)
        .where(and_(*product_filter))
        .subquery()
    )

    query = (
        select(
            brick_query.c.l1name,
            brick_query.c.l2name,
            brick_query.c.brickname,
            func.sum(query.c.total_clicks_query).label("total_clicks_query"),
        )
        .join(
            product_attributes_query,
            query.c.productid == product_attributes_query.c.productid,
        )
        .join(
            brick_query,
            brick_query.c.similargrouplevel
            == product_attributes_query.c.similargrouplevel,
        )
        .group_by(
            brick_query.c.l1name,
            brick_query.c.l2name,
            brick_query.c.brickname,
        )
    )

    total_count_query = select(func.count()).select_from(query)
    query = await sort_and_paginate(query, request_data, "total_clicks_query")
    query_list = [total_count_query, query]

    result = await psql_execute_multiple(query_list)

    result = {
        "total_count": result[0][0][0],
        "rows": [
            {
                "l1name": row[0],
                "l2name": row[1],
                "brickname": row[2],
                "total_clicks_query": row[3],
            }
            for row in result[1]
        ],
    }

    try:
        await redis_db.set(cache_key, json.dumps(result, default=str))
    except Exception as e:
        print(REDIS_WRITE_ERROR, e)

    return result


@TopProductQueryRouter.post("/top-interacted-products")
async def top_interacted_products(
    request_data: dict,
):
    cache_key = f"top_interacted_products:{json.dumps(request_data)}"
    cached_data = await check_in_redis(cache_key)
    if cached_data:
        return json.loads(cached_data)

    duration_filter, search_filter, brick_filter, product_filter = await asyncio.gather(
        build_filter_condition(
            filter_flag="duration", request_filters=request_data, type="ajio-search"
        ),
        build_filter_condition(
            filter_flag="search", request_filters=request_data, type="ajio-search"
        ),
        build_filter_condition(
            filter_flag="brick", request_filters=request_data, type="ajio-search"
        ),
        build_filter_condition(
            filter_flag="attributes", request_filters=request_data, type="ajio-search"
        ),
    )
    


    query = select(
        AjioSearchQueriesTopInteractedProducts.productid,
        AjioSearchQueriesTopInteractedProducts.total_clicks_query,
    ).where(and_(*duration_filter, *search_filter))


    brick_query = (
        select(AjioBrickDetails.similargrouplevel).where(and_(*brick_filter)).subquery()
    )


    product_attributes_query = (
        select(
            AjioProductAttributes.productid,
            AjioProductAttributes.similargrouplevel,
            AjioProductAttributes.productid,
            AjioProductAttributes.title,
            AjioProductAttributes.imgcode,
            AjioProductAttributes.brandname,
        )
        .where(and_(*product_filter))
        .subquery()
    )

    final_query = (
        select(
            product_attributes_query.c.productid,
            product_attributes_query.c.title,
            product_attributes_query.c.brandname,
            product_attributes_query.c.imgcode,
            func.sum(query.c.total_clicks_query).label("total_clicks_query"),
        )
        .join(
            product_attributes_query,
            query.c.productid == product_attributes_query.c.productid,
        )
        .join(
            brick_query,
            brick_query.c.similargrouplevel
            == product_attributes_query.c.similargrouplevel,
        )
        .group_by(
            product_attributes_query.c.productid,
            product_attributes_query.c.title,
            product_attributes_query.c.brandname,
            product_attributes_query.c.imgcode,
        )
    )

    total_count_query = select(func.count()).select_from(final_query)
    final_query = await sort_and_paginate(
        final_query, request_data, "total_clicks_query"
    )
    query_list = [total_count_query, final_query]

    result = await psql_execute_multiple(query_list)

    result = {
        "total_count": result[0][0][0],
        "rows": [
            {
                "productid": row[0],
                "title": row[1],
                "brandname": row[2],
                "imgcode": row[3],
                "total_clicks_query": row[4],
            }
            for row in result[1]
        ],
    }

    try:
        await redis_db.set(cache_key, json.dumps(result, default=str))
    except Exception as e:
        print(REDIS_WRITE_ERROR, e)

    return result


@TopProductQueryRouter.post("/top-interacted-brands")
async def top_interacted_brands(
    request_data: dict,
):
    cache_key = f"top_interacted_brands_:{json.dumps(request_data)}"
    cached_data = await check_in_redis(cache_key)
    if cached_data:
        return json.loads(cached_data)

    duration_filter, search_filter, brick_filter, product_filter = await asyncio.gather(
        build_filter_condition(
            filter_flag="duration", request_filters=request_data, type="ajio-search"
        ),
        build_filter_condition(
            filter_flag="search", request_filters=request_data, type="ajio-search"
        ),
        build_filter_condition(
            filter_flag="brick", request_filters=request_data, type="ajio-search"
        ),
        build_filter_condition(
            filter_flag="attributes", request_filters=request_data, type="ajio-search"
        ),
    )
    brand_filter = list(duration_filter) + list(search_filter)

    query = select(
        AjioSearchQueriesTopInteractedProducts.productid,
        AjioSearchQueriesTopInteractedProducts.total_clicks_query,
    ).where(and_(*brand_filter))

    brick_query = (
        select(AjioBrickDetails.similargrouplevel).where(and_(*brick_filter)).subquery()
    )

    product_attributes_query = (
        select(
            AjioProductAttributes.productid,
            AjioProductAttributes.brandname,
            AjioProductAttributes.similargrouplevel,
        )
        .where(and_(*product_filter))
        .subquery()
    )

    query = (
        select(
            product_attributes_query.c.brandname,
            func.sum(query.c.total_clicks_query).label("total_clicks_query"),
        )
        .join(
            product_attributes_query,
            query.c.productid == product_attributes_query.c.productid,
        )
        .join(
            brick_query,
            brick_query.c.similargrouplevel
            == product_attributes_query.c.similargrouplevel,
        )
        .group_by(
            product_attributes_query.c.brandname,
        )
    )

    query = await sort_and_paginate(query, request_data, "total_clicks_query")

    result = await psql_execute_single(query)

    rows = [{"brandname": row[0], "total_clicks_query": row[1]} for row in result]

    try:
        await redis_db.set(cache_key, json.dumps(rows, default=str))
    except Exception as e:
        print(REDIS_WRITE_ERROR, e)

    return rows


@TopProductQueryRouter.post("/top-interacted-product-titles")
async def top_interacted_titles(
    request_data: dict,
):
    cache_key = f"top_interacted_product_titles_:{json.dumps(request_data)}"
    cached_data = await check_in_redis(cache_key)
    if cached_data:
        return json.loads(cached_data)

    duration_filter, search_filter, brick_filter, product_filter = await asyncio.gather(
        build_filter_condition(
            filter_flag="duration", request_filters=request_data, type="ajio-search"
        ),
        build_filter_condition(
            filter_flag="search", request_filters=request_data, type="ajio-search"
        ),
        build_filter_condition(
            filter_flag="brick", request_filters=request_data, type="ajio-search"
        ),
        build_filter_condition(
            filter_flag="attributes", request_filters=request_data, type="ajio-search"
        ),
    )
    title_filter = list(duration_filter) + list(search_filter)

    query = select(
        AjioSearchQueriesTopInteractedProducts.productid,
        AjioSearchQueriesTopInteractedProducts.total_clicks_query,
    ).where(and_(*title_filter))

    brick_query = (
        select(AjioBrickDetails.similargrouplevel).where(and_(*brick_filter)).subquery()
    )

    product_attributes_query = (
        select(
            AjioProductAttributes.productid,
            AjioProductAttributes.title,
            AjioProductAttributes.similargrouplevel,
        )
        .where(and_(*product_filter))
        .subquery()
    )

    query = (
        select(
            product_attributes_query.c.title,
            func.sum(query.c.total_clicks_query).label("total_clicks_query"),
        )
        .join(
            product_attributes_query,
            query.c.productid == product_attributes_query.c.productid,
        )
        .join(
            brick_query,
            brick_query.c.similargrouplevel
            == product_attributes_query.c.similargrouplevel,
        )
        .group_by(
            product_attributes_query.c.title,
        )
    )

    query = await sort_and_paginate(query, request_data, "total_clicks_query")

    result = await psql_execute_single(query)

    rows = [{"title": row[0], "total_clicks_query": row[1]} for row in result]

    try:
        await redis_db.set(cache_key, json.dumps(rows, default=str))
    except Exception as e:
        print(REDIS_WRITE_ERROR, e)

    return rows


@TopProductQueryRouter.post("/top-queries-session")
async def get_top_queries_by_session(
    request_data: dict,
):
    cache_key = f"top_queries_session_:{json.dumps(request_data)}"
    cached_data = await check_in_redis(cache_key)
    if cached_data:
        return json.loads(cached_data)

    duration_filter, search_filter, brick_filter, product_filter = await asyncio.gather(
        build_filter_condition(
            filter_flag="duration", request_filters=request_data, type="ajio-search"
        ),
        build_filter_condition(
            filter_flag="search", request_filters=request_data, type="ajio-search"
        ),
        build_filter_condition(
            filter_flag="brick", request_filters=request_data, type="ajio-search"
        ),
        build_filter_condition(
            filter_flag="attributes", request_filters=request_data, type="ajio-search"
        ),
    )
    session_filter = list(duration_filter) + list(search_filter)

    query = select(
        AjioSearchQueriesTopInteractedProducts.normalized_search_term,
        AjioSearchQueriesTopInteractedProducts.productid,
        AjioSearchQueriesTopInteractedProducts.sum_session_counts,
    ).where(and_(*session_filter))
    brick_query = (
        select(AjioBrickDetails.similargrouplevel).where(and_(*brick_filter)).subquery()
    )

    product_attributes_query = (
        select(AjioProductAttributes.productid, AjioProductAttributes.similargrouplevel)
        .where(and_(*product_filter))
        .subquery()
    )

    query = (
        select(
            query.c.normalized_search_term,
            func.sum(query.c.sum_session_counts).label("sum_session_counts"),
        )
        .join(
            product_attributes_query,
            query.c.productid == product_attributes_query.c.productid,
        )
        .join(
            brick_query,
            brick_query.c.similargrouplevel
            == product_attributes_query.c.similargrouplevel,
        )
        .group_by(
            query.c.normalized_search_term,
        )
    )

    query = await sort_and_paginate(query, request_data, "sum_session_counts")

    result = await psql_execute_single(query)

    rows = [
        {"normalized_search_term": row[0], "sum_session_counts": row[1]}
        for row in result
    ]

    try:
        await redis_db.set(cache_key, json.dumps(rows, default=str))
    except Exception as e:
        print(REDIS_WRITE_ERROR, e)

    return rows


@TopProductQueryRouter.post("/top-search-queries")
async def top_search_queries(
    request_data: dict,
):
    cache_key = f"top_search_queries_:{json.dumps(request_data)}"
    cached_data = await check_in_redis(cache_key)
    if cached_data:
        return json.loads(cached_data)

    duration_filter, search_filter, brick_filter, product_filter = await asyncio.gather(
        build_filter_condition(
            filter_flag="duration", request_filters=request_data, type="ajio-search"
        ),
        build_filter_condition(
            filter_flag="search", request_filters=request_data, type="ajio-search"
        ),
        build_filter_condition(
            filter_flag="brick", request_filters=request_data, type="ajio-search"
        ),
        build_filter_condition(
            filter_flag="attributes", request_filters=request_data, type="ajio-search"
        ),
    )
    queries_filter = list(duration_filter) + list(search_filter)

    query = select(
        AjioSearchQueriesTopInteractedProducts.search_type,
        AjioSearchQueriesTopInteractedProducts.normalized_search_term,
        AjioSearchQueriesTopInteractedProducts.month_of_year,
        AjioSearchQueriesTopInteractedProducts.week_of_year,
        AjioSearchQueriesTopInteractedProducts.productid,
        AjioSearchQueriesTopInteractedProducts.total_clicks_query,
    ).where(and_(*queries_filter))

    brick_query = (
        select(AjioBrickDetails.similargrouplevel).where(and_(*brick_filter)).subquery()
    )

    product_attributes_query = (
        select(AjioProductAttributes.productid, AjioProductAttributes.similargrouplevel)
        .where(and_(*product_filter))
        .subquery()
    )

    query = (
        select(
            query.c.search_type,
            query.c.normalized_search_term,
            query.c.month_of_year,
            query.c.week_of_year,
            func.sum(query.c.total_clicks_query).label("total_clicks_query"),
        )
        .join(
            product_attributes_query,
            query.c.productid == product_attributes_query.c.productid,
        )
        .join(
            brick_query,
            brick_query.c.similargrouplevel
            == product_attributes_query.c.similargrouplevel,
        )
        .group_by(
            query.c.search_type,
            query.c.normalized_search_term,
            query.c.month_of_year,
            query.c.week_of_year,
        )
    )

    total_count_query = select(func.count()).select_from(query)
    query = await sort_and_paginate(query, request_data, "total_clicks_query")
    query_list = [total_count_query, query]

    result = await psql_execute_multiple(query_list)

    result = {
        "total_count": result[0][0][0],
        "rows": [
            {
                "search_type": row[0],
                "normalized_search_term": row[1],
                "month_of_year": row[2],
                "week_of_year": row[3],
                "total_clicks_query": row[4],
            }
            for row in result[1]
        ],
    }

    try:
        await redis_db.set(cache_key, json.dumps(result, default=str))
    except Exception as e:
        print(REDIS_WRITE_ERROR, e)

    return result


@TopProductQueryRouter.post("/most-interacted-products")
async def most_interacted_products(
    request_data: dict,
):
    cache_key = f"most_interacted_products_:{json.dumps(request_data)}"
    cached_data = await check_in_redis(cache_key)
    if cached_data:
        return json.loads(cached_data)

    brick_filter, product_filter, duration_filter, search_filter = await asyncio.gather(
        build_filter_condition(
            filter_flag="brick", request_filters=request_data, type="ajio-search"
        ),
        build_filter_condition(
            filter_flag="attributes", request_filters=request_data, type="ajio-search"
        ),
        build_filter_condition(
            filter_flag="duration", request_filters=request_data, type="ajio-search"
        ),
        build_filter_condition(
            filter_flag="search", request_filters=request_data, type="ajio-search"
        ),
    )

    brick_details_query = (
        select(
            AjioBrickDetails.l1name,
            AjioBrickDetails.l2name,
            AjioBrickDetails.brickname,
            AjioBrickDetails.similargrouplevel,
        )
        .where(and_(*brick_filter))
        .subquery()
    )

    product_attributes_query = (
        select(
            AjioProductAttributes.productid,
            AjioProductAttributes.title,
            AjioProductAttributes.brandname,
            AjioProductAttributes.similargrouplevel,
        )
        .where(and_(*product_filter))
        .subquery()
    )

    products_filter = list(duration_filter) + list(search_filter)

    top_search_query = (
        select(
            AjioSearchQueriesTopInteractedProducts.productid,
            AjioSearchQueriesTopInteractedProducts.normalized_search_term,
            AjioSearchQueriesTopInteractedProducts.month_of_year,
            AjioSearchQueriesTopInteractedProducts.week_of_year,
            AjioSearchQueriesTopInteractedProducts.total_clicks_query,
            AjioSearchQueriesTopInteractedProducts.clicks_product,
        )
        .where(and_(*products_filter))
        .subquery()
    )

    query = (
        select(
            top_search_query.c.month_of_year,
            top_search_query.c.week_of_year,
            top_search_query.c.normalized_search_term,
            product_attributes_query.c.brandname,
            product_attributes_query.c.productid,
            product_attributes_query.c.title,
            brick_details_query.c.brickname,
            top_search_query.c.clicks_product,
            brick_details_query.c.l1name,
            brick_details_query.c.l2name,
            func.sum(top_search_query.c.total_clicks_query).label("total_clicks_query"),
        )
        .join(
            product_attributes_query,
            top_search_query.c.productid == product_attributes_query.c.productid,
        )
        .join(
            brick_details_query,
            brick_details_query.c.similargrouplevel
            == product_attributes_query.c.similargrouplevel,
        )
        .group_by(
            product_attributes_query.c.brandname,
            product_attributes_query.c.productid,
            product_attributes_query.c.title,
            brick_details_query.c.brickname,
            top_search_query.c.clicks_product,
            brick_details_query.c.l1name,
            brick_details_query.c.l2name,
            top_search_query.c.month_of_year,
            top_search_query.c.week_of_year,
            top_search_query.c.normalized_search_term,
        )
    )

    total_count_query = select(func.count()).select_from(query)
    query = await sort_and_paginate(query, request_data, "total_clicks_query")
    query_list = [total_count_query, query]

    result = await psql_execute_multiple(query_list)

    result = {
        "total_count": result[0][0][0],
        "rows": [
            {
                "month_of_year": row[0],
                "week_of_year": row[1],
                "normalized_search_term": row[2],
                "brandname": row[3],
                "productid": row[4],
                "title": row[5],
                "brickname": row[6],
                "clicks_product": row[7],
                "l1name": row[8],
                "l2name": row[9],
                "total_clicks_query": row[10],
            }
            for row in result[1]
        ],
    }

    try:
        await redis_db.set(cache_key, json.dumps(result, default=str))
    except Exception as e:
        print(REDIS_WRITE_ERROR, e)

    return result
