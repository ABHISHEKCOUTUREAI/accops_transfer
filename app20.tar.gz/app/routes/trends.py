import asyncio
import json
from collections import defaultdict

from db import check_in_redis, psql_execute_multiple, psql_execute_single, redis_db
from fastapi import APIRouter
from models import (
    Calenderyearmonthweekinfo,
    TrendsBestSellers,
    TrendsBrickDetails,
    TrendsProductAttributes,
    TrendsStoreDetails,
)
from settings import settings
from sqlalchemy import Numeric, and_, cast, func, select
from static import REDIS_CONNECT_ERROR, REDIS_WRITE_ERROR, indian_states
from utils import (
    build_filter_condition,
    get_attributes_bestsellers_trends,
    sort_and_paginate,
    get_trends_filters_service
)

TrendsRouter = APIRouter(
    prefix=settings.api_prefix,
    tags=["Trends"],
    responses={404: {"description": "Not found"}},
)



@TrendsRouter.post("/trends-filters")
async def get_trends_filters(request_data: dict):


    return await get_trends_filters_service(request_data, caching_flag = False)


@TrendsRouter.post("/bestsellers-products-trends")
async def bestsellers_products_trends(
    request_data: dict,
):
    cache_key = f"bestsellers-products-trends-{json.dumps(request_data)}"
    try:
        cached_data = await check_in_redis(cache_key)
    except Exception as e:
        print(REDIS_CONNECT_ERROR, e)
        cached_data = None
    if cached_data:
        return json.loads(cached_data)

    (
        bestseller_filter,
        product_filter,
        store_filter,
        brick_filter,
        calender_filter,
    ) = await asyncio.gather(
        build_filter_condition(
            type="trends", request_filters=request_data, filter_flag="bestsellers"
        ),
        build_filter_condition(
            type="trends", request_filters=request_data, filter_flag="products"
        ),
        build_filter_condition(
            type="trends", request_filters=request_data, filter_flag="store_filters"
        ),
        build_filter_condition(
            type="trends", request_filters=request_data, filter_flag="category"
        ),
        build_filter_condition(
            type="calender", request_filters=request_data, filter_flag="calender"
        ),
    )

    bestseller_query = (
        select(
            TrendsBestSellers.itemid,
            TrendsBestSellers.week_of_year,
            TrendsBestSellers.year,
            TrendsBestSellers.store_id,
            TrendsBestSellers.sold_quantity_in_a_week,
        )
        .where(and_(*bestseller_filter))
        .subquery()
    )

    store_query = (
        select(
            TrendsStoreDetails.store_id,
        )
        .where(and_(*store_filter))
        .subquery()
    )

    calender_query = (
        select(
            Calenderyearmonthweekinfo.week_of_year,
            Calenderyearmonthweekinfo.year,
            func.sum(Calenderyearmonthweekinfo.num_days_in_week).label(
                "total_days_count_across_week"
            ),
        )
        .where(and_(*calender_filter))
        .group_by(
            Calenderyearmonthweekinfo.week_of_year, Calenderyearmonthweekinfo.year
        )
        .subquery()
    )

    ros_query = (
        select(
            bestseller_query.c.itemid,
            bestseller_query.c.week_of_year,
            bestseller_query.c.year,
            func.sum(bestseller_query.c.sold_quantity_in_a_week).label(
                "sold_quantity_across_each_week"
            ),
        )
        .join(store_query, store_query.c.store_id == bestseller_query.c.store_id)
        .group_by(
            bestseller_query.c.itemid,
            bestseller_query.c.week_of_year,
            bestseller_query.c.year,
        )
        .subquery()
    )

    # join ros and calender query
    ros_query = (
        select(
            ros_query.c.itemid,
            ros_query.c.year,
            ros_query.c.sold_quantity_across_each_week,
            calender_query.c.total_days_count_across_week,
        )
        .join(
            calender_query,
            and_(
                calender_query.c.week_of_year == ros_query.c.week_of_year,
                calender_query.c.year == ros_query.c.year,
            ),
        )
        .subquery()
    )

    ros_query = (
        select(
            ros_query.c.itemid,
            ros_query.c.year,
            func.sum(ros_query.c.sold_quantity_across_each_week).label(
                "total_sold_quantity"
            ),
            func.round(
                cast(
                    (
                        (
                            func.sum(ros_query.c.sold_quantity_across_each_week)
                            / func.sum(ros_query.c.total_days_count_across_week)
                        )
                        * 7
                    ),
                    Numeric,
                ),
                2,
            ).label("weekly_rate_of_sale"),
        )
        .group_by(ros_query.c.itemid, ros_query.c.year)
        .subquery()
    )

    product_query = (
        select(
            TrendsProductAttributes.itemid,
            TrendsProductAttributes.brandname,
            TrendsProductAttributes.styletype,
            TrendsProductAttributes.primarycolor,
            TrendsProductAttributes.pattern,
            TrendsProductAttributes.fabrictype,
            TrendsProductAttributes.materialtype,
            TrendsProductAttributes.sleeve,
            TrendsProductAttributes.fit,
            TrendsProductAttributes.neckline,
            TrendsProductAttributes.imgcode,
            TrendsProductAttributes.extension,
            TrendsProductAttributes.mrp,
            TrendsProductAttributes.similargrouplevel,
        )
        .where(and_(*product_filter))
        .subquery()
    )

    brick_query = (
        select(
            TrendsBrickDetails.mh_family_desc,
            TrendsBrickDetails.mh_class_desc,
            TrendsBrickDetails.brickname,
            TrendsBrickDetails.similargrouplevel,
        )
        .where(and_(*brick_filter))
        .subquery()
    )

    query = (
        select(
            product_query.c.itemid,
            product_query.c.brandname,
            product_query.c.styletype,
            product_query.c.primarycolor,
            product_query.c.pattern,
            product_query.c.fabrictype,
            product_query.c.materialtype,
            product_query.c.sleeve,
            product_query.c.fit,
            product_query.c.neckline,
            product_query.c.imgcode,
            product_query.c.extension,
            brick_query.c.mh_family_desc,
            brick_query.c.mh_class_desc,
            brick_query.c.brickname,
            product_query.c.mrp,
            ros_query.c.total_sold_quantity,
            ros_query.c.weekly_rate_of_sale,
        )
        .join(ros_query, ros_query.c.itemid == product_query.c.itemid)
        .join(
            brick_query,
            brick_query.c.similargrouplevel == product_query.c.similargrouplevel,
        )
    )
    # count the total number of rows
    total_count_query = select(func.count()).select_from(query)
    bestseller_query = await sort_and_paginate(
        query, request_data, "weekly_rate_of_sale"
    )

    query_list = [bestseller_query, total_count_query]

    result = await psql_execute_multiple(query_list)
    result = {
        "total_count": result[1][0][0],
        "rows": [
            {
                "itemid": row[0],
                "brandname": row[1],
                "styletype": row[2],
                "primarycolor": row[3],
                "pattern": row[4],
                "fabrictype": row[5],
                "materialtype": row[6],
                "sleeve": row[7],
                "fit": row[8],
                "neckline": row[9],
                "imgcode": row[10],
                "extension": row[11],
                "mh_family_desc": row[12],
                "mh_class_desc": row[13],
                "brickname": row[14],
                "mrp": round(float(row[15]), 2),
                "total_qty": round(float(row[16]), 2),
                "weekly_rate_of_sale": round(float(row[17]), 2),
            }
            for row in result[0]
        ],
    }

    try:
        await redis_db.set(cache_key, json.dumps(result, default=str))
    except Exception as e:
        print(REDIS_WRITE_ERROR, e)

    return result


@TrendsRouter.post("/statewise-sales-trends")
async def get_statewise_sales(
    request_data: dict,
):
    cache_key = f"statewise-sales-{json.dumps(request_data)}"
    try:
        cached_data = await check_in_redis(cache_key)
    except Exception as e:
        print(REDIS_CONNECT_ERROR, e)
        cached_data = None
    if cached_data:
        return json.loads(cached_data)

    sold_in_week_query = (
        select(
            TrendsStoreDetails.state,
            func.sum(TrendsBestSellers.sold_quantity_in_a_week).label("quantity"),
        )
        .join(
            TrendsBestSellers, TrendsStoreDetails.store_id == TrendsBestSellers.store_id
        )
        .group_by(TrendsStoreDetails.state)
    )

    maps_rows_state = await psql_execute_single(sold_in_week_query)
    map_data = [
        {
            "state": row[0],
            "statecode": indian_states.get(row[0].lower(), {}).get(
                "statecode", "Not Found"
            ),
            "quantity_sold": float(row[1]),
        }
        for row in maps_rows_state
    ]

    try:
        await redis_db.set(cache_key, json.dumps(map_data, default=str))
    except Exception as e:
        print(REDIS_WRITE_ERROR, e)

    return map_data


@TrendsRouter.post("/fabric-bestsellers-trends")
async def get_fabric_bestsellers_trends(
    request_data: dict,
):
    cache_key = f"fabric-bestsellers-trends-{json.dumps(request_data)}"
    try:
        cached_data = await check_in_redis(cache_key)
    except Exception as e:
        print(REDIS_CONNECT_ERROR, e)
        cached_data = None
    if cached_data:
        return json.loads(cached_data)

    result = await get_attributes_bestsellers_trends(
        request_data,
        "fabrictype",
    )

    try:
        await redis_db.set(cache_key, json.dumps(result, default=str))
    except Exception as e:
        print(REDIS_WRITE_ERROR, e)

    return result


@TrendsRouter.post("/brandnames-bestsellers-trends")
async def brandnames_bestsellers_trends(
    request_data: dict,
):
    cache_key = f"brandnames-bestsellers-trends-{json.dumps(request_data)}"
    try:
        cached_data = await check_in_redis(cache_key)
    except Exception as e:
        print(REDIS_CONNECT_ERROR, e)
        cached_data = None
    if cached_data:
        return json.loads(cached_data)

    result = await get_attributes_bestsellers_trends(
        request_data,
        "brandname",
    )

    try:
        await redis_db.set(cache_key, json.dumps(result, default=str))
    except Exception as e:
        print(REDIS_WRITE_ERROR, e)

    return result


@TrendsRouter.post("/neckline-bestsellers-trends")
async def neckline_bestsellers_trends(
    request_data: dict,
):
    cache_key = f"neckline-bestsellers-trends-{json.dumps(request_data)}"
    try:
        cached_data = await check_in_redis(cache_key)
    except Exception as e:
        print(REDIS_CONNECT_ERROR, e)
        cached_data = None
    if cached_data:
        return json.loads(cached_data)

    result = await get_attributes_bestsellers_trends(
        request_data,
        "neckline",
    )

    try:
        await redis_db.set(cache_key, json.dumps(result, default=str))
    except Exception as e:
        print(REDIS_WRITE_ERROR, e)

    return result


@TrendsRouter.post("/styletype-bestsellers-trends")
async def styletype_bestsellers_trends(
    request_data: dict,
):
    cache_key = f"styletype-bestsellers-trends-{json.dumps(request_data)}"
    try:
        cached_data = await check_in_redis(cache_key)
    except Exception as e:
        print(REDIS_CONNECT_ERROR, e)
        cached_data = None
    if cached_data:
        return json.loads(cached_data)

    result = await get_attributes_bestsellers_trends(
        request_data,
        "styletype",
    )

    try:
        await redis_db.set(cache_key, json.dumps(result, default=str))
    except Exception as e:
        print(REDIS_WRITE_ERROR, e)

    return result


@TrendsRouter.post("/sleevelength-bestsellers-trends")
async def sleevelength_bestsellers_trends(
    request_data: dict,
):
    cache_key = f"sleevelength-bestsellers-trends-{json.dumps(request_data)}"
    try:
        cached_data = await check_in_redis(cache_key)
    except Exception as e:
        print(REDIS_CONNECT_ERROR, e)
        cached_data = None
    if cached_data:
        return json.loads(cached_data)

    result = await get_attributes_bestsellers_trends(
        request_data,
        "sleeve",
    )

    try:
        await redis_db.set(cache_key, json.dumps(result, default=str))
    except Exception as e:
        print(REDIS_WRITE_ERROR, e)

    return result


@TrendsRouter.post("/pattern-bestsellers-trends")
async def pattern_bestsellers_trends(
    request_data: dict,
):
    cache_key = f"pattern-bestsellers-trends-{json.dumps(request_data)}"
    try:
        cached_data = await check_in_redis(cache_key)
    except Exception as e:
        print(REDIS_CONNECT_ERROR, e)
        cached_data = None
    if cached_data:
        return json.loads(cached_data)

    result = await get_attributes_bestsellers_trends(
        request_data,
        "pattern",
    )

    try:
        await redis_db.set(cache_key, json.dumps(result, default=str))
    except Exception as e:
        print(REDIS_WRITE_ERROR, e)

    return result


@TrendsRouter.post("/color-bestsellers-trends")
async def color_bestsellers_trends(
    request_data: dict,
):
    cache_key = f"color-bestsellers-trends-{json.dumps(request_data)}"
    cached_data = await check_in_redis(cache_key)
    try:
        cached_data = await check_in_redis(cache_key)
    except Exception as e:
        print(REDIS_CONNECT_ERROR, e)
        cached_data = None
    if cached_data:
        return json.loads(cached_data)

    result = await get_attributes_bestsellers_trends(
        request_data,
        "primarycolor",
    )

    try:
        await redis_db.set(cache_key, json.dumps(result, default=str))
    except Exception as e:
        print(REDIS_WRITE_ERROR, e)

    return result
