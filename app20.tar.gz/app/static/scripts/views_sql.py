from sqlalchemy import text


# Create a materialized view to store the distinct search terms and weeks
combined_search_terms_weeks = text(
    """
CREATE MATERIALIZED VIEW IF NOT EXISTS combined_search_terms_weeks AS
SELECT 
    st.normalized_search_term,
    w.week_of_year
FROM 
    (SELECT DISTINCT normalized_search_term FROM ajio_search_queries_top_interacted_products) AS st,                                      
    (SELECT DISTINCT week_of_year FROM ajio_search_queries_top_interacted_products) AS w                                      
ORDER BY 
    st.normalized_search_term, w.week_of_year;
"""
)
