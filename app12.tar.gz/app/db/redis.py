from redis import asyncio as aioredis
from settings import settings

try:
    redis_db = aioredis.from_url(f'redis://{settings.redis_service}:{settings.redis_port}/{settings.redis_db}')
except Exception as e:
    print(f"Error connecting to redis: {e}")
    redis_db = None
