import pandas as pd
import os
import datetime
import numpy as np
from sqlalchemy import insert, text
from models import Assortment, NewStoresAssortment, Product, Store, Inventory, Bounce,  MarketResearchAnalysis, BayAllocationCategory, Sales
from databases import Database
import asyncpg

folder = os.path.join(os.getcwd(),"../corpus_files/assortment_data/")

async def insert_csv_into_db(model, file_name, postgres_db: Database, folder: str, batch_size=10000):
    try:
        # Load the CSV file into a DataFrame
        file_path = os.path.join(folder, file_name)
        data = pd.read_csv(file_path)
        data = data.replace({np.nan: None})
        
        for column in data.columns:
            # Check the expected data type from the model
            expected_type = model.__table__.columns[column].type.python_type
            
            if expected_type == datetime.datetime:
                data[column] = pd.to_datetime(data[column], errors='coerce')
            elif expected_type == int:
                data[column] = data[column].fillna(0).astype(int)
            elif expected_type == float:
                data[column] = data[column].apply(lambda x: float(str(x).replace(',', '')) if x is not None else 0.0)
            else:
                data[column] = data[column].astype(expected_type)
        
        total_rows = data.shape[0]
        num_chunks = (total_rows // batch_size) + 1
        
        for batch_number in range(num_chunks):
            start_row = batch_number * batch_size
            end_row = min(start_row + batch_size, total_rows)
            chunk = data.iloc[start_row:end_row]
            
            try:
                # Insert the current batch into the database
                await postgres_db.execute(insert(model).values(chunk.to_dict(orient="records")))
                print(f"Batch {batch_number} loaded for {model.__tablename__}")
            except asyncpg.exceptions.UniqueViolationError:
                continue
        
        print(f"{model.__tablename__} loaded successfully")
    except Exception as e:
        print(e)
        raise e

async def insert_xlsx_into_db(model, file_name, postgres_db: Database, folder: str, batch_size=10000):
    try:
        # Load the CSV file into a DataFrame
        file_path = os.path.join(folder, file_name)
        # for batch_number, chunk in enumerate(pd.read_excel(file_path, engine='openpyxl')):   
            # chunk = chunk.replace({np.nan: None})   
        try:
            data = pd.read_excel(file_path, engine='openpyxl')
            data = data.replace({np.nan: None})
            for column in data.columns:
                # Check the expected data type from the model
                expected_type = model.__table__.columns[column].type.python_type
                
                if expected_type == datetime.datetime:
                    data[column] = pd.to_datetime(data[column])
                else:
                    data[column] = data[column].astype(expected_type)
            total_rows = data.shape[0]
            num_chunks = (total_rows // batch_size) + 1
            
            for batch_number in range(num_chunks):
                start_row = batch_number * batch_size
                end_row = min(start_row + batch_size, total_rows)
                chunk = data.iloc[start_row:end_row]
                
                try:
                    # Insert the current batch into the database
                    await postgres_db.execute(insert(model).values(chunk.to_dict(orient="records")))
                    print(f"Batch {batch_number} loaded for {model.__tablename__}")
                except asyncpg.exceptions.UniqueViolationError:
                    continue
            # print(f"Batch {batch_number} loaded for {model.__tablename__}")
        except asyncpg.exceptions.UniqueViolationError:
            raise Exception(f"Unique constraint violated for {model.__tablename__}")
        print(f"{model.__tablename__} loaded successfully")
    except Exception as e:
        print(e)
        raise e


#loading data to db
async def insert_into_db(model, file_name, postgres_db: Database,  batch_size=1000):
    try:
        truncate_statement = text(f"TRUNCATE TABLE {model.__tablename__}")
        await postgres_db.execute(truncate_statement)
    except Exception as e:
        raise e
    if file_name.endswith('.xlsx'):
        await insert_xlsx_into_db(model, file_name, postgres_db, folder, batch_size)
    elif file_name.endswith('.csv'):
        await insert_csv_into_db(model, file_name, postgres_db, folder, batch_size)


async def load_assortment(postgres_db: Database):
    print("Loading assortment")
    await insert_into_db(Assortment, "assortment.csv", postgres_db)


async def load_inventory(postgres_db: Database):
    print("Loading inventory")
    await insert_into_db(Inventory, "inventory.csv", postgres_db)


async def load_product(postgres_db: Database):
    print("Loading products")
    await insert_into_db(Product,  "product.csv", postgres_db)


async def load_sales(postgres_db: Database):
    print("Loading iqvia sales")
    await insert_into_db(Sales, "sales.csv", postgres_db)  


async def load_store(postgres_db: Database):
    print("Loading store")
    await insert_into_db(Store, "store.csv", postgres_db)


async def load_market_research_analysis(postgres_db: Database):
    print("Loading market research analysis")
    await insert_into_db(MarketResearchAnalysis, "market_research_analysis.xlsx", postgres_db)


async def load_new_store_assortment(postgres_db: Database):
    print("Loading new store assortment")
    await insert_into_db(NewStoresAssortment, "newStoreAssortment.csv", postgres_db)    


async def load_bounce(postgres_db: Database):
    print("Loading bounce")
    await insert_into_db(Bounce, "bounce.csv", postgres_db)