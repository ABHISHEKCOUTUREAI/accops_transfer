
import numpy as np
import pandas as pd

#     assortment_df = pd.read_excel(assortment_file)
#     sales_df = pd.read_excel(sales_file)
    
#     # Select necessary columns
#     assortment_df = assortment_df[['product_id', 'min_qty', 'max_qty']]
#     sales_df = sales_df[['product_id', 'revenue', 'cost', 'quantity_sold']]
    
#     # Merge the data
#     merged_df = assortment_df.merge(sales_df, on=['product_id'], how='inner')

#     # Calculate the margin
#     merged_df['margin'] = merged_df['revenue'] - merged_df['cost']
    

#     # Add random values for the new columns
#     merged_df['qty_bounce_train'] = np.random.randint(1, 101, size=len(merged_df))
#     merged_df['qty_bounce_test'] = np.random.randint(1, 101, size=len(merged_df))
#     merged_df['qty_sold_online'] = np.random.randint(1, 101, size=len(merged_df))
#     merged_df['qty_sold_train'] = np.random.randint(1, 101, size=len(merged_df))
#     merged_df['num_stores_product_part_of_assortment'] = np.random.randint(1, 101, size=len(merged_df))


#     # Add region_type and region_value columns
#     region_types = np.random.choice(['State', 'City'], size=len(merged_df))
#     states = ['Virginia', 'California', 'North Carolina', 'Indiana', 'Wisconsin', 'Florida', 'Nevada']
#     cities = ['Virginia Beach', 'San Bernardino', 'Winston-Salem', 'Indianapolis', 'Milwaukee', 'Tampa', 'North Las Vegas']
    
#     region_values = [np.random.choice(states if rt == 'State' else cities) for rt in region_types]

#     merged_df['region_type'] = region_types
#     merged_df['region_name'] = region_values

#     # Add the store_id column with specified values
#     store_ids = ['NewStore-SmallSized', 'NewStore-LargeSized', 'NewStore-MidSized']
#     merged_df['store_id'] = np.random.choice(store_ids, len(merged_df))

#     # Rename the columns
#     merged_df.rename(columns={'cost': 'total_amount'}, inplace=True)
#     merged_df.rename(columns={'margin': 'total_margin'}, inplace=True)
#     merged_df.rename(columns={'quantity_sold': 'qty_sold'}, inplace=True)
    
#     # drop revenue 
#     merged_df.drop(columns=['revenue'], inplace=True)

#     # Save the merged data to an Excel file
#     merged_df.to_excel(output_file, index=False)
#     # print number of rows 
#     print(len(merged_df))



# # Usage example
# assortment_file = '../../corpus_files/newData/assortment.xlsx'
# sales_file = '../../corpus_files/newData/sales.xlsx'
# output_file = 'new_store_assortment.xlsx'

# new_store_assortment_df = load_new_store_assortment_data(assortment_file, sales_file)




# class MarketResearchAnalysis(Base):            
#     __tablename__ = "market_research_analysis"

#     ranking_level = Column(String, primary_key=True)
    # l0 = Column(String, primary_key=True)
    # l1 = Column(String, primary_key=True)
    # l2 = Column(String, primary_key=True)
    # l3 = Column(String, primary_key=True)
    # product_id = Column(String, primary_key=True)   
    # product_name = Column(String)
    # company = Column(String)
    # brand_name = Column(String)
    # region = Column(String)
    # revenue =  Column(Float)  
    # internal_level_rank = Column(Integer) 

    # aiocd_revenue = Column(Float)
    # aiocd_fraction_revenue= Column(Float)
    # aiocd_level_rank = Column(Integer)

    # iqvia_revenue = Column(Float)
    # fraction_revenue = Column(Float)
    # iqvia_level_rank = Column(Integer)

# create a new table in the product excel fil


def change_product_df(product_file):
    product_df = pd.read_excel(product_file)
    product_df.rename(columns={'L0': 'l0', 'L1': 'l1', 'L2': 'l2', 'L3': 'l3', 'L4': 'l4'}, inplace=True)
    product_df.to_excel('new_product.xlsx', index=False)




def load_new_store_assortment_data(product_file):
    # Load data from the Excel files
    product_df = pd.read_excel(product_file)
   
    # put ranking level a rondom value from  ['l0', 'l1', 'l2', 'l3', 'product_id']

    # Select necessary columns
    product_df = product_df[['L0', 'L1', 'L2', 'L3', 'mfac_name', 'brand_name', 'product_id', 'product_name']]  

    #rename L0 to l0, L1 to l1, L2 to l2, L3 to l3
    product_df.rename(columns={'L0': 'l0', 'L1': 'l1', 'L2': 'l2', 'L3': 'l3'}, inplace=True)  

    product_df['ranking_level'] = np.random.choice(['l0', 'l1', 'l2', 'l3', 'product_id'], size=len(product_df))  


    
    # put ramndom values for the revenue from 1 to 1000
    product_df['revenue'] = np.random.randint(1, 1000, size=len(product_df))

    # put serial number starting from 1 to the length in columnn internal_level_rank
    product_df['internal_level_rank'] = np.arange(1, len(product_df)+1)
    
    # pull null to region column
    product_df['region'] = None


    product_df['aiocd_revenue'] = np.random.randint(1, 1000, size=len(product_df))
    product_df['aiocd_fraction_revenue'] = np.random.randint(0, 1, size=len(product_df))
    product_df['aiocd_level_rank'] = np.random.randint(1, 1000, size=len(product_df))

    product_df['iqvia_revenue'] = np.random.randint(1, 1000, size=len(product_df))
    product_df['fraction_revenue'] = np.random.randint(0, 1, size=len(product_df))
    product_df['iqvia_level_rank'] = np.random.randint(1, 1000, size=len(product_df))
    
    # rename mfac to company
    product_df.rename(columns={'mfac_name': 'company'}, inplace=True)

    # Save the merged data to an Excel file
    product_df.to_excel(output_file, index=False)
    # print number of rows 
    print(len(product_df))



# Usage example
product_file = '../../corpus_files/newData/products.xlsx'
# sales_file = '../../corpus_files/newData/sales.xlsx'
output_file = 'market_research_analysis.xlsx'
# change_product_df(product_file)

new_store_assortment_df = load_new_store_assortment_data(product_file)