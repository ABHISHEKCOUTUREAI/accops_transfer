import json
from decimal import Decimal
from sqlalchemy import or_, ARRAY, String
from db import redis_db
from models import Product, Store

def create_conditions(schema_class, request, column_mappings):
    conditions = []
    for request_field, schema_field in column_mappings:
        request_value = getattr(request, request_field, None)
        if request_value is not None:
            conditions.append(getattr(schema_class, schema_field) == request_value)
    return conditions

def build_condition(
    region_type=None,
    region_name=None,
    L0=None,
    L1=None,
    L2=None,
    L3=None,
    mfac_name=None,
    brand=None,
    molecule=None,
    sap_id=None,
    item_name=None,
    filter=None,
    globalSearch=""
):
    store_condition = []
    product_condition = []

    if region_type == "Zone":
        store_condition.append(Store.zone == region_name)
    elif region_type == "State":
        store_condition.append(Store.state == region_name)
    elif region_type == "City":
        store_condition.append(Store.city == region_name)
    elif region_type == "Branch":
        store_condition.append(Store.store_id == region_name)

    if L0 is not None:
        product_condition.append(Product.l0 == L0)
    if L1 is not None:
        product_condition.append(Product.l1 == L1)
    if L2 is not None:
        product_condition.append(Product.l2 == L2)
    if L3 is not None:
        product_condition.append(Product.l3 == L3)

    if mfac_name is not None:
        product_condition.append(Product.mfac_name == mfac_name)
    if brand is not None:
        product_condition.append(Product.brand_name == brand)

    # globalsearch on prodcut  name, id, description and molecule
    # note that names are asspumed to be always in upper case and description in lower case
    if globalSearch != "":
        product_condition.append(or_(
            Product.product_name.like(f"%{globalSearch.upper()}%"),
            Product.product_id.like(f"%{globalSearch}%"),
            Product.description.like(f"%{globalSearch.lower()}%"),
        ))

    if filter == "all":
        return store_condition + product_condition

    if filter == "store":
        return store_condition

    if filter == "product":
        return product_condition

    return store_condition, product_condition


def decimal_serializer(obj):
    if isinstance(obj, Decimal):
        return str(obj)
    raise TypeError(
        "Object of type {} is not JSON serializable".format(type(obj).__name__)
    )


async def set_redis_cache(cache_key: str, data, default=str):
    serialized_data = json.dumps(data, default=default)
    try:
        await redis_db.set(cache_key, serialized_data)
    except Exception as e:
        print(e)
        pass


async def get_redis_cache(cache_key: str):
    try:
        response = await redis_db.get(cache_key)
        if response:
            result = json.loads(response)
            print("loading from cache: ", cache_key)
            return result
    except Exception as e:
        print(e)
    return None


def form_filter_condition(query, filters):
    """
    forms a filter condition for all the fields of a given query
    """
    condition = []
    for filter in filters:
        if filter.type == "search":
            condition.append(query.c[filter.id].ilike(f"%{filter.query}%"))
        elif filter.type == "range":
            if filter.min:
                condition.append(query.c[filter.id] >= filter.min)
            if filter.max:
                condition.append(query.c[filter.id] <= filter.max)
        elif filter.type == "discrete":
            condition.append(query.c[filter.id].in_(filter.queries))
        elif filter.type == "discrete_contained":
            condition.append(
                query.c[filter.id].cast(ARRAY(String)).contains(filter.queries)
            )
    return condition