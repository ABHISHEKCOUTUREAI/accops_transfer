from datetime import datetime

from configs import config
from models import Assortment, Cart, Inventory, Orders, Product, Sales, Sort
from settings import settings
from sqlalchemy import (
    Numeric,
    and_,
    asc,
    case,
    cast,
    desc,
    func,
    select,
)

from utils import build_condition, form_filter_condition


async def count_elements_query(query, db):
    """
    returns the count of the query for debugging
    """
    query_count = select(func.count()).select_from(query)
    result = await db.fetch_val(query_count)
    print(result, flush=True)
    return result


def form_orders_query(request):
    """
    selects all the orders in a store, retuns the total quantity of each product in the store
    """
    return (
        select(
            Orders.product_id,
            func.sum(Orders.quantity).label("quantity"),
        )
        .where(
            Orders.store_id == request.store_id,
        )
        .group_by(Orders.product_id, Orders.store_id)
        .cte("orders_query")
    )


def form_cart_query(request):
    """
    selects all the cart items in a store, retuns the total quantity of each product in the store
    """
    store_id = request.store_id

    return (
        select(
            Cart.product_id,
            Cart.store_id,
            func.sum(Cart.quantity).label("quantity"),
        )
        .where(
            Cart.store_id == store_id,
        )
        .group_by(Cart.product_id, Cart.store_id)
        .subquery()
    )


def form_product_query(request, product_config):
    """
    Fetches the product details of a store and applies the conditions
    """
    conditions = build_condition(
        L0=request.l0,
        L1=request.l1,
        L2=request.l2,
        L3=request.l3,
        mfac_name=request.mfac_name,
        brand=request.brand_name,
        filter="product",
        globalSearch=request.globalSearch,
    )
    return (
        select(
            *[
                getattr(Product, column_name[0]).label(column_name[1])
                for column_name in product_config["columns"]
            ]
        ).where(and_(*conditions))
    ).cte("products_information")


def create_status_case(query):
    """
    forms the case statement for setting the status of a product
    """
    return case(
        (
            (query.c.current_inventory == 0) & (query.c.min_qty > 0),
            "0_new",
        ),
        (
            (query.c.current_inventory > 0)
            & (query.c.current_inventory < query.c.min_qty),
            "1_replenish",
        ),
        (
            (query.c.current_inventory > 0)
            & (query.c.current_inventory >= query.c.min_qty)
            & (query.c.current_inventory <= query.c.max_qty),
            "2_no_replenishment",
        ),
        (
            (query.c.current_inventory == 0) & (query.c.max_qty == 0),
            "8_dead",
        ),
        (
            (query.c.current_inventory > query.c.max_qty),
            "9_excess",
        ),
        else_="0_new",
    )


def form_inventory_query(request):
    """
    finds the inventory contents of a store given store id witing the inventory date stored in the settings
    """
    return (
        select(
            Inventory.product_id,
            Inventory.store_id,
            func.sum(Inventory.stock_quantity).label("stock_quantity"),
        )
        .where(
            and_(
                Inventory.store_id == request.store_id,
                Inventory.timestamp
                >= datetime.strptime(settings.inventory_start_timestamp, "%Y-%m-%d"),
                Inventory.timestamp
                <= datetime.strptime(settings.inventory_end_timestamp, "%Y-%m-%d"),
            )
        )
        .group_by(Inventory.product_id, Inventory.store_id)
        .subquery()
    )


def form_base_query(request, base_config):
    """
    creates a query with Assortment, products, orders, and cart where it is filtered on product conditions
    and then seelcted by store id.
    """
    product_query = form_product_query(request, product_config=base_config["product"])

    query = (
        select(
            *[
                getattr(Assortment, column_name[0]).label(column_name[1])
                for column_name in base_config["assortment"]["columns"]
            ],
            product_query,
        )
        .where(Assortment.store_id == request.store_id)
        .join(
            product_query,
            and_(
                *[
                    getattr(Assortment, column[0]) == product_query.c[column[1]]
                    for column in base_config["assortment_product_join"]
                ]
            ),
        )
    ).subquery()

    if base_config["order"]:
        order_query = form_orders_query(request)
        query = (
            select(
                query, func.coalesce(order_query.c.quantity, 0).label("order_quantity")
            )
            .join(
                order_query,
                and_(
                    order_query.c.product_id == query.c.product_id,
                ),
                isouter=True,
            )
            .subquery()
        )

    return query


def get_replenishment_case(combined_query):
    """
    creates a replnishment case based on the current orderd quanty and the inventory levels
    compared with the min and max quantity available from assortment
    """
    return case(
        (
            and_(
                combined_query.c.current_inventory + combined_query.c.order_quantity
                >= combined_query.c.min_qty,
                combined_query.c.current_inventory + combined_query.c.order_quantity
                <= combined_query.c.max_qty,
            ),
            0,
        ),
        else_=(
            combined_query.c.max_qty
            - combined_query.c.current_inventory
            - combined_query.c.order_quantity
        ),
    )


def form_combined_query(query, inventory_query):
    """
    combines base query and inventory query.
    """
    return (
        select(
            *[query.c[i.name] for i in query.columns],
            func.coalesce(inventory_query.c.stock_quantity, 0).label(
                "current_inventory"
            ),
        )
        .join(
            inventory_query,
            and_(
                inventory_query.c.product_id == query.c.product_id,
                inventory_query.c.store_id == query.c.store_id,
            ),
            isouter=True,
        )
        .subquery()
    )


def form_assortment_response(results, current_config):
    """
    forms the final response from the results of the queries
    """
    key_mappings = {
        "0_new": "new_count",
        "1_replenish": "replenish_count",
        "2_no_replenishment": "optimal_count",
        "9_excess": "excess_count",
    }
    status_dict = {
        "new_count": 0,
        "replenish_count": 0,
        "optimal_count": 0,
        "excess_count": 0,
    }
    assortment = [dict(row) for row in results[0]]

    assortment_count = 0
    if current_config["overall_count"]:
        status_counts = [dict(row) for row in results[1]]
        for status in status_counts:
            assortment_count += status["count"]
            if status["status_label"] in key_mappings.keys():
                status_dict[key_mappings[status["status_label"]]] = status["count"]
        inhand = [dict(row) for row in results[2]][0]
        recommended = [dict(row) for row in results[3]][0]
        inhand_inventory_cost = inhand["inhand_inventory_cost"]
        inhand_assortment_width = inhand["inhand_assortment_width"]
        recommended_inventory_cost = recommended["recommended_inventory_cost"]
        recommended_assortment_width = recommended["recommended_assortment_width"]
    else:
        assortment_count = results[1]
    response = {
        "assortment_count": assortment_count,
        "assortment": assortment,
        **(status_dict if current_config["overall_count"] else {}),
        **(
            {}
            if not current_config["overall_count"]
            else {
                "inhand_inventory_cost": inhand_inventory_cost,
                "inhand_assortment_width": inhand_assortment_width,
                "recommended_inventory_cost": recommended_inventory_cost,
                "recommended_assortment_width": recommended_assortment_width,
            }
        ),
    }
    return response


def get_inhand_inventory(combined_query):
    """
    finds the inhand inventory cost and assortment width
    """
    return select(
        func.round(
            cast(
                func.coalesce(
                    func.sum(
                        combined_query.c.det_cogs * combined_query.c.current_inventory
                    ),
                    0,
                ),
                Numeric,
            ),
            2,
        ).label("inhand_inventory_cost"),
        func.coalesce(func.count(func.distinct(combined_query.c.product_id)), 0).label(
            "inhand_assortment_width"
        ),
    ).where(
        and_(
            combined_query.c.exist_in_baseline_output == 1,
            combined_query.c.current_inventory.isnot(None),
        )
    )


def get_recomended_inventory(combined_query):
    """
    finds the recommended inventory cost and assortment width
    """
    return select(
        func.round(
            cast(
                func.coalesce(
                    func.sum(combined_query.c.det_cogs * combined_query.c.max_qty),
                    0,
                ),
                Numeric,
            ),
            2,
        ).label("recommended_inventory_cost"),
        func.count(func.distinct(combined_query.c.product_id)).label(
            "recommended_assortment_width"
        ),
    ).where(combined_query.c.exist_in_model_output == 1)


def filter_query(status_query, request, column_names):
    """
    filters the query based on the filters
    """
    filter_condition = form_filter_condition(status_query, request.filters)

    filtered_query = select(
        *[status_query.c[column_name] for column_name in column_names],
    ).where(and_(*filter_condition))

    return filtered_query


def sort_and_paginate(filtered_query, request):
    """
    sorts and paginates the query
    """
    if request.sort is None:
        request.sort = Sort(field="product_id", order="desc")

    offset = (request.page_no - 1) * request.page_count

    ordered_paginated_assortment_query = (
        filtered_query.order_by(
            desc(request.sort.field)
            if request.sort.order == "desc"
            else asc(request.sort.field)
        )
        .offset(offset)
        .limit(request.page_count)
    )

    return ordered_paginated_assortment_query


def get_replenishment_query(combined_query):
    """
    adds the replenishment colums based on the current inventory, order quantity, min and max quantity
    """
    replenishment_case = get_replenishment_case(combined_query)

    return select(
        combined_query,
        replenishment_case.label("minimum_replenishment"),
    ).subquery()


def get_status_query(replenishment_query):
    """
    adds the status label for each product based on the replenishment, and inventory details
    """
    status_case = create_status_case(replenishment_query)
    return select(
        replenishment_query,
        status_case.label("status_label"),
    ).subquery()


def get_status_count_query(status_query):
    """
    finds the count of products with each status label
    """
    return select(
        status_query.c.status_label,
        func.count(status_query.c.product_id).label("count"),
    ).group_by(status_query.c.status_label)


def count_product_id_query(filtered_query):
    """
    counts the product id in the given query
    """
    return select(func.count(filtered_query.c.product_id))


def add_cart_query(query, request):
    """
    Outer joins cart quantity information to the query
    """
    cart_query = form_cart_query(request)
    # query = query.cte("hello")
    return (
        select(
            query,
            func.coalesce(cart_query.c.quantity, 0).label("cart_quantity"),
        )
        .join(
            cart_query,
            and_(
                cart_query.c.product_id == query.c.product_id,
            ),
            isouter=True,
        )
        .subquery()
    )


def form_hit_miss_query(query, request):
    """
    get the correct/wrong predictions by the model
    """
    if request.hit_miss == "hit":
        return (
            select(query)
            .where(and_(query.c.exist_in_model_output == 1, query.c.is_sold == 1))
            .subquery()
        )
    elif request.hit_miss == "miss":
        return (
            select(query)
            .where(and_(query.c.exist_in_model_output == 0, query.c.is_sold == 1))
            .subquery()
        )
    else:
        return select(query).subquery()


def get_sales_info(request):
    return (
        select(
            Sales.product_id,
            Sales.store_id,
            func.coalesce(func.sum(Sales.revenue), 0).label("revenue"),
            func.coalesce(func.sum(Sales.cost), 0).label("cost"),
            func.coalesce(func.sum(Sales.quantity_sold), 0).label("quantity_sold"),
        )
        .where(
            and_(
                Sales.timestamp
                >= datetime.strptime(settings.sales_start_timestamp, "%Y-%m-%d"),
                Sales.timestamp
                <= datetime.strptime(settings.sales_end_timestamp, "%Y-%m-%d"),
            )
        )
        .where(Sales.store_id == request.store_id if request.store_id else True)
        .group_by(Sales.product_id, Sales.store_id)
    )


def get_total_sales(query, request):
    sales_query = get_sales_info(request).subquery()
    query = select(
        query,
        func.coalesce(func.round(cast(sales_query.c.revenue, Numeric), 2), 0).label(
            "total_amount"
        ),
        func.coalesce(
            func.round(
                case(
                    (
                        sales_query.c.revenue > 0,
                        (sales_query.c.revenue - sales_query.c.cost)
                        * 100
                        / sales_query.c.revenue,
                    ),
                    else_=0,
                ).cast(Numeric),
                2,
            ),
            0,
        ).label("total_margin"),
        func.coalesce(sales_query.c.quantity_sold, 0).label("num_qty_sold"),
    ).join(
        sales_query,
        and_(
            query.c.product_id == sales_query.c.product_id,
            sales_query.c.store_id == request.store_id,
        ),
        isouter=True,
    )
    return query.subquery()


def form_hit_miss_response(results):
    """
    forms the final response from the results of the queries
    """
    assortment = [dict(row) for row in results[0]]
    count = results[1]
    response = {
        "count": count,
        "assortment": assortment,
    }
    return response


def get_count_query(query):
    return select(func.count(query.c.product_id))
