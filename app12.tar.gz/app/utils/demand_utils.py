from datetime import datetime, timedelta

from models import Assortment, Inventory, Sales
from settings import settings
from sqlalchemy import and_, case, func, select


async def get_replenishment_query(store_id: str):
    # replenishment case
    replenishment_case = case(
        (
            func.coalesce(Inventory.stock_quantity, 0) <= Assortment.min_qty,
            Assortment.max_qty - func.coalesce(Inventory.stock_quantity, 0),
        ),
        (
            (func.coalesce(Inventory.stock_quantity, 0) < Assortment.max_qty)
            & (func.coalesce(Inventory.stock_quantity, 0) > Assortment.min_qty),
            0,
        ),
        (
            func.coalesce(Inventory.stock_quantity, 0) >= Assortment.max_qty,
            Assortment.max_qty - func.coalesce(Inventory.stock_quantity, 0),
        ),
    )
    # step 2: get the replenishment details
    replenishment_query = (
        select(
            Assortment.product_id,
            replenishment_case.label("replenishment"),
        )
        .where(Assortment.store_id == store_id)
        .outerjoin(
            Inventory,
            and_(
                Inventory.product_id == Assortment.product_id,
                Inventory.store_id == Assortment.store_id,
            ),
        )
    ).cte("replenishment_query")
    return replenishment_query


async def get_weekly_sales(store_id: str):
    # Get the current date and calculate the start of the current week and the past week
    current_date = settings.current_datetime
    current_date = datetime.strptime(current_date, "%Y-%m-%d %H:%M:%S")
    start_of_current_week = current_date - timedelta(days=current_date.weekday())
    start_of_past_week = start_of_current_week - timedelta(days=7)
    end_of_past_week = start_of_current_week - timedelta(seconds=1)

    # Query to get both current week and past week sales in a single query
    query = (
        select(
            Sales.store_id,
            Sales.product_id,
            func.sum(
                case(
                    (Sales.timestamp >= start_of_current_week, Sales.quantity_sold),
                    else_=0,
                )
            ).label("current_week_quantity_sold"),
            func.sum(
                case(
                    (
                        and_(
                            Sales.timestamp <= start_of_past_week,
                            Sales.timestamp <= end_of_past_week,
                        ),
                        Sales.quantity_sold,
                    ),
                    else_=0,
                )
            ).label("past_week_quantity_sold"),
        )
        .where(Sales.store_id == store_id, Sales.timestamp >= start_of_past_week)
        .group_by(Sales.store_id, Sales.product_id)
        .cte("sales_query")
    )

    return query
