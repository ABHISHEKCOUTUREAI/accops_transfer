from fastapi import Form
from sqlalchemy import (
    and_,
    asc,
    case,
    desc,
    distinct,
    func,
    select,
    cast,
    Float,
    Numeric,
)
from models import Product, Assortment, Store


async def get_l2_table_query(
    condition: list,
    page_no_l2: int = Form(1),
    page_count_l2: int = Form(100),
    sort_param_l2: str = Form("count_comp"),
    sort_type_l2: str = Form("desc"),
):
    # sort and limit the query results
    order_by_clause_l2 = (
        desc(f"{sort_param_l2}") if sort_type_l2 == "desc" else asc(f"{sort_param_l2}")
    )
    offset_l2 = (page_no_l2 - 1) * page_count_l2

    l2_query = (
        select(
            Product.l2.label("L2"),
            func.count(
                distinct(
                    case(
                        (
                            and_(*condition, Assortment.exist_in_model_output == 1),
                            Assortment.product_id,
                        )
                    )
                )
            ).label("count_comp"),
            func.count(
                distinct(
                    case(
                        (
                            and_(
                                *condition,
                                Assortment.exist_in_model_output == 0,
                                Assortment.is_sold == 1,
                            ),
                            Assortment.product_id,
                        )
                    )
                )
            ).label("count_miss"),
            case(
                (
                    func.count(
                        distinct(
                            case(
                                (
                                    and_(
                                        *condition,
                                        Assortment.exist_in_model_output == 1,
                                    ),
                                    Assortment.product_id,
                                )
                            )
                        )
                    )
                    != 0,
                    func.round(
                        cast(
                            func.count(
                                distinct(
                                    case(
                                        (
                                            and_(
                                                *condition,
                                                Assortment.exist_in_model_output == 0,
                                                Assortment.is_sold == 1,
                                            ),
                                            Assortment.product_id,
                                        )
                                    )
                                )
                            )
                            / cast(
                                func.count(
                                    distinct(
                                        case(
                                            (
                                                and_(
                                                    *condition,
                                                    Assortment.exist_in_model_output
                                                    == 1,
                                                ),
                                                Assortment.product_id,
                                            )
                                        )
                                    )
                                ),
                                Float,
                            ),
                            Numeric,
                        ),
                        2,
                    ),
                ),
                (
                    func.count(
                        distinct(
                            case(
                                (
                                    and_(
                                        *condition,
                                        Assortment.exist_in_model_output == 1,
                                    ),
                                    Assortment.product_id,
                                )
                            )
                        )
                    )
                    == 0,
                    0,  # or any default value you prefer when the denominator is zero
                ),
            ).label("ratio"),
        )
        .join(Assortment, Product.product_id == Assortment.product_id)
        .join(Store, Store.store_id == Assortment.store_id)
        .group_by(Product.l2)
        .order_by(order_by_clause_l2)
    )

    l2_count_query = select(func.count().label("l2_count")).select_from(l2_query)
    l2_query = l2_query.limit(page_count_l2).offset(offset_l2)

    return l2_query, l2_count_query


async def get_l3_table_query(
    condition: list,
    page_no_l3: int = Form(1),
    page_count_l3: int = Form(100),
    sort_param_l3: str = Form("count_comp"),
    sort_type_l3: str = Form("desc"),
):
    # sort and limit the query results
    order_by_clause_l3 = (
        desc(f"{sort_param_l3}") if sort_type_l3 == "desc" else asc(f"{sort_param_l3}")
    )
    offset_l3 = (page_no_l3 - 1) * page_count_l3

    l3_query = (
        select(
            Product.l3.label("L3"),
            func.count(
                distinct(
                    case(
                        (
                            and_(*condition, Assortment.exist_in_model_output == 1),
                            Assortment.product_id,
                        )
                    )
                )
            ).label("count_comp"),
            func.count(
                distinct(
                    case(
                        (
                            and_(
                                *condition,
                                Assortment.exist_in_model_output == 0,
                                Assortment.is_sold == 1,
                            ),
                            Assortment.product_id,
                        )
                    )
                )
            ).label("count_miss"),
            case(
                (
                    func.count(
                        distinct(
                            case(
                                (
                                    and_(
                                        *condition,
                                        Assortment.exist_in_model_output == 1,
                                    ),
                                    Assortment.product_id,
                                )
                            )
                        )
                    )
                    != 0,
                    func.round(
                        cast(
                            func.count(
                                distinct(
                                    case(
                                        (
                                            and_(
                                                *condition,
                                                Assortment.exist_in_model_output == 0,
                                                Assortment.is_sold == 1,
                                            ),
                                            Assortment.product_id,
                                        )
                                    )
                                )
                            )
                            / cast(
                                func.count(
                                    distinct(
                                        case(
                                            (
                                                and_(
                                                    *condition,
                                                    Assortment.exist_in_model_output
                                                    == 1,
                                                ),
                                                Assortment.product_id,
                                            )
                                        )
                                    )
                                ),
                                Float,
                            ),
                            Numeric,
                        ),
                        2,
                    ),
                ),
                (
                    func.count(
                        distinct(
                            case(
                                (
                                    and_(
                                        *condition,
                                        Assortment.exist_in_model_output == 1,
                                    ),
                                    Assortment.product_id,
                                )
                            )
                        )
                    )
                    == 0,
                    0,  # or any default value you prefer when the denominator is zero
                ),
            ).label("ratio"),
        )
        .join(Assortment, Product.product_id == Assortment.product_id)
        .join(Store, Store.store_id == Assortment.store_id)
        .group_by(Product.l3)
        .order_by(order_by_clause_l3)
    )

    l3_count_query = select(func.count().label("l3_count")).select_from(l3_query)
    l3_query = l3_query.limit(page_count_l3).offset(offset_l3)

    return l3_query, l3_count_query


async def get_l2l3_query(condition: list):
    l2_assort_comp_query = (
        select(
            Product.l2.label("L2"),
            func.count(distinct(Assortment.product_id)).label("COUNT_DISTINCT(sap_id)"),
        )
        .join(Assortment, Assortment.product_id == Product.product_id)
        .join(Store, Store.store_id == Assortment.store_id)
        .where(and_(*condition, Assortment.exist_in_model_output == 1))
        .group_by(Product.l2)
        .order_by(func.count(distinct(Assortment.product_id)).desc())
        .limit(10)
    )

    l2_assort_dist_miss_query = (
        select(
            Product.l2.label("L2"),
            func.count(distinct(Assortment.product_id)).label("COUNT_DISTINCT(sap_id)"),
        )
        .join(Assortment, Assortment.product_id == Product.product_id)
        .join(Store, Store.store_id == Assortment.store_id)
        .where(
            and_(
                *condition,
                Assortment.exist_in_model_output == 0,
                Assortment.is_sold == 1,
            )
        )
        .group_by(Product.l2)
        .order_by(func.count(distinct(Assortment.product_id)).desc())
        .limit(10)
    )

    l3_assort_comp_query = (
        select(
            Product.l3.label("L3"),
            func.count(distinct(Assortment.product_id)).label("COUNT_DISTINCT(sap_id)"),
        )
        .join(Assortment, Assortment.product_id == Product.product_id)
        .join(Store, Store.store_id == Assortment.store_id)
        .where(and_(*condition, Assortment.exist_in_model_output == 1))
        .group_by(Product.l3)
        .order_by(func.count(distinct(Assortment.product_id)).desc())
        .limit(10)
    )

    l3_assort_dist_miss_query = (
        select(
            Product.l3.label("L3"),
            func.count(distinct(Assortment.product_id)).label("COUNT_DISTINCT(sap_id)"),
        )
        .join(Assortment, Assortment.product_id == Product.product_id)
        .join(Store, Store.store_id == Assortment.store_id)
        .where(
            and_(
                *condition,
                Assortment.exist_in_model_output == 0,
                Assortment.is_sold == 1,
            )
        )
        .group_by(Product.l3)
        .order_by(func.count(distinct(Assortment.product_id)).desc())
        .limit(10)
    )

    return (
        l2_assort_comp_query,
        l2_assort_dist_miss_query,
        l3_assort_comp_query,
        l3_assort_dist_miss_query,
    )
