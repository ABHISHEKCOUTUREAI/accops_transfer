import uvicorn
from routes import (
    prediction,
    sales,
    manufacture,
    newproduct,
    L2L3,
    map,
    crud,
    store_assortment,
    category_router,
    cart_router,
    demand_router,
    notification_router,
    assortment_router
)  # , custom_assortment
from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from fastapi.openapi.utils import get_openapi
from contextlib import asynccontextmanager
from db import PostgresDatabase
from utils import (
    load_assortment,
    load_inventory,
    load_product,
    load_store,
    load_sales,
    load_new_store_assortment,
    load_market_research_analysis,
    load_bounce,
)
from settings import settings


@asynccontextmanager
async def lifespan(app: FastAPI):
    print(
        "================================ Starting up ================================================="
    )
    app.state.db = PostgresDatabase(settings)
    app.state.db.create_tables()
    await app.state.db.connect()
    # await load_aiocd_analysis(postgres_db=app.state.db.database)
    # await load_assortment(postgres_db=app.state.db.database)
    # await load_product(postgres_db=app.state.db.database)
    # await load_store(postgres_db=app.state.db.database)
    # await load_bounce(postgres_db=app.state.db.database)
    # await load_orders(postgres_db=app.state.db.database)
    # await load_inventory(postgres_db=app.state.db.database)
    # await load_sales(postgres_db=app.state.db.database)
    # await load_probability(postgres_db=app.state.db.database)
    # await load_aiocd_sales(postgres_db=app.state.db.database)
    # await load_iqvia_sales(postgres_db=app.state.db.database)
    # await load_msa_all_cats(postgres_db=app.state.db.database)
    # await load_new_store_assortment(postgres_db=app.state.db.database)
    # await load_market_research_analysis(postgres_db=app.state.db.database)

    # Add other startup items here
    print("Loading Completed !")
    yield

    print(
        "================================ Shutting down ================================================="
    )


app = FastAPI(
    title="assortment-api",
    docs_url="/docs",
    redoc_url=None,
    lifespan=lifespan,
    root_path="/assortment-backend",
)


def custom_openapi():
    if app.openapi_schema:
        return app.openapi_schema
    openapi_schema = get_openapi(
        title=app.title, version=app.version, routes=app.routes
    )
    app.openapi_schema = openapi_schema
    return app.openapi_schema


app.openapi = custom_openapi


# app.add_middleware(RedisMiddleware, redis_db=redis_db)
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)


@app.get("/")
async def home():
    return {"Welcome": "To Assortment Planning"}


app.include_router(prediction)
app.include_router(sales)
app.include_router(manufacture)
app.include_router(newproduct)
app.include_router(L2L3)
app.include_router(map)
app.include_router(crud)
app.include_router(store_assortment)
app.include_router(category_router)
app.include_router(cart_router)
app.include_router(demand_router)
app.include_router(notification_router)
app.include_router(assortment_router)
# app.include_router(custom_assortment)


if __name__ == "__main__":
    uvicorn.run(app, host="0.0.0.0", port=8000)
