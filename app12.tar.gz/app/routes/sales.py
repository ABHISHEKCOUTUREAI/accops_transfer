import calendar
import datetime
import json
from fastapi import APIRouter, Form, Depends, HTTPException
from models import (
    Sales,
    Product,
    Store,
    MarketResearchAnalysis,
    MarketResearchRequest,
)  # ,  MSAAllCats , MarketResearchAnalysis, IQVIASales
from sqlalchemy import func, select, and_, asc, desc, cast, Numeric
from .common import get_postgres_db
from utils import decimal_serializer, set_redis_cache, get_redis_cache
from collections import defaultdict
from asyncio import gather
from decimal import Decimal
from configs import config

sales = APIRouter(prefix="/couture/assortment", tags=["sales"])


def create_market_research_query(request):
    market_research_config = config['market_research'][request.ranking_type]
    main_table = market_research_config['select']['table']

    # Start building the main query
    main_query = select()

    # Add columns from the main table
    for col in market_research_config['select']['columns']:
        main_query = main_query.add_columns(getattr(main_table, col[0]).label(col[1]))

    # Add filters to the main query
    for filter_col in market_research_config['select']['filter']:
        filter_value = getattr(request, filter_col[1])
        if filter_value is not None:
            main_query = main_query.where(getattr(main_table, filter_col[0]) == filter_value)

    # Process joins
    for join_config in market_research_config['join']:
        join_table = join_config['table']

        # Add filters for the join table
        for filter_col in join_config['filter']:
            filter_value = getattr(request, filter_col[1])
            if filter_value is not None:
                join_table = join_table.where(getattr(join_table, filter_col[0]) == filter_value)
        
        # Create join conditions
        join_conditions = [getattr(main_table, condition[1]) == getattr(join_table, condition[2])
                           for condition in join_config['join_condition']]
        
        # Add columns from the join table
        for col in join_config['columns']:
            main_query = main_query.add_columns(getattr(join_table, col[0]).label(col[1]))

        # Add join to the main query
        main_query = main_query.join(join_table, and_(*join_conditions), isouter=join_config['outer'])
        

    # Create a CTE (Common Table Expression) from the main query
    cte = main_query.cte("final")

    # Select only the required columns from the CTE
    return_columns = market_research_config['return_columns']
    final_query = select(*[cte.c[col] for col in return_columns])

    # Apply rounding to Numeric and Decimal columns
    for col in final_query.columns:
        if isinstance(col.type, (Numeric, Decimal)) and col.name not in market_research_config['skip_rounding']:
            final_query = final_query.column(func.round(col, 2))

    # Create count query
    count_column = market_research_config['count_on']
    count_query = select(func.count(final_query.c[count_column]).label('count'))

    print("====================================================================")
    print(final_query.compile(compile_kwargs={"literal_binds": True}))
    print("====================================================================")
    offset = (request.page_no-1) * request.page_size
    final_query = final_query.offset(offset).limit(request.page_size)
    return final_query, count_query



def decimal_to_float(obj):
    if isinstance(obj, Decimal):
        return float(obj)
    raise TypeError

@sales.post("/past-sales", operation_id="fetch-past-sales")
async def fetch_past_salse(
    region_type: str = Form(None),
    region_name: str = Form(None),
    L0: str = Form(None),
    L1: str = Form(None),
    L2: str = Form(None),
    L3: str = Form(None),
    timedelta: str = Form("month"),
    timeframe: int = Form(100),
    postgres_db=Depends(get_postgres_db),
):
    cache_key = (
        f"past-sales:{region_type}:{region_name}:{L0}:{L1}:{L2}:{L3}:{timeframe}"
    )
    response = await get_redis_cache(cache_key)
    if response:
        return response

    # Check if region_type and region_name are provided
    if region_type is None and region_name is None:
        # Fetch all br_codes without any conditions
        store_query = select(Store.store_id)
    else:
        # Query the Store table to retrieve br_code based on region_type and region_name
        store_query = select(Store.store_id).where(
            (Store.zone == region_name)
            if region_type == "Zone"
            else (Store.state == region_name)
            if region_type == "State"
            else (Store.city == region_name)
            if region_type == "City"
            else (Store.store_id == region_name)
        )

    response = await postgres_db.fetch_all(store_query)
    br_codes = [row[0] for row in response]
    # br_codes = ["TNJ3"]

    # Build the filter
    filter = []
    if L0 is not None:
        filter.append(Product.l0 == L0)
    if L1 is not None:
        filter.append(Product.l1 == L1)
    if L2 is not None:
        filter.append(Product.l2 == L2)
    if L3 is not None:
        filter.append(Product.l3 == L3)

    sales_query = (
        select(
            Sales.timestamp,
            Product.l0.label("L0"),
            func.sum(Sales.revenue).label("total_revenue"),
            func.sum(Sales.quantity_sold).label("units_sold"),
            func.sum(Sales.cost).label("total_cost"),
        )
        .join(Product, Sales.product_id == Product.product_id)
        .where(and_(Sales.store_id.in_(br_codes), *filter))
        .group_by(Sales.timestamp, Product.l0)
    )

    sales = await postgres_db.fetch_all(sales_query)

    # Process the results
    sales_result = {}
    for record in sales:
        date = record["timestamp"].date()
        day = date.day
        month_number = date.month
        month = calendar.month_name[month_number]
        year = date.year

        L0 = record["L0"]
        total_revenue = record["total_revenue"]
        units_sold = record["units_sold"]
        total_cost = record["total_cost"]

        if timedelta == "day":
            index = str(day) + " " + month + " " + str(year)
        elif timedelta == "month":
            index = month + " " + str(year)

        if index not in sales_result:
            sales_result[index] = []
        # Check if the L0 exists in the current month_year data
        l0_found = False
        for item in sales_result[index]:
            if item["L0"] == L0:
                # Add the revenue to the existing L0
                item["total_revenue"] += round(total_revenue, 2)
                item["units_sold"] += round(units_sold, 2)
                item["total_margin"] += round((total_revenue - total_cost), 2)
                l0_found = True
                break

        # If the L0 doesn't exist in the current month_year data, add it
        if not l0_found:
            sales_result[index].append(
                {
                    "L0": L0,
                    "total_revenue": round(total_revenue, 2),
                    "units_sold": round(units_sold, 2),
                    "total_margin": round(total_cost, 2),
                }
            )

    # # Sort the results chronologically by month and year
    if timedelta == "day":
        sorted_sales_result = dict(
            sorted(
                sales_result.items(),
                key=lambda x: datetime.datetime.strptime(x[0], "%d %B %Y"),
            )
        )
    elif timedelta == "month":
        sorted_sales_result = dict(
            sorted(
                sales_result.items(),
                key=lambda x: datetime.datetime.strptime(x[0], "%B %Y"),
            )
        )

    sorted_sales_result = dict(list(sorted_sales_result.items())[-timeframe:])

    await set_redis_cache(cache_key, sorted_sales_result)

    return sorted_sales_result


@sales.post("/aiocd-sales", operation_id="fetch-aiocd-sales")
async def fetch_aiocd_sales(
    ranking_level: str = Form(None),
    L0: str = Form(None),
    L1: str = Form(None),
    L2: str = Form(None),
    L3: str = Form(None),
    sap_id: str = Form(None),
    page_no: int = Form(1),
    page_size: int = Form(100),
    sort_param: str = Form("revenue"),
    sort_type: str = Form("desc"),
    flag: bool = Form(True),
    postgres_db=Depends(get_postgres_db),
):
    cache_key = f"aiocd-sales:{ranking_level}:{L0}:{L1}:{L2}:{L3}:{page_no}:{sort_param}:{sort_type}:{flag}"
    response = await get_redis_cache(cache_key)
    if response:
        return response

    condition = []
    if L0 is not None:
        condition.append(MarketResearchAnalysis.l0 == L0)
    if L1 is not None:
        condition.append(MarketResearchAnalysis.l1 == L1)
    if L2 is not None:
        condition.append(MarketResearchAnalysis.l2 == L2)
    if L3 is not None:
        condition.append(MarketResearchAnalysis.l3 == L3)
    if ranking_level is not None:
        condition.append(MarketResearchAnalysis.ranking_level == ranking_level)
    if sap_id is not None:
        condition.append(MarketResearchAnalysis.product_id == sap_id)

    # Dynamically adjust the order_by clause based on sort_param and sort_type
    sort_column = getattr(
        MarketResearchAnalysis, sort_param, MarketResearchAnalysis.revenue
    )
    order_by_clause = desc(sort_column) if sort_type == "desc" else asc(sort_column)

    aiocd_sales_query = (
        select(
            MarketResearchAnalysis.l0.label("L0"),
            MarketResearchAnalysis.l1.label("L1"),
            MarketResearchAnalysis.l2.label("L2"),
            MarketResearchAnalysis.l3.label("L3"),
            MarketResearchAnalysis.product_id.label("sap_id"),
            MarketResearchAnalysis.product_name.label("item_name"),
            func.round(cast(MarketResearchAnalysis.aiocd_revenue, Numeric), 2).label(
                "aiocd_revenue"
            ),
            func.round(cast(MarketResearchAnalysis.revenue, Numeric), 2).label(
                "revenue"
            ),
            func.round(cast(MarketResearchAnalysis.fraction_revenue, Numeric), 4).label(
                "fraction_revenue"
            ),
            MarketResearchAnalysis.internal_level_rank,
            MarketResearchAnalysis.aiocd_level_rank,
        )
        .where(and_(*condition))
        .order_by(order_by_clause)
    )

    if flag:
        offset = (page_no - 1) * page_size
        aiocd_sales_query = aiocd_sales_query.limit(page_size).offset(offset)

    aiocd_sales_rows = await postgres_db.fetch_all(aiocd_sales_query)
    aiocd_sales_result = [dict(rows) for rows in aiocd_sales_rows]

    aiocd_sales_query = (
        select(func.count()).select_from(MarketResearchAnalysis).where(and_(*condition))
    )
    aiocd_sales_count = await postgres_db.fetch_val(aiocd_sales_query)

    response = {
        "aiocd_sales_result": aiocd_sales_result,
        "aiocd_sales_count": aiocd_sales_count,
    }

    await set_redis_cache(cache_key, response, default=decimal_serializer)
    return response


@sales.post("/iqvia-sales", operation_id="fetch-iqvia-sales")
async def fetch_iqvia_sales(
    ranking_level: str = Form(None),
    L0: str = Form(None),
    L1: str = Form(None),
    L2: str = Form(None),
    L3: str = Form(None),
    sap_id: str = Form(None),
    page_no: int = Form(1),
    page_size: int = Form(100),
    sort_param: str = Form("revenue"),
    sort_type: str = Form("desc"),
    flag: bool = Form(True),
    postgres_db=Depends(get_postgres_db),
):
    cache_key = f"iqvia-sales:{ranking_level}:{L0}:{L1}:{L2}:{L3}:{page_no}:{sort_param}:{sort_type}:{flag}"
    response = await get_redis_cache(cache_key)
    if response:
        return response

    condition = []
    if L0 is not None:
        condition.append(MarketResearchAnalysis.l0 == L0)
    if L1 is not None:
        condition.append(MarketResearchAnalysis.l1 == L1)
    if L2 is not None:
        condition.append(MarketResearchAnalysis.l2 == L2)
    if L3 is not None:
        condition.append(MarketResearchAnalysis.l3 == L3)
    if ranking_level is not None:
        condition.append(MarketResearchAnalysis.ranking_level == ranking_level)
    if sap_id is not None:
        condition.append(MarketResearchAnalysis.product_id == sap_id)

    # Dynamically adjust the order_by clause based on sort_param and sort_type
    sort_column = getattr(
        MarketResearchAnalysis, sort_param, MarketResearchAnalysis.revenue
    )
    order_by_clause = desc(sort_column) if sort_type == "desc" else asc(sort_column)

    iqvia_sales_query = (
        select(
            MarketResearchAnalysis.l0.label("L0"),
            MarketResearchAnalysis.l1.label("L1"),
            MarketResearchAnalysis.l2.label("L2"),
            MarketResearchAnalysis.l3.label("L3"),
            MarketResearchAnalysis.product_id.label("sap_id"),
            MarketResearchAnalysis.product_name.label("item_name"),
            func.round(cast(MarketResearchAnalysis.iqvia_revenue, Numeric), 2).label(
                "iqvia_revenue"
            ),
            func.round(cast(MarketResearchAnalysis.revenue, Numeric), 2).label(
                "revenue"
            ),
            func.round(cast(MarketResearchAnalysis.fraction_revenue, Numeric), 4).label(
                "fraction_revenue"
            ),
            MarketResearchAnalysis.internal_level_rank,
            MarketResearchAnalysis.iqvia_level_rank,
        )
        .where(and_(*condition))
        .order_by(order_by_clause)
    )

    if flag:
        offset = (page_no - 1) * page_size
        iqvia_sales_query = iqvia_sales_query.limit(page_size).offset(offset)

    iqvia_sales_rows = await postgres_db.fetch_all(iqvia_sales_query)
    iqvia_sales_results = [dict(rows) for rows in iqvia_sales_rows]

    iqvia_sales_query = (
        select(func.count()).select_from(MarketResearchAnalysis).where(and_(*condition))
    )
    iqvia_sales_count = await postgres_db.fetch_val(iqvia_sales_query)

    response = {
        "iqvia_sales_results": iqvia_sales_results,
        "iqvia_sales_count": iqvia_sales_count,
    }

    await set_redis_cache(cache_key, response, default=decimal_serializer)
    return response


@sales.post("/test/market-sales", tags=["test"])
async def fetch_market_sales(
    request: MarketResearchRequest,
    postgres_db=Depends(get_postgres_db),
):
    try:
        if request.ranking_type not in config['market_research'].keys():
            return HTTPException(status_code=400, detail="Invalid ranking type")
        cache_key = "market-sales" + json.dumps(request.model_dump(), default=str)
        response = await get_redis_cache(cache_key)
        query, count = create_market_research_query(request)
        result, result_count  = await gather(postgres_db.fetch_all(query), postgres_db.fetch_val(count))
        response = {
            "sales_results": [dict(i) for i in result],
            "sales_count": result_count
        }
        await set_redis_cache(cache_key, response, default=decimal_serializer)
        return response
    except Exception as e:
        return HTTPException(status_code=400, detail=str(e))


@sales.get("/market-trends-l2l3", operation_id="fetch-market-trends-l2l3")
async def fetch_market_trends_l2l3(postgres_db=Depends(get_postgres_db)):
    cache_key = "market-trends-l2l3"
    response = await get_redis_cache(cache_key)
    if response:
        return response

    aiocd_query_l0 = (
        select(
            MarketResearchAnalysis.l0.label("L0"),
            cast(func.sum(MarketResearchAnalysis.revenue), Numeric).label("revenue"),
        )
        .where(MarketResearchAnalysis.l0 != "")
        .group_by(MarketResearchAnalysis.l0)
        .order_by(func.sum(MarketResearchAnalysis.revenue).desc())
        .limit(10)
    )

    aiocd_query_l1 = (
        select(
            MarketResearchAnalysis.l1.label("L1"),
            cast(func.sum(MarketResearchAnalysis.revenue), Numeric).label("revenue"),
        )
        .where(and_(MarketResearchAnalysis.l1 != "", MarketResearchAnalysis.l0 != ""))
        .group_by(MarketResearchAnalysis.l1)
        .order_by(func.sum(MarketResearchAnalysis.revenue).desc())
        .limit(10)
    )

    aiocd_query_l2 = (
        select(
            MarketResearchAnalysis.l2.label("L2"),
            cast(func.sum(MarketResearchAnalysis.revenue), Numeric).label("revenue"),
        )
        .where(
            and_(
                MarketResearchAnalysis.l2 != "",
                MarketResearchAnalysis.l1 != "",
                MarketResearchAnalysis.l0 != "",
            )
        )
        .group_by(MarketResearchAnalysis.l2)
        .order_by(func.sum(MarketResearchAnalysis.revenue).desc())
        .limit(10)
    )

    aiocd_query_l3 = (
        select(
            MarketResearchAnalysis.l3.label("L3"),
            cast(func.sum(MarketResearchAnalysis.revenue), Numeric).label("revenue"),
        )
        .where(
            and_(
                MarketResearchAnalysis.l3 != "",
                MarketResearchAnalysis.l2 != "",
                MarketResearchAnalysis.l1 != "",
                MarketResearchAnalysis.l0 != "",
            )
        )
        .group_by(MarketResearchAnalysis.l3)
        .order_by(func.sum(MarketResearchAnalysis.revenue).desc())
        .limit(10)
    )

    iqvia_query_l0 = (
        select(
            MarketResearchAnalysis.l0.label("L0"),
            cast(func.sum(MarketResearchAnalysis.revenue), Numeric).label("revenue"),
        )
        .where(MarketResearchAnalysis.l0 != "")
        .group_by(MarketResearchAnalysis.l0)
        .order_by(func.sum(MarketResearchAnalysis.revenue).desc())
        .limit(10)
    )

    iqvia_query_l1 = (
        select(
            MarketResearchAnalysis.l1.label("L1"),
            cast(func.sum(MarketResearchAnalysis.revenue), Numeric).label("revenue"),
        )
        .where(and_(MarketResearchAnalysis.l1 != "", MarketResearchAnalysis.l0 != ""))
        .group_by(MarketResearchAnalysis.l1)
        .order_by(func.sum(MarketResearchAnalysis.revenue).desc())
        .limit(10)
    )

    iqvia_query_l2 = (
        select(
            MarketResearchAnalysis.l2.label("L2"),
            cast(func.sum(MarketResearchAnalysis.revenue), Numeric).label("revenue"),
        )
        .where(
            and_(
                MarketResearchAnalysis.l2 != "",
                MarketResearchAnalysis.l1 != "",
                MarketResearchAnalysis.l0 != "",
            )
        )
        .group_by(MarketResearchAnalysis.l2)
        .order_by(func.sum(MarketResearchAnalysis.revenue).desc())
        .limit(10)
    )

    iqvia_query_l3 = (
        select(
            MarketResearchAnalysis.l3.label("L3"),
            cast(func.sum(MarketResearchAnalysis.revenue), Numeric).label("revenue"),
        )
        .where(
            and_(
                MarketResearchAnalysis.l3 != "",
                MarketResearchAnalysis.l2 != "",
                MarketResearchAnalysis.l1 != "",
                MarketResearchAnalysis.l0 != "",
            )
        )
        .group_by(MarketResearchAnalysis.l3)
        .order_by(func.sum(MarketResearchAnalysis.revenue).desc())
        .limit(10)
    )

    queries = [
        postgres_db.fetch_all(query)
        for query in [
            aiocd_query_l0,
            aiocd_query_l1,
            aiocd_query_l2,
            aiocd_query_l3,
            iqvia_query_l0,
            iqvia_query_l1,
            iqvia_query_l2,
            iqvia_query_l3,
        ]
    ]
    result = await gather(*queries)
    (
        aiocd_result_l0,
        aiocd_result_l1,
        aiocd_result_l2,
        aiocd_result_l3,
        iqvia_result_l0,
        iqvia_result_l1,
        iqvia_result_l2,
        iqvia_result_l3,
    ) = result

    aiocd_result_l0 = [dict(row) for row in aiocd_result_l0]
    aiocd_result_l1 = [dict(row) for row in aiocd_result_l1]
    aiocd_result_l2 = [dict(row) for row in aiocd_result_l2]
    aiocd_result_l3 = [dict(row) for row in aiocd_result_l3]
    iqvia_result_l0 = [dict(row) for row in iqvia_result_l0]
    iqvia_result_l1 = [dict(row) for row in iqvia_result_l1]
    iqvia_result_l2 = [dict(row) for row in iqvia_result_l2]
    iqvia_result_l3 = [dict(row) for row in iqvia_result_l3]

    for row in aiocd_result_l0:
        row['revenue'] = float(round(row['revenue'], 0))
    for row in aiocd_result_l1:
        row['revenue'] = float(round(row['revenue'], 0))
    for row in aiocd_result_l2:
        row['revenue'] = float(round(row['revenue'], 0))
    for row in aiocd_result_l3:
        row['revenue'] = float(round(row['revenue'], 0))
    for row in iqvia_result_l0:
        row['revenue'] = float(round(row['revenue'], 0))
    for row in iqvia_result_l1:
        row['revenue'] = float(round(row['revenue'], 0))
    for row in iqvia_result_l2:
        row['revenue'] = float(round(row['revenue'], 0))
    for row in iqvia_result_l3:
        row['revenue'] = float(round(row['revenue'], 0))

    response = {
        "aiocd_result_l0": aiocd_result_l0,
        "aiocd_result_l1": aiocd_result_l1,
        "aiocd_result_l2": aiocd_result_l2,
        "aiocd_result_l3": aiocd_result_l3,
        "iqvia_result_l0": iqvia_result_l0,
        "iqvia_result_l1": iqvia_result_l1,
        "iqvia_result_l2": iqvia_result_l2,
        "iqvia_result_l3": iqvia_result_l3,
    }

    await set_redis_cache(cache_key, response, default=decimal_serializer)

    return response


@sales.get("/sales-filters", operation_id="fetch-filters-sales")
async def fetch_filters_sales(postgres_db=Depends(get_postgres_db)):
    cache_key = "fetch-filters-sales"
    response = await get_redis_cache(cache_key)
    if response:
        return response

    query = select(
        MarketResearchAnalysis.ranking_level,
        MarketResearchAnalysis.l0.label("L0"),
        MarketResearchAnalysis.l1.label("L1"),
        MarketResearchAnalysis.l2.label("L2"),
        MarketResearchAnalysis.l3.label("L3"),
        MarketResearchAnalysis.product_id.label("sap_id"),
    ).order_by(MarketResearchAnalysis.ranking_level)
    rows = await postgres_db.fetch_all(query)

    # Organize data into a nested dictionary
    filters_data = defaultdict(
        lambda: defaultdict(
            lambda: defaultdict(lambda: defaultdict(lambda: defaultdict(dict)))
        )
    )

    for row in rows:
        ranking_level = row[0]
        L0 = row[1]
        L1 = row[2]
        L2 = row[3]
        L3 = row[4]
        sap_id = row[5]

        # Check if all L0, L1, L2, L3 are not empty or "nan" before adding the entry
        if all(
            value and (value.lower() == "" or value.lower()) == "nan"
            for value in [L0, L1, L2, L3]
        ):
            continue
        filters_data[ranking_level][L0][L1][L2][L3][sap_id] = {}

    response = {"filters": filters_data}
    await set_redis_cache(cache_key, response)
    return response
