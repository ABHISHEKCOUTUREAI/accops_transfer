import csv
from datetime import datetime
from io import StringIO

from fastapi import APIRouter, Depends, Form
from fastapi.responses import StreamingResponse
from models import Assortment, Bounce, Product, Sales, Store
from routes.common import get_postgres_db
from settings import settings
from sqlalchemy import (
    Numeric,
    String,
    and_,
    asc,
    case,
    cast,
    desc,
    distinct,
    func,
    nullslast,
    or_,
    select,
)
from utils import build_condition, decimal_serializer, get_redis_cache, set_redis_cache

newproduct = APIRouter(prefix="/couture/assortment", tags=["new-products"])


def form_base_query(store_condition=[], product_condition=[]):
    product_query = select(Product).where(and_(*product_condition)).subquery()
    store_query = (
        select(Store.zone, Store.state, Store.city, Store.store_id)
        .where(and_(*store_condition))
        .subquery()
    )
    bounce_query = (
        select(
            Bounce.product_id,
            Bounce.store_id,
            Bounce.number_of_bounce,
        )
        .where(
            and_(
                Bounce.timestamp
                >= datetime.strptime(settings.bounce_data_start_timestamp, "%Y-%m-%d"),
                Bounce.timestamp
                <= datetime.strptime(settings.bounce_data_end_timestamp, "%Y-%m-%d"),
            )
        )
        .subquery()
    )
    query = (
        select(
            Assortment,
            product_query,
            store_query.c.zone,
            store_query.c.state,
            store_query.c.city,
            bounce_query.c.number_of_bounce,
        )
        .join(product_query, product_query.c.product_id == Assortment.product_id)
        .join(store_query, store_query.c.store_id == Assortment.store_id)
        .join(
            bounce_query,
            and_(
                cast(bounce_query.c.product_id, String) == Assortment.product_id,
                cast(bounce_query.c.store_id, String) == Assortment.store_id,
            ),
            isouter=True,
        )
    )

    return query


@newproduct.post("/new-products", operation_id="fetch-new-products-info")
async def fetch_new_products(
    region_type: str = Form(None),
    region_name: str = Form(None),
    L0: str = Form(None),
    L1: str = Form(None),
    L2: str = Form(None),
    L3: str = Form(None),
    flag: bool = Form(True),
    page_no: int = Form(1),
    page_size: int = Form(100),
    sort_param: str = Form("num_qty_sold"),
    bounce_sort_param: str = Form("item_name"),
    sort_type: str = Form("desc"),
    bounce_sort_type: str = Form("desc"),
    postgres_db=Depends(get_postgres_db),
):
    cache_key = f"new-products:{region_type}:{region_name}:{L0}:{L1}:{L2}:{L3}:{flag}:{page_no}:{sort_param}:{sort_type}:{bounce_sort_param}:{bounce_sort_type}"
    response = await get_redis_cache(cache_key)
    if response:
        return response

    # Build the filter
    store_condition, product_condition = build_condition(
        region_type, region_name, L0, L1, L2, L3
    )

    product_query = form_base_query(store_condition, product_condition).subquery()

    # 1. new_product
    new_product_condition = and_(
        product_query.c.is_new_product == 1, product_query.c.exist_in_model_output == 1
    )

    sales_query = (
        select(
            Sales.product_id,
            Sales.store_id,
            func.sum(Sales.revenue).label("revenue"),
            func.sum(Sales.cost).label("cost"),
            func.sum(Sales.quantity_sold).label("quantity_sold"),
        )
        .where(
            and_(
                Sales.timestamp
                >= func.to_timestamp(settings.sales_start_timestamp, "YYYY-MM-DD"),
                Sales.timestamp
                <= func.to_timestamp(settings.sales_end_timestamp, "YYYY-MM-DD"),
            )
        )
        .group_by(Sales.product_id, Sales.store_id)
        .subquery()
    )

    product_query = (
        select(
            product_query.c.product_id,
            product_query.c.product_name,
            product_query.c.price.label("mrp"),
            func.round(func.sum(cast(sales_query.c.revenue, Numeric)), 2).label(
                "total_amount"
            ),
            func.round(
                func.sum(
                    cast(
                        (sales_query.c.revenue - sales_query.c.cost)
                        / sales_query.c.revenue,
                        Numeric,
                    )
                )
                * 100,
                2,
            ).label("total_margin"),
            func.round(func.sum(cast(sales_query.c.quantity_sold, Numeric)), 2).label(
                "num_qty_sold"
            ),
        )
        .join(
            sales_query,
            and_(
                product_query.c.product_id == sales_query.c.product_id,
                product_query.c.store_id == sales_query.c.store_id,
            ),
            # isouter=True,
        )
        .where(new_product_condition)
        .group_by(
            product_query.c.product_id,
            product_query.c.product_name,
            product_query.c.price,
        )  # Add more columns if needed
    ).subquery()

    # Dynamically adjust the order_by clause based on sorting_parameter and sorting_type
    if sort_param == "num_qty_sold":
        order_by_clause = (
            desc("num_qty_sold") if sort_type == "desc" else asc("num_qty_sold")
        )
    elif sort_param == "total_amount":
        order_by_clause = (
            desc("total_amount") if sort_type == "desc" else asc("total_amount")
        )
    elif sort_param == "total_margin":
        order_by_clause = (
            desc("total_margin") if sort_type == "desc" else asc("total_margin")
        )
    elif sort_param == "sap_id":
        order_by_clause = desc("sap_id") if sort_type == "desc" else asc("product_id")
    elif sort_param == "item_name":
        order_by_clause = (
            desc("item_name") if sort_type == "desc" else asc("product_name")
        )
    elif sort_param == "mrp":
        order_by_clause = nullslast(desc("mrp")) if sort_type == "desc" else asc("mrp")
    else:
        order_by_clause = desc("num_qty_sold")

    product_query = select(product_query).order_by(order_by_clause)

    product_count_query = select(func.count(product_query.c.product_id)).select_from(
        product_query
    )
    product_count = await postgres_db.fetch_val(product_count_query)

    if flag:
        offset = (page_no - 1) * page_size
        product_query = product_query.limit(page_size).offset(offset)

    product_rows = await postgres_db.fetch_all(product_query)
    product_result = [dict(rows) for rows in product_rows]

    bounce_query = form_base_query(store_condition, product_condition).subquery()
    # 2.new_product_bounce
    new_product_bounce_condition = and_(
        bounce_query.c.is_new_product == 1,
        bounce_query.c.number_of_bounce > 0,
        bounce_query.c.is_sold != 1,
    )

    bounce_query = (
        select(
            bounce_query.c.product_id,
            bounce_query.c.product_name.label("item_name"),
            bounce_query.c.l3.label("L3"),
        ).where(new_product_bounce_condition)
    ).subquery()

    # Dynamically adjust the order_by clause based on sorting_parameter and sorting_type
    if bounce_sort_param == "L3":
        order_by_clause = desc("L3") if bounce_sort_type == "desc" else asc("L3")
    elif bounce_sort_param == "sap_id":
        order_by_clause = (
            desc("product_id") if bounce_sort_type == "desc" else asc("product_id")
        )
    elif bounce_sort_param == "item_name":
        order_by_clause = (
            desc("item_name") if bounce_sort_type == "desc" else asc("item_name")
        )
    elif bounce_sort_param == "mrp":
        order_by_clause = desc("price") if bounce_sort_type == "desc" else asc("price")
    else:
        order_by_clause = desc("product_name")

    bounce_query = select(bounce_query).order_by(order_by_clause)

    bounce_count_query = select(func.count(bounce_query.c.product_id)).select_from(
        bounce_query
    )
    bounce_count = await postgres_db.fetch_val(bounce_count_query)

    if flag:
        offset = (page_no - 1) * 100
        bounce_query = bounce_query.limit(100).offset(offset)

    bounce_rows = await postgres_db.fetch_all(bounce_query)
    bounce_result = [dict(rows) for rows in bounce_rows]

    # Process the data and add it to the result dictionary
    response = {
        "product_result": [],
        "product_count": 0,
        "bounce_result": [],
        "bounce_count": 0,
    }
    response["product_result"] = product_result
    response["product_count"] = product_count
    response["bounce_result"] = bounce_result
    response["bounce_count"] = bounce_count

    # Serialize the data using the custom serializer
    if flag:
        await set_redis_cache(cache_key, response, default=decimal_serializer)
    return response


@newproduct.post("/new-product-stats", operation_id="fetch-new-product-stats")
async def fetch_new_products_stats(
    region_type: str = Form(None),
    region_name: str = Form(None),
    L0: str = Form(None),
    L1: str = Form(None),
    L2: str = Form(None),
    L3: str = Form(None),
    postgres_db=Depends(get_postgres_db),
):
    cache_key = f"new-product-stats:{region_type}:{region_name}:{L0}:{L1}:{L2}:{L3}"
    response = await get_redis_cache(cache_key)
    if response:
        return response

    # Build the filter
    store_condition, product_condition = build_condition(
        region_type, region_name, L0, L1, L2, L3
    )

    query = form_base_query(store_condition, product_condition).subquery()

    # total products recommended
    total_products_query = select(func.count(distinct(query.c.product_id))).where(
        and_(query.c.exist_in_model_output == 1)
    )
    total_products_recommended = await postgres_db.fetch_val(total_products_query)

    # New Product recomendation
    new_product_recommendation_query = select(
        func.count(distinct(query.c.product_id))
    ).where(and_(query.c.is_new_product == 1, query.c.exist_in_model_output == 1))
    new_product_recommendation = await postgres_db.fetch_val(
        new_product_recommendation_query
    )

    # New product hit-rate
    new_product_hit_rate_query = (
        select(func.count(distinct(query.c.product_id)))
        .select_from(query)
        .where(
            and_(
                query.c.is_new_product == 1,
                query.c.exist_in_model_output == 1,
                or_(query.c.is_sold == 1, query.c.number_of_bounce > 0),
            )
        )
    )
    new_product_hit_rate = await postgres_db.fetch_val(new_product_hit_rate_query)

    # Total demand
    total_demand_query = (
        select(func.count(distinct(query.c.product_id)))
        .select_from(query)
        .where(and_(or_(query.c.is_sold == 1, query.c.number_of_bounce > 0)))
    )
    total_demand = await postgres_db.fetch_val(total_demand_query)

    # currently explained demand
    curr_explained_demand_query = (
        select(func.count(distinct(query.c.product_id)))
        .select_from(query)
        .where(query.c.is_sold == 1)
    )
    curr_explained_demand = await postgres_db.fetch_val(curr_explained_demand_query)

    # Demand explained by recomandation
    demand_explained_by_recommandation_query = (
        select(func.count(distinct(query.c.product_id)))
        .select_from(query)
        .where(
            and_(
                query.c.exist_in_model_output == 1,
                or_(query.c.is_sold == 1, query.c.number_of_bounce > 0),
            )
        )
    )
    demand_explained_by_recommandation = await postgres_db.fetch_val(
        demand_explained_by_recommandation_query
    )

    results = {}

    results["fraction_new_products"] = (
        round((new_product_recommendation / total_products_recommended) * 100, 2)
        if total_products_recommended != 0
        else 0
    )

    results["new_product_hit_rate"] = (
        round((new_product_hit_rate / new_product_recommendation) * 100, 2)
        if new_product_recommendation != 0
        else 0
    )

    results["total_demand"] = round(total_demand, 2)

    results["current_explained_demand"] = round(curr_explained_demand, 2)

    results["demand_explained_by_reccomendation"] = round(
        demand_explained_by_recommandation, 2
    )

    results["demand_currently_explained_percent"] = (
        round((curr_explained_demand / total_demand) * 100, 2)
        if total_demand != 0
        else 0
    )

    results["demand_explained_reccomendation_percent"] = (
        round((demand_explained_by_recommandation / total_demand) * 100, 2)
        if total_demand != 0
        else 0
    )

    results["improvement_factor"] = (
        round(demand_explained_by_recommandation / curr_explained_demand, 2)
        if curr_explained_demand != 0
        else 0
    )

    await set_redis_cache(cache_key, results)
    return results


@newproduct.post("/new-products-csv", operation_id="fetch-products-csv")
async def fetch_new_products_csv(
    region_type: str = Form(None),
    region_name: str = Form(None),
    L0: str = Form(None),
    L1: str = Form(None),
    L2: str = Form(None),
    L3: str = Form(None),
    sort_param: str = Form("num_qty_sold"),
    sort_type: str = Form("desc"),
    postgres_db=Depends(get_postgres_db),
):
    # Build the filter
    store_condition, product_condition = build_condition(
        region_type, region_name, L0, L1, L2, L3
    )

    query = form_base_query(store_condition, product_condition).subquery()

    # 1. new_product
    new_product_condition = and_(query.c.is_new_product == 1)

    sales_query = (
        select(
            Sales.product_id,
            Sales.store_id,
            func.sum(Sales.revenue).label("revenue"),
            func.sum(Sales.cost).label("cost"),
            func.sum(Sales.quantity_sold).label("quantity_sold"),
        )
        .where(
            and_(
                Sales.timestamp
                >= datetime.strptime(settings.sales_start_timestamp, "%Y-%m-%d"),
                Sales.timestamp
                <= datetime.strptime(settings.sales_end_timestamp, "%Y-%m-%d"),
            )
        )
        .group_by(Sales.product_id, Sales.store_id)
        .subquery()
    )

    product_query = (
        select(
            query.c.product_id,
            query.c.store_id,
            query.c.product_name.label("item_name"),
            func.round(cast(sales_query.c.revenue, Numeric), 2).label("total_amount"),
            func.round(
                cast(
                    (sales_query.c.revenue - sales_query.c.cost)
                    / sales_query.c.revenue,
                    Numeric,
                ) * 100,
                2,
            ).label("total_margin"),
            func.round(cast(sales_query.c.quantity_sold, Numeric), 2).label(
                "num_qty_sold"
            ),
        )
        .join(
            sales_query,
            and_(
                query.c.product_id == sales_query.c.product_id,
                query.c.store_id == sales_query.c.store_id,
            ),
        )
        .where(new_product_condition)
        .subquery()
    )

    # Dynamically adjust the order_by clause based on sorting_parameter and sorting_type
    if sort_param == "num_qty_sold":
        order_by_clause = (
            desc("num_qty_sold") if sort_type == "desc" else asc("num_qty_sold")
        )
    elif sort_param == "total_amount":
        order_by_clause = (
            desc("total_amount") if sort_type == "desc" else asc("total_amount")
        )
    elif sort_param == "total_margin":
        order_by_clause = (
            desc("total_margin") if sort_type == "desc" else asc("total_margin")
        )
    elif sort_param == "sap_id":
        order_by_clause = (
            desc("product_id") if sort_type == "desc" else asc("product_id")
        )
    elif sort_param == "item_name":
        order_by_clause = (
            desc("product_name") if sort_type == "desc" else asc("product_name")
        )
    else:
        order_by_clause = desc("quantity_sold")

    product_query = select(product_query).order_by(order_by_clause)

    product_rows = await postgres_db.fetch_all(product_query)
    product_result = [dict(rows) for rows in product_rows]

    if product_result:
        # Create a CSV string
        csv_content = StringIO()
        csv_writer = csv.DictWriter(csv_content, fieldnames=product_result[0].keys())
        csv_writer.writeheader()
        csv_writer.writerows(product_result)

        # Convert the CSV string to bytes
        csv_bytes = csv_content.getvalue().encode("utf-8")

        # Return the response as a streaming response with content type "text/csv"
        return StreamingResponse(
            iter([csv_bytes]),
            media_type="text/csv",
            headers={"Content-Disposition": "attachment;filename=products.csv"},
        )
    else:
        # If there are no rows, return an empty response
        return StreamingResponse(
            iter([]),
            media_type="text/csv",
            headers={"Content-Disposition": "attachment;filename=products.csv"},
        )


@newproduct.post("/new-products-bounce-csv", operation_id="fetch-bounce-csv")
async def fetch_new_products_bounce_csv(
    region_type: str = Form(None),
    region_name: str = Form(None),
    L0: str = Form(None),
    L1: str = Form(None),
    L2: str = Form(None),
    L3: str = Form(None),
    bounce_sort_param: str = Form("item_name"),
    bounce_sort_type: str = Form("desc"),
    postgres_db=Depends(get_postgres_db),
):
    # Build the filter
    store_condition, product_condition = build_condition(
        region_type, region_name, L0, L1, L2, L3
    )

    query = form_base_query(store_condition, product_condition).subquery()
    # 2.new_product_bounce
    new_product_bounce_condition = and_(
        query.c.is_new_product == 1, query.c.number_of_bounce > 0, query.c.is_sold != 1
    )

    bounce_query = (
        select(
            query.c.product_id.label("sap_id"),
            query.c.product_name.label("item_name"),
            query.c.l3.label("L3"),
        )
        .group_by(
            query.c.product_id,
            query.c.product_name,
            query.c.l3,
        )
        .where(new_product_bounce_condition)
    ).subquery()

    # Dynamically adjust the order_by clause based on sorting_parameter and sorting_type
    if bounce_sort_param == "L3":
        order_by_clause = desc("L3") if bounce_sort_type == "desc" else asc("L3")
    elif bounce_sort_param == "sap_id":
        order_by_clause = (
            desc("sap_id") if bounce_sort_type == "desc" else asc("sap_id")
        )
    elif bounce_sort_param == "item_name":
        order_by_clause = (
            desc("item_name") if bounce_sort_type == "desc" else asc("item_name")
        )
    else:
        order_by_clause = desc("item_name")

    bounce_query = select(bounce_query).order_by(order_by_clause)

    bounce_rows = await postgres_db.fetch_all(bounce_query)
    bounce_result = [dict(rows) for rows in bounce_rows]

    if bounce_result:
        # Create a CSV string
        csv_content = StringIO()
        csv_writer = csv.DictWriter(csv_content, fieldnames=bounce_result[0].keys())
        csv_writer.writeheader()
        csv_writer.writerows(bounce_result)

        # Convert the CSV string to bytes
        csv_bytes = csv_content.getvalue().encode("utf-8")

        # Return the response as a streaming response with content type "text/csv"
        return StreamingResponse(
            iter([csv_bytes]),
            media_type="text/csv",
            headers={"Content-Disposition": "attachment;filename=products.csv"},
        )
    else:
        # If there are no rows, return an empty response
        return StreamingResponse(
            iter([]),
            media_type="text/csv",
            headers={"Content-Disposition": "attachment;filename=products.csv"},
        )


@newproduct.post(
    "/new-products-stats-table", operation_id="fetch-new-product-stats-table"
)
async def fetch_new_products_stats_table(
    region_type: str = Form(None),
    region_name: str = Form(None),
    L0: str = Form(None),
    L1: str = Form(None),
    L2: str = Form(None),
    L3: str = Form(None),
    page_no: int = Form(1),
    page_count: int = Form(100),
    sort_param: str = Form("demand_currently_explained"),
    sort_type: str = Form("asc"),
    postgres_db=Depends(get_postgres_db),
):
    cache_key = f"new-product-stats-table:{region_type}:{region_name}:{L0}:{L1}:{L2}:{L3}:{page_no}:{sort_param}:{sort_type}"
    response = await get_redis_cache(cache_key)
    if response:
        return response

    # Build the filter
    store_condition, product_condition = build_condition(
        region_type, region_name, L0, L1, L2, L3
    )

    query = form_base_query(store_condition, product_condition).subquery()

    new_product_stats_query = (
        select(
            query.c.city,
            query.c.state,
            query.c.zone,
            query.c.store_id.label("br_code"),
            query.c.is_new_product,
            query.c.exist_in_model_output,
            func.count(distinct(query.c.product_id))
            .filter(or_(query.c.is_sold == 1, query.c.number_of_bounce > 0))
            .label("total_demand"),
            case(
                (
                    func.count(distinct(query.c.product_id))
                    .filter(or_(query.c.is_sold == 1, query.c.number_of_bounce > 0))
                    .label("total_demand")
                    != 0,
                    func.round(
                        cast(
                            func.count(distinct(query.c.product_id))
                            .filter(query.c.is_sold == 1)
                            .label("curr_explained_demand")
                            / func.count(distinct(query.c.product_id))
                            .filter(
                                or_(query.c.is_sold == 1, query.c.number_of_bounce > 0)
                            )
                            .label("total_demand"),
                            Numeric,
                        ),
                        2,
                    ),
                ),
                (
                    func.count(distinct(query.c.product_id))
                    .filter(or_(query.c.is_sold == 1, query.c.number_of_bounce > 0))
                    .label("total_demand")
                    == 0,
                    0,
                ),
                else_=(
                    func.count(distinct(query.c.product_id))
                    / func.count(distinct(query.c.product_id))
                ).label("default_case"),
            ).label("demand_currently_explained"),
            case(
                (
                    func.count(distinct(query.c.product_id))
                    .filter(or_(query.c.is_sold == 1, query.c.number_of_bounce > 0))
                    .label("total_demand")
                    != 0,
                    func.round(
                        cast(
                            func.count(distinct(query.c.product_id))
                            .filter(
                                query.c.exist_in_model_output == 1,
                                or_(query.c.is_sold == 1, query.c.number_of_bounce > 0),
                            )
                            .label("demand_explained_by_reccomendation")
                            / func.count(distinct(query.c.product_id))
                            .filter(
                                or_(query.c.is_sold == 1, query.c.number_of_bounce > 0)
                            )
                            .label("total_demand"),
                            Numeric,
                        ),
                        2,
                    ),
                ),
                else_=0,
            ).label("demand_explained_reccomendation"),
            case(
                (
                    func.count(distinct(query.c.product_id))
                    .filter(query.c.is_sold == 1)
                    .label("curr_explained_demand")
                    != 0,
                    func.round(
                        cast(
                            func.count(distinct(query.c.product_id))
                            .filter(
                                query.c.exist_in_model_output == 1,
                                or_(query.c.is_sold == 1, query.c.number_of_bounce > 0),
                            )
                            .label("demand_explained_by_reccomendation")
                            / func.count(distinct(query.c.product_id))
                            .filter(query.c.is_sold == 1)
                            .label("curr_explained_demand"),
                            Numeric,
                        ),
                        2,
                    ),
                ),
                else_=0,
            ).label("improvement_factor"),
        )
        .where(and_(query.c.is_new_product == 1, query.c.exist_in_model_output == 1))
        .group_by(
            query.c.store_id,
            query.c.city,
            query.c.state,
            query.c.zone,
            query.c.is_new_product,
            query.c.exist_in_model_output,
        )
    )
    # sort and limit the query results
    order_by_clause = (
        desc(f"{sort_param}") if sort_type == "desc" else asc(f"{sort_param}")
    )
    offset = (page_no - 1) * page_count

    new_product_stats_query = (
        new_product_stats_query.order_by(order_by_clause)
        .limit(page_count)
        .offset(offset)
    )
    new_product_stats = await postgres_db.fetch_all(new_product_stats_query)

    # Convert Record objects to dictionaries
    new_product_stats = [dict(stat) for stat in new_product_stats]

    # Group new_product_stats by br_code
    grouped_stats = {}
    for stat in new_product_stats:
        br_code = stat["br_code"]
        if br_code not in grouped_stats:
            grouped_stats[br_code] = []
        grouped_stats[br_code].append(stat)

    await set_redis_cache(cache_key, grouped_stats)

    return grouped_stats
    return grouped_stats
