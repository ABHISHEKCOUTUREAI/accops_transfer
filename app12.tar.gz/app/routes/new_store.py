import csv
from asyncio import gather
from collections import defaultdict
from io import StringIO

from fastapi import APIRouter, Depends, Form
from fastapi.responses import StreamingResponse
from models import NewStoresAssortment, Product
from sqlalchemy import Numeric, String, and_, asc, cast, desc, func, select
from utils import decimal_serializer, get_redis_cache, set_redis_cache

from routes import get_postgres_db

store_assortment = APIRouter(prefix="/couture/assortment", tags=["store_assortment"])


@store_assortment.post(
    "/new-store-assortment", operation_id="fetch-new-store-assortment"
)
async def fetch_store_assortment(
    region_type: str = Form(None),
    region_name: str = Form(None),
    L0: str = Form(None),
    L1: str = Form(None),
    L2: str = Form(None),
    L3: str = Form(None),
    mfac_name: str = Form(None),
    brand_name: str = Form(None),
    page_no: int = Form(1),
    page_count: int = Form(100),
    sort_param: str = Form("qty_sold"),
    sort_type: str = Form("asc"),
    postgres_db=Depends(get_postgres_db),
):
    cache_key = f"new-store-assortment:{region_type}:{region_name}:{L0}:{L1}:{L2}:{L3}:{mfac_name}:{brand_name}:{sort_param}:{sort_type}:{sort_param}:{sort_type}:{page_no}:{page_count}"
    response = await get_redis_cache(cache_key)
    if response:
        return response

    query = (
        select(
            Product.l0.label("L0"),
            Product.l1.label("L1"),
            Product.l2.label("L2"),
            Product.l3.label("L3"),
            Product.description,
            Product.mfac_name,
            Product.brand_name,
            Product.product_name,
            NewStoresAssortment.product_id,
            NewStoresAssortment.store_id,
            NewStoresAssortment.region_type,
            NewStoresAssortment.region_name,
            NewStoresAssortment.num_stores_product_part_of_assortment,
            func.round(cast(Product.price, Numeric), 2).label("mrp"),
            func.round(cast(NewStoresAssortment.min_qty, Numeric), 2).label("min_qty"),
            func.round(cast(NewStoresAssortment.max_qty, Numeric), 2).label("max_qty"),
            func.round(cast(NewStoresAssortment.qty_sold, Numeric), 2).label(
                "qty_sold"
            ),
            func.round(cast(NewStoresAssortment.total_amount, Numeric), 2).label(
                "total_amount"
            ),
            func.round(cast(NewStoresAssortment.total_margin, Numeric), 2).label(
                "total_margin"
            ),
        ).join(
            Product, and_(cast(NewStoresAssortment.product_id, String) == Product.product_id, NewStoresAssortment.total_amount > 0)
        )
    ).subquery()

    condition = []
    if region_type == "State":
        condition.append(query.c.region_type == "State")
        condition.append(query.c.region_name == region_name)
    elif region_type == "City":
        condition.append(query.c.region_type == "City")
        condition.append(query.c.region_name == region_name)

    if L0 is not None:
        condition.append(query.c.L0 == L0)
    if L1 is not None:
        condition.append(query.c.L1 == L1)
    if L2 is not None:
        condition.append(query.c.L2 == L2)
    if L3 is not None:
        condition.append(query.c.L3 == L3)
    if mfac_name is not None:
        condition.append(query.c.mfac_name == mfac_name)
    if brand_name is not None:
        condition.append(query.c.brand_name == brand_name)

    # Append the new condition
    additional_condition = and_(
        0.7 * query.c.mrp * query.c.qty_sold <= query.c.total_amount,
        query.c.mrp * query.c.qty_sold >= query.c.total_amount,
    )
    condition.append(additional_condition)

    # sort and limit the query results
    order_by_clause = (
        desc(f"{sort_param}") if sort_type == "desc" else asc(f"{sort_param}")
    )
    offset = (page_no - 1) * page_count

    large_size_query = (
        select(query)
        .where(and_(*condition, query.c.store_id == "NewStore-LargeSized"))
        .order_by(order_by_clause)
        .limit(page_count)
        .offset(offset)
    )
    large_count_query = select(func.count().label("large_count")).where(
        and_(*condition, query.c.store_id == "NewStore-LargeSized")
    )
    mid_size_query = (
        select(query)
        .where(and_(*condition, query.c.store_id == "NewStore-MidSized"))
        .order_by(order_by_clause)
        .limit(page_count)
        .offset(offset)
    )
    mid_count_query = select(func.count().label("mid_count")).where(
        and_(*condition, query.c.store_id == "NewStore-MidSized")
    )
    small_size_query = (
        select(query)
        .where(and_(*condition, query.c.store_id == "NewStore-SmallSized"))
        .order_by(order_by_clause)
        .limit(page_count)
        .offset(offset)
    )
    small_count_query = select(func.count().label("small_count")).where(
        and_(*condition, query.c.store_id == "NewStore-SmallSized")
    )

    query_list = [
        large_size_query,
        large_count_query,
        mid_size_query,
        mid_count_query,
        small_size_query,
        small_count_query,
    ]
    result = await gather(*[postgres_db.fetch_all(query) for query in query_list])
    (
        large_size_rows,
        large_count,
        mid_size_rows,
        mid_count,
        small_size_rows,
        small_count,
    ) = result

    # Dictionary to store results grouped by 'br_code'
    result_dict = {}
    result_dict["LargeSized"] = [dict(row) for row in large_size_rows]
    result_dict["LargeSized_count"] = large_count[0]["large_count"]
    result_dict["MidSized"] = [dict(row) for row in mid_size_rows]
    result_dict["MidSized_count"] = mid_count[0]["mid_count"]
    result_dict["SmallSized"] = [dict(row) for row in small_size_rows]
    result_dict["SmallSized_count"] = small_count[0]["small_count"]

    await set_redis_cache(cache_key, result_dict, default=decimal_serializer)

    return result_dict


@store_assortment.post(
    "/new-store-assortment-csv", operation_id="fetch-new-store-assortment-csv"
)
async def fetch_store_assortment_csv(
    region_type: str = Form(None),
    region_name: str = Form(None),
    L0: str = Form(None),
    L1: str = Form(None),
    L2: str = Form(None),
    L3: str = Form(None),
    mfac_name: str = Form(None),
    brand_name: str = Form(None),
    sort_param: str = Form("qty_sold"),
    sort_type: str = Form("asc"),
    postgres_db=Depends(get_postgres_db),
    store_size: str = Form(None),
):
    query = (
        select(
            Product.l0.label("L0"),
            Product.l1.label("L1"),
            Product.l2.label("L2"),
            Product.l3.label("L3"),
            Product.description,
            Product.mfac_name,
            Product.brand_name,
            Product.product_name,
            NewStoresAssortment.product_id,
            NewStoresAssortment.store_id,
            NewStoresAssortment.region_type,
            NewStoresAssortment.region_name,
            NewStoresAssortment.num_stores_product_part_of_assortment,
            func.round(cast(Product.price, Numeric), 2).label("mrp"),
            func.round(cast(NewStoresAssortment.min_qty, Numeric), 2).label("min_qty"),
            func.round(cast(NewStoresAssortment.max_qty, Numeric), 2).label("max_qty"),
            func.round(cast(NewStoresAssortment.qty_sold, Numeric), 2).label(
                "qty_sold"
            ),
            func.round(cast(NewStoresAssortment.total_amount, Numeric), 2).label(
                "total_amount"
            ),
            func.round(cast(NewStoresAssortment.total_margin, Numeric), 2).label(
                "total_margin"
            ),
        ).join(
            Product, cast(NewStoresAssortment.product_id, String) == Product.product_id
        )
    ).subquery()

    condition = []
    if region_type == "State":
        condition.append(query.c.region_type == "State")
        condition.append(query.c.region_name == region_name)
    elif region_type == "City":
        condition.append(query.c.region_type == "City")
        condition.append(query.c.region_name == region_name)

    if L0 is not None:
        condition.append(query.c.l0 == L0)
    if L1 is not None:
        condition.append(query.c.l1 == L1)
    if L2 is not None:
        condition.append(query.c.l2 == L2)
    if L3 is not None:
        condition.append(query.c.l3 == L3)
    if mfac_name is not None:
        condition.append(query.c.mfac_name == mfac_name)
    if brand_name is not None:
        condition.append(query.c.brand_name == brand_name)

    # sort and limit the query results
    order_by_clause = (
        desc(f"{sort_param}") if sort_type == "desc" else asc(f"{sort_param}")
    )

    if store_size == "large":
        query = (
            select(query)
            .where(and_(*condition, query.c.br_code == "NewStore-LargeSized"))
            .order_by(order_by_clause)
        )
    elif store_size == "medium":
        query = (
            select(query)
            .where(and_(*condition, query.c.br_code == "NewStore-MidSized"))
            .order_by(order_by_clause)
        )
    elif store_size == "small":
        query = (
            select(query)
            .where(and_(*condition, query.c.br_code == "NewStore-SmallSized"))
            .order_by(order_by_clause)
        )
    else:
        query = select(query).where(and_(*condition)).order_by(order_by_clause)

    rows = await postgres_db.fetch_all(query)
    result = [dict(row) for row in rows]
    if result:
        # Create a CSV string
        csv_content = StringIO()
        csv_writer = csv.DictWriter(csv_content, fieldnames=result[0].keys())
        csv_writer.writeheader()
        csv_writer.writerows(result)

        # Convert the CSV string to bytes
        csv_bytes = csv_content.getvalue().encode("utf-8")

        # Return the response as a streaming response with content type "text/csv"
        return StreamingResponse(
            iter([csv_bytes]),
            media_type="text/csv",
            headers={"Content-Disposition": "attachment;filename=response.csv"},
        )
    else:
        # If there are no rows, return an empty response
        return StreamingResponse(
            iter([]),
            media_type="text/csv",
            headers={"Content-Disposition": "attachment;filename=products.csv"},
        )


@store_assortment.post("/new-store-filters", operation_id="fetch-new-store-filters")
async def fetch_store_filters(
    region_type: str = Form(None),
    region_name: str = Form(None),
    L0: str = Form(None),
    L1: str = Form(None),
    L2: str = Form(None),
    L3: str = Form(None),
    mfac_name: str = Form(None),
    brand_name: str = Form(None),
    store_size: str = Form(None),
    postgres_db=Depends(get_postgres_db),
):
    cache_key = f"new-store-filters:{region_type}:{region_name}:{L0}:{L1}:{L2}:{L3}:{mfac_name}:{brand_name}:{store_size}"
    response = await get_redis_cache(cache_key)
    if response:
        return response

    query = (
        select(
            Product.l0.label("L0"),
            Product.l1.label("L1"),
            Product.l2.label("L2"),
            Product.l3.label("L3"),
            Product.mfac_name,
            Product.brand_name,
            NewStoresAssortment.region_type,
            NewStoresAssortment.region_name,
            NewStoresAssortment.store_id.label("store_size"),
            NewStoresAssortment.product_id.label("sap_id"),
            func.round(cast(Product.price, Numeric), 2).label("mrp"),
            func.round(cast(NewStoresAssortment.qty_sold, Numeric), 2).label(
                "qty_sold"
            ),
            func.round(cast(NewStoresAssortment.total_amount, Numeric), 2).label(
                "total_amount"
            ),
        ).join(
            Product, cast(NewStoresAssortment.product_id, String) == Product.product_id
        )
    ).subquery()

    condition = []
    if region_type == "State":
        condition.append(query.c.region_type == "State")
        condition.append(query.c.region_name == region_name)
    elif region_type == "City":
        condition.append(query.c.region_type == "City")
        condition.append(query.c.region_name == region_name)

    if L0 is not None:
        condition.append(query.c.L0 == L0)
    if L1 is not None:
        condition.append(query.c.L1 == L1)
    if L2 is not None:
        condition.append(query.c.L2 == L2)
    if L3 is not None:
        condition.append(query.c.L3 == L3)
    if mfac_name is not None:
        condition.append(query.c.mfac_name == mfac_name)
    if brand_name is not None:
        condition.append(query.c.brand_name == brand_name)

    # Append the new condition
    additional_condition = and_(
        0.7 * query.c.mrp * query.c.qty_sold <= query.c.total_amount,
        query.c.mrp * query.c.qty_sold >= query.c.total_amount,
    )
    condition.append(additional_condition)

    query = select(query).where(and_(*condition)).subquery()

    if store_size is not None:
        query = select(query).where(query.c.store_size == store_size)
    else:
        # Apply the filters and get the br_code with the maximum rows
        max_store_size_query = (
            select(query.c.store_size, func.count().label("row_count"))
            .group_by(query.c.store_size)
            .order_by(func.count().desc())
            .limit(1)
        )
        max_store_size_result = await postgres_db.fetch_all(max_store_size_query)
        if max_store_size_result:
            max_store_size = max_store_size_result[0]["store_size"]
            query = select(query).where(query.c.store_size == max_store_size)

    L0_query = select(query.c.L0, func.count(query.c.sap_id)).group_by(query.c.L0)
    L1_query = select(query.c.L1, func.count(query.c.sap_id)).group_by(query.c.L1)
    L2_query = select(query.c.L2, func.count(query.c.sap_id)).group_by(query.c.L2)
    L3_query = select(query.c.L3, func.count(query.c.sap_id)).group_by(query.c.L3)

    queries = [
        postgres_db.fetch_all(query)
        for query in [L0_query, L1_query, L2_query, L3_query, query]
    ]
    result = await gather(*queries)

    L0_rows, L1_rows, L2_rows, L3_rows, rows = result

    filters_count = {
        "L0": {row[0]: row[1] for row in L0_rows},
        "L1": {row[0]: row[1] for row in L1_rows},
        "L2": {row[0]: row[1] for row in L2_rows},
        "L3": {row[0]: row[1] for row in L3_rows},
    }

    # Organize data into a nested dictionary
    filters_data = defaultdict(
        lambda: defaultdict(lambda: defaultdict(lambda: defaultdict(dict)))
    )
    for row in rows:
        local_L0 = row[0]
        local_L1 = row[1]
        local_L2 = row[2]
        local_L3 = row[3]
        mfac = row[4]
        brand = row[5]
        filters_data["category"][local_L0][local_L1][local_L2][local_L3] = {}
        filters_data["mfac"][mfac][brand] = {}

    filters_data["filters_count"] = filters_count

    # send a list of unique city and state names in NewStoresAssortment table

    city_query = (
        select(query.c.region_name).where(query.c.region_type == "City").distinct()
    )
    city_rows = await postgres_db.fetch_all(city_query)
    city_names = [row["region_name"] for row in city_rows]
    filters_data["city"] = city_names

    state_query = (
        select(query.c.region_name).where(query.c.region_type == "State").distinct()
    )
    state_rows = await postgres_db.fetch_all(state_query)
    state_names = [row["region_name"] for row in state_rows]
    filters_data["state"] = state_names

    await set_redis_cache(cache_key, filters_data)

    return filters_data
