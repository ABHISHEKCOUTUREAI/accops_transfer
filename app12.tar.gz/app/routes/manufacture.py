from fastapi import APIRouter, Form, Depends, UploadFile, File
from models import Product, Sales, Store
from sqlalchemy import func, select, and_
from utils import build_condition, set_redis_cache, get_redis_cache
import json
from typing import Optional
import pandas as pd
from fastapi.responses import JSONResponse
from routes.common import get_postgres_db

manufacture = APIRouter(prefix="/couture/assortment", tags=["manufacture"])


@manufacture.post("/mfac-revenue", operation_id="fetch-brand-revenue")  # done
async def fetch_brand_revenue(
    region_type: str = Form(None),
    region_name: str = Form(None),
    L0: str = Form(None),
    L1: str = Form(None),
    L2: str = Form(None),
    L3: str = Form(None),
    mfac_name: str = Form(None),
    brand_name: str = Form(None),
    postgres_db=Depends(get_postgres_db),
):
    cache_key = f"mfac-revenue:{region_type}:{region_name}:{L0}:{L1}:{L2}:{L3}:{mfac_name}:{brand_name}"
    response = await get_redis_cache(cache_key)
    if response:
        return response

    # Build the filter
    condition = build_condition(
        region_type, region_name, L0, L1, L2, L3, mfac_name, brand_name, filter="all"
    )

    last_year_dates_query = (
        select(Sales.timestamp)
        .distinct()
        .order_by(Sales.timestamp.desc())
        .limit(365)
        .subquery()
    )

    # Query the Orders table to calculate total revenue, total cost, and num orders
    orders_query = (
        select(
            func.sum(Sales.revenue).label("total_revenue"),
            func.sum(Sales.cost).label("total_cost"),
            func.sum(Sales.number_of_orders).label("num_orders"),
            func.sum(Sales.quantity_sold).label("unit_sold"),
        )
        .join(Product, Product.product_id == Sales.product_id)
        .join(Store, Store.store_id == Sales.store_id)
        .where(and_(*condition), Sales.timestamp.in_(last_year_dates_query))
    )

    revenue_data = await postgres_db.fetch_all(orders_query)

    if revenue_data:
        result = {
            "total_sales": round(revenue_data[0]["total_revenue"], 2)
            if revenue_data[0]["total_revenue"] is not None
            else 0,
            "total_orders": round(revenue_data[0]["num_orders"], 2)
            if revenue_data[0]["num_orders"] is not None
            else 0,
            "total_units_sold": round(revenue_data[0]["unit_sold"], 2)
            if revenue_data[0]["unit_sold"] is not None
            else 0,
            "total_margin": round(
                revenue_data[0]["total_revenue"] - revenue_data[0]["total_cost"], 2
            )
            if (
                revenue_data[0]["total_cost"] is not None
                and revenue_data[0]["total_revenue"] is not None
            )
            else 0,
        }
    else:
        result = {}

    await set_redis_cache(cache_key, result)
    return result


@manufacture.post("/top-mfac-brand", operation_id="fetch-top-mfac-brands")
async def fetch_top_mfac_brands(
    request_csv: Optional[UploadFile] = File(None),
    region_type: str = Form(None),
    region_name: str = Form(None),
    L0: str = Form(None),
    L1: str = Form(None),
    L2: str = Form(None),
    L3: str = Form(None),
    mfac_name: str = Form(None),
    brand_name: str = Form(None),
    postgres_db=Depends(get_postgres_db),
):
    condition = build_condition(region_type, region_name, L0, L1, L2, L3, filter="all")

    request_df = None
    if request_csv is not None:
        request_df = pd.read_csv(request_csv.file)
        if request_df.empty:
            return JSONResponse(
                content={"message": "Request data is empty."}, status_code=200
            )
    else:
        cache_key = f"top-mfac-brands:{region_type}:{region_name}:{L0}:{L1}:{L2}:{L3}:{mfac_name}:{brand_name}"
        response = await get_redis_cache(cache_key)
        if response:
            return response

    query = (
        select(
            Product.l0.label("L0"),
            Product.mfac_name,
            Product.brand_name,
            Product.product_id,
            Sales.store_id,
            func.sum(Sales.revenue).label("revenue"),
        )
        .join(Sales, Product.product_id == Sales.product_id)
        .join(Store, Store.store_id == Sales.store_id)
        .where(and_(*condition))
        .group_by(
            Product.l0,
            Product.mfac_name,
            Product.brand_name,
            Product.product_id,
            Sales.store_id,
        )
    )

    data = await postgres_db.fetch_all(query)
    rows = [dict(row) for row in data]

    if request_df is not None:
        result_df = pd.DataFrame(rows)
        if result_df.empty:
            return JSONResponse(content=[], status_code=200)
        else:
            merged_df = pd.merge(
                result_df, request_df, on=["sap_id", "br_code"], how="left"
            )
            rows = merged_df.to_dict(orient="records")

    # Initialize the result dictionary
    result = {"mfac": {}, "brand": {}, "product_id": {}}
    for record in rows:
        if (
            record["mfac_name"]
            and record["brand_name"]
            and record["L0"]
            and record["revenue"]
            and record["product_id"]
        ):
            mfac_name = record["mfac_name"]
            brand_name = record["brand_name"]
            l0_name = record["L0"]
            revenue = record["revenue"]
            product_id = record["product_id"]

            # Initialize mfac entry if not present
            if mfac_name not in result["mfac"]:
                result["mfac"][mfac_name] = {"total": 0}

            # Initialize brand entry if not present
            if brand_name not in result["brand"]:
                result["brand"][brand_name] = {"total": 0}

            # Initialize product_id entry if not present
            if product_id not in result["product_id"]:
                result["product_id"][product_id] = {"total": 0}

            # Initialize L0 entry if not present
            if l0_name not in result["mfac"][mfac_name]:
                result["mfac"][mfac_name][l0_name] = 0

            if l0_name not in result["brand"][brand_name]:
                result["brand"][brand_name][l0_name] = 0

            # Update the values
            result["mfac"][mfac_name][l0_name] += int(revenue)
            result["brand"][brand_name][l0_name] += int(revenue)
            result["product_id"][product_id]["total"] += int(revenue)

            result["mfac"][mfac_name]["total"] += int(revenue)
            result["brand"][brand_name]["total"] += int(revenue)

    # Sort and limit based on total revenue in descending order
    result["mfac"] = dict(
        sorted(result["mfac"].items(), key=lambda item: item[1]["total"], reverse=True)
    )
    result["mfac"] = dict(list(result["mfac"].items())[:10])

    result["brand"] = dict(
        sorted(result["brand"].items(), key=lambda item: item[1]["total"], reverse=True)
    )
    result["brand"] = dict(list(result["brand"].items())[:10])

    result["product_id"] = dict(
        sorted(
            result["product_id"].items(),
            key=lambda item: item[1]["total"],
            reverse=True,
        )
    )
    result["product_id"] = dict(list(result["product_id"].items())[:10])

    if request_csv is None:
        await set_redis_cache(cache_key, result)

    return result
