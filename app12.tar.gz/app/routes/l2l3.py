import json
from fastapi import APIRouter, Depends, Form
from models import Store
from routes import get_postgres_db
from asyncio import gather
from utils import get_l2l3_query, get_l2_table_query, get_l3_table_query, decimal_serializer, get_redis_cache, set_redis_cache


L2L3 = APIRouter(prefix="/couture/assortment", tags=["L2L3"])


@L2L3.post("/l2l3", operation_id="fetch-l2l3")  
async def fetch_l2l3(
    region_type: str = Form(None),
    region_name: str = Form(None),
    postgres_db = Depends(get_postgres_db),
):
 
    cache_key = f"l2l3:{region_type}:{region_name}"
    response = await get_redis_cache(cache_key)
    if response:
        return response

    condition = [] 
    if region_type == "Zone" and region_name is not None:
        condition.append(Store.zone == region_name)
    elif region_type == "State" and region_name is not None:
        condition.append(Store.state == region_name)
    elif region_type == "City" and region_name is not None:
        condition.append(Store.city == region_name)
    elif region_type == "Branch" and region_name is not None:
        condition.append(Store.store_id == region_name)

   
    l2_assort_comp_query, l2_assort_dist_miss_query, l3_assort_comp_query, l3_assort_dist_miss_query = await get_l2l3_query(condition)
  
    queries = [postgres_db.fetch_all(query) for query in [l2_assort_comp_query, l2_assort_dist_miss_query, l3_assort_comp_query, l3_assort_dist_miss_query]]
    result = await gather(*queries)
    l2_assort_comp, l2_assort_dist_miss, l3_assort_comp, l3_assort_dist_miss = result

    l2_assort_comp  = [dict(row) for row in l2_assort_comp]
    l2_assort_dist_miss = [dict(row) for row in l2_assort_dist_miss]
    l3_assort_comp = [dict(row) for row in l3_assort_comp]
    l3_assort_dist_miss = [dict(row) for row in l3_assort_dist_miss]

    # Convert the query results to a list of dictionaries
    result = {
        'l2_assort_comp': l2_assort_comp,
        'l2_assort_dist_miss': l2_assort_dist_miss,
        'l3_assort_comp': l3_assort_comp,
        'l3_assort_dist_miss': l3_assort_dist_miss
    }
  
    await set_redis_cache(cache_key, result, default=decimal_serializer)

    return result



@L2L3.post("/l2l3-table", operation_id="fetch-l2l3-table")
async def fetch_l2l3_table(
    region_type: str = Form(None),
    region_name: str = Form(None),
    page_no_l2: int = Form(1),
    page_count_l2: int = Form(100),
    sort_param_l2: str = Form("count_comp"),
    sort_type_l2: str = Form("desc"),
    page_no_l3: int = Form(1),
    page_count_l3: int = Form(100),
    sort_param_l3: str = Form("count_comp"),
    sort_type_l3: str = Form("desc"),
    postgres_db=Depends(get_postgres_db),
):
    cache_key = f"l2l3-table:{region_type}:{region_name}:{page_no_l2}:{page_count_l2}:{sort_param_l2}:{sort_type_l2}:{page_no_l3}:{page_count_l3}:{sort_param_l3}:{sort_type_l3}"
    response = await get_redis_cache(cache_key)
    if response:
        return response

    condition = []
    if region_type == "Zone" and region_name is not None:
        condition.append(Store.zone == region_name)
    elif region_type == "State" and region_name is not None:
        condition.append(Store.state == region_name)
    elif region_type == "City" and region_name is not None:
        condition.append(Store.city == region_name)
    elif region_type == "Branch" and region_name is not None:
        condition.append(Store.store_id == region_name)


    l2_query, l2_count_query = await get_l2_table_query(condition, page_no_l2, page_count_l2, sort_param_l2, sort_type_l2)
    l3_query, l3_count_query = await get_l3_table_query(condition, page_no_l3, page_count_l3, sort_param_l3, sort_type_l3)

    queries = [
        postgres_db.fetch_all(query) for query in [l2_query, l2_count_query, l3_query, l3_count_query]
    ]
    result = await gather(*queries)
    l2_table, l2_count,  l3_table, l3_count = result
    l2_table = [dict(row) for row in l2_table]
    l3_table = [dict(row) for row in l3_table]

    result_dict = {}
    result_dict["l2_table"] = l2_table
    result_dict["l3_table"] = l3_table
    result_dict["l2_count"] = l2_count[0]["l2_count"]
    result_dict["l3_count"] = l3_count[0]["l3_count"]
     
    await set_redis_cache(cache_key, result_dict, default=decimal_serializer)

    return result_dict