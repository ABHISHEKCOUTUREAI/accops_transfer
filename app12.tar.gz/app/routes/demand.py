from fastapi import APIRouter, Depends, HTTPException
from models import (
    Cart,
    Orders,
    Product,
    ProductDemandRequest,
    ProductDemandResponse,
    Sort,
)
from sqlalchemy import (
    and_,
    func,
    or_,
    select,
)
from utils import get_replenishment_query, get_weekly_sales

from routes.common import get_postgres_db

from .cart import form_filter_condition

demand_router = APIRouter(prefix="/couture/assortment/demand", tags=["demand"])


async def form_demand_query(request: ProductDemandRequest):
    # step 1: define replenishment case

    replenishment_query = await get_replenishment_query(request.store_id)

    # step 3: get the weekly sales details

    query = await get_weekly_sales(request.store_id)

    # step 4: outer_join the replenishment_query with the sales_query and select the top n products
    # only selecting the  products which have been sold in the past week
    final_query = (
        select(
            query.c.product_id,
            query.c.current_week_quantity_sold,
            query.c.past_week_quantity_sold,
            replenishment_query.c.replenishment,
            (
                (query.c.current_week_quantity_sold - query.c.past_week_quantity_sold)
                / query.c.past_week_quantity_sold
                * 100
            ).label("percentage_change"),
        )
        .where(query.c.past_week_quantity_sold > 0)
        .join(
            replenishment_query, query.c.product_id == replenishment_query.c.product_id
        )
    ).cte("final_query")

    # step 5: get product details of the top n products
    # globalsearch applied at this step
    # global search is performed on product_name and description

    product_details_query = (
        select(
            final_query.c.product_id.label("product_id"),
            final_query.c.current_week_quantity_sold.label("items_sold_this_week"),
            final_query.c.past_week_quantity_sold.label("items_sold_last_week"),
            final_query.c.replenishment.label("recommended_replenishment"),
            final_query.c.percentage_change.label("percentage_change"),
            Product.l0,
            Product.l3,
            Product.product_name,
        )
        .outerjoin(Product, final_query.c.product_id == Product.product_id)
        .filter(
            or_(
                Product.product_name.ilike(f"%{request.globalSearch}%"),
                Product.description.ilike(f"%{request.globalSearch}%"),
            )
        )
        .cte("product_details_query")
    )
    return product_details_query


async def get_demand_order_details(request, product_details_query, order):
    # add the filter, limit the query and sort it.
    condition = form_filter_condition(product_details_query, request.filters)
    limit = (
        select(product_details_query)
        .where(and_(*condition))
        .order_by(
            product_details_query.c.percentage_change.desc()
            if order == "desc"
            else product_details_query.c.percentage_change.asc()
        )
        .limit(request.num_products)
    ).cte("limit")

    # Subquery to calculate the sum of Orders.quantity
    order_sum_subquery = (
        select(
            Orders.product_id,
            func.coalesce(func.sum(Orders.quantity), 0).label("order_quantity"),
        )
        .filter(Orders.store_id == request.store_id)
        .group_by(Orders.product_id)
        .subquery()
    )

    # Main query
    order_details = (
        select(
            limit,
            order_sum_subquery.c.order_quantity,
            func.coalesce(Cart.quantity, 0).label("cart_quantity"),
        )
        .outerjoin(
            order_sum_subquery, limit.c.product_id == order_sum_subquery.c.product_id
        )
        .outerjoin(
            Cart,
            and_(
                limit.c.product_id == Cart.product_id,
                Cart.store_id
                == request.store_id,  # Ensure Cart.store_id is joined with request.store_id
            ),
        )
        .order_by(
            limit.c[request.sort.field].desc()
            if request.sort.order == "desc"
            else limit.c[request.sort.field].asc()
        )
    )
    return order_details


async def form_response(result):
    return [
        ProductDemandResponse(
            product_id=row.product_id,
            product_name=row.product_name,
            items_sold_last_week=row.items_sold_last_week,
            items_sold_this_week=row.items_sold_this_week,
            l0=row.l0,
            l3=row.l3,
            recommended_replenishment=row.recommended_replenishment,
            percentage_change=row.percentage_change,
            ordered_quantity=row.order_quantity,
            cart_quantity=row.cart_quantity,
        )
        for row in result
    ]


@demand_router.post(
    "/get-surging-products",
    status_code=200,
    response_model=list[ProductDemandResponse],
    description="Filters applicable on the Response model fields only. Globalsearch is applied on the Prodcut name and description",
)
async def get_surging_products(
    request: ProductDemandRequest, db=Depends(get_postgres_db)
) -> list[ProductDemandResponse]:
    try:
        # cache_key = request.model_dump(mode='json')
        # response = await get_redis_cache(cache_key)
        # if response:
        #     return json.loads(response)
        # set the default sort field and order if not provided
        if request.sort is None:
            request.sort = Sort(field="percentage_change", order="desc")
        product_details_query = await form_demand_query(request)

        order_details = await get_demand_order_details(
            request, product_details_query, "desc"
        )
        result = await db.fetch_all(order_details)
        response = await form_response(result)
        # response = jsonable_encoder(response)
        # await set_redis_cache(cache_key, response)
        return response

    # Execute the query and fetch results
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))


@demand_router.post(
    "/get-dipping-products",
    status_code=200,
    response_model=list[ProductDemandResponse],
    description="Filters applicable on the Response model fields only. Globalsearch is applied on the Prodcut name and description",
)
async def get_dipping_products(
    request: ProductDemandRequest, db=Depends(get_postgres_db)
) -> list[ProductDemandResponse]:
    try:
        # cache_key = request.model_dump(mode='json')
        # response = await get_redis_cache(cache_key)
        # if response:
        #     return json.loads(response)
        # set the default sort field and order if not provided
        if request.sort is None:
            request.sort = Sort(field="percentage_change", order="asc")
        product_details_query = await form_demand_query(request)

        order_details = await get_demand_order_details(
            request, product_details_query, "asc"
        )
        result = await db.fetch_all(order_details)
        response = await form_response(result)
        # response = jsonable_encoder(response)
        # await set_redis_cache(cache_key, response)
        return response

    # Execute the query and fetch results
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))
