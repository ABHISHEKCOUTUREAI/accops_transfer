from asyncio import gather
from datetime import datetime

from fastapi import APIRouter, Depends, Form, HTTPException
from models import (
    Assortment,
    CategoryDistributionResponse,
    CategoryTreeMapResponse,
    CriticalLowStockResponse,
    Inventory,
    Product,
    Store,
    Sort,
)
from settings import settings
from sqlalchemy import and_, case, func, select
from utils import build_condition, get_redis_cache, set_redis_cache
from typing import Optional
from routes.common import get_postgres_db

category_router = APIRouter(prefix="/couture/assortment", tags=["Category Analytics"])


def form_base_query(
    store_condition=[],
    product_condition=[],
    assortment_columns: list = ["max_qty", "min_qty"],
    product_columns: list = [],
    store_columns: list = [],
):
    """
    Form the base query by joining the assortment, product and store tables

    Args:

    store_condition (list): List of conditions for the store table
    product_condition (list): List of conditions for the product table
    assortment_columns (list): List of columns to be selected from the assortment table except product_id and store_id
    product_columns (list): List of columns to be selected from the product table except product_id
    store_columns (list): List of columns to be selected from the store table except store_id
    response_columns (list): List of columns to be selected in the response

    """
    product_query = (
        select(
            *[getattr(Product, column) for column in product_columns],
            Product.product_id,
        )
        .where(and_(*product_condition))
        .cte("product_query")
    )

    store_query = (
        select(*[getattr(Store, column) for column in store_columns], Store.store_id)
        .where(and_(*store_condition))
        .cte("store_query")
    )

    query = (
        select(
            *[getattr(Assortment, column) for column in assortment_columns],
            product_query,
            store_query,
        )
        .join(product_query, product_query.c.product_id == Assortment.product_id)
        .join(store_query, store_query.c.store_id == Assortment.store_id)
    )

    return query


def form_inventory_query():
    inventory_query = (
        select(
            Inventory.product_id,
            Inventory.store_id,
            func.sum(Inventory.stock_quantity).label("stock_quantity"),
        )
        .where(
            and_(
                Inventory.timestamp
                >= datetime.strptime(settings.inventory_start_timestamp, "%Y-%m-%d"),
                Inventory.timestamp
                <= datetime.strptime(settings.inventory_end_timestamp, "%Y-%m-%d"),
            )
        )
        .group_by(Inventory.product_id, Inventory.store_id)
        .cte("inventory_query")
    )
    return inventory_query


@category_router.post(
    "/critical-low-stock",
    operation_id="critical_low_stock",
    status_code=200,
    response_model=list[CriticalLowStockResponse],
)
async def critical_low_stock(
    region_type: str = Form(None),
    region_name: str = Form(None),
    L0: str = Form(None),
    L1: str = Form(None),
    L2: str = Form(None),
    L3: str = Form(None),
    mfac_name: str = Form(None),
    brand_name: str = Form(None),
    page_no: int = Form(1),
    page_count: int = Form(10),
    postgres_db=Depends(get_postgres_db),
    sort_param: str = Form(None),
    sort_order: str = Form(None),
) -> list[CriticalLowStockResponse]:
    """
    Get the critical low stock L3 based on the filter parameters
    """
    try:
        cache_key = f"critical_low_stock_{region_type}_{region_name}_{L0}_{L1}_{L2}_{L3}_{mfac_name}_{brand_name}_{page_no}_{page_count}_{sort_param}_{sort_order}"
        response = await get_redis_cache(cache_key)
        if response:
            return response
        store_condition, product_condition = build_condition(
            region_type,
            region_name,
            L0,
            L1,
            L2,
            L3,
            mfac_name=mfac_name,
            brand=brand_name,
        )

        query = form_base_query(
            store_condition,
            product_condition,
            assortment_columns=["min_qty", "max_qty"],
            product_columns=["product_id", "l3"],
            store_columns=["store_id"],
        ).cte("query")

        inventory_query = form_inventory_query()

        final_query = (
            select(
                query.c.l3.label("category"),
                func.count(query.c.product_id).label("total_deficit"),
            )
            .join(
                inventory_query,
                and_(
                    query.c.product_id == inventory_query.c.product_id,
                    query.c.store_id == inventory_query.c.store_id,
                ),
            )
            .where(inventory_query.c.stock_quantity < query.c.min_qty)
            .group_by(query.c.l3)
            .offset((page_no - 1) * page_count)
        ).cte("final_query")

        if sort_param is None:
            sort_param = "total_deficit"
        if sort_order is None:
            sort_order = "desc"

        filtered_final_query = select(final_query).order_by(
            final_query.c[sort_param].desc() if sort_order == "desc" else final_query.c[sort_param]).limit(page_count).cte("filtered_final_query")
        results = await postgres_db.fetch_all(filtered_final_query)
        await set_redis_cache(cache_key, results, default=dict)

        return list[CriticalLowStockResponse](results)
    except Exception as e:
        raise HTTPException(
            status_code=500,
            detail={str(e)},
        )


@category_router.post(
    "/category-treemap",
    operation_id="category_treemap",
    status_code=200,
    response_model=list[CategoryTreeMapResponse],
)
async def category_treemap(
    region_type: str = Form(None),
    region_name: str = Form(None),
    L0: str = Form(None),
    L1: str = Form(None),
    L2: str = Form(None),
    L3: str = Form(None),
    mfac_name: str = Form(None),
    brand_name: str = Form(None),
    postgres_db=Depends(get_postgres_db),
) -> list[CategoryTreeMapResponse]:
    """
    Get the category treemap based on the filter parameters
    """
    try:
        cache_key = f"category_treemap_{region_type}_{region_name}_{L0}_{L1}_{L2}_{L3}_{mfac_name}_{brand_name}"
        response = await get_redis_cache(cache_key)
        if response:
            return response

        store_condition, product_condition = build_condition(
            region_type,
            region_name,
            L0,
            L1,
            L2,
            L3,
            mfac_name=mfac_name,
            brand=brand_name,
        )

        query = form_base_query(
            store_condition,
            product_condition,
            assortment_columns=["min_qty"],
            product_columns=["l0", "l3"],
            store_columns=[],
        ).cte("query")

        inventory_query = form_inventory_query()

        query = (
            select(
                query.c.l0, query.c.l3, func.count(query.c.product_id).label("count")
            )
            .join(
                inventory_query,
                and_(
                    query.c.product_id == inventory_query.c.product_id,
                    query.c.store_id == inventory_query.c.store_id,
                ),
            )
            .where(inventory_query.c.stock_quantity < query.c.min_qty)
            .group_by(query.c.l0, query.c.l3)
            .order_by(func.count(query.c.product_id).desc())
        )

        results = await postgres_db.fetch_all(query)

        data = {}

        for result in results:
            category = result["l0"]
            if category not in data:
                data[category] = {
                    "category": result["l0"],
                    "value": result["count"],
                    "children": [
                        {
                            "category": result["l3"],
                            "value": result["count"],
                        }
                    ],
                }
            else:
                data[category]["value"] += result["count"]
                data[category]["children"].append(
                    {
                        "category": result["l3"],
                        "value": result["count"],
                    }
                )

        await set_redis_cache(cache_key, list[CategoryTreeMapResponse](data.values()))
        return list[CategoryTreeMapResponse](data.values())
    except Exception as e:
        raise HTTPException(
            status_code=500,
            detail={str(e)},
        )


@category_router.post(
    "/category-distribution",
    operation_id="category_distribution",
    status_code=200,
    response_model=CategoryDistributionResponse,
)
async def category_distribution(
    region_type: str = Form(None),
    region_name: str = Form(None),
    L0: str = Form(None),
    L1: str = Form(None),
    L2: str = Form(None),
    L3: str = Form(None),
    mfac_name: str = Form(None),
    brand_name: str = Form(None),
    filter_params: list[str] = Form([]),
    filter_type: str = Form(None),
    postgres_db=Depends(get_postgres_db),
) -> CategoryDistributionResponse:
    """
    Get the category distribution based on the filter parameters
    """
    try:
        cache_key = f"category_distribution_{region_type}_{region_name}_{L0}_{L1}_{L2}_{L3}_{mfac_name}_{brand_name}_{filter_params}_{filter_type}"
        response = await get_redis_cache(cache_key)
        if response:
            return response
        store_condition, product_condition = build_condition(
            region_type,
            region_name,
            L0,
            L1,
            L2,
            L3,
            mfac_name=mfac_name,
            brand=brand_name,
        )

        query = form_base_query(
            store_condition,
            product_condition,
            assortment_columns=["min_qty", "max_qty"],
            product_columns=["product_id", "l0", "l1", "l2", "l3"],
            store_columns=["store_id"],
        )

        if filter_type == "status_label":
            inventory_query = form_inventory_query()

            join_query = (
                select(
                    query.c.l0,
                    query.c.l1,
                    query.c.l2,
                    query.c.l3,
                    query.c.product_id,
                    case(
                        (
                            (inventory_query.c.stock_quantity == 0)
                            & (query.c.min_qty > 0),
                            "0_new",
                        ),
                        (
                            (inventory_query.c.stock_quantity > 0)
                            & (inventory_query.c.stock_quantity < query.c.min_qty),
                            "1_replenish",
                        ),
                        (
                            (inventory_query.c.stock_quantity > 0)
                            & (inventory_query.c.stock_quantity >= query.c.min_qty)
                            & (inventory_query.c.stock_quantity <= query.c.max_qty),
                            "2_no_replenishment",
                        ),
                        (
                            (inventory_query.c.stock_quantity == 0)
                            & (query.c.max_qty == 0),
                            "8_dead",
                        ),
                        (
                            (inventory_query.c.stock_quantity > query.c.max_qty),
                            "9_excess",
                        ),
                        # else 'unidentified
                    ).label("status_label"),
                )
                .join(
                    inventory_query,
                    and_(
                        query.c.product_id == inventory_query.c.product_id,
                        query.c.store_id == inventory_query.c.store_id,
                    ),
                    isouter=True,
                )
                .cte("join_query")
            )

            query = select(join_query).where(
                join_query.c.status_label.in_(filter_params)
            )

        l0_query = (
            select(
                query.c.l0.label("l0"),
                func.count(query.c.product_id).label("count"),
            )
            .group_by(query.c.l0)
            .order_by(func.count(query.c.product_id).desc())
        )

        l1_query = (
            select(
                query.c.l1.label("l1"),
                func.count(query.c.product_id).label("count"),
            )
            .group_by(query.c.l1)
            .order_by(func.count(query.c.product_id).desc())
        )

        l2_query = (
            select(
                query.c.l2.label("l2"),
                func.count(query.c.product_id).label("count"),
            )
            .group_by(query.c.l2)
            .order_by(func.count(query.c.product_id).desc())
        )

        l3_query = (
            select(
                query.c.l3.label("l3"),
                func.count(query.c.product_id).label("count"),
            )
            .group_by(query.c.l3)
            .order_by(func.count(query.c.product_id).desc())
        )

        results = await gather(
            postgres_db.fetch_all(l0_query),
            postgres_db.fetch_all(l1_query),
            postgres_db.fetch_all(l2_query),
            postgres_db.fetch_all(l3_query),
        )

        data = {
            "l0_data": [dict(row) for row in results[0]],
            "l1_data": [dict(row) for row in results[1]],
            "l2_data": [dict(row) for row in results[2]],
            "l3_data": [dict(row) for row in results[3]],
        }

        await set_redis_cache(cache_key, data)

        return CategoryDistributionResponse(**data)
    except Exception as e:
        raise HTTPException(
            status_code=500,
            detail={str(e)},
        )
