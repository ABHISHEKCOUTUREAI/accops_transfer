from asyncio import gather
from datetime import datetime

from fastapi import APIRouter, Depends, HTTPException
from fastapi.responses import JSONResponse
from models import (
    Assortment,
    AutocompleteProductRequest,
    AutocompleteProductResponse,
    AutocompleteProductResponseChild,
    Cart,
    CartRequest,
    CartResponse,
    Inventory,
    Item,
    OrderResponse,
    OrderResponseProduct,
    Orders,
    OrdersRequest,
    OrdersResponseChild,
    Product,
    ProductRequest,
    ProductResponse,
    ProductResponseChild,
    Sort,
)
from settings import settings
from sqlalchemy import (
    String,
    and_,
    case,
    delete,
    func,
    insert,
    or_,
    select,
    update,
)
from sqlalchemy.dialects.postgresql import ARRAY

from routes.common import get_postgres_db

cart_router = APIRouter(prefix="/couture/assortment", tags=["Cart"])


def form_inventory_query(store_id):
    inventory_query = (
        select(
            Inventory.product_id,
            func.sum(Inventory.stock_quantity).label("stock_quantity"),
        )
        .where(
            and_(
                Inventory.timestamp
                >= datetime.strptime(settings.inventory_start_timestamp, "%Y-%m-%d"),
                Inventory.timestamp
                <= datetime.strptime(settings.inventory_end_timestamp, "%Y-%m-%d"),
                Inventory.store_id == store_id,
            )
        )
        .group_by(Inventory.product_id)
        .cte("inventory_query")
    )
    return inventory_query


def form_orders_query(store_id):
    orders_query = (
        select(Orders.product_id, func.sum(Orders.quantity).label("order_qty"))
        .where(Orders.store_id == store_id)
        .group_by(Orders.product_id)
        .cte("orders_query")
    )
    return orders_query


def form_assortment_query(store_id):
    assortment_query = (
        select(Assortment.product_id, Assortment.max_qty, Assortment.min_qty)
        .where(Assortment.store_id == store_id)
        .cte("assortment")
    )
    return assortment_query


def form_updated_repelishment_query(store_id):
    assortment_query = form_assortment_query(store_id)
    inventory_query = form_inventory_query(store_id)
    orders_query = form_orders_query(store_id)

    updated_replenishment_query = (
        select(
            assortment_query.c.product_id,
            assortment_query.c.min_qty,
            assortment_query.c.max_qty,
            func.coalesce(inventory_query.c.stock_quantity, 0).label("stock_quantity"),
            (
                assortment_query.c.max_qty
                - func.coalesce(inventory_query.c.stock_quantity, 0)
                - func.coalesce(orders_query.c.order_qty, 0)
            ).label("minimum_replenishment"),
            case(
                (
                    (func.coalesce(inventory_query.c.stock_quantity, 0) == 0)
                    & (assortment_query.c.min_qty > 0),
                    "0_new",
                ),
                (
                    (
                        func.coalesce(inventory_query.c.stock_quantity, 0)
                        + func.coalesce(orders_query.c.order_qty, 0)
                        > 0
                    )
                    & (
                        func.coalesce(inventory_query.c.stock_quantity, 0)
                        + func.coalesce(orders_query.c.order_qty, 0)
                        < assortment_query.c.min_qty
                    ),
                    "1_replenish",
                ),
                (
                    (
                        func.coalesce(inventory_query.c.stock_quantity, 0)
                        + func.coalesce(orders_query.c.order_qty, 0)
                        > 0
                    )
                    & (
                        func.coalesce(inventory_query.c.stock_quantity, 0)
                        + func.coalesce(orders_query.c.order_qty, 0)
                        >= assortment_query.c.min_qty
                    )
                    & (
                        func.coalesce(inventory_query.c.stock_quantity, 0)
                        + func.coalesce(orders_query.c.order_qty, 0)
                        <= assortment_query.c.max_qty
                    ),
                    "2_no_replenishment",
                ),
                (
                    (func.coalesce(inventory_query.c.stock_quantity, 0) == 0)
                    & (assortment_query.c.max_qty == 0),
                    "8_dead",
                ),
                (
                    (
                        func.coalesce(inventory_query.c.stock_quantity, 0)
                        + func.coalesce(orders_query.c.order_qty, 0)
                        > assortment_query.c.max_qty
                    ),
                    "9_excess",
                ),
                else_="other",
            ).label("status_label"),
        )
        .join(
            inventory_query,
            and_(
                inventory_query.c.product_id == assortment_query.c.product_id,
                inventory_query.c.stock_quantity < assortment_query.c.min_qty,
            ),
            isouter=True,
        )
        .join(
            orders_query,
            orders_query.c.product_id == assortment_query.c.product_id,
            isouter=True,
        )
        .cte("updated_replenishment_query")
    )

    return updated_replenishment_query


def form_cart_items_query(store_id, cart_query):
    updated_replenishment_query = form_updated_repelishment_query(store_id)
    final_query = (
        select(
            cart_query.c.quantity,
            updated_replenishment_query,
            Product.l0,
            Product.l3,
            Product.description,
            Product.product_name,
            Product.price,
        )
        .join(
            updated_replenishment_query,
            updated_replenishment_query.c.product_id == cart_query.c.product_id,
        )
        .join(
            Product,
            Product.product_id == cart_query.c.product_id,
        )
    )

    return final_query


def form_filter_condition(query, filters):
    condition = []
    for filter in filters:
        if filter.type == "search":
            condition.append(query.c[filter.id].ilike(f"%{filter.query}%"))
        elif filter.type == "range":
            if filter.min:
                condition.append(query.c[filter.id] >= filter.min)
            if filter.max:
                condition.append(query.c[filter.id] <= filter.max)
        elif filter.type == "discrete":
            condition.append(query.c[filter.id].in_(filter.queries))
        elif filter.type == "discrete_contained":
            condition.append(
                query.c[filter.id].cast(ARRAY(String)).contains(filter.queries)
            )
    return condition


def cart_coverage_queries(store_id: str, cart_query):
    assortment_query = form_assortment_query(store_id)
    orders_query = form_orders_query(store_id)
    inventory_query = form_inventory_query(store_id)

    updated_inventory_query = (
        select(
            inventory_query.c.product_id,
            (
                inventory_query.c.stock_quantity
                + func.coalesce(orders_query.c.order_qty, 0)
            ).label("stock_quantity"),
        )
        .join(
            orders_query,
            orders_query.c.product_id == inventory_query.c.product_id,
            isouter=True,
        )
        .cte("updated_inventory_query")
    )

    updated_replenishment_query = (
        select(
            assortment_query.c.product_id,
            (
                assortment_query.c.max_qty - updated_inventory_query.c.stock_quantity
            ).label("updated_replenish_qty"),
        )
        .join(
            updated_inventory_query,
            and_(
                updated_inventory_query.c.product_id == assortment_query.c.product_id,
                updated_inventory_query.c.stock_quantity < assortment_query.c.min_qty,
            ),
        )
        .cte("updated_replenishment_query")
    )

    final_query = (
        select(
            updated_replenishment_query.c.product_id,
            case(
                (
                    cart_query.c.quantity
                    >= updated_replenishment_query.c.updated_replenish_qty,
                    updated_replenishment_query.c.updated_replenish_qty,
                ),
                else_=func.coalesce(cart_query.c.quantity, 0),
            ).label("cart_coverage_by_items"),
            case(
                (
                    cart_query.c.quantity
                    >= updated_replenishment_query.c.updated_replenish_qty,
                    updated_replenishment_query.c.product_id,
                ),
                else_=None,
            ).label("is_optimal"),
            updated_replenishment_query.c.updated_replenish_qty,
        )
        .join(
            cart_query,
            cart_query.c.product_id == updated_replenishment_query.c.product_id,
            isouter=True,
        )
        .cte("final_query")
    )

    cart_coverage_value_query = select(
        (
            func.sum(final_query.c.cart_coverage_by_items * Product.price)
            * 100
            / func.sum(final_query.c.updated_replenish_qty * Product.price)
        ).label("cart_coverage_by_value")
    ).select_from(
        final_query.join(Product, Product.product_id == final_query.c.product_id)
    )

    cart_coverage_items_query = select(
        (
            func.count(final_query.c.is_optimal)
            * 100
            / func.count(final_query.c.product_id)
        ).label("cart_coverage_by_items")
    ).select_from(final_query)

    return cart_coverage_value_query, cart_coverage_items_query


@cart_router.post("/cart", operation_id="add_to_cart", status_code=201)
async def add_to_cart(cart: Item, db=Depends(get_postgres_db)):
    """
    Add a product to the cart
    """
    try:
        existing_cart = await db.fetch_one(
            select(Cart).where(
                and_(
                    Cart.store_id == cart.store_id,
                    Cart.product_id == cart.product_id,
                )
            )
        )
        if existing_cart:
            if cart.quantity == 0:
                await db.execute(
                    delete(Cart).where(
                        and_(
                            Cart.store_id == cart.store_id,
                            Cart.product_id == cart.product_id,
                        )
                    )
                )
                message = "Product deleted from cart successfully"
            else:
                await db.execute(
                    update(Cart)
                    .where(
                        and_(
                            Cart.store_id == cart.store_id,
                            Cart.product_id == cart.product_id,
                        )
                    )
                    .values(quantity=cart.quantity)
                )
                message = "Product updated in cart successfully"
            return JSONResponse(status_code=200, content={"message": message})
        else:
            if cart.quantity == 0:
                return JSONResponse(
                    status_code=400, content={"message": "Quantity cannot be zero"}
                )
            await db.execute(
                insert(Cart).values(
                    store_id=cart.store_id,
                    product_id=cart.product_id,
                    quantity=cart.quantity,
                )
            )
            return JSONResponse(
                status_code=201,
                content={"message": "Product added to cart successfully"},
            )

    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))


@cart_router.post(
    "/get-cart",
    operation_id="get_cart",
    status_code=200,
    response_model=CartResponse,
)
async def get_cart(request: CartRequest, db=Depends(get_postgres_db)) -> CartResponse:
    """
    Get the cart for a store
    """
    try:
        # Check if cart is empty
        cart_width_query = select(func.count(Cart.product_id)).where(
            Cart.store_id == request.store_id
        )
        cart_width = await db.fetch_val(cart_width_query)
        if cart_width == 0:
            return CartResponse(
                items=[],
                cart_coverage_by_value=0,
                cart_coverage_by_items=0,
                total_cart_value=0,
                total_cart_width=0,
                total_count=0,
            )
        if request.sort is None:
            request.sort = Sort(field="quantity", order="desc")
        cart_query = (
            select(Cart.product_id, Cart.quantity)
            .where(Cart.store_id == request.store_id)
            .cte("cart_query")
        )
        (
            cart_coverage_value_query,
            cart_coverage_items_query,
        ) = cart_coverage_queries(request.store_id, cart_query)
        cart_value_query = (
            select(func.sum(cart_query.c.quantity * Product.price))
            .select_from(cart_query)
            .join(Product, Product.product_id == cart_query.c.product_id)
        )
        cart_width_query = select(func.count(cart_query.c.product_id)).select_from(
            cart_query
        )
        query = form_cart_items_query(request.store_id, cart_query).cte("query")
        condition = form_filter_condition(query, request.filters)
        cart_items_query = (
            select(query)
            .where(and_(*condition))
            .order_by(
                query.c[request.sort.field].asc()
                if request.sort.order == "asc"
                else query.c[request.sort.field].desc()
            )
            .offset((request.page_no - 1) * request.page_count)
            .limit(request.page_count)
        )

        tasks = [
            db.fetch_all(cart_items_query),
            db.fetch_val(cart_coverage_value_query),
            db.fetch_val(cart_coverage_items_query),
            db.fetch_val(cart_value_query),
            db.fetch_val(cart_width_query),
        ]

        (
            cart_items,
            cart_coverage_by_value,
            cart_coverage_by_items,
            cart_value,
            cart_width,
        ) = await gather(*tasks)
        response = {
            "items": [dict(row) for row in cart_items],
            "cart_coverage_by_value": cart_coverage_by_value,
            "cart_coverage_by_items": cart_coverage_by_items,
            "total_cart_value": cart_value,
            "total_cart_width": cart_width,
            "total_count": cart_width,
        }
        return CartResponse(**response)
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))


@cart_router.post(
    "/place-order/{store_id}",
    operation_id="place_order",
    status_code=201,
)
async def place_order(store_id: str, db=Depends(get_postgres_db)):
    try:
        cart = await db.fetch_all(select(Cart).where(Cart.store_id == store_id))
        if not cart:
            return JSONResponse(
                status_code=400,
                content={"message": "Cart is empty. Please add products to cart"},
            )
        order_id = f"{store_id}-{datetime.now().strftime('%Y%m%d%H%M%S')}"
        current_time = datetime.now()
        await db.execute(
            insert(Orders).values(
                [
                    dict(
                        order_id=order_id,
                        order_created_at=current_time,
                        store_id=item.store_id,
                        product_id=item.product_id,
                        quantity=item.quantity,
                        fulfillment_status="unfulfilled",
                    )
                    for item in cart
                ]
            )
        )
        await db.execute(delete(Cart).where(Cart.store_id == store_id))
        return JSONResponse(
            content={"message": "Order placed successfully", "order_id": order_id}
        )
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))


@cart_router.post(
    "/fulfill-order/{order_id}", operation_id="fulfill_order", status_code=200
)
async def fulfill_order(order_id: str, db=Depends(get_postgres_db)):
    try:
        order = await db.fetch_one(select(Orders).where(Orders.order_id == order_id))
        if not order:
            return JSONResponse(
                status_code=400,
                content={"message": "Order not found"},
            )
        if order.fulfillment_status == "fulfilled":
            return JSONResponse(
                status_code=400,
                content={"message": "Order already fulfilled"},
            )
        await db.execute(
            update(Orders)
            .where(Orders.order_id == order_id)
            .values(fulfillment_status="fulfilled", fulfillment_datetime=datetime.now())
        )
        return JSONResponse(
            content={"message": "Order fulfilled successfully", "order_id": order_id}
        )
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))


@cart_router.delete(
    "/hard-reset/{store_id}", operation_id="hard_reset", status_code=200
)
async def hard_reset(store_id: str, db=Depends(get_postgres_db)):
    try:
        await db.execute(delete(Orders).where(Orders.store_id == store_id))
        return JSONResponse(content={"message": "Orders Deleted successfully"})
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))


## globalsearch only works for product name and description
@cart_router.post(
    "/orders", status_code=200, response_model=OrderResponse, operation_id="get_orders"
)
async def get_orders_for_branch(
    request: OrdersRequest, db=Depends(get_postgres_db)
) -> OrderResponse:
    """
    Get orders for a branch given the store_id.
    A new filter is used here which filters the order based on the product id along with the default filters.

    """
    try:
        # get the total orders available in a branch
        offset = (request.page_no - 1) * request.page_count

        # Filter the Orders table first
        filtered_orders = (
            select(
                Orders.order_id,
                Orders.order_created_at,
                Orders.fulfillment_datetime,
                Orders.fulfillment_status,
                Orders.product_id,
            ).where(
                Orders.store_id == request.store_id,
            )
        ).cte("filtered_orders")
        # # Join the filtered Orders table with the Products table and apply globalsearch filter
        query = (
            select(
                filtered_orders.c.order_id,
                func.max(filtered_orders.c.order_created_at).label("ordered_at"),
                func.max(filtered_orders.c.fulfillment_datetime).label("fulfilled_at"),
                func.max(filtered_orders.c.fulfillment_status).label("order_status"),
                func.array_agg(Product.product_id).label("product_id"),
                func.array_agg(Product.product_name).label("product_name"),
                func.count(Product.product_id).label("total_products"),
            )
            .join(Product, filtered_orders.c.product_id == Product.product_id)
            .filter(
                or_(
                    Product.product_name.ilike(f"%{request.globalSearch}%"),
                    Product.description.ilike(f"%{request.globalSearch}%"),
                    filtered_orders.c.order_id.ilike(f"%{request.globalSearch}%"),
                )
            )
            .group_by(filtered_orders.c.order_id)
        ).cte("query")
        # Apply additional filters using form_filter_condition
        condition = form_filter_condition(query, request.filters)

        # Query to count the total number of distinct orders
        total_orders_query = select(func.count(func.distinct(query.c.order_id))).where(
            and_(*condition)
        )
        # Create the final query with the applied conditions, ordering, and pagination
        final_query = (
            select(query)
            .where(and_(*condition))
            .order_by(query.c.ordered_at.desc())
            .offset(offset)
            .limit(request.page_count)
        )
        # Execute the queries
        tasks = [db.fetch_all(final_query), db.fetch_val(total_orders_query)]
        results, total_orders = await gather(*tasks)

        response = OrderResponse(
            total_count=total_orders,
            items=[
                OrdersResponseChild(
                    order_id=result.order_id,
                    ordered_at=result.ordered_at,
                    fulfilled_at=result.fulfilled_at,
                    order_status=result.order_status,
                    products=[
                        OrderResponseProduct(
                            product_id=result.product_id[j],
                            product_name=result.product_name[j],
                        )
                        for j in range(min(len(result.product_id), 5))
                    ],
                    total_products=result.total_products,
                )
                for result in results
            ],
        )
        return response

    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))


@cart_router.post(
    "/order-details",
    status_code=200,
    response_model=ProductResponse,
    operation_id="get_products",
)
async def get_products(
    request: ProductRequest, db=Depends(get_postgres_db)
) -> ProductResponse:
    try:
        # select the order details based on order id
        orders_query = (
            (
                select(
                    Orders.fulfillment_status.label("order_status"),
                    Orders.order_created_at.label("ordered_at"),
                    Orders.fulfillment_datetime.label("fulfilled_at"),
                )
            )
            .where(Orders.order_id == request.order_id)
            .limit(1)
        )

        # find the total order value
        order_value_query = (
            select(
                func.sum(Product.price * Orders.quantity).label("order_cost"),
            )
            .select_from(Orders)
            .where(Orders.order_id == request.order_id)
            .join(Product, Product.product_id == Orders.product_id)
        )

        # Filter the Orders based on the order_id to obtain the products in the order for joing with the products table
        filtered_orders = (
            select(
                Orders.order_id,
                Orders.product_id,
                Orders.quantity.label("ordered_quantity"),
                Orders.fulfillment_status.label("order_status"),
            ).where(Orders.order_id == request.order_id)
        ).cte("filtered_orders")

        # Join the filtered Orders with the Product table
        query = (
            select(
                Product.product_id,
                Product.product_name,
                Product.description,
                Product.price,
                filtered_orders.c.ordered_quantity,
            )
            .join(Product, filtered_orders.c.product_id == Product.product_id)
            .filter(
                or_(
                    Product.product_name.ilike(f"%{request.globalSearch}%"),
                    Product.description.ilike(f"%{request.globalSearch}%"),
                ),
            )
        ).cte("query")

        # Apply additional filters and sorting
        condition = form_filter_condition(query, request.filters)

        total_products_query = select(
            func.count(func.distinct(query.c.product_id))
        ).where(and_(*condition))

        # set default sort condition
        if request.sort is None:
            request.sort = Sort(field="ordered_quantity", order="desc")
        offset = (request.page_no - 1) * request.page_count

        # apply the filterm sort and offset-limit for pagination
        final_query = (
            select(query)
            .where(and_(*condition))
            .order_by(
                query.c[request.sort.field].asc()
                if request.sort.order == "asc"
                else query.c[request.sort.field].desc()
            )
            .offset(offset)
            .limit(request.page_count)
        )

        tasks = [
            db.fetch_all(final_query),
            db.fetch_val(total_products_query),
            db.fetch_one(orders_query),
            db.fetch_val(order_value_query),
        ]
        results, total_products, order_details, order_cost = await gather(*tasks)

        response = ProductResponse(
            count=total_products,
            order_id=order_details.order_id,
            ordered_at=order_details.ordered_at,
            fulfilled_at=order_details.fulfilled_at,
            order_status=order_details.order_status,
            total_order_value=order_cost,
            products=[
                ProductResponseChild(
                    product_id=result.product_id,
                    product_name=result.product_name,
                    description=result.description,
                    ordered_quantity=result.ordered_quantity,
                    price=result.price,
                )
                for result in results
            ],
        )
        return response

    except Exception as e:
        return HTTPException(status_code=500, detail=str(e))


@cart_router.post(
    "/autocomplete-products",
    status_code=200,
    response_model=AutocompleteProductResponse,
)
async def autocomplete_products(
    request: AutocompleteProductRequest, db=Depends(get_postgres_db)
) -> AutocompleteProductResponse:
    try:
        query = (
            select(
                Product.product_id,
                Product.product_name,
            )
            .filter(
                or_(
                    Product.product_name.ilike(f"%{request.query}%"),
                ),
            )
            .order_by(Product.product_name.asc())
        ).cte("query")

        total_products_query = select(func.count(func.distinct(query.c.product_id)))

        offset = (request.page_no - 1) * request.page_count
        final_query = (
            select(query)
            ## sort by productid ascending
            .offset(offset)
            .limit(request.page_count)
        )

        tasks = [db.fetch_all(final_query), db.fetch_val(total_products_query)]
        results, total_products = await gather(*tasks)
        response = AutocompleteProductResponse(
            total_count=total_products,
            products=[
                AutocompleteProductResponseChild(
                    product_id=result.product_id,
                    product_name=result.product_name,
                )
                for result in results
            ],
        )
        return response

    except Exception as e:
        return HTTPException(status_code=500, detail=str(e))
