from fastapi import Request
from databases import Database
from settings import Settings


def get_postgres_db(request: Request) -> Database:
    return request.app.state.db.database

def get_settings(request: Request) -> Settings:
    return request.app.state.settings