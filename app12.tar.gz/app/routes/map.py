import json
from fastapi import APIRouter, Depends
from models import Store
from routes import get_postgres_db
from sqlalchemy import func, select
from db import redis_db
from utils import (
    decimal_serializer,
    get_state_map_data,
    get_zone_map_data,
    get_redis_cache,
    set_redis_cache,
)


map = APIRouter(prefix="/couture/assortment", tags=["manufacture"])


@map.get("/map", operation_id="fetch-map-results")
async def fetch_map_data(
    postgres_db=Depends(get_postgres_db),
):
    cache_key = "map"
    response = await get_redis_cache(cache_key)
    if response:
        return response

    # get state data
    (
        assortment_state,
        total_revenue,
        total_margin,
        total_quantity_sold,
    ) = await get_state_map_data(postgres_db)

    # get zone data
    assortment_zone = await get_zone_map_data(postgres_db)

    #  get all stores count
    store_count_query = select(func.count(Store.store_id))
    store_count = await postgres_db.fetch_one(store_count_query)

    # Response
    result = {
        "state": assortment_state,
        "zone": assortment_zone,
        "total_revenue": total_revenue,
        "total_quantity_sold": total_quantity_sold,
        "total_margin": total_margin,
        "total_store": store_count[0],
    }

    await set_redis_cache(cache_key, result, default=decimal_serializer)

    return result
