from asyncio import gather

from fastapi import APIRouter, Depends, HTTPException
from models import (
    NotificationResponse,
    Product,
    ReplenishmentNotificationRequest,
)
from sqlalchemy import select
from utils import get_replenishment_query, get_weekly_sales

from routes.common import get_postgres_db

notification_router = APIRouter(
    prefix="/couture/assortment/notifications", tags=["notifications"]
)


@notification_router.post(
    "/",
    status_code=200,
    response_model=NotificationResponse,
    description="Fetches the top n Replenisment worthy and surging products for a store",
)
async def get_notification_products(
    request: ReplenishmentNotificationRequest, db=Depends(get_postgres_db)
) -> NotificationResponse:
    try:
        # Part1:  get the replenishment
        replenishment_query = await get_replenishment_query(request.store_id)
        # limit the number of products to be shown
        limited = (
            (
                select(replenishment_query).order_by(
                    replenishment_query.c.replenishment.desc()
                )
            )
            .limit(request.num_products)
            .cte("limited")
        )
        # get the product details
        product_details_query = (
            select(limited, Product.product_name)
            .select_from(limited)
            .join(Product, Product.product_id == limited.c.product_id)
        )

        # Part2:  get the surge_details
        surge_query = await get_weekly_sales(request.store_id)
        # limit the number of products to be shown
        filtered_surge = (
            (
                select(
                    surge_query.c.product_id,
                    (
                        (
                            surge_query.c.current_week_quantity_sold
                            - surge_query.c.past_week_quantity_sold
                        )
                        / surge_query.c.past_week_quantity_sold
                        * 100
                    ).label("percentage_change"),
                ).where(surge_query.c.past_week_quantity_sold > 0)
            )
        ).subquery()

        limited_surge = (
            (
                select(filtered_surge)
                .where(filtered_surge.c.percentage_change > 0)
                .order_by(filtered_surge.c.percentage_change.desc())
            )
            .limit(request.num_products)
            .cte("limited_surge")
        )

        surge_product_details_query = (
            select(limited_surge, Product.product_name)
            .select_from(limited_surge)
            .join(Product, Product.product_id == limited_surge.c.product_id)
        )

        replenishment_results, surge_results = await gather(
            db.fetch_all(product_details_query),
            db.fetch_all(surge_product_details_query),
        )

        replenishment_results = [dict(row) for row in replenishment_results]
        surge_results = [dict(row) for row in surge_results]

        response = {"replenishment": replenishment_results, "surge": surge_results}
        return response
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))
