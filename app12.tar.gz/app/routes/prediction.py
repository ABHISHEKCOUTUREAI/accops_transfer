import csv
import math
from asyncio import gather
from collections import defaultdict
from datetime import datetime
from io import StringIO
from typing import List, Optional

import pandas as pd
from fastapi import APIRouter, Depends, File, Form, Request, UploadFile
from fastapi.responses import JSONResponse, StreamingResponse
from models import Assortment, Cart, Inventory, Orders, Product, Sales, Store
from settings import settings
from sqlalchemy import and_, asc, case, desc, func, or_, select
from utils import (
    build_condition,
    get_assortment_results,
    get_hit_results,
    get_miss_results,
    get_redis_cache,
    get_status_count,
    set_redis_cache,
)

from routes.common import get_postgres_db

prediction = APIRouter(prefix="/couture/assortment", tags=["prediction"])

def form_orders_query():
    return select(
        Orders.product_id,
        Orders.store_id,
        func.sum(Orders.quantity).label("quantity"),
        func.max(Orders.fulfillment_status).label("fulfillment_status"),
        ).group_by(Orders.product_id, Orders.store_id).cte("orders_query")


def form_base_query(store_condition=[], product_condition=[], globalSearch=""):
    product_query = select(Product).where(and_(*product_condition)).subquery()
    store_query = (
        select(Store.zone, Store.state, Store.city, Store.store_id)
        .where(and_(*store_condition))
        .subquery()
    )
    order_query = form_orders_query()

    query = (
        select(
            Assortment,
            product_query.c.l0.label("L0"),
            product_query.c.l1.label("L1"),
            product_query.c.l2.label("L2"),
            product_query.c.l3.label("L3"),
            product_query.c.description,
            product_query.c.price,
            product_query.c.product_name,
            product_query.c.mfac_name,
            product_query.c.brand_name,
            store_query.c.zone,
            store_query.c.state,
            store_query.c.city,
            func.coalesce(Cart.quantity, 0).label("cart_quantity"),
            func.coalesce(order_query.c.quantity, 0).label("order_quantity"),
            func.coalesce(order_query.c.fulfillment_status, "Not Ordered").label(
                "order_status"
            ),
        )
        .join(product_query, product_query.c.product_id == Assortment.product_id)
        .join(store_query, store_query.c.store_id == Assortment.store_id)
        .outerjoin(
            Cart,
            and_(
                Cart.product_id == Assortment.product_id,
                Cart.store_id == Assortment.store_id,
            ),
        )
        .outerjoin(
            order_query,
            and_(
                order_query.c.product_id == Assortment.product_id,
                order_query.c.store_id == Assortment.store_id,
            ),
        )
    )
    return query


@prediction.post("/hit-and-miss", operation_id="fetch-products-info")
async def fetch_hit_and_miss(
    request: Request,
    request_csv: Optional[UploadFile] = File(None),
    region_type: str = Form(None),
    region_name: str = Form(None),
    L0: str = Form(None),
    L1: str = Form(None),
    L2: str = Form(None),
    L3: str = Form(None),
    mfac_name: str = Form(None),
    brand_name: str = Form(None),
    page_no: int = Form(1),
    page_count: int = Form(100),
    sort_param: str = Form("num_qty_sold"),
    sort_type: str = Form("desc"),
    filter_params: List[str] = Form([]),
    molecule: str = Form(None),
    sap_id: int = Form(None),
    filter_type: str = Form(None),
    counts_flag: bool = Form(True),
    item_name: str = Form(None),
    postgres_db=Depends(get_postgres_db),
    globalSearch: str = Form(None),
):
    request_df = None
    if request_csv is not None:
        request_df = pd.read_csv(request_csv.file)
        if request_df.empty:
            return JSONResponse(
                content={"message": "Request data is empty."}, status_code=200
            )

    store_condition, product_condition = build_condition(
        region_type,
        region_name,
        L0,
        L1,
        L2,
        L3,
        mfac_name,
        brand=brand_name,
        molecule=molecule,
        sap_id=sap_id,
        item_name=item_name,
    )

    query = form_base_query(store_condition, product_condition, globalSearch).subquery()

    sales_query = (
        select(
            Sales.product_id,
            Sales.store_id,
            func.sum(Sales.revenue).label("revenue"),
            func.sum(Sales.cost).label("cost"),
            func.sum(Sales.quantity_sold).label("quantity_sold"),
        )
        .where(
            and_(
                Sales.timestamp
                >= datetime.strptime(settings.sales_start_timestamp, "%Y-%m-%d"),
                Sales.timestamp
                <= datetime.strptime(settings.sales_end_timestamp, "%Y-%m-%d"),
            )
        )
        .group_by(Sales.product_id, Sales.store_id)
        .subquery()
    )

    inventory_query = (
        select(
            Inventory.product_id,
            Inventory.store_id,
            func.sum(Inventory.stock_quantity).label("stock_quantity"),
        )
        .where(
            and_(
                Inventory.timestamp
                >= datetime.strptime(settings.inventory_start_timestamp, "%Y-%m-%d"),
                Inventory.timestamp
                <= datetime.strptime(settings.inventory_end_timestamp, "%Y-%m-%d"),
            )
        )
        .group_by(Inventory.product_id, Inventory.store_id)
        .subquery()
    )

    query = (
        select(
            query,
            func.coalesce(sales_query.c.revenue, 0).label("total_amount"),
            (
                (sales_query.c.revenue - sales_query.c.cost)
                * 100
                / sales_query.c.revenue
            ).label("total_margin"),
            # num_qty_sold if it exists or else 0
            func.coalesce(sales_query.c.quantity_sold, 0).label("num_qty_sold"),
            func.coalesce(inventory_query.c.stock_quantity, 0).label(
                "current_inventory"
            ),
        )
        .join(
            sales_query,
            and_(
                sales_query.c.product_id == query.c.product_id,
                sales_query.c.store_id == query.c.store_id,
            ),
            isouter=True,
        )
        .join(
            inventory_query,
            and_(
                inventory_query.c.product_id == query.c.product_id,
                inventory_query.c.store_id == query.c.store_id,
            ),
            isouter=True,
        )
        .subquery()
    )
    result = {
        "assortment": [],
        "hits": [],
        "misses": [],
        "hit_count": 0,
        "miss_count": 0,
        "assortment_count": 0,
    }

    # sort and limit the query results
    order_by_clause = (
        desc(f"{sort_param}") if sort_type == "desc" else asc(f"{sort_param}")
    )
    offset = (page_no - 1) * page_count

    # Hits
    is_csv = False
    hit_response = await get_hit_results(
        request,
        query,
        order_by_clause,
        offset,
        postgres_db,
        is_csv,
        request_df,
        page_count=100,
    )
    hits, hit_count = hit_response
    result["hits"] = hits
    result["hit_count"] = hit_count

    # Misses
    miss_response = await get_miss_results(
        request,
        query,
        order_by_clause,
        offset,
        postgres_db,
        is_csv,
        request_df,
        page_count=100,
    )
    misses, miss_count = miss_response
    result["misses"] = misses
    result["miss_count"] = miss_count

    # Assortment
    assortment_response = await get_assortment_results(
        request,
        query,
        order_by_clause,
        offset,
        postgres_db,
        is_csv,
        request_df,
        page_count=100,
        filter_params=filter_params,
        filter_type=filter_type,
    )
    assortment, assortment_count, assortment_query = assortment_response
    result["assortment"] = assortment
    result["assortment_count"] = assortment_count

    if counts_flag:
        # Status count
        response = await get_status_count(assortment_query, postgres_db)
        (
            new_count,
            replenish_count,
            optimal_count,
            excess_count,
            total_assortment_count,
        ) = response
        result["new_count"] = new_count
        result["replenish_count"] = replenish_count
        result["optimal_count"] = optimal_count
        result["excess_count"] = excess_count
        result["total_assortment_count"] = total_assortment_count

    inhand_inventory_query = select(
        func.sum(query.c.det_cogs * query.c.current_inventory).label(
            "inhand_inventory_cost"
        ),
        func.count(func.distinct(query.c.product_id)).label("inhand_assortment_width"),
    ).where(
        and_(
            query.c.exist_in_baseline_output == 1, query.c.current_inventory.isnot(None)
        )
    )

    inventory_response = await postgres_db.fetch_all(inhand_inventory_query)

    result["inhand_inventory_cost"] = (
        round(inventory_response[0]["inhand_inventory_cost"], 2)
        if inventory_response[0]["inhand_inventory_cost"] is not None
        else 0
    )
    result["inhand_assortment_width"] = (
        inventory_response[0]["inhand_assortment_width"]
        if inventory_response[0]["inhand_assortment_width"] is not None
        else 0
    )

    recommended_inventory_query = select(
        func.sum(query.c.det_cogs * query.c.max_qty).label(
            "recommended_inventory_cost"
        ),
        func.count(func.distinct(query.c.product_id)).label(
            "recommended_assortment_width"
        ),
    ).where(query.c.exist_in_model_output == 1)

    recommended_response = await postgres_db.fetch_all(recommended_inventory_query)

    result["recommended_inventory_cost"] = (
        round(recommended_response[0]["recommended_inventory_cost"], 2)
        if recommended_response[0]["recommended_inventory_cost"] is not None
        else 0
    )
    result["recommended_assortment_width"] = (
        recommended_response[0]["recommended_assortment_width"]
        if recommended_response[0]["recommended_assortment_width"] is not None
        else 0
    )


    return result


@prediction.post("/hit-miss-csv", operation_id="fetch-hit-miss-csv")  # done
async def fetch_hit_and_miss_csv(
    request: Request,
    request_csv: Optional[UploadFile] = File(None),
    region_type: str = Form(None),
    region_name: str = Form(None),
    L0: str = Form(None),
    L1: str = Form(None),
    L2: str = Form(None),
    L3: str = Form(None),
    molecule: str = Form(None),
    sap_id: int = Form(None),
    status: str = Form("0_new"),
    sort_param: str = Form("num_qty_sold"),
    sort_type: str = Form("desc"),
    csv_flag: str = Form("recommended"),
    postgres_db=Depends(get_postgres_db),
    filter_params: List[str] = Form([]),
    filter_type: str = Form(None),
):
    request_df = None
    if request_csv is not None:
        request_df = pd.read_csv(request_csv.file)
        if request_df.empty:
            return JSONResponse(
                content={"message": "Request data is empty."}, status_code=200
            )

    store_condition, product_condition = build_condition(
        region_type, region_name, L0, L1, L2, L3, molecule, sap_id
    )

    query = form_base_query(store_condition, product_condition).subquery()

    sales_query = (
        select(
            Sales.product_id,
            Sales.store_id,
            func.sum(Sales.revenue).label("revenue"),
            func.sum(Sales.cost).label("cost"),
            func.sum(Sales.quantity_sold).label("quantity_sold"),
        )
        .where(
            and_(
                Sales.timestamp
                >= datetime.strptime(settings.sales_start_timestamp, "%Y-%m-%d"),
                Sales.timestamp
                <= datetime.strptime(settings.sales_end_timestamp, "%Y-%m-%d"),
            )
        )
        .group_by(Sales.product_id, Sales.store_id)
        .subquery()
    )

    inventory_query = (
        select(
            Inventory.product_id,
            Inventory.store_id,
            func.sum(Inventory.stock_quantity).label("stock_quantity"),
        )
        .where(
            and_(
                Inventory.timestamp
                >= datetime.strptime(settings.inventory_start_timestamp, "%Y-%m-%d"),
                Inventory.timestamp
                <= datetime.strptime(settings.inventory_end_timestamp, "%Y-%m-%d"),
            )
        )
        .group_by(Inventory.product_id, Inventory.store_id)
        .subquery()
    )

    query = (
        select(
            query,
            sales_query.c.revenue.label("total_amount"),
            (
                (sales_query.c.revenue - sales_query.c.cost)
                * 100
                / sales_query.c.revenue
            ).label("total_margin"),
            sales_query.c.quantity_sold.label("num_qty_sold"),
            inventory_query.c.stock_quantity.label("current_inventory"),
        )
        .join(
            sales_query,
            and_(
                sales_query.c.product_id == query.c.product_id,
                sales_query.c.store_id == query.c.store_id,
            ),
            isouter=True,
        )
        .join(
            inventory_query,
            and_(
                inventory_query.c.product_id == query.c.product_id,
                inventory_query.c.store_id == query.c.store_id,
            ),
            isouter=True,
        )
        .subquery()
    )

    # sort and limit the query results
    order_by_clause = (
        desc(f"{sort_param}") if sort_type == "desc" else asc(f"{sort_param}")
    )
    offset = 0

    # Hits
    is_csv = True
    if csv_flag == "hits":
        # Hits
        hit_response = await get_hit_results(
            request,
            query,
            order_by_clause,
            offset,
            postgres_db,
            is_csv,
            request_df,
            page_count=1000,
        )
        hits, hit_count = hit_response
        result = [dict(row) for row in hits]

    # Misses
    elif csv_flag == "misses":
        miss_response = await get_miss_results(
            request,
            query,
            order_by_clause,
            offset,
            postgres_db,
            is_csv,
            request_df,
            page_count=1000,
        )
        misses, miss_count = miss_response
        result = [dict(row) for row in misses]

    # Assortment
    else:
        assortment_response = await get_assortment_results(
            request,
            query,
            order_by_clause,
            offset,
            postgres_db,
            is_csv,
            request_df,
            page_count=1000,
            filter_params=filter_params,
            filter_type=filter_type,
        )
        assortment, assortment_count, assortment_query = assortment_response
        result = [dict(row) for row in assortment]

    # filter by status
    if status is not None and csv_flag != "misses":
        result = [row for row in result if row["status_label"] == status]

    if request_df is not None:
        result_df = pd.DataFrame(result)
        if not result:
            return JSONResponse(content=[], status_code=200)
        merged_df = pd.merge(
            result_df, request_df, on=["sap_id", "br_code"], how="left"
        )
        result = merged_df.to_dict(orient="records")

    if result:
        # Create a CSV string
        csv_content = StringIO()
        csv_writer = csv.DictWriter(csv_content, fieldnames=result[0].keys())
        csv_writer.writeheader()
        csv_writer.writerows(result)

        # Convert the CSV string to bytes
        csv_bytes = csv_content.getvalue().encode("utf-8")

        # Return the response as a streaming response with content type "text/csv"
        return StreamingResponse(
            iter([csv_bytes]),
            media_type="text/csv",
            headers={"Content-Disposition": "attachment;filename=response.csv"},
        )
    else:
        # If there are no rows, return an empty response
        return StreamingResponse(
            iter([]),
            media_type="text/csv",
            headers={"Content-Disposition": "attachment;filename=products.csv"},
        )


@prediction.post("/margin-buckets", operation_id="fetch-margin-buckets")  # done
async def fetch_margin_buckets(
    region_type: str = Form(None),
    region_name: str = Form(None),
    L0: str = Form(None),
    L1: str = Form(None),
    L2: str = Form(None),
    L3: str = Form(None),
    postgres_db=Depends(get_postgres_db),
):
    # Build the filter
    store_condition, product_condition = build_condition(
        region_type, region_name, L0, L1, L2, L3
    )

    query = form_base_query(store_condition, product_condition).subquery()
    # Hits
    sales_query = (
        select(
            Sales.product_id,
            Sales.store_id,
            func.sum(Sales.revenue).label("revenue"),
            func.sum(Sales.cost).label("cost"),
            func.sum(Sales.quantity_sold).label("quantity_sold"),
        )
        .where(
            and_(
                Sales.timestamp
                >= datetime.strptime(settings.sales_start_timestamp, "%Y-%m-%d"),
                Sales.timestamp
                <= datetime.strptime(settings.sales_end_timestamp, "%Y-%m-%d"),
            )
        )
        .group_by(Sales.product_id, Sales.store_id)
        .subquery()
    )

    query = (
        select(
            query,
            sales_query.c.revenue.label("total_amount"),
            (
                (sales_query.c.revenue - sales_query.c.cost)
                * 100
                / sales_query.c.revenue
            ).label("total_margin"),
        )
        .join(
            sales_query,
            and_(
                sales_query.c.product_id == query.c.product_id,
                sales_query.c.store_id == query.c.store_id,
            ),
        )
        .subquery()
    )

    base_margin_query = select(
        # Calculate the derived 'margin' column with a case statement to handle division by zero
        query.c.exist_in_model_output,
        query.c.is_sold,
        case(
            (
                query.c.total_amount - query.c.total_margin != 0,
                (query.c.total_margin / (query.c.total_amount - query.c.total_margin))
                * 100,
            ),
            else_=0,
        ).label("margin"),
    ).subquery()
    hit_condition = and_(
        base_margin_query.c.exist_in_model_output == 1,
        base_margin_query.c.is_sold == 1,
    )
    miss_condition = and_(
        base_margin_query.c.exist_in_model_output == 0,
        base_margin_query.c.is_sold == 1,
    )
    hit_query = select(base_margin_query).where(hit_condition)
    miss_query = select(base_margin_query).where(miss_condition)

    hit_ranges = await postgres_db.fetch_all(hit_query)
    miss_ranges = await postgres_db.fetch_all(miss_query)

    hit_bucket = defaultdict(int)
    miss_bucket = defaultdict(int)

    for row in hit_ranges:
        hit_bucket[math.ceil(row["margin"] / 5)] += 1
    for row in miss_ranges:
        miss_bucket[math.ceil(row["margin"] / 5)] += 1

    hit_bucket_list = []
    miss_bucket_list = []
    for bucket_index in range(21):
        hit_bucket_list.append(hit_bucket[bucket_index])
        miss_bucket_list.append(miss_bucket[bucket_index])

    return {"hit_bucket": hit_bucket_list, "miss_bucket": miss_bucket_list}


# Take a csv file with fields br_code, sap_id, min_qty, max_qty as column names
@prediction.post("/bulk-assortment", operation_id="fetch-bulk-assortment")
async def fetch_bulk_assortment(
    region_type: str = Form(None),
    region_name: str = Form(None),
    file: UploadFile = File(...),
    postgres_db=Depends(get_postgres_db),
):
    # read csv file
    csv_data = pd.read_csv(file.file)

    # get column names
    column_names = csv_data.columns.tolist()

    # get index of column name sap_id
    sap_id_index = column_names.index("sap_id")

    # get index of column name br_code
    # br_code_index = column_names.index("br_code")

    tuple_list = []
    # create  list of tuples of form (br_code, sap_id)
    # for index, row in csv_data.iterrows():
    #     tuple_list.append((row[br_code_index], row[sap_id_index]))
    for index, row in csv_data.iterrows():
        tuple_list.append(row[sap_id_index])

    query = (
        select(
            Assortment.product_id,
            Assortment.store_id,
            Store.zone,
            Store.state,
            Store.city,
            Store.store_id,
            Product.product_name,
        )
        .join(Store, Assortment.store_id == Store.store_id)
        .subquery()
    )

    region_conditions = []
    if region_type == "Zone":
        region_conditions.append(query.c.zone == region_name)
    elif region_type == "State":
        region_conditions.append(query.c.state == region_name)
    elif region_type == "City":
        region_conditions.append(query.c.city == region_name)
    elif region_type == "Branch":
        region_conditions.append(query.c.br_code == region_name)

    br_sap_conditions = [query.c.product_id == int(sap_id) for sap_id in tuple_list]

    query = (
        select(query)
        .where(and_(or_(*region_conditions), or_(br_sap_conditions)))
        .subquery()
    )

    sales_query = (
        select(
            Sales.product_id,
            Sales.store_id,
            func.sum(Sales.revenue).label("revenue"),
            func.sum(Sales.cost).label("cost"),
            func.sum(Sales.quantity_sold).label("quantity_sold"),
        )
        .where(
            and_(
                Sales.timestamp
                >= datetime.strptime(settings.sales_start_timestamp, "%Y-%m-%d"),
                Sales.timestamp
                <= datetime.strptime(settings.sales_end_timestamp, "%Y-%m-%d"),
            )
        )
        .group_by(Sales.product_id, Sales.store_id)
        .subquery()
    )

    query = select(
        query,
        sales_query.c.revenue.label("total_amount"),
        (
            (sales_query.c.revenue - sales_query.c.cost) * 100 / sales_query.c.revenue
        ).label("total_margin"),
        sales_query.c.quantity_sold.label("num_qty_sold"),
    ).join(
        sales_query,
        and_(
            query.c.product_id == sales_query.c.product_id,
            query.c.store_id == sales_query.c.store_id,
        ),
    )

    query = select(
        # AssortmentOutput.br_code,
        query.c.product_id,
        query.c.product_name,
        # Assortment.total_amount,
        func.sum(query.c.total_amount).label("total_amount"),  # Actual past sales
        func.sum(query.c.total_margin).label("total_margin"),  # Actual past margin
        func.sum(query.c.num_qty_sold).label("num_qty_sold"),
        # func.sum(query.c.total_amount_train).label("total_amount_train"),
        # func.sum(query.c.total_margin_train).label("total_margin_train"),
        # func.sum(query.c.num_qty_sold_train).label("num_qty_sold_train"),
        # AssortmentOutput.total_margin,    # Actual past margin
        # AssortmentOutput.num_qty_sold ,
        # AssortmentOutput.total_amount_train,
        # AssortmentOutput.total_margin_train,
        # AssortmentOutput.exist_in_model_output,
        # AssortmentOutput.is_sold,
    ).group_by(query.c.product_id)

    rows = await postgres_db.fetch_all(query)
    return rows


@prediction.post("/fetch-filters", operation_id="fetch-filters")
async def fetch_filters(
    request_csv: Optional[UploadFile] = File(None),
    region_type: str = Form(None),
    region_name: str = Form(None),
    L0: str = Form(None),
    L1: str = Form(None),
    L2: str = Form(None),
    L3: str = Form(None),
    mfac_name: str = Form(None),
    brand_name: str = Form(None),
    postgres_db=Depends(get_postgres_db),
):
    request_df = None
    if request_csv is not None:
        request_df = pd.read_csv(request_csv.file)
        if request_df.empty:
            return JSONResponse(
                content={"message": "Request data is empty."}, status_code=200
            )
    else:
        cache_key = f"fetch-filters:{region_type}:{region_name}:{L0}:{L1}:{L2}:{L3}:{mfac_name}:{brand_name}"
        response = await get_redis_cache(cache_key)
        if response:
            return response

    store_condition, product_condition = build_condition(
        region_type, region_name, L0, L1, L2, L3, mfac_name=mfac_name, brand=brand_name
    )

    query = form_base_query(store_condition, product_condition).subquery()

    query = (
        select(
            query.c.store_id,
            query.c.state,
            query.c.city,
            query.c.zone,
            query.c.L0,
            query.c.L1,
            query.c.L2,
            query.c.L3,
            query.c.mfac_name,
            query.c.brand_name,
            query.c.product_id,
        )
        .where(and_(query.c.exist_in_model_output == 1))
        .subquery()
    )

    L0_query = select(
        query.c.L0, func.count(func.distinct(query.c.product_id))
    ).group_by(query.c.L0)

    L1_query = select(
        query.c.L1, func.count(func.distinct(query.c.product_id))
    ).group_by(query.c.L1)

    L2_query = select(
        query.c.L2, func.count(func.distinct(query.c.product_id))
    ).group_by(query.c.L2)

    L3_query = select(
        query.c.L3, func.count(func.distinct(query.c.product_id))
    ).group_by(query.c.L3)

    queries = [
        postgres_db.fetch_all(query)
        for query in [L0_query, L1_query, L2_query, L3_query, query]
    ]

    result = await gather(*queries)

    L0_rows, L1_rows, L2_rows, L3_rows, rows = result

    filters_count = {
        "L0": {row[0]: row[1] for row in L0_rows},
        "L1": {row[0]: row[1] for row in L1_rows},
        "L2": {row[0]: row[1] for row in L2_rows},
        "L3": {row[0]: row[1] for row in L3_rows},
    }

    if request_df is not None:
        rows = [dict(row) for row in rows]
        result_df = pd.DataFrame(rows)
        if not result:
            return JSONResponse(content=[], status_code=200)
        # TODO: right join
        merged_df = pd.merge(
            result_df, request_df, on=["product_id", "store_id"], how="left"
        )

        # merged_df = merged_df[
        # ["br_code", "state", "city", "zone", "L0", "L1", "L2", "L3", "mfac_name", "brand_name"]
        # ].fillna({'br_code': 'NA', 'state': 'NA', 'city': 'NA', 'zone': 'NA', 'L0': 'NA', 'L1': 'NA', 'L2': 'NA', 'L3': 'NA', 'mfac_name': 'NA', 'brand_name': 'NA'})
        rows = merged_df.to_dict(orient="records")

    # Organize data into a nested dictionary
    filters_data = defaultdict(
        lambda: defaultdict(lambda: defaultdict(lambda: defaultdict(dict)))
    )

    for row in rows:
        br_code = row["store_id"]
        state = row["state"]
        city = row["city"]
        zone = row["zone"]
        local_L0 = row["L0"]
        local_L1 = row["L1"]
        local_L2 = row["L2"]
        local_L3 = row["L3"]
        mfac = row["mfac_name"]
        brand = row["brand_name"]

        filters_data["location"][zone][state][city][br_code] = {}
        filters_data["category"][local_L0][local_L1][local_L2][local_L3] = {}
        filters_data["mfac"][mfac][brand] = {}

    filters_data["filters_count"] = filters_count

    if request_csv is None:
        await set_redis_cache(cache_key, filters_data)

    return filters_data


# API to search molecule from product table
@prediction.get("/molecule-autocomplete")
async def fetch_molecule(molecule: str = None, postgres_db=Depends(get_postgres_db)):
    cache_key = f"molecule-autocomplete:{molecule}"
    response = await get_redis_cache(cache_key)
    if response:
        return response

    # do prefix search of molecule in product table
    query = (
        select(Product.description)
        .where(Product.description.ilike(f"%{molecule}%"))
        .distinct()
    )
    rows = await postgres_db.fetch_all(query)
    result = [row[0] for row in rows]

    await set_redis_cache(cache_key, result)
    return result
