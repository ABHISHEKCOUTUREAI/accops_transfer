from asyncio import gather

from configs import config
from fastapi import APIRouter, Depends, HTTPException
from models import (
    HitMissRequest,
    HitMissResponse,
    StoreAssortmentRequest,
    StoreAssortmentResponse,
)
from utils import (
    add_cart_query,
    count_product_id_query,
    filter_query,
    form_assortment_response,
    form_base_query,
    form_combined_query,
    form_hit_miss_query,
    form_hit_miss_response,
    form_inventory_query,
    get_count_query,
    get_inhand_inventory,
    get_recomended_inventory,
    get_replenishment_query,
    get_status_count_query,
    get_status_query,
    get_total_sales,
    sort_and_paginate,
)

from routes.common import get_postgres_db

assortment_router = APIRouter(
    prefix="/couture/assortment/test", tags=["new-assortment"]
)


@assortment_router.post(
    "/assortment",
    # response_model=StoreAssortmentResponse,
    operation_id="fetch-assorment-info",
    summary="Fetches the assortment information for a store based on the request",
    description="Fetches the assortment information for a store based on the request. This is a functionality meant for the store manager",
)
async def fetch_products_info(
    request: StoreAssortmentRequest,
    db=Depends(get_postgres_db),
):  # -> StoreAssortmentResponse:
    try:
        currrent_config = config["assortment"]
        query = form_base_query(request=request, base_config=currrent_config)

        if currrent_config["inventory"]:
            inventory_query = form_inventory_query(request=request)
            combined_query = form_combined_query(query, inventory_query)
            replenishment_query = get_replenishment_query(combined_query)
            status_query = get_status_query(replenishment_query)
        else:
            status_query = query

        if currrent_config["cart"]:
            query_with_cart = add_cart_query(status_query, request)
        else:
            query_with_cart = status_query

        column_to_keep = currrent_config["return_columns"]
        filtered_query = filter_query(
            query_with_cart, request, column_names=column_to_keep
        )

        ordered_paginated_assortment_query = sort_and_paginate(filtered_query, request)
        tasks = [
            db.fetch_all(ordered_paginated_assortment_query),
        ]
        if currrent_config["inventory"]:
            status_count_query = get_status_count_query(status_query)
            tasks.append(db.fetch_all(status_count_query))
        else:
            status_count_query = count_product_id_query(query)
            tasks.append(db.fetch_val(status_count_query))

        if currrent_config["overall_count"]:
            inhand_inventory_query = get_inhand_inventory(combined_query)
            recommended_inventory_query = get_recomended_inventory(combined_query)
            tasks.append(db.fetch_all(inhand_inventory_query))
            tasks.append(db.fetch_all(recommended_inventory_query))

        results = await gather(*tasks)

        response = form_assortment_response(results, currrent_config)
        return response

    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))


@assortment_router.post(
    "/hit-miss",
    # response_model=HitMissResponse,
    operation_id="fetch-hit-miss-info",
    summary="Fetches the hit and miss information for a store based on the request",
    description="Fetches the hit and miss information for a store based on the request. This is a functionality meant for the store manager or overall operations manager",
)
async def fetch_hit_miss_info(
    request: HitMissRequest,
    db=Depends(get_postgres_db),
):  # -> HitMissResponse:
    try:
        currrent_config = config["hit_miss"]
        query = form_base_query(request=request, base_config=currrent_config)
        if currrent_config["inventory"]:
            inventory_query = form_inventory_query(request=request)
            combined_query = form_combined_query(query, inventory_query)
            replenishment_query = get_replenishment_query(combined_query)
            status_query = get_status_query(replenishment_query)

        else:
            status_query = query

        hit_miss_query = form_hit_miss_query(status_query, request)
        if currrent_config["cart"]:
            query_with_cart = add_cart_query(hit_miss_query, request)
        else:
            query_with_cart = hit_miss_query

        if currrent_config["sales"]:
            total_sales_info = get_total_sales(query_with_cart, request)
        else:
            total_sales_info = query_with_cart
        column_to_keep = currrent_config["return_columns"]
        filtered_query = filter_query(
            total_sales_info, request, column_names=column_to_keep
        )

        ordered_paginated_assortment_query = sort_and_paginate(filtered_query, request)
        count_query = get_count_query(filtered_query)
        tasks = [
            db.fetch_all(ordered_paginated_assortment_query),
            db.fetch_val(count_query),
        ]

        results = await gather(*tasks)

        response = form_hit_miss_response(results)
        return response

    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))
