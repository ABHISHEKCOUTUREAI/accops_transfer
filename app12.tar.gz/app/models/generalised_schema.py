from sqlalchemy import (
    Column,
    DateTime,
    Float,
    Index,
    Integer,
    PrimaryKeyConstraint,
    String,
)
from sqlalchemy.ext.declarative import declarative_base

Base = declarative_base()


# Common tables
class Assortment(Base):
    __tablename__ = "assortment"

    product_id = Column(String, primary_key=True)
    store_id = Column(String, primary_key=True)
    min_qty = Column(Integer)  # min_prediction
    max_qty = Column(Integer)  # max_prediction
    probability = Column(Float)  # probability of prediction
    exist_in_model_output = Column(Integer)
    exist_in_baseline_output = Column(Integer)
    is_sold = Column(Integer)
    is_new_product = Column(Integer)
    det_cogs = Column(Float)

    __table_args__ = (
        PrimaryKeyConstraint("product_id", "store_id"),
        Index("idx_assortment_product_id", "product_id"),
        Index("idx_assortment_store_id", "store_id"),
    )


class NewStoresAssortment(Base):
    __tablename__ = "new_store_assortment"

    product_id = Column(Integer, primary_key=True)
    total_amount = Column(Float)
    total_margin = Column(Float)
    qty_sold = Column(Float)
    min_qty = Column(Integer)
    max_qty = Column(Integer)
    qty_bounce_train = Column(Float)
    qty_bounce_test = Column(Float)
    qty_sold_online = Column(Float)
    store_id = Column(String, primary_key=True)
    qty_sold_train = Column(Float)
    num_stores_product_part_of_assortment = Column(Integer)
    region_type = Column(String, primary_key=True)
    region_name = Column(String, primary_key=True)

    __table_args__ = (
        PrimaryKeyConstraint("product_id", "store_id", "region_type", "region_name"),
        Index("idx_new_store_assortment_product_id", "product_id"),
        Index("idx_new_store_assortment_store_id", "store_id"),
        Index("idx_new_store_assortment_region_type", "region_type"),
        Index("idx_new_store_assortment_region_name", "region_name"),
    )


class Product(Base):
    __tablename__ = "product"

    product_id = Column(String, primary_key=True)
    product_name = Column(String)
    brand_name = Column(String)
    price = Column(Float)
    l0 = Column(String)
    l1 = Column(String)
    l2 = Column(String)
    l3 = Column(String)
    l4 = Column(String)
    mfac_name = Column(String)
    description = Column(String)

    __table_args__ = (
        Index("idx_product_product_name", "product_name"),
        Index("idx_product_brand_name", "brand_name"),
        Index("idx_product_l0", "l0"),
        Index("idx_product_l1", "l1"),
        Index("idx_product_l2", "l2"),
        Index("idx_product_l3", "l3"),
        Index("idx_product_l4", "l4"),
        Index("idx_product_mfac_name", "mfac_name"),
        Index("idx_product_description", "description"),
    )


class Store(Base):
    __tablename__ = "store"

    store_id = Column(String, primary_key=True)
    zone = Column(String)
    state = Column(String)
    city = Column(String)
    pincode = Column(Integer)

    __table_args__ = (
        PrimaryKeyConstraint("store_id"),
        Index("idx_store_store_id", "store_id"),
        Index("idx_store_zone", "zone"),
        Index("idx_store_state", "state"),
        Index("idx_store_city", "city"),
    )


class Inventory(Base):
    __tablename__ = "inventory"
    timestamp = Column(DateTime, primary_key=True)
    store_id = Column(String, primary_key=True)
    product_id = Column(String, primary_key=True)
    stock_value = Column(Float)
    stock_quantity = Column(Float)

    __table_args__ = (
        PrimaryKeyConstraint("timestamp", "store_id", "product_id"),
        Index("idx_inventory_timestamp", "timestamp"),
        Index("idx_inventory_store_id", "store_id"),
        Index("idx_inventory_product_id", "product_id"),
    )


class Sales(Base):
    __tablename__ = "sales"
    timestamp = Column(DateTime, primary_key=True)
    store_id = Column(String, primary_key=True)
    product_id = Column(String, primary_key=True)
    quantity_sold = Column(Float)
    revenue = Column(Float)  # Selling price
    cost = Column(Float)  # Cost price (COGS)
    number_of_orders = Column(Integer)

    __table_args__ = (
        PrimaryKeyConstraint("timestamp", "store_id", "product_id"),
        Index("idx_sales_timestamp", "timestamp"),
        Index("idx_sales_store_id", "store_id"),
        Index("idx_sales_product_id", "product_id"),
    )


class Cart(Base):
    __tablename__ = "cart"
    store_id = Column(String, primary_key=True)
    product_id = Column(String, primary_key=True)
    quantity = Column(Float)

    __table_args__ = (
        PrimaryKeyConstraint("store_id", "product_id"),
        Index("idx_cart_store_id", "store_id"),
    )


class Orders(Base):
    __tablename__ = "orders"
    order_id = Column(String, primary_key=True)
    order_created_at = Column(DateTime)
    store_id = Column(String, primary_key=True)
    product_id = Column(String, primary_key=True)
    quantity = Column(Float)
    fulfillment_status = Column(String)
    fulfillment_datetime = Column(DateTime)

    __table_args__ = (
        PrimaryKeyConstraint("order_id", "store_id", "product_id"),
        Index("idx_orders_order_id", "order_id"),
        Index("idx_orders_store_id", "store_id"),
        Index("idx_order_created_at", "order_created_at"),
    )


# Assortment
class Bounce(Base):
    __tablename__ = "bounce"

    store_id = Column(String, primary_key=True)
    product_id = Column(String, primary_key=True)
    timestamp = Column(DateTime, primary_key=True)
    number_of_bounce = Column(Float)

    __table_args__ = (
        PrimaryKeyConstraint("store_id", "product_id", "timestamp"),
        Index("idx_bounce_store_id", "store_id"),
        Index("idx_bounce_product_id", "product_id"),
        Index("idx_bounce_timestamp", "timestamp"),
    )


class MarketResearchAnalysis(Base):
    __tablename__ = "market_research_analysis"

    ranking_level = Column(String, primary_key=True)
    l0 = Column(String, primary_key=True)
    l1 = Column(String, primary_key=True)
    l2 = Column(String, primary_key=True)
    l3 = Column(String, primary_key=True)
    product_id = Column(String, primary_key=True)
    product_name = Column(String)
    company = Column(String)
    brand_name = Column(String)
    region = Column(String)
    revenue = Column(Float)
    internal_level_rank = Column(Integer)

    aiocd_revenue = Column(Float)
    aiocd_fraction_revenue = Column(Float)
    aiocd_level_rank = Column(Integer)

    iqvia_revenue = Column(Float)
    fraction_revenue = Column(Float)
    iqvia_level_rank = Column(Integer)

class IQVIAResearchAnalysis(Base):
    __tablename__ = "iqvia_research_analysis"

    ranking_level = Column(String, primary_key=True)
    l0 = Column(String, primary_key=True)
    l1 = Column(String, primary_key=True)
    l2 = Column(String, primary_key=True)
    l3 = Column(String, primary_key=True)
    product_id = Column(String, primary_key=True)
    product_name = Column(String)
    brand_name = Column(String)
    region = Column(String)
    revenue = Column(Float)
    internal_level_rank = Column(Integer)

    iqvia_revenue = Column(Float)
    fraction_revenue = Column(Float)
    iqvia_level_rank = Column(Integer)

class AIOCDResearchAnalysis(Base):
    __tablename__ = "aiocd_research_analysis"

    ranking_level = Column(String, primary_key=True)
    l0 = Column(String, primary_key=True)
    l1 = Column(String, primary_key=True)
    l2 = Column(String, primary_key=True)
    l3 = Column(String, primary_key=True)
    product_id = Column(String, primary_key=True)
    product_name = Column(String)
    company = Column(String)
    brand_name = Column(String)
    # region = Column(String)
    revenue = Column(Float)
    internal_level_rank = Column(Integer)

    aiocd_revenue = Column(Float)
    aiocd_fraction_revenue = Column(Float)
    aiocd_level_rank = Column(Integer)

# FMCG
class BayAllocationCategory(Base):
    __tablename__ = "bay_allocation_cat"

    id = Column(Integer, primary_key=True, autoincrement=True)
    total_bays = Column(Integer)
    staples = Column(Integer)
    beverage = Column(Integer)
    c_and_s = Column(Integer)
    dairy = Column(Integer)
    bakery = Column(Integer)
    personal_care = Column(Integer)
    home_care = Column(Integer)
    gm = Column(Integer)
    digital = Column(Integer)
    flex_beauty = Column(Integer)


# class FMCGMatketResearchAnalysis(Base):
#     __tablename__ = "fmcg_market"

#     timestamp = Column(DateTime, primary_key=True)
#     brand_name = Column(String, primary_key=True)
#     l0 = Column(String, primary_key=True)
#     l1 = Column(String, primary_key=True)
#     l2 = Column(String, primary_key=True)
#     l3 = Column(String, primary_key=True)
#     company = Column(String)
#     net_amount = Column(Float)
#     region = Column(String)
