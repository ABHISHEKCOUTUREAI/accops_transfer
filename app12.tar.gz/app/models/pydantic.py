from datetime import datetime
from typing import Literal, Optional, Union

from pydantic import BaseModel


class L0Response(BaseModel):
    l0: str
    count: int


class L1Response(BaseModel):
    l1: str
    count: int


class L2Response(BaseModel):
    l2: str
    count: int


class L3Response(BaseModel):
    l3: str
    count: int


class CategoryDistributionResponse(BaseModel):
    l0_data: list[L0Response]
    l1_data: list[L1Response]
    l2_data: list[L2Response]
    l3_data: list[L3Response]


class CategoryTreeMapBase(BaseModel):
    category: str
    value: int


class CategoryTreeMapResponse(BaseModel):
    category: str
    value: int
    children: list[CategoryTreeMapBase]


class CriticalLowStockResponse(BaseModel):
    category: str
    total_deficit: int


class Item(BaseModel):
    store_id: str
    product_id: str
    quantity: int


class Sort(BaseModel):
    field: str
    order: Literal["asc", "desc"]


class SearchFilter(BaseModel):
    id: str
    type: str = "search"
    query: str


class RangeFilter(BaseModel):
    id: str
    type: str = "range"
    min: Optional[Union[int, datetime]] = None
    max: Optional[Union[int, datetime]] = None


class DiscreteFilter(BaseModel):
    id: str
    type: str = "discrete"
    queries: list[str]


class RequestBody(BaseModel):
    page_no: int = 1
    page_count: int = 20
    sort: Optional[Sort] = None
    filters: Optional[list[Union[SearchFilter, RangeFilter, DiscreteFilter]]] = []


class CartRequest(RequestBody):
    store_id: str


class CartItem(BaseModel):
    product_id: str
    quantity: int
    product_name: str
    description: str
    l0: str
    l3: str
    price: float
    min_qty: int
    max_qty: int
    stock_quantity: int
    minimum_replenishment: int
    status_label: Literal[
        "0_new", "1_replenish", "2_no_replenishment", "8_dead", "9_excess", "other"
    ]


class CartResponse(BaseModel):
    total_cart_value: float
    total_cart_width: int
    total_count: int
    cart_coverage_by_value: float
    cart_coverage_by_items: float
    items: list[CartItem]


class OrdersRequest(RequestBody):
    store_id: str
    globalSearch: Optional[str] = ""


class OrderResponseProduct(BaseModel):
    product_id: str
    product_name: str


class OrdersResponseChild(BaseModel):
    order_id: str
    ordered_at: Optional[datetime] = ""
    fulfilled_at: Optional[datetime] = None
    order_status: Optional[str] = ""
    products: list[OrderResponseProduct] = []
    total_products: int


class OrderResponse(BaseModel):
    total_count: int
    items: Optional[list[OrdersResponseChild]] = []


class ProductResponseChild(BaseModel):
    product_id: str
    product_name: str
    description: Optional[str] = ""
    price: float
    ordered_quantity: int


class ProductResponse(BaseModel):
    count: Optional[int] = 0
    order_status: Optional[str] = None
    ordered_at: Optional[datetime] = None
    fulfilled_at: Optional[datetime] = None
    total_order_value: Optional[float] = 0
    products: Optional[list[ProductResponseChild]] = None


class ProductRequest(RequestBody):
    order_id: str
    globalSearch: Optional[str] = ""


class AutocompleteProductRequest(BaseModel):
    query: str
    page_no: int
    page_count: int


class AutocompleteProductResponseChild(BaseModel):
    product_id: str
    product_name: str


class AutocompleteProductResponse(BaseModel):
    total_count: int
    products: list[AutocompleteProductResponseChild]


class ProductDemandRequest(BaseModel):
    store_id: str
    num_products: int
    sort: Optional[Sort] = None
    filters: Optional[list[Union[SearchFilter, RangeFilter, DiscreteFilter]]] = []
    globalSearch: Optional[str] = ""


class ProductDemandResponse(BaseModel):
    product_id: str
    product_name: str
    items_sold_last_week: Optional[int]
    items_sold_this_week: Optional[int]
    l0: Optional[str]
    l3: Optional[str]
    recommended_replenishment: Optional[int]
    percentage_change: Optional[float]
    ordered_quantity: Optional[int]
    cart_quantity: Optional[int]


class ReplenishmentNotificationResponse(BaseModel):
    product_id: str
    product_name: str
    replenishment: int


class SurgetNotificationResponse(BaseModel):
    product_id: str
    product_name: str
    percentage_change: float


class NotificationResponse(BaseModel):
    replenishment: list[ReplenishmentNotificationResponse]
    surge: list[SurgetNotificationResponse]


class ReplenishmentNotificationRequest(BaseModel):
    store_id: str
    num_products: int


class PageDetails(BaseModel):
    page_no: int
    page_count: int


class BaseFilter(BaseModel):
    sort: Optional[Sort] = None
    filters: Optional[list[Union[SearchFilter, RangeFilter, DiscreteFilter]]] = []
    globalSearch: Optional[str] = ""


class StoreAssortmentRequest(PageDetails, BaseFilter):
    store_id: str
    l0: Optional[str] = None
    l1: Optional[str] = None
    l2: Optional[str] = None
    l3: Optional[str] = None
    mfac_name: Optional[str] = None
    brand_name: Optional[str] = None


class StoreAssortmentResponseChild(BaseModel):
    product_id: str
    product_name: str
    description: str
    l0: str
    l3: str
    price: float
    min_qty: int
    max_qty: int
    cart_quantity: int
    order_quantity: int
    minimum_replenishment: int
    status_label: Literal[
        "0_new", "1_replenish", "2_no_replenishment", "8_dead", "9_excess", "other"
    ]


class StoreAssortmentResponse(BaseModel):
    assortment_count: int
    assortment: list[StoreAssortmentResponseChild]
    new_count: int = 0
    replenish_count: int = 0
    optimal_count: int = 0
    excess_count: int = 0
    inhand_inventory_cost: float = 0
    inhand_assortment_width: int = 0
    recommended_inventory_cost: float = 0
    recommended_assortment_width: int = 0


class MarketResearchRequest(BaseModel):
    ranking_level: Optional[str] = None
    l0: Optional[str] = None
    l1: Optional[str] = None
    l2: Optional[str] = None
    l3: Optional[str] = None
    sap_id: Optional[str] = None
    page_no: int = 1
    page_size: int = 100
    sort_param: str = "revenue"
    sort_type: str = "desc"
    flag: bool = True
    ranking_type: str = "iqvia"


class HitMissRequest(StoreAssortmentRequest):
    hit_miss: Optional[str] = None


class HitMissResponseChild(BaseModel):
    current_inventory: int
    num_qty_sold: int
    total_amount: float
    total_margin: float
    product_id: str
    product_name: str
    description: str
    l0: str
    l3: str
    price: float
    min_qty: int
    max_qty: int
    minimum_replenishment: int
    status_label: Literal[
        "0_new", "1_replenish", "2_no_replenishment", "8_dead", "9_excess", "other"
    ]


class HitMissResponse(BaseModel):
    count: int
    assortment: list[HitMissResponseChild]
