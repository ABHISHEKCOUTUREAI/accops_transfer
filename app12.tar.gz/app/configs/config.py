from models import AIOCDResearchAnalysis, IQVIAResearchAnalysis, Product

config = {
    "market_research": {
        "iqvia": {
            "select": {
                "table": IQVIAResearchAnalysis,
                "columns": [
                    ("l0", "l0"),
                    ("l1", "l1"),
                    ("l2", "l2"),
                    ("l3", "l3"),
                    ("ranking_level", "ranking_level"),
                    ("product_id", "product_id"),
                    ("internal_level_rank", "internal_level_rank"),
                ],
                "filter": [
                    ("l0", "l0"),
                    ("l1", "l1"),
                    ("l2", "l2"),
                    ("l3", "l3"),
                    ("ranking_level", "ranking_level"),
                    ("product_id", "sap_id"),
                ],
            },
            "join": [
                # (Product, )
            ],
            "count_on": "product_id",
            "return_columns": [
                "l1",
                "l0",
                "l2",
                "l3",
                "product_id",
                "internal_level_rank",
            ],
            "skip_rounding": ["product_id"],
        },
        "aiocd": {
            "select": {
                "table": AIOCDResearchAnalysis,
                "columns": [
                    ("l0", "l0"),
                    ("l1", "l1"),
                    ("l2", "l2"),
                    ("ranking_level", "ranking_level"),
                    ("product_id", "product_id"),
                    ("internal_level_rank", "internal_level_rank"),
                ],
                "filter": [
                    ("l0", "l0"),
                    ("l1", "l1"),
                    ("l2", "l2"),
                    ("l3", "l3"),
                    ("ranking_level", "ranking_level"),
                    ("product_id", "sap_id"),
                ],
            },
            "join": [
                {
                    "table": Product,
                    "join_condition": [
                        (Product, "l0", "l0"),
                        (Product, "l1", "l1"),
                        (Product, "l2", "l2"),
                    ],
                    "columns": [("product_id", "sap_id")],
                    "filter": [],
                    "outer": True,
                }
            ],
            "count_on": "product_id",
            "return_columns": ["l1", "l0", "l2", "product_id", "internal_level_rank"],
            "skip_rounding": ["product_id"],
        },
    },
    # assortment api
    "assortment": {
        "product": {
            "columns": [
                ("l0", "l0"),
                ("product_name", "product_name"),
                ("price", "price"),
                ("l3", "l3"),
                ("product_id", "product_id"),
                ("description", "description"),
            ],
        },
        "assortment": {
            "columns": [
                ("min_qty", "min_qty"),
                ("max_qty", "max_qty"),
                ("is_new_product", "is_new_product"),
                ("det_cogs", "det_cogs"),
                ("exist_in_baseline_output", "exist_in_baseline_output"),
                ("exist_in_model_output", "exist_in_model_output"),
                ("store_id", "store_id"),
                ("is_sold", "is_sold"),
            ],
        },
        "assortment_product_join": [("product_id", "product_id")],
        "count_on": "product_id",
        "return_columns": [
            "product_id",
            "product_name",
            "description",
            "l0",
            "l3",
            "price",
            "min_qty",
            "max_qty",
            # "minimum_replenishment",
            # "status_label",
            # 'cart_quantity',
            "order_quantity",
        ],
        "order": True,
        "cart": False,
        "inventory": False,
        "status": False,
        "overall_count": False,
    },
    "hit_miss": {
        "product": {
            "columns": [
                ("l0", "l0"),
                ("product_name", "product_name"),
                ("price", "price"),
                ("l3", "l3"),
                ("product_id", "product_id"),
                ("description", "description"),
            ],
        },
        "assortment": {
            "columns": [
                ("min_qty", "min_qty"),
                ("max_qty", "max_qty"),
                ("is_new_product", "is_new_product"),
                ("det_cogs", "det_cogs"),
                ("exist_in_baseline_output", "exist_in_baseline_output"),
                ("exist_in_model_output", "exist_in_model_output"),
                ("store_id", "store_id"),
                ("is_sold", "is_sold"),
            ],
        },
        "assortment_product_join": [
            ("product_id", "product_id"),
        ],
        "count_on": "product_id",
        "return_columns": [
            "product_id",
            "product_name",
            "description",
            "l0",
            "l3",
            "price",
            "min_qty",
            "max_qty",
            "minimum_replenishment",
            "status_label",
            "current_inventory",
            "num_qty_sold",
            "total_amount",
            "total_margin",
            "order_quantity",
            "cart_quantity",
        ],
        "order": True,
        "cart": True,
        "inventory": True,
        "sales": True,
    },
}
