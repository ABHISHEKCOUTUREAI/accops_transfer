from db import psql_execute_multiple, psql_execute_single
from fastapi import APIRouter
from models import AjioBrickDetails, AjioProductAttributes, SearchInteractions
from sqlalchemy.sql import func, select

SearchInteractionRouter = APIRouter(
    tags=["Google Search Interaction"],
    responses={404: {"description": "Not found"}},
)


async def get_products_by_category_query(category):
    query = (
        select(
            AjioBrickDetails.brickname,
            AjioProductAttributes.brandname,
            AjioProductAttributes.imgcode,
            AjioProductAttributes.productid,
        )
        .join(
            AjioBrickDetails,
            AjioBrickDetails.similargrouplevel
            == AjioProductAttributes.similargrouplevel,
        )
        .where(AjioBrickDetails.brickname == category.category)
        .limit(5)
    )

    return query


@SearchInteractionRouter.post("/top-search-interactions")
async def get_top_search_interactions(request_data: dict):
    # Define the query to fetch data from the database
    query = (
        select(
            SearchInteractions.category,
            func.array_agg(SearchInteractions.related_top_searches).label(
                "related_top_searches"
            ),
            func.array_agg(SearchInteractions.related_rising_searches).label(
                "related_rising_searches"
            ),
        ).group_by(SearchInteractions.category)  # Group by category
    )

    # count the total number of rows
    total_count_query = select(func.count()).select_from(query)
    count = await psql_execute_single(total_count_query)

    page_no = request_data.get("page_no", 1)
    page_count = request_data.get("page_count", 50)
    offset = (page_no - 1) * page_count
    query = query.limit(page_count).offset(offset)

    # Execute the query
    category_result = await psql_execute_single(query)

    category_map = {
        category.category: {
            "category": category.category,
            "related_top_searches": [
                search for search in category.related_top_searches if search is not None
            ],
            "related_rising_searches": [
                search
                for search in category.related_rising_searches
                if search is not None
            ],
            "products": [],
        }
        for category in category_result
    }

    product_by_category_query_list = []
    for category in category_result:
        product_by_category_query_list.append(
            await get_products_by_category_query(category)
        )

    # Execute all the queries at once
    product_results = await psql_execute_multiple(product_by_category_query_list)

    for product_row in product_results:
        for row in product_row:
            category = row.brickname
            product_data = {
                "brickname": row.brickname,
                "brandname": row.brandname,
                "imgcode": row.imgcode,
                "productid": row.productid,
            }
            category_map[category]["products"].append(product_data)

    # make a list and put all category_map values in it
    category_map = list(category_map.values())

    result = {"count": count[0][0], "data": category_map}

    return result
