import json

from db import check_in_redis, psql_execute_single, redis_db
from fastapi import APIRouter
from models import (
    TrendsBestSellersMonth,
    TrendsBestSellersWeek,
    TrendsStoreDetails,
)
from settings import settings
from sqlalchemy import func, select
from static import REDIS_CONNECT_ERROR, REDIS_WRITE_ERROR, indian_states
from utils import (
    get_attributes_bestsellers_trends,
    get_trends_bestseller_month_level,
    get_trends_bestseller_week_level,
    get_trends_filters_service,
)

TrendsRouter = APIRouter(
    prefix=settings.api_prefix,
    tags=["Trends"],
    responses={404: {"description": "Not found"}},
)


@TrendsRouter.post("/trends-filters")
async def get_trends_filters(request_data: dict):
    return await get_trends_filters_service(request_data, caching_flag=False)


@TrendsRouter.post("/bestsellers-products-trends")
async def bestsellers_products_trends(
    request_data: dict,
):
    cache_key = f"bestsellers-products-trends-{json.dumps(request_data)}"
    try:
        cached_data = await check_in_redis(cache_key)
    except Exception as e:
        print(REDIS_CONNECT_ERROR, e)
        cached_data = None
    if cached_data:
        return json.loads(cached_data)

    if request_data.get("nested_data", {}).get("duration", {}).get("week"):
        result = await get_trends_bestseller_week_level(request_data)
    else:
        result = await get_trends_bestseller_month_level(request_data)

    try:
        await redis_db.set(cache_key, json.dumps(result, default=str))
    except Exception as e:
        print(REDIS_WRITE_ERROR, e)

    return result


@TrendsRouter.post("/statewise-sales-trends")
async def get_statewise_sales(
    request_data: dict,
):
    cache_key = f"statewise-sales-{json.dumps(request_data)}"
    try:
        cached_data = await check_in_redis(cache_key)
    except Exception as e:
        print(REDIS_CONNECT_ERROR, e)
        cached_data = None
    if cached_data:
        return json.loads(cached_data)

    if request_data.get("nested_data", {}).get("duration", {}).get("week"):
        best_sellers_schema = TrendsBestSellersWeek
        quantity_column = TrendsBestSellersWeek.sold_quantity_in_a_week
    else:
        best_sellers_schema = TrendsBestSellersMonth
        quantity_column = TrendsBestSellersMonth.sold_quantity_in_a_month

    sold_in_week_query = (
        select(
            TrendsStoreDetails.state,
            func.sum(quantity_column).label("quantity"),
        )
        .join(
            TrendsStoreDetails,
            TrendsStoreDetails.store_id == best_sellers_schema.store_id,
        )
        .group_by(TrendsStoreDetails.state)
    )

    maps_rows_state = await psql_execute_single(sold_in_week_query)
    map_data = [
        {
            "state": row[0],
            "statecode": indian_states.get(row[0].lower(), {}).get(
                "statecode", "Not Found"
            ),
            "quantity_sold": float(row[1]),
        }
        for row in maps_rows_state
    ]

    try:
        await redis_db.set(cache_key, json.dumps(map_data, default=str))
    except Exception as e:
        print(REDIS_WRITE_ERROR, e)

    return map_data


@TrendsRouter.post("/fabric-bestsellers-trends")
async def get_fabric_bestsellers_trends(
    request_data: dict,
):
    cache_key = f"fabric-bestsellers-trends-{json.dumps(request_data)}"
    try:
        cached_data = await check_in_redis(cache_key)
    except Exception as e:
        print(REDIS_CONNECT_ERROR, e)
        cached_data = None
    if cached_data:
        return json.loads(cached_data)

    result = await get_attributes_bestsellers_trends(
        request_data,
        "fabrictype",
    )

    try:
        await redis_db.set(cache_key, json.dumps(result, default=str))
    except Exception as e:
        print(REDIS_WRITE_ERROR, e)

    return result


@TrendsRouter.post("/brandnames-bestsellers-trends")
async def brandnames_bestsellers_trends(
    request_data: dict,
):
    cache_key = f"brandnames-bestsellers-trends-{json.dumps(request_data)}"
    try:
        cached_data = await check_in_redis(cache_key)
    except Exception as e:
        print(REDIS_CONNECT_ERROR, e)
        cached_data = None
    if cached_data:
        return json.loads(cached_data)

    result = await get_attributes_bestsellers_trends(
        request_data,
        "brandname",
    )

    try:
        await redis_db.set(cache_key, json.dumps(result, default=str))
    except Exception as e:
        print(REDIS_WRITE_ERROR, e)

    return result


@TrendsRouter.post("/neckline-bestsellers-trends")
async def neckline_bestsellers_trends(
    request_data: dict,
):
    cache_key = f"neckline-bestsellers-trends-{json.dumps(request_data)}"
    try:
        cached_data = await check_in_redis(cache_key)
    except Exception as e:
        print(REDIS_CONNECT_ERROR, e)
        cached_data = None
    if cached_data:
        return json.loads(cached_data)

    result = await get_attributes_bestsellers_trends(
        request_data,
        "neckline",
    )

    try:
        await redis_db.set(cache_key, json.dumps(result, default=str))
    except Exception as e:
        print(REDIS_WRITE_ERROR, e)

    return result


@TrendsRouter.post("/styletype-bestsellers-trends")
async def styletype_bestsellers_trends(
    request_data: dict,
):
    cache_key = f"styletype-bestsellers-trends-{json.dumps(request_data)}"
    try:
        cached_data = await check_in_redis(cache_key)
    except Exception as e:
        print(REDIS_CONNECT_ERROR, e)
        cached_data = None
    if cached_data:
        return json.loads(cached_data)

    result = await get_attributes_bestsellers_trends(
        request_data,
        "styletype",
    )

    try:
        await redis_db.set(cache_key, json.dumps(result, default=str))
    except Exception as e:
        print(REDIS_WRITE_ERROR, e)

    return result


@TrendsRouter.post("/sleevelength-bestsellers-trends")
async def sleevelength_bestsellers_trends(
    request_data: dict,
):
    cache_key = f"sleevelength-bestsellers-trends-{json.dumps(request_data)}"
    try:
        cached_data = await check_in_redis(cache_key)
    except Exception as e:
        print(REDIS_CONNECT_ERROR, e)
        cached_data = None
    if cached_data:
        return json.loads(cached_data)

    result = await get_attributes_bestsellers_trends(
        request_data,
        "sleeve",
    )

    try:
        await redis_db.set(cache_key, json.dumps(result, default=str))
    except Exception as e:
        print(REDIS_WRITE_ERROR, e)

    return result


@TrendsRouter.post("/pattern-bestsellers-trends")
async def pattern_bestsellers_trends(
    request_data: dict,
):
    cache_key = f"pattern-bestsellers-trends-{json.dumps(request_data)}"
    try:
        cached_data = await check_in_redis(cache_key)
    except Exception as e:
        print(REDIS_CONNECT_ERROR, e)
        cached_data = None
    if cached_data:
        return json.loads(cached_data)

    result = await get_attributes_bestsellers_trends(
        request_data,
        "pattern",
    )

    try:
        await redis_db.set(cache_key, json.dumps(result, default=str))
    except Exception as e:
        print(REDIS_WRITE_ERROR, e)

    return result


@TrendsRouter.post("/color-bestsellers-trends")
async def color_bestsellers_trends(
    request_data: dict,
):
    cache_key = f"color-bestsellers-trends-{json.dumps(request_data)}"
    cached_data = await check_in_redis(cache_key)
    try:
        cached_data = await check_in_redis(cache_key)
    except Exception as e:
        print(REDIS_CONNECT_ERROR, e)
        cached_data = None
    if cached_data:
        return json.loads(cached_data)

    result = await get_attributes_bestsellers_trends(
        request_data,
        "primarycolor",
    )

    try:
        await redis_db.set(cache_key, json.dumps(result, default=str))
    except Exception as e:
        print(REDIS_WRITE_ERROR, e)

    return result
