from sqlalchemy import Column, Integer, String
from sqlalchemy.ext.declarative import declarative_base

Base = declarative_base()


class CombinedSearchTermsWeeksResponse(Base):
    __tablename__ = "combined_search_terms_weeks"
    normalized_search_term = Column(String, primary_key=True)
    week_of_year = Column(Integer, primary_key=True)
