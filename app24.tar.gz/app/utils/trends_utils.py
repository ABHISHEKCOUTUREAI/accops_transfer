import asyncio
import json
from collections import defaultdict

from db import check_in_redis, psql_execute_multiple, psql_execute_single, redis_db
from models import (
    TrendsBestSellersMonth,
    TrendsBestSellersWeek,
    TrendsBrickDetails,
    TrendsProductAttributes,
    TrendsStoreDetails,
)
from sqlalchemy import Numeric, and_, cast, func, select
from static import REDIS_WRITE_ERROR, month_mapping

from .api_contract_utils import calculate_time_delta
from .common_utils import (
    build_filter_condition,
    select_filter_subquery,
    sort_and_paginate,
)


async def get_trends_filters_service(
    request_data: dict,
    caching_flag: bool = False,
):
    cache_key = f"trends_filters{json.dumps(request_data)}"
    cached_data = await check_in_redis(cache_key)
    if cached_data:
        return json.loads(cached_data)

    query = await create_trends_filter_query(request_data)
    result = await psql_execute_single(query)
    response = await create_trends_filters_response(result, request_data)

    try:
        await redis_db.set(cache_key, json.dumps(response, default=str))
    except Exception as e:
        print(REDIS_WRITE_ERROR, e)

    if caching_flag:
        print("Trends filters loaded successfully")
    else:
        return response


async def create_trends_filters_response(result, request_data):
    def filter_non_null(result, index):
        values = list(
            set(
                val[index]
                for val in result
                if val[index] != "nan" and val[index] is not None
            )
        )
        return sorted(values)

    categories = {
        "demographic": {"zone_desc": 1, "state": 2, "city": 3, "district": 4},
        "category": {"category_family": 7, "category_class": 8, "category": 9},
        "attributes": {
            "styletype": 10,
            "neckline": 11,
            "pattern": 12,
            "fabric_type": 13,
            "sleeve": 14,
            "fit": 15,
            "color": 16,
            "brandname": 17,
        },
        "store_filters": {"pincode": 5, "store_id": 6},
    }

    response = {
        category: {key: filter_non_null(result, idx) for key, idx in keys.items()}
        for category, keys in categories.items()
    }

    cache_key_min_max = "min_max_bestseller_week_trends"
    min_max_week = await redis_db.get(cache_key_min_max)
    if min_max_week:
        min_week, max_week = json.loads(min_max_week)
    else:
        await calculate_time_delta_week_trends()
        min_max_week = await redis_db.get(cache_key_min_max)
        min_week, max_week = json.loads(min_max_week)

    if request_data.get("nested_data", {}).get("duration", {}).get("week"):
        response["duration"] = {
            "months": [],
            "week": list(range(min_week, max_week + 1)),
        }
    else:
        response["duration"] = {
            "month": list(
                {month_mapping[val[0]] for val in result if val[0] not in ["nan", None]}
            ),
            "week": list(range(min_week, max_week + 1)),
        }

    return response


async def get_attributes_bestsellers_trends(request_data, attribute: str):
    # Determine which schema to use based on the presence of "week" in the request data
    if request_data.get("nested_data", {}).get("duration", {}).get("week"):
        duration_filter_flag = "bestsellers_week"
        best_sellers_schema = TrendsBestSellersWeek
        quantity_column = TrendsBestSellersWeek.sold_quantity_in_a_week
    else:
        duration_filter_flag = "bestsellers_month"
        best_sellers_schema = TrendsBestSellersMonth
        quantity_column = TrendsBestSellersMonth.sold_quantity_in_a_month

    (
        product_filter,
        brick_filter,
        duration_filter,
        demographic_filter,
    ) = await asyncio.gather(
        build_filter_condition(
            type="trends", request_filters=request_data, filter_flag="products"
        ),
        build_filter_condition(
            type="trends", request_filters=request_data, filter_flag="category"
        ),
        build_filter_condition(
            type="trends",
            request_filters=request_data,
            filter_flag=duration_filter_flag,
        ),
        build_filter_condition(
            type="trends", request_filters=request_data, filter_flag="store_filters"
        ),
    )

    product_query = (
        select(
            getattr(TrendsProductAttributes, attribute),
            TrendsProductAttributes.itemid,
            TrendsProductAttributes.similargrouplevel,
        )
        .where(
            and_(
                *product_filter, getattr(TrendsProductAttributes, attribute) is not None
            )
        )
        .subquery()
    )

    brick_query = (
        select(TrendsBrickDetails.brickname, TrendsBrickDetails.similargrouplevel)
        .where(and_(*brick_filter))
        .subquery()
    )

    sold_in_week_query = (
        select(
            quantity_column.label("quantity_column"),
            best_sellers_schema.itemid,
            best_sellers_schema.store_id,
        )
        .where(and_(*duration_filter))
        .subquery()
    )

    store_query = (
        select(
            TrendsStoreDetails.store_id,
        )
        .where(and_(*demographic_filter))
        .subquery()
    )

    # join all three queries
    query = (
        select(
            getattr(product_query.c, attribute),
            brick_query.c.brickname,
            func.sum(sold_in_week_query.c.quantity_column).label("quantity"),
        )
        .join(
            brick_query,
            product_query.c.similargrouplevel == brick_query.c.similargrouplevel,
        )
        .join(sold_in_week_query, product_query.c.itemid == sold_in_week_query.c.itemid)
        .join(store_query, sold_in_week_query.c.store_id == store_query.c.store_id)
        .group_by(
            getattr(product_query.c, attribute),
            brick_query.c.brickname,
        )
        .order_by(func.sum(sold_in_week_query.c.quantity_column).desc())
    )

    rows = await psql_execute_single(query)
    result = defaultdict(dict)
    for row in rows:
        if row[0] and row[0] != "nan":
            result[row[1]][row[0]] = float(row[2])

    return result


async def calculate_time_delta_week_trends():
    cache_key = "min_max_bestseller_week_trends"
    cached_data = await redis_db.get(cache_key)
    if not cached_data:
        week_query = select(
            func.max(TrendsBestSellersWeek.week_of_year)
        )
        week_result = await psql_execute_single(week_query)
        max_week = week_result[0][0]

        # Query to select the minimum week from the database
        min_week_query = select(
            func.min(TrendsBestSellersWeek.week_of_year)
        )
        min_week_result = await psql_execute_single(min_week_query)
        min_week = min_week_result[0][0]

        await redis_db.set(cache_key, json.dumps([min_week, max_week]))

    print("time-delta loaded")

async def create_trends_filter_query(request_data):
    # Determine the appropriate filter flag based on the presence of 'week' in the request data
    if request_data.get("nested_data", {}).get("duration", {}).get("week"):
        duration_filter_flag = "bestsellers_week"
        best_seller_schema = TrendsBestSellersWeek
        duration_columns = ["week_of_year", "itemid", "store_id"]
    else:
        duration_filter_flag = "bestsellers_month"
        best_seller_schema = TrendsBestSellersMonth
        duration_columns = ["month_of_year", "itemid", "store_id"]

    duration_filter, store_filter, brick_filter, product_filter = await asyncio.gather(
        build_filter_condition(
            type="trends",
            request_filters=request_data,
            filter_flag=duration_filter_flag,
        ),
        build_filter_condition(
            type="trends", request_filters=request_data, filter_flag="store_filters"
        ),
        build_filter_condition(
            type="trends", request_filters=request_data, filter_flag="category"
        ),
        build_filter_condition(
            type="trends", request_filters=request_data, filter_flag="products"
        ),
    )

    store_columns = [
        "zone_desc",
        "state",
        "city",
        "districtsname",
        "pin_code",
        "store_id",
    ]
    brick_columns = [
        "mh_family_desc",
        "mh_class_desc",
        "brickname",
        "similargrouplevel",
    ]
    product_columns = [
        "similargrouplevel",
        "itemid",
        "styletype",
        "neckline",
        "pattern",
        "fabrictype",
        "sleeve",
        "fit",
        "primarycolor",
        "brandname",
    ]

    duration_query, store_query, brick_query, product_query = await asyncio.gather(
        select_filter_subquery(
            best_seller_schema, list(duration_filter), duration_columns
        ),
        select_filter_subquery(TrendsStoreDetails, list(store_filter), store_columns),
        select_filter_subquery(TrendsBrickDetails, list(brick_filter), brick_columns),
        select_filter_subquery(
            TrendsProductAttributes, list(product_filter), product_columns
        ),
    )

    query = (
        select(
            getattr(duration_query.c, duration_columns[0]),
            store_query.c.zone_desc,
            store_query.c.state,
            store_query.c.city,
            store_query.c.districtsname,
            store_query.c.pin_code,
            store_query.c.store_id,
            brick_query.c.mh_family_desc,
            brick_query.c.mh_class_desc,
            brick_query.c.brickname,
            product_query.c.styletype,
            product_query.c.neckline,
            product_query.c.pattern,
            product_query.c.fabrictype,
            product_query.c.sleeve,
            product_query.c.fit,
            product_query.c.primarycolor,
            product_query.c.brandname,
        )
        .join(store_query, duration_query.c.store_id == store_query.c.store_id)
        .join(product_query, product_query.c.itemid == duration_query.c.itemid)
        .join(
            brick_query,
            brick_query.c.similargrouplevel == product_query.c.similargrouplevel,
        )
    )

    return query


async def get_trends_bestseller_week_level(request_data: dict):
    (
        bestseller_filter,
        product_filter,
        store_filter,
        brick_filter,
    ) = await asyncio.gather(
        build_filter_condition(
            type="trends", request_filters=request_data, filter_flag="bestsellers_week"
        ),
        build_filter_condition(
            type="trends", request_filters=request_data, filter_flag="products"
        ),
        build_filter_condition(
            type="trends", request_filters=request_data, filter_flag="store_filters"
        ),
        build_filter_condition(
            type="trends", request_filters=request_data, filter_flag="category"
        ),
    )

    bestseller_query = (
        select(
            TrendsBestSellersWeek.itemid,
            TrendsBestSellersWeek.week_of_year,
            TrendsBestSellersWeek.year,
            TrendsBestSellersWeek.store_id,
            TrendsBestSellersWeek.sold_quantity_in_a_week,
            TrendsBestSellersWeek.healthy_live_days_in_a_week,
        )
        .where(and_(*bestseller_filter))
        .subquery()
    )

    store_query = (
        select(
            TrendsStoreDetails.store_id,
        )
        .where(and_(*store_filter))
        .subquery()
    )

    ros_query = (
        select(
            bestseller_query.c.itemid,
            bestseller_query.c.week_of_year,
            bestseller_query.c.year,
            func.sum(bestseller_query.c.sold_quantity_in_a_week).label(
                "sold_quantity_across_each_week"
            ),
            func.avg(bestseller_query.c.healthy_live_days_in_a_week).label(
                "total_days_count_across_week"
            ),
        )
        .join(store_query, store_query.c.store_id == bestseller_query.c.store_id)
        .group_by(
            bestseller_query.c.itemid,
            bestseller_query.c.week_of_year,
            bestseller_query.c.year,
        )
        .subquery()
    )

    ros_query = (
        select(
            ros_query.c.itemid,
            ros_query.c.year,
            func.sum(ros_query.c.sold_quantity_across_each_week).label(
                "total_sold_quantity"
            ),
            func.round(
                cast(
                    (
                        (
                            func.sum(ros_query.c.sold_quantity_across_each_week)
                            / func.sum(ros_query.c.total_days_count_across_week)
                        )
                        * 7
                    ),
                    Numeric,
                ),
                2,
            ).label("weekly_rate_of_sale"),
        )
        .group_by(ros_query.c.itemid, ros_query.c.year)
        .subquery()
    )

    product_query = (
        select(
            TrendsProductAttributes.itemid,
            TrendsProductAttributes.brandname,
            TrendsProductAttributes.styletype,
            TrendsProductAttributes.primarycolor,
            TrendsProductAttributes.pattern,
            TrendsProductAttributes.fabrictype,
            TrendsProductAttributes.materialtype,
            TrendsProductAttributes.sleeve,
            TrendsProductAttributes.fit,
            TrendsProductAttributes.neckline,
            TrendsProductAttributes.imgcode,
            TrendsProductAttributes.extension,
            TrendsProductAttributes.mrp,
            TrendsProductAttributes.similargrouplevel,
        )
        .where(and_(*product_filter))
        .subquery()
    )

    brick_query = (
        select(
            TrendsBrickDetails.mh_family_desc,
            TrendsBrickDetails.mh_class_desc,
            TrendsBrickDetails.brickname,
            TrendsBrickDetails.similargrouplevel,
        )
        .where(and_(*brick_filter))
        .subquery()
    )

    query = (
        select(
            product_query.c.itemid,
            product_query.c.brandname,
            product_query.c.styletype,
            product_query.c.primarycolor,
            product_query.c.pattern,
            product_query.c.fabrictype,
            product_query.c.materialtype,
            product_query.c.sleeve,
            product_query.c.fit,
            product_query.c.neckline,
            product_query.c.imgcode,
            product_query.c.extension,
            brick_query.c.mh_family_desc,
            brick_query.c.mh_class_desc,
            brick_query.c.brickname,
            product_query.c.mrp,
            ros_query.c.total_sold_quantity,
            ros_query.c.weekly_rate_of_sale,
        )
        .join(ros_query, ros_query.c.itemid == product_query.c.itemid)
        .join(
            brick_query,
            brick_query.c.similargrouplevel == product_query.c.similargrouplevel,
        )
    )
    # count the total number of rows
    total_count_query = select(func.count()).select_from(query)
    bestseller_query = await sort_and_paginate(
        query, request_data, "weekly_rate_of_sale"
    )

    query_list = [bestseller_query, total_count_query]

    result = await psql_execute_multiple(query_list)
    result = {
        "total_count": result[1][0][0],
        "rows": [
            {
                "itemid": row[0],
                "brandname": row[1],
                "styletype": row[2],
                "primarycolor": row[3],
                "pattern": row[4],
                "fabrictype": row[5],
                "materialtype": row[6],
                "sleeve": row[7],
                "fit": row[8],
                "neckline": row[9],
                "imgcode": row[10],
                "extension": row[11],
                "mh_family_desc": row[12],
                "mh_class_desc": row[13],
                "brickname": row[14],
                "mrp": round(float(row[15]), 2),
                "total_qty": round(float(row[16]), 2),
                "weekly_rate_of_sale": round(float(row[17]), 2),
            }
            for row in result[0]
        ],
    }
    return result


async def get_trends_bestseller_month_level(request_data: dict):
    (
        bestseller_filter,
        product_filter,
        store_filter,
        brick_filter,
    ) = await asyncio.gather(
        build_filter_condition(
            type="trends", request_filters=request_data, filter_flag="bestsellers_month"
        ),
        build_filter_condition(
            type="trends", request_filters=request_data, filter_flag="products"
        ),
        build_filter_condition(
            type="trends", request_filters=request_data, filter_flag="store_filters"
        ),
        build_filter_condition(
            type="trends", request_filters=request_data, filter_flag="category"
        ),
    )

    bestseller_query = (
        select(
            TrendsBestSellersMonth.itemid,
            TrendsBestSellersMonth.month_of_year,
            TrendsBestSellersMonth.year,
            TrendsBestSellersMonth.store_id,
            TrendsBestSellersMonth.sold_quantity_in_a_month,
            TrendsBestSellersMonth.healthy_live_days_in_a_month,
        )
        .where(and_(*bestseller_filter))
        .subquery()
    )

    store_query = (
        select(
            TrendsStoreDetails.store_id,
        )
        .where(and_(*store_filter))
        .subquery()
    )

    ros_query = (
        select(
            bestseller_query.c.itemid,
            bestseller_query.c.month_of_year,
            bestseller_query.c.year,
            func.sum(bestseller_query.c.sold_quantity_in_a_month).label(
                "sold_quantity_across_each_month"
            ),
            func.avg(bestseller_query.c.healthy_live_days_in_a_month).label(
                "total_days_count_across_month"
            ),
        )
        .join(store_query, store_query.c.store_id == bestseller_query.c.store_id)
        .group_by(
            bestseller_query.c.itemid,
            bestseller_query.c.month_of_year,
            bestseller_query.c.year,
        )
        .subquery()
    )

    ros_query = (
        select(
            ros_query.c.itemid,
            ros_query.c.year,
            func.sum(ros_query.c.sold_quantity_across_each_month).label(
                "total_sold_quantity"
            ),
            func.round(
                cast(
                    (
                        (
                            func.sum(ros_query.c.sold_quantity_across_each_month)
                            / func.sum(ros_query.c.total_days_count_across_month)
                        )
                        * 7
                    ),
                    Numeric,
                ),
                2,
            ).label("weekly_rate_of_sale"),
        )
        .group_by(ros_query.c.itemid, ros_query.c.year)
        .subquery()
    )

    product_query = (
        select(
            TrendsProductAttributes.itemid,
            TrendsProductAttributes.brandname,
            TrendsProductAttributes.styletype,
            TrendsProductAttributes.primarycolor,
            TrendsProductAttributes.pattern,
            TrendsProductAttributes.fabrictype,
            TrendsProductAttributes.materialtype,
            TrendsProductAttributes.sleeve,
            TrendsProductAttributes.fit,
            TrendsProductAttributes.neckline,
            TrendsProductAttributes.imgcode,
            TrendsProductAttributes.extension,
            TrendsProductAttributes.mrp,
            TrendsProductAttributes.similargrouplevel,
        )
        .where(and_(*product_filter))
        .subquery()
    )

    brick_query = (
        select(
            TrendsBrickDetails.mh_family_desc,
            TrendsBrickDetails.mh_class_desc,
            TrendsBrickDetails.brickname,
            TrendsBrickDetails.similargrouplevel,
        )
        .where(and_(*brick_filter))
        .subquery()
    )

    query = (
        select(
            product_query.c.itemid,
            product_query.c.brandname,
            product_query.c.styletype,
            product_query.c.primarycolor,
            product_query.c.pattern,
            product_query.c.fabrictype,
            product_query.c.materialtype,
            product_query.c.sleeve,
            product_query.c.fit,
            product_query.c.neckline,
            product_query.c.imgcode,
            product_query.c.extension,
            brick_query.c.mh_family_desc,
            brick_query.c.mh_class_desc,
            brick_query.c.brickname,
            product_query.c.mrp,
            ros_query.c.total_sold_quantity,
            ros_query.c.weekly_rate_of_sale,
        )
        .join(ros_query, ros_query.c.itemid == product_query.c.itemid)
        .join(
            brick_query,
            brick_query.c.similargrouplevel == product_query.c.similargrouplevel,
        )
    )
    # count the total number of rows
    total_count_query = select(func.count()).select_from(query)
    bestseller_query = await sort_and_paginate(
        query, request_data, "weekly_rate_of_sale"
    )

    query_list = [bestseller_query, total_count_query]

    result = await psql_execute_multiple(query_list)

    result = {
        "total_count": result[1][0][0],
        "rows": [
            {
                "itemid": row[0],
                "brandname": row[1],
                "styletype": row[2],
                "primarycolor": row[3],
                "pattern": row[4],
                "fabrictype": row[5],
                "materialtype": row[6],
                "sleeve": row[7],
                "fit": row[8],
                "neckline": row[9],
                "imgcode": row[10],
                "extension": row[11],
                "mh_family_desc": row[12],
                "mh_class_desc": row[13],
                "brickname": row[14],
                "mrp": round(float(row[15]), 2),
                "total_qty": round(float(row[16]), 2),
                "weekly_rate_of_sale": round(float(row[17]), 2),
            }
            for row in result[0]
        ],
    }
    return result
