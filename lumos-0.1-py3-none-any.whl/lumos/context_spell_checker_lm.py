import csv
import itertools
import json
import math
import os
import pickle
import re
import time
from collections import namedtuple
from heapq import nlargest
from pprint import pprint

import epitran
import fuzzy
import inflect
import jellyfish
import Levenshtein
import numpy as np
import pandas as pd
import torch
import unidecode
from nltk.corpus import stopwords
from nltk.stem import WordNetLemmatizer
from sklearn.preprocessing import MinMaxScaler
from symspellpy import SymSpell, Verbosity
from symspellpy.suggest_item import SuggestItem
from textblob import TextBlob, Word
from tqdm import tqdm
from transformers import AutoTokenizer, BertForMaskedLM

from lumos.utils import FunctionCache, MaxHeap, params_template, score_template

tqdm.pandas()

import logging

# Configure the logging settings
logging.basicConfig(
    level=logging.DEBUG, format="%(asctime)s - %(name)s - %(levelname)s - %(message)s"
)


class CustomSymSpell(SymSpell):
    def __init__(
        self,
        max_dictionary_edit_distance,
        symspell_prefix_length,
        min_word_freq,
        rightwords_path,
        phonetics_path,
        low_frequency_threshold=5,
    ):
        super().__init__()
        # self.min_word_freq = 100
        # self.max_dictionary_edit_distance = max_dictionary_edit_distance
        # self.symspell_prefix_length = 10
        self.low_frequency_threshold = 200
        self.phonetics_path = phonetics_path
        self.rightwords_path = rightwords_path
        self.sym_spell = SymSpell(
            max_dictionary_edit_distance=max_dictionary_edit_distance,
            prefix_length=symspell_prefix_length,
            count_threshold=min_word_freq - 1,
        )
        self.phonetic_sym_spell = SymSpell(
            max_dictionary_edit_distance=max_dictionary_edit_distance,
            prefix_length=symspell_prefix_length,
            count_threshold=min_word_freq - 1,
        )

        # self.sym_spell.load_pickle(model_path + os.sep + "model_dict.pkl")
        # ip_model_path = "/Users/meghana/Documents/separateModules/ContextSpellChecker/spell_checker_model_lm_old/rightwords_freq.txt"
        ip_model_path = rightwords_path
        # model_path = "/Users/meghana/Documents/separateModules/ContextSpellChecker/spell_checker_from_gpu_nb/model_dict.txt"
        self.sym_spell.load_dictionary(ip_model_path, term_index=0, count_index=1)
        # phonetic_model_path = "/Users/meghana/Documents/separateModules/ContextSpellChecker/data/IPA_old/concatenated_text_semicol.csv"
        # # phonetic_model_path = phonetics_path
        # file_path = phonetic_model_path
        # word_freq_dict = {}
        # with open(file_path, "r") as file:
        #     reader = csv.reader(file)
        #     for row in reader:
        #         word, freq = row[0], int(row[1])
        #         word_freq_dict[word] = freq
        # print("word_freq_dict", word_freq_dict)
        word_freq_dict = (
            pd.read_parquet(phonetics_path)[["ipa_code", "frequency"]]
            .set_index("ipa_code")["frequency"]
            .to_dict()
        )
        for word, freq in word_freq_dict.items():
            self.phonetic_sym_spell.create_dictionary_entry(word, freq)

    def custom_symspell_lookup(self, input_term):
        suggestions = []
        # Check if the input term is in the dictionary
        suggestion_count = self.sym_spell.words.get(input_term, 0)
        suggestions = self.sym_spell.lookup(
            input_term, Verbosity.ALL, include_unknown=True
        )
        # if suggestion_count > 0 and suggestion_count >= self.low_frequency_threshold:
        #     suggestions.append((input_term, suggestion_count))

        if (
            suggestion_count > 0
            and suggestion_count <= self.low_frequency_threshold
            and suggestion_count < 0
        ):
            # Remove the word temporarily
            self.sym_spell = self.sym_spell.delete_dictionary_entry(input_term)
            # Get suggestions
            suggestions = self.sym_spell.lookup(
                input_term, Verbosity.ALL, include_unknown=True
            )
            item = SuggestItem(term=input_term, distance=0, count=suggestion_count)
            suggestions.append(item)
            # if suggestion_count <= self.low_frequency_threshold:
            self.sym_spell = self.sym_spell.create_dictionary_entry(
                input_term, suggestion_count
            )

        return suggestions

    def phonetic_lookup(self, input_word):
        print("Inside phonetic lookup")
        epi = epitran.Epitran("eng-Latn")
        input_term = epi.transliterate(input_word)
        print(input_word, input_term)
        suggestion_count = self.phonetic_sym_spell.words.get(input_term, 0)
        suggestions = self.phonetic_sym_spell.lookup(
            input_term, Verbosity.ALL, include_unknown=True
        )
        # if suggestion_count > 0 and suggestion_count >= self.low_frequency_threshold:
        #     suggestions.append((input_term, suggestion_count))

        # if suggestion_count > 0 and  suggestion_count <= self.low_frequency_threshold and suggestion_count < 0:
        #     # Remove the word temporarily
        #     self.phonetic_sym_spell = self.phonetic_sym_spell.delete_dictionary_entry(input_term)
        #     # Get suggestions
        #     suggestions = self.phonetic_sym_spell.lookup(input_term, Verbosity.ALL, include_unknown=True)
        #     item = SuggestItem(term=input_term, distance=0, count=suggestion_count)
        #     suggestions.append(item)
        #     # if suggestion_count <= self.low_frequency_threshold:
        #     self.phonetic_sym_spell = self.phonetic_sym_spell.create_dictionary_entry(input_term, suggestion_count)
        # ipa_word = pd.read_parquet("/Users/meghana/Documents/separateModules/ContextSpellChecker/data/IPA_old/IPA_parquet/")
        ipa_word = pd.read_parquet(self.phonetics_path)
        suggestion_words = list(sug_i.term for sug_i in suggestions[:20])
        suggestion_items = list(
            [sug_i.term, sug_i.distance] for sug_i in suggestions[:20]
        )
        dict_outputs = {}
        for sug_i in suggestions[:20]:
            key1 = ipa_word[ipa_word["ipa_code"] == sug_i.term][
                "rightword"
            ].reset_index(drop=True)[0]
            dict_outputs[key1] = sug_i.distance

        # return [suggestion[0] for suggestion in suggestions]
        # return phonetically_similar_words
        print(dict_outputs)
        return dict_outputs

    def get_sorted_suggestions(self, input_word):
        final_suggestions = {}
        suggestions = self.custom_symspell_lookup(input_word)
        suggestions2 = self.phonetic_lookup(input_word)
        for sug_i in suggestions[:50]:
            final_suggestions[sug_i.term] = [sug_i.distance, sug_i.count]
            if sug_i.term in suggestions2.keys():
                final_suggestions[sug_i.term] = [
                    sug_i.distance / 2.0 + suggestions2[sug_i.term] / 2.0,
                    sug_i.count,
                ]
        sorted_dict = dict(sorted(final_suggestions.items(), key=lambda x: x[1]))
        sorted_keys = sorted(
            final_suggestions.keys(),
            key=lambda x: (final_suggestions[x][0], -final_suggestions[x][1]),
        )
        # print("\n\n get_sorted_suggestions:", sorted_keys)

        return list(sorted_keys)


class QueryCorrectorLM:
    def __init__(self, model_path=None):
        # minimum word frequency to be considered correct
        self.min_word_freq = 100
        self.max_dictionary_edit_distance = 5
        self.symspell_prefix_length = 10
        self.constant_test = 10
#         if model != None:
#             self.model = model
        # Setup basic things needed
        # self.load_trained_model()
        # self.phonetics_path = phonetics_path
        # self.rightwords_path = rightwords_path

        # # Setting up the model path
        if model_path is not None:
            self.model_path = model_path

    def get_top_n_elements(self, dictionary, n):
        return dict(
            sorted(dictionary.items(), key=lambda item: item[1], reverse=True)[:n]
        )

    def basic_setup(self, rightwords_path, phonetics_path):
        """
        Sets up basic things.
        """
        print("Setting up basic things in place")

        # Logging setup
        self.setup_logger()

        self.custom_sym_spell = CustomSymSpell(
            self.max_dictionary_edit_distance,
            self.symspell_prefix_length,
            self.min_word_freq,
            rightwords_path,
            phonetics_path,
            self.min_word_freq + 50,
        )
        self.set_params()

        # All stop words are right words and more words will be added later
        def get_top_n_elements(dictionary, n):
            return dict(
                sorted(dictionary.items(), key=lambda item: item[1], reverse=True)[:n]
            )

        print(get_top_n_elements(self.rightwords, 10))
        print(self.rightwords["hoodies"])

        self.resetRightWords(rightwords_path)
        print(get_top_n_elements(self.rightwords, 10))
        print(self.rightwords["hoodies"])

        # Lemmatizer and pluralizing, singularizing engine to get root wordss
        self.wordnet_lemmatizer = WordNetLemmatizer()
        self.p = inflect.engine()
        self.dmeta = fuzzy.DMetaphone()  # Phonetics engine

        # Regex for checking contains digit
        self.RE_D = re.compile("\d")

        # Regex for preprocessing
        self.preprocessing_regex_1 = re.compile(r"(?<=[0-9])[^0-9a-zA-Z'.\/_%\-']+")
        self.preprocessing_regex_2 = re.compile(r"(?<![0-9])[^0-9a-zA-Z]+")
        self.epi = epitran.Epitran("eng-Latn")

    def setup_logger(self):
        """
        Sets up logger
        """
        self.logger = logging.getLogger(__name__)
        self.logger.setLevel(logging.DEBUG)

        # Create a formatter with function name and attach it to the handler
        formatter = logging.Formatter(
            "%(asctime)s - %(name)s - %(levelname)s - %(funcName)s - %(message)s"
        )

        # Remove existing handlers from the logger
        for handler in self.logger.handlers:
            handler.setFormatter(formatter)

    def model_setup(
        self,
        context_model_path,
        rightwords_path,
        phonetics_path,
        tokenizer_path=None,
    ):
        """
        This function takes the model path and load all the required files for prediction/spell correction
        model_path: Directory path for all required files
        """
        if tokenizer_path is None:
            tokenizer_path = context_model_path
        # Loading symspell pickle
        print("Importing Spell Checking Dictionaries")
        self.rightwords = (
            # pd.read_csv(
            #     model_path + os.sep + "model_dict.txt", sep=" ", names=["word", "freq"]
            # )
            pd.read_csv(rightwords_path, sep=" ", names=["word", "freq"])
            .set_index("word")["freq"]
            .to_dict()
        )

        # self.sym_spell = SymSpell(
        #     max_dictionary_edit_distance=self.max_dictionary_edit_distance,
        #     prefix_length=self.symspell_prefix_length,
        #     count_threshold=self.min_word_freq - 1,
        # )
        # self.sym_spell.load_pickle(model_path + os.sep + "model_dict.pkl")
        self.custom_sym_spell = CustomSymSpell(
            self.max_dictionary_edit_distance,
            self.symspell_prefix_length,
            self.min_word_freq,
            rightwords_path,
            phonetics_path,
            self.min_word_freq + 50,
        )

        # Loading context models, either fasttext or tsv word embeddings
        print("Importing Context Models")
        # self.tokenizer = AutoTokenizer.from_pretrained(tokenizer_path)
        # self.model = BertForMaskedLM.from_pretrained(context_model_path)
        # self.mask_token_id = self.tokenizer.convert_tokens_to_ids("[MASK]")

        print("Final setting up!")
        # self.set_params()
        # Generating Phonetics
        print("Generating Phonetics")
        self.generatePhoneticsDict()

    def set_params(self, **kwargs):
        """
        This function can be used to setup default parameters for a model
        and the user can use this function to manually tune the model according to its needs
        """
        print(
            "================================================================ called set_params================================================================"
        )
        # Default parameters
        if len(kwargs) == 0:
            self.params = params_template(
                context_param=10,
                phone_param=5000,
                freq_param=1000,
                dist_param=1000.0,
                right_param=1000.0,
            )

        # Externally set parameters
        else:
            try:
                self.params = self.params._replace(**kwargs)
            except Exception as e:
                print("Invalid arguments: ", kwargs)

        self.get_params(return_params=False)

    def get_params(self, return_params=True):
        """
        To get and display current parameters of the model
        """
        print(f"Current parameters of model: {self.params}")

        if return_params:
            return self.params

    def addRightWords(self, rightword_dict):
        """
        This function input two lists, r_list: list of rightwords, r_count: count of each rightword

        This is to used to externally setup the rightwords by user(precalculated)
        """
        print("Adding rightwords", rightword_dict)

        for rword, rcount in rightword_dict.items():
            self.rightwords[rword] = self.rightwords.get(rword, 0) + max(
                int(rcount), self.min_word_freq
            )

    def addW2R(self, w2r_dict):
        """
        This function setup w2r
        """
        self.w2r = {}
        for w, r in w2r_dict.items():
            self.w2r[w] = (r[0], False)  # (rightword, isException)

    def addW2R_exception(self, words):
        """
        This function adds w2r exceptions to be given precedence over context always
        """
        print("Adding w2r exceptions")
        words = set(words)
        words.intersection_update(set(self.w2r.keys()))

        for word in words:
            self.w2r[word] = (self.w2r[word][0], True)  # (rightword, isException)

    def add_fixed_words(self, words):
        """
        This function adds fixed words that will not be changed
        """
        print("Adding Fixed words")
        self.fixed_words = set(words)
        self.fixed_words.intersection_update(set(self.rightwords))

    def resetRightWords(self, rightwords_path):
        """
        This function is used to reset the right words
        """
        print("resetting right words.....\n")
        # self.rightwords = (
        # pd.read_csv(
        #     model_path + os.sep + "model_dict.txt", sep=" ", names=["word", "freq"]
        # )
        # "/Users/meghana/Documents/separateModules/ContextSpellChecker/spell_checker_model_lm_old/rightwords_freq.txt"
        self.rightwords = (
            pd.read_csv(rightwords_path, sep=" ", names=["word", "freq"])
            .set_index("word")["freq"]
            .to_dict()
        )
        self.rightwords.update(
            {sw: self.min_word_freq for sw in stopwords.words("english")}
        )

    # pass

    def saveRightWordsDict(self, output_data_folder=None):
        print("Saving Dict text")
        output_file_path = output_data_folder + os.sep + "model_dict.txt"

        pd.DataFrame(
            [[word, freq] for word, freq in self.rightwords.items()],
            columns=["word", "freq"],
        ).to_csv(output_file_path, header=None, index=False, sep=" ")

        return output_file_path

    def save_model(self):
        print("Saving Model")
        with open(self.model_path + os.sep + "model.pkl", "wb") as output_file:
            pickle.dump(self, output_file)

    @classmethod
    def load_trained_model(cls, filepath, rightwords_path, phonetics_path):
        print("Loading trained model")
        with open(filepath + os.sep + "model.pkl", "rb") as file:
            obj = pickle.load(file)
        if isinstance(obj, cls):
            obj.basic_setup(rightwords_path, phonetics_path)
            return obj
        else:
            raise ValueError("Loaded object is not an instance of the class.")

    def set_up_basic_params(self, obj, rightwords_path, phonetics_path):
        obj.basic_setup(rightwords_path, phonetics_path)
        return obj

    def load_context_model(self, context_model_path, tokenizer_path=None):
        if tokenizer_path is None:
            tokenizer_path = context_model_path

        # Already Pretrained context model
        print("Importing Context Models")
        self.tokenizer = AutoTokenizer.from_pretrained(tokenizer_path)
        self.model = BertForMaskedLM.from_pretrained(context_model_path)
        self.mask_token_id = self.tokenizer.convert_tokens_to_ids("[MASK]")

    def train(self):
        """
        This is the complete wrapper function for handling the different traininng operations
        involving training symspell, creating word dictionaries, refining the file, trainig context and all

        After training all the trained files and models are saved in the output folder given and ready for inference.

        input parameters:
        input_data_file: txt file to be trained on
        output_data_folder: output folder for storing models and files
        epoch: Number of epochs for which the context needs to be trained
        refineFile: its a bool representing whether a refined file need to be created, or go with raw file itself
        pre_embedding_path: Feed already trained embeddings to learn new embeddings
        """

        if not os.path.exists(self.model_path):
            os.makedirs(self.model_path)

        self.sym_spell = SymSpell(
            max_dictionary_edit_distance=self.max_dictionary_edit_distance,
            prefix_length=self.symspell_prefix_length,
            count_threshold=self.min_word_freq - 1,
        )
        print("\n================================ inside training =================")

        dict_path = self.saveRightWordsDict(output_data_folder=self.model_path)

        print("Learning word variations")
        self.sym_spell.load_dictionary(dict_path, 0, 1)

        print("Setting params dict")
        self.set_params()

        self.generatePhoneticsDict()

        self.save_model()

    def sigmoid(self, x):
        return math.exp(x) / (1 + math.exp(x))

    def get_context_score_bert(self, sentence):
        # Tokenize the sentence
        tokens = self.tokenizer.tokenize(sentence)

        # Loop over each token in the sentence and mask it out
        scores = []
        for i in range(len(tokens)):
            # Make a copy of the original token list
            masked_tokens = tokens.copy()

            # Mask out the i-th token
            masked_tokens[i] = "[MASK]"

            # Convert the masked token list back to a string
            masked_sentence = " ".join(masked_tokens)

            # Convert the masked sentence to input IDs for the model
            input_ids = self.tokenizer.encode(masked_sentence, return_tensors="pt")

            # Get the model's predictions for the masked tokens
            with torch.no_grad():
                outputs = self.model(input_ids)
                predictions = outputs[0].squeeze(0)

            # Get the predicted probability of the correct token for the i-th position
            masked_index = masked_tokens.index("[MASK]")
            target_token = tokens[i]
            target_token_id = self.tokenizer.convert_tokens_to_ids(target_token)
            target_token_prob = predictions[masked_index][target_token_id].item()
            #         print(predictions[masked_index][target_token_id])
            # Add the score to the list of scores
            scores.append(target_token_prob)

        # Calculate the average score for the sentence
        avg_score = sum(scores) / len(scores)

        avg_score = round((self.sigmoid(avg_score) * 10)) / 10

        return avg_score

    def get_context_score_bert2(self, sentence):
        # Tokenize the sentence
        tokens = self.tokenizer.tokenize(sentence)

        # Initialize a list to store probabilities
        probabilities = []

        for i in range(len(tokens)):
            # Create a copy of the tokens to avoid modifying the original list
            masked_tokens = tokens.copy()

            # Mask the current token
            masked_tokens[i] = self.tokenizer.mask_token

            # Convert tokens to token IDs
            token_ids = self.tokenizer.convert_tokens_to_ids(masked_tokens)

            # Pad or truncate token_ids to the model's maximum sequence length
            max_length = self.model.config.max_position_embeddings
            if len(token_ids) > max_length - 2:
                token_ids = token_ids[: max_length - 2]

            # Add special tokens [CLS] and [SEP]
            token_ids = (
                [self.tokenizer.cls_token_id]
                + token_ids
                + [self.tokenizer.sep_token_id]
            )

            # Convert token IDs to tensors
            token_ids = torch.tensor([token_ids])

            # Use the model for prediction
            with torch.no_grad():
                outputs = self.model(token_ids)
                predictions = outputs.logits

            # Get the predicted token ID for the masked position
            predicted_token_id = torch.argmax(predictions[0, i + 1]).item()

            # Apply softmax to the logits
            probabilities_tensor = torch.nn.functional.softmax(predictions, dim=-1)

            # Get the probability of the predicted token
            predicted_probability = probabilities_tensor[
                0, i + 1, predicted_token_id
            ].item()

            probabilities.append(predicted_probability)

        # Calculate the average probability
        average_probability = sum(probabilities) / len(probabilities)

        return average_probability

    def get_context_score_bert3(self, sentence):
        # Tokenize the sentence
        tokens = self.tokenizer.tokenize(sentence)

        # Find the index of the masked token
        #     mask_index = tokens.index("[MASK]")

        # Convert tokens to input IDs
        token_input_ids = self.tokenizer.convert_tokens_to_ids(tokens)

        # Convert to tensor and add a batch dimension
        input_ids = torch.tensor(
            [
                token_input_ids[:i] + [self.mask_token_id] + token_input_ids[i + 1 :]
                for i in range(len(tokens))
            ]
        )
        # Forward pass through the model
        with torch.no_grad():
            outputs = self.model(input_ids)

        #     prob_scores = []
        total_prob = 1.0
        for i in range(len(tokens)):
            predictions = outputs.logits[i, i]  # [batch_num, masked_token_index]
            temp_prob = torch.softmax(predictions, dim=-1)[token_input_ids[i]].item()
            #         prob_scores.append(temp_prob)
            total_prob *= temp_prob
        #         print(outputs.logits.shape)

        return math.log(total_prob)

    def get_context_score_words(self, candidate_words, pre_sent, post_sent):
        pre_sent_tokenised = self.tokenizer.tokenize((" ".join(pre_sent)))
        post_sent_tokenised = self.tokenizer.tokenize(" ".join(post_sent))

        # Tokenize the sentence and target phrase
        tokenized_target_phrases = [
            self.tokenizer.tokenize(word) for word in candidate_words
        ]
        num_tokenized_target_phrases = len(tokenized_target_phrases)
        tokenized_sentences = [
            ["[CLS]"]
            + pre_sent_tokenised
            + ["[MASK]"] * len(tokenized_target_phrase)
            + post_sent_tokenised
            + ["[SEP]"]
            for tokenized_target_phrase in tokenized_target_phrases
        ]

        # Convert tokens to IDs
        token_ids = [
            self.tokenizer.convert_tokens_to_ids(tokenized_sentence)
            for tokenized_sentence in tokenized_sentences
        ]
        target_token_ids = [
            self.tokenizer.convert_tokens_to_ids(tokenized_target_phrase)
            for tokenized_target_phrase in tokenized_target_phrases
        ]

        max_len = min(max(len(token_id) for token_id in token_ids), 512)
        token_ids = [
            token_id[:max_len] + (max_len - len(token_id)) * [0]
            for token_id in token_ids
        ]

        # # Find the index of the masked token i.e cls + pre_sent + 1
        masked_index = len(pre_sent_tokenised) + 2

        input_ids = torch.tensor(token_ids)

        # Get the model's predictions
        with torch.no_grad():
            predictions = self.model(input_ids)

        prob_score = np.asarray(
            [
                np.prod(
                    [
                        torch.softmax(predictions.logits[i, masked_index + j], dim=0)[
                            token_id
                        ].item()
                        for j, token_id in enumerate(target_token_ids[i])
                    ]
                )
                for i in range(num_tokenized_target_phrases)
            ]
        )

        return prob_score

    def get_context_score_sentence(self, sentence):
        sentence_splitted = sentence.split(" ")

        # Tokenize the sentence and target phrase
        tokenized_target_phrases = [
            self.tokenizer.tokenize(word)
            for word in sentence_splitted
            # if word not in self.rightwords
        ]
        num_tokenized_target_phrases = len(tokenized_target_phrases)
        if num_tokenized_target_phrases == 0:
            pass
        #             return 1.0
        tokenized_sentences = [
            ["[CLS]"]
            + sentence_splitted[:i]
            + ["[MASK]"] * len(tokenized_target_phrase)
            + sentence_splitted[i + 1 :]
            + ["[SEP]"]
            for i, tokenized_target_phrase in enumerate(tokenized_target_phrases)
            # if sentence_splitted[i] not in self.rightwords
        ]

        # Convert tokens to IDs
        token_ids = [
            self.tokenizer.convert_tokens_to_ids(tokenized_sentence)
            for tokenized_sentence in tokenized_sentences
        ]
        target_token_ids = [
            self.tokenizer.convert_tokens_to_ids(tokenized_target_phrase)
            for tokenized_target_phrase in tokenized_target_phrases
        ]

        max_len = min(max(len(token_id) for token_id in token_ids), 512)
        token_ids = [
            token_id[:max_len]
            + (max_len - len(token_id)) * [self.tokenizer.pad_token_id]
            for token_id in token_ids
        ]

        # # Find the index of the masked token i.e cls + pre_sent + 1
        masked_index = [
            token_id.index(self.tokenizer.mask_token_id) for token_id in token_ids
        ]

        input_ids = torch.tensor(token_ids)

        # Get the model's predictions
        with torch.no_grad():
            predictions = self.model(input_ids)

        prob_score = np.asarray(
            [
                np.prod(
                    [
                        torch.softmax(
                            predictions.logits[i, masked_index[i] + j], dim=0
                        )[token_id].item()
                        for j, token_id in enumerate(target_token_ids[i])
                    ]
                )
                for i in range(num_tokenized_target_phrases)
            ]
        )

        return np.log(np.prod(prob_score))

    def get_context_score_sentences(self, sentences):
        if isinstance(sentences, str):
            # If input is a single string, convert it to a list with one element
            sentences = [sentences]

        sentences_store = [0] * len(sentences)
        start_index = 0
        token_ids = []
        for i, sentence in enumerate(sentences):
            sentence_splitted = sentence.split(" ")

            # Tokenize the sentence and target phrase
            tokenized_target_phrases = [
                self.tokenizer.tokenize(word) for word in sentence_splitted
            ]

            tokenized_sentences = [
                ["[CLS]"]
                + sentence_splitted[:i]
                + ["[MASK]"] * len(tokenized_target_phrase)
                + sentence_splitted[i + 1 :]
                + ["[SEP]"]
                for i, tokenized_target_phrase in enumerate(tokenized_target_phrases)
            ]

            # Convert tokens to IDs
            token_ids += [
                self.tokenizer.convert_tokens_to_ids(tokenized_sentence)
                for tokenized_sentence in tokenized_sentences
            ]

            target_token_ids = [
                self.tokenizer.convert_tokens_to_ids(tokenized_target_phrase)
                for tokenized_target_phrase in tokenized_target_phrases
            ]

            masked_index = [
                token_id.index(self.tokenizer.mask_token_id)
                for token_id in token_ids[
                    start_index : start_index + len(target_token_ids)
                ]
            ]

            sentences_store[i] = (
                masked_index,
                target_token_ids,
                range(start_index, start_index + len(target_token_ids)),
            )
            start_index += len(target_token_ids)

        max_len = min(max(len(token_id) for token_id in token_ids), 512)
        token_ids = [
            token_id[:max_len]
            + (max_len - len(token_id)) * [self.tokenizer.pad_token_id]
            for token_id in token_ids
        ]

        attention_mask = [
            [
                (
                    0
                    if token
                    in (self.tokenizer.mask_token_id, self.tokenizer.pad_token_id)
                    else 1
                )
                for token in token_id
            ]
            for token_id in token_ids
        ]
        #     input_ids = torch.tensor(token_ids)
        input_ids = {
            "input_ids": torch.tensor(token_ids),
            # "attention_mask": torch.tensor(attention_mask),
        }

        # Get the model's predictions
        with torch.no_grad():
            predictions = self.model(**input_ids)

        prob_score = [
            (
                [
                    np.prod(
                        [
                            torch.softmax(
                                predictions.logits[
                                    i, masked_index[i - index.start] + j
                                ],
                                dim=0,
                            )[token_id].item()
                            for j, token_id in enumerate(
                                target_token_ids[i - index.start]
                            )
                        ]
                    )
                    for i in index
                ]
            )
            for masked_index, target_token_ids, index in sentences_store
        ]

        results = [np.log(np.prod(prob)) for prob in prob_score]
        return np.interp(
            results, (min(results), max(results)), (0, 1)
        )  # Normalizing results between 0 and 1

    # @FunctionCache(max_cache_size=10_000)
    def get_w2r_predictions(self, query):
        """Returns W2r predictions and whether it should be given an exception or not"""

        query_splitted = self.preprocessQuery(query).split()
        w2r_output = [
            (
                self.w2r.get(word, (word, False))
                if not self.is_number(word)
                else (word, False)
            )
            for word in query_splitted
        ]
        w2r_query = " ".join([x[0] for x in w2r_output])
        exceptions = {query_splitted[i]: x[0] for i, x in enumerate(w2r_output) if x[1]}

        # Temp exception removal (only take very different variants). To be removed later
        exceptions = {
            key: value
            for key, value in exceptions.items()
            if jellyfish.damerau_levenshtein_distance(key, value) > 2
        }

        return w2r_query, exceptions

    # @FunctionCache(max_cache_size=10_000)
    def ensemble_correct(self, query, return_all=False):
        query_type = "NA"
        final_query = ""

        w2r_query, exceptions = self.get_w2r_predictions(query)

        context_query_dict = self.correct(query, 5)

        # self.logger.debug("%s", pprint.pformat(context_query_dict, indent=4))
        self.logger.debug("%s", pprint(context_query_dict, indent=4))
        context_query = list(context_query_dict.keys())[0]

        self.logger.debug(f"W2R Query: {w2r_query} Context Query: {context_query}")

        if exceptions:
            context_query_components = context_query_dict[context_query][
                "sent_components"
            ]
            query_splitted = self.preprocessQuery(query).split()
            context_query_splitted = context_query.split(" ")

            i = 0
            context_query_grouped = {}
            for i, group_size in enumerate(context_query_components):
                context_query_grouped[query_splitted[i]] = " ".join(
                    context_query_splitted[i : i + group_size]
                )
                i += group_size

            self.logger.debug(
                f"Exceptions: {exceptions}, Grouped context query: {context_query_grouped}"
            )

            for w, r in exceptions.items():
                if context_query_grouped.get(w, "") != r:
                    query_type, final_query = "W2R Exception", w2r_query
                    break

        if query_type != "W2R Exception":
            if w2r_query == context_query:
                query_type, final_query = "Same query", w2r_query

            else:
                (w2r_context, context_query_context) = self.get_context_score_sentence(
                    w2r_query
                ), self.get_context_score_sentence(context_query)

                if w2r_context > context_query_context:
                    query_type, final_query = "W2R query", w2r_query

                if w2r_context < context_query_context:
                    query_type, final_query = "Context query", context_query

        if return_all:
            return final_query, query_type, w2r_query, context_query
        else:
            return final_query

    def check_correct_word(self, word):
        return str(TextBlob(word).correct()) == word

    def getWordVariants(self, word):
        # return_set = set()
        # if self.check_correct_word(word):
        #     sigular = Word(word).singularize()
        #     plural = Word(word).pluralize()
        #     if self.check_correct_word(sigular):
        #         return_set.add(sigular)
        #     if self.check_correct_word(plural):
        #         return_set.add(plural)
        #     return return_set
        # else:
        return {
            word,
            Word(word).singularize(),
            Word(word).pluralize(),
        }

    # @FunctionCache(max_cache_size=10_000)
    def custom_lookup(self, term, n=5, compound_term=False):
        n = 20
        try:
            term_len = len(term)
            max_edit_distance = min(
                self.max_dictionary_edit_distance, max(round(term_len / 2) + 1, 1)
            )
            term_variants = self.getWordVariants(term)
            phone_wrongs = self.getPhoneticVariants(term)
            valid_term_variants = term_variants.intersection(self.rightwords)
            max_freq_term_variants = (
                max(self.rightwords[variant] for variant in valid_term_variants)
                if len(valid_term_variants) > 0
                else 0
            )

            # Deciding final terms to return
            if term in self.rightwords:
                n = len(valid_term_variants)

            # Getting top suggestions
            # for i in range(1, max_edit_distance + 1):
            print(
                "inside lookup:================================================================",
                term,
            )
            # print(self.sym_spell)
            # suggestions = self.custom_sym_spell.custom_symspell_lookup(term)
            get_sorted_suggestions = self.custom_sym_spell.get_sorted_suggestions(term)

            # self.sym_spell.lookup(term, Verbosity.ALL)
            #     Verbosity.ALL,
            #     max_edit_distance=max_edit_distance,
            #     include_unknown=True,
            # )

            # distance_sug = list({sug.term for sug in suggestions[:60]})
            # phonetic_sug = list(set(phonetic_sug).intersection(set(distance_sug)))
            # print("phonetic_sug:", phonetic_sug)

            phonetic_variants = {
                word
                for pw in phone_wrongs
                for word in self.inversePhoneticsDict.get(pw, set())
                if Levenshtein.distance(word, term) <= max_edit_distance
            }
            print("\nphonetic_variants", phonetic_variants)

            # suggestions array
            suggestions = get_sorted_suggestions[:n]
            suggestions.extend(
                list(
                    # {sug.term for sug in suggestions[:n]} |
                    (  # TERM VARIANTS
                        {variant for variant in valid_term_variants}
                        if len(term) > 2
                        else set()
                    )
                    | phonetic_variants
                )
            )
            # if len(get_sorted_suggestions) != 0:
            # suggestions.extend(get_sorted_suggestions[:n])
            print("suggestions: ", get_sorted_suggestions)

            ## Compound terms
            if compound_term:
                c_term = self.sym_spell.word_segmentation(term)
                corrected_string = c_term.corrected_string
                split_terms = corrected_string.split()
                if c_term.segmented_string == corrected_string and all(
                    len(split_term) != 1 for split_term in split_terms
                ):
                    suggestions.append(corrected_string)
                    if corrected_string not in valid_term_variants:
                        n = max(len(valid_term_variants) + 1, n)
                        valid_term_variants.add(corrected_string)
                        max_freq_term_variants = max(
                            max_freq_term_variants,
                            np.mean(
                                [
                                    self.rightwords[split_term]
                                    for split_term in split_terms
                                ]
                            ),
                        )

            # Getting the frequency of words
            print(
                "inside lookup:================================================================: 1.5",
                term,
            )
            print("max_freq_term_variants", max_freq_term_variants)
            for sug in suggestions:
                print("\n\nfreqq", sug, self.rightwords.get(sug, 0))
                print(self.get_top_n_elements(self.rightwords, 10))
                print(self.rightwords[sug])
                print(self.rightwords.get("hoodies", 0))
            # check this once
            normalised_freq = [
                (
                    max_freq_term_variants
                    if sug in valid_term_variants
                    else self.rightwords.get(sug, 0)
                )
                for sug in suggestions
            ]
            print(normalised_freq)
            normalised_freq = np.interp(
                normalised_freq, (min(normalised_freq), max(normalised_freq)), (0, 1)
            )
            print(normalised_freq)
            print(
                "inside lookup:================================================================: 2",
                term,
            )

            # Normalised frequncy, distance, Phonetics(Added later), rightword boolean
            s_dict = {
                sug: (
                    [freq, 1, 1]
                    if sug in valid_term_variants
                    else [
                        freq,
                        max(
                            [
                                1
                                - (
                                    jellyfish.damerau_levenshtein_distance(
                                        variant, term
                                    )
                                    / term_len
                                )
                                for variant in self.getWordVariants(sug)
                                if variant in self.rightwords
                            ]
                            + [0]
                        ),
                        0,
                    ]
                )
                for sug, freq in zip(suggestions, normalised_freq)
            }
            print(
                "inside lookup:================================================================: 3",
                term,
            )

            # Adding Phonetics
            for r in s_dict.keys():
                phone_rights = self.getPhoneticVariants(r)
                if phone_wrongs.isdisjoint(phone_rights):  # Partial phonetic score
                    phone_ratio = max(
                        Levenshtein.ratio(pw, pr)
                        for pw in phone_wrongs
                        for pr in phone_rights
                    )
                else:
                    phone_ratio = 1.0
                s_dict[r].insert(2, phone_ratio)  ##Adding at 2nd index

            # Sorting to get top words and converting to named tuple
            s_dict = {
                key: score_template(
                    total_freq_score=s_dict[key][0],
                    total_dist_score=s_dict[key][1],
                    total_phone_score=s_dict[key][2],
                    total_right_score=s_dict[key][3],
                )
                for key in sorted(s_dict, key=lambda x: s_dict[x][::-1], reverse=True)[
                    :n
                ]
            }
            print("\n\n all sorted keys \n\n", s_dict)

        except Exception as e:
            print("Custom Lookup", term, e)
            return {term: score_template}
        return s_dict

    def getPhoneticsCode(self, word):
        try:
            sphone = jellyfish.soundex(word)
            try:
                dphone = self.dmeta(word)[0]
                dphone = dphone.decode() if dphone is not None else ""
            except Exception as e:
                dphone = ""

        except Exception as e:
            sphone = ""
            dphone = ""
            print("Phonetics calc error for word, ", word)
            raise e

        return {sphone, dphone}

    # def getPhoneticsCode(self, word):
    #     # if two ouputs needed
    #     phonetics_df = pd.read_parquet(
    #         "/Users/meghana/Documents/separateModules/ContextSpellChecker/data/IPA/IPA_parquet/")
    #     phonetics = phonetics_df[phonetics_df["variants"] == word]["ipa_w"].tolist()
    #     if len(phonetics) == 0:
    #         epi = epitran.Epitran("eng-Latn")
    #         phonetics_code = epi.transliterate(word)
    #         print("inside epitran run ... found new word: ", word)
    #         return {phonetics_code}
    #     else:
    #         # print(word)
    #         return set(phonetics)

    def generatePhoneticsDict(self):
        print("inside generate....")
        list_of_words = set()
        i = 0
        # for word in self.rightwords.keys():
        #     for variant in self.getWordVariants(word):
        #         print(i, variant)
        #         i = i+1
        #         list_of_words.add(variant)
        # list(list_of_words)
        print("saving rightwords")
        # df = pd.DataFrame(list(self.rightwords.keys()), columns=["Words"])
        # df =
        # df.to_csv("/Users/meghana/Documents/separateModules/ContextSpellChecker/data/IPA/rightwords_variant_inputs.csv")
        # df.to_csv("/Users/meghana/Documents/separateModules/ContextSpellChecker/data/IPA/rightwords_variants.csv")
        # quit()
        self.phoneticsDict = {
            word: set().union(
                *[
                    self.getPhoneticsCode(variant)
                    for variant in self.getWordVariants(word)
                ]
            )
            for word in self.rightwords.keys()
        }
        print(
            "\n\n generate phonetics dictionary",
            dict(list(self.phoneticsDict.items())[:6]),
        )

        # Inverse phonetics dict phone_code -> right_word
        self.inversePhoneticsDict = {}
        for word in self.rightwords.keys():
            for variant in self.getWordVariants(word).intersection(self.rightwords):
                for p_code in self.getPhoneticsCode(variant):
                    if p_code not in self.inversePhoneticsDict:
                        self.inversePhoneticsDict[p_code] = set()
                    self.inversePhoneticsDict[p_code].update({word})

    def comparePhonetics(self, w1, w2):
        w_meta = self.dmeta(w1)

        if w_meta[0] is not None:
            w_len = len(w_meta[0])
        else:
            w_len = 0

        phone = self.dmeta(w2)[0]
        if (phone is not None) and (phone[:w_len] == w_meta[0]):
            return 1

        return 0

    def getPhoneticVariants(self, word):
        return self.phoneticsDict.get(
            word,
            set().union(
                *[
                    self.getPhoneticsCode(variant)
                    for variant in self.getWordVariants(word)
                ]
            ),
        ).difference(
            {""}
        )  # Removing blank phonetics at end

    def mergeSentences(self, sentences_old):
        sentences_new = []
        for s_old in sentences_old:
            if isinstance(s_old, str):
                q_arr = s_old.split()
            else:
                q_arr = s_old
            new_arr = [q_arr[0]]
            for i in range(1, len(q_arr)):
                gram_2 = new_arr[-1] + q_arr[i]
                if self.custom_sym_spell.words.get(gram_2, 0) != 0:
                    new_arr.pop()
                    new_arr.append(gram_2)
                else:
                    new_arr.append(q_arr[i])

            k_new = " ".join(new_arr)
            sentences_new.append(k_new)

        return sentences_new

    def mergeSentencesDict(self, sentences_old_dict):
        sentences_new = self.mergeSentences(sentences_old_dict.keys())

        sentences_new_dict = {}

        for i, old_sentence in enumerate(sentences_old_dict.keys()):
            new_sentence = sentences_new[i]
            if old_sentence != new_sentence:
                sentences_new_dict[old_sentence] = sentences_old_dict[
                    old_sentence
                ].copy()
                sentences_new_dict[old_sentence]["total_score"] -= 0.01
            sentences_new_dict[new_sentence] = sentences_old_dict[old_sentence]

        return sentences_new_dict

    def getCombinationScores(self, combinations, top_n):
        sentence_scores = MaxHeap(top_n * 5)

        for comb in itertools.product(*combinations):
            # Starting from fresh 0 scores
            scores = score_template()._asdict()

            sent = " ".join(comb)
            sent_components = [1] * len(comb)  # number of components/words per block
            for i, word in enumerate(comb):
                values = combinations[i][word]
                scores["total_freq_score"] += (
                    values.total_freq_score * self.params.freq_param
                )
                scores["total_dist_score"] += (
                    values.total_dist_score * self.params.dist_param
                )
                scores["total_phone_score"] += (
                    values.total_phone_score * self.params.phone_param
                )
                scores["total_right_score"] += (
                    values.total_right_score * self.params.right_param
                )

                # If contain spaces, add more words
                sent_components[i] += word.count(" ")

            scores["total_score"] += (
                scores["total_freq_score"]
                + scores["total_dist_score"]
                + scores["total_right_score"]
                + scores["total_phone_score"]
            )
            scores["sent_components"] = sent_components
            sentence_scores.add((scores["total_score"], (sent, scores)))

        return sentence_scores

    def containsNumber(self, word):
        return bool(self.RE_D.search(word))

    def is_number(self, input_str):
        return input_str.isdigit()

    def preprocessQuery(self, query):
        """Preprocessing steps"""
        try:
            return re.sub(
                self.preprocessing_regex_1,
                " ",
                re.sub(self.preprocessing_regex_2, " ", str(query).lower()),
            ).strip()
        except Exception as e:
            print(e)
            return query

    # @FunctionCache(max_cache_size=3)
    def correct(
        self,
        query,
        top_n=1,
        compounding=True,
        top_words=20,
        merging=True,
        verbose=False,
        ignore_errors=False,
    ):
        print("in correct")
        # self.resetRightWords()
        # self.set_params()
        print(self.params)
        print(len(self.rightwords))

        # print("after set params in correct")

        # print("after reset rightwordws in correct")

        print(query)
        # self.generatePhoneticsDict()
        # print("test in correct:",self.custom_sym_spell.custom_symspell_lookup("jearcy"))
        try:
            preprocessed_query = self.preprocessQuery(query)

            if len(query) == 0:
                raise Exception(
                    f"Query:'{query}' -> length is zero after preprocessing"
                )
            else:
                query = preprocessed_query

            q_arr = query.split()

            context_check = True
            # For single words and no context
            if len(q_arr) <= 1:
                context_check = False

            ##For numbers
            attention_mask = [(not self.is_number(word)) for word in q_arr]

            top_words = min(top_n * 5, top_words)
            # getting combinations for words that are not right?!
            combinations = [
                (
                    self.custom_lookup(word, top_words, compound_term=compounding)
                    if attention
                    else {word: score_template()}
                )
                for attention, word in zip(attention_mask, q_arr)
            ]
            # print("\ntype of combinations",type(combinations))
            # Getting topn sentences to be evaluated further
            sentence_scores = self.getCombinationScores(combinations, top_n)
            # print("\n\ncombinations sentence_scores :", sentence_scores)

            # Rearranging the dict
            sentence_scores = {
                tuple[1][0]: tuple[1][1] for tuple in sentence_scores.getTop()
            }

            # Merging words if possible
            if merging:
                sentence_scores = self.mergeSentencesDict(sentence_scores)

            # Checking for context
            if context_check:
                context_scores = self.get_context_score_sentences(
                    sentence_scores.keys()
                )
                for context_score, (sent, score_dict) in zip(
                    context_scores, sentence_scores.items()
                ):
                    score_dict["total_context_score"] = (
                        context_score * self.params.context_param * (len(q_arr) - 1)
                    )
                    score_dict["total_score"] += score_dict["total_context_score"]
                    sentence_scores[sent] = score_dict

            # Sorting Each sentence scores
            sentence_scores = {
                key: sentence_scores[key]
                for key in sorted(
                    sentence_scores,
                    key=lambda x: sentence_scores[x]["total_score"],
                    reverse=True,
                )[:top_n]
            }
        except Exception as e:
            print("Spell Checker", query, e)
            return {query: score_template()._asdict()}
            if not ignore_errors:
                raise e

        if verbose:
            print(json.dumps(sentence_scores, indent=4))
        return sentence_scores

    def reset_function_cache(self):
        """
        To reset the function cache of various functions. More functions can be added.
        """
        self.correct.cache.clear()  # Clear the cache


if __name__ == "__main__":
    # model_path = "/Users/anmol1.goyal/Desktop/Couture/phase2-search/Spell Checker/trained_models/LM_model"
    model_path = "/Users/meghana/Documents/separateModules/ContextSpellChecker/spell_checker_model_lm"
    # sc = QueryCorrectorLM(model_path)
    # print(sc, type(sc))
    # query_corrector_model = sc.load_trained_model(model_path)
    # print(query_corrector_model.correct("dupattas for woman", 5))

    model_path = "/Users/meghana/Documents/separateModules/ContextSpellChecker/spell_checker_model_lm"
    obj = QueryCorrectorLM(model_path)
    obj.save_model()
    loaded_obj = QueryCorrectorLM.load_trained_model(model_path)
    print(loaded_obj.correct("stachel purs for woman", 5))

    # obj.load_trained_model(model_path)

    # custom_sym_spell = CustomSymSpell(model_path, 250)
    # suggestions = custom_sym_spell.custom_symspell_lookup("hudy")
    # suggestion_words = list({sug.term for sug in suggestions[:30]})
    # print(suggestion_words)

    # sc.correct("manshirts", 5)
    # sc.correct("bridal lehnga", 5)
    # sc.correct("nike thousand off", 5)
    # sc.correct("t shirts", 5)
    # sc.correct("red tape", 5)
    # sc.correct("shitrs", 5)
    # sc.correct("lenght", 5)
    # sc.correct("shirts man", 5)
    # sc.correct("slingbags", 5)
    # sc.correct("kurtas for women", 5)

    # print(sc.getContextScore("dupattas for woman"), sc.getRootWord("dupattas"))
    # print(sc.getContextScore("dupatta for woman"), sc.getRootWord("dupatta"))

    # df = pd.read_csv("/Users/anmolgoyal/Downloads/top_50000_stepwise_output.csv")[["query","spell_check","match_phrases"]]
    # df["corrected_queries"] = df["query"].progress_apply(sc.correct, verbose=False, ignore_errors=True)
    # df.to_csv("/Users/anmolgoyal/Downloads/Corrected_top_50000_stepwise_output.csv")
    # print(sc.custom_lookup("short", n=10, compound_term=False))

    # print(sc.sym_spell.lookup_compound("t shirts",max_edit_distance=5)[0].term)
    # print(sc.stop_word_list)
    # df = pd.read_parquet("/Users/anmolgoyal/Downloads/Wrong2RightUpdatedHistory")
    # df = pd.read_csv("/Users/anmolgoyal/Desktop/Couture/RightWords/RightWordsDF.csv")
    # df = pd.read_parquet(
    #     "/Users/anmolgoyal/Desktop/Couture/RightWords/Rightwords")

    # df = pd.read_csv("/Users/anmolgoyal/Downloads/26042022/Generated_Df_RW.csv")
    # print(df["count"])
    # print(df["count"].tolist())
    # sc.addRightWords(df["rightword"].tolist(), df["count"].tolist())
    # print(sc.rightwords)

    # sc.train(input_data_file="/Users/anmolgoyal/Desktop/Couture/Spell Checker/training_data/train_data_new.txt",
    #          output_data_folder="/Users/anmolgoyal/Desktop/Couture/Spell Checker/trained_models/Iterations_Final", epoch=10, refineFile=True)
    # sc.train(input_data_file="/Users/anmolgoyal/Desktop/Couture/Spell Checker/training_data/train_data_new.txt",
    #          output_data_folder="/Users/anmolgoyal/Desktop/Couture/Spell Checker/trained_models/Iterations_9", epoch=10, refineFile=True, pre_embedding_path="/Users/anmolgoyal/Downloads/glove.6B.100d.txt")
