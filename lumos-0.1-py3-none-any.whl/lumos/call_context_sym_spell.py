from context_spell_checker_lm import QueryCorrectorLM

model_path = "/Users/meghana/Documents/separateModules/ContextSpellChecker/spell_checker_model_lm"
obj = QueryCorrectorLM(model_path)
corrector = obj.load_trained_model(model_path)

print(corrector.correct("hudies", 5))

self.sym_spell = CustomSymSpell(
    self.model_path,
    self.max_dictionary_edit_distance,
    self.symspell_prefix_length,
    self.min_word_freq,
    self.min_word_freq+50)
