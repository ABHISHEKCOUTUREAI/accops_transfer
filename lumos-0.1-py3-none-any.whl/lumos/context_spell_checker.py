import ast
import itertools
import json
import math
import os
import re
import time
from heapq import nlargest

import fasttext
import fuzzy
import inflect
import jellyfish
import numpy as np
import pandas as pd
import torch
import unidecode
from nltk.stem import WordNetLemmatizer
from sklearn.preprocessing import MinMaxScaler
from symspellpy import SymSpell, Verbosity
from tqdm import tqdm

from lumos.utils import ContextModel, MaxHeap, stop_words
from lumos.utils.context_learner import ContextLearner

tqdm.pandas()


class QueryCorrector:
    def __init__(self, model_path=None, model_type="custom"):
        # Setting up the stopwords from configuration
        self.stop_word_list = stop_words

        # minimum word frequency to be considered correct
        self.min_word_freq = 100

        # All stop words are right words and more words will be added later
        self.resetRightWords()
        self.wordDict = None

        # Lemmatizer and pluralizing, singularizing engine to get root wordss
        self.wordnet_lemmatizer = WordNetLemmatizer()
        self.p = inflect.engine()

        # Model type describing the model type to be loaded/trained
        # 'Custom': Tensorflow model, 'fasttext': Fasttext Model
        self.model_type = model_type

        # Setting up the model if already trained model available
        if model_path is not None:
            self.model_setup(model_path)

    def model_setup(self, model_path):
        """
        This function takes the model path and load all the required files for prediction/spell correction
        model_path: Directory path for all required files
        """

        # Loading symspell pickle
        print("Importing Spell Checking Dictionaries")
        self.max_dictionary_edit_distance = 5
        self.sym_spell = SymSpell(
            max_dictionary_edit_distance=self.max_dictionary_edit_distance,
            prefix_length=10,
            count_threshold=100,
        )
        self.sym_spell.load_pickle(model_path + os.sep + "model_dict.pkl")

        # Loading context models, either fasttext or tsv word embeddings
        print("Importing Context Models")
        if self.model_type == "fasttext":
            fasttext.FastText.eprint = lambda x: None
            self.model = fasttext.load_model(model_path + os.sep + "model_default")

        else:
            self.model = ContextModel(model_path + os.sep)

        print("Final setting up!")
        self.dmeta = fuzzy.DMetaphone()  # Phonetics engine
        self.params_dict = {}  # Model Tunable parameters default set up
        self.set_params()

    def addRightWords(self, r_list, r_count=None):
        """
        This function input two lists, r_list: list of rightwords, r_count: count of each rightword

        This is to used to externally setup the rightwords by user(precalculated)
        """
        if r_count is not None:
            for i, rword in enumerate(r_list):
                try:
                    self.rightwords[rword] = self.rightwords.get(rword, 0) + int(
                        r_count[i]
                    )
                except Exception as e:
                    print("Exception:", e, "for the word ", rword, r_count[i])
                    self.rightwords[rword] = 1000
        else:
            for i, rword in enumerate(r_list):
                self.rightwords[rword] = (
                    self.rightwords.get(rword, 0) + self.min_word_freq
                )

    def resetRightWords(self):
        """
        This function is used to reset the right words
        """
        self.rightwords = {sw: self.min_word_freq for sw in self.stop_word_list}
        pass

    def removeStopWords(self, arr):
        """
        The function removes the stopwords from a query array and returns the refined query without stopwords
        """
        return [i for i in arr if i not in self.stop_word_list]

    def get_params(self, return_params=True):
        """
        To get and display current parameters of the model
        """
        print("Current parameters of model")

        [print(key, ":", value) for key, value in self.params_dict.items()]

        if return_params:
            return self.params_dict

    def set_params(self, new_param_dict=None):
        """
        This function can be used to setup default parameters for a model
        and the user can use this function to manually tune the model according to its needs
        """

        # Default parameters
        if new_param_dict is None:
            self.params_dict["context_param"] = 2000
            self.params_dict["phone_param"] = 500
            self.params_dict["freq_param"] = 50
            self.params_dict["dist_param"] = 100.0
            self.params_dict["right_param"] = 200.0

        # Externally set parameters
        else:
            for key in new_param_dict.keys():
                if self.params_dict.get(key, False):
                    self.params_dict[key] = new_param_dict[key]
                else:
                    print("No parameter found: ", key)

        self.get_params(return_params=False)

    def createWordDict(
        self,
        input_data_file=None,
        output_data_folder=None,
        refined=True,
        count_threshold=1,
        from_file=True,
    ):
        print("Creating Word Dictionaries for lookup")
        wordDict = self.rightwords

        if input_data_file is not None:
            print("Reading input file")
            file = open(input_data_file, "r", errors="ignore")
            query_list = file.read().splitlines()

            # Creating Word Dict
            for q in tqdm(query_list):
                for w in re.sub("\W+", " ", q.lower()).split():
                    wordDict[w] = wordDict.get(w, 0) + 1

            file.close()

        # elif input_data_file is not None and self.rightwords is not None:
        #     print("Reading input file to add to rightwords")
        #     file = open(input_data_file, "r", errors="ignore")
        #     query_list = file.read().splitlines()

        #     # including single letter tokens
        #     for q in tqdm(query_list):
        #         for w in re.sub("\W+", " ", q.lower()).split():
        #             if len(w) == 1:
        #                 wordDict[w] = wordDict.get(w, 0) + 1

        #     file.close()

        else:
            print("Please provide a input data file or set rightwords")

        wordDict_temp = wordDict
        wordDict = {}
        if refined:
            # Refining dict
            print("Refining Dict")
            for key in wordDict_temp.keys():
                decoded_key = re.sub("\W+", "", unidecode.unidecode(str(key)))
                # if len(decoded_key)>=1 and int(wordDict_temp[key])>=count_threshold and not re.search(r'\d', decoded_key):
                if len(decoded_key) >= 1 and not re.search(r"\d", decoded_key):
                    wordDict[decoded_key] = wordDict_temp[key]
        else:
            wordDict = wordDict_temp

        print("Saving Dict text")
        self.wordDict = wordDict
        output_file_path = output_data_folder + os.sep + "model_dict.txt"
        output_file = open(output_file_path, "w")

        output_file.writelines(
            [str(key) + " " + str(int(wordDict[key])) + "\n" for key in wordDict.keys()]
        )
        output_file.close()

        self.rightwords = wordDict

        return output_file_path

    def getRootWord(self, word):
        """
        This function inputs a str word and outputs the root word
        E.g. -> studying -> study, women-> woman
        """

        new_word = word
        s_noun = self.p.singular_noun(new_word)
        if s_noun:
            new_word = s_noun

        return self.wordnet_lemmatizer.lemmatize(new_word)

    def refineTrainingFile(self, input_data_file, output_data_folder):
        """
        This function inputs the training file and creates a refined file
        i.e. only the rightwords are retained and everything else is deleted to get better context model,
        and other words will not be predicted, so learning context only for the right words

        Output: new refined file in the ouput folder
        """

        print("Creating refined file")
        file = open(input_data_file, "r", errors="ignore")
        query_list = file.read().splitlines()

        new_query_list = []
        old_words = 0
        new_words = 0
        for query in tqdm(query_list):
            new_query = []
            for word in query.split(" "):
                old_words += 1
                if self.wordDict.get(word, False):
                    new_words += 1
                    new_word = self.getRootWord(word)

                    new_query.append(unidecode.unidecode(new_word))

            new_query_list.append(" ".join(new_query) + "\n")

        file.close()

        output_file_path = output_data_folder + os.sep + "refined_file.txt"
        output_file = open(output_file_path, "w")

        output_file.writelines(new_query_list)
        output_file.close()

        print("old WORDS: ", old_words, " New words: ", new_words)
        return output_file_path

    def trainContext(
        self,
        input_data_file=None,
        output_data_folder=None,
        epoch=5,
        pre_embedding_path=None,
    ):
        """
        This is a wrapper function to train context models, based on different parameters

        This function has the ability to train both a fasttext model or a custom_tensorflow model based on model type

        After training this sets the model object up

        To be called by train function
        """
        if self.model_type == "fasttext":
            self.model = fasttext.train_unsupervised(
                input_data_file, epoch=epoch, minn=0, maxn=0
            )
            self.model.save_model(output_data_folder + os.sep + "model_default")
        else:
            vocab_size = 10240
            sequence_length = 20
            window_size = 4
            num_ns = 3
            self.model = ContextLearner(
                file_path=input_data_file,
                output_folder=output_data_folder,
                vocab_size=vocab_size,
                sequence_length=sequence_length,
                window_size=window_size,
                num_ns=num_ns,
                pre_embedding_path=pre_embedding_path,
            ).train(epochs=epoch)

    def train(
        self,
        input_data_file=None,
        output_data_folder=None,
        epoch=5,
        refineFile=True,
        pre_embedding_path=None,
    ):
        """
        This is the complete wrapper function for handling the different traininng operations
        involving training symspell, creating word dictionaries, refining the file, trainig context and all

        After training all the trained files and models are saved in the output folder given and ready for inference.

        input parameters:
        input_data_file: txt file to be trained on
        output_data_folder: output folder for storing models and files
        epoch: Number of epochs for which the context needs to be trained
        refineFile: its a bool representing whether a refined file need to be created, or go with raw file itself
        pre_embedding_path: Feed already trained embeddings to learn new embeddings
        """
        if input_data_file is None:
            raise Exception("Please provide a input data file")

        if not os.path.exists(output_data_folder):
            os.makedirs(output_data_folder)

        self.sym_spell = SymSpell(
            max_dictionary_edit_distance=5, prefix_length=10, count_threshold=100
        )
        dict_path = self.createWordDict(
            input_data_file, output_data_folder, from_file=True
        )
        print("Learning word variations")
        self.sym_spell.load_dictionary(dict_path, 0, 1)
        if output_data_folder is not None:
            print("Saving word variations to disk")
            self.sym_spell.save_pickle(output_data_folder + os.sep + "model_dict.pkl")

        print("Learning context")
        if refineFile:
            input_data_file = self.refineTrainingFile(
                input_data_file, output_data_folder
            )
        self.trainContext(
            input_data_file,
            output_data_folder,
            epoch=epoch,
            pre_embedding_path=pre_embedding_path,
        )

    def get_context_score_bert(self, sentence):
        # Tokenize the sentence
        tokens = self.tokenizer.tokenize(sentence)

        # Loop over each token in the sentence and mask it out
        scores = []
        for i in range(len(tokens)):
            # Make a copy of the original token list
            masked_tokens = tokens.copy()

            # Mask out the i-th token
            masked_tokens[i] = "[MASK]"

            # Convert the masked token list back to a string
            masked_sentence = " ".join(masked_tokens)

            # Convert the masked sentence to input IDs for the model
            input_ids = self.tokenizer.encode(masked_sentence, return_tensors="pt")

            # Get the model's predictions for the masked tokens
            with torch.no_grad():
                outputs = self.model(input_ids)
                predictions = outputs[0].squeeze(0)

            # Get the predicted probability of the correct token for the i-th position
            masked_index = masked_tokens.index("[MASK]")
            target_token = tokens[i]
            target_token_id = self.tokenizer.convert_tokens_to_ids(target_token)
            target_token_prob = predictions[masked_index][target_token_id].item()
            #         print(predictions[masked_index][target_token_id])
            # Add the score to the list of scores
            scores.append(target_token_prob)

        # Calculate the average score for the sentence
        avg_score = sum(scores) / len(scores)

        avg_score = math.exp(avg_score) / (1 + math.exp(avg_score))

        return avg_score

    def getContextScore(self, sentence):
        """
        To get the context score of a sentence i.e. validity of a sentence contextually

        a score between 0.0 and 0.99

        """

        s_arr = self.removeStopWords(sentence.split())

        rwords = 0
        new_query = []
        for i in s_arr:
            rw = self.getRootWord(i)
            if self.model.get_word_id(rw) != -1:
                rwords += 1
            new_query.append(rw)

        sentence = " ".join(new_query)
        c_score = np.linalg.norm(self.model.get_sentence_vector(sentence)) * (
            rwords / max(1, len(s_arr))
        )

        if c_score > 0.99:
            return 0.0

        return c_score

    """# Analysis Context"""

    def custom_literal_eval(x):
        """
        To literal eval a string to proper list/dict
        """

        if isinstance(x, list):
            return x
        if x is np.nan:
            return []
        try:
            return ast.literal_eval(str(x))
        except Exception as e:
            print(e, x)
            return []

    def refine_suggestions(self, suggestions):
        # Refining suggestion
        sug_terms = [sug.term for sug in suggestions]
        # sug_counts = [sug.count for sug in suggestions]
        rem_sug = []
        for i, sug in enumerate(suggestions):
            p_noun = self.p.plural_noun(sug.term)
            if self.p.singular_noun(sug.term) == False and p_noun in sug_terms:
                if self.sym_spell.words.get(sug.term, 0) <= self.sym_spell.words.get(
                    p_noun, 0
                ):
                    rem_sug.append(i)

        suggestions = [i for j, i in enumerate(suggestions) if j not in rem_sug]

        return suggestions

    def isSingular(self, word):
        """
        Checks if a word is singular or not
        """
        return not self.p.singular_noun(word)

    def custom_lookup(self, term, n=20, compound_term=False):
        try:
            max_edit_distance = 5

            # suggestions = self.sym_spell.lookup(term, Verbosity.ALL, max_edit_distance=max_edit_distance,include_unknown=True)[:n]

            for i in range(1, max_edit_distance + 1):
                suggestions = self.sym_spell.lookup(
                    term,
                    Verbosity.ALL,
                    max_edit_distance=max_edit_distance,
                    include_unknown=True,
                )[:n]
                if len(suggestions) >= n:
                    break

            # #Refining Suggestions
            # suggestions = self.refine_suggestions(suggestions)

            s_dict = {}

            scaler = MinMaxScaler()
            temp = scaler.fit_transform([[sug.count] for sug in suggestions])

            for i, sug in enumerate(suggestions):
                s_dict[sug.term] = [temp[i][0], sug.distance, 0]

            # Refining Distance
            for key in s_dict.keys():
                if self.isSingular(key):
                    plural_key = self.p.plural_noun(key)
                    if s_dict.get(plural_key, False):
                        s_dict[plural_key][1] = min(
                            s_dict[key][1], s_dict[plural_key][1]
                        )

            # getting if its a rightword
            for key in s_dict.keys():
                if s_dict[key][1] == 0:
                    s_dict[key][2] = 1

            if compound_term:
                # for d in range(self.max_dictionary_edit_distance):
                #   c_term=self.sym_spell.lookup_compound(term, max_edit_distance=d)[0]
                #   split_terms=c_term.term.split()
                #   if s_dict.get(c_term.term,True) and ' ' in c_term.term and len(split_terms[0])!=1 and len(split_terms[1])!=1:
                #     s_dict[c_term.term] = [1.0,(c_term.distance)]

                c_term = self.sym_spell.word_segmentation(term)
                split_terms = c_term[1].split()
                if (
                    s_dict.get(c_term[1], True)
                    and " " in c_term[1]
                    and len(split_terms[0]) != 1
                    and len(split_terms[1]) != 1
                ):
                    s_dict[c_term[1]] = [1.0, (c_term[2]), 1]

        except Exception as e:
            print("Custom Lookup", term, e)
            raise e
        return s_dict

    def comparePhonetics(self, w1, w2):
        w_meta = self.dmeta(w1)

        if w_meta[0] is not None:
            w_len = len(w_meta[0])
        else:
            w_len = 0

        phone = self.dmeta(w2)[0]
        if (phone is not None) and (phone[:w_len] == w_meta[0]):
            return 1

        return 0

    def updatePhoneticScore(self, rwords, w_word):
        try:
            w_meta = self.dmeta(w_word)

            if w_meta[0] is not None:
                w_len = len(w_meta[0])
            else:
                w_len = 0

            w_fuzzy = fuzzy.nysiis(w_word)
            w_soundex = jellyfish.soundex(w_word)
            for w in rwords.keys():
                pscore = 0
                phone = self.dmeta(w)[0]
                if (phone is not None) and (phone[:w_len] == w_meta[0]):
                    pscore += 0.5
                if fuzzy.nysiis(w) == w_fuzzy:
                    pscore += 0.5
                if jellyfish.soundex(w) == w_soundex:
                    pscore += 1
                    # print(w)

                rwords[w] += [pscore]

            # Refining Phonetics for plural variants
            for key in rwords.keys():
                if self.isSingular(key):
                    plural_key = self.p.plural_noun(key)
                    if rwords.get(plural_key, False):
                        rwords[plural_key][-1] = max(
                            rwords[key][-1], rwords[plural_key][-1]
                        )

        except Exception as e:
            if "ascii" in str(e) and "fafsdfsdfsdfsdf" in str(e):
                return self.updatePhoneticScore(rwords, unidecode.unidecode(w_word))
            else:
                print("Phonetic Lookup", w_word, rwords, e)
                raise e
        return rwords

    def mergeSentences(self, sentences_old):
        sentences_new = []
        for s_old in sentences_old:
            if isinstance(s_old, str):
                q_arr = s_old.split()
            else:
                q_arr = s_old
            new_arr = [q_arr[0]]
            for i in range(1, len(q_arr)):
                gram_2 = new_arr[-1] + q_arr[i]
                if self.sym_spell.words.get(gram_2, 0) != 0:
                    new_arr.pop()
                    new_arr.append(gram_2)
                else:
                    new_arr.append(q_arr[i])

            k_new = " ".join(new_arr)
            sentences_new.append(k_new)

        return sentences_new

    def mergeSentencesDict(self, sentences_old_dict):
        sentences_new = self.mergeSentences(sentences_old_dict.keys())

        sentences_new_dict = {
            sentences_new[i]: sentences_old_dict[key]
            for i, key in enumerate(sentences_old_dict.keys())
        }

        return sentences_new_dict

    def getCombinationScores(self, sent="", scores={}, index=0):
        global sentence_scores, combinations, params_dict
        scores = scores.copy()
        if index == (len(combinations)):
            sent = sent[1:]
            scores["total_context_score"] = np.linalg.norm(
                scores["total_context_score"] / index
            )
            scores["total_score"] = (
                scores["total_score"] + scores["total_context_score"]
            ) / index
            sentence_scores.add((scores["total_score"], (sent, scores)))
            return

        if index == 0:
            scores = {
                "total_score": 0.0,
                "total_freq_score": 0.0,
                "total_dist_score": 0.0,
                "total_right_score": 0.0,
                "total_phone_score": 0.0,
                "total_context_score": np.array([0.0] * 100),
            }

        for word, values in combinations[index].items():
            temp_scores = scores.copy()
            freq_score = values[0] * params_dict["freq_param"]
            dist_score = (self.max_dictionary_edit_distance - values[1]) * params_dict[
                "dist_param"
            ]
            right_score = values[2] * params_dict["right_param"]
            phone_score = values[3] * params_dict["phone_param"]
            context_vec = (
                self.model.get_sentence_vector(self.getRootWord(word))
            ) * params_dict["context_param"]

            temp_scores["total_score"] += (
                freq_score + dist_score + phone_score + right_score
            )
            temp_scores["total_freq_score"] += freq_score
            temp_scores["total_dist_score"] += dist_score
            temp_scores["total_right_score"] += right_score
            temp_scores["total_phone_score"] += phone_score
            temp_scores["total_context_score"] = (
                temp_scores["total_context_score"] + context_vec
            )

            self.getCombinationScores(
                sent=sent + " " + word, scores=temp_scores.copy(), index=index + 1
            )

    def correct(
        self,
        query,
        top_n=1,
        compounding=True,
        top_words=5,
        merging=True,
        verbose=True,
        ignore_errors=False,
    ):
        global sentence_scores, combinations, params_dict
        try:
            params_dict = self.params_dict.copy()

            # For single words and no context
            if " " not in query:
                params_dict["context_param"] = 0.0
                # params_dict["phone_param"] = 500
                # params_dict["freq_param"] = 1000
                # params_dict["dist_param"] = 500
                # params_dict["right_param"] = 200

            sentences_total_score = {}

            query = re.sub("\W+", " ", query.lower())
            q_arr = query.split()

            if len(q_arr) > 5:
                top_words = 3
            if len(q_arr) > 10:
                top_words = 1

            combinations = []
            for q in q_arr:
                comb = self.custom_lookup(q, top_words, compound_term=compounding)

                comb = self.updatePhoneticScore(comb, q)

                combinations.append(comb)

            #########
            start = time.time()

            sentence_scores = MaxHeap(top_n)

            self.getCombinationScores()
            # print("----------------------")
            # print(sentence_scores.getTop())
            # print("----------------------")
            ########

            # start = time.time()
            # s = [comb.keys() for comb in combinations]
            # sentences = list(itertools.product(*s))

            # # if merging:
            # #   sentences= self.mergeSentences(sentences)

            # # print(sentences)
            # # print(combinations)

            # sentences_other_score={}
            # for i,sent in enumerate(sentences):

            #   # s_sent = ' '.join(self.removeStopWords(sent))
            #   s_sent = ' '.join(sent)

            #   # total_score=self.getContextScore("dummy")*0.0
            #   total_score=0.0
            #   total_freq_score = 0.0
            #   total_dist_score = 0.0
            #   total_right_score = 0.0
            #   total_phone_score = 0.0
            #   for j,word in enumerate(sent):

            #     comb = combinations[j][word]
            #     freq_score = comb[0]*params_dict["freq_param"]
            #     dist_score = (self.max_dictionary_edit_distance-comb[1])*params_dict["dist_param"]
            #     right_score = (comb[2]*params_dict["right_param"])
            #     phone_score = (comb[3]*params_dict["phone_param"])

            #     # context_score = params_dict["context_param"]*self.getContextScore(word)

            #     total_score+=freq_score + dist_score +phone_score+right_score
            #     total_freq_score+=freq_score
            #     total_dist_score+=dist_score
            #     total_right_score+=right_score
            #     total_phone_score+=phone_score

            #   total_context_score = np.linalg.norm(self.getContextScore(s_sent))*params_dict["context_param"]

            #   sentences_total_score[s_sent] = (total_score + total_context_score)/len(sent)

            #   sentences_other_score[s_sent] = {"Frequency":total_freq_score,"Phonetics":total_phone_score,"Distance score":total_dist_score, "Context": total_context_score}
            #   # sentences_total_score[s_sent] = print(np.linalg.norm(self.getContextScore(s_sent)))

            # # print(context_score, other_score)

            # sentences_total_score = {i:sentences_total_score[i]/1000 for i in nlargest(top_n, sentences_total_score, key = sentences_total_score.get)}

            # end = time.time()
            # print("Time2: ",end - start)

            sentences_total_score = {}
            for tuple in sentence_scores.getTop():
                sentences_total_score[tuple[1][0]] = tuple[1][1]

        except Exception as e:
            print("Spell Checker", query, e)
            if not ignore_errors:
                raise e

        # for key in sentences_total_score.keys():
        #   sentences_total_score[key] = {**{"Total_score":sentences_total_score[key]}, **sentences_other_score.get(key,{})}

        if merging:
            sentences_total_score = self.mergeSentencesDict(sentences_total_score)

        if verbose:
            print(json.dumps(sentences_total_score, indent=4))
        return sentences_total_score

    def batch_queries(self, queries, output_file=None):
        corrected_queries = []
        for i, q in enumerate(queries):
            corrected_queries.append(self.correct(q))

        if output_file is not None:
            with open(output_file, "w") as outfile:
                outfile.write("\n".join(corrected_queries))

        return corrected_queries


if __name__ == "__main__":
    # sc = Query_Corrector(
    #     model_path="/Users/anmolgoyal/Desktop/Couture/Spell Checker/trained_models/Iterations_Final")
    sc = QueryCorrector(
        model_path="/Users/anmolgoyal/Desktop/Couture/Spell Checker/trained_models/Iterations_9"
    )
    sc.correct("dupattas for woman", 5)
    sc.correct("manshirts", 5)
    sc.correct("bridal lehnga", 5)
    sc.correct("nike thousand off", 5)
    sc.correct("t shirts", 5)
    sc.correct("red tape", 5)
    sc.correct("shitrs", 5)
    sc.correct("lenght", 5)
    sc.correct("shirts man", 5)
    sc.correct("slingbags", 5)
    sc.correct("kurtas for women", 5)

    # print(sc.getContextScore("dupattas for woman"), sc.getRootWord("dupattas"))
    # print(sc.getContextScore("dupatta for woman"), sc.getRootWord("dupatta"))

    # df = pd.read_csv("/Users/anmolgoyal/Downloads/top_50000_stepwise_output.csv")[["query","spell_check","match_phrases"]]
    # df["corrected_queries"] = df["query"].progress_apply(sc.correct, verbose=False, ignore_errors=True)
    # df.to_csv("/Users/anmolgoyal/Downloads/Corrected_top_50000_stepwise_output.csv")
    # print(sc.custom_lookup("short", n=10, compound_term=False))

    # print(sc.sym_spell.lookup_compound("t shirts",max_edit_distance=5)[0].term)
    # print(sc.stop_word_list)
    # df = pd.read_parquet("/Users/anmolgoyal/Downloads/Wrong2RightUpdatedHistory")
    # df = pd.read_csv("/Users/anmolgoyal/Desktop/Couture/RightWords/RightWordsDF.csv")
    # df = pd.read_parquet(
    #     "/Users/anmolgoyal/Desktop/Couture/RightWords/Rightwords")

    df = pd.read_csv("/Users/anmolgoyal/Downloads/26042022/Generated_Df_RW.csv")
    # print(df["count"])
    # print(df["count"].tolist())
    sc.addRightWords(df["rightword"].tolist(), df["count"].tolist())
    # print(sc.rightwords)

    # sc.train(input_data_file="/Users/anmolgoyal/Desktop/Couture/Spell Checker/training_data/train_data_new.txt",
    #          output_data_folder="/Users/anmolgoyal/Desktop/Couture/Spell Checker/trained_models/Iterations_Final", epoch=10, refineFile=True)
    # sc.train(input_data_file="/Users/anmolgoyal/Desktop/Couture/Spell Checker/training_data/train_data_new.txt",
    #          output_data_folder="/Users/anmolgoyal/Desktop/Couture/Spell Checker/trained_models/Iterations_9", epoch=10, refineFile=True, pre_embedding_path="/Users/anmolgoyal/Downloads/glove.6B.100d.txt")
