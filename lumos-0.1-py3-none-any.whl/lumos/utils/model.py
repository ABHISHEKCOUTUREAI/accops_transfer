import numpy as np
import pandas as pd


class ContextModel:
    """
    A model for representing and manipulating context vectors of words and sentences.

    This class loads word vectors and metadata from specified files and provides methods
    to retrieve word IDs and compute sentence vectors based on the loaded word vectors.

    Attributes:
        model_path (str): The path to the directory containing the model files.
        model (dict): A dictionary mapping words to their vector representations.
        word_id (dict): A dictionary mapping words to their unique IDs.
        model_len (int): The length of the vector representations.

    Methods:
        __init__(self, model_path): Initializes the ContextModel instance, loading model
            data from the specified path.
        setup_model(self): Reads the metadata and vector files, populates the `model`
            and `word_id` attributes, and computes the length of the vector representations.
        get_word_id(self, word): Returns the ID of the given word, or -1 if not found.
        get_sentence_vector(self, sentence): Computes and returns the average normalized
            vector representation of the given sentence.
    """

    def __init__(self, model_path):
        """
        Initializes the ContextModel instance.

        Args:
            model_path (str): The path to the directory containing the model files.
        """
        self.model_path = model_path
        self.setup_model()

    def setup_model(self):
        """
        Reads model data from files, initializes model attributes, and computes the
        length of the vector representations.

        This method loads word metadata and vectors from corresponding files in the
        `model_path` directory, constructs the `model` and `word_id` dictionaries,
        and calculates the length of vector representations.
        """
        md = pd.read_csv(self.model_path + "metadata.tsv", sep="\t", names=["words"])
        vec = pd.read_csv(self.model_path + "vectors.tsv", sep="\t", header=None)

        self.model = {}
        self.word_id = {}
        for i, word in enumerate(md["words"]):
            self.model[word] = np.array(list(map(float, vec.iloc[i])))
            self.word_id[word] = i

        # print(self.model)
        self.model_len = self.model[next(iter(self.model))].shape[0]
        # print(self.model_len)

    def get_word_id(self, word):
        """
        Returns the ID of the given word if it exists in the model, otherwise -1.

        Args:
            word (str): The word whose ID is to be retrieved.

        Returns:
            int: The ID of the word, or -1 if the word is not found in the model.
        """
        return self.word_id.get(word, -1)

    def get_sentence_vector(self, sentence):
        """
        Computes and returns the average normalized vector representation of a sentence.

        The method splits the sentence into words, sums up their normalized vectors (if
        available in the model), and divides by the number of words to get the average
        normalized vector.

        Args:
            sentence (str): The sentence to be vectorized.

        Returns:
            numpy.ndarray: The average normalized vector representation of the sentence.
        """
        s_arr = sentence.split(" ")
        c_vec = np.array([0.0] * self.model_len)
        for word in s_arr:
            if self.word_id.get(word, -1) != -1:
                c_vec += self.model[word] / np.linalg.norm(self.model[word])

        return c_vec / len(s_arr)
