import tensorflow as tf
from tensorflow.keras import layers


class Word2Vec(tf.keras.Model):
    """
    Word2Vec model for generating word embeddings.

    This model creates embeddings for a target word and its context words, suitable for use in
    natural language processing tasks. It utilizes the skip-gram architecture from Word2Vec to
    learn word embeddings.

    Attributes:
        target_embedding (tf.keras.layers.Embedding): Embedding layer for the target words.
        context_embedding (tf.keras.layers.Embedding): Embedding layer for the context words.

    Parameters:
        vocab_size (int): Size of the vocabulary.
        embedding_dim (int): Dimensionality of the embedding vector.
        num_ns (int): Number of negative samples for each positive context word.
        embedding_matrix (array-like): Initial embedding matrix.

    Methods:
        call(pair): Performs the forward pass of the model.
        custom_loss(x_logit, y_true): Calculates the custom loss for the model using sigmoid cross-entropy.

    The `call` method takes a pair of `target` and `context` as input, where `target` is the word to be
    embedded and `context` includes the context words. It returns the dot products of the embeddings
    of the target word with each of its context words, which can be used to calculate the similarity
    between the target word and its context.

    The static method `custom_loss` computes the loss using sigmoid cross-entropy, which is suitable
    for training the Word2Vec model on a binary classification task where the goal is to distinguish
    between true context words from negative samples.
    """

    def __init__(self, vocab_size, embedding_dim, num_ns, embedding_matrix):
        super(Word2Vec, self).__init__()
        self.target_embedding = layers.Embedding(
            vocab_size,
            embedding_dim,
            input_length=1,
            name="w2v_embedding",
            embeddings_initializer=tf.keras.initializers.Constant(embedding_matrix),
        )
        self.context_embedding = layers.Embedding(
            vocab_size, embedding_dim, input_length=num_ns + 1
        )

    def call(self, pair):
        """
        Performs the forward pass of the model.

        Args:
            pair (tuple of tf.Tensor): A tuple containing the target and context words.
            The target tensor shape is expected to be (batch, 1) and context tensor shape is
            (batch, num_ns + 1) where `num_ns` is the number of negative samples.

        Returns:
            tf.Tensor: The dot products of the target and context embeddings. Shape is (batch, num_ns + 1),
            representing the similarity of the target word with each of its context words.
        """
        target, context = pair
        # target: (batch, dummy?)  # The dummy axis doesn't exist in TF2.7+
        # context: (batch, context)
        if len(target.shape) == 2:
            target = tf.squeeze(target, axis=1)
        # target: (batch,)
        word_emb = self.target_embedding(target)
        # word_emb: (batch, embed)
        context_emb = self.context_embedding(context)
        # context_emb: (batch, context, embed)
        dots = tf.einsum("be,bce->bc", word_emb, context_emb)
        # dots: (batch, context)
        return dots

    def custom_loss(x_logit, y_true):
        """
        Custom loss function for the Word2Vec model.

        Args:
            x_logit (tf.Tensor): Logits predicted by the model.
            y_true (tf.Tensor): True labels.

        Returns:
            tf.Tensor: The computed loss using sigmoid cross-entropy.
        """
        return tf.nn.sigmoid_cross_entropy_with_logits(logits=x_logit, labels=y_true)
