from collections import namedtuple

score_template = namedtuple(
    "score_template",
    [
        "total_freq_score",
        "total_dist_score",
        "total_phone_score",
        "total_right_score",
        "total_context_score",
        "total_score",
        "sent_components",
    ],
    defaults=[0, 0, 0, 0, 0, 0, []],
)


params_template = namedtuple(
    "params_template",
    [
        "context_param",
        "phone_param",
        "freq_param",
        "dist_param",
        "right_param",
    ],
    defaults=[10, 5000, 1, 1000.0, 2000.0],
)
