from heapq import heapify, heappush, heappushpop, nlargest


class MaxHeap:
    """Max Heap Data Structure Wrapper"""

    def __init__(self, top_n):
        self.h = []
        self.length = top_n
        heapify(self.h)

    def add(self, element):
        if len(self.h) < self.length:
            heappush(self.h, element)
        else:
            heappushpop(self.h, element)

    def getTop(self):
        return nlargest(self.length, self.h)
