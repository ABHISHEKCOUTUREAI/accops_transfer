import io
import os
import re
import string

import numpy as np
import tensorflow as tf
from tensorflow.keras import layers

from lumos.utils import ContextModel
from lumos.utils.word2vec import Word2Vec


class ContextLearner:
    """
    A machine learning model class designed for learning word contexts and embeddings from text data.
    It utilizes TensorFlow to preprocess text data, generate training data, and train a Word2Vec model.

    Attributes:
        file_path (str, optional): Path to the text file used for training. Defaults to None.
        output_folder (str, optional): Path to the folder where the output embeddings will be saved. Defaults to None.
        vocab_size (int): The size of the vocabulary. Defaults to 2048.
        sequence_length (int): The length of the sequences to be considered for model training. Defaults to 20.
        window_size (int): The size of the window to be considered for creating context pairs. Defaults to 4.
        num_ns (int): Number of negative samples to be selected for each positive sample in training. Defaults to 3.
        pre_embedding_path (str, optional): Path to pre-trained embeddings. Defaults to None.

    Methods:
        getDataset(): Initializes the dataset from the file path provided.
        custom_standardization(input_data): Standardizes the input data by converting it to lowercase and removing punctuation.
        createEmbeddingMatrix(): Prepares the embedding matrix either from scratch or using pre-trained embeddings if available.
        text_vectorize(): Creates and adapts a TextVectorization layer for converting text to vector form.
        generate_training_data_sequence(sequences, window_size, num_ns, vocab_size, seed): Generates training data using the skip-gram model with negative sampling.
        save_weights(word2vec): Saves the weights of the trained Word2Vec model along with the vocabulary.
        dataset_generator(): Yields batches of training data.
        train(epochs): Trains the Word2Vec model using the generated dataset for a specified number of epochs.
    """

    def __init__(
        self,
        file_path=None,
        output_folder=None,
        vocab_size=2048,
        sequence_length=20,
        window_size=4,
        num_ns=3,
        pre_embedding_path=None,
    ):
        self.file_path = file_path
        self.output_folder = output_folder
        self.output_path = ""

        self.text_ds = None
        self.getDataset()

        # Define the vocabulary size and the number of words in a sequence.
        self.vocab_size = vocab_size
        self.sequence_length = sequence_length

        self.BATCH_SIZE = 1024
        self.BUFFER_SIZE = 10000

        self.embedding_dim = 100

        self.vectorize_layer = None

        self.window_size = window_size

        self.num_ns = num_ns

        self.pre_embedding_path = pre_embedding_path

    def getDataset(self):
        self.text_ds = tf.data.TextLineDataset(self.file_path).filter(
            lambda x: tf.cast(tf.strings.length(x), bool)
        )

    # Now, create a custom standardization function to lowercase the text and
    # remove punctuation.

    def custom_standardization(self, input_data):
        lowercase = tf.strings.lower(input_data)
        return tf.strings.regex_replace(
            lowercase, "[%s]" % re.escape(string.punctuation), ""
        )

    def createEmbeddingMatrix(self):
        # Prepare embedding matrix
        print("Creating embedding matrix")
        embedding_matrix = np.zeros((self.vocab_size, self.embedding_dim))
        if self.pre_embedding_path is not None:
            # Setup Pre embedding vectors

            embeddings_index = {}
            with open(self.pre_embedding_path) as f:
                for line in f:
                    word, coefs = line.split(maxsplit=1)
                    coefs = np.fromstring(coefs, "f", sep=" ")
                    embeddings_index[word] = coefs

            print("Found %s word vectors." % len(embeddings_index))

            hits = 0
            misses = 0
            for i, word in enumerate(self.vectorize_layer.get_vocabulary()):
                embedding_vector = embeddings_index.get(word)
                if embedding_vector is not None:
                    # Words not found in embedding index will be all-zeros.
                    # This includes the representation for "padding" and "OOV"
                    embedding_matrix[int(i)] = embedding_vector
                    hits += 1
                else:
                    misses += 1
            print("Converted %d words (%d misses)" % (hits, misses))

        return embedding_matrix

    def text_vectorize(self):
        # Use the `TextVectorization` layer to normalize, split, and map strings to
        # integers. Set the `output_sequence_length` length to pad all samples to the
        # same length.
        vectorize_layer = layers.TextVectorization(
            standardize=self.custom_standardization,
            max_tokens=self.vocab_size,
            output_mode="int",
            output_sequence_length=self.sequence_length,
        )

        vectorize_layer.adapt(self.text_ds.batch(1024))

        # Save the created vocabulary for reference.
        inverse_vocab = vectorize_layer.get_vocabulary()
        print(inverse_vocab[:20])

        return vectorize_layer

    # Generates skip-gram pairs with negative sampling for a list of sequences
    # (int-encoded sentences) based on window size, number of negative samples
    # and vocabulary size.

    def generate_training_data_sequence(
        self, sequences, window_size, num_ns, vocab_size, seed
    ):
        # Elements of each training example are appended to these lists.
        targets, contexts, labels = [], [], []

        for sequence in sequences:
            # Iterate over all sequences (sentences) in the dataset.
            # Generate positive skip-gram pairs for a sequence (sentence).
            positive_skip_grams, _ = tf.keras.preprocessing.sequence.skipgrams(
                sequence,
                vocabulary_size=vocab_size,
                sampling_table=self.sampling_table,
                window_size=window_size,
                negative_samples=0,
            )

            # Iterate over each positive skip-gram pair to produce training examples
            # with a positive context word and negative samples.
            for target_word, context_word in positive_skip_grams:
                context_class = tf.expand_dims(
                    tf.constant([context_word], dtype="int64"), 1
                )
                (
                    negative_sampling_candidates,
                    _,
                    _,
                ) = tf.random.log_uniform_candidate_sampler(
                    true_classes=context_class,
                    num_true=1,
                    num_sampled=num_ns,
                    unique=True,
                    range_max=vocab_size,
                    seed=seed,
                    name="negative_sampling",
                )

                # Build context and label vectors (for one target word)
                negative_sampling_candidates = tf.expand_dims(
                    negative_sampling_candidates, 1
                )

                context = tf.concat([context_class, negative_sampling_candidates], 0)
                label = tf.constant([1] + [0] * num_ns, dtype="int64")

                # Append each element from the training example to global lists.
                targets.append(target_word)
                contexts.append(context)
                labels.append(label)

        return targets, contexts, labels

    def save_weights(self, word2vec):
        weights = word2vec.get_layer("w2v_embedding").get_weights()[0]
        vocab = self.vectorize_layer.get_vocabulary()

        if self.output_folder is not None:
            self.output_path = self.output_folder + os.sep

        out_v = io.open(self.output_path + "vectors.tsv", "w", encoding="utf-8")
        out_m = io.open(self.output_path + "metadata.tsv", "w", encoding="utf-8")

        for index, word in enumerate(vocab):
            if index == 0:
                continue  # skip 0, it's padding.
            vec = weights[index]
            out_v.write("\t".join([str(x) for x in vec]) + "\n")
            out_m.write(word + "\n")
        out_v.close()
        out_m.close()

    def dataset_generator(self):
        total_batches = int(len(self.sequences) / self.BATCH_SIZE) + 1

        while True:
            for i in range(total_batches):
                targets, contexts, labels = self.generate_training_data_sequence(
                    self.sequences[i * self.BATCH_SIZE : (1 + i) * self.BATCH_SIZE],
                    window_size=self.window_size,
                    num_ns=self.num_ns,
                    vocab_size=self.vocab_size,
                    seed=1,
                )

                targets = np.array(targets)
                contexts = np.array(contexts)[:, :, 0]
                labels = np.array(labels)

                if i == 0:
                    print("\n")
                    print(f"targets.shape: {targets.shape}")
                    print(f"contexts.shape: {contexts.shape}")
                    print(f"labels.shape: {labels.shape}")

                # dataset = tf.data.Dataset.from_tensor_slices(((targets, contexts), labels))
                # dataset = dataset.shuffle(self.BUFFER_SIZE).batch(self.BATCH_SIZE, drop_remainder=True)

                # dataset = dataset.cache().prefetch(buffer_size=tf.data.AUTOTUNE)
                # print(dataset)
                # yield dataset

                yield ((targets, contexts), labels)

    def train(self, epochs):
        self.vectorize_layer = self.text_vectorize()
        embedding_matrix = self.createEmbeddingMatrix()

        # Vectorize the data in text_ds.
        text_vector_ds = (
            self.text_ds.batch(1024)
            .prefetch(tf.data.AUTOTUNE)
            .map(self.vectorize_layer)
            .unbatch()
        )

        print("Sequences Created")

        # Build the sampling table for `vocab_size` tokens.
        self.sampling_table = tf.keras.preprocessing.sequence.make_sampling_table(
            self.vocab_size
        )

        self.sequences = list(text_vector_ds.as_numpy_iterator())
        print(len(self.sequences))

        word2vec = Word2Vec(
            self.vocab_size,
            self.embedding_dim,
            num_ns=4,
            embedding_matrix=embedding_matrix,
        )
        word2vec.compile(
            optimizer="adam",
            loss=tf.keras.losses.CategoricalCrossentropy(from_logits=True),
            metrics=["accuracy"],
        )

        tensorboard_callback = tf.keras.callbacks.TensorBoard(log_dir="logs")

        print("Model Training")
        word2vec.fit(
            self.dataset_generator(),
            epochs=epochs,
            steps_per_epoch=int(len(self.sequences) / self.BATCH_SIZE) + 1,
            callbacks=[tensorboard_callback],
        )

        self.save_weights(word2vec)

        return ContextModel(self.output_path)


if __name__ == "__main__":
    cl = ContextLearner(
        file_path="/Users/anmolgoyal/Downloads/train_data.txt",
        output_folder="/Users/anmolgoyal/Desktop/Couture/Spell Checker/trained_models/Iterations_6",
        vocab_size=10240,
        sequence_length=20,
        window_size=5,
        pre_embedding_path="/Users/anmolgoyal/Downloads/glove.6B.100d.txt",
    )

    cl.train()
