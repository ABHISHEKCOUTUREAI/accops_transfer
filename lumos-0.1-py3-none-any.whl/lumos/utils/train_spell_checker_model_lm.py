import json

import pandas as pd

from lumos import QueryCorrectorLM


def init_model(model_path):
    global sc
    print("Initiating Module")
    sc = QueryCorrectorLM(model_path=model_path)


def test_trained_model(model_path):
    global sc
    sc = QueryCorrectorLM.load_trained_model(model_path)
    dummy_query = "shurts for men"

    print("Testing trained model with dummy query {}".format(dummy_query))
    print(sc.ensemble_correct(dummy_query, return_all=True))
    print(sc.ensemble_correct("shirtsformen under 1000", return_all=True))
    print(sc.ensemble_correct("boxer shurts", return_all=True))


if __name__ == "__main__":
    # print("Fetching command  line parameters")
    # # Create an argument parser
    # parser = argparse.ArgumentParser(description="Training Autosuggest")

    # # Define the named arguments
    # parser.add_argument(
    #     "--model_path",
    #     type=str,
    #     help="The path where the model needs to be trained and saved",
    # )
    # parser.add_argument(
    #     "--df_path",
    #     type=str,
    #     help="Dataframe of final queries",
    # )
    # parser.add_argument(
    #     "--synonym_path",
    #     type=str,
    #     default="/Users/anmol1.goyal/Desktop/Couture/AutoSuggest/synonyms.csv",
    #     help="Synonyms used",
    # )

    # # Parse the command-line arguments
    # args = parser.parse_args()

    # # Accessing named command-line arguments
    # model_path = args.model_path
    # df_path = args.df_path
    # synonym_path = args.synonym_path

    model_path = "/Users/anmol1.goyal/Desktop/Couture/phase2-search/Spell Checker/trained_models/LM_model"
    # context_model_path = "/Users/anmol1.goyal/Desktop/Couture/Semantic Search/saved_model/bert_pretrained_history_interactions"
    context_model_path = "/Users/anmol1.goyal/Desktop/Couture/Semantic Search/saved_model/bert_pretrained_history_interactions_self_tokenizer"
    tokenizer_path = "/Users/anmol1.goyal/Desktop/Couture/Semantic Search/saved_model/tokenizer-bert-base-ajio-history-interaction-dict-fast/"
    rightword_path = "/Users/anmol1.goyal/Downloads/22082023_new/Rightwords"
    w2r_path = "/Users/anmol1.goyal/Downloads/22082023_new/w2r (2).json"
    w2r_exception_path = "/Users/anmol1.goyal/Downloads/22082023_new/w2rMappingsAfterInternalBrandSynonymsNewWithoutShrts"
    w2r_exception_csr_path = (
        "/Users/anmol1.goyal/Downloads/22082023_new/CategorySynonymsRefined"
    )

    # Perform actions based on the arguments
    print(f"Final Model path: {model_path}")
    print(f"Context Model path: {context_model_path}")
    print(f"Tokenizer Model path: {tokenizer_path}")
    print(f"Rightword path: {rightword_path}")
    print(f"W2R path: {w2r_path}")
    print(f"W2R Exception path: {w2r_exception_path}")
    print(f"W2R Exception CSR path: {w2r_exception_csr_path}")

    if model_path is not None:
        init_model(model_path=model_path)
    else:
        print("Error: Please specify a model path")
        exit

    ################# Prparing dfs and Training #################

    # Rightwords
    rightword_dict = (
        pd.read_parquet(rightword_path, columns=["rightword", "count"])
        .set_index("rightword")
        .to_dict()["count"]
    )

    # W2Rs
    with open(w2r_path) as f:
        w2r = json.load(f)

    # W2R exceptions
    w2r_df = pd.read_parquet(
        w2r_exception_path, columns=["wrongword", "rightword", "type", "iscategory"]
    )
    w2r_exceptions = set(
        w2r_df[
            w2r_df["type"].isin(
                [
                    "rightword_brandsynonym",
                    "rightword_internalbrandsynonyms",
                    "hinglish",
                    "manually_tagged",
                    "manual_changes",
                    "hinglish_internalbrandsynonyms",
                    "hinglish_brandsynonym",
                    "manually_tagged_internalbrandsynonyms",
                    "manually_tagged_brandsynonym",
                    "manual",
                ]
            )
        ]["wrongword"]
    )
    w2r_exceptions.update(
        set(pd.read_parquet(w2r_exception_csr_path, columns=["wrongword"])["wrongword"])
    )

    ##Fixed words
    is_categories = set(
        w2r_df[w2r_df["iscategory"] & w2r_df["rightword"].isin(rightword_dict)][
            "rightword"
        ]
    )

    #### Training
    sc.load_context_model(context_model_path, tokenizer_path)
    sc.addRightWords(rightword_dict=rightword_dict)
    sc.addW2R(w2r)
    sc.addW2R_exception(w2r_exceptions)
    sc.add_fixed_words(is_categories)
    sc.train()

    #############################################################

    test_trained_model(model_path)
