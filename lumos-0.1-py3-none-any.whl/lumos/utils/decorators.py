import functools
from collections import deque


class FunctionCache:
    """
    To cache functions in memory
    """

    def __init__(self, max_cache_size):
        self.max_cache_size = max_cache_size
        self.cache = {}
        self.cache_order = deque()

    def __call__(self, method):
        @functools.wraps(method)
        def wrapper(instance, *args, **kwargs):
            key = (id(instance), method.__name__, args, frozenset(kwargs.items()))
            if key in self.cache:
                # Move the accessed item to the front of the cache order
                self.cache_order.remove(key)
                self.cache_order.appendleft(key)
                return self.cache[key]

            result = method(instance, *args, **kwargs)
            self.cache[key] = result
            self.cache_order.appendleft(key)

            # Check if the cache size exceeds the maximum limit
            if len(self.cache) > self.max_cache_size:
                self.evict_oldest()

            return result

        return wrapper

    def evict_oldest(self):
        if self.cache_order:
            oldest_key = self.cache_order.pop()
            del self.cache[oldest_key]
