from fastapi import APIRouter, Form, HTTPException
from ..models import AssortmentOutput
from ..db import postgres_db
from sqlalchemy import and_, insert, update, select
from fastapi.responses import JSONResponse
from pydantic import BaseModel
from typing import List, Dict, Any
from sqlalchemy.exc import IntegrityError


crud = APIRouter(prefix="/couture/assortment", tags=["crud"])

class CustomForm(BaseModel):
    zone: str  
    state: str
    city: str
    br_code: str
    L0: str 
    L1: str 
    L2: str 
    L3: str 
    request_data: List[Dict[str, Any]]



@crud.post("/append", operation_id="add-assortment")
async def append_asssortment(
 request: CustomForm 
):
    try:  
        form_data = request
        # Get the column names from the model and  set all columns to None)
        column_names = [column.name for column in AssortmentOutput.__table__.columns]
        default_values = {column: None for column in column_names}

        # Initialize an empty list to store the processed dictionaries
        processed_data = []
        for data_dict in form_data.request_data:
            # Convert specific fields to integers
            for field in ['sap_id', 'total_amount', 'total_margin', 'num_qty_sold', 'min_qty', 'max_qty']:
                if field in data_dict and data_dict[field] is not None:
                    if data_dict[field] != '':
                       data_dict[field] = int(float(data_dict[field]))
                    else:
                       data_dict[field] = 0

            data_dict = {column: data_dict.get(column, default_values[column]) for column in column_names}

            # Update data_dict with common values
            data_dict.update({
                "zone": form_data.zone,
                "state": form_data.state,
                "city": form_data.city,
                "br_code": form_data.br_code,
                "L0": form_data.L0,
                "L1": form_data.L1,
                "L2": form_data.L2,
                "L3": form_data.L3,
                "exist_in_model_output": 1,
                'del_flag': 0
            })

            # Append the updated dictionary to the list
            processed_data.append(data_dict)
        
        status_messages = []
        # Check if the combination of sap_id and br_code already exists
        for data_dict in processed_data:
            existing_row = await postgres_db.fetch_one(
                select([AssortmentOutput]).where(
                    (AssortmentOutput.sap_id == data_dict['sap_id']) &
                    (AssortmentOutput.br_code == data_dict['br_code'])
                )
            )

            if existing_row:
                # Update the existing row
                await postgres_db.execute(
                    update(AssortmentOutput).where(
                        (AssortmentOutput.sap_id == data_dict['sap_id']) &
                        (AssortmentOutput.br_code == data_dict['br_code'])
                    ).values(data_dict)
                )
                status_messages.append(f"Sap_id {data_dict['sap_id']} updated successfully")
            else:
                # Insert a new row
                await postgres_db.execute(
                    insert(AssortmentOutput).values(data_dict)
                )
                status_messages.append(f"Sap_id {data_dict['sap_id']} added successfully")

        # Construct the final response message
        response_message = ", ".join(status_messages)
        return JSONResponse(content={"message": response_message}, status_code=201)



    except IntegrityError as e:
        # Handle duplicate key violation
        return HTTPException(status_code=400, detail=f"Duplicate key violation: {str(e)}")


    except Exception as e:
        return HTTPException(status_code=400,  detail=f"Error in adding file to db {str(e)}")  



@crud.delete("/delete", operation_id="delete-assortment")
async def delete_asssortment(
    br_code: str = Form(None),
    sap_ids: list[int] = Form([]),
):

    try:
        if br_code is None or sap_ids is None:
            raise HTTPException(status_code=400, detail={"message": "Either br_code or sap_id must be provided for deletion"})
        condition = []
        if br_code is not None:
            condition.append(AssortmentOutput.br_code == br_code)
        if sap_ids:
            condition.append(AssortmentOutput.sap_id.in_(sap_ids))

        if not condition:
            raise HTTPException(status_code=400, detail="No conditions provided for deletion")


        # Update the rows matching the conditions
        query = update(AssortmentOutput).where(and_(*condition)).values(del_flag=1, exist_in_model_output=0)
        await postgres_db.execute(query)

        return JSONResponse(content={"message": "Data deleted successfully"}, status_code=201)
    
    except HTTPException as http_exception:
        raise http_exception   
     
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Error updating rows: {str(e)}")