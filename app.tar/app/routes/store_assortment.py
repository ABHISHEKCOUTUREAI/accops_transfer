import csv
from itertools import groupby
from fastapi import APIRouter, Form, Depends
from io import StringIO
from fastapi.responses import StreamingResponse
from app.models import  CityLevelAssortment, StateLevelAssortment
from sqlalchemy import func, select, and_
from .common import get_postgres_db
from ..utils import decimal_serializer, order_clause_store_assortment, form_store_assortment_query
from app.db import redis_db
from app.utils import decimal_serializer
import json

store_assortment = APIRouter(prefix="/couture/assortment", tags=["store_assortment"])


def build_condition(query, L0, L1, L2, L3, mfac_name, brand_name):
    condition = []

    if L0 is not None:
        condition.append(query.c.L0 == L0)
    if L1 is not None:
        condition.append(query.c.L1 == L1)
    if L2 is not None:
        condition.append(query.c.L2 == L2)
    if L3 is not None:
        condition.append(query.c.L3 == L3)

    if mfac_name is not None:
        condition.append(query.c.mfac_name == mfac_name)
    if brand_name is not None:
        condition.append(query.c.brand_name == brand_name)

    return condition


@store_assortment.post("/store-assortment", operation_id="fetch-store-assortment")   
async def fetch_store_assortment(
    region_type: str = Form(None),
    region_name: str = Form(None),
    L0: str = Form(None),
    L1: str = Form(None),
    L2: str = Form(None),
    L3: str = Form(None),
    mfac_name: str = Form(None),
    brand_name: str = Form(None),
    page_no: int = Form(1),
    page_count: int = Form(100),
    sort_param: str = Form(None),
    sort_type: str = Form(None),
    postgres_db = Depends(get_postgres_db),
    flag: bool = Form(True),
    store_size: str = Form(None),
):
    cache_key = f"store-assortment:{region_type}:{region_name}:{L0}:{L1}:{L2}:{L3}:{mfac_name}:{brand_name}:{page_no}:{sort_param}:{sort_type}:{sort_param}:{sort_type}:{flag}:{page_count}:{store_size}"
    response = await redis_db.get(cache_key)
    if response:
        result = json.loads(response)
        return result

    if region_type == "State":
        query = form_store_assortment_query(StateLevelAssortment, region_type, region_name)
    else:
        query = form_store_assortment_query(CityLevelAssortment, region_type, region_name)
    
    condition = build_condition(query, L0, L1, L2, L3, mfac_name, brand_name)

    query = select([query]).where(and_(*condition)).subquery()

    order_by_clause = order_clause_store_assortment(sort_param, sort_type)

    large_size_query = select([query]).where(query.c.br_code == 'NewStore-LargeSized').order_by(order_by_clause)

    mid_size_query = select([query]).where(query.c.br_code == 'NewStore-MidSized').order_by(order_by_clause)
    
    small_size_query = select([query]).where(query.c.br_code == 'NewStore-SmallSized').order_by(order_by_clause)

    if flag:
        offset = (page_no - 1) * page_count
        large_size_query = large_size_query.limit(page_count).offset(offset)
        mid_size_query = mid_size_query.limit(page_count).offset(offset)
        small_size_query = small_size_query.limit(page_count).offset(offset)

    large_size_rows = await postgres_db.fetch_all(large_size_query)
    mid_size_rows = await postgres_db.fetch_all(mid_size_query)
    small_size_rows = await postgres_db.fetch_all(small_size_query)


    large_count_query = select([func.count().label('large_count')]).where(query.c.br_code == 'NewStore-LargeSized')
    large_count = await postgres_db.fetch_val(large_count_query)

    mid_count_query = select([func.count().label('mid_count')]).where(query.c.br_code == 'NewStore-MidSized')
    mid_count = await postgres_db.fetch_val(mid_count_query)

    small_count_query = select([func.count().label('small_count')]).where(query.c.br_code == 'NewStore-SmallSized')
    small_count = await postgres_db.fetch_val(small_count_query)

    result_dict = {}  # Dictionary to store results grouped by 'br_code'

    result_dict["LargeSized"] = [dict(row) for row in large_size_rows]
    result_dict["MidSized"] = [dict(row) for row in mid_size_rows]
    result_dict["SmallSized"] = [dict(row) for row in small_size_rows]
 
    result_dict['LargeSized_count'] = large_count
    result_dict['MidSized_count'] = mid_count
    result_dict['SmallSized_count'] = small_count

    serialized_data = json.dumps(result_dict, default=decimal_serializer)
    await redis_db.set(cache_key, serialized_data)

    return result_dict


@store_assortment.post("/store-assortment-csv", operation_id="fetch-store-assortment-csv")   
async def fetch_store_assortment_csv(
    region_type: str = Form(None),
    region_name: str = Form(None),
    L0: str = Form(None),
    L1: str = Form(None),
    L2: str = Form(None),
    L3: str = Form(None),
    mfac_name: str = Form(None),
    brand_name: str = Form(None),
    sort_param: str = Form(None),
    sort_type: str = Form(None),
    postgres_db = Depends(get_postgres_db),
    store_size: str = Form(None),
):

    if region_type == "State":
        query = form_store_assortment_query(StateLevelAssortment, region_type, region_name)
    else:
        query = form_store_assortment_query(CityLevelAssortment, region_type, region_name)

    condition = build_condition(query, L0, L1, L2, L3, mfac_name, brand_name)

    query = select([query]).where(and_(*condition)).subquery()

    order_by_clause = order_clause_store_assortment(sort_param, sort_type)

    if store_size == "large":
        query = select([query]).where(query.c.br_code == 'NewStore-LargeSized').order_by(order_by_clause)
    elif store_size == "medium":
        query = select([query]).where(query.c.br_code == 'NewStore-MidSized').order_by(order_by_clause)
    elif store_size == "small":
        query = select([query]).where(query.c.br_code == 'NewStore-SmallSized').order_by(order_by_clause)

    query = select(
        [
            query.c.sap_id.label('Product SAP'),
            query.c.item_name.label('Description'),
            query.c.molecule,
            query.c.L0,
            query.c.L3,
            query.c.mrp.label('MRP'),
            query.c.min_qty.label('Min Qty'),
            query.c.max_qty.label('Max Qty'),
            query.c.num_qty_sold.label("Actual Sales"),
            query.c.total_amount.label("Total Amount"),
            query.c.total_margin.label("Margin"),
            query.c.num_stores_product_part_of_assortment.label("Number of Stores"),
        ]
    )

    rows = await postgres_db.fetch_all(query)

    result = [dict(row) for row in rows]

    if result:
        # Create a CSV string
        csv_content = StringIO()
        csv_writer = csv.DictWriter(csv_content, fieldnames=result[0].keys())
        csv_writer.writeheader()
        csv_writer.writerows(result)

        # Convert the CSV string to bytes
        csv_bytes = csv_content.getvalue().encode("utf-8")

        # Return the response as a streaming response with content type "text/csv"
        return StreamingResponse(
            iter([csv_bytes]),
            media_type="text/csv",
            headers={"Content-Disposition": "attachment;filename=response.csv"},
        )
    else:
        # If there are no rows, return an empty response
        return StreamingResponse(
            iter([]),
            media_type="text/csv",
            headers={"Content-Disposition": "attachment;filename=products.csv"},
        )
