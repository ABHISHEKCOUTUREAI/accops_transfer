import json
from asyncio import gather
from collections import defaultdict

from fastapi import APIRouter, Depends, Form
from sqlalchemy import Numeric, String, and_, cast, func, select

from app.db import redis_db
from app.utils import build_condition, decimal_serializer

from ..models import AssortmentOutput, MSAAllCats, Product, StateLevelAssortment, CityLevelAssortment
from .common import get_postgres_db


utils = APIRouter(prefix="/couture/assortment", tags=["utils"])


@utils.post("/fetch-filters", operation_id="fetch-filters")   
async def fetch_filters(
    region_type: str = Form(None),
    region_name: str = Form(None),
    L0: str = Form(None),
    L1: str = Form(None),
    L2: str = Form(None),
    L3: str = Form(None),
    mfac_name: str = Form(None),
    brand_name: str = Form(None),
    postgres_db = Depends(get_postgres_db)
):

    cache_key = f"fetch-filters:{region_type}:{region_name}:{L0}:{L1}:{L2}:{L3}:{mfac_name}:{brand_name}"
    response =  await redis_db.get(cache_key)
    if response:
        print('Hit', cache_key)
        result = json.loads(response)
        return result
    
    condition = build_condition(region_type, region_name, L0, L1, L2, L3, mfac_name=mfac_name, brand=brand_name)

    query = select(
        [AssortmentOutput.br_code,
        AssortmentOutput.state,
        AssortmentOutput.city,
        AssortmentOutput.zone,
        AssortmentOutput.L0,
        AssortmentOutput.L1,
        AssortmentOutput.L2,
        AssortmentOutput.L3,
        AssortmentOutput.mfac_name,
        AssortmentOutput.brand_name,
        AssortmentOutput.sap_id]
    ).where(and_(AssortmentOutput.exist_in_model_output == 1, *condition)).subquery()

    L0_query = select([query.c.L0, func.count(func.distinct(query.c.sap_id))]).group_by(query.c.L0)

    L1_query = select([query.c.L1, func.count(func.distinct(query.c.sap_id))]).group_by(query.c.L1)

    L2_query = select([query.c.L2, func.count(func.distinct(query.c.sap_id))]).group_by(query.c.L2)

    L3_query = select([query.c.L3, func.count(func.distinct(query.c.sap_id))]).group_by(query.c.L3)
    
    queries = [postgres_db.fetch_all(query) for query in [L0_query, L1_query, L2_query, L3_query, query]]

    result = await gather(*queries)

    L0_rows, L1_rows, L2_rows, L3_rows, rows = result

    filters_count = {
        'L0': {row[0]: row[1] for row in L0_rows},
        'L1': {row[0]: row[1] for row in L1_rows},
        'L2': {row[0]: row[1] for row in L2_rows},
        'L3': {row[0]: row[1] for row in L3_rows}
    }

    # Organize data into a nested dictionary
    filters_data = defaultdict(lambda: defaultdict(lambda: defaultdict(lambda: defaultdict(dict))))

    for row in rows:
        br_code = row[0]
        state = row[1]
        city = row[2]
        zone = row[3]
        local_L0 = row[4]
        local_L1 = row[5]
        local_L2 = row[6]
        local_L3 = row[7]
        mfac = row[8]
        brand = row[9]

        filters_data['location'][zone][state][city][br_code] = {}
        filters_data['category'][local_L0][local_L1][local_L2][local_L3] = {}
        filters_data['mfac'][mfac][brand] = {}

    filters_data['filters_count'] = filters_count
    serialized_data = json.dumps(filters_data)
    await redis_db.set(cache_key, serialized_data)
    return filters_data


@utils.get("/fetch-filters-sales", operation_id="fetch-filters-sales")   
async def fetch_filters_sales(
    postgres_db = Depends(get_postgres_db)
):

    cache_key = "fetch-filters-sales"
    response =   await redis_db.get(cache_key)
    if response:
        print('Hit', cache_key)
        result = json.loads(response)
        return result
    
    query = select(
        MSAAllCats.ranking_level,
        MSAAllCats.L0,
        MSAAllCats.L1,
        MSAAllCats.L2,
        MSAAllCats.L3,
        MSAAllCats.sap_id,
    ).order_by(MSAAllCats.ranking_level) 
    rows = await postgres_db.fetch_all(query)
    
    
    # Organize data into a nested dictionary
    filters_data =  defaultdict(lambda: defaultdict(lambda: defaultdict(lambda: defaultdict(lambda: defaultdict(dict)))))

    for row in rows:
        ranking_level = row[0]
        L0 = row[1]
        L1 = row[2]
        L2 = row[3]
        L3 = row[4]
        sap_id = row[5]

        # Check if all L0, L1, L2, L3 are not empty or "nan" before adding the entry
        if all(value and (value.lower() == '' or  value.lower()) == "nan" for value in [L0, L1, L2, L3]):
            continue
        filters_data[ranking_level][L0][L1][L2][L3][sap_id] = {}

    response =  {
        'filters': filters_data
    }
    serialized_data = json.dumps(response)
    await redis_db.set(cache_key, serialized_data)
    return response


@utils.post("/fetch-assortment")  
async def fetch_assortment(
    br_code: str = Form(None),
    L0: str = Form(None),
    L1: str = Form(None),
    L2: str = Form(None),
    L3: str = Form(None),
    sap_id: int = Form(None),
    flag: bool = Form(True),
    postgres_db = Depends(get_postgres_db)
):
    cache_key = f"hit_and_miss:{br_code}:{L0}:{L1}:{L2}:{L3}:{sap_id}"
    response =  await redis_db.get(cache_key)
    if response:
        print(cache_key)
        result = json.loads(response)
        return result

    condition = []

    if L0 is not None:
        condition.append(AssortmentOutput.L0 == L0)
    if L1 is not None:
        condition.append(AssortmentOutput.L1 == L1)
    if L2 is not None:
        condition.append(AssortmentOutput.L2 == L2)
    if L3 is not None:
        condition.append(AssortmentOutput.L3 == L3) 
    if br_code is not None:
        condition.append(AssortmentOutput.br_code == br_code)      
    if sap_id is not None :
        if flag:
            condition.append(cast(AssortmentOutput.sap_id, String).startswith(str(sap_id)))
        else:
            condition.append(AssortmentOutput.sap_id == sap_id)    
       

    # Build the filter 
    if flag:
        query = ( 
            select([
            AssortmentOutput.sap_id,
        ])
        .group_by(AssortmentOutput.sap_id, AssortmentOutput.item_name)  # Add more columns if needed
        )
    else:
        query = ( 
            select([
            AssortmentOutput.sap_id,
            AssortmentOutput.item_name,
            func.round(func.sum(cast(AssortmentOutput.total_amount, Numeric)), 2).label('total_amount'),
            func.round(func.sum(cast(AssortmentOutput.total_margin, Numeric)), 2).label('total_margin'),
            func.round(func.sum(cast(AssortmentOutput.num_qty_sold, Numeric)), 2).label('num_qty_sold'),
        ])
        .group_by(AssortmentOutput.sap_id, AssortmentOutput.item_name)  # Add more columns if needed
        )

    # Assortment
    assortment_condition = and_(*condition, AssortmentOutput.exist_in_model_output == 0)
    assortment_query = query.where(assortment_condition)

    assortment_rows = await postgres_db.fetch_all(assortment_query)
    result = [dict(rows) for rows in assortment_rows]
    if not flag:
        for assort in result:
            assort["total_amount"] = round(assort["total_amount"], 2) if assort["total_amount"] is not None else None
            assort["total_margin"] = round(assort["total_margin"], 2) if assort["total_margin"] is not None else None

    serialized_data = json.dumps(result, default=decimal_serializer)
    await redis_db.set(cache_key, serialized_data)
    return result




def store_filter_query(model, region_type, region_name):
    # Filter the region type first
    if region_type == "State":
        query = select([model]).where(model.state == region_name).subquery()
    else:
        query = select([model]).where(model.city == region_name).subquery()


    query = (
        select(
        [
            Product.L0,
            Product.L1,
            Product.L2,
            Product.L3,
            Product.mfac_name,
            Product.brand_name,
            query.c.sap_id.label('sap_id'),
            query.c.br_code.label('br_code'),
        ]
        ).join(Product, query.c.sap_id == Product.sap_id)
    ).subquery()

    return query




# fetch filters for store assortment which should contain l0, l1, l2, l3, mfac, brand and counts 
@utils.post("/fetch-store-filters", operation_id="fetch-filters")   
async def fetch_store_filters(
    region_type: str = Form(None),
    region_name: str = Form(None),
    L0: str = Form(None),
    L1: str = Form(None),
    L2: str = Form(None),
    L3: str = Form(None),
    mfac_name: str = Form(None),
    brand_name: str = Form(None),
    br_code: str = Form(None),
    postgres_db = Depends(get_postgres_db)
):

    cache_key = f"fetch-store-filters:{region_type}:{region_name}:{L0}:{L1}:{L2}:{L3}:{mfac_name}:{brand_name}:{br_code}"
    response =  await redis_db.get(cache_key)
    if response:
        print(cache_key)
        result = json.loads(response)
        return result
    

    condition = []
    if region_type == "State":
        query = store_filter_query(StateLevelAssortment, region_type, region_name)
    else:
        query = store_filter_query(CityLevelAssortment, region_type, region_name)
    
    condition = build_condition(query, L0, L1, L2, L3, mfac_name, brand_name)

    query = select([query]).where(and_(*condition)).subquery()



   
    if br_code is not None:
        query = select([query]).where(query.c.br_code == br_code)
    else: 
        # Apply the filters and get the br_code with the maximum rows
        max_br_code_query = select([query.c.br_code, func.count().label('row_count')]).group_by(query.c.br_code).order_by(func.count().desc()).limit(1)
        max_br_code_result = await postgres_db.fetch_one(max_br_code_query)

        if max_br_code_result:
            max_br_code = max_br_code_result['br_code']
            print(max_br_code)
            query = select([query]).where(query.c.br_code == max_br_code)



    L0_query = select([query.c.L0, func.count(query.c.sap_id)]).group_by(query.c.L0)

    L1_query = select([query.c.L1, func.count(query.c.sap_id)]).group_by(query.c.L1)

    L2_query = select([query.c.L2, func.count(query.c.sap_id)]).group_by(query.c.L2)

    L3_query = select([query.c.L3, func.count(query.c.sap_id)]).group_by(query.c.L3)
    

    queries = [postgres_db.fetch_all(query) for query in [L0_query, L1_query, L2_query, L3_query, query]]
    result = await gather(*queries)

    L0_rows, L1_rows, L2_rows, L3_rows, rows = result

    filters_count = {
        'L0': {row[0]: row[1] for row in L0_rows},
        'L1': {row[0]: row[1] for row in L1_rows},
        'L2': {row[0]: row[1] for row in L2_rows},
        'L3': {row[0]: row[1] for row in L3_rows}
    }

    # Organize data into a nested dictionary
    filters_data = defaultdict(lambda: defaultdict(lambda: defaultdict(lambda: defaultdict(dict))))

    for row in rows:
        local_L0 = row[0]
        local_L1 = row[1]
        local_L2 = row[2]
        local_L3 = row[3]
        mfac = row[4]
        brand = row[5]

        filters_data['category'][local_L0][local_L1][local_L2][local_L3] = {}
        filters_data['mfac'][mfac][brand] = {}

    filters_data['filters_count'] = filters_count
    serialized_data = json.dumps(filters_data)
    await redis_db.set(cache_key, serialized_data)
    return filters_data



# API to search molecule from product table
@utils.get("/fetch-molecule-autocomplete")
async def fetch_molecule(
    molecule: str = None,
    postgres_db = Depends(get_postgres_db)
):
    cache_key = f"fetch-molecule:{molecule}"
    response =  await redis_db.get(cache_key)
    if response:
        print('Hit', cache_key)
        result = json.loads(response)
        return result

    # do prefix search of molecule in product table
    query = select([Product.molecule]).where(Product.molecule.ilike(f'%{molecule}%')).distinct()
    rows = await postgres_db.fetch_all(query)
    result = [row[0] for row in rows]

    serialized_data = json.dumps(result)
    await redis_db.set(cache_key, serialized_data)
    return result