import databases
# from app.settings import settings
from sqlalchemy import create_engine
from sqlalchemy.orm import sessionmaker
from  app.models import AiocdAnalysis, Orders, Bounce, Product, Inventory, Store, AssortmentOutput, Probability, AiocdAnalysisSales, IQVIASales, MSAAllCats, Base, StateLevelAssortment, CityLevelAssortment


class PostgresDatabase:
    def __init__(self, settings):
        SQLALCHEMY_DATABASE_URL = "postgresql://" + settings.postgres_user + ":" + settings.postgres_password + "@" + settings.postgres_service + ":5432/" + settings.postgres_db
        SQLALCHEMY_DATABASE_URL_ASYNC  = "postgresql+asyncpg://" + settings.postgres_user + ":" + settings.postgres_password + "@" + settings.postgres_service + ":5432/" + settings.postgres_db


        self.postgres_engine = create_engine(
            SQLALCHEMY_DATABASE_URL
        )

        Session = sessionmaker(autocommit=False, autoflush=False, bind=self.postgres_engine)
        postgres_sync_db = Session() # noqa F841

        self.database = databases.Database(SQLALCHEMY_DATABASE_URL_ASYNC)

    async def connect(self):
       await self.database.connect()

    def get_db(self):
        return self.database

    def create_tables(self):
        AiocdAnalysis.__table__.create(bind=self.postgres_engine, checkfirst=True)
        Orders.__table__.create(bind=self.postgres_engine, checkfirst=True)
        Bounce.__table__.create(bind=self.postgres_engine, checkfirst=True)
        Product.__table__.create(bind=self.postgres_engine, checkfirst=True)
        Inventory.__table__.create(bind=self.postgres_engine, checkfirst=True)
        Store.__table__.create(bind=self.postgres_engine, checkfirst=True)
        AssortmentOutput.__table__.create(bind=self.postgres_engine, checkfirst=True)
        Probability.__table__.create(bind=self.postgres_engine, checkfirst=True)
        AiocdAnalysisSales.__table__.create(bind=self.postgres_engine, checkfirst=True)
        IQVIASales.__table__.create(bind=self.postgres_engine, checkfirst=True)
        MSAAllCats.__table__.create(bind=self.postgres_engine, checkfirst=True)
        StateLevelAssortment.__table__.create(bind=self.postgres_engine, checkfirst=True)
        CityLevelAssortment.__table__.create(bind=self.postgres_engine, checkfirst=True)
        print("Postgres table created")    
