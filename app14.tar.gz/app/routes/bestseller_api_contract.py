import json
from datetime import datetime

from db import check_in_redis, psql_execute_multiple, psql_execute_single, redis_db
from fastapi import APIRouter, Depends, FastAPI
from models import (
    AjioBestSellers,
    AjioBrickDetails,
    AjioProductAttributes,
    AjioSearchQueriesTopInteractedProducts,
    AttributeQueryParams,
    CategoryQueryParams,
    FilterQuery,
    ProductQueryParams,
    SearchParams,
    SearchTrends,
    CombinedSearchTermsWeeksResponse
)
from sqlalchemy import func, select
from sqlalchemy.dialects.postgresql import aggregate_order_by
from static import REDIS_WRITE_ERROR
from utils import (
    api_contract_ajio_bestseller_query,
    api_contract_search_attributes,
    api_contract_trends_bestseller_query,
    calculate_time_delta,
    create_bestseller_attribute_query,
    create_most_searched_attributes_query,
    create_request_api_contract_ajio,
    create_request_api_contract_filters,
    create_request_api_contract_trends,
    fields_info,
    load_attributes_images,
    load_category_images,
)

from .ajio import get_ajio_filters

app = FastAPI()


BestSellerAPIContractRouter = APIRouter(
    prefix="/coutureapi/fast-fashion/bestsellers",
    tags=["API Contract"],
    responses={404: {"description": "Not found"}},
)


@BestSellerAPIContractRouter.get("/products")
async def get_bestseller_products(
    query_params: ProductQueryParams = Depends(),
):
    cache_key = f"api_contract_products_{json.dumps(query_params.model_dump())}"
    cached_data = await check_in_redis(cache_key)
    if cached_data:
        return json.loads(cached_data)

    request_data_ajio = await create_request_api_contract_ajio(query_params)
    ajio_query = await api_contract_ajio_bestseller_query(
        request_data_ajio, query_params
    )

    request_data_trends = await create_request_api_contract_trends(query_params)
    trends_query = await api_contract_trends_bestseller_query(request_data_trends)

    # Combine both the queries
    ajio_query = ajio_query.cte()
    trends_query = trends_query.cte()

    sort_order = query_params.sort_order
    if sort_order == "asc":
        order_by_clause = ajio_query.c.weekly_rate_of_sale.asc()
    else:
        order_by_clause = ajio_query.c.weekly_rate_of_sale.desc()
    query = (
        select(
            ajio_query.c.productid,
            ajio_query.c.title,
            ajio_query.c.brandname,
            ajio_query.c.mrp,
            ajio_query.c.weekly_rate_of_sale.label("ajio_weekly_ros"),
            trends_query.c.weekly_rate_of_sale.label("trends_weekly_ros"),
            ajio_query.c.imgcode,
        )
        .join(
            trends_query,
            ajio_query.c.productid == trends_query.c.itemid,
            isouter=True,
        )
        .order_by(order_by_clause)
    )

    result = await psql_execute_single(query)

    result = [
        {
            "item_id": row[0],
            "title": row[1],
            "brand_name": row[2],
            "mrp": row[3],
            "ajio_weekly_ros": row[4],
            "trends_weekly_ros": row[5] if row[5] is not None else 0,
            "image_code": row[6],
        }
        for row in result
    ]

    try:
        await redis_db.set(cache_key, json.dumps(result, default=str))
    except Exception as e:
        print(REDIS_WRITE_ERROR, e)

    return result


@BestSellerAPIContractRouter.get("/category")
async def get_category(
    query_params: CategoryQueryParams = Depends(),
):
    cache_key = f"api_contract_category_{json.dumps(query_params.model_dump())}"
    cached_data = await check_in_redis(cache_key)
    if cached_data:
        return json.loads(cached_data)

    query = select(
        AjioBrickDetails.l2name.distinct(),
    ).where(AjioBrickDetails.l1name == query_params.gender)
    result = await psql_execute_single(query)

    # load the category images
    category_images = await redis_db.get("category_images")
    if category_images:
        category_images = json.loads(category_images)
    else:
        await load_category_images()
        category_images = await redis_db.get("category_images")
        category_images = json.loads(category_images)

    # join the query l2name with the category_images to create final response
    result = [
        {
            "category": row[0],
            "id": category_images.get(row[0], {}).get("id", ""),
            "imgcode": category_images.get(row[0], {}).get("imgcode", ""),
        }
        for row in result
    ]

    try:
        await redis_db.set(cache_key, json.dumps(result, default=str))
    except Exception as e:
        print(REDIS_WRITE_ERROR, e)

    return result


@BestSellerAPIContractRouter.get("/attributes")
async def get_bestseller_attributes(
    query_params: AttributeQueryParams = Depends(),
):
    cache_key = f"api_contract_attributes_{json.dumps(query_params.model_dump())}"
    cached_data = await check_in_redis(cache_key)
    if cached_data:
        return json.loads(cached_data)

    week = query_params.week
    if week is None:
        week_query = select(func.max(AjioBestSellers.week_of_year))
        week_result = await psql_execute_single(week_query)
        week = week_result[0][0]

    # get attributes images
    attributes_images = await redis_db.get("attributes_images")
    if attributes_images:
        attributes_images = json.loads(attributes_images)
    else:
        await load_attributes_images()
        attributes_images = await redis_db.get("attributes_images")
        attributes_images = json.loads(attributes_images)

    # Build main query
    if (
        query_params.attribute == "all"
        or query_params.attribute not in api_contract_search_attributes
    ):
        query_list = [
            await create_bestseller_attribute_query(query_params, attribute, week)
            for attribute in api_contract_search_attributes
        ]

        # Execute the main query
        results = await psql_execute_multiple(query_list)
        processed_result = []
        for result in results:
            response = {
                "attribute": api_contract_search_attributes[results.index(result)],
                "values": [
                    {
                        "name": row[0],
                        "current_sales": round(row[1], 2),
                        "previous_sales": round(row[2], 2),
                        "precentage_change": round(
                            ((row[1] - row[2]) * 100) / row[2], 2
                        )
                        if row[2] != 0
                        else 0,
                        "id": attributes_images.get(
                            api_contract_search_attributes[results.index(result)], {}
                        )
                        .get(row[0])
                        .get("productid"),
                        "imgcode": attributes_images.get(
                            api_contract_search_attributes[results.index(result)], {}
                        )
                        .get(row[0])
                        .get("imgcode"),
                    }
                    for row in result
                ],
            }
            processed_result.append(response)

    else:
        query = await create_bestseller_attribute_query(
            query_params, query_params.attribute, week
        )

        result = await psql_execute_single(query)

        # Process the result
        processed_result = [
            {
                "attribute": query_params.attribute,
                "values": [
                    {
                        "name": row[0],
                        "current_sales": round(row[1], 2),
                        "previous_sales": round(row[2], 2),
                        "precentage_change": round(
                            ((row[1] - row[2]) * 100) / row[2], 2
                        )
                        if row[2] != 0
                        else 0,
                        "id": attributes_images.get(query_params.attribute)
                        .get(row[0])
                        .get("productid"),
                        "imgcode": attributes_images.get(query_params.attribute)
                        .get(row[0])
                        .get("imgcode"),
                    }
                    for row in result
                ],
            }
        ]

    # Cache the result
    try:
        await redis_db.set(cache_key, json.dumps(processed_result, default=str))
    except Exception as e:
        print(REDIS_WRITE_ERROR, e)

    return processed_result


@BestSellerAPIContractRouter.get("/most-searched-trends")
async def get_most_searched_trends(
    query_params: SearchTrends = Depends(),
):  
    time1 = datetime.now()
    cache_key = (
        f"api_contract_most_searched_trends{json.dumps(query_params.model_dump())}"
    )
    cached_data = await check_in_redis(cache_key)
    if cached_data:
        return json.loads(cached_data)

    brick_conditions = []
    if query_params.category is not None:
        brick_conditions.append(AjioBrickDetails.l2name == query_params.category)
    if query_params.brickname is not None:
        brick_conditions.append(AjioBrickDetails.brickname == query_params.brickname)

    cache_key_min_max = "min_max_week"
    min_max_week = await redis_db.get(cache_key_min_max)
    if min_max_week:
        min_week, max_week = json.loads(min_max_week)
    else:
        await calculate_time_delta()
        min_max_week = await redis_db.get(cache_key_min_max)
        min_week, max_week = json.loads(min_max_week)

    
    no_of_weeks = query_params.num_days // 7
    start_week = max_week - no_of_weeks + 1
    # Ensure the starting week is not earlier than the minimum week present
    if start_week < min_week:
        start_week = min_week
    

    # Query to get session counts for each week
    page = query_params.page
    page_size = query_params.page_size
    time2 = datetime.now()
    print("Time taken to calculate time delta: ", time2 - time1)


    search_query = (
        select(
            AjioSearchQueriesTopInteractedProducts.normalized_search_term,
            AjioSearchQueriesTopInteractedProducts.week_of_year,
            func.sum(AjioSearchQueriesTopInteractedProducts.sum_session_counts).label(
                "total_searches"
            ),
        )
        .join(
            AjioProductAttributes,
            AjioSearchQueriesTopInteractedProducts.productid
            == AjioProductAttributes.productid,
        )
        .join(
            AjioBrickDetails,
            AjioProductAttributes.similargrouplevel
            == AjioBrickDetails.similargrouplevel,
            isouter=True,
        )
        .group_by(
            AjioSearchQueriesTopInteractedProducts.normalized_search_term,
            AjioSearchQueriesTopInteractedProducts.week_of_year,
        )
        .where(
            *brick_conditions,
            AjioSearchQueriesTopInteractedProducts.week_of_year.between(
                start_week, max_week + 1
            ),
        )
    ).cte()

    # Left join combined_query with search_query
    joined_query = select(
        CombinedSearchTermsWeeksResponse.normalized_search_term,
        CombinedSearchTermsWeeksResponse.week_of_year,
        func.coalesce(search_query.c.total_searches, 0).label("total_searches"),
    ).join(
        search_query,
        (
            (CombinedSearchTermsWeeksResponse.normalized_search_term== search_query.c.normalized_search_term)
            & (CombinedSearchTermsWeeksResponse.week_of_year == search_query.c.week_of_year)
        ),
        isouter=True,
    ).where(
        CombinedSearchTermsWeeksResponse.week_of_year.between(start_week, max_week + 1)
    )

    # now do array arrgeration of total_searches week wise and group buy only normalized_search_term
    aggregated_query = (
        (
            select(
                joined_query.c.normalized_search_term,
                func.array_agg(
                    aggregate_order_by(
                        joined_query.c.total_searches, joined_query.c.week_of_year.asc()
                    )
                ).label("searches_ordered"),
                func.sum(joined_query.c.total_searches).label("total_searches"),
            ).group_by(joined_query.c.normalized_search_term)
        )
        .where(joined_query.c.week_of_year.between(start_week, max_week + 1))
        .order_by(func.sum(joined_query.c.total_searches).desc())
        .limit(page_size)
        .offset((page - 1) * page_size)
    ).cte()

    last_searched_timestamp_query = (
        select(
            AjioSearchQueriesTopInteractedProducts.normalized_search_term,
            func.max(AjioSearchQueriesTopInteractedProducts.week_of_year).label(
                "last_searched_timestamp"
            ),
        ).group_by(AjioSearchQueriesTopInteractedProducts.normalized_search_term)
    ).cte()

    final_query = (
        select(
            aggregated_query.c.normalized_search_term,
            aggregated_query.c.searches_ordered,
            aggregated_query.c.total_searches,
            last_searched_timestamp_query.c.last_searched_timestamp,
        )
        .join(
            last_searched_timestamp_query,
            aggregated_query.c.normalized_search_term
            == last_searched_timestamp_query.c.normalized_search_term,
        )
        .order_by(aggregated_query.c.total_searches.desc())
    )
    
    time3 = datetime.now()
    print("Time taken to create query: ", time3 - time2)

    result = await psql_execute_single(final_query)

    time4 = datetime.now()
    print("Time taken to execute query: ", time4 - time3)


    result = [
        {
            "name": row[0],
            "last_searched_timestamp": row[3],
            "search_distribution": {
                "divisions": len(row[1]),
                "data": row[1],
            },
            "total_searches": row[2],
        }
        for row in result
    ]

    time5 = datetime.now()
    print("Time taken to process result: ", time5 - time4)

    try:
        await redis_db.set(cache_key, json.dumps(result, default=str))
    except Exception as e:
        print(REDIS_WRITE_ERROR, e)

    return result


@BestSellerAPIContractRouter.get("/most-searched-attributes")
async def get_most_searched_attributes(
    query_params: SearchParams = Depends(),
):
    cache_key = (
        f"api_contract_most_searched_attributes_{json.dumps(query_params.model_dump())}"
    )
    cached_data = await check_in_redis(cache_key)
    if cached_data:
        return json.loads(cached_data)

    start_week, latest_week = await calculate_time_delta(query_params)

    # create a list of queries for each attribute
    if query_params.attribute == "all":
        query_list = [
            await create_most_searched_attributes_query(
                query_params, attribute, start_week, latest_week
            )
            for attribute in api_contract_search_attributes
        ]

        results = await psql_execute_multiple(query_list)

        data = []
        for result in results:
            count = 0
            for row in result:
                count += row[1]
            response = {
                "attribute": api_contract_search_attributes[results.index(result)],
                "distribution": [
                    {"name": row[0], "percentage": round(((row[1] * 100) / count), 2)}
                    for row in result
                ],
            }
            data.append(response)

    else:
        query = await create_most_searched_attributes_query(
            query_params, query_params.attribute, start_week, latest_week
        )

        results = await psql_execute_single(query)

        count = 0
        for row in results:
            count += row[1]
        data = {
            "attribute": query_params.attribute,
            "distribution": [
                {"name": row[0], "percentage": round(((row[1] * 100) / count), 2)}
                for row in results
            ],
        }

    try:
        await redis_db.set(cache_key, json.dumps(data, default=str))
    except Exception as e:
        print(REDIS_WRITE_ERROR, e)

    return data


@BestSellerAPIContractRouter.get("/filters")
async def get_api_contract_filters(
    query_params: FilterQuery = Depends(),
):
    cache_key = f"api_contract_filters_{json.dumps(query_params.model_dump())}"
    cached_data = await check_in_redis(cache_key)
    if cached_data:
        return json.loads(cached_data)

    time1 = datetime.now()

    request_data_ajio = await create_request_api_contract_filters(query_params)
    time2 = datetime.now()
    print("Time taken to create request data: ", time2 - time1)

    filter_query = await get_ajio_filters(request_data_ajio, api_contract_flag=True)
    time3 = datetime.now()
    print("Time taken to get filters: ", time3 - time2)

    result = await psql_execute_single(filter_query)
    time4 = datetime.now()
    print("Time taken to execute query: ", time4 - time3)

    # Define a list of tuples with field information: (name, displayName, index)
    response = {}

    # Iterate over the fields_info to populate the response dictionary
    for field in fields_info:
        name, display_name, index = field[:3]
        # Use mapping if provided, otherwise use the value directly
        if len(field) == 4:
            mapping = field[3]
            values = {
                mapping[val[index]]: mapping[val[index]]
                for val in result
                if val[index] != "nan" and val[index] is not None
            }
        else:
            values = {
                val[index]: val[index]
                for val in result
                if val[index] != "nan" and val[index] is not None
            }

        response[name] = {"name": name, "displayName": display_name, "values": values}

    time5 = datetime.now()
    print("Time taken to create response: ", time5 - time4)
    try:
        await redis_db.set(cache_key, json.dumps(response, default=str))
    except Exception as e:
        print(REDIS_WRITE_ERROR, e)

    return response
