from pydantic_settings import BaseSettings

class Settings(BaseSettings):

    postgres_user: str 
    postgres_password: str 
    postgres_db: str
    postgres_service: str
    postgres_port: str
    postgres_pool_size_str: str
    postgres_max_overflow_str: str
    redis_service: str 
    redis_db_str: str
    redis_port_str: str
    uvicorn_workers: str 
    uvicorn_port: str
    redis_state_str: str

    @property
    def redis_db(self):
        return int(self.redis_db_str)
    
    @property
    def redis_port(self):
        return int(self.redis_port_str)
    
    @property
    def redis_state(self):
        return bool(int(self.redis_state_str))
    
    @property
    def postgres_pool_size(self):
        return int(self.postgres_pool_size_str)
    
    @property
    def postgres_max_overflow(self):
        return int(self.postgres_max_overflow_str)
    
    class Config:
        env_file = ".env"

settings = Settings()
