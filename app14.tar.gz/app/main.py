import uvicorn
from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from fastapi.openapi.utils import get_openapi
from contextlib import asynccontextmanager
from db import set_redis_state, ping_redis
from settings import settings
from routes import (
    AjioRouter,
    TrendsRouter,
    HealthCheckRouter,
    SearchInteractionRouter,
    TopProductQueryRouter,
    BestSellerAPIContractRouter,
    DBRouter,
)
from routes import load_ajio_cached_filters, load_trends_filters_cache, load_cached_search_interaction_filters
from utils import load_category_images, load_attributes_images, calculate_time_delta

@asynccontextmanager
async def lifespan(app: FastAPI):
    await ping_redis()
    if settings.redis_state:
        await set_redis_state(flush_db=True)
    await load_ajio_cached_filters()
    await load_trends_filters_cache()
    await load_cached_search_interaction_filters()
    await load_category_images()
    await load_attributes_images()
    await calculate_time_delta()
    

    print(
        "================================ Starting up ================================================="
    )
    yield

    print(
        "================================ Shutting down ================================================="
    )


app = FastAPI(
    title="fastfashion-api",
    docs_url="/docs",
    redoc_url=None,
    lifespan=lifespan,
    root_path="/fast-fashion",
)


def custom_openapi():
    if app.openapi_schema:
        return app.openapi_schema
    openapi_schema = get_openapi(
        title=app.title,
        version=app.version,
        routes=app.routes,
        servers=[{"url": "/fast-fashion"}],
    )
    app.openapi_schema = openapi_schema
    return app.openapi_schema


app.openapi = custom_openapi

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)


@app.get("/")
async def home():
    return {"Welcome to FastFashion API"}


app.include_router(AjioRouter)
app.include_router(TrendsRouter)
app.include_router(HealthCheckRouter)
app.include_router(SearchInteractionRouter)
app.include_router(TopProductQueryRouter)
app.include_router(BestSellerAPIContractRouter)
app.include_router(DBRouter)

if __name__ == "__main__":
    uvicorn.run(app, host="0.0.0.0", port=8000)
