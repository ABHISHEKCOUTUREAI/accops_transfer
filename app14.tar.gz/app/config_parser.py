"""Parse Configurations From Default.yml File."""

import os
import sys
import configargparse


BASE_DIR = os.path.dirname(os.path.abspath(__file__))

FILE_FORMAT = "{0}/{1}"
YAML_FILE = "default.yaml"

default_config_file = FILE_FORMAT.format(BASE_DIR, YAML_FILE)

parser = configargparse.ArgParser(
    config_file_parser_class=configargparse.YAMLConfigFileParser,
    default_config_files=[default_config_file],
    auto_env_var_prefix="",
)

parser.add("--POSTGRES_USER", help="POSTGRES_USER")
parser.add("--POSTGRES_PASSWORD", help="POSTGRES_PASSWORD")
parser.add("--POSTGRES_DB", help="POSTGRES_DB")
parser.add("--POSTGRES_SERVICE", help="POSTGRES_SERVICE")
parser.add("--UVICORN_WORKERS", help="UVICORN_WORKERS")
parser.add("--UVICORN_PORT", help="UVICORN_PORT")
parser.add("REDIS_SERVICE", help="REDIS_SERVICE")
parser.add("REDIS_DB_STR", help="REDIS_DB_STR")
parser.add("REDIS_PORT_STR", help="REDIS_PORT_STR")

arguments = sys.argv
argument_options = parser.parse_known_args(arguments)

docker_args = argument_options[0]
