 CREATE TABLE ajio_search_queries_top_interacted_products_new (
    year INT,
    month_of_year INT,
    week_of_year INT,
    search_type VARCHAR,
    normalized_search_term VARCHAR,
    productid VARCHAR,
    sum_session_counts BIGINT,
    impressions_product BIGINT,
    clicks_product BIGINT,
    total_clicks_query BIGINT,
    PRIMARY KEY (year, month_of_year, week_of_year, search_type, normalized_search_term, productid)
) PARTITION BY RANGE (month_of_year);




DO $$ 
BEGIN
    FOR i IN 1..5 LOOP
        EXECUTE format('
            CREATE TABLE IF NOT EXISTS ajio_denormalized_mv%02s 
            PARTITION OF ajio_denormalized_mv 
            FOR VALUES FROM (%s) TO (%s)
            PRIMARY KEY (year, month_of_year, week_of_year, productid, pincode);
        ', LPAD(i::TEXT, 2, '0'), i, i + 1);
    END LOOP;
END $$;


INSERT INTO ajio_search_queries_top_interacted_products_new
SELECT * FROM ajio_search_queries_top_interacted_products;






CREATE MATERIALIZED VIEW mv_ros_query AS
SELECT
    productid,
    week_of_year,
    year,
    AVG(mrp) AS mrp,
    SUM(sold_quantity_in_a_week) AS sold_quantity_across_each_week
FROM
    ajio_denormalized_mv
GROUP BY
    productid, week_of_year, year;



CREATE MATERIALIZED VIEW mv_calender_query AS
SELECT
    year,
    week_of_year,
    SUM(num_days_in_week) AS total_days_count_across_week
FROM
    calendaryearmonthweekinfo
GROUP BY
    year, week_of_year;


CREATE MATERIALIZED VIEW mv_product_query AS
SELECT
    productid,
    title,
    brandname,
    imgcode,
    styletype,
    colorfamily,
    pattern,
    neckline,
    l1name,
    l2name,
    brickname
FROM
    ajio_product_brick_mv;



SELECT ajio_brick_details.l2name, ajio_product_attributes.productid, ajio_product_attributes.imgcode
FROM ajio_brick_details 
JOIN ajio_product_attributes  ON ajio_brick_details.similargrouplevel = ajio_product_attributes.similargrouplevel 
WHERE ajio_brick_details.l1name = MEN
GROUP BY ajio_brick_details.l2name



https://assets.ajio.com/medias/sys_master/root/20230823/CEy1/64e55f4fddf779151962eb4c/466486631_blue.jpg


SELECT month_of_year, quarter_of_year, zone, state, city, districtsname, l1name, l2name, brickname, styletype, neckline, pattern, fabrictype, sleevelength, fit, colorfamily, brandname, occasion, bodytype, materialtype, distress, traditionalweave, hemline 
FROM ajio_denormalized_mv 
WHERE l1name IN ('Men') AND month_of_year IN (4);



