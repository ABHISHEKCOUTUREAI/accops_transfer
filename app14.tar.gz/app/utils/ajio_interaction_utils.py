from sqlalchemy import select
import asyncio
from models import (
    AjioBrickDetails,
    AjioProductAttributes,
    AjioSearchQueriesTopInteractedProducts,
)
from .common_utils import build_filter_condition, select_filter_subquery


async def create_search_interaction_filter_query(request_data):
    duration_filter, brick_filter, product_filter = await asyncio.gather(
        build_filter_condition(
            filter_flag="duration", request_filters=request_data, type="ajio-search"
        ),
        build_filter_condition(
            filter_flag="brick", request_filters=request_data, type="ajio-search"
        ),
        build_filter_condition(
            filter_flag="attributes", request_filters=request_data, type="ajio-search"
        ),
    )

    duration_columns = [
        "month_of_year",
        "week_of_year",
        "search_type",
        "normalized_search_term",
        "productid",
    ]
    brick_columns = ["l1name", "l2name", "brickname", "similargrouplevel"]
    product_columns = ["productid", "brandname", "similargrouplevel"]

    duration_search_query, brick_query, product_attributes_query = await asyncio.gather(
        select_filter_subquery(
            AjioSearchQueriesTopInteractedProducts, list(duration_filter), duration_columns
        ),
        select_filter_subquery(AjioBrickDetails, list(brick_filter), brick_columns),
        select_filter_subquery(
            AjioProductAttributes, list(product_filter), product_columns
        ),
    )

    query = (
        select(
            duration_search_query.c.month_of_year,
            duration_search_query.c.week_of_year,
            duration_search_query.c.search_type,
            duration_search_query.c.normalized_search_term,
            brick_query.c.l1name,
            brick_query.c.l2name,
            brick_query.c.brickname,
            product_attributes_query.c.brandname,
        )
        .join(
            product_attributes_query,
            duration_search_query.c.productid == product_attributes_query.c.productid,
        )
        .join(
            brick_query,
            brick_query.c.similargrouplevel == product_attributes_query.c.similargrouplevel,
        )
    )
    return query
