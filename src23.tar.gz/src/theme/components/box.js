const Box = {
  variants: {
    sideBarTitleSelected: {
      bg: 'gray.100',
      color: 'gray.700',
      fontWeight: '500',
      height: 'auto',
      width: 'auto',
      minWidth: 0,
      justifyContent: 'start',
      gap: 2,
      px: '20px',
      py: '10px',
      background:
        'linear-gradient(90deg, rgba(0, 0, 0, 0.48) 0%, rgba(0, 0, 0, 0.7) 51.5%, rgba(0, 0, 0, 0.8) 96%)',
      boxShadow: '2px 2px 20px 2px rgba(0, 0, 0, 0.17)',
      borderRadius: '0px 8px 8px 0px',
      _hover: {
        background:
          'linear-gradient(90deg, rgba(0, 0, 0, 0.48) 0%, rgba(0, 0, 0, 0.7) 51.5%, rgba(0, 0, 0, 0.8) 96%)',
        boxShadow: '2px 2px 20px 2px rgba(0, 0, 0, 0.17)',
        borderRadius: '0px 8px 8px 0px'
      },
      _active: {
        background:
          'linear-gradient(90deg, rgba(0, 0, 0, 0.48) 0%, rgba(0, 0, 0, 0.7) 51.5%, rgba(0, 0, 0, 0.8) 96%)',
        boxShadow: '2px 2px 20px 2px rgba(0, 0, 0, 0.17)',
        borderRadius: '0px 8px 8px 0px'
      },

      _disabled: {}
    }
  }
};

export default Box;
