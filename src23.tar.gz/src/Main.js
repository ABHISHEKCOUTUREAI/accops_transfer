/* eslint-disable react/jsx-key */
import { useTheme } from '@chakra-ui/react';
import { Analytics, Home, Inventory, ListAltOutlined } from '@mui/icons-material';
import { ThemeProvider, createTheme } from '@mui/material';
import Box from '@mui/material/Box';
import CssBaseline from '@mui/material/CssBaseline';
import * as React from 'react';
import { useEffect, useState } from 'react';
import { Route, Routes, useNavigate, Navigate } from 'react-router-dom';
import AppBar from './Artifactory/Components/AppBar/AppBar.js';
import { LocationContext } from './Contexts/LocationContext';
import { Colors } from './Static/properties/properties';
import AssortmentAnalysis from './Views/AssortmentAnalysis';
import AssortmentCustom from './Views/AssortmentCustom';
import AssortmentPlanning from './Views/AssortmentPlanning';
import Chatbot from './Views/Chatbot';
import Login from './Views/Login';
import MarketTrends from './Views/MarketTrends';
import NewAssortment from './Views/NewAssortment';
import Profile from './Views/Profile';
import Homenew from './Views/newHome';
import SideBar from './components/Sidebar';
import configuration from './config/configuration.js';
import Cart from './Views/Cart.js';
import { InventoryInfo } from './Views/InventoryInfo.js';
import { StoreManagerHome } from './Views/StoreManagerHome.js';
import { NotificationsPanel } from './components/NotificationPanel.js';
import ShoppingCartIcon from '@mui/icons-material/ShoppingCart';
import Orders from './Views/Orders.js';
import OrderDetails from './Views/OrderDetails.js';
const drawerWidth = 250;

export default function Main() {
  const theme = createTheme({
    palette: {
      primary: {
        main: Colors.white
      },
      secondary: {
        main: Colors.blue
      }
    }
  });
  const navigate = useNavigate();

  const handleNavigation = (path, row) => {
    navigate(path, { state: { row: row } });
  };

  const [loading, setLoading] = useState(true);
  const [filtersOpen, setFiltersOpen] = useState(false);

  useEffect(() => {
    if (window.location.pathname === `/` || window.location.pathname === ``) {
      navigate(`/home`);
    }
  }, [navigate]);

  const useStyles = (chakratheme) => ({
    sidenav: {
      height: '100%',
      position: 'fixed',
      zIndex: 9999,
      top: 0,
      left: 0,
      overflowX: 'hidden',
      transition: '0.5s',
      boxShadow: `${chakratheme.colors.shadow} 0px 0px 10px 0px`,
      // borderRight: '1px dashed rgba(170, 170, 170, 0.5)',
      display: 'flex',
      flexDirection: 'column',
      background: 'rgb(255, 255, 255)',
      backdropFilter: 'blur(6px)'
    },
    button: {
      padding: '22px 11px',
      margin: '2px 17px',
      width: 'calc(100% - 34px)',
      textAlign: 'left',
      justifyContent: 'left',
      borderRadius: '8px'
    },
    icon: {
      height: 24,
      width: 24,
      color: 'black'
    }
  });
  const chakratheme = useTheme();
  const styles = useStyles(chakratheme);

  // eslint-disable-next-line no-unused-vars
  const [menu, setMenu] = useState([
    {
      variant: 'button',
      icon: <Home style={styles.icon} />,
      text: 'Home',
      link: `/home`,
      spacing: 2
    },
    {
      variant: 'list',
      text: 'ASSORTMENT',
      child: [
        {
          variant: 'button',
          icon: <Inventory style={styles.icon} />,
          IconClass: Inventory,
          text: 'Store Assortment',
          link: `/store-assortment`,
          spacing: 2
        },
        {
          variant: 'button',
          icon: <Analytics style={styles.icon} />,
          IconClass: Analytics,
          text: 'Recommendation Analysis',
          link: '/assortment-analysis',
          spacing: 2
        },
        {
          variant: 'button',
          icon: <ListAltOutlined style={styles.icon} />,
          IconClass: ListAltOutlined,
          text: 'Custom Recommendation Analysis',
          link: '/assortment-custom',
          spacing: 2
        }
      ]
    }
  ]);

  const [isCollapsed, setIsCollapsed] = useState(true);

  const handleCollapseToggle = () => {
    setIsCollapsed(!isCollapsed);
  };

  useEffect(() => {
    const isLoggedIn = localStorage.getItem('isLoggedIn');
    const pathname = window.location.pathname;
    if (
      isLoggedIn === 'true' &&
      (pathname === `${process.env.PUBLIC_URL}/login` || pathname === '/')
    ) {
      window.location.pathname = '/home';
    } else if (isLoggedIn !== 'true' && pathname !== `${process.env.PUBLIC_URL}/login`) {
      window.location.pathname = `${process.env.PUBLIC_URL}/login`;
    }
    setLoading(false);
  }, []);

  // const [useCase, setUseCase] = useState('usecase-home');
  // const [console, setConsole] = useState('usecases');
  const [consoleState, setConsoleState] = useState({
    state: configuration
  });

  const setGlobalFilterSelections = (filterID) => (selection) => {
    setConsoleState({
      ...consoleState,
      state: {
        ...consoleState.state,
        globalFilters: {
          ...consoleState.state.globalFilters,
          [filterID]: {
            ...consoleState.state.globalFilters[filterID],
            selected: selection
          }
        }
      }
    });
  };

  // const getDefault = (filterID) => {
  //   return consoleState.state.globalFilters.filterID.default;
  // };

  const setDefault = (filterID) => (defaultSelection) => {
    setConsoleState({
      ...consoleState,
      state: {
        ...consoleState.state,
        globalFilters: {
          ...consoleState.state.globalFilters,
          [filterID]: {
            ...consoleState.state.globalFilters[filterID],
            default: defaultSelection
          }
        }
      }
    });
  };
  const levelNames = (filterID) => {
    return consoleState.state.globalFilters[filterID].levelNames;
  };

  const levelExamples = consoleState.state?.globalFiltersExample;

  return (
    <LocationContext.Provider
      value={{
        filterIDs: Object.keys(consoleState.state.globalFilters),
        consoleState: consoleState,
        setConsoleState: setConsoleState,
        setGlobalFilterSelections: setGlobalFilterSelections,
        globalFiltersLevelNames: levelNames,
        setDefaultFilterValue: setDefault,

        selectedRegions: consoleState.state.globalFilters.region.selected,
        setSelectedRegions: setGlobalFilterSelections('region'),
        selectedCategories: consoleState.state.globalFilters.category.selected,
        setSelectedCategories: setGlobalFilterSelections('category'),
        selectedBrands: consoleState.state.globalFilters.manufacturer.selected,
        setSelectedBrands: setGlobalFilterSelections('manufacturer'),
        selectedRegionsdefault: consoleState.state.globalFilters.region.default
      }}>
      {loading ? null : window.location.pathname !== `${process.env.PUBLIC_URL}/login` ? (
        <ThemeProvider theme={theme}>
          <Box fontFamily={'Montserrat'}>
            <CssBaseline />
            <AppBar
              width="100%"
              name={'Pharma Assortment Console'}
              isCollapsed={isCollapsed}
              setLoading={setLoading}
              notificationPanel={() => <NotificationsPanel />}
              notifications={[]}
              cartLink={() => (
                <ShoppingCartIcon style={{ cursor: 'pointer' }} onClick={() => navigate('/cart')} />
              )}
            />

            <SideBar
              menu={menu}
              margin={true}
              setMenu={setMenu}
              handleCollapseToggle={handleCollapseToggle}
              setIsCollapsed={setIsCollapsed}
              isCollapsed={isCollapsed}
              drawerWidth={drawerWidth}
            />

            <Box
              component="main"
              sx={{
                flexGrow: 1,
                marginLeft: isCollapsed ? '80px' : `${drawerWidth}px`, // Adjust margin based on sidebar state
                transition: 'margin-left 0.3s ease' // Smooth transition for sidebar animation
              }}
              style={{ backgroundColor: 'white' }}>
              <Routes>
                <Route path={`/home`} element={<Homenew />} />
                <Route path={``} element={<Navigate to="/home" replace />} />

                {consoleState.state.pages.storeAssortment.display ? (
                  <Route
                    path={`/store-assortment`}
                    element={
                      <AssortmentPlanning
                        isCollapsed={isCollapsed}
                        open={filtersOpen}
                        setOpen={setFiltersOpen}
                        levelExamples={levelExamples}
                        setSelectedRegionsdefault={setDefault('region')}
                        selectedRegionsdefault={consoleState.state.globalFilters.region.default}
                      />
                    }
                  />
                ) : null}
                {consoleState.state.pages.assortmentAnalysis.display ? (
                  <Route
                    path={`/assortment-analysis`}
                    element={
                      <AssortmentAnalysis
                        open={filtersOpen}
                        setOpen={setFiltersOpen}
                        levelExamples={levelExamples}
                        setSelectedRegionsdefault={setDefault('region')}
                        selectedRegionsdefault={consoleState.state.globalFilters.region.default}
                      />
                    }
                  />
                ) : null}
                {consoleState.state.pages.assortmentCustom.display ? (
                  <Route
                    path={`/assortment-custom`}
                    element={
                      <AssortmentCustom
                        open={filtersOpen}
                        setOpen={setFiltersOpen}
                        levelExamples={levelExamples}
                      />
                    }
                  />
                ) : null}
                {consoleState.state.pages.marketTrends.display ? (
                  <Route
                    path={`/assortment-rankings`}
                    element={<MarketTrends open={filtersOpen} setOpen={setFiltersOpen} />}
                  />
                ) : null}
                {consoleState.state.pages.chatbot.display ? (
                  <Route
                    path={`/assistant`}
                    element={<Chatbot open={filtersOpen} setOpen={setFiltersOpen} />}
                  />
                ) : null}
                {consoleState.state.pages.freshStore.display ? (
                  <Route
                    path={`/new-assortment`}
                    element={
                      <NewAssortment
                        isCollapsed={isCollapsed}
                        open={filtersOpen}
                        setOpen={setFiltersOpen}
                        levelExamples={levelExamples}
                      />
                    }
                  />
                ) : null}
                <Route
                  path={'/profile'}
                  element={
                    <Profile
                      isCollapsed={isCollapsed}
                      categoryLevelNames={levelNames('category')}
                      selectedCategories={consoleState.state.globalFilters.category.selected}
                      setSelectedCategories={setGlobalFilterSelections('category')}
                      levelNames={levelNames('region')}
                      selectedRegions={consoleState.state.globalFilters.region.selected}
                      setSelectedRegions={setGlobalFilterSelections('region')}
                      handleNavigation={handleNavigation}
                      brandLevelNames={levelNames('manufacturer')}
                      selectedBrands={consoleState.state.globalFilters.manufacturer.selected}
                      setSelectedBrands={setGlobalFilterSelections('manufacturer')}
                    />
                  }
                />
                {consoleState.state.pages.cart.display ? (
                  <Route path={'/cart'} exact element={<Cart />} />
                ) : null}
                {consoleState.state.pages.orders.display ? (
                  <Route path={'/orders'} exact element={<Orders />} />
                ) : null}
                {consoleState.state.pages.orders.display ? (
                  <Route path={'/orders/:orderID'} exact element={<OrderDetails />} />
                ) : null}
                <Route
                  path={'/inventoryinfo/:id'}
                  element={<InventoryInfo theme={chakratheme} />}
                />
                <Route
                  path="/store-manager-home"
                  element={<StoreManagerHome theme={chakratheme} />}
                />
              </Routes>
            </Box>
          </Box>
        </ThemeProvider>
      ) : (
        <Routes>
          <Route path={`/login`} element={<Login />} />
        </Routes>
      )}
    </LocationContext.Provider>
  );
}
