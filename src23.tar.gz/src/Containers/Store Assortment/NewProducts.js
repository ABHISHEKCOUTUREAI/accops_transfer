import { Flex, Text } from '@chakra-ui/layout';
import React, { useContext } from 'react';
import {
  Box,
  Popover,
  PopoverArrow,
  PopoverContent,
  PopoverTrigger,
  useTheme
} from '@chakra-ui/react';
import { InfoOutlined } from '@mui/icons-material';
import IconButton from '@mui/material/IconButton';
import { Tooltip } from '@mui/material';
import AssortmentTable from '../../components/Table';
import LayoutCard from '../../components/LayoutCard';
import DownloadIcon from '@mui/icons-material/Download';
import { LocationContext } from '../../Contexts/LocationContext';

export default function NewProducts(props) {
  const chakratheme = useTheme();
  const { consoleState } = useContext(LocationContext);
  return (
    <>
      <Flex w="100%">
        <Flex direction="column" w="100%" style={{ padding: '0px 0' }}>
          <Flex justifyContent="space-between" alignItems="center" mt={5}>
            <Flex flexDir={'row'}>
              <Text fontWeight={'bold'} fontSize="16px" textAlign="left" mb={3}>
                New Product Recommendations
              </Text>
              <Popover placement="right" trigger="hover">
                <PopoverTrigger>
                  <InfoOutlined
                    style={{
                      width: '15px',
                      height: '15px'
                    }}
                    cursor={'pointer'}
                  />
                </PopoverTrigger>
                <PopoverContent maxW="30vh" p={3}>
                  <PopoverArrow />
                  <Text
                    color="black.1000"
                    backgroundColor={'white'}
                    fontSize="11px"
                    wordBreak="break-word"
                    wordWrap="break-word"
                    ml={1}
                    maxW="20vh">
                    {'Products not sold in selected store in past'}
                  </Text>
                </PopoverContent>
              </Popover>
            </Flex>
            <Flex mb={2}>
              <Text mr={2} marginTop="5px">
                {props.newproductsdownload && 'Downloading...'}
              </Text>
              <Tooltip title="Download new product recommendations" placement="top" arrow>
                <IconButton
                  variant="contained"
                  sx={{
                    cursor: 'pointer',
                    backgroundColor: 'white',
                    color: `${chakratheme.colors.primary.main}`,
                    transition: 'color 0.1s',
                    boxShadow: `0 0 20px 0 ${chakratheme.colors.shadow}`,
                    borderRadius: '50px',
                    width: '35px',
                    height: '35px',
                    '&:hover': {
                      backgroundColor: `${chakratheme.colors.primary.main}`,
                      color: 'white'
                    }
                  }}
                  onClick={() => props.downloadCSV(props.newProducts)}>
                  <DownloadIcon sx={{ fontSize: '22px' }} />
                </IconButton>
              </Tooltip>
            </Flex>
          </Flex>
          <AssortmentTable
            loading={props.newProductsLoading}
            data={props.newProducts}
            handlePagination={props.handlePagination2}
            totalProductsCount={props.totalProductsCount2}
            page={props.page2}
            setPage={props.setPage2}
            sortOrder={props.sortOrder2}
            setSortOrder={props.setSortOrder2}
            sortBy={props.sortBy2}
            setSortBy={props.setSortBy2}
            headers={[
              {
                name: 'Product SAP',
                id: 'sap_id',
                sort: '',
                colSpan: 3
              },
              {
                name: 'Description',
                id: 'item_name',
                sort: '',
                colSpan: 5,
                type: 'text'
              },
              {
                name: `Retail Price (${consoleState.state.currency || '$'})`,
                id: 'mrp',
                sort: '',
                colSpan: 4,
                type: 'text'
              }
            ]}
          />
        </Flex>
      </Flex>
      <Flex justifyContent={'center'} h="100%" w="100%" direction={'row'}>
        <Box w="100%" h="100%">
          <LayoutCard
            w="100%"
            heading="% New products recommended"
            value={props.newProductsStat && props.newProductsStat['fraction_new_products']}
            tooltip="Products not sold in last 3 months but part of Assortment list. "
            suffix="%"
            layoutStyle={{
              flex: 1,
              padding: '20px',
              boxShadow: `0 0 30px 0 ${chakratheme.colors.shadow}`,
              height: '20%',
              maxHeight: '200px',
              margin: '10px 0 0px 10px'
            }}></LayoutCard>
        </Box>
      </Flex>
    </>
  );
}
