import { Flex, Text } from '@chakra-ui/layout';
import React, { useContext, useRef, useState, useEffect } from 'react';
import {
  Box,
  useTheme
  // Button
} from '@chakra-ui/react';
// import IconButton from '@mui/material/IconButton';
// import { Tooltip } from '@mui/material';
// import DownloadIcon from '@mui/icons-material/Download';
// import ArrowForwardIcon from '@mui/icons-material/ArrowForward';
// import ArrowBackIcon from '@mui/icons-material/ArrowBack';
// import { Edit, Save } from '@mui/icons-material';
// import { Button } from '@mui/material';
// import EditableTable from '../../components/EditableTable';
import CurrentInventory from '../../components/CurrentInventory';
// import { ShoppingCart } from '@mui/icons-material';
// import discard from '../../Static/discard.png';
import { LocationContext } from '../../Contexts/LocationContext';
import { attachGlobalFilters } from '../../Utils/misc';
import { EditTableNew } from '../../components/EditTableNew';
// import { useNavigate } from 'react-router-dom';
export default function ProductsAssortment(props) {
  const {
    // globalFiltersLevelNames,
    filterIDs,
    consoleState
  } = useContext(LocationContext);
  const chakratheme = useTheme();
  // const navigate = useNavigate();
  const ref = useRef(null);
  const handleScroll = () => {
    ref.current?.scrollIntoView({ behavior: 'smooth' });
  };
  const [filters, setFilters] = useState();

  // const _lastIndex = props.lastIndex(consoleState.state.globalFilters['region'].selected);
  // const _name = globalFiltersLevelNames('region')[_lastIndex];
  // const _value = consoleState.state.globalFilters['region'].selected[_lastIndex];

  useEffect(() => {
    let formData = new FormData();
    formData = attachGlobalFilters(formData, consoleState);
    setFilters(formData);
    console.log('ProductsAssortment: ', formData);
  }, [...filterIDs.map((filter) => consoleState.state.globalFilters[filter].selected)]);
  return (
    <>
      <Box mt={4} w="100%" h="100%">
        <Box w={'100%'}>
          <CurrentInventory
            handleScroll={handleScroll}
            totalproducts={props.totalassortmentcount}
            categories={props.l}
            setAssortmentTableState={props.setAssortmentTableState}
            assortmentTableState={props.assortmentTableState}
            // setAssortmentStatusFilter={props.setAssortmentStatusFilter}
            globalFilters={filters}
            setHeaders={props.setHeaders}
            headers={props.headers}
            values={props.inventoryStatus}></CurrentInventory>
        </Box>
        <Box
          ref={ref}
          w="100%"
          style={{
            borderRadius: '20px',
            boxShadow: `${chakratheme.colors.shadow} 0px 0px 20px 0px`,
            padding: '20px',
            marginTop: '20px'
          }}>
          <Flex
            w="100%"
            justifyContent="space-between"
            alignItems={'center'}
            // marginTop="10px"
            fontFamily={'Poppins'}
            my={5}>
            <Box flex="7">
              <Text mb={0} fontWeight={'bold'} fontSize="15px" textAlign="left">
                Forecasted Demand for Products
                {/* {filterIDs.includes('region') &&
                consoleState.state.globalFilters['region'].selected.some((f) => f) ? (
                  <>
                    (
                    <span
                      style={{
                        color: 'green',
                        fontWeight: 'bold',
                        backgroundColor: `${chakratheme.colors.success.light}`,
                        padding: '2px 3px',
                        borderRadius: '4px'
                      }}>
                      {_value}{' '}
                    </span>{' '}
                    {_name})
                  </>
                ) : null} */}
              </Text>
            </Box>

            {/* <Button
              onClick={() => navigate('/cart')}
              style={{
                color: 'white',
                padding: '10px 15px',
                borderRadius: '8px',
                backgroundColor: `${chakratheme.colors.primary.main}`,
                boxShadow: 'none',
                fontSize: '14px'
              }}>
              <ShoppingCart style={{ fontSize: '16px' }} />
              Go to cart
            </Button> */}
            {/* <Flex mb="1" alignItems={'center'} gap="5px">
              {props.isEdit === true && props.alignment === 'assortment' && (
                <Tooltip title="Discard Changes" placement="top" arrow>
                  <IconButton
                    variant="contained"
                    sx={{
                      cursor: 'pointer',
                      backgroundColor: 'white',
                      color: `${chakratheme.colors.gray.light}`,
                      transition: 'color 0.1s',
                      boxShadow: `none`,
                      border: `1px solid ${chakratheme.colors.gray.light}`,
                      borderRadius: '5px',
                      width: '35px',
                      height: '35px',
                      '&:hover': {
                        backgroundColor: `${chakratheme.colors.gray.lighter}`
                        // color: 'white'
                      },
                      padding: '2px'
                    }}
                    onClick={() => {
                      props.setIsEdit(false);
                      props.hits_and_misses('assortment');
                    }}>
                    <Image
                      src={discard}
                      w="20px"
                      // h="22px"
                      sx={{ filter: chakratheme.colors.gray.light_filter }}
                    />
                  </IconButton>
                </Tooltip>
              )}

              {props.isEdit === true && props.alignment === 'assortment' && (
                <Tooltip title="Save Changes" placement="top" arrow>
                  <IconButton
                    variant="contained"
                    sx={{
                      cursor: 'pointer',
                      backgroundColor: 'white',
                      color: `${chakratheme.colors.gray.light}`,
                      transition: 'color 0.1s',
                      boxShadow: `none`,
                      border: `1px solid ${chakratheme.colors.gray.light}`,
                      borderRadius: '5px',
                      width: '35px',
                      height: '35px',
                      '&:hover': {
                        backgroundColor: `${chakratheme.colors.gray.lighter}`
                        // color: 'white'
                      }
                    }}
                    onClick={() => {
                      props.handleSave();
                    }}>
                    <Save sx={{ fontSize: '22px' }} />
                  </IconButton>
                </Tooltip>
              )}
              {consoleState.state.assortmentTable.editable &&
                props.isEdit === false &&
                props.alignment === 'assortment' && (
                  <Tooltip title="Edit recommended assortment" placement="top" arrow>
                    <IconButton
                      variant="contained"
                      onClick={() => {
                        if (
                          props.selectedRegions[3] === null &&
                          props.selectedCategories[3] === null
                        ) {
                          alert('Select branch code and L3 Category');
                          return;
                        } else if (props.selectedRegions[3] === null) {
                          alert('Select branch code');
                          return;
                        } else if (props.selectedCategories[3] === null) {
                          alert('Select L3 Category');
                          return;
                        }
                        props.setIsEdit(true);
                      }}
                      backgroundColor="black"
                      color="secondary"
                      style={{
                        cursor: 'pointer',
                        backgroundColor: `${chakratheme.colors.primary.main}`,
                        color: 'white',
                        borderRadius: '5px',
                        boxShadow: `0 0 20px 0 ${chakratheme.colors.shadow}`,
                        width: '35px',
                        height: '35px'
                      }}>
                      <Edit sx={{ fontSize: '18px' }} />
                    </IconButton>
                  </Tooltip>
                )}
              {props.isEdit === false && (
                <Flex>
                  <Text marginTop="15px">{props.hitmisscsvloading && 'Downloading...'}</Text>
                  <Tooltip title="Download assortment" placement="top" arrow>
                    <IconButton
                      variant="contained"
                      sx={{
                        cursor: 'pointer',
                        backgroundColor: 'white',
                        color: `${chakratheme.colors.gray.light}`,
                        transition: 'color 0.1s',
                        boxShadow: `none`,
                        border: `1px solid ${chakratheme.colors.gray.light}`,
                        borderRadius: '5px',
                        width: '35px',
                        height: '35px',
                        '&:hover': {
                          backgroundColor: `${chakratheme.colors.primary.main}`,
                          color: 'white'
                        }
                      }}
                      onClick={() => props.downloadCSV3()}>
                      <DownloadIcon sx={{ fontSize: '22px' }} />
                    </IconButton>
                  </Tooltip>
                </Flex>
              )}
            </Flex> */}
          </Flex>
          <EditTableNew
            assortmentTableStateExternal={props.assortmentTableState}
            month={props.month}
          />
          {/* <EditableTable
            assortmentTableState={props.assortmentTableState}
            setAssortmentTableState={props.setAssortmentTableState}
            lastIndex={props.lastIndex}
            data={props.hits_misses_data}
            hits_and_misses={props.hits_and_misses}
            setData={props.set_hits_misses_data}
            handlePagination={props.handlePagination}
            totalProductsCount={props.totalProductsCount}
            setTotalProductsCount={props.setTotalProductsCount}
            finaladdedproducts={props.finaladdedproducts}
            setfinaladdedproducts={props.setfinaladdedproducts}
            L0={props.selectedCategories[0]}
            L3={props.selectedCategories[3]}
            page={props.page1}
            isEdit={props.isEdit}
            setIsEdit={props.setIsEdit}
            loading={props.hitsMissesLoading}
            setPage={props.setPage1}
            sortBy={props.sortBy1}
            setSortBy={props.setSortBy1}
            sortOrder={props.sortOrder1}
            setSortOrder={props.setSortOrder1}
            headers={props.headers}
            setHeaders={props.setHeaders}
            fetchBulkData={props.fetchBulkData}
            uploadedFile={props.uploadedFile}
            setUploadedFile={props.setUploadedFile}
            pinFilters={props.pinFilters}
            setPinFilters={props.setPinFilters}
            categoryNested={props.categoryNested}
            categoryLevelNames={props.categoryLevelNames}
            selectedCategories={props.selectedCategories2}
            setSelectedCategories={props.setSelectedCategories2}
            regions_nested={props.regions_nested}
            levelNames={props.levelNames}
            selectedRegions={props.selectedRegions2}
            setSelectedRegions={props.setSelectedRegions2}
            showCircle={true}
            assortmentStatusFilter={props.assortmentStatusFilter}
            setAssortmentStatusFilter={props.setAssortmentStatusFilter}
            // searchData={props.searchData}
            // setSearchData={props.setSearchData}
            brandData={props.brandData}
            brandLevelNames={props.brandLevelNames}
            selectedBrands={props.selectedBrands}
            setSelectedBrands={props.setSelectedBrands}
          /> */}
        </Box>
      </Box>
    </>
  );
}
