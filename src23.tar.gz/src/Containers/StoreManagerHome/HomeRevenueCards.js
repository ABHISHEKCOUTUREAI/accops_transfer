import { StatsCard } from '../../components/StatsCard';
import { Flex } from '@chakra-ui/react';
export const HomeRevenueCards = () => {
  const cardNames = ['revenue', 'margin', 'sales', 'stores'];
  const totalRevenue = 521815754;
  const totalMargin = 10990027;
  const totalQuantity = 34490908;
  const totalStore = 192;
  const cardMap = {
    revenue: {
      name: 'Total Revenue',
      value: totalRevenue,
      change: 12.5,
      description: 'from the last month',
      ext: '₹',
      backgroundColor: 'black',
      color: 'white'
    },
    margin: {
      name: 'Total Margin',
      value: totalMargin,
      change: 2.5,
      description: 'from the last month',
      ext: '₹',
      backgroundColor: 'white',
      color: 'black'
    },
    sales: {
      name: 'Total Quantity Sold',
      value: totalQuantity,
      change: 2.5,
      description: 'from the last month',
      ext: '',
      backgroundColor: 'white',
      color: 'black'
    },
    stores: {
      name: 'Total Stores',
      value: totalStore,
      change: 10,
      description: 'from the last month',
      ext: '',
      backgroundColor: 'white',
      color: 'black'
    }
  };

  return (
    <>
      <Flex>
        {cardNames.map((c, ind) => (
          <StatsCard
            key={ind}
            header={cardMap[c].name}
            number={cardMap[c].value}
            variation={cardMap[c].change}
            footer={cardMap[c].description}
            bg={cardMap[c].backgroundColor}
            color={cardMap[c].color}
          />
        ))}
      </Flex>
    </>
  );
};
