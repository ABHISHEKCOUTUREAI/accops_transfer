/* eslint-disable no-unused-vars */

import { Box, Flex, Text, useTheme } from '@chakra-ui/react';
import { InfoOutlined } from '@mui/icons-material';
import RingChart from '../../Artifactory/Charts/RingChart';
import { Skeleton, Tooltip } from '@mui/material';
import { NewReleases, RemoveShoppingCart, ReportProblem, Check } from '@mui/icons-material';
import { useState } from 'react';
// import { ArrowUpward } from '@mui/icons-material';

const formatInternationalStandard = (num) => {
  // remove decimal from number
  if (num > 0) {
    const numStr = num.toString().split('.')[0];
    // add commas to number
    return numStr.replace(/(\d)(?=(\d{3})+(?!\d))/g, '$1,');
  } else {
    return num;
  }
};

const statusToIcon = {
  '0_new': NewReleases,
  '9_excess': RemoveShoppingCart,
  '1_replenish': ReportProblem,
  '2_no_replenishment': Check
};
export const HomeCards = (props) => {
  const chakratheme = useTheme();
  const cardNames = ['replenish', 'excess', 'optimal', 'new'];
  const cardMap = {
    excess: {
      name: 'Excess Products',
      value: props.values['excess'],
      change: '12.5%',
      color: `${chakratheme.colors.orange}`,
      id: '9_excess',
      tooltip: 'Products with existing inventory greater than maximum recommended quantity.'
    },
    replenish: {
      name: 'Low Stock Products',
      value: props.values['replenish'],
      change: '12.5%',
      color: 'red',
      id: '1_replenish',
      tooltip:
        'Products with existing inventory less than minimum recommended quantity (These require replenishment)'
    },
    optimal: {
      name: 'Optimal Products',
      value: props.values['optimal'],
      change: '12.5%',
      color: `${chakratheme.colors.success.main}`,
      id: '2_no_replenishment',
      tooltip:
        'Products with existing inventory in between minimum and maximum recommended quantity (These dont require any action)'
    },
    new: {
      name: 'New Products',
      value: props.values['new'],
      change: '12.5%',
      color: 'blue',
      id: '0_new',
      tooltip:
        "Products not in the Store's existing inventory, but are recommended by our assortment."
    }
  };
  const [cardHovered, setCardHovered] = useState(null);

  return (
    <Box w="100%">
      {Object.keys(props.values).length ? (
        <Flex gap="20px">
          <Flex
            flex={1}
            direction="column"
            borderRadius={'20px'}
            style={{
              boxShadow: `${chakratheme.colors.shadow} 0px 0px 20px 0px`,
              margin: '0px 0px',
              backgroundColor: `${chakratheme.colors.primary.main}`
            }}>
            <Text
              fontWeight="bold"
              color={'white'}
              padding={'20px'}
              style={{
                fontFamily: 'Hanken Grotesk'
              }}>
              Inventory Status
            </Text>
            {!props.loading ? (
              <RingChart
                totalproducts={props.totalproducts}
                series={[
                  props.values['excess'],
                  props.values['replenish'],
                  props.values['optimal'],
                  props.values['new']
                ]}
                width="100%"
                label={props.categories}
                title=""
              />
            ) : (
              <Skeleton
                variant="rectangular"
                width="200px"
                height="400px"
                style={{ margin: '10px', borderRadius: '20px' }}
              />
            )}
          </Flex>
          <Flex
            wrap="wrap"
            // w="40%"
            // gap="2%"
            columnGap={'2%'}
            rowGap={'20px'}
            justifyContent={'space-between'}>
            {cardNames.map((card, i) => {
              const Icon = statusToIcon[cardMap[card].id];
              return (
                <Flex
                  key={card}
                  w="48%"
                  // w="250px"
                  // marginLeft="5px"
                  // marginRight="5px"
                  direction="column"
                  cursor={'pointer'}
                  _hover={{
                    backgroundColor:
                      i == 0
                        ? `${chakratheme.colors.primary.hover} !important`
                        : `${chakratheme.colors.heroColorHover} !important`
                  }}
                  onMouseEnter={() => setCardHovered(card)}
                  onMouseLeave={() => setCardHovered(null)}
                  style={{
                    backgroundColor: i == 0 ? `${chakratheme.colors.primary.main}` : 'white',
                    color: i == 0 ? 'white' : 'black',
                    boxShadow: `${chakratheme.colors.shadow} 0px 0px 40px 0px`,
                    padding: '20px 20px 10px 20px',
                    borderRadius: '20px',
                    // borderTopLeftRadius: 0,
                    // borderBottomLeftRadius: 0,
                    fontFamily: 'Hanken Grotesk'
                    // borderLeft: '5px solid',
                    // borderColor: cardMap[card].color
                  }}>
                  <Flex alignItems={'flex-start'} mb="10px" direction={'column'}>
                    <Box
                      mr="2"
                      style={{
                        backgroundColor: cardMap[card].color,
                        width: '20px',
                        height: '5px',
                        borderRadius: '5px'
                      }}></Box>
                    <Flex fir={'row'}>
                      <Text fontWeight={'bold'}>{cardMap[card].name}</Text>
                      {cardMap[card].tooltip && (
                        <Tooltip arrow placement="top-start" title={cardMap[card].tooltip}>
                          <InfoOutlined
                            style={{
                              width: '15px',
                              height: '15px'
                            }}
                            cursor={'pointer'}
                          />
                        </Tooltip>
                      )}
                    </Flex>
                  </Flex>
                  <Flex alignItems={'center'} wrap="wrap">
                    <Icon
                      style={{
                        fontSize: '30px',
                        marginRight: '10px',
                        color: i == 0 ? 'white' : cardMap[card].color,
                        opacity: i == 0 ? 1 : 0.3
                      }}
                    />
                    <Text
                      fontSize={'35px'}
                      color={i == 0 ? 'white' : null}
                      fontWeight={i == 0 ? 'bold' : null}>
                      {formatInternationalStandard(cardMap[card].value)}
                    </Text>
                  </Flex>
                </Flex>
              );
            })}
          </Flex>
        </Flex>
      ) : (
        <Text>No Values</Text>
      )}
    </Box>
  );
};
