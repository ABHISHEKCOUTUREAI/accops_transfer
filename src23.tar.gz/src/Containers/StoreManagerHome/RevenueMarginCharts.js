import { useTheme } from '@emotion/react';
import PastSalesGlobal from '../../Views/PastSalesGlobal';
import { useState } from 'react';
import { ChevronDownIcon } from '@chakra-ui/icons';
import {
  Flex,
  Text,
  Menu,
  Spacer,
  MenuButton,
  MenuList,
  MenuItemOption,
  Button
} from '@chakra-ui/react';
export const RevenueMarginCharts = ({ salesData }) => {
  const chakratheme = useTheme();
  const [graphDuration, setGraphDuration] = useState({
    revenue: 100,
    margin: 100
  });
  const durationList = [3, 6, 12, 100];

  return (
    <Flex mt="40px" gap="10px">
      {['revenue', 'margin'].map((card) => (
        <Flex
          key={card}
          mr="20px"
          width="50%"
          direction="column"
          padding="20px"
          style={{
            boxShadow: `0 0 20px 0 ${chakratheme.colors.shadow}`,
            borderRadius: '20px'
          }}>
          <Flex justifyContent={'center'} alignItems="center">
            <Text
              style={{
                fontFamily: 'Poppins',
                fontWeight: 'bold'
              }}>
              Total {card.charAt(0).toUpperCase() + card.slice(1)}
              <span style={{ color: `${chakratheme.colors.gray.light}`, fontWeight: 'normal' }}>
                {' '}
                over time
              </span>
            </Text>
            <Spacer />
            <Menu matchWidth={true}>
              <MenuButton
                as={Button}
                sx={{
                  display: 'flex',
                  width: '100px',
                  alignItems: 'center',
                  backgroundColor: `${chakratheme.colors.gray.lighter}`,
                  borderRadius: '20px',
                  padding: '5px 10px'
                }}
                // leftIcon={view === 'module' ? <ViewModule /> : <ViewList />}
                rightIcon={<ChevronDownIcon color={`${chakratheme.colors.gray.darker}`} />}>
                <Text color={`${chakratheme.colors.gray.darker}`} fontSize={'12px'}>
                  {' '}
                  {graphDuration[card] === 100 ? 'All time' : `${graphDuration[card]} months`}{' '}
                </Text>
              </MenuButton>
              <MenuList
                alignItems={'center'}
                onMouseEnter={(e) => {
                  e.stopPropagation();
                }}
                zIndex="100"
                fontSize={'12px'}
                borderRadius={'10px'}
                paddingTop="10px"
                paddingBottom="10px"
                backgroundColor={'white'}
                boxShadow={`0 0 10px 0 ${chakratheme.colors.shadow}`}>
                {durationList.map((duration) => (
                  <MenuItemOption
                    cursor="pointer"
                    _hover={{
                      backgroundColor: `${chakratheme.colors.gray[300]}`
                    }}
                    key={duration}
                    value={duration}
                    onClick={(e) => {
                      e.stopPropagation();
                      setGraphDuration((prev) => ({ ...prev, [card]: duration }));
                    }}>
                    {duration === 100 ? 'All time' : `${duration} months`}
                  </MenuItemOption>
                ))}
              </MenuList>
            </Menu>
          </Flex>
          <PastSalesGlobal
            duration={graphDuration[card]}
            salesData={card == 'revenue' ? salesData?.revenue : salesData?.margin}
            name={card}
          />
        </Flex>
      ))}
    </Flex>
  );
};
