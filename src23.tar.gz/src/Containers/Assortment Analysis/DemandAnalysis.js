import { Box, Flex, Text, StatUpArrow, useTheme } from '@chakra-ui/react';
import HorizontalBarChart from '../../Artifactory/Charts/HorizontalBarChart';
import LayoutCard from '../../components/LayoutCard';
import { Skeleton } from '@mui/material';

const DemandAnalysis = (props) => {
  const chakratheme = useTheme();
  return (
    <>
      <Text fontWeight={'bold'} fontSize="16px" textAlign="left" mt="10">
        Demand Analysis
      </Text>
      <Flex w="100%">
        {!props.newProductStatsLoading ? (
          <Box
            mt={1}
            flex="5"
            w="80%"
            borderRadius={'20px'}
            p="10px"
            justifyItems={'center'}
            alignItems={'center'}
            style={{ boxShadow: `0 0 30px 0 ${chakratheme.colors.shadow}` }}>
            <HorizontalBarChart
              categories={[
                'Demand Explained by previous Assortment',
                'Demand Explained By Couture Recommendations',
                'Total Demand'
              ]}
              data={[
                props.newProductsStat && props.newProductsStat['current_explained_demand'],
                props.newProductsStat &&
                  props.newProductsStat['demand_explained_by_reccomendation'],
                props.newProductsStat && props.newProductsStat['total_demand']
              ]}
            />
          </Box>
        ) : (
          <Skeleton
            variant="rectangular"
            width="80%"
            height="200px"
            style={{ margin: '10px', borderRadius: '20px' }}
          />
        )}
        {!props.newProductStatsLoading ? (
          <LayoutCard
            heading="Improvement factor"
            color={true}
            icon={<StatUpArrow boxSize={'30px'} />}
            value={props.newProductsStat && props.newProductsStat['improvement_factor']}
            tooltip="Fraction of demand that we can potentially satisfy / Fraction of demand that is being currently satisfied"
            layoutStyle={{
              flex: 1,
              margin: '10px 0 10px 10px',
              padding: '20px',
              boxShadow: `0 0 30px 0 ${chakratheme.colors.shadow}`,
              backgroundColor:
                props.newProductsStat && props.newProductsStat['improvement_factor'] < 1.0
                  ? `${chakratheme.colors.lightred}`
                  : `${chakratheme.colors.success.light}`,
              color:
                props.newProductsStat && props.newProductsStat['improvement_factor'] < 1.0
                  ? 'red'
                  : 'green',
              borderRadius: '20px',
              fontWeight: 'bold'
            }}></LayoutCard>
        ) : (
          <Skeleton
            variant="rectangular"
            width="20%"
            height="200px"
            style={{ margin: '10px', borderRadius: '20px' }}
          />
        )}
      </Flex>
    </>
  );
};
export default DemandAnalysis;
