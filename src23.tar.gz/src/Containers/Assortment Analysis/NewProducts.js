import { Flex, Text } from '@chakra-ui/layout';
import React from 'react';
import {
  Box,
  Popover,
  PopoverArrow,
  PopoverContent,
  PopoverTrigger,
  useTheme
} from '@chakra-ui/react';
import { InfoOutlined } from '@mui/icons-material';
import IconButton from '@mui/material/IconButton';
import { Tooltip } from '@mui/material';
import AssortmentTable from '../../components/Table';
import LayoutCard from '../../components/LayoutCard';
import DownloadIcon from '@mui/icons-material/Download';

export default function NewProducts(props) {
  const chakratheme = useTheme();
  return (
    <>
      <Flex w="100%">
        <Box w="45%">
          <Flex justifyContent="space-between" alignItems="center" mt={3}>
            <Flex flexDir={'row'}>
              <Text fontWeight={'bold'} fontSize="16px" textAlign="left" mb={3}>
                {props.consoleState.state.constants.assortmentAnalysis.NEW_PRODUCTS_TABLE_TITLE}
              </Text>
              <Popover placement="right" trigger="hover">
                <PopoverTrigger>
                  <InfoOutlined
                    style={{
                      width: '15px',
                      height: '15px'
                    }}
                    cursor={'pointer'}
                  />
                </PopoverTrigger>
                <PopoverContent maxW="30vh" p={3}>
                  <PopoverArrow />
                  <Text
                    color="black.1000"
                    backgroundColor={'white'}
                    fontSize="11px"
                    wordBreak="break-word"
                    wordWrap="break-word"
                    ml={1}
                    maxW="20vh">
                    {
                      'Products not sold in the store in past but requested by customers during analysis period'
                    }
                  </Text>
                </PopoverContent>
              </Popover>
            </Flex>
            <Flex mb={2}>
              <Text mr={2} marginTop="5px">
                {props.newproductsbounceload && 'Downloading...'}
              </Text>
              <Tooltip title="Download new products bounced" placement="top" arrow>
                <IconButton
                  variant="contained"
                  sx={{
                    cursor: 'pointer',
                    backgroundColor: 'white',
                    color: `${chakratheme.colors.primary.main}`,
                    transition: 'color 0.1s',
                    boxShadow: `0 0 20px 0 ${chakratheme.colors.shadow}`,
                    borderRadius: '50px',
                    width: '35px',
                    height: '35px',
                    '&:hover': {
                      backgroundColor: `${chakratheme.colors.primary.main}`,
                      color: 'white'
                    }
                  }}
                  onClick={() => props.downloadCSV2()}>
                  <DownloadIcon sx={{ fontSize: '22px' }} />
                </IconButton>
              </Tooltip>
            </Flex>
          </Flex>
          <AssortmentTable
            loading={props.newProductsLoading}
            data={props.tableData}
            handlePagination={props.handlePagination3}
            sortBy={props.sortBy3}
            setSortBy={props.setSortBy3}
            sortOrder={props.sortOrder3}
            setSortOrder={props.setSortOrder3}
            totalProductsCount={props.tableData && props.tableData.length}
            page={props.page3}
            setPage={props.setPage3}
            headers={props.headers2}
          />{' '}
        </Box>
        <Flex mt={3} ml={4} direction="column" flex="7" style={{ padding: '0px 0' }}>
          <Flex justifyContent="space-between" alignItems="center">
            <Flex flexDir={'row'}>
              <Text ml={2} fontWeight={'bold'} fontSize="16px" textAlign="left" mb={3}>
                {
                  props.consoleState.state.constants.assortmentAnalysis
                    .NEW_PRODUCTS_RECOMMENDATION_TITLE
                }
              </Text>
              <Popover placement="right" trigger="hover">
                <PopoverTrigger>
                  <InfoOutlined
                    style={{
                      width: '15px',
                      height: '15px'
                    }}
                    cursor={'pointer'}
                  />
                </PopoverTrigger>
                <PopoverContent maxW="30vh" p={3}>
                  <PopoverArrow />
                  <Text
                    color="black.1000"
                    backgroundColor={'white'}
                    fontSize="11px"
                    wordBreak="break-word"
                    wordWrap="break-word"
                    ml={1}
                    maxW="20vh">
                    {'Products not sold in selected store in past'}
                  </Text>
                </PopoverContent>
              </Popover>
            </Flex>
            <Flex mb={2}>
              <Text mr={2} marginTop="5px">
                {props.newproductsload && 'Downloading...'}
              </Text>
              <Tooltip title="Download new product recommendations" placement="top" arrow>
                <IconButton
                  variant="contained"
                  sx={{
                    cursor: 'pointer',
                    backgroundColor: 'white',
                    color: `${chakratheme.colors.primary.main}`,
                    transition: 'color 0.1s',
                    boxShadow: `0 0 20px 0 ${chakratheme.colors.shadow}`,
                    borderRadius: '50px',
                    width: '35px',
                    height: '35px',
                    '&:hover': {
                      backgroundColor: `${chakratheme.colors.primary.main}`,
                      color: 'white'
                    }
                  }}
                  onClick={() => props.downloadCSV(props.newProducts)}>
                  <DownloadIcon sx={{ fontSize: '22px' }} />
                </IconButton>
              </Tooltip>
            </Flex>
          </Flex>
          <AssortmentTable
            loading={props.newProductsLoading}
            data={props.newProducts}
            handlePagination={props.handlePagination}
            totalProductsCount={props.totalProductsCount2}
            sortBy={props.sortBy2}
            setSortBy={props.setSortBy2}
            sortOrder={props.sortOrder2}
            setSortOrder={props.setSortOrder2}
            page={props.page2}
            setPage={props.setPage2}
            headers={[
              {
                name: 'Product ID',
                id: 'product_id',
                sort: '',
                colSpan: 2
              },
              {
                name: 'Product Name',
                id: 'product_name',
                sort: '',
                colSpan: 5,
                type: 'text'
              },
              {
                name: 'Actual Sales',
                id: 'num_qty_sold',
                sort: 'desc',
                colSpan: 2
              },
              {
                name: 'Total Amount',
                id: 'total_amount',
                sort: '',
                colSpan: 3
              },
              {
                name: 'Margin',
                id: 'total_margin',
                sort: '',
                colSpan: 2
              }
            ]}
          />
        </Flex>
      </Flex>
      <Flex h="100%" w="100%" direction={'row'} gap="10px" mt="10px">
        <LayoutCard
          w="100%"
          heading="New Products Hit Rate "
          value={props.newProductsStat && props.newProductsStat['new_product_hit_rate']}
          tooltip="Percentage of new products sold in target period."
          style={{ position: 'relative' }}
          suffix="%"
          layoutStyle={{
            flex: 1,
            padding: '20px',
            boxShadow: `0 0 20px 0 ${chakratheme.colors.shadow}`,
            height: '20%',
            maxHeight: '200px',
            margin: '10px 0 10px 0px',
            borderRadius: '20px'
          }}></LayoutCard>
        {/* <LayoutCard
          w="100%"
          heading="% New products recommended"
          value={props.newProductsStat && props.newProductsStat['fraction_new_products']}
          tooltip="Products not sold in last 3 months but part of Assortment list. "
          suffix="%"
          layoutStyle={{
            flex: 1,
            padding: '20px',
            boxShadow: `0 0 20px 0 ${chakratheme.colors.shadow}`,
            height: '20%',
            maxHeight: '200px',
            margin: '10px 0 0px 0px',
            borderRadius: '20px'
          }}></LayoutCard> */}
      </Flex>
    </>
  );
}
