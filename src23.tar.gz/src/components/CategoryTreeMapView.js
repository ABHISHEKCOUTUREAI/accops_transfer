import TreeMap from '../Artifactory/Charts/TreeMap';
import { Flex, ChakraProvider, Text } from '@chakra-ui/react';
import theme from '../theme';
import { useContext, useEffect, useState } from 'react';
import { LocationContext } from '../Contexts/LocationContext';
import { getCategoryAnalyticsAPI } from '../Utils/CategoryAnalyticsAPI';
export const CategoryTreeMapView = ({ filterData }) => {
  const { consoleState } = useContext(LocationContext);
  const categoryAnalyticsAPI = getCategoryAnalyticsAPI(consoleState);
  const [data, setData] = useState({
    name: 'Low Stock Distribution',
    children: []
  });

  // const chakratheme = useTheme();
  const transFormToTreemapView = (data) => {
    return data.map((x) => {
      // Map the current element
      let mappedElement = {
        id: x.category,
        name: x.category,
        value: x.value
      };

      // If the element has children, recursively map them
      if (x.children && Array.isArray(x.children)) {
        mappedElement.children = transFormToTreemapView(x.children);
      }

      return mappedElement;
    });
  };

  const getCategoryLowStockTreeMap = async () => {
    try {
      const res = await categoryAnalyticsAPI.getCategoryLowStockTreeMap(filterData);
      setData((data) => ({ ...data, children: transFormToTreemapView(res.data) }));
    } catch (e) {
      console.log(e);
    }
  };

  useEffect(() => {
    getCategoryLowStockTreeMap();
  }, [filterData]);

  return (
    <ChakraProvider theme={theme}>
      {/* <Flex flex={1} direction={'column'}> */}

      <Flex
        boxShadow={'rgb(231, 231, 231) 0px 0px 20px 0px'}
        mt="20px"
        borderRadius={'20px'}
        w="100%"
        pl="20px">
        <Flex direction="column" my={5} w="100%">
          <Text
            style={{
              fontSize: '16px',
              fontFamily: 'Poppins',
              fontWeight: 'bold',
              marginTop: '0px'
            }}>
            Low stock category distribution
          </Text>
          <TreeMap
            data={data}
            tooltipFormatter={(categoryName, subcategoryName, value) =>
              `${categoryName}${subcategoryName}<br/>Total Stock: ${value}`
            }
          />
        </Flex>
      </Flex>
      {/* </Flex> */}
    </ChakraProvider>
  );
};
