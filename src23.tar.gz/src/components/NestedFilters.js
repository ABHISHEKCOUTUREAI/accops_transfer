/* eslint-disable no-unused-vars */
import { Image } from '@chakra-ui/image';
import { Flex, Text } from '@chakra-ui/layout';
import { IconButton, useTheme } from '@chakra-ui/react';
import { Replay } from '@mui/icons-material';
import { Autocomplete, Divider, InputAdornment, TextField, Tooltip } from '@mui/material';
import { Box } from '@mui/system';
import React from 'react';
const findPathToItemRecursive = (
  item,
  index,
  nestedData,
  currentPath,
  currentIndex,
  selectedItems
) => {
  let i = 0;
  let temp = nestedData;
  let currentOptions;
  //  = Object.keys(nestedData[currentPath[currentIndex]]);
  while (i < currentIndex) {
    temp = temp[currentPath[i]];
    i++;
  }
  currentOptions = Object.keys(temp);
  if (currentIndex === index) {
    if (currentOptions.includes(item)) {
      return [...currentPath, item];
    } else {
      return null;
    }
  } else {
    if (selectedItems[currentIndex] !== null) {
      const temp = findPathToItemRecursive(
        item,
        index,
        nestedData,
        [...currentPath, selectedItems[currentIndex]],
        currentIndex + 1,
        selectedItems
      );
      if (temp) {
        return temp;
      } else {
        return null;
      }
    }
    let i = 0;
    while (i < currentOptions.length) {
      const temp = findPathToItemRecursive(
        item,
        index,
        nestedData,
        [...currentPath, currentOptions[i]],
        currentIndex + 1,
        selectedItems
      );
      if (temp) {
        return temp;
      }
      i++;
    }
    return null;
  }
};
export default function NestedFilters(props) {
  const nestedData = props.nestedData;
  const levelNames = props.levelNames;
  const levelCount = props.levelNames ? props.levelNames.length : 0;

  const findPathToItem = (item, index) => {
    return findPathToItemRecursive(
      item.replace(/\(\d+\)/, '').trim(),
      index,
      nestedData,
      [],
      0,
      props.selectedItems
      // (props.filterCount && props.filterCount[`L${index}`][item]) || 0
    );
  };
  const getOptions = (index) => {
    const currentPath = props.selectedItems.slice(0, index);

    // get non-null path items
    const currentPathItems = currentPath.filter((item) => item !== null);
    const total_len = currentPath.length;
    const non_null_len = currentPathItems.length;
    let temp = nestedData;
    let i = 0;
    while (i < non_null_len && temp) {
      if (currentPathItems[i]) {
        temp = temp[currentPathItems[i]];
      } else {
        temp = temp[currentPathItems[i]];
      }
      i++;
    }
    // merge all the options in the nth level recursively
    const set = new Set();
    const getOptionsRecursive = (nestedData, currIndex) => {
      const keys = nestedData ? Object.keys(nestedData) : [];
      keys.forEach((key) => {
        if (total_len === currIndex) {
          const filterCountKey = `L${index}`;
          if (props.type === 'category') {
            set.add(
              `${key} (${(props.filterCount && props.filterCount[filterCountKey][key]) || 0})`
            );
          } else {
            set.add(key);
          }
        } else {
          getOptionsRecursive(nestedData[key], currIndex + 1);
        }
      });
    };
    getOptionsRecursive(temp, non_null_len);
    //convert set to list
    const options = Array.from(set);
    if (props.type === 'category') {
      options.sort((a, b) => {
        const countA = parseInt(a.match(/\((\d+)\)/)[1], 10);
        const countB = parseInt(b.match(/\((\d+)\)/)[1], 10);
        return countB - countA; // Sort in descending order
      });
    }
    return options;
  };

  const handleBranchSelection = () => {
    // Call the provided callback with the selected branch
    // if(levelNames[0] === 'Zone') props.onBranchSelected(selectedBranch, filter);
    // console.log("filter", filter);
    // props.regionName(filter);
  };

  const chakratheme = useTheme();

  return (
    <Flex alignItems="center" backgroundColor={'e6f4ff'} w="100%">
      <Tooltip title="Reset Filters" placement="bottom" arrow>
        <span>
          <IconButton
            isDisabled={props.nonedit}
            cursor={props.nonedit ? 'not-allowed' : 'pointer'}
            icon={<Replay />}
            style={{ paddingLeft: '10px', paddingRight: '10px' }}
            _hover={{ color: `${chakratheme.colors.black[600]}` }}
            onClick={() => {
              props.setSelectedItems(Array(levelCount).fill(null));
            }}
          />
        </span>
      </Tooltip>
      {levelNames &&
        levelNames.map((filter, index) => {
          // let gradientStart, gradientEnd;

          // if (props.type === 'category') {
          //   gradientStart = 'rgba(250, 123, 123,';
          //   gradientEnd = 'rgba(250, 123, 123,';
          // } else if (props.type === 'region') {
          //   gradientStart = 'rgba(129, 255, 129,';
          //   gradientEnd = 'rgba(129, 255, 129,';
          // } else {
          //   gradientStart = 'rgba(135, 206, 235,';
          //   gradientEnd = 'rgba(135, 206, 235,';
          // }

          // // Add index-based gradient position
          // gradientStart += `${index * 0.25})`;
          // gradientEnd += `${(index + 1) * 0.25})`;
          return (
            <Flex key={index} flex="4">
              <Divider orientation="vertical" flexItem />
              <Autocomplete
                disabled={props.nonedit}
                value={props.selectedItems[index]}
                onChange={(event, newValue) => {
                  if (newValue === null) {
                    // set all items after this index to null
                    const temp = [
                      ...props.selectedItems.slice(0, index),
                      ...Array(levelCount - index).fill(null)
                    ];
                    props.setSelectedItems(temp);
                    return;
                  }
                  // find path to the selected item without knowing the previous items
                  const path_to_item = findPathToItem(newValue, index);
                  let temp = [
                    ...path_to_item,
                    ...Array(levelCount - path_to_item.length).fill(null)
                  ];

                  // temp.forEach((item, i) => {
                  //   if (item !== null && i !== index) {
                  //     const key = item.replace(/\(\d+\)/, '').trim();
                  //     const filterCountKey = `L${i}`;
                  //     if (
                  //       props.type === 'category' &&
                  //       props.filterCount &&
                  //       props.filterCount[filterCountKey]
                  //     ) {
                  //       const countToAdd = props.filterCount[filterCountKey][key] || 0;
                  //       temp[i] = `${item} (${countToAdd})`;
                  //     }
                  //   }
                  // });

                  props.setSelectedItems(temp);
                  if (newValue !== null && newValue !== props.selectedItems[index]) {
                    handleBranchSelection(newValue, filter);
                  }
                }}
                options={getOptions(index)}
                // filterOptions={(x) => x}
                sx={{
                  // border: "1px solid blue",
                  '& .MuiOutlinedInput-root': {
                    border: '0px'
                    // height: "20px"
                    // border: "1px solid yellow",
                    // borderRadius: '0',
                    // padding: '10px'
                  },
                  '& .MuiOutlinedInput-root .MuiOutlinedInput-notchedOutline': {
                    border: `0px solid ${chakratheme.colors.gray.light}`
                  },
                  '& .MuiOutlinedInput-root.Mui-focused .MuiOutlinedInput-notchedOutline': {
                    border: `0px solid ${chakratheme.colors.gray.light}`
                  },

                  width: '100%',
                  height: '55px',
                  padding: '0px'
                }}
                popupIcon={null}
                disablePortal
                id={`combo-box-demo-${filter}`}
                // options={props.options[filter]}
                renderOption={(propss, option) => {
                  return (
                    <Box
                      component="li"
                      style={{
                        // margin: "10px 0",
                        padding: '10px 0px 10px 15px'
                      }}
                      sx={{ '& > img': { mr: 2, flexShrink: 0 } }}
                      {...propss}>
                      <Text
                        // color={props.type == 'region' ? 'green' : 'black'}
                        // color="green"
                        style={{
                          textAlign: 'left'
                        }}
                        textAlign={'left'}>
                        {option}
                      </Text>
                    </Box>
                  );
                }}
                renderInput={(params) => {
                  return (
                    <Flex alignItems={'center'} fontWeight={'bold'} pl="5px" pr="5px">
                      <Image src={props.icons[filter]} boxSize={'25px'} />
                      <TextField
                        sx={{
                          input: {
                            fontWeight: 'bold',
                            fontSize: '14px'
                            // fontWeight: props.selectedItems[index]==null?null: 'bold'
                          }
                        }}
                        error={false}
                        InputProps={{
                          startAdornment: (
                            <InputAdornment position="start">
                              <Image src={props.icons[filter]} boxSize={'25px'} />
                            </InputAdornment>
                          )
                        }}
                        {...params}
                        placeholder={`Select ${filter}`}
                      />
                    </Flex>
                  );
                }}
              />
            </Flex>
          );
        })}
    </Flex>
  );
}
