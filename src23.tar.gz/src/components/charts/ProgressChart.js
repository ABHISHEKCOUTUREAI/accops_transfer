import React, { useRef, useEffect } from 'react';
import * as echarts from 'echarts';

const gaugeData = [
  {
    value: 31,
    name: 'Change',
    title: {
      offsetCenter: ['0%', '0%']
    },
    detail: {
      valueAnimation: true,
      offsetCenter: ['0%', '0%']
    }
  }
];

const ProgressChart = ({ height }) => {
  const chartContainerRef = useRef(null);
  console.log(height);
  useEffect(() => {
    if (chartContainerRef.current) {
      const myChart = echarts.init(chartContainerRef.current);
      myChart.setOption({
        series: [
          {
            type: 'gauge',
            data: gaugeData,
            startAngle: 90,
            endAngle: -270,
            pointer: {
              show: false
            },
            progress: {
              show: true,
              overlap: false,
              roundCap: true,
              clip: false,
              itemStyle: {
                borderWidth: 0,
                borderColor: '#464646'
              }
            },
            tooltip: {
              trigger: 'item'
            },
            axisLine: {
              lineStyle: {
                width: 20
              }
            },
            splitLine: {
              show: false,
              distance: 0,
              length: 10
            },
            axisTick: {
              show: false
            },
            axisLabel: {
              show: false,
              distance: 50
            },
            title: {
              fontSize: 0
            },
            detail: {
              // show: false,
              width: 50,
              height: 44,
              fontSize: 50,
              color: 'inherit',
              borderColor: 'inherit',
              borderRadius: 20,
              borderWidth: 0,
              formatter: '{value}%'
            }
          }
        ]
      });

      return () => {
        myChart.dispose();
      };
    }
  }, [gaugeData]);

  return (
    <div ref={chartContainerRef} style={{ width: '100%', height: height ? height : '300px' }} />
  );
};

export default ProgressChart;
