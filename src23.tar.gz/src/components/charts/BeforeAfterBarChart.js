import React, { useRef, useEffect } from 'react';
import * as echarts from 'echarts';
import { useTheme } from '@chakra-ui/react';

const BeforeAfterBarChart = () => {
  const chartContainerRef = useRef(null);
  const theme = useTheme();

  useEffect(() => {
    if (chartContainerRef.current) {
      const myChart = echarts.init(chartContainerRef.current);
      myChart.setOption({
        tooltip: {
          trigger: 'axis',
          axisPointer: {
            type: 'shadow'
          }
        },
        legend: {},
        grid: {
          left: '3%',
          right: '4%',
          bottom: '3%',
          containLabel: true
        },
        xAxis: [
          {
            type: 'category',
            data: ['Before', 'After']
          }
        ],
        yAxis: [
          {
            type: 'value'
          }
        ],
        series: [
          {
            name: 'Sales value across weeks',
            type: 'bar',
            color: theme.colors.success.main,
            data: [862, 1018],
            emphasis: {
              focus: 'series'
            },
            markLine: {
              lineStyle: {
                type: 'dashed'
              },
              data: [[{ type: 'min' }, { type: 'max' }]]
            }
          }
        ]
      });

      return () => {
        myChart.dispose();
      };
    }
  }, []);

  return <div ref={chartContainerRef} style={{ width: '100%', height: '400px' }} />;
};

export default BeforeAfterBarChart;
