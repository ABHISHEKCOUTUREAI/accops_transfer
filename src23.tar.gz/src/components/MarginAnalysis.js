import { Box, Flex, Text, Divider, useTheme } from '@chakra-ui/react';
import BarGraphChart from '../Artifactory/Charts/BarGraphChart';
import { Skeleton } from '@mui/material';

const MarginAnalysis = (props) => {
  const chakratheme = useTheme();
  return (
    <Box style={{ padding: '20px 0' }}>
      <Text fontWeight={900} fontSize="15px" textAlign="left" mb="5">
        Product Spread Across Margin Ranges
      </Text>
      <Flex width="100%" direction={'row'} gap="10px">
        <Flex
          w="50%"
          direction="column"
          p="5"
          borderRadius={'20px'}
          style={{ boxShadow: `0 0 30px 0 ${chakratheme.colors.shadow}` }}>
          <Text fontWeight={1000} fontSize="13px" textAlign="left">
            {props.consoleState.state.constants.assortmentAnalysis.ASSORTMENT_HITS}
            {/* Recommended products{' '}
            <span
              style={{
                color: `${chakratheme.colors.primary.main}`,
                fontWeight: 'bold',
                backgroundColor: `${chakratheme.colors.primary.lighter}`,
                padding: '2px 3px',
                borderRadius: '4px'
              }}>
              actually
            </span>{' '}
            sold */}
          </Text>
          {props.fullData && props.fullData.hit_bucket ? (
            <BarGraphChart
              xlabel="Total Margin Percentage"
              ylabel="Number of Products"
              data={props.fullData.hit_bucket}
            />
          ) : (
            <Skeleton
              variant="rectangular"
              width="100%"
              height="400px"
              style={{ margin: '10px', borderRadius: '20px' }}
            /> // Empty fragment, you can use null or any other placeholder component as well
          )}
        </Flex>
        <Divider orientation="vertical" />
        <Flex
          w="50%"
          p="5"
          direction="column"
          borderRadius={'20px'}
          style={{ boxShadow: `0 0 30px 0 ${chakratheme.colors.shadow}` }}>
          <Text fontWeight={1000} fontSize="13px" textAlign="left">
            {props.consoleState.state.constants.assortmentAnalysis.ASSORTMENT_MISSES}
            {/* Sold products{' '}
            <span
              style={{
                color: `${chakratheme.colors.primary.main}`,
                fontWeight: 'bold',
                backgroundColor: `${chakratheme.colors.primary.lighter}`,
                padding: '2px 3px',
                borderRadius: '4px'
              }}>
              not covered
            </span>{' '}
            by recommendation */}
          </Text>
          {props.fullData && props.fullData.miss_bucket ? (
            <BarGraphChart
              xlabel="Total Margin Percentage"
              ylabel="Number of Products"
              data={props.fullData.miss_bucket}
            />
          ) : (
            <Skeleton
              variant="rectangular"
              width="100%"
              height="400px"
              style={{ margin: '10px', borderRadius: '20px' }}
            /> // Empty fragment, you can use null or any other placeholder component as well
          )}
        </Flex>
      </Flex>
    </Box>
  );
};
export default MarginAnalysis;
