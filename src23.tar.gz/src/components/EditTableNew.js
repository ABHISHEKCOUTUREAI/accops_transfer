import { useContext, useEffect } from 'react';
import { useXTableState, XTable } from './CommonTable';
import { LocationContext } from '../Contexts/LocationContext';
import { attachGlobalFilters, attachSortFilterData } from '../Utils/misc';
import {
  Flex,
  HStack,
  Input,
  // Button,
  Spinner,
  ChakraProvider,
  IconButton,
  Text,
  useToast
} from '@chakra-ui/react';
import EditIcon from '@mui/icons-material/Edit';
import CheckIcon from '@mui/icons-material/Check';
import CloseIcon from '@mui/icons-material/Close';
import { useState } from 'react';
import axios from 'axios';
import statusColors from '../Views/statusColors';
import {
  // ExpandCircleDown,
  NewReleases,
  RemoveShoppingCart,
  ReportProblem,
  Check
} from '@mui/icons-material';
import { getCartAPI } from '../Utils/CartAPI';
import { useTheme } from '@chakra-ui/react';
import { TableBaseConfig } from '../misc/tableBaseConfig';
import { Chip } from '@mui/material';

export const EditTableNew = ({ assortmentTableStateExternal, month }) => {
  const { filterIDs, consoleState } = useContext(LocationContext);
  const chakratheme = useTheme();
  const cartAPI = getCartAPI(consoleState);
  const toast = useToast();
  const handlePagination = async (state, page) => {
    let formData = new FormData();

    formData.append('page_no', page);

    formData = attachGlobalFilters(formData, consoleState);
    formData = attachSortFilterData(formData, state);

    formData.append('timestamp', month);

    let config = {
      method: 'post',
      url: `${consoleState.state.api.BASE_URL}${consoleState.state.api.ASSORTMENT}`,
      data: formData
    };

    const response = await axios(config);
    return {
      data: response.data[consoleState.state.assortmentTable.types['assortment'].apiKey].map(
        (data) => {
          return {
            ...data,
            cart: data.cart_quantity,
            update_button_loading: false,
            cart_mode: 'disabled', // In this case, show edit icon. In editing show 'x' and 'check' icon
            order_status:
              data.minimum_replenishment > 0
                ? 'notplaced'
                : ['fulfilled', 'notplaced', 'progress', ''][Math.floor(Math.random() * 4)]
          };
        }
      ),
      totalRecords: response.data[`assortment_count`]
    };
  };
  const ElementForCartColumn = ({ row, setRow, value }) => {
    const [_value, _setValue] = useState(value);
    return (
      <HStack>
        <Input
          w="50px"
          type="number"
          h="40px"
          border="1px solid #dddddd"
          borderRadius={'5px'}
          padding="0px 5px"
          value={_value}
          isDisabled={row.cart_mode === 'disabled'}
          onChange={(e) => {
            _setValue(e.target.value);
            // setRow({ ...row, cart: e.target.value });
          }}
        />
        {row.update_button_loading ? (
          <Spinner />
        ) : (
          <Flex gap={'5px'}>
            <IconButton
              variant={row.cart_mode === 'disabled' ? 'outline' : 'solid'}
              icon={row.cart_mode === 'disabled' ? <EditIcon /> : <CheckIcon />}
              style={{
                background: row.cart_mode !== 'disabled' ? chakratheme.colors.green.light : '',
                // padding: '10px 10px',
                borderRadius: '8px',
                color:
                  row.cart_mode !== 'disabled'
                    ? chakratheme.colors.green.main
                    : chakratheme.colors.gray.semilight,
                fontWeight: '400'
              }}
              isDisabled={row.cart_mode !== 'disabled' && _value <= 0}
              onClick={
                row.cart_mode !== 'disabled'
                  ? async () => {
                      try {
                        const data = {
                          quantity: _value,
                          store_id: row.store_id,
                          product_id: row.product_id
                        };
                        setRow({ ...row, update_button_loading: true });
                        const res = await cartAPI.addToCart(data);
                        setRow({
                          ...row,
                          update_button_loading: false,
                          cart_mode: 'disabled',
                          cart: _value
                        });
                        console.log(res.data);
                        toast({
                          title: 'Success.',
                          description: 'Cart updated successfully',
                          status: 'success',
                          duration: 3000,
                          isClosable: true
                        });
                      } catch (e) {
                        setRow({ ...row, update_button_loading: false, cart_mode: 'disabled' });
                        console.log(e);
                        toast({
                          title: 'Failed.',
                          description: 'Cart updated failed',
                          status: 'error',
                          duration: 3000,
                          isClosable: true
                        });
                      }
                    }
                  : () => {
                      setRow({ ...row, cart_mode: 'enabled' });
                    }
              }></IconButton>
            <IconButton
              visibility={row.cart_mode === 'disabled' ? 'hidden' : 'visible'}
              icon={<CloseIcon />}
              style={{
                backgroundColor: chakratheme.colors.error.light,
                color: chakratheme.colors.error.main
              }}
              onClick={() => {
                _setValue(row.cart);
                setRow({ ...row, cart_mode: 'disabled' });
              }}></IconButton>
          </Flex>
        )}
      </HStack>
    );
  };

  const columnTransformers = {
    status: ({ value }) => {
      const statusToBgColor = {
        '0_new': '#caddfc',
        '9_excess': '#f7cfb5',
        '1_replenish': '#fccbc7',
        '2_no_replenishment': '#c3dbca'
      };
      const statusToColor = {
        '0_new': '#4287f5',
        '9_excess': '#Dd6A1F',
        '1_replenish': '#eb4034',
        '2_no_replenishment': '#32a852'
      };
      const statusToName = {
        '0_new': 'New',
        '9_excess': 'Excess',
        '1_replenish': 'Low Stock',
        '2_no_replenishment': 'Optimal'
      };
      const statusToIcon = {
        '0_new': NewReleases,
        '9_excess': RemoveShoppingCart,
        '1_replenish': ReportProblem,
        '2_no_replenishment': Check
      };
      const Icon = statusToIcon[value];
      return (
        <Chip
          icon={
            <Icon
              style={{
                color: statusToColor[value],
                fontSize: '14px'
              }}
            />
          }
          key={value}
          label={statusToName[value]}
          style={{
            fontWeight: 'bold',
            backgroundColor: statusToBgColor[value],
            color: statusToColor[value]
          }}
          size="small"
        />
      );
    },
    recommended_replenishment: ({ value, row }) => {
      const statusToBgColor = {
        '0_new': '#caddfc',
        '9_excess': '#f7cfb5',
        '1_replenish': '#fccbc7',
        '2_no_replenishment': '#c3dbca'
      };
      const statusToColor = {
        '0_new': '#4287f5',
        '9_excess': '#Dd6A1F',
        '1_replenish': '#eb4034',
        '2_no_replenishment': '#32a852'
      };

      const statusToIcon = {
        '0_new': NewReleases,
        '9_excess': RemoveShoppingCart,
        '1_replenish': ReportProblem,
        '2_no_replenishment': Check
      };
      const Icon = statusToIcon[row['status_label']];
      return (
        <Flex
          h="100%"
          p="5px 20px"
          bg={statusToBgColor[row['status_label']]}
          alignItems={'center'}
          gap="5px"
          color={statusToColor[row['status_label']]}>
          <Icon style={{ fontSize: '12px' }} />
          {value}
        </Flex>
      );
    },
    cart: ({ value, row, setRow }) => {
      // const _cartStatus = row.cart == 0 ? ''
      return <ElementForCartColumn value={value} row={row} setRow={setRow} />;
    },
    order_status: ({ value }) => {
      // Return a Button that is going to call the cart API
      if (!value) return null;
      const { statusToBgColor, statusToColor, statusToIcon } = statusColors;
      const valueToKey = {
        progress: 'partial',
        notplaced: 'pending',
        fulfilled: 'done'
      };
      const valueToLabel = {
        progress: 'In Progress',
        notplaced: 'Not Placed',
        fulfilled: 'Fulfilled'
      };
      const _key = valueToKey[value];
      const Icon = statusToIcon[_key];
      return (
        <Chip
          icon={
            <Icon
              style={{
                color: statusToColor[_key],
                fontSize: '14px'
              }}
            />
          }
          label={valueToLabel[value]}
          style={{
            fontWeight: 'bold',
            backgroundColor: statusToBgColor[_key],
            color: statusToColor[_key]
          }}
          size="small"
        />
      );
    }
  };

  const groupTransformers = {
    product_details: ({ row }) => {
      return (
        <Flex direction="column" gap="5px" w="100%">
          <Text fontWeight={'bold'}>{row['product_id']}</Text>
          <Text
            w="100%"
            style={{
              wordBreak: 'break-word !important',
              whiteSpace: 'normal'
            }}>
            {row['product_name']}
          </Text>
        </Flex>
      );
    }
  };

  const columnFilterOptionTransformer = {
    status: {
      status_label: ({ value }) => {
        const statusToBgColor = {
          '0_new': '#caddfc',
          '9_excess': '#f7cfb5',
          '1_replenish': '#fccbc7',
          '2_no_replenishment': '#c3dbca'
        };
        const statusToColor = {
          '0_new': '#4287f5',
          '9_excess': '#Dd6A1F',
          '1_replenish': '#eb4034',
          '2_no_replenishment': '#32a852'
        };
        const statusToName = {
          '0_new': 'New',
          '9_excess': 'Excess',
          '1_replenish': 'Low Stock',
          '2_no_replenishment': 'Optimal'
        };
        const statusToIcon = {
          '0_new': NewReleases,
          '9_excess': RemoveShoppingCart,
          '1_replenish': ReportProblem,
          '2_no_replenishment': Check
        };
        const Icon = statusToIcon[value];
        return (
          <Chip
            icon={
              <Icon
                style={{
                  color: statusToColor[value],
                  fontSize: '14px'
                }}
              />
            }
            key={value}
            label={statusToName[value]}
            style={{
              fontWeight: 'bold',
              backgroundColor: statusToBgColor[value],
              color: statusToColor[value]
            }}
            size="small"
          />
        );
      }
    }
  };

  const filterTransformHeaders = (headers) => {
    return headers
      ?.filter((t) => consoleState.state.features.assortmentTable.headers.includes(t.id))
      .map((t) =>
        columnTransformers[t.id] ? { ...t, transformer: columnTransformers[t.id] } : { ...t }
      )
      .map((t) =>
        columnFilterOptionTransformer[t.id]
          ? {
              ...t,
              filters: {
                ...t.filters,
                discrete: {
                  ...t.filters.discrete,
                  optionTransformer: columnFilterOptionTransformer[t.id][t.filters.filterID]
                }
              }
            }
          : { ...t }
      );
  };

  const filterTransformGroups = (groups) => {
    let groupIds = consoleState.state.features.assortmentTable.groups.map((g) => g.id);
    return groups
      ?.filter((g) => groupIds.includes(g.id))
      .map((g) => ({
        ...g,
        columns: consoleState.state.features.assortmentTable.groups.find((x) => x.id === g.id)
          .columns
      }))
      .map((g) =>
        groupTransformers[g.id] ? { ...g, collapsedTransformer: groupTransformers[g.id] } : { ...g }
      );
  };

  // -------How to make a config-------------
  // 1. Import the base config
  // 2. Filter and transform the headers
  // 3. Filter and transform the groups
  // 4. Take unhideableColumns and defaultHiddenColumns from config
  // 5. Add the pagination function

  const makeTableConfig = (baseConfig) => {
    baseConfig.columns.headers = filterTransformHeaders(baseConfig.columns.headers);
    baseConfig.columns.groups.groups = filterTransformGroups(baseConfig.columns.groups.groups);
    baseConfig.columns.unhideableColumns =
      consoleState.state.features.assortmentTable.unhideableColumns;
    baseConfig.columns.defaultHiddenColumns =
      consoleState.state.features.assortmentTable.defaultHiddenColumns;
    baseConfig.pagination.fetch = handlePagination;
    return baseConfig;
  };

  const config = makeTableConfig(TableBaseConfig);
  const { state: tableState, setState: setTableState } = useXTableState(config);

  useEffect(() => {
    setTableState((state) => ({
      ...state,
      filters: {
        ...state.filters,
        status_label: assortmentTableStateExternal.filtersData.filter_params || []
      }
    }));
  }, [assortmentTableStateExternal.filtersData]);

  useEffect(() => {
    // // console.log('Inside EditTableNew: Filters changed');
    // // setStoreId(consoleState?.state?.globalFilters?.region?.selected[3]);
    // // setTableState(() => ({
    // //   ...state,
    // //   pagination: {...state.pagination, pageNumber}
    // // }))
    // handlePagination(tableState, 1);
    console.log('External hook triggered');
    setTableState((prev) => ({ ...prev, trigger: prev.trigger + 1 }));
  }, [...filterIDs.map((filter) => consoleState.state.globalFilters[filter].selected)]);

  // on change of global filters, handlepaginataion with params
  // useEffect(() => {
  //   handlePagination(tableState, 1);
  // }, []);

  return (
    <ChakraProvider>
      <XTable
        state={tableState}
        setState={setTableState}
        config={config}
        style={{ fontFamily: 'Hanken Grotesk' }}
      />
    </ChakraProvider>
  );
};
