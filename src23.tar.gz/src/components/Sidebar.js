/* eslint-disable no-unused-vars */
import { useContext, useEffect, useState } from 'react';
import { useLocation, useNavigate } from 'react-router-dom';
import couturelogo from '../Static/coutureai_logo.jpeg';
// import couturelogo from '../Static/exl_logo.png';
import { Button, Box, Divider, Flex, Text, Image, Stack, Spacer, useTheme } from '@chakra-ui/react';
import {
  KeyboardArrowDownRounded,
  KeyboardArrowUpRounded,
  CircleRounded,
  AddShoppingCartOutlined,
  BarChartOutlined,
  AddBusinessOutlined,
  QueryStats,
  Timeline,
  ShoppingCart,
  ShoppingCartCheckoutRounded
} from '@mui/icons-material';
import home from '../Static/home.png';
import bot from '../Static/bot.png';
import inventory from '../Static/inventory.png';
import analytics from '../Static/analytics.png';
import bag from '../Static/bag.png';
// import fashionlogo from '../Static/images/fashionlogo.png';
// import user from '../Static/images/user.png';
import settings from '../Static/settings.png';
import logout from '../Static/logout.png';
import { LocationContext } from '../Contexts/LocationContext';

const useStyles = (chakratheme) => ({
  sidenav: {
    height: '100%',
    position: 'fixed',
    zIndex: 1000,
    top: 0,
    left: 0,
    overflowX: 'hidden',
    transition: 'width 0.5s',
    boxShadow: `${chakratheme.colors.shadow} 0px 0px 10px 0px`,
    display: 'flex',
    flexDirection: 'column',
    background: 'rgba(255, 255, 255, 0.8)',
    backdropFilter: 'blur(6px)'
  },
  button: {
    padding: '13px 11px',
    margin: '10px 17px',
    width: 'calc(100% - 34px)',
    textAlign: 'left',
    justifyContent: 'left',
    borderRadius: '8px',
    fontWeight: '400',
    fontSize: '14px',
    transition: 'background-color 0.3s',
    ':hover': {
      backgroundColor: `${chakratheme.colors.gray.lighter}`,
      color: `${chakratheme.colors.gray.dark}`,
      fontWeight: '600'
    }
  },
  stackHeader: {
    padding: '22px 11px',
    margin: '2px 17px',
    width: 'calc(100% - 34px)',
    textAlign: 'left',
    justifyContent: 'left',
    alignItems: 'center',
    borderRadius: '8px',
    color: `${chakratheme.colors.black[600]}`,
    fontWeight: '400',
    fontSize: '14px',
    transition: 'background-color 0.3s',
    ':hover': {
      backgroundColor: `${chakratheme.colors.gray.lighter}`,
      color: `${chakratheme.colors.gray.dark}`,
      fontWeight: '600'
    }
  },
  stackButton: {
    padding: '12px 11px',
    margin: '2px 20px 2px 0',
    width: 'calc(100%)',
    textAlign: 'left',
    justifyContent: 'left',
    borderRadius: '8px',
    color: `${chakratheme.colors.black[600]}`,
    fontWeight: '400',
    fontSize: '14px',
    transition: 'background-color 0.3s',
    ':hover': {
      backgroundColor: `${chakratheme.colors.gray.lighter}`,
      color: `${chakratheme.colors.gray.dark}`,
      fontWeight: '600'
    }
  },
  icon: {
    height: 24,
    width: 24,
    marginRight: '10px'
  },
  stackIcon: {
    height: 30,
    width: 30,
    overflow: 'show',
    // marginRight: '10px',
    // filter: 'invert(61%) sepia(12%) saturate(0%) hue-rotate(279deg) brightness(98%) contrast(90%)',
    transform: 'translate(-27px)',
    backgroundColor: `${chakratheme.colors.primary.lighter}`,
    borderRadius: '8px',
    padding: '5px'
  }
});
const styleFilter = {
  filter: 'invert(27%) sepia(64%) saturate(2635%) hue-rotate(244deg) brightness(87%) contrast(115%)'
};

const SideBar = (props) => {
  const { consoleState } = useContext(LocationContext);
  const chakratheme = useTheme();
  const styles = useStyles(chakratheme);
  const navigate = useNavigate();
  // const [storeId, setStoreId] = useState(consoleState?.state?.globalFilters?.region?.selected[3]);

  // const dispatch = useDispatch();
  // const location.pathname = useLocation();
  // const userStore = useSelector((store) => store.user);
  // const [projectId, setProjectId] = useState('');
  const [isOpen, setIsOpen] = useState(false);
  const location = useLocation();

  // const location.pathname = `${window.location.pathname.pathname.slice(window.location.pathname.pathname.indexOf('/'))}`;
  console.log(location.pathname, 'LOCATION');
  // const [logoutSpacing, setLogoutSpacing] = useState(2);
  // const [isAdmin, setIsAdmin] = useState(false);
  const fullMenu = [
    {
      variant: 'button',
      icon: (
        <Image
          src={home}
          style={{
            height: 24,
            width: 24,
            marginRight: '10px',
            filter:
              'invert(61%) sepia(12%) saturate(0%) hue-rotate(279deg) brightness(98%) contrast(90%)',
            ':hover': {
              filter: 'none'
            }
          }}
        />
      ),
      text: 'Home',
      link: `/home`,
      spacing: 2
    },
    {
      variant: 'list',
      open: [`/store-assortment`, `/new-assortment`].includes(location.pathname) ? true : false,

      text: 'Assortment',
      spacing: 2,
      icon: (
        <Image
          src={inventory}
          style={{
            height: 24,
            width: 24,
            marginRight: '10px',
            filter:
              'invert(61%) sepia(12%) saturate(0%) hue-rotate(279deg) brightness(98%) contrast(90%)'
          }}
        />
      ),
      child: [
        consoleState.state.pages.storeAssortment
          ? {
              variant: 'button',
              icon: <AddShoppingCartOutlined style={styles.stackIcon} />,
              text: 'Existing Stores',
              link: `/store-assortment`
              //   spacing: 2
            }
          : null,
        consoleState.state.pages.freshStore.display
          ? {
              variant: 'button',
              icon: <AddBusinessOutlined style={styles.stackIcon} />,
              text: 'Fresh Store',
              link: `/new-assortment`
              //   spacing: 2
            }
          : null
      ].filter((x) => x)
    },
    {
      variant: 'list',
      open: [`/assortment-analysis`, `/assortment-custom`].includes(location.pathname)
        ? true
        : false,
      text: 'Analytics',
      spacing: 2,
      icon: (
        <Image
          src={analytics}
          style={{
            height: 24,
            width: 24,
            marginRight: '10px',
            filter:
              'invert(61%) sepia(12%) saturate(0%) hue-rotate(279deg) brightness(98%) contrast(90%)'
          }}
        />
      ),
      child: [
        consoleState.state.pages.assortmentAnalysis
          ? {
              variant: 'button',
              icon: <BarChartOutlined style={styles.stackIcon} />,
              text: 'Assortment Analysis',
              link: `/assortment-analysis`,
              spacing: 2
            }
          : null,
        consoleState.state.pages.assortmentCustom
          ? {
              variant: 'button',
              icon: <QueryStats style={styles.stackIcon} />,
              text: 'Catalogue Assessment',
              link: `/assortment-custom`,
              spacing: 2
            }
          : null,
        consoleState.state.pages.marketTrends
          ? {
              variant: 'button',
              icon: <Timeline style={styles.stackIcon} />,
              text: 'Market Trends',
              link: `/assortment-rankings`,
              spacing: 2
            }
          : null
      ].filter((x) => x)
    },
    {
      variant: 'list',
      open: [`/orders`, `/cart`].includes(location.pathname) ? true : false,
      text: 'Manage Stock',
      spacing: 2,
      icon: (
        <Image
          src={bag}
          style={{
            height: 24,
            width: 24,
            marginRight: '10px',
            filter:
              'invert(61%) sepia(12%) saturate(0%) hue-rotate(279deg) brightness(98%) contrast(90%)'
          }}
        />
      ),
      child: [
        consoleState.state.pages.cart
          ? {
              variant: 'button',
              icon: <ShoppingCart style={styles.stackIcon} />,
              text: 'Cart',
              link: `/cart`,
              spacing: 2
            }
          : null,
        consoleState.state.pages.orders
          ? {
              variant: 'button',
              icon: <ShoppingCartCheckoutRounded style={styles.stackIcon} />,
              text: 'Orders',
              link: `/orders`,
              spacing: 2
            }
          : null
      ].filter((x) => x)
    }
    // consoleState.state.pages.chatbot
    //   ? {
    //       variant: 'button',
    //       icon: (
    //         <Image
    //           src={bot}
    //           style={{
    //             height: 24,
    //             width: 24,
    //             marginRight: '10px',
    //             filter:
    //               'invert(61%) sepia(12%) saturate(0%) hue-rotate(279deg) brightness(98%) contrast(90%)',
    //             // transition: 'filter 0.3s',
    //             ':hover': {
    //               filter: 'none'
    //             }
    //           }}
    //         />
    //       ),
    //       text: 'NL Query',
    //       link: `/assistant`,
    //       spacing: 2
    //     }
    //   : null
  ];

  const [menu, setMenu] = useState(
    fullMenu.filter((x) => consoleState.state.menuItems.includes(x.text))
  );
  const [downMenu, setDownMenu] = useState([
    {
      variant: 'button',
      icon: (
        <Image
          src={settings}
          style={{
            height: 24,
            width: 24,
            marginRight: '10px',
            filter:
              'invert(61%) sepia(12%) saturate(0%) hue-rotate(279deg) brightness(98%) contrast(90%)',
            // transition: 'filter 0.3s',
            ':hover': {
              filter: 'none'
            }
          }}
        />
      ),
      text: 'Profile',
      link: '/profile',
      spacing: 2
    },
    {
      variant: 'button',
      icon: (
        <Image
          src={logout}
          style={{
            height: 24,
            width: 24,
            marginRight: '10px',
            filter:
              'invert(61%) sepia(12%) saturate(0%) hue-rotate(279deg) brightness(98%) contrast(90%)',
            // transition: 'filter 0.3s',
            ':hover': {
              filter: 'none'
            }
          }}
        />
      ),
      text: 'Logout',
      link: '/login',
      action: () => {
        localStorage.removeItem('isLoggedIn');
        localStorage.removeItem('role');
      },
      spacing: 2
    }
  ]);

  const handleMenuClick = (tab) => {
    tab.action?.();
    navigate(`${tab.link}`);
  };

  // useEffect(() => {
  //   setStoreId(consoleState?.state?.globalFilters?.region?.selected[3]);
  // }, [...filterIDs.map((filter) => consoleState.state.globalFilters[filter].selected)]);

  // useEffect(() => {
  //   if (!storeId) setMenu(fullMenu.filter((x) => x.text !== 'Manage Stock'));
  //   else setMenu(fullMenu.filter((x) => x));
  // }, [storeId]);

  return (
    <Box
      style={{ ...styles.sidenav, width: isOpen ? '260px' : '80px' }}
      onMouseEnter={() => {
        setIsOpen(true);
        props.setIsCollapsed(false);
        // props.handleCollapseToggle();
      }}
      onMouseLeave={() => {
        setIsOpen(false);
        props.setIsCollapsed(true);
        // props.handleCollapseToggle();
      }}>
      <Box sx={{ flexGrow: 1 }}>
        <Flex direction="column" pt={4} h="100%" pb="30px">
          <Flex mb="15px">
            <Image
              src={`${process.env.PUBLIC_URL}/${process.env.REACT_APP_BRANDING || 'Couture'}/logo.png`}
              // w="40px"
              w="45px"
              objectFit="contain"
              style={{
                // filter:
                //   'invert(100%) sepia(0%) saturate(0%) hue-rotate(93deg) brightness(103%) contrast(103%)',
                margin: '2px 10px 2px 18px',
                // backgroundColor: 'black',
                borderRadius: '8px'
              }}></Image>
            {isOpen ? (
              <Flex
                direction="column"
                w="100%"
                justifyContent={'center'}
                alignItems={'flex-start'}
                fontFamily={'Poppins'}>
                <Flex direction={'column'}>
                  <Text style={{ fontSize: '12px', color: `${chakratheme.colors.primary.main}` }}>
                    {consoleState.state.constants.sidebar.logoTitle}
                  </Text>
                  <Text style={{ fontSize: '16px', fontWeight: 'bold' }}>
                    {consoleState.state.name}
                    <span style={{ color: `${chakratheme.colors.black[400]}` }}>Console</span>
                  </Text>
                </Flex>
              </Flex>
            ) : null}
          </Flex>
          {menu.map((tab, i) => (
            <Box key={i}>
              {tab.variant === 'button' ? (
                <Button
                  onClick={() => handleMenuClick(tab)}
                  variant="menu"
                  //   filter={
                  //     location.pathname === tab.link && !isOpen
                  //       ? 'invert(27%) sepia(64%) saturate(2635%) hue-rotate(244deg) brightness(87%) contrast(115%)'
                  //       : null
                  //   }
                  backgroundColor={
                    location.pathname === tab.link && !isOpen
                      ? `${chakratheme.colors.primary.lighter}`
                      : 'white'
                  }
                  // variant={
                  //   `/${window.location.pathname.pathname.split('/')[2]}` === tab.link ? 'menuSolid' : 'menu'
                  // }
                  sx={styles.button}>
                  <Flex
                    filter={
                      location.pathname === tab.link && !isOpen
                        ? 'invert(28%) sepia(95%) saturate(7170%) hue-rotate(257deg) brightness(97%) contrast(90%)'
                        : null
                    }>
                    {tab.icon}
                  </Flex>
                  {isOpen ? <Box ml={tab.spacing}>{tab.text}</Box> : ''}
                </Button>
              ) : (
                <>
                  <Flex
                    transition="width 0.2s"
                    alignItems="center"
                    cursor={'pointer'}
                    onClick={() => {
                      setMenu([
                        ...menu.slice(0, i),
                        { ...tab, open: !tab.open },
                        ...menu.slice(i + 1)
                      ]);
                    }}>
                    <Flex direction="row" sx={styles.stackHeader}>
                      {tab.icon}
                      {isOpen ? <Box ml={tab.spacing}>{tab.text}</Box> : ''}
                      <Spacer />
                      {isOpen ? (
                        tab.open ? (
                          <KeyboardArrowUpRounded
                            style={{ color: `${chakratheme.colors.gray.light}` }}
                          />
                        ) : (
                          <KeyboardArrowDownRounded
                            style={{ color: `${chakratheme.colors.gray.light}` }}
                          />
                        )
                      ) : null}
                    </Flex>
                  </Flex>
                  {tab.open ? (
                    <Stack
                      direction="row"
                      mt={2}
                      mb={2}
                      borderLeft={`1px solid ${chakratheme.colors.gray[300]}`}
                      ml="40px">
                      {/* <Divider
                        h="100%"
                        ml="40px"
                        border="1px solid rgba(240, 240, 240, 1)"
                        orientation="vertical"
                        // borderColor="rgba(180, 180, 180, 1)"
                      /> */}
                      <Flex direction="column" w="100%">
                        {tab.child.map((child, index) => (
                          <Box key={index} p="0 10px 0 0px" w="100%">
                            <Button
                              h="50px"
                              w="30px"
                              onClick={() => handleMenuClick(child)}
                              variant={location.pathname === child.link ? 'menu' : 'menu'}
                              style={{
                                backgroundColor: isOpen
                                  ? location.pathname === child.link
                                    ? `${chakratheme.colors.primary.lighter}`
                                    : 'white'
                                  : 'white',
                                color:
                                  location.pathname === child.link && !isOpen
                                    ? `${chakratheme.colors.primary.main}`
                                    : null
                              }}
                              sx={styles.stackButton}>
                              {location.pathname === child.link && !isOpen ? (
                                <Box w="30px" h="30px">
                                  {child.icon}
                                </Box>
                              ) : (
                                <CircleRounded
                                  style={{
                                    transform: 'translate(-14px)',
                                    fontSize: '4px',
                                    color: 'rgba(180, 180, 180, 1)'
                                  }}
                                />
                              )}
                              {/* {child.icon} */}
                              {isOpen ? <Box ml={child.spacing}>{child.text}</Box> : null}
                            </Button>
                          </Box>
                        ))}
                      </Flex>
                    </Stack>
                  ) : null}
                </>
              )}
            </Box>
          ))}
          <Spacer />
          {downMenu.map((tab, i) => (
            <Box key={i}>
              {tab.variant === 'button' ? (
                <Button
                  onClick={() => handleMenuClick(tab)}
                  variant="menu"
                  backgroundColor={
                    location.pathname === tab.link ? `${chakratheme.colors.gray[300]}` : 'white'
                  }
                  sx={styles.button}>
                  <Flex
                    filter={
                      location.pathname === tab.link && !isOpen
                        ? 'invert(28%) sepia(95%) saturate(7170%) hue-rotate(257deg) brightness(97%) contrast(90%)'
                        : null
                    }>
                    {tab.icon}
                  </Flex>
                  {isOpen ? <Box ml={tab.spacing}>{tab.text}</Box> : ''}
                </Button>
              ) : (
                <>
                  <Flex py={1} alignItems="center" mt={4}>
                    <Flex direction="row" sx={styles.button}>
                      {tab.icon}
                      {isOpen ? <Box ml={tab.spacing}>{tab.text}</Box> : ''}
                    </Flex>
                  </Flex>
                  <Stack direction="row" height="90px">
                    <Divider
                      ml="40px"
                      orientation="vertical"
                      borderColor="rgba(180, 180, 180, 1)"
                    />
                    <Flex direction="column">
                      {tab.child.map((child, index) => (
                        <Box key={index} p="0 0 0 0px">
                          {isOpen ? (
                            <Button
                              onClick={() => handleMenuClick(child)}
                              variant={location.pathname === child.link ? 'menu' : 'menu'}
                              style={{
                                backgroundColor:
                                  location.pathname === child.link
                                    ? `${chakratheme.colors.gray[300]}`
                                    : 'white'
                              }}
                              sx={styles.button}>
                              {child.icon}
                              <Box ml={child.spacing}>{child.text}</Box>
                            </Button>
                          ) : (
                            ''
                          )}
                        </Box>
                      ))}
                    </Flex>
                  </Stack>
                </>
              )}
            </Box>
          ))}
        </Flex>
      </Box>
    </Box>
  );
};

export default SideBar;
