/* eslint-disable react/no-unescaped-entities */
import {
  Box,
  Flex,
  Text
  // Spacer,
  // Image,
  //   CircularProgress,
  //   CircularProgressLabel
  //   Spacer,
  //   Menu,
  //   MenuButton,
  //   Button,
  //   MenuItemOption,
  //   MenuList
} from '@chakra-ui/react';
// import { useContext } from 'react';
import { useTheme } from '@chakra-ui/react';

import {} from // Tab
//   IconButton
'@mui/material';
// import { TabPanel, TabContext, TabList } from '@mui/lab';
// import brand from '../Static/brand.png';
import StackedLineChartIcon from '@mui/icons-material/StackedLineChart';
import AttachMoneyIcon from '@mui/icons-material/AttachMoney';
import SignalCellularAltIcon from '@mui/icons-material/SignalCellularAlt';
import AnalyticsIcon from '@mui/icons-material/Analytics';
// import { LocationContext } from '../Contexts/LocationContext';

const MetricsComponent = (props) => {
  //   const { consoleState } = useContext(LocationContext);
  const chakratheme = useTheme();

  //   const getStats = async (data) => {
  //     try {
  //       let config = {
  //         method: 'POST',
  //         url: `${consoleState.state.api.BASE_URL}/metrics`,
  //         data: data
  //       };

  //       const res = await axios(config);
  //       return res.data;
  //     } catch (error) {
  //       console.log(error);
  //     }
  //   };

  //   const stats = {
  //     model_percentage_error: 36,
  //     baseline_absolute_error: 16,
  //     model_absolute_error: 19,
  //     baseline_percentage_error: 60.46,
  //     model_rmse: 25,
  //     baseline_rmse: 24
  //   };

  const cards = [
    'model_absolute_error',
    'baseline_absolute_error',
    'model_percentage_error',
    'baseline_percentage_error',
    'model_rmse',
    'baseline_rmse'
  ];
  const cardMap = {
    model_absolute_error: {
      name: 'Model Absolute Error',
      icon: AttachMoneyIcon,
      color: `${chakratheme.colors.primary.lighter}`,
      textColor: `${chakratheme.colors.primary.main}`,
      ext: ''
    },
    baseline_absolute_error: {
      name: 'Baseline Absolute Error',
      icon: AnalyticsIcon,
      color: `${chakratheme.colors.primary.lighter}`,
      textColor: `${chakratheme.colors.primary.main}`,
      ext: ''
    },
    model_percentage_error: {
      name: 'Model Percentage Error',
      icon: StackedLineChartIcon,
      color: `${chakratheme.colors.primary.lighter}`,
      textColor: `${chakratheme.colors.primary.main}`,
      ext: ''
    },
    baseline_percentage_error: {
      name: 'Baseline Percentage Error',
      icon: SignalCellularAltIcon,
      color: `${chakratheme.colors.primary.lighter}`,
      textColor: `${chakratheme.colors.primary.main}`,
      ext: ''
    },
    model_rmse: {
      name: 'Model RMSE',
      icon: SignalCellularAltIcon,
      color: `${chakratheme.colors.primary.lighter}`,
      textColor: `${chakratheme.colors.primary.main}`,
      ext: ''
    },
    baseline_rmse: {
      name: 'Baseline RMSE',
      icon: SignalCellularAltIcon,
      color: `${chakratheme.colors.primary.lighter}`,
      textColor: `${chakratheme.colors.primary.main}`,
      ext: ''
    }
  };
  return (
    <Flex direction="column" w="100%" mt={3}>
      <Box w="100%">
        {props.statistics ? (
          <Flex w="100%" flexWrap={'wrap'} justifyContent={'space-between'}>
            {cards.map((card, i) => {
              //   const Icon = cardMap[card].icon;
              return (
                <Flex
                  key={card}
                  w="32%"
                  margin="8px 0px"
                  direction="column"
                  style={{
                    backgroundColor: 'white',
                    color: i == 'black',
                    boxShadow: `${chakratheme.colors.shadow} 0px 0px 20px 0px`,
                    padding: '20px',
                    borderRadius: '20px',
                    fontFamily: 'Hanken Grotesk'
                  }}>
                  <Text fontWeight={'bold'} mb="20px">
                    {cardMap[card].name}
                  </Text>
                  <Flex alignItems={'center'} wrap="wrap">
                    <Text fontSize={'36px'} fontWeight={'bold'}>
                      {cardMap[card].ext}
                      {props.statistics[card] ? `${props.statistics[card]}` : '-'}
                    </Text>
                  </Flex>
                </Flex>
              );
            })}
          </Flex>
        ) : null}
      </Box>
    </Flex>
  );
};
export default MetricsComponent;
