/* eslint-disable no-unused-vars */
import { Flex, Text, ChakraProvider, Select } from '@chakra-ui/react';
import DonutGraphChart from '../Artifactory/Charts/DonutGraphChart';
import theme from '../theme';
import { useEffect, useState } from 'react';
export const CategoryDonutView = ({ data }) => {
  const options = [
    {
      title: 'L0',
      value: 'l0_data'
    },
    {
      title: 'L1',
      value: 'l1_data'
    },
    {
      title: 'L2',
      value: 'l2_data'
    },
    {
      title: 'L3',
      value: 'l3_data'
    },
    {
      title: 'L4',
      value: 'l4_data'
    }
  ];
  const [selectedOption, setSelectedOption] = useState(options[0].value);
  const [currentKey, setCurrentKey] = useState(''); // This is required because of the format backend sends the data in

  const transformData = (data) => {
    // Used to transform data into format required for displaying donut chart
    // return data?.map((x) => ({ name: x[currentKey], value: x.count }));
    const sortedArray = data?.sort((a, b) => -a.count + b.count) ?? [];
    const othersCount = sortedArray.slice(10).reduce((acc, x) => {
      return acc + x.count;
    }, 0);
    return [
      ...sortedArray.slice(0, 10).map((x) => ({ name: x[currentKey], value: x.count })),
      {
        name: 'Others',
        value: othersCount
      }
    ];
  };

  useEffect(() => {
    setCurrentKey(selectedOption.split('_')[0]); // This is required because of the format backend sends the data in
  }, [selectedOption]);
  return (
    <>
      <ChakraProvider theme={theme}>
        <Flex flex={1} direction={'column'} height={'100%'}>
          <Flex
            boxShadow={'rgb(231, 231, 231) 0px 0px 20px 0px'}
            borderRadius={'20px'}
            direction={'column'}
            gap={2}
            height={'100%'}>
            <Text
              style={{
                fontSize: '16px',
                fontFamily: 'Poppins',
                fontWeight: 'bold'
              }}
              mt={5}
              mx={5}>
              Category Distribution
            </Text>
            <Select
              // mx={'auto'}
              mx={'20px'}
              w={'90%'}
              maxW={'400px'}
              value={selectedOption}
              onChange={(e) => setSelectedOption(e.target.value)}>
              {options.map((o, i) => (
                <option key={i} value={o.value}>
                  {o.title}
                </option>
              ))}
            </Select>
            <DonutGraphChart
              formattedData={{
                name: 'Hello',
                data: transformData(data[selectedOption]),
                tooltipPrefix: 'Items'
              }}
            />
          </Flex>
        </Flex>
      </ChakraProvider>
    </>
  );
};
