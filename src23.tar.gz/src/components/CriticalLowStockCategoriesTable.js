import { BaseChakraTableComponent } from './BaseChakraTableComponent';
// import ReportProblemIcon from '@mui/icons-material/ReportProblem';
import { Flex, Card, ChakraProvider, Text } from '@chakra-ui/react';
// import { lowStockCategoriesData } from '../Utils/mockData/CriticalLowStockData';
import theme from '../theme';
import { Check, FiberManualRecord, RemoveShoppingCart, WarningRounded } from '@mui/icons-material';
import { Chip } from '@mui/material';
import { useContext, useEffect, useState } from 'react';
import { getCategoryAnalyticsAPI } from '../Utils/CategoryAnalyticsAPI';
import { LocationContext } from '../Contexts/LocationContext';
export const CriticalLowStockCategoriesTable = ({ filterData, ...props }) => {
  const { consoleState } = useContext(LocationContext);
  const categoryAnalyticsAPI = getCategoryAnalyticsAPI(consoleState);
  const [data, setData] = useState([]);
  const [loading, setLoading] = useState(false);
  const [dataForCurrentPage, setDataForCurrentPage] = useState([]);
  const [pageNo, setPageNum] = useState(0);
  const [maxPages, setMaxPages] = useState(0);
  const itemsPerPage = 6;
  const statusToBgColor = {
    // '0_new': '#caddfc',
    partial: '#f7cfb5',
    unfulfilled: '#fccbc7',
    fulfilled: '#c3dbca'
  };
  const statusToColor = {
    // '0_new': '#4287f5',
    partial: '#Dd6A1F',
    unfulfilled: '#eb4034',
    fulfilled: '#32a852'
  };
  const statusToName = {
    // '0_new': 'New',
    partial: 'Partial',
    unfulfilled: 'Pending',
    fulfilled: 'Fulfilled'
  };
  const statusToIcon = {
    // '0_new': NewReleases,
    partial: RemoveShoppingCart,
    unfulfilled: FiberManualRecord,
    fulfilled: Check
  };

  // const hea ders = ['Category', 'Total Deficit', 'Fulfillment'];
  const headers = [
    {
      title: 'Category',
      key: 'category'
      // sort: 'default'
    },
    {
      title: 'Total Deficit',
      key: 'total_deficit'
      // sort: 'default'
    }
    // {
    //   title: 'Fulfillment',
    //   key: 'fulfillment',
    //   sort: null
    // }
  ];
  const transformers = {
    total_deficit: (row) => (
      <Flex gap={'10px'}>
        <Text alignContent={'flex-end'}>{row.total_deficit}</Text>
      </Flex>
    ),
    fulfillment: (v) => {
      const Icon = statusToIcon[v.status];
      return (
        <Flex gap={'10px'}>
          <Chip
            icon={
              <Icon
                style={{
                  color: statusToColor[v.status],
                  fontSize: '14px'
                }}
              />
            }
            value={statusToName[v.status]}
            label={`${statusToName[v.status]} ${v.added ? '(' + v.added + ')' : ''}`}
            style={{
              fontWeight: 'bold',
              fontSize: '12px',
              backgroundColor: statusToBgColor[v.status],
              color: statusToColor[v.status]
            }}
            size="small"
          />
        </Flex>
      );
    }
  };

  const getDataForPage = (i) => {
    return data.slice((i - 1) * itemsPerPage, i * itemsPerPage);
  };

  useEffect(() => {
    setDataForCurrentPage(getDataForPage(pageNo));
  }, [pageNo]);

  const getCriticalLowStockAnalyticsData = async (entries) => {
    try {
      filterData.append('page_count', entries);
      setLoading(true);
      const res = await categoryAnalyticsAPI.getCategoryAnalytics(filterData);
      setData(res.data);
      setMaxPages(Math.ceil(res.data.length / itemsPerPage));
      setPageNum(1);
      setLoading(false);
    } catch (e) {
      console.log(e);
      setLoading(false);
    }
  };

  useEffect(() => {
    getCriticalLowStockAnalyticsData(100);
  }, [filterData]);
  return (
    <ChakraProvider theme={theme}>
      <Card
        borderRadius={'20px'}
        {...props}
        p="20px"
        mt="20px"
        boxShadow={'rgb(231, 231, 231) 0px 0px 20px 0px'}>
        <Flex direction={'column'}>
          <Flex gap="5px">
            <WarningRounded style={{ color: 'red' }} />
            <Text
              style={{
                fontSize: '16px',
                fontFamily: 'Poppins',
                fontWeight: 'bold',
                marginTop: '0px'
              }}>
              Categories with critical low stock
            </Text>
          </Flex>

          <BaseChakraTableComponent
            rowData={dataForCurrentPage}
            headers={headers}
            columDataTransformers={transformers}
            totalPages={maxPages}
            currentPage={pageNo}
            nexPageCallback={(newPage) => setPageNum(newPage)}
            layout="fixed"
            loading={loading}
            style={{
              fontFamily: 'Arial, sans-serif',
              fontSize: '14px',
              height: '369px',
              overflow: 'auto',
              borderRadius: '0px',
              marginTop: '10px',
              border: '1px solid #eeeeee'
            }}
          />
        </Flex>
      </Card>
    </ChakraProvider>
  );
};
