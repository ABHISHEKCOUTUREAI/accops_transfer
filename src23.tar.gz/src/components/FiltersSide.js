/* eslint-disable no-unused-vars */
import { Image } from '@chakra-ui/image';
import { Flex, Text } from '@chakra-ui/layout';
import { Button, useTheme, useToast } from '@chakra-ui/react';
import { Autocomplete, InputAdornment, TextField, ThemeProvider, createTheme } from '@mui/material';
import { Box } from '@mui/system';
import React, { useContext } from 'react';
import { LocationContext } from '../Contexts/LocationContext';
import { useLocation } from 'react-router-dom';
const findPathToItemRecursive = (
  item,
  index,
  nestedData,
  currentPath,
  currentIndex,
  selectedItems
) => {
  let i = 0;
  let temp = nestedData;
  let currentOptions;
  //  = Object.keys(nestedData[currentPath[currentIndex]]);
  while (i < currentIndex) {
    temp = temp[currentPath[i]];
    i++;
  }
  currentOptions = Object.keys(temp);
  if (currentIndex === index) {
    if (currentOptions.includes(item)) {
      return [...currentPath, item];
    } else {
      return null;
    }
  } else {
    if (selectedItems[currentIndex] !== null) {
      const temp = findPathToItemRecursive(
        item,
        index,
        nestedData,
        [...currentPath, selectedItems[currentIndex]],
        currentIndex + 1,
        selectedItems
      );
      if (temp) {
        return temp;
      } else {
        return null;
      }
    }
    let i = 0;
    while (i < currentOptions.length) {
      const temp = findPathToItemRecursive(
        item,
        index,
        nestedData,
        [...currentPath, currentOptions[i]],
        currentIndex + 1,
        selectedItems
      );
      if (temp) {
        return temp;
      }
      i++;
    }
    return null;
  }
};
export default function FiltersSide(props) {
  const { consoleState } = useContext(LocationContext);
  const location = useLocation();
  const toast = useToast();
  const nestedData = props.nestedData;
  const levelNames =
    location.pathname.includes('new-assortment') && props.type === 'region'
      ? props.levelNames.slice(0, 3)
      : props.levelNames;

  const levelCount = props.levelNames ? props.levelNames.length : 0;

  const findPathToItem = (item, index) => {
    return findPathToItemRecursive(
      item.replace(/\(\d+\)/, '').trim(),
      index,
      nestedData,
      [],
      0,
      props.selectedItems
      // (props.filterCount && props.filterCount[`L${index}`][item]) || 0
    );
  };
  const getOptions = (index) => {
    const currentPath = props.selectedItems.slice(0, index);

    // get non-null path items
    const currentPathItems = currentPath.filter((item) => item !== null);
    const total_len = currentPath.length;
    const non_null_len = currentPathItems.length;
    let temp = nestedData;
    let i = 0;
    while (i < non_null_len && temp) {
      temp = temp[currentPathItems[i]];
      i++;
    }
    // merge all the options in the nth level recursively
    const set = new Set();
    const getOptionsRecursive = (nestedData, currIndex) => {
      const keys = nestedData ? Object.keys(nestedData) : [];
      keys.forEach((key) => {
        if (total_len === currIndex) {
          const filterCountKey = consoleState.state.globalFilters.category.levelNames[index];
          // const filterCountKey = `L${index}`;
          if (props.type === 'category' && props.filter !== 'markettrends') {
            console.log('___6565', props.filterCount, filterCountKey, key);
            set.add(
              `${key} (${(props.filterCount && props.filterCount[filterCountKey][key]) || 0})`
            );
          } else {
            set.add(key);
          }
        } else {
          getOptionsRecursive(nestedData[key], currIndex + 1);
        }
      });
    };
    getOptionsRecursive(temp, non_null_len);
    //convert set to list
    const options = Array.from(set);
    if (props.type === 'category' && props.filter !== 'markettrends') {
      options.sort((a, b) => {
        const countA = parseInt(a.match(/\((\d+)\)/)[1], 10);
        const countB = parseInt(b.match(/\((\d+)\)/)[1], 10);
        return countB - countA; // Sort in descending order
      });
    }
    return options;
  };

  const chakratheme = useTheme();

  console.log('props.default', props.selectedItems, props.selectedRegionsdefault);

  return (
    <ThemeProvider theme={() => createTheme()}>
      <Flex
        alignItems="center"
        justifyContent={'center'}
        direction="column"
        backgroundColor={'e6f4ff'}
        w="100%">
        {levelNames &&
          levelNames.map((filter, index) => {
            return (
              <Flex mt="10" key={index} m="5" bg="white" w="95%" direction="column">
                {/* <Divider orientation="vertical" flexItem /> */}
                <Text style={{ fontSize: '14px', fontFamily: 'Poppins' }}>{filter}</Text>
                <Autocomplete
                  disabled={props.nonedit}
                  value={props.selectedItems[index]}
                  onChange={(event, newValue) => {
                    if (newValue === null) {
                      // set all items after this index to null
                      const temp = [
                        ...props.selectedItems.slice(0, index),
                        ...Array(levelCount - index).fill(null)
                      ];
                      props.setSelectedItems(temp);
                      return;
                    }
                    // find path to the selected item without knowing the previous items
                    const path_to_item = findPathToItem(newValue, index);
                    let temp = [
                      ...path_to_item,
                      ...Array(levelCount - path_to_item.length).fill(null)
                    ];

                    props.setSelectedItems(temp);
                  }}
                  options={getOptions(index)}
                  // filterOptions={(x) => x}
                  sx={{
                    width: '100%',
                    height: '55px',
                    padding: '0px'
                  }}
                  popupIcon={null}
                  disablePortal
                  id={`combo-box-demo-${filter}`}
                  // options={props.options[filter]}
                  renderOption={(propss, option) => {
                    return (
                      <Box
                        component="li"
                        style={{
                          // margin: "10px 0",
                          padding: '10px 0px 10px 15px'
                        }}
                        sx={{ '& > img': { mr: 2, flexShrink: 0 } }}
                        {...propss}>
                        <Text
                          style={{
                            textAlign: 'left'
                          }}
                          textAlign={'left'}>
                          {option}
                        </Text>
                      </Box>
                    );
                  }}
                  renderInput={(params) => {
                    return (
                      <Flex alignItems={'center'} fontWeight={'bold'} pr="5px">
                        <TextField
                          sx={{
                            input: {
                              fontWeight: 'bold',
                              fontSize: '14px'
                            }
                          }}
                          error={false}
                          InputProps={{
                            startAdornment: (
                              <InputAdornment position="start">
                                <Image src={props.icons[filter]} boxSize={'25px'} />
                              </InputAdornment>
                            )
                          }}
                          {...params}
                          placeholder={`Eg. ${props.levelExamples[filter]}`}
                        />
                      </Flex>
                    );
                  }}
                />
              </Flex>
            );
          })}
        <Flex justifyContent={props.default ? 'space-between' : 'flex-end'} w="100%">
          {props.default &&
            props.selectedItems[3] &&
            props.selectedRegionsdefault[3] !== props.selectedItems[3] && (
              <Button
                mr="2"
                ml={9}
                mt={4}
                mb={7}
                style={{
                  // color: `${chakratheme.colors.primary.main}`,
                  color: `${chakratheme.colors.primary.main}`,
                  backgroundColor: `${chakratheme.colors.primary.lighter}`,
                  borderRadius: '13px',
                  padding: '5px 10px'
                }}
                onClick={() => {
                  if (props.selectedItems[3]) {
                    props.setSelectedRegionsdefault(props.selectedItems);
                    toast({
                      title: 'Default store updated successfully',
                      status: 'success',
                      duration: 3000,
                      isClosable: true
                    });
                  } else {
                    alert('Select store to update the default store');
                  }
                }}>
                Save this store as default
              </Button>
            )}
          <Button
            mr="2"
            style={{
              color: `${chakratheme.colors.primary.main}`,
              borderRadius: '0',
              padding: '5px 10px'
            }}
            onClick={() => {
              props.setSelectedItems(Array(levelCount).fill(null));
            }}>
            Clear
          </Button>
        </Flex>
      </Flex>
    </ThemeProvider>
  );
}
