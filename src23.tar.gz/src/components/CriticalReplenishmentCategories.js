import { BaseChakraTableComponent } from './BaseChakraTableComponent';
// import ReportProblemIcon from '@mui/icons-material/ReportProblem';
import { Flex, Card, ChakraProvider, Text, useTheme } from '@chakra-ui/react';
import theme from '../theme';
// import { criticalReplenishmentData } from '../Utils/mockData/CriticalLowStockData';
import { NearbyErrorRounded } from '@mui/icons-material';
import { useContext, useEffect, useState } from 'react';
import { LocationContext } from '../Contexts/LocationContext';
import { getCategoryAnalyticsAPI } from '../Utils/CategoryAnalyticsAPI';
export const CriticalReplenishmentCategoriesTable = ({ filterData, ...props }) => {
  const chakratheme = useTheme();
  const { consoleState } = useContext(LocationContext);
  const categoryAnalyticsAPI = getCategoryAnalyticsAPI(consoleState);
  const [data, setData] = useState([]);
  const [loading, setLoading] = useState(false);
  const [dataForCurrentPage, setDataForCurrentPage] = useState([]);
  const [pageNo, setPageNum] = useState(0);
  const [maxPages, setMaxPages] = useState(0);
  const itemsPerPage = 6;
  // const headers = ['Category', 'Required Replenishment'];
  const headers = [
    {
      title: 'Category',
      key: 'category'
      // sort: 'default'
    },
    {
      title: 'Required Replenishment',
      key: 'total_deficit'
      // sort: 'default'
    }
  ];
  const transformers = {
    required_replenishment: (row) => (
      <Flex gap={'10px'}>
        <Text alignContent={'flex-end'}>{row.required_replenishment}</Text>
      </Flex>
    )
  };
  const getDataForPage = (i) => {
    return data.slice((i - 1) * itemsPerPage, i * itemsPerPage);
  };

  const getCriticalLowStockAnalyticsData = async (entries) => {
    try {
      filterData.append('page_count', entries);
      setLoading(true);
      const res = await categoryAnalyticsAPI.getCategoryAnalytics(filterData);
      setData(res.data);
      setMaxPages(Math.ceil(res.data.length / itemsPerPage));
      setPageNum(1);
      setLoading(false);
    } catch (e) {
      console.log(e);
      setLoading(false);
    }
  };

  useEffect(() => {
    getCriticalLowStockAnalyticsData(100);
  }, [filterData]);

  useEffect(() => {
    setDataForCurrentPage(getDataForPage(pageNo));
  }, [pageNo]);

  return (
    <ChakraProvider theme={theme}>
      <Card
        borderRadius={'20px'}
        {...props}
        p="20px"
        mt="20px"
        boxShadow={'rgb(231, 231, 231) 0px 0px 20px 0px'}>
        <Flex direction={'column'}>
          <Flex gap="5px">
            <NearbyErrorRounded style={{ color: chakratheme.colors.orange }} />
            <Text
              style={{
                fontSize: '16px',
                fontFamily: 'Poppins',
                fontWeight: 'bold',
                marginTop: '0px'
              }}>
              Categories with most replenishment needs
            </Text>
          </Flex>
          <BaseChakraTableComponent
            rowData={dataForCurrentPage}
            headers={headers}
            columDataTransformers={transformers}
            totalPages={maxPages}
            currentPage={pageNo}
            layout="fixed"
            loading={loading}
            nexPageCallback={(newPage) => setPageNum(newPage)}
            style={{
              fontFamily: 'Arial, sans-serif',
              fontSize: '14px',
              height: '369px',
              overflow: 'auto',
              borderRadius: '0px',
              marginTop: '10px',
              border: '1px solid #eeeeee'
            }}
          />
        </Flex>
      </Card>
      {/* </Flex> */}
    </ChakraProvider>
  );
};
