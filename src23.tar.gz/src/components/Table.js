/* eslint-disable no-unused-vars */
import { Box, Divider, Flex, Spacer, Text } from '@chakra-ui/layout';
import { Image, Table, Tbody, Td, Th, Thead, Tr, useTheme } from '@chakra-ui/react';
import { Cancel, ChevronLeftRounded, ChevronRightRounded, Search } from '@mui/icons-material';
import {
  Chip,
  FormControl,
  IconButton,
  InputAdornment,
  InputLabel,
  MenuItem,
  OutlinedInput,
  Select,
  Skeleton,
  Tooltip,
  debounce
} from '@mui/material';
import { useEffect, useState } from 'react';
import Ascending from '../Static/ascending.png';
import Descending from '../Static/descending.png';
import { FilterList } from '@mui/icons-material';
import { formatNumber } from '../Utils/formatNumberMillionBillion';
const ITEM_HEIGHT = 48;
const ITEM_PADDING_TOP = 0;
const MenuProps = {
  PaperProps: {
    style: {
      maxHeight: ITEM_HEIGHT * 4.5 + ITEM_PADDING_TOP,
      width: 150
    }
  }
};
const AssortmentTable = (props) => {
  const chakratheme = useTheme();
  const pageSize = props.page_size ? props.page_size : 20;
  const [paginatedData, setPaginatedData] = useState(null);
  const [headers, setHeaders] = useState(props.headers); // {name: 'Name', id: 'ID', sort: null/''/'asc'}
  const paginate = () => {
    const start = props.page * pageSize - pageSize;
    const end = props.page * pageSize;
    setPaginatedData(props.data && props.data.slice(start, end));
  };

  const [hoveredRow, setHoveredRow] = useState(null);
  console.log('sortdata', props.assortmentTableState);
  useEffect(() => {
    setHeaders(props.headers);
  }, [props.headers]);

  useEffect(() => {
    paginate();
  }, [
    pageSize,
    props.page,
    // props.sortBy,
    props.assortmentTableState,
    headers,
    props.data
  ]);
  const tdStyle = {
    fontFamily: 'Arial, sans-serif',
    fontWeight: 'regular', // Replace with your desired font
    padding: '5px 15px',
    fontSize: '12px',
    textAlign: 'left',
    color: `${chakratheme.colors.black[800]}`
  };

  // const formatNumber = (num) => {
  //   if (String(num).length <= 3) {
  //     return num;
  //   }
  //   if (String(num).length === 4 || String(num).length === 5) {
  //     return String(parseFloat((num / 1000).toFixed(2))) + 'K';
  //   } else if (String(num).length === 6 || String(num).length === 7) {
  //     return String(parseFloat((num / 100000).toFixed(2))) + 'Lk';
  //   } else {
  //     return String(parseFloat((num / 10000000).toFixed(2))) + 'Cr';
  //   }
  // };

  const TruncatedText = ({ text, maxLength, index }) => {
    // const isHovered = index == hoveredRow;
    const truncatedText =
      // isHovered
      // ? text
      // :
      text && text.length > maxLength ? text.slice(0, maxLength) + '...' : text;
    return (
      <Tooltip title={text} arrow placement="top">
        <span fontSize={'13px'}>{truncatedText}</span>
      </Tooltip>
    );
  };
  const debouncedHandleKeyChange = debounce((variable, value) => {
    props.setSearchData({
      ...props.searchData,
      [variable]: value
    });
    props.setAssortmentTableState({
      ...props.assortmentTableState,
      searchData: {
        ...props.assortmentTableState.searchData,
        [variable]: value
      }
    });
    props.setPage(1);
  }, 1000);

  const thStyle = {
    color: 'black',
    padding: '10px 15px',
    fontSize: '13px',
    fontWeight: 'bold',
    borderBottom: `1px solid ${chakratheme.colors.gray.light}`,
    textAlign: 'left'
  };
  return (
    <Box
      style={{
        boxShadow: `${chakratheme.colors.shadow} 0px 0px 20px 0px`,
        display: 'block',
        borderRadius: '5px'
      }}>
      <Box
        overflowY="auto"
        overfloX="scroll"
        borderRadius="5px"
        height={props.height ? props.height : '600px'}
        w="100%"
        maxHeight={props.height ? props.height : '600px'}>
        <Table
          style={{ borderSpacing: '0 1em' }}
          __css={{ width: 'full' }}
          variant="simple"
          colorScheme="teal">
          <Thead
            style={{
              position: 'sticky',
              top: 0,
              zIndex: 6,
              opacity: 1,
              backgroundColor: `${chakratheme.colors.primary.lighter}`,
              borderRadius: '20px',
              color: `${chakratheme.colors.primary.main}`
            }}>
            <Tr style={{ borderRadius: '20px', color: `${chakratheme.colors.primary.main}` }}>
              {headers &&
                headers.map((title, i) => {
                  return (
                    <Tooltip
                      key={i}
                      arrow
                      placement="top-start"
                      title={title?.toolTip ? title.toolTipText : null}>
                      <Th
                        _hover={{
                          backgroundColor: `${chakratheme.colors.primary.light}`
                        }}
                        colSpan={title.colSpan ? title.colSpan : 1}
                        onClick={() => {
                          props.setPage(1);
                          let currentSortOrder = '';
                          const prevSortOrder = props.assortmentTableState.sortData.sort_type;
                          if (prevSortOrder === '') {
                            currentSortOrder = 'desc';
                          } else if (prevSortOrder === 'desc') {
                            currentSortOrder = 'asc';
                          }
                          // props.setSortOrder(currentSortOrder); // Update the sort order state
                          props.setAssortmentTableState({
                            ...props.assortmentTableState,
                            sortData: {
                              ...props.assortmentTableState.sortData,
                              sort_param: currentSortOrder !== '' ? title.id : '',
                              sort_type: currentSortOrder
                            }
                          });
                          // currentSortOrder !== '' ? props.setSortBy(title.id) : props.setSortBy('');
                          setHeaders((prev) => {
                            return prev.map((item, index) => {
                              if (index !== i)
                                return {
                                  ...item,
                                  sort: item.sort || item.sort == '' ? '' : null
                                };
                              else {
                                return { ...title, sort: currentSortOrder };
                              }
                            });
                          });
                        }}
                        key={i}
                        style={thStyle}>
                        <Flex
                          color={`${chakratheme.colors.primary.main}`}
                          fontWeight={'bold'}
                          alignItems="center"
                          justifyContent="flex-start"
                          cursor={'pointer'}>
                          {title.filter == null && title.search == null ? (
                            title.name
                          ) : title.search != null ? (
                            <FormControl
                              sx={{ m: 1, width: title.name === 'Description' ? '30ch' : '15ch' }}
                              variant="outlined">
                              <InputLabel
                                htmlFor="outlined-adornment-password"
                                style={{
                                  color: `${chakratheme.colors.primary.main}`,
                                  fontWeight: 'bold',
                                  fontSize: '13px'
                                }}>
                                {title.name}
                              </InputLabel>
                              <OutlinedInput
                                sx={{
                                  color: `${chakratheme.colors.primary.main}`,
                                  '.MuiOutlinedInput-notchedOutline': {
                                    borderColor: `${chakratheme.colors.gray.light}`
                                  },
                                  '&.Mui-focused .MuiOutlinedInput-notchedOutline': {
                                    borderColor: `${chakratheme.colors.gray.light}`
                                  },
                                  '&:hover .MuiOutlinedInput-notchedOutline': {
                                    borderColor: `${chakratheme.colors.gray.light}`
                                  },
                                  '& > .MuiSvgIcon-root ': {
                                    fill: `${chakratheme.colors.primary.main}`
                                  }
                                }}
                                onClick={(e) => {
                                  e.stopPropagation();
                                }}
                                id="outlined-adornment-password"
                                type={'text'}
                                onChange={(e) => {
                                  const val = e.target.value;
                                  props.setHeaders(
                                    headers.map((item) => {
                                      if (item.id === title.id) {
                                        return {
                                          ...item,
                                          search_query: val
                                        };
                                      }
                                      return item;
                                    })
                                  );
                                  debouncedHandleKeyChange(title.search_variable, val);
                                }}
                                onKeyDown={(e) => {
                                  if (e.key === 'Enter') {
                                    const val = headers.find(
                                      (item) => item.id === title.id
                                    ).search_query;
                                    props.setSearchData({
                                      ...props.searchData,
                                      [title.search_variable]: val
                                    });
                                    props.setAssortmentTableState({
                                      ...props.assortmentTableState,
                                      searchData: {
                                        ...props.assortmentTableState.searchData,
                                        [title.search_variable]: val
                                      }
                                    });
                                    props.setPage(1);
                                  }
                                }}
                                endAdornment={
                                  <InputAdornment position="end">
                                    <IconButton
                                      aria-label="toggle password visibility"
                                      onClick={() => {
                                        const val = headers.find(
                                          (item) => item.id === title.id
                                        ).search_query;
                                        if (val === '') return;
                                        props.setSearchData({
                                          ...props.searchData,
                                          [title.search_variable]: val
                                        });
                                      }}
                                      edge="end">
                                      <Search
                                        style={{ color: `${chakratheme.colors.primary.main}` }}
                                      />
                                    </IconButton>
                                  </InputAdornment>
                                }
                                label={title.name}
                              />
                            </FormControl>
                          ) : (
                            <Flex direction="column">
                              <FormControl
                                style={{
                                  minWidth: '150px',
                                  color: 'white'
                                }}>
                                <InputLabel
                                  id="demo-multiple-chip-label"
                                  sx={{
                                    color: `${chakratheme.colors.primary.main}`,
                                    fontWeight: 'bold',
                                    fontSize: '13px'
                                  }}>
                                  Status
                                </InputLabel>
                                <Select
                                  labelId="demo-multiple-chip-label"
                                  id="demo-multiple-chip"
                                  multiple
                                  labelStyle={{ color: `${chakratheme.colors.red}` }}
                                  sx={{
                                    color: 'white',
                                    '.MuiOutlinedInput-notchedOutline': {
                                      borderColor: 'rgba(228, 219, 233, 0.25)'
                                    },
                                    '&.Mui-focused .MuiOutlinedInput-notchedOutline': {
                                      borderColor: 'rgba(228, 219, 233, 0.25)'
                                    },
                                    '&:hover .MuiOutlinedInput-notchedOutline': {
                                      borderColor: 'rgba(228, 219, 233, 0.25)'
                                    },
                                    '& > .MuiSvgIcon-root ': {
                                      fill: 'white'
                                    }
                                  }}
                                  fullWidth
                                  value={title.filter}
                                  onChange={(e) => {
                                    const val = e.target.value;
                                    setHeaders(
                                      headers.map((item) => {
                                        if (item.id === title.id) {
                                          return {
                                            ...item,
                                            filter: val
                                          };
                                        }
                                        return item;
                                      })
                                    );
                                    props.setAssortmentStatusFilter(val);
                                    props.setAssortmentTableState({
                                      ...props.assortmentTableState,
                                      filtersData: {
                                        ...props.assortmentTableState.filterData,
                                        filter_type: 'status_label',
                                        filter_params: val
                                      }
                                    });
                                  }}
                                  input={<OutlinedInput id="select-multiple-chip" label="Chip" />}
                                  renderValue={(selected) => (
                                    <Box sx={{ display: 'flex', flexWrap: 'wrap', gap: 0.5 }}>
                                      {selected.map((value) => (
                                        <Chip
                                          onClick={(e) => {
                                            e.stopPropagation();
                                          }}
                                          onMouseDown={(e) => {
                                            e.stopPropagation();
                                          }}
                                          key={value}
                                          label={
                                            title.filterData.find((e) => e.value === value).name
                                          }
                                          deleteIcon={
                                            <Cancel
                                              style={{
                                                color: title.filterData.find(
                                                  (e) => e.value === value
                                                ).color
                                              }}
                                            />
                                          }
                                          onDelete={(e) => {
                                            e.stopPropagation();
                                            setHeaders(
                                              headers.map((item) => {
                                                if (item.id === title.id) {
                                                  return {
                                                    ...item,
                                                    filter: item.filter.filter((e) => e !== value)
                                                  };
                                                }
                                                return item;
                                              })
                                            );
                                            props.setAssortmentStatusFilter(
                                              title.filter.filter((e) => e !== value)
                                            );
                                            props.setAssortmentTableState({
                                              ...props.assortmentTableState,
                                              filtersData: {
                                                ...props.assortmentTableState.filterData,
                                                filter_type: 'status_label',
                                                filter_params: title.filter.filter(
                                                  (e) => e !== value
                                                )
                                              }
                                            });
                                          }}
                                          style={{
                                            fontWeight: 'bold',
                                            backgroundColor: title.filterData.find(
                                              (e) => e.value === value
                                            ).bg,
                                            color: title.filterData.find((e) => e.value === value)
                                              .color
                                          }}
                                          size="small"
                                        />
                                      ))}
                                    </Box>
                                  )}
                                  MenuProps={MenuProps}>
                                  {title.filterData.map((ele) => (
                                    <MenuItem
                                      key={ele.value}
                                      value={ele.value}
                                      _hover={{
                                        backgroundColor: ele.bg
                                      }}
                                      style={{
                                        backgroundColor: headers
                                          .find((e) => e.id === title.id)
                                          .filter.includes(ele.value)
                                          ? `${chakratheme.colors.primary.main}`
                                          : null,
                                        color: headers
                                          .find((e) => e.id === title.id)
                                          .filter.includes(ele.value)
                                          ? 'white'
                                          : 'black'
                                      }}>
                                      <Box
                                        style={{
                                          backgroundColor: ele.color,
                                          width: '10px',
                                          height: '10px',
                                          borderRadius: '50%',
                                          display: 'inline-block',
                                          marginRight: '5px'
                                        }}></Box>{' '}
                                      {ele.name}
                                    </MenuItem>
                                  ))}
                                </Select>
                              </FormControl>
                            </Flex>
                          )}
                          {title.sort != null && title.sort != undefined ? (
                            <>
                              {title.sort == '' || title.sort == 'asc' || title.sort == 'desc' ? (
                                <Flex ml={1} minW="20px">
                                  {title.sort == 'asc' ? (
                                    <Image w="20px" h="20px" m="2px" src={Ascending} />
                                  ) : // <KeyboardDoubleArrowUp style={{ color: 'black' }} />
                                  title.sort == 'desc' ? (
                                    <Image w="20px" h="20px" m="2px" src={Descending} />
                                  ) : (
                                    <FilterList
                                      style={{ color: `${chakratheme.colors.primary.main}` }}
                                    />
                                  )}
                                </Flex>
                              ) : null}
                            </>
                          ) : null}
                        </Flex>
                      </Th>
                    </Tooltip>
                  );
                })}
            </Tr>
          </Thead>
          {props.loading ? (
            <Tbody>
              {Array.from(Array(20).keys()).map((item, i) => {
                return (
                  <Tr
                    key={i}
                    _hover={{
                      backgroundColor: `${chakratheme.colors.gray.lighter}`
                    }}
                    style={{
                      padding: '20px 0px',
                      borderBottom: `2px solid ${chakratheme.colors.gray.lighter}`
                    }}>
                    {headers &&
                      headers.map((header, index) => {
                        return (
                          <Td
                            key={index}
                            colSpan={header.colSpan ? header.colSpan : 1}
                            style={tdStyle}>
                            <Skeleton
                              variant="rectangular"
                              style={{
                                width: '90%',
                                height: '20px'
                              }}
                            />
                          </Td>
                        );
                      })}
                  </Tr>
                );
              })}
            </Tbody>
          ) : (
            <Tbody>
              {paginatedData &&
                paginatedData.map((item, i) => (
                  <Tr
                    key={i}
                    _hover={{
                      backgroundColor: `${chakratheme.colors.gray.lighter}`
                    }}
                    onMouseEnter={() => setHoveredRow(i)}
                    onMouseLeave={() => setHoveredRow(null)}
                    style={{
                      padding: '20px 0px',
                      borderBottom: `2px solid ${chakratheme.colors.gray.lighter}`,
                      backgroundColor:
                        hoveredRow === i ? `${chakratheme.colors.gray.lighter}` : 'white'
                    }}>
                    {headers &&
                      headers.map((header, index) => {
                        return (
                          <Td
                            key={index}
                            colSpan={header.colSpan ? header.colSpan : 1}
                            style={{
                              ...tdStyle,
                              color:
                                props.showCircle && header.id == 'minimum_replenishment'
                                  ? item['current_inventory'] == 0 &&
                                    item['minimum_replenishment'] > 0
                                    ? 'green'
                                    : item['minimum_replenishment'] >= 0 &&
                                        item['current_inventory'] > 0
                                      ? 'orange'
                                      : item['minimum_replenishment'] == 0 &&
                                          item['current_inventory'] == 0
                                        ? 'grey'
                                        : 'red'
                                  : `${chakratheme.colors.black[800]}`
                            }}>
                            {header.id === 'aiocd_revenue' ||
                            header.id === 'iqvia_revenue' ||
                            header.id === 'revenue'
                              ? formatNumber(Math.floor(item[header.id]))
                              : header.id !== 'molecule'
                                ? item[header.id]
                                : null}
                            {header.id === 'molecule' && (
                              <TruncatedText text={item[header.id]} maxLength={15} index={i} />
                            )}
                            {/* give a green/yellow/red circle */}
                            {props.showCircle && header.id === 'sap_id' ? (
                              <Box
                                w="10px"
                                h="10px"
                                borderRadius="50%"
                                bg={
                                  item['current_inventory'] == 0 &&
                                  item['minimum_replenishment'] > 0
                                    ? 'green'
                                    : item['minimum_replenishment'] >= 0 &&
                                        item['current_inventory'] > 0
                                      ? 'orange'
                                      : item['minimum_replenishment'] == 0 &&
                                          item['current_inventory'] == 0
                                        ? 'grey'
                                        : 'red'
                                }></Box>
                            ) : null}
                          </Td>
                        );
                      })}
                  </Tr>
                ))}
            </Tbody>
          )}
        </Table>
      </Box>
      {props.data && props.data.length > 0 && (
        <>
          <Divider />
          <Flex
            style={{
              bottom: '0', // Align the Flex to the bottom
              width: '90%' // Make it take the full width
            }}
            justifyContent="space-between"
            alignItems="center"
            ml={5}>
            <Text fontSize="14px">
              {`Showing  ${(props.page - 1) * pageSize + 1} to  ${Math.min(
                props.page * pageSize,
                props.totalProductsCount
              )} of ${props.totalProductsCount} records`}
            </Text>
            <Spacer />
            <Flex justifyContent="flex-end" alignItems="center" mr={10}>
              <Box h="40px" mx={4}>
                <Divider orientation="vertical" />
              </Box>
              <IconButton
                onClick={() => props.setPage(props.page - 1)}
                disabled={props.page === 1}
                size="sm"
                variant="iconOutline">
                <ChevronLeftRounded />
              </IconButton>
              <Text fontSize="14px" size="sm" p={5}>
                Page {props.page} of {Math.ceil(props.totalProductsCount / pageSize)}
              </Text>
              <IconButton
                variant="iconOutline"
                onClick={() => {
                  if (props.page !== Math.ceil(props.totalProductsCount / pageSize)) {
                    props.setPage(props.page + 1);
                    if (props.page_size === 10) {
                      if (props.page % 10 === 0 || props.page === 1) {
                        props.handlePagination();
                      }
                    } else {
                      if (props.page % 5 === 0 || props.page === 1) {
                        props.handlePagination();
                      }
                    }
                  }
                }}
                isDisabled={props.page === Math.ceil(props.totalProductsCount / pageSize)}
                size="sm">
                <ChevronRightRounded />
              </IconButton>
              {/* )} */}
            </Flex>
          </Flex>
        </>
      )}
    </Box>
  );
};
export default AssortmentTable;
