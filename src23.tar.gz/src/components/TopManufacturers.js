/* eslint-disable react/no-unescaped-entities */
import {
  Box,
  Flex,
  Text,
  // Spacer,
  // Image,
  CircularProgress,
  CircularProgressLabel,
  Spacer,
  Menu,
  MenuButton,
  Button,
  MenuItemOption,
  MenuList
} from '@chakra-ui/react';
import { useContext, useState } from 'react';
import { useTheme } from '@chakra-ui/react';
import { InfoOutlined } from '@mui/icons-material';
import HorizontalStackedBarChart from '../Artifactory/Charts/HorizontalStackedBarChart';
// import manufacturer from '../Static/manufacturer.png';
import { Skeleton, Tooltip } from '@mui/material';
import {
  // Tab
  IconButton
} from '@mui/material';
// import { TabPanel, TabContext, TabList } from '@mui/lab';
// import brand from '../Static/brand.png';
import StackedLineChartIcon from '@mui/icons-material/StackedLineChart';
import AttachMoneyIcon from '@mui/icons-material/AttachMoney';
import SignalCellularAltIcon from '@mui/icons-material/SignalCellularAlt';
import AnalyticsIcon from '@mui/icons-material/Analytics';
import { ChevronDownIcon } from '@chakra-ui/icons';
import { LocationContext } from '../Contexts/LocationContext';

const TopManufacturers = (props) => {
  console.log('hmfac', props.horizontalStackData, props.brandStackData);
  const { consoleState } = useContext(LocationContext);
  const chakratheme = useTheme();
  const [filterTypes, setFilterTypes] = useState({
    manufacturer: 'total',
    brand: 'total'
  });
  const categoriesList = props.horizontalStackData.map((item) => item.name);

  const mfacCategoryData = {
    total: {
      color: `${chakratheme.colors.primary.main}`,
      ...(props.horizontalStackData.length
        ? props.horizontalStackData.find((item) => item.name === 'total')
        : {})
    },

    ...categoriesList.reduce((acc, cat) => {
      if (cat == 'total') return acc;
      acc[cat] = {
        ...(props.horizontalStackData.length
          ? props.horizontalStackData.find((item) => item.name === cat)
          : { name: cat, data: Array(props.horizontalStackData[0].data.length).fill(0) }),
        color: `${chakratheme.colors.primary.main}`
      };
      return acc;
    }, {})
  };
  const mfacBrandCategoryData = {
    total: {
      name: 'total',
      ...(props.brandStackData.length
        ? props.brandStackData.find((item) => item.name === 'total')
        : [])
    },
    ...categoriesList.reduce((acc, cat) => {
      if (cat == 'total') return acc;
      acc[cat] = {
        ...(props.brandStackData.length
          ? props.brandStackData.find((item) => item.name === cat)
          : { name: cat, data: Array(props.brandStackData[0].data.length).fill(0) }),
        color: `${chakratheme.colors.primary.main}`
      };
      return acc;
    }, {})
  };

  console.log('mfac', mfacCategoryData);
  console.log('mfac', mfacBrandCategoryData);
  // const categoriesList = ['total', 'Pharma', 'Non Pharma'];
  const charts = consoleState.state.features.manufacturerCharts?.topMfacChartList || [];
  const cards = ['total_units_sold', 'total_orders', 'total_sales', 'total_margin'];
  const cardMap = {
    total_units_sold: {
      name: 'Total Units Sold',
      icon: AttachMoneyIcon,
      color: `${chakratheme.colors.primary.lighter}`,
      textColor: `${chakratheme.colors.primary.main}`,
      ext: ''
    },
    total_orders: {
      name: 'Total Orders',
      icon: AnalyticsIcon,
      color: `${chakratheme.colors.primary.lighter}`,
      textColor: `${chakratheme.colors.primary.main}`,
      ext: ''
    },
    total_sales: {
      name: 'Total Sales',
      icon: StackedLineChartIcon,
      color: `${chakratheme.colors.primary.lighter}`,
      textColor: `${chakratheme.colors.primary.main}`,
      ext: consoleState.state.currency || '$'
    },
    total_margin: {
      name: 'Total Margin',
      icon: SignalCellularAltIcon,
      color: `${chakratheme.colors.primary.lighter}`,
      textColor: `${chakratheme.colors.primary.main}`,
      ext: consoleState.state.currency || '$'
    }
  };
  return (
    <Flex direction="column" w="100%" mt={3}>
      <Box w="100%">
        {props.stats ? (
          <Flex w="100%" justifyContent={'space-between'}>
            {cards.map((card, i) => {
              const Icon = cardMap[card].icon;
              return (
                <Flex
                  key={card}
                  w="24%"
                  margin="8px 0px"
                  direction="column"
                  style={{
                    backgroundColor: i == 0 ? `${chakratheme.colors.primary.main}` : 'white',
                    color: i == 0 ? 'white' : 'black',
                    boxShadow: `${chakratheme.colors.shadow} 0px 0px 20px 0px`,
                    padding: '20px',
                    borderRadius: '20px',
                    fontFamily: 'Hanken Grotesk'
                  }}>
                  <Text fontWeight={'bold'} mb="20px">
                    <IconButton
                      variant="contained"
                      sx={{
                        cursor: 'pointer',
                        backgroundColor: `${chakratheme.colors.primary.lighter}`,
                        color: `${chakratheme.colors.primary.main}`,
                        transition: 'color 0.1s',
                        borderRadius: '50px',
                        '&:hover': {
                          backgroundColor: `${chakratheme.colors.primary.lighter}`,
                          color: `${chakratheme.colors.primary.main}`
                        },
                        marginRight: '10px'
                      }}>
                      <Icon />
                    </IconButton>
                    {cardMap[card].name}
                  </Text>
                  <Flex alignItems={'center'} wrap="wrap">
                    <Text fontSize={'36px'} fontWeight={'bold'}>
                      {cardMap[card].ext}
                      {props.stats[card] ? props.formatNumber(props.stats[card]) : '-'}
                    </Text>
                    {card == 'total_margin' && props.stats.total_margin ? (
                      <Flex
                        ml={3}
                        direction="column-reverse"
                        alignItems={'center'}
                        justifyContent={'center'}>
                        <CircularProgress
                          value={
                            ((props.stats &&
                              props.stats.total_margin &&
                              props.stats.total_margin.toFixed(0)) *
                              100) /
                            (props.stats &&
                              props.stats.total_sales &&
                              props.stats.total_sales.toFixed(0))
                          }
                          size="80px"
                          color={`${chakratheme.colors.success.dark}`}>
                          <CircularProgressLabel>
                            {(
                              ((props.stats &&
                                props.stats.total_margin &&
                                props.stats.total_margin.toFixed(0)) *
                                100) /
                              (props.stats &&
                                props.stats.total_sales &&
                                props.stats.total_sales.toFixed(0))
                            ).toFixed(0)}
                            %
                          </CircularProgressLabel>
                        </CircularProgress>
                      </Flex>
                    ) : null}
                  </Flex>
                </Flex>
              );
            })}
          </Flex>
        ) : null}
      </Box>
      <Flex
        w="100%"
        fontFamily={'Poppins'}
        gap="20px"
        justifyContent="space-between"
        style={{
          // padding: '20px',
          marginTop: '20px'
        }}>
        {charts.map((chart, i) => {
          return (
            <Flex
              key={i}
              direction="column"
              boxShadow={`0px 0px 20px 0px ${chakratheme.colors.shadow}`}
              borderRadius={'20px'}
              w="100%"
              padding="20px"
              // marginRight="10px"
              style={{ paddingLeft: 0, paddingRight: 0 }}
              value={i}>
              <Flex ml={2} flexDir={'row'} alignItems={'center'}>
                <Text fontWeight={'bold'} fontSize="16px" ml={2} textAlign="left">
                  Top{' '}
                  <span
                    style={{
                      color: `${chakratheme.colors.gray.darker}`,
                      fontWeight: 'bold',
                      padding: '2px 3px',
                      borderRadius: '4px'
                    }}>
                    {chart === 'manufacturer' ? 'Manufacturers' : 'Brands'}
                  </span>{' '}
                  by revenue
                </Text>
                <Tooltip
                  title={`Top ${chart === 'manufacturer' ? 'manufacturers' : 'brands'} as per assortment for the stores in selected demography`}>
                  <InfoOutlined
                    style={{
                      width: '15px',
                      height: '15px'
                    }}
                    cursor={'pointer'}
                  />
                </Tooltip>

                <Spacer />
                <Menu matchWidth={true}>
                  <MenuButton
                    as={Button}
                    variant={'menu'}
                    sx={{
                      display: 'flex',
                      width: '150px',
                      alignItems: 'center',
                      backgroundColor: `${chakratheme.colors.gray.lighter}`,
                      borderRadius: '20px',
                      padding: '5px 10px',
                      marginRight: '20px'
                    }}
                    // leftIcon={view === 'module' ? <ViewModule /> : <ViewList />}
                    rightIcon={<ChevronDownIcon color={`${chakratheme.colors.gray.darker}`} />}>
                    <Text color={`${chakratheme.colors.gray.darker}`} fontSize={'12px'}>
                      {' '}
                      {filterTypes[chart] == 'total' ? 'All Categories' : filterTypes[chart]}{' '}
                    </Text>
                  </MenuButton>
                  <MenuList
                    alignItems={'center'}
                    onMouseEnter={(e) => {
                      e.stopPropagation();
                    }}
                    zIndex="100"
                    fontSize={'12px'}
                    borderRadius={'10px'}
                    paddingTop="10px"
                    paddingBottom="10px"
                    backgroundColor={'white'}
                    boxShadow={`0 0 10px 0 ${chakratheme.colors.shadow}`}>
                    {categoriesList.map((category) => (
                      <MenuItemOption
                        cursor="pointer"
                        _hover={{
                          backgroundColor: `${chakratheme.colors.gray[300]}`
                        }}
                        key={category}
                        value={category}
                        onClick={(e) => {
                          e.stopPropagation();
                          setFilterTypes((prev) => ({ ...prev, [chart]: category }));
                        }}>
                        {category == 'total' ? 'All Categories' : category}
                      </MenuItemOption>
                    ))}
                  </MenuList>
                </Menu>
              </Flex>
              <Flex w="100%">
                {' '}
                <div style={{ flex: '63%', padding: '20px' }}>
                  {!props.loading ? (
                    <HorizontalStackedBarChart
                      data={
                        chart === 'manufacturer'
                          ? [mfacCategoryData[filterTypes['manufacturer']]]
                          : [mfacBrandCategoryData[filterTypes['brand']]]
                      }
                      categoryNames={
                        chart === 'manufacturer'
                          ? props.categoryNames.slice(0, 5)
                          : props.brandCategoryNames.slice(0, 5)
                      }
                      title=""
                    />
                  ) : (
                    <Skeleton
                      variant="rectangular"
                      width="100%"
                      height="400px"
                      style={{ margin: '10px', borderRadius: '20px' }}
                    />
                  )}
                </div>
              </Flex>
            </Flex>
          );
        })}
      </Flex>
    </Flex>
  );
};
export default TopManufacturers;
