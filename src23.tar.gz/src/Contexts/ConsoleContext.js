import { createContext } from 'react';

export const ConsoleContext = createContext();
