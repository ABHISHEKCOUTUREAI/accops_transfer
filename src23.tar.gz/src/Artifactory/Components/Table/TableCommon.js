import { Flex, Table, TableContainer, Tbody, Th, Thead, Tr, useTheme } from '@chakra-ui/react';
import React from 'react';

const TableCommon = (props) => {
  const chakratheme = useTheme();
  return (
    <TableContainer display="flex" w="100%" maxW="100%" overflowY="auto" {...props}>
      <Table variant={'simple'}>
        <Thead
          bgColor={`${chakratheme.colors.primary.lighter}`}
          sx={{ position: 'sticky', top: 0, zIndex: 900 }}>
          <Tr textColor={'black'}>
            {props.header &&
              props.header.map((title, i) => (
                <Th key={i} colSpan={title.colSpan ? title.colSpan : null}>
                  {title.leftIconHeader ? (
                    <Flex flexDir="row">
                      {title.leftIconHeader}
                      {title.name}
                      {title.rightIconHeader ? title.rightIconHeader : null}
                    </Flex>
                  ) : (
                    title.name
                  )}
                </Th>
                // <Th key={i} colSpan={title.colSpan}>
                //   {title.leftIconHeader ? title.leftIconHeader : title.name}
                // </Th>
              ))}
          </Tr>
        </Thead>
        <Tbody>{props.children}</Tbody>
      </Table>
    </TableContainer>
  );
};

export default TableCommon;
