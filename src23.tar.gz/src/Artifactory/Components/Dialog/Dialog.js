import {
  Button,
  Divider,
  Modal,
  ModalBody,
  ModalCloseButton,
  ModalContent,
  ModalFooter,
  ModalHeader,
  ModalOverlay
} from '@chakra-ui/react';

const Dialog = (props) => {
  return (
    <Modal isOpen={props.open} onClose={props.onClose} size={props.size ? props.size : '6xl'}>
      <ModalOverlay />
      <ModalContent>
        <ModalHeader>{props.header ? props.header : null}</ModalHeader>
        <ModalCloseButton />
        <Divider />
        <ModalBody w="100%">{props.children ? props.children : null}</ModalBody>
        <Divider />
        {props.isFooter === null || props.isFooter ? (
          <ModalFooter>
            <Button variant="outline" mr={3} onClick={props.onClose}>
              Close
            </Button>
            <Button
              variant="primary"
              onClick={() => {
                props.handleSubmit();
                props.onClose();
              }}>
              Submit
            </Button>
          </ModalFooter>
        ) : null}
      </ModalContent>
    </Modal>
  );
};

export default Dialog;
