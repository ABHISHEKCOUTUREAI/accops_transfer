import { Box } from '@chakra-ui/react';

const Card = (props) => {
  return (
    <Box
      bg="white"
      borderRadius="8px"
      w="full"
      p="4"
      {...props}
      boxShadow={'1px 1px 10px 2px rgba(0, 0, 0, 0.03)'}>
      {props.children}
    </Box>
  );
};

export default Card;
