import React from 'react';
import { Box, GridItem, Image, Text, Flex } from '@chakra-ui/react';

const ProductBox = ({ product }) => {
  const { brandname, image, name, price, mrp } = product;
  return (
    <GridItem colSpan={1} rowSpan={1}>
      <Box
        border="1px"
        borderColor={'#5C469C6A'}
        backgroundColor="white"
        borderRadius="md"
        justifyContent="flex-start"
        alignItems="flex-start"
        w="100%"
        h="100%"
        mb={2}>
        <Box display="flex" justifyContent="center" alignItems="center" h="65%">
          <Image src={image} w="170px" h="100%" />
        </Box>
        <Box h="35%" p="4" position="relative">
          <Text fontFamily="AG2Body-Semibold" fontSize="md" fontWeight="bold">
            {name}
          </Text>
          <Flex alignItems="baseline">
            <Text fontFamily="AG2Body-Semibold" fontSize="sm" fontWeight="semibold" color="#1D267D">
              {`Rs. ${price}`}
            </Text>
            {mrp ? (
              <Text
                as="s"
                fontFamily="AG2Body-Semibold"
                fontSize="sm"
                fontWeight="semibold"
                color="#6067a4"
                mt={1}
                mb={5}
                ml={2}>
                {`Rs. ${mrp}`}
              </Text>
            ) : (
              <Text
                as="s"
                fontFamily="AG2Body-Semibold"
                fontSize="sm"
                fontWeight="semibold"
                color="#6067a4"
                mt={1}
                mb={5}
                ml={2}>
                Rs. 1250
              </Text>
            )}
          </Flex>
          <Text position="absolute" bottom="3" left="4" fontSize="sm" mt={3} color="#5C469C">
            {`${brandname}`}
          </Text>
        </Box>
      </Box>
    </GridItem>
  );
};
export default ProductBox;
