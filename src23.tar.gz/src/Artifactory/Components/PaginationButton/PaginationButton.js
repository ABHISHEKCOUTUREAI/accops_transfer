import { Flex, IconButton, Text, useTheme } from '@chakra-ui/react';
import React from 'react';

import PropTypes from 'prop-types';
import { ChevronLeftIcon, ChevronRightIcon } from '@chakra-ui/icons';

const PaginationButton = ({ pg, pageSize, setPg, handlePagination, totalCount }) => {
  const chakratheme = useTheme();
  return (
    <Flex w="100%" alignItems="center" my={3}>
      <Flex w="42%" justifyContent="flex-start">
        <Text fontSize="14px">
          {`Showing ${(pg - 1) * pageSize + 1} to ${Math.min(
            pg * pageSize,
            totalCount
          )} of ${totalCount} records`}
        </Text>
      </Flex>
      <Flex w="58%" justifyContent="flex-start">
        <Flex gap={3} alignItems="center">
          <IconButton
            onClick={() => setPg(pg - 1)}
            isDisabled={pg === 1}
            size="sm"
            bg={chakratheme.colors.primary.lighter}
            isRound
            color={chakratheme.colors.primary.main}
            variant="outline"
            fontSize="25px"
            icon={<ChevronLeftIcon />}
          />
          <Flex
            bg={chakratheme.colors.primary.lighter}
            color={chakratheme.colors.primary.main}
            borderRadius="20px"
            px="20px"
            justifyContent="center"
            alignItems="center"
            height="30px">
            Page {pg} of {Math.ceil(totalCount / pageSize)}
          </Flex>
          <IconButton
            variant="outline"
            bg={chakratheme.colors.primary.lighter}
            color={chakratheme.colors.primary.main}
            isRound
            onClick={() => {
              if (pg !== Math.ceil(totalCount / pageSize)) {
                setPg(pg + 1);
                if (pageSize === 10) {
                  if (pg % 10 === 0 || pg === 1) {
                    handlePagination();
                  }
                } else if (pg % 5 === 0 || pg === 1) {
                  handlePagination();
                }
              }
            }}
            isDisabled={pg === Math.ceil(totalCount / pageSize)}
            fontSize="25px"
            size="sm"
            icon={<ChevronRightIcon />}
          />
        </Flex>
      </Flex>
    </Flex>
  );
};

PaginationButton.propTypes = {
  products: PropTypes.object.isRequired,
  pg: PropTypes.number.isRequired,
  setPg: PropTypes.func.isRequired,
  handlePagination: PropTypes.func.isRequired,
  pageSize: PropTypes.number.isRequired
};

export default PaginationButton;
