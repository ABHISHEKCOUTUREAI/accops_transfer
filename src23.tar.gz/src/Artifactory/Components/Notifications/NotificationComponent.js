import { Box, Flex, Text } from '@chakra-ui/react';
import { CheckCircleIcon, WarningIcon, CloseIcon } from '@chakra-ui/icons';
import { useEffect, useState } from 'react';

export const NotificationComponent = ({ message }) => {
  const [notification, setNotification] = useState({});
  const [isClosed, setIsClosed] = useState(false);

  useEffect(() => {
    const statusMap = {
      low_stock: {
        variant: 'warning',
        content: `${message.product_name} is running out of stock!`,
        icon: WarningIcon,
        color: '#C53030',
        backgroundColor: '#FED7D7'
      },
      high_demand: {
        variant: 'success',
        content: `${message.product_name} is having high demand!`,
        icon: CheckCircleIcon,
        color: '#2F855A',
        backgroundColor: '#C6F6D5'
      }
    };

    if (message.status in statusMap) {
      const { variant, content, icon, color, backgroundColor } = statusMap[message.status];
      setNotification({ variant, content, icon, color, backgroundColor });
    }
  }, [message]);

  const IconComponent = notification.icon || WarningIcon; // Default icon if status is unknown

  return (
    <>
      {!isClosed && (
        <Box
          backgroundColor={notification.backgroundColor}
          p={4}
          borderRadius="md"
          boxShadow="md"
          position="relative">
          <CloseIcon
            position="absolute"
            top="8px"
            right="8px"
            fontSize={'xx-small'}
            cursor={'pointer'}
            onClick={() => {
              setIsClosed(true);
            }}
          />
          <Flex alignItems="center" justifyContent="space-between" width="100%">
            <Flex alignItems="center">
              <IconComponent color={notification.color} />
              <Text ml={2}>{notification.content}</Text>
            </Flex>
          </Flex>
        </Box>
      )}
    </>
  );
};
