/*eslint-disable no-unused-vars */
import { Box, Button, Text, useTheme } from '@chakra-ui/react';
import React, { useState, useCallback } from 'react';
import PropTypes from 'prop-types';

const HoverTextBox = ({ content, selected, handleSelect, value }) => {
  const [isHovered, setIsHovered] = useState(false);
  const theme = useTheme();

  const handleMouseEnter = useCallback(() => {
    setIsHovered(true);
  }, []);

  const handleMouseLeave = useCallback(() => {
    setIsHovered(false);
  }, []);

  const textColor = selected
    ? theme.colors.white
    : isHovered
      ? theme.colors.blue[500]
      : theme.colors.black;
  const borderColor = selected
    ? 'transparent'
    : isHovered
      ? theme.colors.blue[500]
      : theme.colors.gray[300];
  const bgColor = selected ? theme.colors.blue[600] : theme.colors.white;

  return (
    <Button
      display="flex"
      alignItems="center"
      justifyContent="space-between"
      borderWidth="2px"
      borderRadius="lg"
      p="8px 14px"
      onMouseEnter={handleMouseEnter}
      onMouseLeave={handleMouseLeave}
      borderColor={borderColor}
      backgroundColor={bgColor}
      variant="unstyled"
      transition="background-color 0.2s ease-in-out, border-color 0.2s ease-in-out"
      onClick={handleSelect ? () => handleSelect(value) : null}
      cursor="pointer"
      gap={3}
      _hover={{
        textDecoration: 'none',
        color: isHovered && !selected ? theme.colors.blue.main : textColor
      }}
      _focus={{
        boxShadow: 'none'
      }}>
      <Text fontSize="14px" color={textColor} fontFamily={'Hanken Grotesk'}>
        {content}
      </Text>
    </Button>
  );
};

HoverTextBox.propTypes = {
  content: PropTypes.string.isRequired,
  selected: PropTypes.bool,
  handleSelect: PropTypes.func,
  value: PropTypes.number
};

HoverTextBox.defaultProps = {
  selected: false
};

export default HoverTextBox;
