import { Box, Flex, Image, Spacer, Text } from '@chakra-ui/react';
import { Link } from 'react-router-dom';
import Container from '../../Components/Container/Container';
// import couturelogo from '../../../Static/coutureai_logo.jpeg'; // import GlobalSearch from '../GlobalSearch/GlobalSearch';
import profile from '../../../Static/profile.jpeg';

const AppBar = (props) => {
  return (
    <Container isCollapsed={props.isCollapsed} style={{ padding: '0 0 0 50px' }}>
      <Box
        color="primary"
        sx={{
          // height: '100px',
          paddingLeft: '30px',
          paddingBottom: '5px',
          padding: '20px 0 20px 20px',
          // boxShadow: '0 0 40px 0 #dddddd',
          marginLeft: props.isCollapsed ? '30px' : '200px'
        }}>
        <Flex w={'100%'} alignItems="center" justifyContent={'center'} gap={5}>
          {/* <Link to={'/assortment/home'}>
            <Image src={couturelogo} pl={6} w="6vh" />
          </Link>
          <Link to={'/assortment/home'}>
            <div style={{ fontSize: '19px', marginLeft: '20px', color: '#888888' }}>
              <span style={{ fontWeight: 'bold', color: '#444444' }}>{props.name}</span>
            </div> */}
          {/* </Link> */}
          <Spacer />
          {props.cartLink && props.cartLink()}
          {props.notifications && props.notificationPanel(props.notifications)}
          <Flex alignItems={'center'} justifyContent={'center'} mr="30px">
            <Link to="/profile">
              <Image src={profile} w="40px" h="40px" objectFit="cover" borderRadius={'50%'} />
            </Link>
            <Text
              ml="2"
              style={{
                fontFamily: 'Raleway'
              }}>
              John Doe
            </Text>
          </Flex>
        </Flex>
      </Box>
    </Container>
  );
};

export default AppBar;
