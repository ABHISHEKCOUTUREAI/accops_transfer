import React, { useState, useEffect } from 'react';
import {
  Divider,
  Input,
  InputGroup,
  InputRightElement,
  List,
  ListItem,
  Text
} from '@chakra-ui/react';
import { Close } from '@mui/icons-material';

const renderListItems = (props, input, isHover, setIsHover, handleItemClick) => {
  if (props.list && props.list.length > 0) {
    return props.list.map((item, i) => {
      if (item.toLowerCase().includes(input.toLowerCase())) {
        return (
          <ListItem
            key={i}
            cursor={'pointer'}
            mx={2}
            borderRadius={8}
            onMouseEnter={() => setIsHover(i)}
            onMouseLeave={() => setIsHover(-1)}
            backgroundColor={i === isHover ? '#8080803A' : null}
            onClick={() => handleItemClick(item)}>
            <Text p={2}>{item}</Text>
            <Divider />
          </ListItem>
        );
      }
      return null;
    });
  }
  return (
    <ListItem
      mx={2}
      borderRadius={8}
      style={{
        display: 'flex',
        justifyContent: 'center',
        alignItems: 'center'
      }}>
      <Text p={2} variant={'body1regular'}>
        No Options Available!
      </Text>
    </ListItem>
  );
};

const AutocompleteBox = (props) => {
  const [isHover, setIsHover] = useState(-1);
  const [input, setInput] = useState('');

  useEffect(() => {
    if (props.name) {
      setInput(props.name);
    }
  }, [props.name]);

  const handleKeyDown = (e) => {
    if (e.key === 'ArrowDown') {
      e.preventDefault();
      navigateList(1);
    } else if (e.key === 'ArrowUp') {
      e.preventDefault();
      navigateList(-1);
    } else if (e.key === 'Enter') {
      e.preventDefault();
      selectItem(isHover);
    }
  };

  const navigateList = (direction) => {
    setIsHover((prevIndex) => {
      const nextIndex = prevIndex + direction;
      if (nextIndex >= props.list.length || nextIndex < 0) {
        return prevIndex;
      }
      return nextIndex;
    });
  };

  const selectItem = (index) => {
    if (index >= 0 && index < props.list.length) {
      const selectedItem = props.list[index];
      props.setShowList(false);
      setInput(selectedItem);
      props.setName(selectedItem);
      props.setCurrentSelectedAttribute(props.currentSelectedAttribute);
    }
  };

  const handleInputChange = (e) => {
    setInput(e.target.value);
  };

  const handleClearInput = () => {
    props.setName(null);
    setInput('');
    props.setCurrentSelectedAttribute(props.currentSelectedAttribute);
  };

  const handleItemClick = (item) => {
    props.setShowList(false);
    setInput(item);
    props.setName(item);
    props.setCurrentSelectedAttribute(props.currentSelectedAttribute);
  };

  return (
    <>
      <InputGroup
        w="90%"
        mx={4}
        my={4}
        backgroundColor={'Delta'}
        borderRadius={8}
        onClick={() => props.setShowList(true)}>
        <Input
          backgroundColor={'Delta'}
          borderRadius={8}
          placeholder="eg: Anarkali"
          onKeyDown={handleKeyDown}
          onChange={handleInputChange}
          value={input}
        />
        <InputRightElement>
          <Close cursor="pointer" onClick={handleClearInput} style={{ width: '15px' }} />
        </InputRightElement>
      </InputGroup>
      {props.showList && (
        <List
          w="90%"
          mx={4}
          maxH={'40vh'}
          py={2}
          overflow={'auto'}
          zIndex={999}
          position="absolute"
          background={'Delta'}
          top={'56px'}
          borderRadius={8}
          border={'1px solid #8080803A'}>
          {renderListItems(props, input, isHover, setIsHover, handleItemClick)}
        </List>
      )}
    </>
  );
};

export default AutocompleteBox;
