import { ArrowUpIcon } from '@chakra-ui/icons';
import { Flex, useTheme } from '@chakra-ui/react';
import React, { useState, useEffect } from 'react';

const GoToTopButton = () => {
  const [isVisible, setIsVisible] = useState(false);
  const chakratheme = useTheme();

  useEffect(() => {
    const toggleVisibility = () => {
      if (window.scrollY > window.innerHeight / 2) {
        setIsVisible(true);
      } else {
        setIsVisible(false);
      }
    };

    window.addEventListener('scroll', toggleVisibility);

    return () => window.removeEventListener('scroll', toggleVisibility);
  }, []);

  const scrollToTop = () => {
    window.scrollTo({
      top: 0,
      behavior: 'smooth'
    });
  };

  return (
    <>
      {isVisible && (
        <Flex
          style={{
            justifyContent: 'center',
            alignItems: 'center',
            position: 'fixed',
            bottom: '20px',
            right: '20px',
            backgroundColor: 'rgba(221, 231, 241, 0.6)',
            color: `${chakratheme.colors.primary.main}`,
            fontWeight: 'bold',
            padding: '10px',
            borderRadius: '5px',
            cursor: 'pointer',
            zIndex: 1000
          }}
          onClick={scrollToTop}>
          Go to Top
          <ArrowUpIcon ml={2} boxSize={5} />
        </Flex>
      )}
    </>
  );
};

export default GoToTopButton;
