import React from 'react';
import { LineChart, Line, Tooltip, Legend, XAxis, YAxis } from 'recharts';

const LineComponent = ({ item, type, checkedItems }) => {
  if (checkedItems && !checkedItems[item.id]) return null;

  return (
    <Line
      key={item.name}
      type={type || 'monotone'}
      isAnimationActive={false}
      dataKey={item.name}
      stroke={item.color}
      strokeDasharray={item.strokeDashArray ? '3 3' : null}
      strokeWidth={2}
      dot={false}
    />
  );
};

const AxisComponent = ({ isXAxis, isYAxis, dataKeyXAxis }) => (
  <>
    {isXAxis && <XAxis dataKey={dataKeyXAxis || 'name'} fontSize={10} />}
    {isYAxis && <YAxis />}
  </>
);

const LegendTooltipComponent = ({ isLegend, isTooltip }) => (
  <>
    {isLegend && <Legend layout="horizontal" align="center" verticalAlign="top" type="circle" />}
    {isTooltip && <Tooltip />}
  </>
);

const LineGraphChart = (props) => {
  const { width = 300, height = 100, data, label, type, checkedItems, children } = props;

  return (
    <LineChart width={width} height={height} data={data} {...props}>
      {label ? (
        label.map((item) => (
          <LineComponent key={item.name} item={item} type={type} checkedItems={checkedItems} />
        ))
      ) : (
        <Line
          type={type || 'monotone'}
          dataKey={label || 'pv'}
          stroke={props.color || '#14C53C'}
          strokeWidth={2}
          dot={false}
        />
      )}
      <AxisComponent
        isXAxis={props.isXAxis}
        isYAxis={props.isYAxis}
        dataKeyXAxis={props.dataKeyXAxis}
      />
      <LegendTooltipComponent isLegend={props.isLegend} isTooltip={props.isTooltip} />
      {children}
    </LineChart>
  );
};

export default LineGraphChart;
