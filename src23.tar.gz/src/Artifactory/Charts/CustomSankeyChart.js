import * as echarts from 'echarts';
import React, { useEffect, useRef } from 'react';
import PropTypes from 'prop-types';

function CustomSankeyChart(props) {
  const chartContainerRef = useRef(null);

  useEffect(() => {
    // Ensure that props.data is valid
    if (!props.data || !Array.isArray(props.data.nodes) || !Array.isArray(props.data.links)) {
      console.error('Invalid data format:', props.data);
      return;
    }

    const chartInstance = echarts.init(chartContainerRef.current);

    const option = {
      tooltip: {
        trigger: 'item',
        triggerOn: 'mousemove'
      },
      series: [
        {
          type: 'sankey',
          data: props.data.nodes,
          links: props.data.links,
          emphasis: {
            focus: 'adjacency'
          },
          draggable: false,
          levels: [
            {
              depth: 0,
              itemStyle: {
                color: '#fbb4ae'
              },
              lineStyle: {
                color: 'source',
                opacity: 0.6
              }
            },
            {
              depth: 1,
              itemStyle: {
                color: '#b3cde3'
              },
              lineStyle: {
                color: 'source',
                opacity: 0.6
              }
            },
            {
              depth: 2,
              itemStyle: {
                color: '#ccebc5'
              },
              lineStyle: {
                color: 'source',
                opacity: 0.6
              }
            },
            {
              depth: 3,
              itemStyle: {
                color: '#decbe4'
              },
              lineStyle: {
                color: 'source',
                opacity: 0.6
              }
            }
          ],
          lineStyle: {
            curveness: 0.5
          }
        }
      ]
    };

    chartInstance.setOption(option);

    // Cleanup function to dispose the chart instance on unmount
    return () => {
      if (chartInstance) {
        chartInstance.dispose();
      }
    };
  }, [props.data]); // Re-run useEffect when props.data changes

  return <div ref={chartContainerRef} style={{ width: '100%', height: '800px' }}></div>;
}

CustomSankeyChart.propTypes = {
  data: PropTypes.object.isRequired
};

export default CustomSankeyChart;
