import { ResponsiveContainer, PieChart, Pie, Cell } from 'recharts';
import { formatNumber } from './functions';

const PieeChart = (props) => {
  const formattedData = props.data.map((item) => ({
    name: item[props.label],
    value: item[props.value]
  }));

  const COLORS = [
    '#6A96B8',
    '#7CC7A9',
    '#E8C884',
    '#E56C7C',
    '#827EAF',
    '#E96DAB',
    '#6D9CCE',
    '#B283C8',
    '#EAA572',
    '#7CCDBF'
  ];

  return (
    <ResponsiveContainer width="100%" height={450}>
      <PieChart height={450}>
        <Pie
          data={formattedData}
          cx="50%"
          cy="50%"
          outerRadius={120}
          dataKey="value"
          // labelLine={false}
          // label={renderCustomizedLabel}
          label={({ cx, cy, midAngle, innerRadius, outerRadius, value, index }) => {
            const RADIAN = Math.PI / 180;
            const radius = 25 + innerRadius + (outerRadius - innerRadius);
            const x = cx + radius * Math.cos(-midAngle * RADIAN);
            const y = cy + radius * Math.sin(-midAngle * RADIAN);

            const radius_percentage = innerRadius + (outerRadius - innerRadius) * 0.75;
            const x_percentage = cx + radius_percentage * Math.cos(-midAngle * RADIAN);
            const y_percentage = cy + radius_percentage * Math.sin(-midAngle * RADIAN);
            const percentage =
              (value / formattedData.reduce((acc, cur) => acc + cur.value, 0)) * 100;

            return (
              <g>
                <text
                  x={x_percentage}
                  y={y_percentage - 10}
                  fill={'white'}
                  fontSize={12}
                  textAnchor="middle"
                  dominantBaseline="central">
                  {`${percentage.toFixed(2)}%`}
                </text>
                <text
                  x={x}
                  fontWeight={'bold'}
                  y={y}
                  fill="black"
                  // fill={COLORS[index % COLORS.length]}
                  fontSize={10}
                  textAnchor={x > cx ? 'start' : 'end'}
                  dominantBaseline="central">
                  {formattedData[index].name} ({formatNumber(value)})
                </text>
              </g>
            );
          }}>
          {formattedData.map((entry, index) => (
            <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
          ))}
        </Pie>
      </PieChart>
    </ResponsiveContainer>
  );
};

export default PieeChart;
