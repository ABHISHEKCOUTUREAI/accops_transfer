import React, { useRef, useEffect } from 'react';
import * as echarts from 'echarts';

export const BoxPlot = ({ data, title, yLabel, ...props }) => {
  const chartContainerRef = useRef(null);

  useEffect(() => {
    if (chartContainerRef.current) {
      const boxPlotChart = echarts.init(chartContainerRef.current);
      boxPlotChart.setOption({
        title: [
          {
            text: title,
            left: 'center'
          }
        ],
        dataset: [
          {
            // prettier-ignore
            source: data
          },
          {
            transform: {
              type: 'boxplot',
              config: { itemNameFormatter: 'expr {value}' }
            }
          },
          {
            fromDatasetIndex: 1,
            fromTransformResult: 1
          }
        ],
        tooltip: {
          trigger: 'item',
          axisPointer: {
            type: 'shadow'
          }
        },
        grid: {
          left: '10%',
          right: '10%',
          bottom: '15%'
        },
        xAxis: {
          type: 'category',
          boundaryGap: true,
          nameGap: 30,
          splitArea: {
            show: false
          },
          splitLine: {
            show: false
          }
        },
        yAxis: {
          type: 'value',
          name: yLabel,
          splitArea: {
            show: true
          }
        },
        series: [
          {
            name: 'boxplot',
            type: 'boxplot',
            datasetIndex: 1
          },
          {
            name: 'outlier',
            type: 'scatter',
            datasetIndex: 2
          }
        ]
      });
    }
  }, [data]);

  return <div ref={chartContainerRef} style={{ width: '100%', height: '400px' }} />;
};
