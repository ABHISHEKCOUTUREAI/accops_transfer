import React, { useEffect, useState } from 'react';
import ReactApexChart from 'react-apexcharts';
import { useTheme } from '@chakra-ui/react';

const BarGraphChart = ({ data, xlabel, ylabel }) => {
  const chakratheme = useTheme();
  const [options, setOptions] = useState({});
  const [series, setSeries] = useState([]);

  const styles = {
    chart: {
      // ... other styles
    },
    dataLabels: {
      opacity: 0 // Set opacity to 0 to hide labels
    }
  };

  useEffect(() => {
    const xLabels = [];
    for (let i = 0; i < 20; i++) {
      if (i === 20) {
        xLabels.push(`${i * 5}%`); // Use only the starting margin percentage for the last label
      } else {
        xLabels.push(`${i * 5}-${(i + 1) * 5}%`);
      }
    }

    // Set options and series for the chart
    setOptions({
      chart: {
        type: 'bar',
        // width: '100%',
        height: '400px'
      },
      plotOptions: {
        bar: {
          horizontal: false
        }
      },
      dataLabels: {
        enabled: false
      },
      xaxis: {
        categories: xLabels,
        title: {
          text: xlabel
        },
        offsetY: -4
      },
      yaxis: {
        title: {
          text: ylabel
        }
      },
      tooltip: {
        custom: function ({ seriesIndex, dataPointIndex, w }) {
          let data = w.globals.initialSeries[seriesIndex].data[dataPointIndex];
          return `
      <div style="padding: 10px;">
        <ul style="list-style-type: none; padding: 0; margin: 0;">
          <li># products: <b>${data}</b></li>
        </ul>
      </div>`;

          // return '<ul>' + '<li><b>Products</b>: ' + data + '</li>' + '</ul>';
        }
      },
      colors: [`${chakratheme.colors.primary.main}`]
    });

    setSeries([{ data: data }]);
  }, [data]);

  return (
    <div id="chart" style={styles.chart}>
      <ReactApexChart options={options} series={series} type="bar" height={400} />
    </div>
  );
};

export default BarGraphChart;
