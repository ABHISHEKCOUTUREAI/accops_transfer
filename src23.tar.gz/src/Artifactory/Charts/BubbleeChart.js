import React from 'react';
import { Chart as ChartJS, LinearScale, PointElement, Tooltip, Legend } from 'chart.js';
import { Bubble } from 'react-chartjs-2';

ChartJS.register(LinearScale, PointElement, Tooltip, Legend);

export default function BubbleeChart(props) {
  const minMargin = Math.min(...props.data.map((item) => item.total_margin));
  const maxMargin = Math.max(...props.data.map((item) => item.total_margin));

  // Normalize the radius based on margin
  const normalizeRadius = (margin) => {
    const minRadius = 1; // Set a minimum radius
    const maxRadius = 40; // Set a maximum radius
    const normalizedRadius =
      ((margin - minMargin) / (maxMargin - minMargin)) * (maxRadius - minRadius) + minRadius;
    return normalizedRadius;
  };

  const options = {
    scales: {
      x: {
        beginAtZero: true,
        title: {
          display: true,
          text: 'Distribution of Products' // Add your X-Axis heading here
        }
      },
      y: {
        beginAtZero: true,
        title: {
          display: true,
          text: 'Total Amount' // Add your Y-Axis heading here
        }
      }
    },
    elements: {
      point: {
        pointLabel: 'sap_id' // Display item.sap_id as labels
      }
    },
    plugins: {
      tooltip: {
        callbacks: {
          label: function (context) {
            const label = context.dataset.data[context.dataIndex].label;
            const y = context.dataset.data[context.dataIndex].totalamount;
            // const maxMargin = Math.max(...props.data.map((item) => item.total_margin));
            // const percentage = ((y / maxMargin) * 100).toFixed(2);
            return `Item SAP ID: ${label}, Margin: ${y}`;
          }
        }
      }
    }
  };

  const data = {
    datasets: [
      {
        label: props.label,
        data: props.data.map((item, index) => ({
          // x: faker.datatype.number({ min: 0, max: 100 }),
          x: index,
          y: item.total_amount,
          r: normalizeRadius(item.total_margin), // Use total_margin_train for radius
          label: item.sap_id,
          totalamount: item.total_margin_percent
        })),
        backgroundColor: 'rgba(255, 99, 132, 0.5)'
      }
    ]
  };
  return <Bubble options={options} data={data} />;
}
