import React, { useEffect, useState } from 'react';
import ReactApexChart from 'react-apexcharts';
const fullMonthNameToIndexStartingWithZero = {
  January: 0,
  February: 1,
  March: 2,
  April: 3,
  May: 4,
  June: 5,
  July: 6,
  August: 7,
  September: 8,
  October: 9,
  November: 10,
  December: 11
};

const ApexChart = (props) => {
  const sales_data = props.data;

  const sortedData = Object.keys(sales_data)
    .map((key) => {
      return {
        date: new Date(
          key.split(' ')[1],
          fullMonthNameToIndexStartingWithZero[key.split(' ')[0]],
          1
        ),
        value: sales_data[key]
      };
    })
    .sort((a, b) => a.date - b.date);

  const _originalSeries = Object.keys(sortedData[0].value)
    .sort((a, b) => sortedData[0].value[a] - sortedData[0].value[b])
    .map((key) => {
      return {
        name: key,
        data: sortedData.map((item) => [item.date.getTime(), item.value[key]])
      };
    });

  const allCategoriesData = _originalSeries.reduce(
    (acc, item) => {
      return acc.map((data, index) => {
        return [item.data[index][0], data[1] + item.data[index][1]];
      });
    },
    _originalSeries[0].data.map((item) => [item[0], 0])
  );
  const allCat = {
    name: 'All Categories',
    data: allCategoriesData.slice(Math.max(0, allCategoriesData.length - props.duration - 1))
  };
  const [series, setSeries] = useState([
    ..._originalSeries.map((item) => {
      return {
        ...item,
        data: item.data.slice(_originalSeries[0].data.length - props.duration - 1)
      };
    }),
    allCat
  ]);
  console.log('_sales allcat', allCategoriesData);

  console.log('_sales series', series);
  console.log('_sales data', props.data);
  console.log('_sales _original', _originalSeries);
  const [annotations, setAnnotations] = useState({
    yaxis: [
      {
        y: 8800,
        borderColor: '#29145e',
        label: {
          // borderColor: '#00E396',
          style: {
            color: '#fff',
            background: '#29145e'
          },
          text: 'Average'
        }
      }
    ]
  });
  useEffect(() => {
    const _seriesX = [
      ..._originalSeries.map((item) => {
        return {
          ...item,
          data: item.data.slice(Math.max(0, _originalSeries[0].data.length - props.duration - 1))
        };
      }),
      { ...allCat, data: allCat.data.slice(Math.max(0, allCat.data.length - props.duration - 1)) }
    ];
    const filtered = _seriesX.filter((item) => item.name === props.category);
    setSeries(filtered);
    const average =
      filtered[0].data.reduce((acc, item) => {
        return acc + item[1];
      }, 0) / filtered[0].data.length;
    setAnnotations({
      yaxis: [
        {
          y: average,
          borderColor: '#29145e',
          label: {
            // borderColor: '#00E396',
            style: {
              color: '#fff',
              background: '#29145e'
            },
            text: 'Average'
          }
        }
      ]
    });
  }, [props.duration, props.category]);

  // series: series,
  const options = {
    chart: {
      type: 'line',
      height: 350,
      stacked: true,
      toolbar: {
        show: false // Hide toolbar icons
      },
      zoom: {
        enabled: false // Disable zooming
      }
    },
    colors: ['#22114e', '#6734eb', '#af94f4', '#b399f5', '#e0d6fb'],
    // colors: ['#001F3F', '#005B96', '#4D94DB', '#71B2E5', '#93C8EF'],
    dataLabels: {
      enabled: false
    },
    stroke: {
      // curve: 'smooth'
    },
    fill: {
      type: 'gradient',
      gradient: {
        opacityFrom: 0.6,
        opacityTo: 0.8
      }
    },
    grid: {
      show: false
    },

    legend: {
      position: 'top',
      horizontalAlign: 'left'
    },
    xaxis: {
      type: 'datetime'
    },
    yaxis: {
      labels: {
        formatter: function (val) {
          return val + 'k';
        }
      }
    }
  };

  return (
    <div id="chart">
      <ReactApexChart
        options={{ ...options, annotations: annotations }}
        series={series.reverse()}
        type="line"
        height={350}
      />
    </div>
  );
};

export default ApexChart;
