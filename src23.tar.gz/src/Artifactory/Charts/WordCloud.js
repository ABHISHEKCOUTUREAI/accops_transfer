import React from 'react';
import ReactWordcloud from 'react-wordcloud';
import 'tippy.js/dist/tippy.css';
import 'tippy.js/animations/scale.css';

const WordCloud = (props) => {
  const options = {
    rotations: 0,
    fontSizes: [10, 30], // adjust font size range as needed
    maxFontSize: 20,
    enableOptimizations: true
  };

  return (
    <div style={{ width: 'auto', height: '250px', overflow: 'auto' }}>
      <ReactWordcloud words={props.data} options={options} />
    </div>
  );
};

export default WordCloud;
