import {
  Legend,
  Line,
  LineChart,
  ResponsiveContainer,
  Brush,
  Tooltip,
  XAxis,
  YAxis
} from 'recharts';

const LinearRegression = (props) => {
  const data = props.seasonalityData;

  return (
    <ResponsiveContainer width="100%" height={250}>
      <LineChart data={data['regressionData']} margin={{ top: 5, right: 30, left: 20, bottom: 5 }}>
        <XAxis
          dataKey="date"
          angle={-15}
          tick={{ fontSize: 12 }} // Adjust font size for the tick labels
          height={50} // Increase height to make room for rotated labels
        />
        <YAxis dataKey="sales" />
        <Tooltip />
        <Legend />
        <Line type="monotone" dataKey="sales" stroke="#675cfd" dot={false} strokeWidth={'3px'} />
        {/* <Line type="monotone" dataKey="trend" stroke="#ff9900" dot={false} strokeWidth={'3px'} /> */}
        <Brush dataKey="date" height={30} stroke="#8884d8" />
        {/* <ReferenceLine segment={line} label="regression" stroke="red" /> */}
      </LineChart>
    </ResponsiveContainer>
  );
};
export default LinearRegression;
