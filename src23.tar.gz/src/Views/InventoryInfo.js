/* eslint-disable no-unused-vars */
import { useTheme } from '@emotion/react';
import Container from '../Artifactory/Components/Container/Container';
import {
  Flex,
  Text,
  Box,
  Table,
  Tbody,
  Tr,
  Td,
  TableContainer,
  Thead,
  Th,
  ChakraProvider,
  Select,
  Button
} from '@chakra-ui/react';
import { useState } from 'react';
import { StatsCard } from '../components/StatsCard';
import BeforeAfterBarChart from '../components/charts/BeforeAfterBarChart';

const totalRevenue = 521815754;
const totalMargin = 10990027;
const totalQuantity = 34490908;

const cardNames = ['revenue', 'margin', 'sales'];

const cardMap = {
  revenue: {
    name: 'Total Revenue',
    value: totalRevenue,
    change: 12.5,
    description: 'from the last month',
    ext: '₹',
    backgroundColor: 'black',
    color: 'white'
  },
  margin: {
    name: 'Total Margin',
    value: totalMargin,
    change: 2.5,
    description: 'from the last month',
    ext: '₹',
    backgroundColor: 'white',
    color: 'black'
  },
  sales: {
    name: 'Total Quantity Sold',
    value: totalQuantity,
    change: 2.5,
    description: 'from the last month',
    ext: '',
    backgroundColor: 'white',
    color: 'black'
  }
};

export const InventoryInfo = (props) => {
  const chakratheme = useTheme();
  const inventoryData = {
    sap_id: 493921856,
    item_name: "ECOSPRIN 75 TABLET 14'S",
    L0: 'Pharma',
    L3: 'Blood Clot',
    mrp: 5.33,
    molecule: 'aspirin 75 mg',
    br_code: 'T9TN',
    probability: 0.9999964435820108,
    current_inventory: 42,
    min_qty: 18,
    max_qty: 26,
    num_qty_sold: 11,
    total_amount: 46.83,
    total_margin: 0.94,
    minimum_replenishment: 16,
    status_label: '9_excess'
  };

  const [replenishQty, setReplenishQty] = useState(0);

  const infoFieldsLeft = ['sap_id', 'item_name', 'L0', 'L3'];

  const infoFieldsRight = ['mrp', 'molecule', 'br_code', 'current_inventory'];
  const recommendedFields = ['max_qty', 'min_qty', 'minimum_replenishment'];

  const handleSelectChange = (e) => {
    setReplenishQty(e.target.value);
  };

  return (
    <Container>
      <ChakraProvider theme={props.theme}>
        <Flex direction="column" id="overview" gap={10} marginLeft={'20px'}>
          <Flex direction={'column'} gap={3}>
            <Flex direction={'column'}>
              <Text
                style={{
                  fontSize: '22px',
                  fontFamily: 'Poppins',
                  fontWeight: 'bold',
                  marginTop: '0px'
                }}>
                Inventory Info
              </Text>
              <Box
                w="100px"
                h="5px"
                bg={`${chakratheme.colors.primary.main}`}
                borderRadius="3px"
                mt={2}
              />
            </Flex>
            <Text
              mt={3}
              style={{
                color: `${chakratheme.colors.black[400]}`,
                fontSize: '13px',
                fontFamily: 'sans-serif'
              }}>
              Detailed information about the inventory
            </Text>

            <Flex w={'80%'} gap={10}>
              <Flex w={'50%'}>
                <TableContainer w={'100%'}>
                  <Box border="1px solid" borderColor="gray.200" borderRadius="25px">
                    <Table variant="unstyled" w={'100%'}>
                      <Tbody>
                        {infoFieldsLeft?.map((t) => (
                          <Tr key={t}>
                            <Td>
                              <Text
                                style={{
                                  fontSize: '16px',
                                  fontFamily: 'Poppins',
                                  fontWeight: 600,
                                  marginTop: '0px'
                                }}>
                                {t}
                              </Text>
                            </Td>
                            <Td>{inventoryData[t]}</Td>
                          </Tr>
                        ))}
                      </Tbody>
                    </Table>
                  </Box>
                </TableContainer>
              </Flex>

              <Flex w={'50%'}>
                <TableContainer w={'100%'}>
                  <Box border="1px solid" borderColor="gray.200" borderRadius="25px">
                    <Table variant="unstyled">
                      <Tbody>
                        {infoFieldsRight?.map((t) => (
                          <Tr key={t}>
                            <Td>
                              <Text
                                style={{
                                  fontSize: '16px',
                                  fontFamily: 'Poppins',
                                  fontWeight: 600,
                                  marginTop: '0px'
                                }}>
                                {t}
                              </Text>
                            </Td>
                            <Td>{inventoryData[t]}</Td>
                          </Tr>
                        ))}
                      </Tbody>
                    </Table>
                  </Box>
                </TableContainer>
              </Flex>
            </Flex>
          </Flex>

          <Flex direction={'column'} gap={5}>
            <Flex direction={'column'}>
              <Text
                style={{
                  fontSize: '22px',
                  fontFamily: 'Poppins',
                  fontWeight: 'bold',
                  marginTop: '0px'
                }}>
                Recommendation
              </Text>
              <Box
                w="100px"
                h="5px"
                bg={`${chakratheme.colors.primary.main}`}
                borderRadius="3px"
                mt={2}
              />
            </Flex>

            <Flex w={'80%'} gap={10}>
              <Flex w={'50%'}>
                <TableContainer width={'100%'}>
                  <Box border="1px solid" borderColor="gray.200" borderRadius="25px">
                    <Table variant="unstyled">
                      <Tbody>
                        {recommendedFields?.map((t) => (
                          <Tr key={t}>
                            <Td>
                              <Text
                                style={{
                                  fontSize: '16px',
                                  fontFamily: 'Poppins',
                                  fontWeight: 600,
                                  marginTop: '0px'
                                }}>
                                {t}
                              </Text>
                            </Td>
                            <Td>{inventoryData[t]}</Td>
                          </Tr>
                        ))}
                      </Tbody>
                    </Table>
                  </Box>
                </TableContainer>
              </Flex>

              <Flex w={'50%'}>
                {inventoryData?.minimum_replenishment > 0 && (
                  <Flex direction={'column'} gap={3} mx={5} my={'auto'} w={'50%'}>
                    <Text>Select Replenishment</Text>
                    <Select value={replenishQty} onChange={handleSelectChange}>
                      {Array(inventoryData?.minimum_replenishment)
                        .fill(0)
                        .map((n, i) => (
                          <option key={i + 1} value={i + 1}>
                            {i + 1}
                          </option>
                        ))}
                    </Select>
                    <Button>Analyze</Button>
                  </Flex>
                )}
              </Flex>
            </Flex>
          </Flex>

          <Flex direction={'column'}>
            <Flex direction={'column'}>
              <Text
                style={{
                  fontSize: '22px',
                  fontFamily: 'Poppins',
                  fontWeight: 'bold',
                  marginTop: '0px'
                }}>
                Key Impact Indicators
              </Text>
              <Box
                w="100px"
                h="5px"
                bg={`${chakratheme.colors.primary.main}`}
                borderRadius="3px"
                mt={2}
              />
            </Flex>
            <Flex w={'90%'} justifyContent={'space-between'}>
              {cardNames.map((c, ind) => (
                <Flex direction={'column'} key={ind} gap={'20px'}>
                  <StatsCard
                    header={cardMap[c].name}
                    number={cardMap[c].value}
                    variation={cardMap[c].change}
                    footer={cardMap[c].description}
                    bg={cardMap[c].backgroundColor}
                    color={cardMap[c].color}
                  />
                  <BeforeAfterBarChart />
                </Flex>
              ))}
            </Flex>
          </Flex>
        </Flex>
      </ChakraProvider>
    </Container>
  );
};
