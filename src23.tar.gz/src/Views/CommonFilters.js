import { ChevronDownIcon, ChevronRightIcon, ChevronUpIcon, SearchIcon } from '@chakra-ui/icons';
import { Divider, Flex, Spacer, Text, VStack } from '@chakra-ui/layout';
import {
  Button,
  ChakraProvider,
  Checkbox,
  IconButton,
  Input,
  InputGroup,
  InputRightElement,
  Popover,
  PopoverArrow,
  PopoverBody,
  PopoverCloseButton,
  PopoverContent,
  PopoverHeader,
  PopoverTrigger,
  Radio,
  Switch,
  Tag,
  TagLabel,
  TagRightIcon,
  useDisclosure,
  useTheme
} from '@chakra-ui/react';
import { CloseOutlined } from '@mui/icons-material';
import { useEffect, useRef, useState } from 'react';

export const useXFiltersState = (config) => {
  const [state, setState] = useState({
    filters: config.filters.reduce((acc, filter) => {
      acc[filter.id] = {
        options: [],
        selected:
          filter.type == 'search'
            ? ''
            : filter.type == 'select'
              ? []
              : filter.type == 'checkbox' && filter.checkbox.multiple
                ? []
                : filter.type == 'checkbox' && !filter.checkbox.multiple
                  ? ''
                  : filter.type == 'range'
                    ? { min: '', max: '' }
                    : filter.type == 'boolean'
                      ? false
                      : null
      };
      return acc;
    }, {}),
    groups: config.groups.reduce((acc, group) => {
      acc[group.id] = {
        expanded: true
      };
      return acc;
    }, {})
  });
  return { state, setState };
};
const XSearch = ({ state, filter, setState }) => {
  const { isOpen, onClose, onOpen } = useDisclosure();
  const [searchedTerm, setSearchedTerm] = useState('');
  const [filteredOptions, setFilteredOptions] = useState(filter.search.options);
  const initialFocusRef = useRef();
  const [highlightedIndex, setHighlightedIndex] = useState(0);

  useEffect(() => {
    setState({
      ...state,
      filters: {
        ...state.filters,
        [filter.id]: {
          ...state.filters[filter.id],
          selected: searchedTerm
        }
      }
    });
  }, [searchedTerm]);

  return (
    <VStack alignItems={'start'} w="100%" spacing="5px" position={'relative'}>
      <Flex w="100%">
        <Text mb={0} fontSize="13px" textAlign="left">
          {filter.name}
        </Text>
        <Spacer />
        <Text fontSize="10px" color="#aaaaaa" cursor="pointer">
          Clear
        </Text>
      </Flex>
      <Popover
        offset={[null, 30]}
        initialFocusRef={initialFocusRef}
        placement="right"
        isOpen={isOpen}
        onClose={onClose}>
        <PopoverTrigger>
          <Input
            ref={initialFocusRef}
            w="100%"
            h="40px"
            fontSize={'14px'}
            placeholder={'Search ' + filter.name}
            value={searchedTerm}
            onClick={() => {
              setFilteredOptions(
                filter.search.options.filter((option) =>
                  option.toLowerCase().includes(searchedTerm.toLowerCase())
                )
              );
              onOpen();
            }}
            // onFocus={onOpen}
            onKeyDown={(e) => {
              if (e.key === 'ArrowDown') {
                const _newIndex =
                  highlightedIndex < filteredOptions.length - 1
                    ? highlightedIndex + 1
                    : highlightedIndex;
                e.preventDefault();
                setHighlightedIndex((prev) =>
                  prev < filteredOptions.length - 1 ? prev + 1 : prev
                );

                const el = document.querySelectorAll('.search-option');
                if (el) {
                  el[_newIndex].scrollIntoView({
                    behavior: 'smooth'
                  });
                }
              }
              if (e.key === 'ArrowUp') {
                const _newIndex = highlightedIndex > 0 ? highlightedIndex - 1 : 0;
                e.preventDefault();
                setHighlightedIndex((prev) => (prev > 0 ? prev - 1 : 0));
                const el = document.querySelectorAll('.search-option');
                if (el) {
                  el[_newIndex].scrollIntoView({
                    behavior: 'smooth'
                  });
                }
              }
              if (e.key === 'Enter') {
                e.preventDefault();
                if (highlightedIndex >= 0 && highlightedIndex < filteredOptions.length) {
                  setSearchedTerm(filteredOptions[highlightedIndex]);
                  onClose();
                }
              }
            }}
            onBlur={(e) => {
              // check if target is popover
              console.log('relatedTarget', e.relatedTarget);
              console.log('relatedTarget', e);
              console.log('relatedTarget', e.relatedTarget?.id);
              if (e.relatedTarget && e.relatedTarget.closest('#popover-content')) {
                e.preventDefault();
                return;
              }
              onClose();
            }}
            onChange={(e) => {
              const term = e.target.value;
              const _filteredOptions = filter.search.options.filter((option) =>
                option.toLowerCase().includes(term.toLowerCase())
              );
              setFilteredOptions(_filteredOptions);
              if (_filteredOptions.length > 0) {
                onOpen();
                setHighlightedIndex(0);
              } else onClose();
              setSearchedTerm(e.target.value);
            }}
          />
        </PopoverTrigger>
        <PopoverContent
          id="popover-content"
          width={'300px'}
          fontFamily="Hanken Grotesk"
          style={{
            boxShadow: '0 0 20px 0 #dddddd'
          }}>
          <PopoverArrow />

          <PopoverBody maxHeight="700px" overflowY={'scroll'} p="0">
            {filteredOptions
              .sort((a, b) => a.toLowerCase().localeCompare(b.toLowerCase()))
              .map((option, k) => {
                return (
                  <Flex
                    key={k}
                    onClick={() => {
                      setSearchedTerm(option);
                      onClose();
                    }}
                    _hover={{
                      cursor: 'pointer',
                      backgroundColor: highlightedIndex != k ? '#f7f7f7 !important' : null
                    }}
                    w="100%"
                    gap="5px"
                    p="5px 10px"
                    minHeight={'40px'}
                    alignItems={'center'}
                    style={{
                      //   border: '1px solid #EEEEEE',
                      //   borderRadius: '5px',
                      color: highlightedIndex == k ? '#1776F5' : '#000',
                      backgroundColor: highlightedIndex == k ? '#E7F5FB' : '#fff'
                    }}>
                    {/* highlight option searchterm */}
                    <Text flexDirection={'row'} className="search-option">
                      {option}
                    </Text>
                  </Flex>
                );
              })}
          </PopoverBody>
        </PopoverContent>
      </Popover>
    </VStack>
  );
};
const XSelect = ({ state, filter, setState }) => {
  const { isOpen, onToggle, onClose } = useDisclosure();
  const [searchedTerm, setSearchedTerm] = useState('');
  const initialFocusRef = useRef();

  return (
    <VStack alignItems={'start'} w="100%" spacing="5px" position={'relative'}>
      <Flex w="100%">
        <Text mb={0} fontSize="13px" textAlign="left">
          {filter.name}
        </Text>
        <Spacer />
        <Text fontSize="10px" color="#aaaaaa" cursor="pointer">
          Clear
        </Text>
      </Flex>
      <Popover
        offset={[null, 30]}
        initialFocusRef={initialFocusRef}
        placement="right"
        isOpen={isOpen}
        onClose={onClose}>
        <PopoverTrigger>
          <Flex
            onClick={() => {
              onToggle();
            }}
            _hover={{
              cursor: 'pointer',
              backgroundColor: '#f7f7f7 !important'
            }}
            w="100%"
            gap="5px"
            minHeight={'40px'}
            alignItems={'center'}
            style={{
              border: '1px solid #EEEEEE',
              borderRadius: '5px',
              backgroundColor: isOpen ? '#fefefe' : '#fff'
            }}>
            <Flex wrap="wrap" gap="5px" padding="5px">
              {state.filters[filter.id].selected
                .slice(0, !isOpen ? 3 : undefined)
                .map((option, k) => {
                  return (
                    <Tag
                      key={k}
                      size="md"
                      style={{
                        borderRadius: '2px',
                        border: '1px solid #E7E7E7',
                        backgroundColor: '#F1F1F1',
                        color: '#2E2F32'
                      }}>
                      <TagLabel>{option}</TagLabel>
                      {isOpen ? (
                        <TagRightIcon
                          onClick={(e) => {
                            e.stopPropagation();
                            setState({
                              ...state,
                              filters: {
                                ...state.filters,
                                [filter.id]: {
                                  ...state.filters[filter.id],
                                  selected: state.filters[filter.id].selected.filter(
                                    (item) => item != option
                                  )
                                }
                              }
                            });
                          }}>
                          <CloseOutlined
                            style={{
                              color: '#AFB0B3'
                            }}
                          />
                        </TagRightIcon>
                      ) : null}
                    </Tag>
                  );
                })}
              {!isOpen && state.filters[filter.id].selected.length > 3 ? (
                <Tag
                  size="md"
                  style={{
                    borderRadius: '0px'
                  }}>
                  +{state.filters[filter.id].selected.length - 3}
                </Tag>
              ) : null}
            </Flex>
            <Spacer />
            <IconButton variant="ghost" icon={<ChevronRightIcon />}></IconButton>
          </Flex>
        </PopoverTrigger>
        <PopoverContent
          width={'300px'}
          fontFamily="Hanken Grotesk"
          style={{
            boxShadow: '0 0 20px 0 #dddddd'
          }}>
          <PopoverCloseButton />
          <PopoverArrow />
          <PopoverHeader>
            <VStack alignItems={'start'} spacing="5px">
              <Text>{filter.name}</Text>
              <Input
                ref={initialFocusRef}
                placeholder={'Search ' + filter.name}
                value={searchedTerm}
                onChange={(e) => {
                  setSearchedTerm(e.target.value);
                }}
              />
            </VStack>
          </PopoverHeader>
          <PopoverBody maxHeight="700px" overflowY={'scroll'}>
            {filter.select.options
              .sort((a, b) => a.toLowerCase().localeCompare(b.toLowerCase()))
              .map((option, k) => {
                if (option.toLowerCase().includes(searchedTerm.toLowerCase())) {
                  return (
                    <Flex
                      key={k}
                      onClick={() => {
                        if (state.filters[filter.id].selected.includes(option)) {
                          setState({
                            ...state,
                            filters: {
                              ...state.filters,
                              [filter.id]: {
                                ...state.filters[filter.id],
                                selected: state.filters[filter.id].selected.filter(
                                  (item) => item != option
                                )
                              }
                            }
                          });
                        } else {
                          setState({
                            ...state,
                            filters: {
                              ...state.filters,
                              [filter.id]: {
                                ...state.filters[filter.id],
                                selected: [...state.filters[filter.id].selected, option]
                              }
                            }
                          });
                        }
                      }}
                      _hover={{
                        cursor: 'pointer',
                        backgroundColor: state.filters[filter.id].selected.includes(option)
                          ? '#f7f7f7 !important'
                          : '#f7f7f7 !important'
                      }}
                      w="100%"
                      gap="5px"
                      p="5px 10px"
                      minHeight={'40px'}
                      alignItems={'center'}
                      style={{
                        //   border: '1px solid #EEEEEE',
                        //   borderRadius: '5px',
                        backgroundColor: state.filters[filter.id].selected.includes(option)
                          ? '#f7f7f7'
                          : '#fff'
                      }}>
                      {option}
                    </Flex>
                  );
                }
              })}
          </PopoverBody>
        </PopoverContent>
      </Popover>
    </VStack>
  );
};

const XFilters = ({ config, state, setState }) => {
  const chakratheme = useTheme();
  return (
    <ChakraProvider>
      <Flex
        style={{
          borderRadius: '20px',
          boxShadow: `${chakratheme.colors.shadow} 0px 0px 20px 0px`,
          backgroundColor: '#fff'
        }}
        minWidth={config.maxWidth}
        maxWidth={config.maxWidth}
        p="20px"
        flexDir={'column'}>
        <Flex gap="10px" alignItems={'center'}>
          <Text fontFamily={'Poppins'} mb={0} fontWeight={'bold'} fontSize="15px" textAlign="left">
            Filters
          </Text>
          <Spacer />
          {/* <Button variant="outline">Discard</Button> */}
          {/* <Button>Apply</Button> */}
          <Button variant="ghost" fontSize="13px" fontWeight={'regular'}>
            Clear All
          </Button>
        </Flex>
        <InputGroup>
          {' '}
          <Input placeholder="Search Filters" fontSize="14px" />
          <InputRightElement>
            <SearchIcon />
          </InputRightElement>
        </InputGroup>
        <Divider mb="10px" />
        {config.groups.map((group, i) => (
          <Flex flexDir={'column'} key={i} mt="10px">
            <Flex
              alignItems={'center'}
              W="100%"
              _hover={{
                cursor: 'pointer',
                backgroundColor: '#f7f7f7 !important'
              }}
              onClick={() => {
                setState({
                  ...state,
                  groups: {
                    ...state.groups,
                    [group.id]: {
                      expanded: !state.groups[group.id].expanded
                    }
                  }
                });
              }}>
              <Text mb={0} fontWeight={'bold'} fontSize="15px" textAlign="left">
                {group.name}
              </Text>
              <Spacer />
              <IconButton
                variant="ghost"
                icon={
                  state.groups[group.id].expanded ? <ChevronUpIcon /> : <ChevronDownIcon />
                }></IconButton>
            </Flex>
            {state.groups[group.id].expanded && (
              <Flex flexDir={'column'} gap="20px">
                {group.children.map((child, j) => {
                  const _filter = config.filters.find((filter) => filter.id == child);

                  return (
                    <VStack alignItems={'start'} key={j}>
                      {_filter.type == 'select' ? (
                        <XSelect
                          config={config}
                          state={state}
                          setState={setState}
                          filter={_filter}
                        />
                      ) : null}
                      {_filter.type == 'boolean' ? (
                        <Flex
                          pl="20px"
                          pr="20px"
                          onClick={() => {
                            setState({
                              ...state,
                              filters: {
                                ...state.filters,
                                [_filter.id]: {
                                  ...state.filters[_filter.id],
                                  selected: !state.filters[_filter.id].selected
                                }
                              }
                            });

                            // onToggle();
                          }}
                          _hover={{
                            cursor: 'pointer',
                            backgroundColor: '#f7f7f7 !important'
                          }}
                          w="100%"
                          gap="5px"
                          minHeight={'40px'}
                          alignItems={'center'}
                          style={{
                            border: '1px solid #EEEEEE',
                            borderRadius: '5px',
                            backgroundColor: '#fff'
                          }}>
                          <Text>{_filter.name}</Text>
                          <Spacer />
                          <Switch
                            isChecked={state.filters[_filter.id].selected}
                            onChange={(e) => {
                              e.stopPropagation();
                              setState({
                                ...state,
                                filters: {
                                  ...state.filters,
                                  [_filter.id]: {
                                    ...state.filters[_filter.id],
                                    selected: e.target.checked
                                  }
                                }
                              });
                            }}
                          />
                        </Flex>
                      ) : null}
                      {_filter.type == 'search' && _filter.search.autoComplete ? (
                        <XSearch
                          config={config}
                          state={state}
                          setState={setState}
                          filter={_filter}
                        />
                      ) : null}
                      {_filter.type == 'range' && _filter.range.type == 'number' ? (
                        <VStack alignItems="start">
                          <Text mb={0} fontSize="13px" textAlign="left">
                            {_filter.name}
                          </Text>
                          <Flex
                            w="100%"
                            padding="5px 20px"
                            gap="5px"
                            minHeight={'40px'}
                            alignItems={'center'}
                            style={{
                              border: '1px solid #EEEEEE',
                              borderRadius: '5px',
                              backgroundColor: '#fff'
                            }}>
                            <Input
                              border="0"
                              backgroundColor={'#f5f5f5'}
                              borderRadius={'5px'}
                              type="number"
                              placeholder="Min"
                              value={state.filters[_filter.id].selected.min}
                              onChange={(e) => {
                                setState({
                                  ...state,
                                  filters: {
                                    ...state.filters,
                                    [_filter.id]: {
                                      ...state.filters[_filter.id],
                                      selected: {
                                        ...state.filters[_filter.id].selected,
                                        min: e.target.value
                                      }
                                    }
                                  }
                                });
                              }}
                            />
                            <Text>-</Text>
                            <Input
                              border="0"
                              backgroundColor={'#f5f5f5'}
                              borderRadius={'5px'}
                              type="number"
                              placeholder="Max"
                              value={state.filters[_filter.id].selected.max}
                              onChange={(e) => {
                                setState({
                                  ...state,
                                  filters: {
                                    ...state.filters,
                                    [_filter.id]: {
                                      ...state.filters[_filter.id],
                                      selected: {
                                        ...state.filters[_filter.id].selected,
                                        max: e.target.value
                                      }
                                    }
                                  }
                                });
                              }}
                            />
                          </Flex>
                        </VStack>
                      ) : null}
                      {_filter.type == 'checkbox' ? (
                        <VStack alignItems="start">
                          <Text mb={0} fontSize="13px" textAlign="left">
                            {_filter.name}
                          </Text>
                          <Flex
                            w="100%"
                            direction={'column'}
                            wrap="wrap"
                            padding="5px 0px"
                            gap="5px"
                            minHeight={'40px'}
                            alignItems={'flex-start'}
                            style={{
                              //   border: '1px solid #EEEEEE',
                              //   borderRadius: '5px',
                              backgroundColor: '#fff'
                            }}>
                            {_filter.checkbox.options.map((option, k) => {
                              if (_filter.checkbox.multiple)
                                return (
                                  <Checkbox
                                    style={{ fontSize: '14px' }}
                                    key={k}
                                    isChecked={state.filters[_filter.id].selected.includes(option)}
                                    onChange={() => {
                                      if (state.filters[_filter.id].selected.includes(option)) {
                                        setState({
                                          ...state,
                                          filters: {
                                            ...state.filters,
                                            [_filter.id]: {
                                              ...state.filters[_filter.id],
                                              selected: state.filters[_filter.id].selected.filter(
                                                (item) => item != option
                                              )
                                            }
                                          }
                                        });
                                      } else {
                                        setState({
                                          ...state,
                                          filters: {
                                            ...state.filters,
                                            [_filter.id]: {
                                              ...state.filters[_filter.id],
                                              selected: [
                                                ...state.filters[_filter.id].selected,
                                                option
                                              ]
                                            }
                                          }
                                        });
                                      }
                                    }}>
                                    <Text fontSize={'12px'}>{option}</Text>
                                  </Checkbox>
                                );
                              else
                                return (
                                  <Radio
                                    key={k}
                                    value={option}
                                    isChecked={state.filters[_filter.id].selected == option}
                                    onChange={() => {
                                      if (state.filters[_filter.id].selected == option) {
                                        setState({
                                          ...state,
                                          filters: {
                                            ...state.filters,
                                            [_filter.id]: {
                                              ...state.filters[_filter.id],
                                              selected: ''
                                            }
                                          }
                                        });
                                      } else {
                                        setState({
                                          ...state,
                                          filters: {
                                            ...state.filters,
                                            [_filter.id]: {
                                              ...state.filters[_filter.id],
                                              selected: option
                                            }
                                          }
                                        });
                                      }
                                    }}>
                                    <Text fontSize={'14px'}>{option}</Text>
                                  </Radio>
                                );
                            })}
                          </Flex>
                        </VStack>
                      ) : null}
                    </VStack>
                  );
                })}
              </Flex>
            )}
          </Flex>
        ))}
      </Flex>
    </ChakraProvider>
  );
};
export default XFilters;

// const filtersConfig = {
//     maxWidth: '350px',
//     filters: [
//       {
//         id: 'city',
//         name: 'City',
//         type: 'select',
//         select: {
//           multiple: true,
//           options:
//             // convert array to set to array
//             Array.from(new Set(fakerGenerate('city', 1000)))
//         }
//       },
//       {
//         id: 'country',
//         name: 'Country',
//         type: 'select',
//         select: {
//           multiple: true,
//           options: Array.from(new Set(fakerGenerate('country', 1000)))
//         }
//       },
//       {
//         id: 'state',
//         name: 'State',
//         type: 'select',
//         select: {
//           multiple: true,
//           options: Array.from(new Set(fakerGenerate('state', 1000)))
//         }
//       },
//       {
//         id: 'zipCode',
//         name: 'Zip Code',
//         type: 'select',
//         select: {
//           multiple: true,
//           options: Array.from(new Set(fakerGenerate('zipCode', 1000)))
//         }
//       },
//       {
//         id: 'county',
//         name: 'County',
//         type: 'select',
//         select: {
//           multiple: true,
//           options: Array.from(new Set(fakerGenerate('county', 1000)))
//         }
//       }
//     ],
//     groups: [
//       {
//         id: 'location',
//         children: ['city', 'country', 'state', 'zipCode', 'county'],
//         defaultExpanded: true,
//         name: 'Location'
//       }
//     ]
//   };
