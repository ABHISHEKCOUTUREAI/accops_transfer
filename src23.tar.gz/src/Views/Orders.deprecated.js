import { Box, Flex, HStack, Spacer, Text } from '@chakra-ui/layout';
import { IconButton, useTheme } from '@chakra-ui/react';
import React, { useContext } from 'react';
import { LocationContext } from '../Contexts/LocationContext';
import { attachGlobalFilters } from '../Utils/misc';
import axios from 'axios';
import { NewReleases, RemoveShoppingCart, ReportProblem, Check } from '@mui/icons-material';
import { Chip } from '@mui/material';

import { XTable, useXTableState } from '../components/CommonTable';
import statusColors from './statusColors';
import { ChevronDownIcon, ChevronRightIcon } from '@chakra-ui/icons';
import XFilters, { useXFiltersState } from './CommonFilters';
import { fakerEN as faker } from '@faker-js/faker';

const Orders = () => {
  const chakratheme = useTheme();

  const { consoleState } = useContext(LocationContext);

  const handlePagination = async (state, page) => {
    let formData = new FormData();

    formData.append('page_no', page);

    formData = attachGlobalFilters(formData, consoleState);
    // formData = attachTableData(formData, assortmentTableState);

    let config = {
      method: 'post',
      url: `${consoleState.state.api.BASE_URL}${consoleState.state.api.ASSORTMENT}`,
      data: formData
    };

    const response = await axios(config);
    return {
      data: response.data[consoleState.state.assortmentTable.types['assortment'].apiKey].map(
        (data) => {
          return {
            ...data,
            order_status:
              data.minimum_replenishment > 0
                ? 'notplaced'
                : ['fulfilled', 'notplaced', 'progress', ''][Math.floor(Math.random() * 4)]
          };
        }
      ),
      totalRecords: response.data[`assortment_count`]
    };
  };

  //   const formatInternationalStandard = (num) => {
  //     // remove decimal from number
  //     if (num > 0) {
  //       const numStr = num.toString().split('.')[0];
  //       // add commas to number
  //       return numStr.replace(/(\d)(?=(\d{3})+(?!\d))/g, '$1,');
  //     } else {
  //       return num;
  //     }
  //   };

  const tableConfig = {
    maxHeight: '800px',
    rows: {
      rowDatakey: 'product_id',
      rowGroups: {
        allowRowGroup: true,
        groupKey: 'L3',
        groupTransformer: ({ value, data, expanded, setExpanded }) => {
          return (
            <Flex
              w="100%"
              p="10px 20px"
              gap="5px"
              bg="#fdfdfd"
              alignItems="center"
              cursor={'pointer'}
              _hover={{
                bg: '#f5f5f5 !important'
              }}
              onClick={() => setExpanded(!expanded)}
              style={{
                padding: '10px'
              }}>
              <IconButton
                icon={expanded ? <ChevronDownIcon /> : <ChevronRightIcon />}
                variant="ghost"
              />
              <Text color="#444746">{value}</Text>
              <Spacer />
              <Text>
                {data.length} Product{data.length > 1 ? 's' : ''}
              </Text>
            </Flex>
          );
        }
      }
    },
    columns: {
      headers: [
        {
          title: 'Inventory Status',
          id: 'status',
          dataIndex: 'status_label',
          colSpan: 1,
          sort: {
            allow: true
          },
          transformer: ({ value }) => {
            const statusToBgColor = {
              '0_new': '#caddfc',
              '9_excess': '#f7cfb5',
              '1_replenish': '#fccbc7',
              '2_no_replenishment': '#c3dbca'
            };
            const statusToColor = {
              '0_new': '#4287f5',
              '9_excess': '#Dd6A1F',
              '1_replenish': '#eb4034',
              '2_no_replenishment': '#32a852'
            };
            const statusToName = {
              '0_new': 'New',
              '9_excess': 'Excess',
              '1_replenish': 'Low Stock',
              '2_no_replenishment': 'Optimal'
            };
            const statusToIcon = {
              '0_new': NewReleases,
              '9_excess': RemoveShoppingCart,
              '1_replenish': ReportProblem,
              '2_no_replenishment': Check
            };
            const Icon = statusToIcon[value];
            return (
              <Chip
                icon={
                  <Icon
                    style={{
                      color: statusToColor[value],
                      fontSize: '14px'
                    }}
                  />
                }
                key={value}
                label={statusToName[value]}
                style={{
                  fontWeight: 'bold',
                  backgroundColor: statusToBgColor[value],
                  color: statusToColor[value]
                }}
                size="small"
              />
            );
          },
          filters: {
            filterType: 'discrete',
            filterID: 'status_label',
            discrete: {
              multiple: true,
              options: [
                { label: 'New', value: '0_new' },
                { label: 'Excess', value: '9_excess' },
                { label: 'Low Stock', value: '1_replenish' },
                { label: 'Optimal', value: '2_no_replenishment' }
              ],
              optionTransformer: ({ value }) => {
                const statusToBgColor = {
                  '0_new': '#caddfc',
                  '9_excess': '#f7cfb5',
                  '1_replenish': '#fccbc7',
                  '2_no_replenishment': '#c3dbca'
                };
                const statusToColor = {
                  '0_new': '#4287f5',
                  '9_excess': '#Dd6A1F',
                  '1_replenish': '#eb4034',
                  '2_no_replenishment': '#32a852'
                };
                const statusToName = {
                  '0_new': 'New',
                  '9_excess': 'Excess',
                  '1_replenish': 'Low Stock',
                  '2_no_replenishment': 'Optimal'
                };
                const statusToIcon = {
                  '0_new': NewReleases,
                  '9_excess': RemoveShoppingCart,
                  '1_replenish': ReportProblem,
                  '2_no_replenishment': Check
                };
                const Icon = statusToIcon[value];
                return (
                  <Chip
                    icon={
                      <Icon
                        style={{
                          color: statusToColor[value],
                          fontSize: '14px'
                        }}
                      />
                    }
                    key={value}
                    label={statusToName[value]}
                    style={{
                      fontWeight: 'bold',
                      backgroundColor: statusToBgColor[value],
                      color: statusToColor[value]
                    }}
                    size="small"
                  />
                );
              }
            }
          }
        },
        {
          title: 'Product ID',
          id: 'product_id',
          dataIndex: 'product_id',
          colSpan: 1
        },
        {
          title: 'Name',
          sort: {
            allow: true
          },
          id: 'product_name',
          dataIndex: 'product_name',
          colSpan: 1,
          filters: {
            filterType: 'search',
            filterID: 'product_name'
          }
        },
        {
          title: 'Molecule',
          sort: {
            allow: true
          },
          dataIndex: 'description',
          colSpan: 1,
          filters: {
            filterType: 'search',
            filterID: 'description'
          }
        },
        {
          title: 'SBU',
          sort: {
            allow: true
          },
          id: 'L0',
          dataIndex: 'L0',
          colSpan: 1
        },
        {
          title: 'Segment',
          id: 'L3',
          dataIndex: 'L3',
          colSpan: 1
        },
        {
          title: `Retail Price`,
          id: 'price',
          dataIndex: 'price',
          colSpan: 1,
          filters: {
            filterType: 'range',
            filterID: 'price',
            range: {
              defaultMin: 0,
              defaultMax: 10000
            }
          }
        },
        {
          title: 'Existing Inventory',
          id: 'current_inventory',
          dataIndex: 'current_inventory',
          colSpan: 1,
          filters: {
            filterType: 'range',
            filterID: 'current_inventory',
            range: {
              defaultMin: 0,
              defaultMax: 1000
            }
          }
        },
        {
          title: 'Order trigger qty',
          id: 'order_trigger_qty',
          colSpan: 1,
          dataIndex: 'min_qty'
        },
        {
          title: 'Max stocked qty',
          id: 'max_stocked_qty',
          colSpan: 1,
          dataIndex: 'max_qty'
        },
        {
          title: 'Recommended Replenishment',
          id: 'recommended_replenishment',
          dataIndex: 'minimum_replenishment',
          colSpan: 1,
          cellBackground: ({ row }) => {
            const statusToBgColor = {
              '0_new': '#caddfc',
              '9_excess': '#f7cfb5',
              '1_replenish': '#fccbc7',
              '2_no_replenishment': '#c3dbca'
            };
            return statusToBgColor[row['status_label']];
          },
          transformer: ({ value, row }) => {
            const statusToBgColor = {
              '0_new': '#caddfc',
              '9_excess': '#f7cfb5',
              '1_replenish': '#fccbc7',
              '2_no_replenishment': '#c3dbca'
            };
            const statusToColor = {
              '0_new': '#4287f5',
              '9_excess': '#Dd6A1F',
              '1_replenish': '#eb4034',
              '2_no_replenishment': '#32a852'
            };

            const statusToIcon = {
              '0_new': NewReleases,
              '9_excess': RemoveShoppingCart,
              '1_replenish': ReportProblem,
              '2_no_replenishment': Check
            };
            const Icon = statusToIcon[row['status_label']];
            return (
              <Flex
                h="100%"
                p="5px 20px"
                bg={statusToBgColor[row['status_label']]}
                alignItems={'center'}
                gap="5px"
                color={statusToColor[row['status_label']]}>
                <Icon style={{ fontSize: '12px' }} />
                {value}
              </Flex>
            );
          }
        },
        {
          title: 'Order Status',
          dataIndex: 'order_status',
          colSpan: 1,
          transformer: ({ value }) => {
            if (!value) return null;
            const { statusToBgColor, statusToColor, statusToIcon } = statusColors;
            const valueToKey = {
              progress: 'partial',
              notplaced: 'pending',
              fulfilled: 'done'
            };
            const valueToLabel = {
              progress: 'In Progress',
              notplaced: 'Not Placed',
              fulfilled: 'Fulfilled'
            };
            const _key = valueToKey[value];
            const Icon = statusToIcon[_key];
            return (
              <Chip
                icon={
                  <Icon
                    style={{
                      color: statusToColor[_key],
                      fontSize: '14px'
                    }}
                  />
                }
                label={valueToLabel[value]}
                style={{
                  fontWeight: 'bold',
                  backgroundColor: statusToBgColor[_key],
                  color: statusToColor[_key]
                }}
                size="small"
              />
            );
          }
        }
      ],
      groups: {
        allowGroups: true,
        groups: [
          {
            name: 'Product Details',
            columns: ['Product ID', 'Name', 'Molecule', 'SBU', 'Segment', 'Retail Price'],
            collapsible: true,
            defaultCollapsed: true,
            collapsedName: 'Summary',
            collapsedTransformer: ({ row }) => {
              return (
                <Flex direction="column" gap="5px" w="100%">
                  <Text fontWeight={'bold'}>{row['product_id']}</Text>
                  <Text
                    w="100%"
                    style={{
                      wordBreak: 'break-word !important',
                      whiteSpace: 'normal'
                    }}>
                    {row['product_name']}
                  </Text>
                </Flex>
              );
            }
          },
          {
            name: 'Predictions',
            columns: ['Order trigger qty', 'Max stocked qty', 'Recommended Replenishment']
            // collapsible: true,
            // collapsedName: 'Summary'
          }
        ]
      },
      unhideableColumns: ['Cart', 'Order Status', 'Product ID'],
      defaultHiddenColumns: ['Inventory Status', 'SBU', 'Segment']
    },
    pagination: {
      infiniteScroll: true,
      allowPagination: true,
      defaultPageNumber: 1,
      defaultPageSize: 20,
      defaultFetchSize: 100,
      pageSizeOptions: [10, 20, 50, 100],
      fetch: handlePagination
    }
  };

  const fakerGenerate = (name, count) => {
    const sample = {
      person: [
        'bio',
        'firstName',
        'fullName',
        'gender',
        'jobArea',
        'jobTitle',
        'lastName',
        'zodiacSign'
      ],
      commerce: [
        'department',
        'isbn',
        'price',
        'product',
        'productAdjective',
        'productDescription',
        'productMaterial',
        'productName'
      ],
      location: ['city', 'country', 'state', 'zipCode', 'county']
    };

    const group = Object.keys(sample).find((key) => sample[key].includes(name));
    const method = faker[group][name];
    return Array.from({ length: count }, () => method());
  };
  const filtersConfig = {
    maxWidth: '350px',
    filters: [
      {
        id: 'city',
        name: 'City',
        type: 'select',
        select: {
          multiple: true,
          options:
            // convert array to set to array
            Array.from(new Set(fakerGenerate('city', 1000)))
        }
      },
      {
        id: 'country',
        name: 'Country',
        type: 'select',
        select: {
          multiple: true,
          options: Array.from(new Set(fakerGenerate('country', 1000)))
        }
      },
      {
        id: 'state',
        name: 'State',
        type: 'select',
        select: {
          multiple: true,
          options: Array.from(new Set(fakerGenerate('state', 1000)))
        }
      },
      //   {
      //     id: 'zipCode',
      //     name: 'Zip Code',
      //     type: 'select',
      //     select: {
      //       multiple: true,
      //       options: Array.from(new Set(fakerGenerate('zipCode', 1000)))
      //     }
      //   },
      //   {
      //     id: 'county',
      //     name: 'County',
      //     type: 'select',
      //     select: {
      //       multiple: true,
      //       options: Array.from(new Set(fakerGenerate('county', 1000)))
      //     }
      //   },
      {
        id: 'department',
        name: 'Department',
        type: 'select',
        select: {
          multiple: true,
          options: Array.from(new Set(fakerGenerate('department', 1000)))
        }
      },
      {
        id: 'isbn',
        name: 'ISBN',
        type: 'boolean'
      },
      {
        id: 'issold',
        name: 'Is Sold',
        type: 'boolean'
      },
      {
        id: 'status',
        name: 'Status',
        type: 'checkbox',
        checkbox: {
          multiple: false,
          options: ['Pending', 'Delievered', 'Cancelled']
        }
      },
      {
        id: 'price',
        name: 'Price',
        type: 'range',
        range: {
          type: 'number',
          defaultMin: 0,
          defaultMax: null
        }
      },
      {
        id: 'product',
        name: 'Product',
        type: 'search',
        search: {
          autoComplete: true,
          free: true,
          options: Array.from(new Set(fakerGenerate('product', 1000)))
        }
      },
      {
        id: 'productAdjective',
        name: 'Product Adjective',
        type: 'select',
        select: {
          multiple: true,
          options: Array.from(new Set(fakerGenerate('productAdjective', 1000)))
        }
      }
    ],
    groups: [
      {
        id: 'location',
        children: ['city', 'country', 'state'],
        defaultExpanded: true,
        name: 'Location'
      },
      {
        id: 'commerce',
        children: [
          'department',
          'status',
          'isbn',
          'price',
          'product',
          'productAdjective',
          'issold'
        ],
        defaultExpanded: true,
        name: 'Commerce'
      }
    ]
  };
  const { state: tableState, setState: setTableState } = useXTableState(tableConfig);
  const { state: filtersState, setState: setFiltersState } = useXFiltersState(filtersConfig);
  return (
    <Flex
      direction="column"
      alignItems="flex-start"
      justifyContent="center"
      gap="20px"
      width="100%"
      style={{ padding: '50px 20px 20px 20px' }}>
      <Flex direction="column" id="overview" gap="0px">
        <Text
          style={{
            fontSize: '22px',
            fontFamily: 'Poppins',
            fontWeight: 'bold',
            marginTop: '0px'
          }}>
          Orders
        </Text>
        <Box w="50px" h="5px" bg={`${chakratheme.colors.primary.main}`} borderRadius="3px" mt={2} />
        <Text
          mt={3}
          style={{
            color: `${chakratheme.colors.black[400]}`,
            fontSize: '13px',
            fontFamily: 'sans-serif'
          }}>
          Order History And Fulfillment.
        </Text>
      </Flex>

      <HStack w="100%" gap="20px" alignItems={'start'}>
        <XFilters config={filtersConfig} state={filtersState} setState={setFiltersState} />
        <Box
          w="100%"
          style={{
            borderRadius: '20px',
            boxShadow: `${chakratheme.colors.shadow} 0px 0px 20px 0px`,
            padding: '20px'
          }}>
          <Flex
            w="100%"
            justifyContent="space-between"
            alignItems={'center'}
            // marginTop="10px"
            fontFamily={'Poppins'}>
            <Box flex="7">
              <Text mb={0} fontWeight={'bold'} fontSize="15px" textAlign="left">
                Past Orders
              </Text>
            </Box>
          </Flex>

          <XTable
            state={tableState}
            setState={setTableState}
            config={tableConfig}
            style={{ fontFamily: 'Hanken Grotesk' }}
          />
        </Box>
      </HStack>
    </Flex>
  );
};

export default Orders;
