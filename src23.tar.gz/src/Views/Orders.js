import { Box, Divider, Flex, HStack, Spacer, Text } from '@chakra-ui/layout';
import {
  IconButton,
  Input,
  InputGroup,
  InputRightElement,
  Tag,
  TagLabel,
  useTheme,
  // Button,
  // Tooltip,
  useToast,
  ChakraProvider
} from '@chakra-ui/react';
import React, { useContext, useEffect, useState } from 'react';
import { ConfirmationDialog } from '../components/ConfirmationDialog';
// import { LocationContext } from '../Contexts/LocationContext';
// import { attachGlobalFilters } from '../Utils/misc';
// import axios from 'axios';
import statusColors from './statusColors';
import XFilters, { useXFiltersState } from './CommonFilters';
// import { fakerEN as faker } from '@faker-js/faker';
import { useNavigate } from 'react-router-dom';
import { SearchIcon } from '@chakra-ui/icons';
import { ChevronLeftRounded, ChevronRightRounded } from '@mui/icons-material';
import { getCartAPI } from '../Utils/CartAPI';
import { LocationContext } from '../Contexts/LocationContext';
import { useHardResetCofirmationDialogState } from '../components/ConfirmationDialog';
import theme from '../theme';
Date.prototype.addDays = function (days) {
  var date = new Date(this.valueOf());
  date.setDate(date.getDate() + days);
  return date;
};
const Orders = () => {
  const chakratheme = useTheme();
  const { consoleState } = useContext(LocationContext);
  const cartAPI = getCartAPI(consoleState);
  const [storeId] = useState(consoleState?.state?.globalFilters?.region?.selected[3]);
  const [searchString, setSearchString] = useState('');
  const toast = useToast();
  const filterToQueryMap = {
    Pending: 'unfulfilled',
    Delievered: 'fulfilled'
  };

  const hardReset = async () => {
    try {
      const res = await cartAPI.hardReset(storeId);
      if (res.status === 200 || res.status === 202 || res.status === 204) {
        toast({
          title: 'Reset Successful.',
          description: 'The orders have been successfully reset.',
          status: 'success',
          duration: 3000,
          isClosable: true
        });
        navigate('/store-assortment');
      }
    } catch (e) {
      console.log(e);
    }
  };

  const [hardResetDialogState, setHardResetButtonDisabled] = useHardResetCofirmationDialogState(
    false,
    hardReset
  );

  const [ordersState, setOrdersState] = useState({
    data: [],
    fetchVariables: {
      loading: false,
      error: false,
      started: false,
      errorMessage: ''
    },
    pagination: {
      currentPage: 1,
      pageSize: 20,
      totalRecords: 0
    }
  });
  const fetchOrders = async (reqBody) => {
    setOrdersState({
      ...ordersState,
      fetchVariables: {
        ...ordersState.fetchVariables,
        loading: true
      }
    });
    if (!reqBody)
      reqBody = {
        store_id: storeId,
        page_no: 1,
        page_count: 20,
        globalSearch: '',
        filters: []
      };
    const res = await cartAPI.getOrders(reqBody);

    setOrdersState({
      ...ordersState,
      data: res.data.items,
      fetchVariables: {
        ...ordersState.fetchVariables,
        loading: false,
        started: true
      },
      pagination: {
        ...ordersState.pagination,
        totalRecords: res.data.total_count,
        totalPages: Math.ceil(res.data.total_count / ordersState.pagination.pageSize)
      }
    });
  };

  useEffect(() => {
    fetchOrders();
  }, []);

  useEffect(() => {
    if (ordersState.data.length <= 0) setHardResetButtonDisabled(true);
    else setHardResetButtonDisabled(false);
  }, [ordersState.data]);
  const navigate = useNavigate();

  // const fakerGenerate = (name, count) => {
  //   const sample = {
  //     person: [
  //       'bio',
  //       'firstName',
  //       'fullName',
  //       'gender',
  //       'jobArea',
  //       'jobTitle',
  //       'lastName',
  //       'zodiacSign'
  //     ],
  //     commerce: [
  //       'department',
  //       'isbn',
  //       'price',
  //       'product',
  //       'productAdjective',
  //       'productDescription',
  //       'productMaterial',
  //       'productName'
  //     ],
  //     location: ['city', 'country', 'state', 'zipCode', 'county']
  //   };

  //   const group = Object.keys(sample).find((key) => sample[key].includes(name));
  //   const method = faker[group][name];
  //   return Array.from({ length: count }, () => method());
  // };
  const filtersConfig = {
    maxWidth: '350px',
    filters: [
      {
        id: 'status',
        name: 'Status',
        type: 'checkbox',
        checkbox: {
          multiple: false,
          options: ['Pending', 'Delievered']
        }
      },
      // {
      //   id: 'constituents',
      //   name: 'Constituent Products',
      //   type: 'select',
      //   select: {
      //     multiple: true,
      //     options: fakerGenerate('product', 10)
      //   }
      // },
      {
        id: 'timeperiod',
        name: 'Time Period',
        type: 'checkbox',
        checkbox: {
          multiple: false,
          options: ['Today', 'Yesterday', 'Last 7 Days', 'Last 30 Days']
        }
      }
    ],
    groups: [
      {
        id: 'orders',
        children: ['status', 'timeperiod'],
        defaultExpanded: true,
        name: 'Orders'
      }
    ]
  };
  const { state: filtersState, setState: setFiltersState } = useXFiltersState(filtersConfig);

  useEffect(() => {
    // change of status filter
    if (filtersState.filters.status.selected) {
      let reqBody = {
        page_no: 1,
        page_count: 20,
        store_id: storeId,
        filters: [
          {
            id: 'order_status',
            type: 'discrete',
            queries: [filterToQueryMap[filtersState.filters.status.selected]]
          }
        ],
        globalSearch: searchString
      };
      fetchOrders(reqBody);
    }
  }, [filtersState.filters.status]);

  const searchByString = () => {
    let reqBody = {
      page_no: 1,
      page_count: 20,
      store_id: storeId,
      globalSearch: searchString
    };
    if (filtersState.filters.status.selected) {
      reqBody.filters = [
        {
          id: 'order_status',
          type: 'discrete',
          queries: [filterToQueryMap[filtersState.filters.status.selected]]
        }
      ];
    }
    fetchOrders(reqBody);
  };

  function getFormattedDate(date) {
    const year = date.getFullYear();
    const month = String(date.getMonth() + 1).padStart(2, '0');
    const day = String(date.getDate()).padStart(2, '0');
    return `${year}-${month}-${day}T00:00:00`; // Adjust format as needed
    // return Math.floor(date.getTime() / 1000);
  }

  // Function to get filters for date selection
  function getDateFilters(selected) {
    const now = new Date();
    const today = new Date(now.getFullYear(), now.getMonth(), now.getDate());
    const yesterday = new Date(today);
    yesterday.setDate(yesterday.getDate() - 1);

    const last7Days = new Date(today);
    last7Days.setDate(last7Days.getDate() - 7);

    const last30Days = new Date(today);
    last30Days.setDate(last30Days.getDate() - 30);

    if (selected === 'Today')
      return {
        id: 'ordered_at',
        type: 'range',
        min: getFormattedDate(today),
        max: getFormattedDate(now)
      };
    if (selected === 'Yesterday')
      return {
        id: 'ordered_at',
        type: 'range',
        min: getFormattedDate(yesterday),
        max: getFormattedDate(today)
      };
    else if (selected === 'Last 7 Days')
      return {
        id: 'ordered_at',
        type: 'range',
        min: getFormattedDate(last7Days),
        max: getFormattedDate(today)
      };
    else if (selected === 'Last 30 Days')
      return {
        id: 'ordered_at',
        type: 'range',
        min: getFormattedDate(last30Days),
        max: getFormattedDate(now)
      };
  }

  useEffect(() => {
    if (filtersState.filters.timeperiod.selected) {
      let reqBody = {
        page_no: 1,
        page_count: 20,
        store_id: storeId,
        globalSearch: searchString
      };

      reqBody.filters = [getDateFilters(filtersState.filters.timeperiod.selected)];
      fetchOrders(reqBody);
    }
  }, [filtersState.filters.timeperiod]);
  return (
    <ChakraProvider theme={theme}>
      <Flex
        direction="column"
        alignItems="flex-start"
        justifyContent="center"
        gap="20px"
        width="100%"
        style={{ padding: '50px 20px 20px 20px' }}>
        <Flex justifyContent={'space-between'} width={'100%'}>
          <Flex direction="column" id="overview" gap="0px">
            <Text
              style={{
                fontSize: '22px',
                fontFamily: 'Poppins',
                fontWeight: 'bold',
                marginTop: '0px'
              }}>
              Orders
            </Text>
            <Box
              w="50px"
              h="5px"
              bg={`${chakratheme.colors.primary.main}`}
              borderRadius="3px"
              mt={2}
            />
            <Text
              mt={3}
              style={{
                color: `${chakratheme.colors.black[400]}`,
                fontSize: '13px',
                fontFamily: 'sans-serif'
              }}>
              Order History And Fulfillment.
            </Text>
          </Flex>
          <Flex>
            <ConfirmationDialog state={hardResetDialogState} />
            {/* <Tooltip label="">
            <Button
              backgroundColor={`${chakratheme.colors.primary.main}`}
              color={'white'}
              padding={'10px 20px'}
              fontWeight={'bold'}
              height={'40px'}
              borderRadius={'8px'}
              onClick={() => hardReset()}>
              Hard Reset
            </Button>
          </Tooltip> */}
          </Flex>
        </Flex>

        <HStack w="100%" gap="20px" alignItems={'start'}>
          <XFilters config={filtersConfig} state={filtersState} setState={setFiltersState} />
          <Box
            w="100%"
            style={{
              borderRadius: '20px',
              boxShadow: `${chakratheme.colors.shadow} 0px 0px 20px 0px`,
              padding: '20px'
            }}>
            <Flex
              w="100%"
              justifyContent="space-between"
              alignItems={'center'}
              // marginTop="10px"
            >
              <Box flex="7">
                <Text
                  mb={2}
                  fontFamily={'Poppins'}
                  fontWeight={'bold'}
                  fontSize="15px"
                  textAlign="left">
                  Past Orders
                </Text>
                <InputGroup>
                  <Input
                    w="100%"
                    style={{
                      borderRadius: '2px',
                      border: '1px solid #f0f0f0',
                      padding: '10px 20px',
                      fontSize: '15px',
                      fontWeight: 'regular',
                      fontFamily: 'Montserrat',
                      background: 'none'
                    }}
                    value={searchString}
                    onChange={(e) => setSearchString(e.target.value)}
                    placeholder="Search Orders"
                  />
                  <InputRightElement
                    padding="15px 10px"
                    onClick={(e) => searchByString(e.target.value)}
                    cursor={'pointer'}>
                    <SearchIcon />
                  </InputRightElement>
                </InputGroup>
                <Box w="100%" h="1px" mt="10px" bg="#fafafa" />

                {ordersState.pagination.totalRecords > 0 ? (
                  <Flex
                    style={{
                      bottom: '0',
                      width: '100%',
                      padding: '0px 10px'
                    }}
                    justifyContent="space-between"
                    alignItems="center">
                    <Text fontSize="14px">
                      {`Showing  ${(ordersState.pagination.currentPage - 1) * ordersState.pagination.pageSize + 1} to  ${Math.min(
                        ordersState.pagination.currentPage * ordersState.pagination.pageSize,
                        ordersState.pagination.totalRecords
                      )} of ${ordersState.pagination.totalRecords} records`}
                    </Text>
                    <Spacer />
                    <Flex justifyContent="flex-end" alignItems="center">
                      <Box h="40px" mx={4}>
                        <Divider orientation="vertical" />
                      </Box>
                      <IconButton
                        onClick={() => {
                          setOrdersState({
                            ...ordersState,
                            pagination: {
                              ...ordersState.pagination,
                              currentPage: ordersState.pagination.currentPage - 1
                            }
                          });
                        }}
                        isDisabled={ordersState.pagination.currentPage <= 1}
                        size="sm"
                        variant="iconOutline">
                        <ChevronLeftRounded />
                      </IconButton>
                      <Text fontSize="14px" size="sm" p={5}>
                        Page {ordersState.pagination.currentPage} of{' '}
                        {Math.ceil(
                          ordersState.pagination.totalRecords / ordersState.pagination.pageSize
                        )}
                      </Text>
                      <IconButton
                        variant="iconOutline"
                        onClick={() => {
                          if (
                            ordersState.pagination.currentPage !== ordersState.pagination.totalPages
                          ) {
                            setOrdersState({
                              ...ordersState,
                              pagination: {
                                ...ordersState.pagination,
                                currentPage: ordersState.pagination.currentPage + 1
                              }
                            });
                          }
                        }}
                        isDisabled={
                          ordersState.pagination.currentPage >= ordersState.pagination.totalPages
                        }
                        size="sm">
                        <ChevronRightRounded />
                      </IconButton>
                    </Flex>
                  </Flex>
                ) : (
                  <Text textAlign={'center'}>No records found</Text>
                )}

                <Flex>
                  {ordersState.fetchVariables.loading ? null : (
                    <Flex direction="column" w="100%" gap="20px">
                      {ordersState.data &&
                        ordersState.data.map((order, index) => {
                          const Icon =
                            order?.order_status === 'unfulfilled'
                              ? statusColors.statusToIcon.partial
                              : statusColors.statusToIcon.done;

                          return (
                            <Flex
                              key={index}
                              justifyContent="space-between"
                              alignItems="center"
                              w="100%"
                              cursor="pointer"
                              _hover={{
                                backgroundColor: `#fafafa !important`
                              }}
                              onClick={() => {
                                navigate(`/orders/${order?.order_id}`);
                              }}
                              style={{
                                padding: '20px 20px',
                                borderRadius: '10px',
                                border: '1px solid #f0f0f0'
                                // boxShadow: `${chakratheme.colors.shadow} 0px 0px 20px 0px`
                              }}>
                              <Flex
                                flex="2"
                                justifyContent="space-between"
                                // alignItems="center"
                                direction={'column'}>
                                <Text fontFamily={'Poppins'} fontSize="13px" fontWeight="bold">
                                  {order?.total_products} Product
                                  {order?.total_products > 1 ? 's' : ''}
                                </Text>
                                <Text fontSize="12px" color="#999999">
                                  #{order?.order_id}
                                </Text>
                                <Text fontSize="14px" color="#999999">
                                  Order Placed on{' '}
                                  <span style={{ color: '#555555', fontWeight: 'bold' }}>
                                    {new Date(order?.ordered_at)
                                      .toString()
                                      .split(' ')
                                      .slice(0, 4)
                                      .join(' ')}
                                  </span>
                                </Text>
                                {/* <Text fontSize="13px" fontWeight="bold">
                                Fulfilled At: {JSON.stringify(order?.fulfilled_at)}
                              </Text> */}
                              </Flex>
                              <Spacer />
                              <Flex flex="2" wrap="wrap" gap="5px" padding="5px" fontSize={'10px'}>
                                {order?.products?.slice(0, 2).map((product, index) => {
                                  return (
                                    <Tag
                                      key={index}
                                      size="sm"
                                      style={{
                                        borderRadius: '2px',
                                        border: '1px solid #E7E7E7',
                                        backgroundColor: '#F1F1F1',
                                        color: '#2E2F32',
                                        padding: '5px 10px'
                                      }}>
                                      <TagLabel>
                                        {product.product_name.slice(0, 20)}
                                        {product.product_name.length > 20 ? '...' : ''}
                                      </TagLabel>
                                    </Tag>
                                  );
                                })}
                                {order?.total_products > 2 ? (
                                  <Tag
                                    size="sm"
                                    style={{
                                      borderRadius: '2px',
                                      border: '1px solid #E7E7E7',
                                      backgroundColor: '#F1F1F1',
                                      color: '#2E2F32',
                                      padding: '5px 10px'
                                    }}>
                                    <TagLabel>+{order?.total_products - 2}</TagLabel>
                                  </Tag>
                                ) : null}
                              </Flex>
                              <Spacer />
                              <Flex flex="2" direction="column" gap="5px" alignItems={'flex-end'}>
                                <Flex
                                  maxWidth="150px"
                                  flex="1"
                                  p="5px 10px"
                                  alignItems="center"
                                  justifyContent={'space-around'}
                                  style={{
                                    color:
                                      order?.order_status === 'unfulfilled'
                                        ? statusColors.statusToColor.partial
                                        : statusColors.statusToColor.done,
                                    backgroundColor:
                                      order?.order_status === 'unfulfilled'
                                        ? statusColors.statusToBgColor.partial
                                        : statusColors.statusToBgColor.done,
                                    borderRadius: '20px'
                                  }}>
                                  <Icon fontSize="12px" />
                                  <Text fontSize="12px" fontWeight="bold">
                                    {order?.order_status === 'unfulfilled'
                                      ? 'Delivery Expected'
                                      : 'Delievered'}
                                  </Text>
                                </Flex>
                                <Flex
                                  p="5px 20px"
                                  style={{
                                    backgroundColor: '#f9f9f9'
                                  }}>
                                  {order?.order_status === 'pending' ? (
                                    <Text fontSize="12px" color="#777777">
                                      <span
                                        style={{
                                          color: statusColors.statusToColor.partial
                                        }}>
                                        Expected Delievery
                                      </span>{' '}
                                      on{' '}
                                      {order?.fulfilled_at
                                        ?.toString()
                                        .split(' ')
                                        .slice(0, 4)
                                        .join(' ') ??
                                        new Date()
                                          .addDays(3)
                                          .toString()
                                          .split(' ')
                                          .slice(0, 4)
                                          .join(' ')}
                                    </Text>
                                  ) : (
                                    <Text fontSize="12px" color="#777777">
                                      <span
                                        style={{
                                          color: statusColors.statusToColor.done
                                        }}>
                                        {/* Delievered */}
                                      </span>{' '}
                                      on{' '}
                                      {order?.fulfilled_at
                                        ?.toString()
                                        .split(' ')
                                        .slice(0, 4)
                                        .join(' ') ??
                                        new Date()
                                          .addDays(3)
                                          .toString()
                                          .split(' ')
                                          .slice(0, 4)
                                          .join(' ')}
                                    </Text>
                                  )}
                                </Flex>
                              </Flex>
                            </Flex>
                          );
                        })}
                    </Flex>
                  )}
                </Flex>
              </Box>
            </Flex>
          </Box>
        </HStack>
      </Flex>
    </ChakraProvider>
  );
};

export default Orders;
