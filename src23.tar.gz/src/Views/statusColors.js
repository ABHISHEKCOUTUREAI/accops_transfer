import { Check, FiberManualRecord, Warning } from '@mui/icons-material';

const statusToBgColor = {
  // '0_new': '#caddfc',
  partial: '#f7cfb5',
  pending: '#fccbc7',
  done: '#c3dbca'
};
const statusToColor = {
  // '0_new': '#4287f5',
  partial: '#Dd6A1F',
  pending: '#eb4034',
  done: '#32a852'
};
const statusToIcon = {
  // '0_new': NewReleases,
  pending: Warning,
  partial: FiberManualRecord,
  done: Check
};
export default {
  statusToBgColor,
  statusToColor,
  statusToIcon
};
