import { Text, Flex } from '@chakra-ui/react';
import { HomeCards } from '../Containers/StoreManagerHome/HomeInventoryCards';
import { HomeRevenueCards } from '../Containers/StoreManagerHome/HomeRevenueCards';
import { fetchPastSales } from '../adapters/analytics';
import { useState, useEffect, useContext } from 'react';
import { RevenueMarginCharts } from '../Containers/StoreManagerHome/RevenueMarginCharts';
import { LocationContext } from '../Contexts/LocationContext';
export const StoreManagerHome = () => {
  const data = {
    excess: 2480,
    replenish: 1209,
    optimal: 872,
    new: 2951
  };
  const totalProducts = 7512;
  const categories = ['Excess Products', 'Low Stock Products', 'Optimal Products', 'New Products'];
  const { consoleState } = useContext(LocationContext);

  const [salesData, setSalesData] = useState(null);

  useEffect(() => {
    fetchPastSales(consoleState).then((data) => {
      setSalesData(data);
      console.log('salesData', data);
    });
  }, []);

  return (
    <Flex direction={'column'} mx={5}>
      {/* HEADER */}
      <Flex direction={'column'}>
        <Text
          style={{
            fontSize: '16px',
            fontFamily: 'Poppins',
            fontWeight: 'bold',
            marginTop: '0px'
          }}>
          Hello
        </Text>
        <Text
          style={{
            fontSize: '22px',
            fontFamily: 'Poppins',
            fontWeight: 'bold',
            marginTop: '0px'
          }}>
          Store Manager
        </Text>
      </Flex>

      <HomeCards values={data} totalProducts={totalProducts} categories={categories} />
      <HomeRevenueCards />
      <RevenueMarginCharts salesData={salesData} />
    </Flex>
  );
};
