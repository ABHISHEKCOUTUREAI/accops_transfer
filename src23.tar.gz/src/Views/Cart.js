import { Box, Flex, HStack, Spacer, Text } from '@chakra-ui/layout';
import {
  Button,
  ChakraProvider,
  CircularProgress,
  CircularProgressLabel,
  Input,
  useTheme,
  useToast,
  IconButton,
  Spinner
} from '@chakra-ui/react';
import React, { useContext, useState } from 'react';
import { LocationContext } from '../Contexts/LocationContext';
import EditIcon from '@mui/icons-material/Edit';
import { CheckIcon, CloseIcon } from '@chakra-ui/icons';
// import { attachGlobalFilters } from '../Utils/misc';
// import axios from 'axios';
import {
  ExpandCircleDown
  // NewReleases,
  // RemoveShoppingCart,
  // ReportProblem,
  // Check
} from '@mui/icons-material';
// import { Chip } from '@mui/material';

import ProgressChart from '../components/charts/ProgressChart';
import { XTable, useXTableState } from '../components/CommonTable';
// import statusColors from './statusColors';
import { getCartAPI } from '../Utils/CartAPI';
import { useNavigate } from 'react-router-dom';
import theme from '../theme';

const Cart = () => {
  const chakratheme = useTheme();
  const [cartValue, setCartValue] = useState(0);
  const [cartWidth, setCartWidth] = useState(0);
  const [cartCoverageByItems, setCartCoverageByItems] = useState(0);
  const [cartCoverageByValue, setCartCoverageByValue] = useState(0);
  const [checkoutButtonDisabled, setCheckoutButtonDisabled] = useState(true);
  const { consoleState } = useContext(LocationContext);
  const [storeId] = useState(consoleState?.state?.globalFilters?.region?.selected[3]);
  const cartAPI = getCartAPI(consoleState);
  const toast = useToast();
  const navigate = useNavigate();

  const fetchData = async (state, page) => {
    try {
      const res = await cartAPI.getCart({
        store_id: storeId,
        page_no: page,
        page_count: 20,
        sort: {
          field: state.sort.dataIndex || 'quantity',
          order: state.sort.order || 'desc'
        },
        filters: []
      });

      setCartValue(res.data?.total_cart_value);
      setCartCoverageByValue((res.data?.cart_coverage_by_value * 100).toFixed(2));
      setCartWidth(res.data?.total_cart_width);
      setCartCoverageByItems((res.data?.cart_coverage_by_items * 100).toFixed(2));
      if (res.data?.items.length > 0) setCheckoutButtonDisabled(false);

      return {
        data: res.data?.items.map((x) => ({ ...x, cart_mode: 'disabled' })) || [],
        totalRecords: res.data?.items?.length || 0
      };
    } catch (e) {
      return { data: [], totalRecords: 0 };
    }
  };

  const ElementForCartColumn = ({ row, setRow, value }) => {
    const [_value, _setValue] = useState(value);
    // const _cartStatus = row.cart == 0 ? ''
    return (
      <HStack>
        <Input
          w="100px"
          type="number"
          h="40px"
          border="1px solid #dddddd"
          borderRadius={'5px'}
          padding="0px 5px"
          value={_value}
          onChange={(e) => {
            _setValue(e.target.value);
            setRow({ ...row, cart: e.target.value });
          }}
          disabled={row.cart_mode === 'disabled'}
        />
        <Flex gap={'5px'}>
          {row.update_button_loading ? (
            <Spinner />
          ) : (
            <IconButton
              variant={row.cart_mode === 'disabled' ? 'outline' : 'solid'}
              icon={row.cart_mode === 'disabled' ? <EditIcon /> : <CheckIcon />}
              style={{
                background: row.cart_mode !== 'disabled' ? chakratheme.colors.success.dark : '',
                // padding: '10px 10px',
                borderRadius: '8px',
                color: row.cart_mode !== 'disabled' ? 'white' : 'black',
                fontWeight: '400'
              }}
              onClick={
                row.cart_mode !== 'disabled'
                  ? async () => {
                      try {
                        const data = {
                          quantity: row.cart,
                          store_id: storeId,
                          product_id: row.product_id
                        };
                        setRow({ ...row, update_button_loading: true });
                        const res = await cartAPI.addToCart(data);
                        setRow({
                          ...row,
                          update_button_loading: false,
                          cart_mode: 'disabled'
                        });
                        console.log(res.data);
                      } catch (e) {
                        setRow({
                          ...row,
                          update_button_loading: false,
                          cart_mode: 'disabled'
                        });
                        console.log(e);
                      }
                    }
                  : () => {
                      setRow({ ...row, cart_mode: 'enabled' });
                    }
              }></IconButton>
          )}
          <IconButton
            visibility={
              row.cart_mode === 'disabled' || row.update_button_loading ? 'hidden' : 'visible'
            }
            icon={<CloseIcon />}
            style={{
              backgroundColor: chakratheme.colors.error.dark,
              color: 'white'
            }}
            onClick={() => setRow({ ...row, cart_mode: 'disabled' })}></IconButton>
        </Flex>
      </HStack>
    );
  };

  const handlePlaceOrder = async () => {
    try {
      const res = await cartAPI.placeOrder(storeId);
      if (res.status === 200 || res.status === 201) {
        toast({
          title: 'Order Placed.',
          description: 'Order placed successfully',
          status: 'success',
          duration: 3000,
          isClosable: true
        });
        return res.data['order_id'];
      }
    } catch (e) {
      toast({
        title: 'Failed.',
        description: 'Failed to place order',
        status: 'error',
        duration: 3000,
        isClosable: true
      });
    }
  };

  const cards = [
    {
      name: 'Cart Value',
      ext: '₹',
      value: cartValue,
      from: 12381237,
      color: chakratheme.colors.green.main,
      coverage: cartCoverageByValue,
      text: 'Total value of products in cart'
    },
    {
      name: 'Cart Width',
      ext: '',
      value: cartWidth,
      from: 12337,
      color: chakratheme.colors.orange,
      coverage: cartCoverageByItems,
      text: 'Total Count of products in cart'
    }
  ];

  const formatInternationalStandard = (num) => {
    // remove decimal from number
    if (num > 0) {
      const numStr = num.toString().split('.')[0];
      // add commas to number
      return numStr.replace(/(\d)(?=(\d{3})+(?!\d))/g, '$1,');
    } else {
      return num;
    }
  };

  const config = {
    maxHeight: '600px',
    rows: {
      rowDatakey: 'product_id'
    },
    columns: {
      headers: [
        // {
        //   title: 'Inventory Status',
        //   id: 'status',
        //   dataIndex: 'status_label',
        //   colSpan: 1,
        //   sort: {
        //     allow: true
        //   },
        //   transformer: ({ value }) => {
        //     const statusToBgColor = {
        //       '0_new': '#caddfc',
        //       '9_excess': '#f7cfb5',
        //       '1_replenish': '#fccbc7',
        //       '2_no_replenishment': '#c3dbca'
        //     };
        //     const statusToColor = {
        //       '0_new': '#4287f5',
        //       '9_excess': '#Dd6A1F',
        //       '1_replenish': '#eb4034',
        //       '2_no_replenishment': '#32a852'
        //     };
        //     const statusToName = {
        //       '0_new': 'New',
        //       '9_excess': 'Excess',
        //       '1_replenish': 'Low Stock',
        //       '2_no_replenishment': 'Optimal'
        //     };
        //     const statusToIcon = {
        //       '0_new': NewReleases,
        //       '9_excess': RemoveShoppingCart,
        //       '1_replenish': ReportProblem,
        //       '2_no_replenishment': Check
        //     };
        //     const Icon = statusToIcon[value];
        //     return (
        //       <Chip
        //         icon={
        //           <Icon
        //             style={{
        //               color: statusToColor[value],
        //               fontSize: '14px'
        //             }}
        //           />
        //         }
        //         key={value}
        //         label={statusToName[value]}
        //         style={{
        //           fontWeight: 'bold',
        //           backgroundColor: statusToBgColor[value],
        //           color: statusToColor[value]
        //         }}
        //         size="small"
        //       />
        //     );
        //   },
        //   filters: {
        //     filterType: 'discrete',
        //     filterID: 'status_label',
        //     discrete: {
        //       multiple: true,
        //       options: [
        //         { label: 'New', value: '0_new' },
        //         { label: 'Excess', value: '9_excess' },
        //         { label: 'Low Stock', value: '1_replenish' },
        //         { label: 'Optimal', value: '2_no_replenishment' }
        //       ],
        //       optionTransformer: ({ value }) => {
        //         const statusToBgColor = {
        //           '0_new': '#caddfc',
        //           '9_excess': '#f7cfb5',
        //           '1_replenish': '#fccbc7',
        //           '2_no_replenishment': '#c3dbca'
        //         };
        //         const statusToColor = {
        //           '0_new': '#4287f5',
        //           '9_excess': '#Dd6A1F',
        //           '1_replenish': '#eb4034',
        //           '2_no_replenishment': '#32a852'
        //         };
        //         const statusToName = {
        //           '0_new': 'New',
        //           '9_excess': 'Excess',
        //           '1_replenish': 'Low Stock',
        //           '2_no_replenishment': 'Optimal'
        //         };
        //         const statusToIcon = {
        //           '0_new': NewReleases,
        //           '9_excess': RemoveShoppingCart,
        //           '1_replenish': ReportProblem,
        //           '2_no_replenishment': Check
        //         };
        //         const Icon = statusToIcon[value];
        //         return (
        //           <Chip
        //             icon={
        //               <Icon
        //                 style={{
        //                   color: statusToColor[value],
        //                   fontSize: '14px'
        //                 }}
        //               />
        //             }
        //             key={value}
        //             label={statusToName[value]}
        //             style={{
        //               fontWeight: 'bold',
        //               backgroundColor: statusToBgColor[value],
        //               color: statusToColor[value]
        //             }}
        //             size="small"
        //           />
        //         );
        //       }
        //     }
        //   }
        // },
        {
          title: 'Product ID',
          id: 'product_id',
          dataIndex: 'product_id',
          colSpan: 1
        },
        {
          title: 'Name',
          sort: {
            allow: true
          },
          id: 'product_name',
          dataIndex: 'product_name',
          colSpan: 1,
          filters: {
            filterType: 'search',
            filterID: 'product_name'
          }
        },
        {
          title: 'Molecule',
          sort: {
            allow: true
          },
          dataIndex: 'description',
          colSpan: 1,
          filters: {
            filterType: 'search',
            filterID: 'description'
          }
        },
        {
          title: 'SBU',
          sort: {
            allow: true
          },
          id: 'L0',
          dataIndex: 'l0',
          colSpan: 1
        },
        {
          title: 'Segment',
          id: 'L3',
          dataIndex: 'l3',
          colSpan: 1
        },
        {
          title: `Retail Price`,
          id: 'price',
          dataIndex: 'price',
          colSpan: 1,
          filters: {
            filterType: 'range',
            filterID: 'price',
            range: {
              defaultMin: 0,
              defaultMax: 10000
            }
          }
        },
        {
          title: 'Existing Inventory',
          id: 'current_inventory',
          dataIndex: 'stock_quantity',
          colSpan: 1,
          filters: {
            filterType: 'range',
            filterID: 'current_inventory',
            range: {
              defaultMin: 0,
              defaultMax: 1000
            }
          }
        },
        {
          title: 'Order trigger qty',
          id: 'order_trigger_qty',
          colSpan: 1,
          dataIndex: 'min_qty'
        },
        {
          title: 'Max stocked qty',
          id: 'max_stocked_qty',
          colSpan: 1,
          dataIndex: 'max_qty'
        },
        // {
        //   title: 'Recommended Replenishment',
        //   id: 'recommended_replenishment',
        //   dataIndex: 'minimum_replenishment',
        //   colSpan: 1,
        //   cellBackground: ({ row }) => {
        //     const statusToBgColor = {
        //       '0_new': '#caddfc',
        //       '9_excess': '#f7cfb5',
        //       '1_replenish': '#fccbc7',
        //       '2_no_replenishment': '#c3dbca'
        //     };
        //     return statusToBgColor[row['status_label']];
        //   },
        //   transformer: ({ value, row }) => {
        //     const statusToBgColor = {
        //       '0_new': '#caddfc',
        //       '9_excess': '#f7cfb5',
        //       '1_replenish': '#fccbc7',
        //       '2_no_replenishment': '#c3dbca'
        //     };
        //     const statusToColor = {
        //       '0_new': '#4287f5',
        //       '9_excess': '#Dd6A1F',
        //       '1_replenish': '#eb4034',
        //       '2_no_replenishment': '#32a852'
        //     };

        //     const statusToIcon = {
        //       '0_new': NewReleases,
        //       '9_excess': RemoveShoppingCart,
        //       '1_replenish': ReportProblem,
        //       '2_no_replenishment': Check
        //     };
        //     const Icon = statusToIcon[row['status_label']];
        //     return (
        //       <Flex
        //         h="100%"
        //         p="5px 20px"
        //         bg={statusToBgColor[row['status_label']]}
        //         alignItems={'center'}
        //         gap="5px"
        //         color={statusToColor[row['status_label']]}>
        //         <Icon style={{ fontSize: '12px' }} />
        //         {value}
        //       </Flex>
        //     );
        //   }
        // },
        {
          title: 'Cart',
          dataIndex: 'quantity',
          colSpan: 1,
          transformer: ({ value, row, setRow }) => {
            return <ElementForCartColumn row={row} setRow={setRow} value={value} />;
          }
        }
        // {
        //   title: 'Order Status',
        //   dataIndex: 'order_status',
        //   colSpan: 1,
        //   transformer: ({ value }) => {
        //     if (!value) return null;
        //     const { statusToBgColor, statusToColor, statusToIcon } = statusColors;
        //     const valueToKey = {
        //       progress: 'partial',
        //       notplaced: 'pending',
        //       fulfilled: 'done'
        //     };
        //     const valueToLabel = {
        //       progress: 'In Progress',
        //       notplaced: 'Not Placed',
        //       fulfilled: 'Fulfilled'
        //     };
        //     const _key = valueToKey[value];
        //     const Icon = statusToIcon[_key];
        //     return (
        //       <Chip
        //         icon={
        //           <Icon
        //             style={{
        //               color: statusToColor[_key],
        //               fontSize: '14px'
        //             }}
        //           />
        //         }
        //         label={valueToLabel[value]}
        //         style={{
        //           fontWeight: 'bold',
        //           backgroundColor: statusToBgColor[_key],
        //           color: statusToColor[_key]
        //         }}
        //         size="small"
        //       />
        //     );
        //   }
        // }
      ],
      groups: {
        allowGroups: true,
        groups: [
          {
            name: 'Product Details',
            columns: ['Product ID', 'Name', 'Molecule', 'Retail Price'],
            collapsible: true,
            defaultCollapsed: true,
            collapsedName: 'Summary',
            collapsedTransformer: ({ row }) => {
              return (
                <Flex direction="column" gap="5px" w="100%">
                  <Text fontWeight={'bold'}>{row['product_id']}</Text>
                  <Text
                    w="100%"
                    style={{
                      wordBreak: 'break-word !important',
                      whiteSpace: 'normal'
                    }}>
                    {row['product_name']}
                  </Text>
                </Flex>
              );
            }
          },
          {
            name: 'Predictions',
            columns: ['Order trigger qty', 'Max stocked qty']
            // collapsible: true,
            // collapsedName: 'Summary'
          }
        ]
      },
      unhideableColumns: ['Cart', 'Order Status', 'Product ID'],
      defaultHiddenColumns: ['Inventory Status', 'SBU', 'Segment']
    },
    pagination: {
      infiniteScroll: false,
      allowPagination: true,
      defaultPageNumber: 1,
      defaultPageSize: 20,
      defaultFetchSize: 100,
      pageSizeOptions: [10, 20, 50, 100],
      fetch: fetchData
    }
  };
  const { state: tableState, setState: setTableState } = useXTableState(config);

  return (
    <ChakraProvider theme={theme}>
      <Flex
        direction="column"
        alignItems="flex-start"
        justifyContent="center"
        // width="100%"
        style={{ padding: '50px 20px 20px 20px' }}>
        <Flex direction="column" id="overview">
          <Text
            style={{
              fontSize: '22px',
              fontFamily: 'Poppins',
              fontWeight: 'bold',
              marginTop: '0px'
            }}>
            Cart
          </Text>
          <Box
            w="50px"
            h="5px"
            bg={`${chakratheme.colors.primary.main}`}
            borderRadius="3px"
            mt={2}
          />
        </Flex>
        <Text
          mt={3}
          style={{
            color: `${chakratheme.colors.black[400]}`,
            fontSize: '13px',
            fontFamily: 'sans-serif'
          }}>
          Items added for the checkout will appear here.
        </Text>
        <Flex
          fontFamily={'Hanken Grotesk'}
          gap="20px"
          direction={'row'}
          justifyContent={'flex-start'}
          // w={'100%'}
          alignItems={'flex-start'}
          marginTop={'20px'}
          marginBottom={'20px'}>
          <Flex
            w="400px"
            direction="column"
            borderRadius={'20px'}
            style={{
              boxShadow: `${chakratheme.colors.shadow} 0px 0px 20px 0px`,
              margin: '0px 0px'
            }}>
            <Text
              fontWeight="bold"
              color={'black'}
              padding={'20px'}
              paddingBottom={'5px'}
              style={{
                fontFamily: 'Hanken Grotesk'
              }}>
              Impact Comparison
            </Text>
            <Text
              color={'gray'}
              pl="20px"
              fontSize="12px"
              style={{
                fontFamily: 'Hanken Grotesk'
              }}>
              Impact the products in cart have on the overall sales.
            </Text>
            <ProgressChart height={'300px'} />
          </Flex>
          <Flex direction="column" gap="20px">
            {cards.map((card) => {
              return (
                <Flex
                  h="45%"
                  key={card}
                  // w="24%"
                  style={{
                    backgroundColor: 'white',
                    color: 'black',
                    boxShadow: `${chakratheme.colors.shadow} 0px 0px 20px 0px`,
                    padding: '20px',
                    borderRadius: '20px',
                    fontFamily: 'Hanken Grotesk'
                  }}>
                  <Flex gap="20px" w="100%">
                    <Flex direction="column">
                      <Text fontWeight={'bold'} mb="5px">
                        {card.name}
                      </Text>
                      <Text
                        color={'gray'}
                        mb="20px"
                        fontSize="12px"
                        style={{
                          fontFamily: 'Hanken Grotesk'
                        }}>
                        {card.text}
                      </Text>
                      <Flex alignItems={'center'} wrap="wrap">
                        <Text fontSize={'40px'}>
                          {
                            card.ext // add currency symbol
                          }
                          {formatInternationalStandard(card.value)}
                        </Text>
                      </Flex>
                    </Flex>
                    <Spacer />
                    <CircularProgress
                      value={card.coverage}
                      size="100px"
                      thickness="4px"
                      color={card.color}>
                      <CircularProgressLabel my="-20px" color={card.color}>
                        {card.coverage}%
                      </CircularProgressLabel>
                      <CircularProgressLabel my="0px" fontSize="10px" color={card.color}>
                        Coverage
                      </CircularProgressLabel>
                    </CircularProgress>
                  </Flex>
                </Flex>
              );
            })}
          </Flex>
          <Flex
            flex="1 1 auto"
            h="100%"
            direction="column"
            style={{
              padding: '20px',
              borderRadius: '20px',
              boxShadow: `${chakratheme.colors.shadow} 0px 0px 20px 0px`
            }}>
            <Text
              fontWeight="bold"
              color={'black'}
              paddingBottom={'5px'}
              style={{
                fontFamily: 'Hanken Grotesk'
              }}>
              Invoice
            </Text>
            <Flex gap="10px">
              {consoleState.state.globalFilters['region'].selected.map((v, i) => {
                return (
                  <Flex key={i} gap={'10px'}>
                    <Input
                      style={{
                        padding: '10px 20px',
                        borderRadius: '5px',
                        color: '#777777'
                        // border: '1px solid #e0e0e0'
                      }}
                      maxWidth="100px"
                      placeholder=""
                      value={v}
                      isDisabled
                    />
                  </Flex>
                );
              })}
            </Flex>
            <Flex direction="column" w="100%" gap="5px" mt="10px">
              <Flex w="100%" color="gray">
                Subtotal
                <Spacer /> {Number(cartValue).toFixed(2)}
              </Flex>
              <Flex w="100%" color="gray">
                Taxes <Spacer />
                0.0
              </Flex>
              <Flex w="100%" fontWeight={'bold'}>
                Total <Spacer />
                {Number(cartValue).toFixed(2)}
              </Flex>
            </Flex>
            <Flex direction="row" w="100%" gap="5px" mt="20px">
              <Spacer />
              <Button
                style={{
                  backgroundColor: chakratheme.colors.green.light,
                  color: chakratheme.colors.green.main,
                  padding: '10px 20px',
                  borderRadius: '10px',
                  fontWeight: 'bold'
                }}
                isDisabled={checkoutButtonDisabled}
                onClick={async () => {
                  await handlePlaceOrder(storeId);
                  navigate(`/orders`);
                }}
                leftIcon={
                  <ExpandCircleDown
                    style={{
                      transform: 'rotate(270deg)',
                      color: chakratheme.colors.green.main
                    }}
                  />
                }>
                Checkout
              </Button>
            </Flex>
          </Flex>
        </Flex>
        {consoleState.state.features.assortmentTable ? (
          <Box
            w="100%"
            style={{
              borderRadius: '20px',
              boxShadow: `${chakratheme.colors.shadow} 0px 0px 20px 0px`,
              padding: '20px',
              marginTop: '10px'
            }}>
            <Flex
              w="100%"
              justifyContent="space-between"
              alignItems={'center'}
              // marginTop="10px"
              fontFamily={'Poppins'}>
              <Box flex="7">
                <Text mb={0} fontWeight={'bold'} fontSize="15px" textAlign="left">
                  Cart
                </Text>
              </Box>
            </Flex>

            <XTable
              state={tableState}
              setState={setTableState}
              config={config}
              style={{ fontFamily: 'Hanken Grotesk' }}
              hideFilters={true}
            />
          </Box>
        ) : null}
      </Flex>
    </ChakraProvider>
  );
};

export default Cart;
