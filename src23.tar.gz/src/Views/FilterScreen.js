import { Flex, Spacer, Text } from '@chakra-ui/layout';
import { IconButton, Image, useTheme } from '@chakra-ui/react';
import { Close, CloseFullscreen, OpenInFull, PushPin } from '@mui/icons-material';
import CSV2 from '../Static/csv2.png';
import Zone from '../Static/zone.png';
import State from '../Static/state.png';
import City from '../Static/city.png';
import Branch from '../Static/store.png';
import NestedFilters from '../components/NestedFilters';
import L0 from '../Static/L0.png';
import L1 from '../Static/L1.png';
import L2 from '../Static/L2.png';
import L3 from '../Static/L3.png';
import brand from '../Static/brand.png';
import manufacturer from '../Static/manufacturer.png';
import React, { useEffect, useState } from 'react';
import { Tooltip } from '@mui/material';
import axios from 'axios';

const FilterScreen = (props) => {
  const chakratheme = useTheme();
  const [minimized, setMinimized] = useState(false);

  const anySelected =
    props.selectedRegions?.some((region) => region !== '' && region != null) ||
    props.selectedCategories?.some((category) => category !== '' && category != null) ||
    props.selectedBrands?.some((brand) => brand !== '' && brand != null);

  const [filterCount, setFilterCount] = React.useState();
  const [regions_nested, setRegionsNested] = React.useState([]);
  const [categoryNested, setCategoryNested] = React.useState([]);
  const [brandData, setBrandData] = React.useState([]);
  const fetchFilters = () => {
    const formData = new FormData();
    const lastIndexNonNull = props.lastIndex(props.selectedRegions);

    if (lastIndexNonNull != -1) formData.append('region_type', props.levelNames[lastIndexNonNull]);
    else formData.append('region_type', null);
    if (lastIndexNonNull != -1)
      formData.append('region_name', props.selectedRegions[lastIndexNonNull]);
    else formData.append('region_name', null);
    if (props.selectedBrands[0]) formData.append('mfac_name', props.selectedBrands[0]);
    if (props.selectedBrands[1]) formData.append('brand_name', props.selectedBrands[1]);
    if (props.selectedCategories[0]) formData.append('L0', props.selectedCategories[0]);
    if (props.selectedCategories[1]) formData.append('L1', props.selectedCategories[1]);
    if (props.selectedCategories[2]) formData.append('L2', props.selectedCategories[2]);
    if (props.selectedCategories[3]) formData.append('L3', props.selectedCategories[3]);
    let configStat = {
      method: 'post',
      url: `${process.env.REACT_APP_API_BASE_URL}/fetch-filters`,
      data: formData
    };
    axios(configStat)
      .then(async (response) => {
        setRegionsNested(response.data.location);
        setCategoryNested(response.data.category);
        setBrandData(response.data.mfac);
        setFilterCount(response.data.filters_count);
      })
      .catch(function (e) {
        if (axios.isCancel(e)) {
          console.log('Request canceled', e.message);
        } else {
          console.log('error');
        }
      });
  };
  useEffect(() => {
    fetchFilters();
  }, [props.selectedRegions, props.selectedBrands, props.selectedCategories]);
  return (
    <Flex
      // zIndex={99999}
      direction="column"
      w={props.width ? props.width : '100%'}
      p={5}
      borderRadius={'20px'}
      style={{
        boxShadow:
          props.pinFilters !== undefined ? `0 0 40px 0 ${chakratheme.colors.shadow}` : 'none'
      }}
      alignItems={'flex-start'}>
      <Flex w="100%" justifyContent={'center'} alignItems="center">
        {minimized ? (
          <Flex direction="column">
            <Flex>
              {props.levelNames.map((levelName, index) => {
                return props.selectedRegions[index] ? (
                  <Text marginLeft={'10px'}>
                    <span style={{ fontWeight: 'bold', marginLeft: '3px' }}>{levelName}</span>{' '}
                    {props.selectedRegions[index]}
                  </Text>
                ) : null;
              })}
            </Flex>
            <Flex>
              {props.categoryLevelNames.map((levelName, index) => {
                return props.selectedCategories[index] ? (
                  <Text marginLeft={'10px'}>
                    <span style={{ fontWeight: 'bold', marginLeft: '3px' }}>{levelName}</span>{' '}
                    {props.selectedCategories[index]}
                  </Text>
                ) : null;
              })}
            </Flex>
            <Flex>
              {props.brandLevelNames.map((levelName, index) => {
                return props.selectedBrands[index] ? (
                  <Text marginLeft={'10px'}>
                    <span style={{ fontWeight: 'bold', marginLeft: '3px' }}>{levelName}</span>{' '}
                    {props.selectedBrands[index]}
                  </Text>
                ) : null;
              })}
            </Flex>
            {props.uploadedFile ? (
              <Flex
                alignItems={'center'}
                ml="10px"
                pt="5px"
                pb="5px"
                pl="20px"
                pr="20px"
                bgColor={`${chakratheme.colors.gray.lighter}`}
                borderRadius={'30px'}>
                <Image w="30px" h="30px" src={CSV2} />
                <Text
                  ml="3"
                  color="blue"
                  cursor="pointer"
                  onClick={() => {
                    // window.open(props.uploadedFile.fileUrl);
                    // open selected csv file in windows
                    window.open(URL.createObjectURL(props.uploadedFile));
                  }}>
                  {props.uploadedFile.name}
                </Text>
                <Spacer />

                <IconButton
                  ml={2}
                  color={`${chakratheme.colors.black[400]}`}
                  icon={<Close style={{ transform: 'scale(0.8)' }} />}
                  onClick={() => {
                    props.setUploadedFile(null);
                  }}></IconButton>
              </Flex>
            ) : null}
          </Flex>
        ) : null}
        {minimized & !anySelected ? (
          <Text
            fontWeight={800}
            color={`${chakratheme.colors.gray.light}`}
            fontSize="18px"
            textAlign="left">
            No Filters Selected. Expand to select filters.
          </Text>
        ) : null}
        <Spacer />
        <Tooltip title={minimized ? 'Maximize' : 'Minimize'} arrow>
          <IconButton
            icon={
              minimized ? (
                <OpenInFull sx={{ fontSize: '22px' }} />
              ) : (
                <CloseFullscreen sx={{ fontSize: '22px' }} />
              )
            }
            style={{
              backgroundColor: `${chakratheme.colors.primary.main}`,
              color: 'white',
              padding: '10px',
              borderRadius: '50%',
              marginBottom: '5px',
              boxShadow: `0 0 20px 0 ${chakratheme.colors.shadow}`,
              width: '35px',
              height: '35px'
            }}
            onClick={() => {
              setMinimized(!minimized);
            }}></IconButton>
        </Tooltip>
        {props.pinFilters != null ? (
          <Tooltip
            title={`${props.pinFilters ? 'Unpin' : 'Pin'} the Filters ${
              props.pinFilters ? 'from' : 'to'
            } the top`}
            arrow>
            <IconButton
              icon={<PushPin sx={{ fontSize: '22px' }} />}
              style={{
                backgroundColor: props.pinFilters ? `${chakratheme.colors.primary.main}` : 'white',
                color: props.pinFilters ? 'white' : `${chakratheme.colors.primary.main}`,
                padding: '10px',
                borderRadius: '50%',
                marginBottom: '5px',
                marginLeft: '10px',
                boxShadow: `0 0 20px 0 ${chakratheme.colors.shadow}`,
                width: '35px',
                height: '35px'
              }}
              onClick={() => {
                props.setPinFilters(!props.pinFilters);
              }}></IconButton>
          </Tooltip>
        ) : null}
      </Flex>
      {minimized ? null : (
        <Flex w="100%" direction="column">
          <Flex w="100%">
            <Flex w={props.nomfac ? '100%' : '66%'} direction={'column'}>
              <Text fontWeight={800} fontSize="14px" textAlign="left" mb={2}>
                Select Region
              </Text>
              <Flex
                w="100%"
                alignItems={'center'}
                h="100%"
                style={{
                  borderRadius: '20px',
                  boxShadow: `${chakratheme.colors.shadow} 0px 0px 40px 0px`
                }}
                mb="5">
                <NestedFilters
                  nonedit={props.nonedit}
                  nestedData={regions_nested}
                  type="region"
                  levelNames={props.levelNames}
                  selectedItems={props.selectedRegions}
                  setSelectedItems={props.setSelectedRegions}
                  onBranchSelected={props.handleSelectedBranch}
                  icons={{
                    Zone: Zone,
                    State: State,
                    City: City,
                    Branch: Branch
                  }}></NestedFilters>
              </Flex>
            </Flex>
            {!props.nomfac && (
              <Flex w="33%" direction="column">
                <Text ml={4} fontWeight={800} fontSize="14px" textAlign="left" mb={2}>
                  Select Manufacturer/Brand
                </Text>
                <Flex
                  alignItems={'center'}
                  w="100%"
                  ml={3}
                  style={{
                    borderRadius: '20px',

                    boxShadow: `${chakratheme.colors.shadow} 0px 0px 20px 10px`
                  }}>
                  <NestedFilters
                    nestedData={brandData}
                    levelNames={props.brandLevelNames}
                    nonedit={props.nonedit}
                    type="brand"
                    selectedItems={props.selectedBrands}
                    setSelectedItems={props.setSelectedBrands}
                    icons={{
                      Manufacturer: manufacturer,
                      Brand: brand
                    }}></NestedFilters>
                </Flex>
              </Flex>
            )}
          </Flex>
          {props.nonedit ? (
            <Text fontWeight={800} fontSize="14px" textAlign="left" mb={2}>
              Selected Category
            </Text>
          ) : (
            <Text fontWeight={800} fontSize="14px" textAlign="left" mb={2}>
              Select Category
            </Text>
          )}
          <Flex
            w="100%"
            alignItems={'center'}
            h="100%"
            style={{
              borderRadius: '20px',
              boxShadow: `${chakratheme.colors.shadow} 0px 0px 40px 0px`
            }}
            mb="5">
            <NestedFilters
              nonedit={props.nonedit}
              nestedData={categoryNested}
              levelNames={props.categoryLevelNames}
              selectedItems={props.selectedCategories}
              filterCount={filterCount}
              type="category"
              setSelectedItems={props.setSelectedCategories}
              icons={{
                L0: L0,
                L1: L1,
                L2: L2,
                L3: L3
              }}></NestedFilters>
          </Flex>
        </Flex>
      )}
      {minimized ? null : (
        <Flex w="100%">
          <Spacer />
          {props.uploadedFile ? (
            <Flex
              alignItems={'center'}
              ml="10px"
              mr="10px"
              pl="20px"
              pr="20px"
              bgColor={`${chakratheme.colors.gray.lighter}`}
              borderRadius={'30px'}>
              <Image w="30px" h="30px" src={CSV2} />
              <Text
                ml="3"
                color="blue"
                cursor="pointer"
                onClick={() => {
                  window.open(URL.createObjectURL(props.uploadedFile));
                }}>
                {props.uploadedFile.name}
              </Text>

              <IconButton
                ml={2}
                color={`${chakratheme.colors.black[400]}`}
                icon={<Close style={{ transform: 'scale(0.8)' }} />}
                onClick={() => {
                  props.setUploadedFile(null);
                  props.setCustomData([]);
                  props.setLoad(false);
                }}></IconButton>
            </Flex>
          ) : null}
        </Flex>
      )}
    </Flex>
  );
};
export default FilterScreen;
