import { Flex, Spacer, Text, useTheme } from '@chakra-ui/layout';
import { Button, IconButton, Image } from '@chakra-ui/react';
import { ArrowRightAlt, Close, UploadFile, UploadFileSharp } from '@mui/icons-material';
import { FileUploader } from 'react-drag-drop-files';
import CSV2 from '../Static/csv2.png';
import { CopyBlock, atomOneDark } from 'react-code-blocks';
import Zone from '../Static/zone.png';
import Branch from '../Static/store.png';
import NestedFilters from '../components/NestedFilters';
import L0 from '../Static/L0.png';
import L1 from '../Static/L1.png';
import L2 from '../Static/L2.png';
import L3 from '../Static/L3.png';
import CSVLogo from '../Static/csv.png';
import { useState } from 'react';
import { Box, Modal, Tooltip } from '@mui/material';
const jsx = `
{
    "sap_id":Number (required),
    "br_code":String (required),
    "max_Qty":Number (required),
    "min_Qty":Number (required)
}
`;

const HomeFilters = (props) => {
  const minimized = false;
  const [csvUploadOpen, setCsvUploadOpen] = useState(false);
  const chakratheme = useTheme();

  return (
    <Flex
      direction="column"
      w={props.width ? props.width : '100%'}
      py={5}
      ml={3}
      px={1}
      borderRadius={'20px'}
      alignItems={'flex-start'}>
      <Flex w="100%" justifyContent={'center'} alignItems="center">
        {minimized ? (
          <Flex direction="column">
            <Flex>
              {props.levelNames.map((levelName, index) => {
                return props.selectedRegions[index] ? (
                  <Text marginLeft={'10px'}>
                    <span style={{ fontWeight: 'bold', marginLeft: '3px' }}>{levelName}</span>{' '}
                    {props.selectedRegions[index]}
                  </Text>
                ) : null;
              })}
            </Flex>
            <Flex>
              {props.categoryLevelNames.map((levelName, index) => {
                return props.selectedCategories[index] ? (
                  <Text marginLeft={'10px'}>
                    <span style={{ fontWeight: 'bold', marginLeft: '3px' }}>{levelName}</span>{' '}
                    {props.selectedCategories[index]}
                  </Text>
                ) : null;
              })}
            </Flex>
            {props.uploadedFile ? (
              <Flex
                alignItems={'center'}
                ml="10px"
                pt="5px"
                pb="5px"
                pl="20px"
                pr="20px"
                bgColor={`${chakratheme.colors.gray.lighter}`}
                borderRadius={'30px'}>
                <Image w="30px" h="30px" src={CSV2} />
                <Text
                  ml="3"
                  color="blue"
                  cursor="pointer"
                  onClick={() => {
                    // window.open(props.uploadedFile.fileUrl);
                    // open selected csv file in windows
                    window.open(URL.createObjectURL(props.uploadedFile));
                  }}>
                  {props.uploadedFile.name}
                </Text>
                <Spacer />

                <IconButton
                  ml={2}
                  color={`${chakratheme.colors.black[400]}`}
                  icon={<Close style={{ transform: 'scale(0.8)' }} />}
                  onClick={() => {
                    props.setUploadedFile(null);
                  }}></IconButton>
              </Flex>
            ) : null}
          </Flex>
        ) : null}
      </Flex>
      {minimized ? null : (
        <Flex w="100%" direction="column">
          <Text mt={2} fontWeight={800} fontSize="15px" textAlign="left" mb={2}>
            Select Category
          </Text>
          <Flex
            w="100%"
            alignItems={'center'}
            h="100%"
            style={{
              borderRadius: '20px',
              boxShadow: `${chakratheme.colors.shadow} 0px 0px 40px 0px`
            }}
            mb="5">
            <NestedFilters
              nestedData={props.categoryNested}
              levelNames={props.categoryLevelNames}
              selectedItems={props.selectedCategories}
              setSelectedItems={props.setSelectedCategories}
              type="homecategory"
              icons={{
                'Filter level': Zone,
                L0: L0,
                L1: L1,
                L2: L2,
                L3: L3,
                'Sap ID': Branch
              }}></NestedFilters>
          </Flex>
          <Text fontSize="13px" style={{ marginTop: '-10px' }} ml={5} color="grey">
            * Select filter-level to get industry-to-internal category gaps.
          </Text>
        </Flex>
      )}
      {minimized ? null : (
        <Flex w="100%">
          <Spacer />
          {props.uploadedFile ? (
            <Flex
              alignItems={'center'}
              ml="10px"
              mr="10px"
              pl="20px"
              pr="20px"
              bgColor={`${chakratheme.colors.gray.lighter}`}
              borderRadius={'30px'}>
              <Image w="30px" h="30px" src={CSV2} />
              <Text
                ml="3"
                color="blue"
                cursor="pointer"
                onClick={() => {
                  window.open(URL.createObjectURL(props.uploadedFile));
                }}>
                {props.uploadedFile.name}
              </Text>

              <IconButton
                ml={2}
                color={`${chakratheme.colors.black[400]}`}
                icon={<Close style={{ transform: 'scale(0.8)' }} />}
                onClick={() => {
                  props.setUploadedFile(null);
                  props.setCustomData([]);
                }}></IconButton>
            </Flex>
          ) : null}
          {props.flag && (
            <Tooltip title={'Upload CSV File'} arrow>
              <Button
                style={{
                  color: `${chakratheme.colors.primary.main}`,
                  backgroundColor: `${chakratheme.colors.primary.lighter}`,
                  borderRadius: '20px',
                  marginBottom: '5px',
                  boxShadow: `0 0 20px 0 ${chakratheme.colors.shadow}`,
                  fontWeight: 'bold',
                  padding: '10px 30px',
                  marginRight: '20px'
                }}
                onClick={() => {
                  setCsvUploadOpen(true);
                }}
                leftIcon={<UploadFile />}>
                Upload CSV
              </Button>
            </Tooltip>
          )}
          <Modal
            open={csvUploadOpen}
            onClose={() => {
              setCsvUploadOpen(false);
            }}
            aria-labelledby="modal-modal-title"
            aria-describedby="modal-modal-description">
            <Box
              sx={{
                position: 'absolute',
                top: '50%',
                left: '50%',
                transform: 'translate(-50%, -50%)',
                width: 800,
                height: 400,
                bgcolor: 'background.paper',
                boxShadow: 24,
                borderRadius: 3,
                padding: '20px 10px'
              }}>
              <Flex w="100%" mb="2px" justifyContent={'center'} alignItems={'center'}>
                <Spacer />
                <IconButton
                  mr="10px"
                  icon={<Close />}
                  onClick={() => {
                    setCsvUploadOpen(false);
                  }}
                  style={{
                    backgroundColor: `${chakratheme.colors.primary.main}`,
                    color: 'white',
                    padding: '10px',
                    borderRadius: '50%',
                    marginBottom: '5px',
                    boxShadow: `0 0 20px 0 ${chakratheme.colors.shadow}`
                  }}></IconButton>
              </Flex>
              <Flex direction="row" w="100%" h="65%">
                <Flex
                  flex="1"
                  h="100%"
                  alignItems={'center'}
                  justifyContent={'center'}
                  style={{
                    borderRight: `1px solid ${chakratheme.colors.gray.light}`
                  }}>
                  <FileUploader
                    multiple={false}
                    handleChange={(e) => {
                      props.setUploadedFile(e);
                    }}
                    name="file"
                    types={['csv']}
                    label="Upload or drop two CSV files here">
                    <Box
                      style={{
                        width: '300px',
                        height: '200px',
                        borderRadius: '20px',
                        backgroundColor: `${chakratheme.colors.gray.lighter}`,
                        border: `1px dashed ${chakratheme.colors.gray.light}`
                      }}>
                      <Flex
                        w="100%"
                        h="100%"
                        direction={'column'}
                        justifyContent={'center'}
                        alignItems={'center'}>
                        <Image src={CSVLogo} w="100px" />
                        <Text color={`${chakratheme.colors.gray.light}`} fontSize="13px">
                          Drag and Drop A CSV File
                        </Text>
                      </Flex>
                    </Box>
                  </FileUploader>
                </Flex>
                <Flex flex="1" h="100%" justifyContent={'center'} alignItems={'center'}>
                  <Box>
                    <CopyBlock
                      language={'json'}
                      showLineNumbers={false}
                      text={jsx}
                      theme={atomOneDark}
                    />
                    <Text
                      mt={2}
                      fontSize="14px"
                      color="gray.600"
                      fontStyle="italic"
                      fontWeight="medium"
                      lineHeight="1.4">
                      * Multiple store codes (br_code) can be uploaded.
                    </Text>
                  </Box>
                </Flex>
              </Flex>
              <Flex w="100%" justifyContent={'center'} alignItems={'center'}>
                <Button
                  mt={3}
                  style={{
                    backgroundColor:
                      props.uploadedFile == null
                        ? `${chakratheme.colors.gray.light}`
                        : `${chakratheme.colors.primary.main}`,
                    color: props.uploadedFile == null ? 'white' : 'white',
                    cursor: props.uploadedFile == null ? 'default' : 'pointer',
                    borderRadius: '20px',
                    marginBottom: '5px',
                    boxShadow: `0 0 20px 0 ${chakratheme.colors.shadow}`,
                    fontWeight: 'bold',
                    padding: '10px 30px'
                  }}
                  leftIcon={<UploadFileSharp />}
                  rightIcon={<ArrowRightAlt />}
                  onClick={() => {
                    setCsvUploadOpen(false);
                    props.fetchBulkData(props.uploadedFile);
                  }}
                  isDisabled={props.uploadedFile == null ? true : false}>
                  Append to current Assortment
                </Button>
                <Button
                  mt={3}
                  ml={3}
                  style={{
                    backgroundColor:
                      props.uploadedFile == null
                        ? `${chakratheme.colors.gray.light}`
                        : `${chakratheme.colors.primary.main}`,
                    color: props.uploadedFile == null ? 'white' : 'white',
                    cursor: props.uploadedFile == null ? 'default' : 'pointer',
                    borderRadius: '20px',
                    marginBottom: '5px',
                    boxShadow: `0 0 20px 0 ${chakratheme.colors.shadow}`,
                    fontWeight: 'bold',
                    padding: '10px 30px'
                  }}
                  leftIcon={<UploadFileSharp />}
                  rightIcon={<ArrowRightAlt />}
                  onClick={() => {
                    setCsvUploadOpen(false);
                    props.fetchBulkData(props.uploadedFile);
                  }}
                  isDisabled={props.uploadedFile == null ? true : false}>
                  Analysis of uploaded data
                </Button>
              </Flex>
              <Flex w="100%" justifyContent={'center'} alignItems={'center'}>
                {props.uploadedFile ? (
                  <Text
                    color="blue"
                    cursor="pointer"
                    onClick={() => {
                      // window.open(props.uploadedFile.fileUrl);
                      // open selected csv file in windows
                      window.open(URL.createObjectURL(props.uploadedFile));
                    }}>
                    {props.uploadedFile.name}
                  </Text>
                ) : (
                  <Text color={`${chakratheme.colors.gray.light}`}>
                    Selected File will appear here
                  </Text>
                )}
                {props.uploadedFile ? (
                  <IconButton
                    ml={2}
                    color={`${chakratheme.colors.black[400]}`}
                    icon={<Close style={{ transform: 'scale(0.8)' }} />}
                    onClick={() => {
                      props.setUploadedFile(null);
                    }}></IconButton>
                ) : null}
              </Flex>
            </Box>
          </Modal>
        </Flex>
      )}
    </Flex>
  );
};
export default HomeFilters;
