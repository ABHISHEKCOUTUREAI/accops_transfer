import React, { useState, useEffect, useContext } from 'react';
import { Card, CardHeader } from 'reactstrap';
import India from '@svg-maps/india';
import OpenInNewIcon from '@mui/icons-material/OpenInNew';
import { SVGMap } from 'react-svg-map';
import { useNavigate } from 'react-router-dom';
import { Tooltip } from '@mui/material';
import 'react-svg-map/lib/index.css';
import { Flex, ChakraProvider } from '@chakra-ui/react';
import theme from '../../theme';
import './IndiaMap.css';
import { formatNumber } from '../../Utils/formatNumberMillionBillion';
import { LocationContext } from '../../Contexts/LocationContext';
function MapChart({ chakratheme, ...props }) {
  // const chakratheme = useTheme();
  const { consoleState } = useContext(LocationContext);
  const [stateCode, setStateCode] = useState('jk');
  const [stateName, setStateName] = useState('');
  const [detail, setDetail] = useState({});

  const navigate = useNavigate();

  const [iconPosition, setIconPosition] = useState({ x: -100, y: -100 }); // Off-screen initially

  // Function to handle displaying the icon at the clicked state's position
  const showIconAtState = (clickedStateCode, event) => {
    const clickedStateData = props.statesData.find((data) => data.statecode === clickedStateCode);

    const clickedStateName = event.target.getAttribute('name');

    if (clickedStateData) {
      setStateCode(clickedStateCode);
      setStateName(clickedStateName);

      // Set icon position based on event coordinates
      setIconPosition({ x: event.pageX, y: event.pageY });
    }
  };

  const handleClick = () => {
    navigate(`/assortment-analysis`, {
      state: {
        stateName: stateName,
        zone: detail && detail.zone
      }
    });
  };

  function onLocationClick(event) {
    const clickedStateCode = event.target.id.toUpperCase();
    const clickedStateName = event.target.getAttribute('name');

    // Find the matching data based on the clicked state code
    const clickedStateData = props.statesData.find((data) => data.statecode === clickedStateCode);

    // Set detail to empty object if the clickedStateData is undefined
    const clickedDetail = clickedStateData || {};

    setStateCode(clickedStateCode);
    setStateName(clickedStateName);
    setDetail(clickedDetail);
    const element = document.getElementById(event.target.id);
    element.classList.add('svg-map__location');
    // element.class = 'svg-map__location';
    element.style.fill = null;

    showIconAtState(event.target.id.toUpperCase(), event);

    // navigate('/assortment/assortment-analysis');
  }

  // const formatNumber = (num) => {
  //   if (String(num).length <= 3) {
  //     return num;
  //   }
  //   if (String(num).length === 4 || String(num).length === 5) {
  //     return String(parseFloat((num / 1000).toFixed(2))) + 'K';
  //   } else if (String(num).length === 6 || String(num).length === 7) {
  //     return String(parseFloat((num / 100000).toFixed(2))) + 'Lk';
  //   } else {
  //     return String(parseFloat((num / 10000000).toFixed(2))) + 'Cr';
  //   }
  // };

  const [idIntensityMapping, setIdIntensityMapping] = useState({});

  function onLocationMouseOver(event) {
    const clickedStateCode = event.target.id.toUpperCase();
    const clickedStateName = event.target.getAttribute('name');

    // Find the matching data based on the clicked state code
    const clickedStateData = props.statesData.find((data) => data.statecode === clickedStateCode);

    // Set detail to empty object if the clickedStateData is undefined
    const clickedDetail = clickedStateData || {};

    setStateCode(clickedStateCode);
    setStateName(clickedStateName);
    setDetail(clickedDetail);
    const element = document.getElementById(event.target.id);
    if (element) {
      element.style.fill = `${chakratheme.colors.gray.light}`;
    }
    if (isHovered) {
      element.style.fill = `${chakratheme.colors.gray.light}`;
    }
  }

  function onLocationMouseOut(event) {
    const stateCodee = event.target.id.toLowerCase();
    const element = document.getElementById(stateCodee);

    if (element && props.selectedZone == null && props.selectedState == null) {
      // Retrieve the intensity from idIntensityMapping
      const intensity = idIntensityMapping[stateCodee];
      if (intensity || intensity === 0) {
        element.style.fill = `rgba(43, 181, 91, ${intensity})`;
      } else {
        element.style.fill = `rgb(179, 209, 255)`;
      }
    } else if (props.selectedZone) {
      const stateInSelectedZone = props.statesData.find(
        (state) => state.statecode.toLowerCase() === stateCodee && state.zone === props.selectedZone
      );

      // If the state belongs to the selected zone, fill it with the specified color
      if (stateInSelectedZone) {
        const intensity = idIntensityMapping[stateCodee];
        element.style.fill = `rgba(43, 181, 91 ${intensity})`;
      } else {
        // If not, fill it with white
        element.style.fill = 'white';
      }
      // element.style.fill = `rgb(179, 209, 255)`;
    } else {
      const stateInSelectedZone = props.statesData.find(
        (state) =>
          state.statecode.toLowerCase() === stateCodee && state.state === props.selectedState
      );

      // If the state belongs to the selected zone, fill it with the specified color
      if (stateInSelectedZone) {
        const intensity = idIntensityMapping[stateCodee];
        element.style.fill = `rgba(43, 181, 91, ${intensity})`;
      } else {
        // If not, fill it with white
        element.style.fill = 'white';
      }
    }
  }
  const revenues = props.statesData.map((state) => state.revenue);
  const highestRevenue = Math.max(...revenues);

  const changeColorOnClick = () => {
    const updatedMapping = {};

    props.statesData.forEach((state) => {
      const element = document.getElementById(state.statecode.toLowerCase());
      if (element) {
        const intensity = state.revenue / highestRevenue;
        element.style.fill = `rgba(43, 181, 91, ${intensity})`;
        updatedMapping[state.statecode.toLowerCase()] = intensity;
      }
    });

    // Update the state with the new mapping
    setIdIntensityMapping(updatedMapping);
  };
  useEffect(() => {
    // const interval = setInterval(waitForDOM, 100);
    // function waitForDOM() {
    const element = document.getElementById('or');
    if (element) {
      if (props?.statesData.length != 0) {
        // clearInterval(interval);
        changeColorOnClick();
      }
    }
    // }
  }, [props?.statesData]);

  useEffect(() => {
    if (props.selectedZone) {
      selectZone();
    } else {
      changeColorOnClick();
    }
  }, [props.selectedZone]);

  useEffect(() => {
    if (props.selectedState) {
      selectState();
    } else {
      if (props.selectedZone) {
        return;
      }
      changeColorOnClick();
    }
  }, [props.selectedState]);

  const selectZone = () => {
    const updatedMapping = {};

    props.statesData.forEach((state) => {
      const element = document.getElementById(state.statecode.toLowerCase());
      if (element) {
        const isSelectedZone = state.zone.toLowerCase() === props.selectedZone.toLowerCase();

        if (isSelectedZone) {
          const intensity = state.revenue / highestRevenue;
          element.style.fill = `rgba(43, 181, 91, ${intensity})`;
          updatedMapping[state.statecode.toLowerCase()] = intensity;
        } else {
          element.style.fill = 'white';
        }
        // updatedMapping[state.statecode.toLowerCase()] = isSelectedZone ? 1 : 0;
      }

      // if (element) {
      //   // Check if the state belongs to the selected zone
      //   const isSelectedZone = state.zone.toLowerCase() === props.selectedZone.toLowerCase();

      //   if (isSelectedZone) {
      //     // Highlight states belonging to the selected zone with a color
      //     element.style.fill = `rgb(179, 209, 255)`; // Replace with the desired color
      //   } else {
      //     // Fill the rest of the states with white
      //     element.style.fill = 'white';
      //   }

      //   // Update the mapping
      //   updatedMapping[state.statecode.toLowerCase()] = isSelectedZone ? 1 : 0;
      // }
    });

    // Update the state with the new mapping
    setIdIntensityMapping(updatedMapping);
  };

  const selectState = () => {
    const updatedMapping = {};

    props.statesData.forEach((state) => {
      const element = document.getElementById(state.statecode.toLowerCase());
      if (element) {
        const isSelectedZone = state.state.toLowerCase() === props.selectedState.toLowerCase();

        if (isSelectedZone) {
          const intensity = state.revenue / highestRevenue;
          element.style.fill = `rgba(43, 181, 91, ${intensity})`;
          updatedMapping[state.statecode.toLowerCase()] = intensity;
        } else {
          element.style.fill = 'white';
        }
        // updatedMapping[state.statecode.toLowerCase()] = isSelectedZone ? 1 : 0;
      }

      // if (element) {
      //   // Check if the state belongs to the selected zone
      //   const isSelectedZone = state.zone.toLowerCase() === props.selectedZone.toLowerCase();

      //   if (isSelectedZone) {
      //     // Highlight states belonging to the selected zone with a color
      //     element.style.fill = `rgb(179, 209, 255)`; // Replace with the desired color
      //   } else {
      //     // Fill the rest of the states with white
      //     element.style.fill = 'white';
      //   }

      //   // Update the mapping
      //   updatedMapping[state.statecode.toLowerCase()] = isSelectedZone ? 1 : 0;
      // }
    });

    // Update the state with the new mapping
    setIdIntensityMapping(updatedMapping);
  };

  const [isHovered, setIsHovered] = useState(false);

  return (
    <ChakraProvider theme={theme}>
      <>
        <div
          //  className="square"
          style={{
            position: 'absolute',
            marginLeft: '180px'
          }}>
          {stateCode && stateName && (
            <Card>
              <CardHeader style={{ fontSize: '0.75rem', marginLeft: '5px', padding: '5px' }}>
                <strong>{stateName}</strong>
              </CardHeader>
              <Flex
                mr={2}
                ml={2}
                style={{
                  // width: '50px',
                  // height: '20px',
                  color: `${chakratheme.colors.blue}`,
                  backgroundColor: `${chakratheme.colors.primary.lighter}`,
                  marginBottom: '10px',
                  padding: '5px 10px',
                  borderRadius: '20px',
                  fontWeight: 'bold',
                  fontSize: '13px'
                }}>
                Revenue -
                <span
                  style={{
                    fontSize: '13px',
                    fontWeight: 'bold',
                    marginLeft: '5px'
                  }}>
                  {`${consoleState.state.currency || '$'} ${formatNumber(Math.floor(detail.revenue))}`}
                </span>
              </Flex>
            </Card>
          )}
        </div>
        {/* <button onClick={changeColorOnClick}>Change Color</button> */}

        <SVGMap
          map={India}
          className="svg-map"
          // onLocationClick={(event) =>
          //   showIconAtState(event.target.id.toUpperCase(), event)
          // }
          onLocationClick={onLocationClick}
          // locationClassName=""
          // locationClassName={(location) =>
          //   highlightedStates.includes((location.id).toUpperCase()) ? "" : ""
          // }
          // locationClassName={(location) =>
          //   highlightedStates.includes(location.id) ? "highlighted" : ""
          // }
          onLocationMouseOut={onLocationMouseOut}
          onLocationMouseOver={onLocationMouseOver}
        />
        {iconPosition.x !== -100 && (
          <div
            style={{
              position: 'absolute',
              left: iconPosition.x,
              top: iconPosition.y,
              cursor: 'pointer',
              zIndex: 999
            }}
            onMouseEnter={() => setIsHovered(true)}
            onMouseLeave={() => setIsHovered(false)}
            onClick={() => {
              handleClick();
            }}>
            {/* Display your icon here */}
            {/* Replace this with your icon component */}
            <Tooltip title={'Go to detailed view'} arrow>
              <OpenInNewIcon
                style={{
                  color: 'white',
                  backgroundColor: 'black',
                  padding: '5px',
                  borderRadius: '50%'
                }}
                cursor={'pointer'}
                onClick={handleClick}
              />
            </Tooltip>

            {/* <span role="img" aria-label="Icon">
            // 📍
          </span> */}
          </div>
        )}
      </>
    </ChakraProvider>
  );
}

export default MapChart;
