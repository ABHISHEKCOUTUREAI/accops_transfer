import axios from 'axios';

export const newProductStats = (
  regionValue,
  regionName,
  selectedCategories,
  setNewProductsStat,
  consoleState
) => {
  const formDataStat = new FormData();
  formDataStat.append('region_type', regionName);
  formDataStat.append('region_name', regionValue);
  if (selectedCategories[0]) formDataStat.append('L0', selectedCategories[0]);
  if (selectedCategories[1]) formDataStat.append('L1', selectedCategories[1]);
  if (selectedCategories[2]) formDataStat.append('L2', selectedCategories[2]);
  if (selectedCategories[3]) formDataStat.append('L3', selectedCategories[3]);
  let configStat = {
    method: 'post',
    url: `${consoleState.state.api.BASE_URL}/new-product-stats`,
    data: formDataStat
  };
  axios(configStat)
    .then(async (response) => {
      setNewProductsStat(response.data);
    })
    .catch(function () {
      console.log('error');
    });
};
