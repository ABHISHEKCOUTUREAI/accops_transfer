export const formatInternationalStandard = (num) => {
  // remove decimal from number
  if (num > 0) {
    const numStr = num.toString().split('.')[0];
    // add commas to number
    return numStr.replace(/(\d)(?=(\d{3})+(?!\d))/g, '$1,');
  } else {
    return num;
  }
};
