import axios from 'axios';

export const getNotificationsAPI = (consoleState) => ({
  getNotifications: (body) => {
    let config = {
      method: 'POST',
      url: `${consoleState.state.api.BASE_URL}${consoleState.state.api.NOTIFICATIONS}`,
      data: body
    };
    return axios(config);
  }
});
