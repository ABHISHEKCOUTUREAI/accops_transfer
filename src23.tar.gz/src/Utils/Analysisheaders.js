import configuration from '../config/configuration';
export const headersnew = [
  {
    name: 'SAP ID',
    id: 'sap_id',
    sort: '',
    colSpan: 4,
    search: true,
    search_query: '',
    search_variable: 'sap_id'
  },
  {
    name: 'Description',
    id: 'item_name',
    sort: '',
    colSpan: 5,
    type: 'text',
    search: true,
    search_query: '',
    search_variable: 'item_name'
  },
  {
    name: 'Attributes',
    id: 'molecule',
    sort: '',
    colSpan: 4,
    type: 'text',
    search: true,
    search_query: '',
    search_variable: 'molecule'
  },
  {
    name: 'L0',
    id: 'L0',
    colSpan: 2,
    type: 'text'
  },
  {
    name: 'L3',
    id: 'L3',
    colSpan: 2,
    type: 'text'
  },
  {
    name: `Retail Price (${configuration.currency || '$'})`,
    id: 'mrp',
    sort: '',
    colSpan: 2,
    type: 'text'
  },
  {
    name: 'Pre-existing Inventory',
    id: 'current_inventory',
    sort: '',
    colSpan: 2,
    type: 'text'
  },

  {
    name: 'Suggested Order Trigger Qty',
    id: 'min_qty',
    sort: '',
    colSpan: 2,
    type: 'text',
    toolTip: true,
    toolTipText: 'Quantity at which the order replenishment is triggered'
  },
  {
    name: 'Suggested max stocked qty',
    id: 'max_qty',
    sort: '',
    colSpan: 3,
    type: 'text',
    toolTip: true,
    toolTipText: 'Max Quantity which can be stocked'
  },
  {
    name: 'Recommended Replenishment',
    id: 'minimum_replenishment',
    sort: '',
    colSpan: 2,
    toolTip: true,
    colorScheme: true,
    toolTipText:
      'Minimum replenishment required. If existing inventory is less than the min quantity, \n then replenishment is min quantity - existing inventory\n, if existing inventory is greater than min quantity and less than max quantity, then replenishment is 0, else replenishment is max quantity - existing inventory'
  },
  {
    name: 'Actual Sales',
    id: 'num_qty_sold',
    sort: 'desc',
    colSpan: 2,
    toolTip: true,
    toolTipText: 'Total quantities sold in the specified time period'
  },
  {
    name: `Sales (${configuration.currency || '$'})`,
    id: 'total_amount',
    sort: '',
    colSpan: 2,
    toolTip: true,
    toolTipText: 'Total revenue in the specified time period'
  },
  {
    name: 'Margin %',
    id: 'total_margin',
    sort: '',
    colSpan: 2,
    toolTip: true,
    toolTipText: 'Gross Profit Margin'
  }
];

export const headersmisses = [
  {
    name: 'SAP ID',
    id: 'sap_id',
    sort: '',
    colSpan: 4,
    search: true,
    search_query: '',
    search_variable: 'sap_id'
  },
  {
    name: 'Description',
    id: 'item_name',
    sort: '',
    colSpan: 5,
    type: 'text',
    search: true,
    search_query: '',
    search_variable: 'item_name'
  },
  {
    name: 'Attributes',
    id: 'molecule',
    sort: '',
    colSpan: 4,
    type: 'text',
    search: true,
    search_query: '',
    search_variable: 'molecule'
  },
  {
    name: 'L0',
    id: 'L0',
    colSpan: 2,
    type: 'text'
  },
  {
    name: 'L3',
    id: 'L3',
    colSpan: 2,
    type: 'text'
  },
  {
    name: `Retail Price (${configuration.currency || '$'})`,
    id: 'mrp',
    sort: '',
    colSpan: 2,
    type: 'text'
  },
  {
    name: 'Existing Inventory',
    id: 'current_inventory',
    sort: '',
    colSpan: 2,
    type: 'text'
  },
  {
    name: 'Actual Sales',
    id: 'num_qty_sold',
    sort: 'desc',
    colSpan: 2,
    toolTip: true,
    toolTipText: 'Total quantities sold in the specified time period'
  },
  {
    name: `Sales (${configuration.currency || '$'})`,
    id: 'total_amount',
    sort: '',
    colSpan: 2,
    toolTip: true,
    toolTipText: 'Total revenue in the specified time period'
  },
  {
    name: 'Margin %',
    id: 'total_margin',
    sort: '',
    colSpan: 2,
    toolTip: true,
    toolTipText: 'Gross Profit Margin'
  }
];
