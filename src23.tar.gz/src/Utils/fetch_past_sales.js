import axios from 'axios';
import { attachGlobalFilters } from './misc';

export const fetch_past_sales = (setSalesData, consoleState, token = null) => {
  // const lastIndexNonNull = lastIndex(selectedRegions);
  let formData = new FormData();
  formData.append('checkbox', false);
  formData = attachGlobalFilters(formData, consoleState);

  console.log('past sales', formData);
  // if (lastIndexNonNull !== -1) formData.append('region_type', levelNames[lastIndexNonNull]);
  // if (lastIndexNonNull !== -1) formData.append('region_name', selectedRegions[lastIndexNonNull]);
  // if (selectedCategories[0]) formData.append('L0', selectedCategories[0]);
  // if (selectedCategories[1]) formData.append('L1', selectedCategories[1]);
  // if (selectedCategories[2]) formData.append('L2', selectedCategories[2]);
  // if (selectedCategories[3]) formData.append('L3', selectedCategories[3]);
  let config = {
    method: 'post',
    url: `${consoleState.state.api.BASE_URL}${consoleState.state.api.PAST_SALES}`,
    data: formData,
    cancelToken: token
  };

  axios(config)
    .then(async (response) => {
      console.log('past sales response', response.data);

      const _data = response.data;
      const topCategory = consoleState.state.globalFilters.category.levelNames[0];
      const revenueKey = consoleState.state.pastSales.keys.revenue;
      const keyProcessor = consoleState.state.pastSales.keyProcessor;

      // const categories_l0 = ['Surgical', 'Devices', 'Pharma', 'Generics', 'Non Pharma'];
      const data = Object.keys(_data).reduce((acc, key) => {
        const _key = keyProcessor(key);
        acc[_key] = _data[key];
        return acc;
      }, {});
      const categorySet = new Set();
      Object.values(data).forEach((item) => {
        item.forEach((key) => {
          categorySet.add(key[topCategory]);
        });
      });
      const categories = Array.from(categorySet);

      const newDataRevenue = Object.keys(data).reduce((acc, key) => {
        const item = data[key];
        let temp = {};
        item.map((dict) => {
          if (temp[dict[topCategory]])
            temp[dict[topCategory]] += Math.round(dict[revenueKey] / 1000);
          else temp[dict[topCategory]] = Math.round(dict[revenueKey] / 1000);
        });
        categories.forEach((category) => {
          if (!temp[category]) temp[category] = 0;
        });
        acc[key] = temp;
        return acc;
      }, {});
      setSalesData(newDataRevenue);
      console.log('past sales data', newDataRevenue);
    })
    .catch(function (err) {
      console.log('error', err);
    });
};
