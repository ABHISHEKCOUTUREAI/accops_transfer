import axios from 'axios';

export const getCartAPI = (consoleState) => ({
  getCart: (body) => {
    let config = {
      method: 'POST',
      url: `${consoleState.state.api.BASE_URL}${consoleState.state.api.GET_CART}`,
      data: body
    };
    return axios(config);
  },
  addToCart: (body) => {
    let config = {
      method: 'POST',
      url: `${consoleState.state.api.BASE_URL}${consoleState.state.api.ADD_TO_CART}`,
      data: body
    };
    return axios(config);
  },
  getOrders: (reqBody) => {
    let config = {
      method: 'POST',
      url: `${consoleState.state.api.BASE_URL}${consoleState.state.api.ORDERS}`,
      data: reqBody
    };
    return axios(config);
  },
  placeOrder: (storeId) => {
    let config = {
      method: 'POST',
      url: `${consoleState.state.api.BASE_URL}${consoleState.state.api.PLACE_ORDER}/${storeId}`
    };
    return axios(config);
  },
  getOrderDetails: (reqBody) => {
    let config = {
      method: 'POST',
      url: `${consoleState.state.api.BASE_URL}${consoleState.state.api.ORDER_DETAILS}`,
      data: reqBody
    };
    return axios(config);
  },
  hardReset: (storeId) => {
    let config = {
      method: 'DELETE',
      url: `${consoleState.state.api.BASE_URL}${consoleState.state.api.HARD_RESET_ORDER}/${storeId}`
    };
    return axios(config);
  }
});
