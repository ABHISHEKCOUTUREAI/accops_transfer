import axios from 'axios';
import { attachGlobalFilters } from './misc';

export const mfacRevenue = (consoleState, setStats, cancelToken = null) => {
  let formData = new FormData();
  formData = attachGlobalFilters(formData, consoleState);

  let config = {
    method: 'post',
    url: `${consoleState.state.api.BASE_URL}${consoleState.state.api.MFAC_REVENUE}`,
    data: formData,
    cancelToken: cancelToken
  };

  axios(config)
    .then(async (response) => {
      setStats(response.data);
    })
    .catch(function () {
      console.log('error');
      setStats({});
    });
};
