import configuration from '../config/configuration';

const formatNumberMillionBillion = (num) => {
  if (String(num).length <= 3) {
    return num;
  }
  if (String(num).length >= 4 && String(num).length <= 6) {
    return String(parseFloat((num / 1000).toFixed(2))) + 'K';
  } else if (String(num).length >= 7 && String(num).length <= 9) {
    return String(parseFloat((num / 1000000).toFixed(2))) + 'M';
  } else {
    return String(parseFloat((num / 1000000000).toFixed(2))) + 'B';
  }
};

const formatNumberLakhCrore = (num) => {
  if (String(num).length <= 3) {
    return num;
  }
  if (String(num).length === 4 || String(num).length === 5) {
    return String(parseFloat((num / 1000).toFixed(2))) + 'K';
  } else if (String(num).length === 6 || String(num).length === 7) {
    return String(parseFloat((num / 100000).toFixed(2))) + 'Lk';
  } else {
    return String(parseFloat((num / 10000000).toFixed(2))) + 'Cr';
  }
};

export const formatNumber = (value) => {
  var num = value.toFixed(0);
  if (configuration?.currency === '$') {
    return formatNumberMillionBillion(num);
  } else {
    return formatNumberLakhCrore(num);
  }
};
