export const TableBaseConfig = {
  maxHeight: '600px',
  rows: {
    rowDatakey: 'product_id'
  },
  columns: {
    headers: [
      {
        title: 'Inventory Status',
        id: 'status',
        dataIndex: 'status_label',
        colSpan: 1,
        sort: {
          allow: true
        },
        transformer: null,
        filters: {
          filterType: 'discrete',
          filterID: 'status_label',
          discrete: {
            multiple: true,
            options: [
              { label: 'New', value: '0_new' },
              { label: 'Excess', value: '9_excess' },
              { label: 'Low Stock', value: '1_replenish' },
              { label: 'Optimal', value: '2_no_replenishment' }
            ],
            optionTransformer: null
          }
        }
      },
      {
        title: 'Product ID',
        id: 'product_id',
        dataIndex: 'product_id',
        colSpan: 1
      },
      {
        title: 'Name',
        sort: {
          allow: true
        },
        id: 'product_name',
        dataIndex: 'product_name',
        colSpan: 1,
        filters: {
          filterType: 'search',
          filterID: 'product_name'
        }
      },
      {
        title: process.env.REACT_APP_CONSOLE_TYPE === 'pharma' ? 'Molecule' : 'Description',
        sort: {
          allow: true
        },
        id: 'description',
        dataIndex: 'description',
        colSpan: 1,
        filters: {
          filterType: 'search',
          filterID: 'description'
        }
      },
      {
        title: 'Brand Name',
        sort: {
          allow: true
        },
        id: 'brand_name',
        dataIndex: 'brand_name',
        colSpan: 1
      },
      {
        title: 'L0',
        sort: {
          allow: true
        },
        id: 'L0',
        dataIndex: 'L0',
        colSpan: 1
      },
      {
        title: 'L3',
        id: 'L3',
        dataIndex: 'L3',
        colSpan: 1,
        sort: {
          allow: true
        }
      },
      {
        title: 'Channel',
        id: 'channel',
        dataIndex: 'channel',
        colSpan: 1,
        sort: {
          allow: true
        },
        filters: {
          filterType: 'discrete',
          filterID: 'channel',
          discrete: {
            multiple: true,
            options: [
              { label: 'Offline', value: 'offline' },
              { label: 'Online', value: 'online' }
            ],
            optionTransformer: null
          }
        }
      },
      {
        title: `Retail Price`,
        id: 'price',
        dataIndex: 'price',
        colSpan: 1,
        sort: {
          allow: true
        },
        filters: {
          filterType: 'range',
          filterID: 'price',
          range: {
            defaultMin: 0,
            defaultMax: 10000
          }
        }
      },
      {
        title: 'Existing Inventory',
        id: 'current_inventory',
        dataIndex: 'current_inventory',
        colSpan: 1,
        sort: {
          allow: true
        },
        filters: {
          filterType: 'range',
          filterID: 'current_inventory',
          range: {
            defaultMin: 0,
            defaultMax: 1000
          }
        }
      },
      {
        title: 'Order trigger qty',
        id: 'order_trigger_qty',
        colSpan: 1,
        dataIndex: 'min_qty',
        sort: {
          allow: true
        }
      },
      {
        title: 'Max stocked qty',
        id: 'max_stocked_qty',
        colSpan: 1,
        dataIndex: 'max_qty',
        sort: {
          allow: true
        }
      },
      {
        title: 'Recommended Replenishment',
        id: 'recommended_replenishment',
        dataIndex: 'minimum_replenishment',
        colSpan: 1,
        sort: {
          allow: true
        },
        cellBackground: ({ row }) => {
          const statusToBgColor = {
            '0_new': '#caddfc',
            '9_excess': '#f7cfb5',
            '1_replenish': '#fccbc7',
            '2_no_replenishment': '#c3dbca'
          };
          return statusToBgColor[row['status_label']];
        },
        transformer: null
      },
      {
        title: 'Cart',
        id: 'cart',
        dataIndex: 'cart',
        colSpan: 1,
        transformer: null
      },
      {
        title: 'Order in Process',
        dataIndex: 'order_quantity',
        id: 'order_quantity',
        colSpan: 1
      },
      {
        title: 'Order Status',
        dataIndex: 'order_status',
        colSpan: 1,
        transformer: null
      }
    ],
    groups: {
      allowGroups: true,
      groups: [
        {
          name: 'Product Details',
          id: 'product_details',
          columns: [
            'Product ID',
            'Name',
            'Description',
            'Brand Name',
            'L0',
            'L3',
            'Channel',
            'Retail Price'
          ],
          collapsible: true,
          defaultCollapsed: false,
          collapsedName: 'Summary',
          collapsedTransformer: null
        },
        {
          name: 'Predictions',
          id: 'predictions',
          columns: ['Order trigger qty', 'Max stocked qty', 'Recommended Replenishment']
          // collapsible: true,
          // collapsedName: 'Summary'
        }
      ]
    },
    unhideableColumns: ['Product ID', 'Order in Process'],
    defaultHiddenColumns: []
  },
  pagination: {
    infiniteScroll: false,
    allowPagination: true,
    defaultPageNumber: 1,
    defaultPageSize: 20,
    defaultFetchSize: 100,
    pageSizeOptions: [10, 20, 50, 100],
    fetch: null // to be set from component
  }
};
