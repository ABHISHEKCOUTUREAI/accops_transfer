export const Colors = {
  blue: '#6734eb',
  white: '#FFFFFF',
  black: '#000000'
};
