import { Search } from '@mui/icons-material';
import AccessTimeOutlinedIcon from '@mui/icons-material/AccessTimeOutlined';
import AutoAwesomeMosaicOutlinedIcon from '@mui/icons-material/AutoAwesomeMosaicOutlined';
import CategoryOutlinedIcon from '@mui/icons-material/CategoryOutlined';
import PlaceOutlinedIcon from '@mui/icons-material/PlaceOutlined';
import StoreMallDirectoryOutlinedIcon from '@mui/icons-material/StoreMallDirectoryOutlined';

function capitalizeHeading(word) {
  // Split the word at underscores and capitalize the first letter of each word
  let words = word.split('_').map((w) => w.charAt(0).toUpperCase() + w.slice(1));
  // Join the words with spaces
  return words.join(' ');
}

const refineDataForWordCloud = (data) => {
  /*
        the data is in this format
        {
            brand_name: 'brand_name',
            total_clicks: 1237921
        }
    */
  const keys = Object.keys(data[0]);
  const refinedData = data.map((entry) => {
    return {
      text: entry[keys[0]],
      value: entry[keys[1]]
    };
  });
  return refinedData;
};

/*
      Output has to be in ["From", "To", "Weight"] format
      Input is in this format: 
      {
          "necktype_trends": 
              {
                  "Mandarin": {
                      "tshirts": 12315623,
                      "kurtas": 13712,
                      "shirts": 129381263
                  },
                  "V": {
                      "tshirts": 12315623,
                      "kurtas": 13712,
                      "shirts": 129381263
                  }
              }
      }
  */

function refineDataForSankeyChart(obj) {
  const result = [['From', 'To', 'Revenue']];
  function flattenHelper(obj, prefix) {
    for (const key in obj) {
      if (typeof obj[key] === 'object') {
        flattenHelper(obj[key], [...prefix, key]);
      } else {
        result.push([...prefix, key, obj[key]]);
      }
    }
  }
  for (const key in obj) {
    flattenHelper(obj[key], [key]);
  }

  result.sort((a, b) => {
    if (a[2] < b[2]) {
      return -1;
    } else if (a[2] > b[2]) {
      return 1;
    } else {
      return 0;
    }
  });
  let res = result.slice(0, Math.floor(result.length * 0.6));
  return res;
}

const refineDataForSankeyChartV2 = (obj) => {
  let nodes = [],
    links = [],
    allKeys = new Set();

  const keys = Object.keys(obj);
  let maxValue;
  keys.map((firstKey) => {
    const secondKeys = Object.keys(obj[firstKey]);
    if (Object.keys(obj[firstKey]).length >= 1) {
      secondKeys.map((secondKey) => {
        let target = obj[firstKey][secondKey];
        if (target >= 1 && secondKey !== 'nan' && secondKey !== 'null') {
          allKeys.add(firstKey);
          allKeys.add(secondKey);
          maxValue = Math.max(maxValue, obj[firstKey][secondKey]);
          links.push({
            source: firstKey,
            target: secondKey,
            value: obj[firstKey][secondKey]
          });
        }
        return null;
      });
    }
    return null;
  });

  for (const key of allKeys) {
    nodes.push({ name: key });
  }

  const result = { nodes: nodes, links: links };
  return result;
};

const refineDataForTreeMap = (data, name) => {
  // Calculate total value for each category
  const categoryTotals = {};
  Object.entries(data).forEach(([category, types]) => {
    categoryTotals[category] = Object.values(types).reduce((acc, curr) => acc + curr, 0);
  });

  // Calculate total value for all categories
  const globalTotal = Object.values(categoryTotals).reduce((acc, curr) => acc + curr, 0);

  // Transform data and add percentage value
  const transformedData = {
    name: name,
    children: Object.entries(data).map(([category, types]) => ({
      name: category,
      children: Object.entries(types).map(([type, value]) => ({
        name: type,
        value: value,
        // Calculate percentage contribution
        percentage: {
          withinCategory: (value / categoryTotals[category]) * 100,
          global: (value / globalTotal) * 100
        }
      }))
    }))
  };
  return transformedData;
};

const headingIcons = {
  demographic: <PlaceOutlinedIcon w={'5px'} h={'5px'} />,
  brick_filters: <CategoryOutlinedIcon />,
  category: <CategoryOutlinedIcon />,
  attributes: <AutoAwesomeMosaicOutlinedIcon />,
  duration: <AccessTimeOutlinedIcon />,
  search_filters: <Search />,
  store_filters: <StoreMallDirectoryOutlinedIcon />
  // Heading2: <AddIcon />,
  // Heading3: <CloseIcon />,
  // Add more headings and their corresponding icons as needed
};

const customOrder = (all, selected) => {
  const remainingContent = all.filter((item) => !selected.includes(item));
  const result = [...selected, ...remainingContent];
  return result;
};

const useStyles = (chakratheme) => ({
  cardStyle: {
    flexDirection: 'column',
    padding: '10px 20px',
    backgroundColor: 'white',
    borderRadius: '10px',
    boxShadow: `${chakratheme.colors.shadow} 0 0 20px 0`
  },
  H2Title: {
    fontWeight: 'semibold',
    fontSize: '18px',
    padding: '10px 0 0 0'
  },
  H3Title: {
    fontSize: '16px',
    padding: '5px 0',
    fontFamily: 'Jost',
    color: `${chakratheme.colors.gray.main}`
  },
  tooltipStyle: {
    bg: `${chakratheme.colors.gray.lighter}`,
    border: `1px solid ${chakratheme.colors.gray.light}`,
    color: `${chakratheme.colors.gray.dark}`,
    padding: '5px 15px',
    borderRadius: '3px',
    fontSize: '13px'
  }
});

const processNestedData = (nestedData, setFilterHeadings, setLevelNames) => {
  if (nestedData?.data) {
    setFilterHeadings(Object.keys(nestedData.data));
    const updatedLevelNames = {};
    Object.keys(nestedData.data).forEach((filter) => {
      updatedLevelNames[filter] = Object.keys(nestedData.data[filter]);
    });
    setLevelNames(updatedLevelNames);
  }
};

const generateNestedData = (selectedFilters, headings) => {
  let obj = {};
  headings.forEach((heading) => {
    obj[heading] = selectedFilters[heading];
  });
  return obj;
};

const checkIfOnlyOneMonthIsSelected = (selectedFilters) => {
  // now check duration only
  const durationKeys = Object.keys(selectedFilters['duration']);
  for (const element of durationKeys) {
    const key = element;
    if (key !== 'month') {
      const selectedValues = Object.values(selectedFilters['duration'][key]);
      if (selectedValues.length !== 0) {
        return false;
      }
    }
    // number of months should be as 1
    else if (selectedFilters['duration']['month'].length !== 1) {
      // more months are selected
      return false;
    }
  }
  return true;
};

// check if only month is selected in duration and not others
const checkIfDefaultFilter = (selectedFilters) => {
  const keys = Object.keys(selectedFilters);
  for (const element of keys) {
    const key = element;
    if (key !== 'duration') {
      const selectedValues = Object.values(selectedFilters[key]);
      for (const element of selectedValues) {
        const arr = element;
        if (arr.length !== 0) {
          return false;
        }
      }
    }
  }

  return checkIfOnlyOneMonthIsSelected(selectedFilters) !== false;
};

const tableInitialState = (pageNo, sortParam, sortOrder) => {
  return {
    page_no: pageNo,
    sort_param: sortParam,
    sort_type: sortOrder
  };
};

export {
  capitalizeHeading,
  customOrder,
  headingIcons,
  processNestedData,
  refineDataForSankeyChart,
  refineDataForSankeyChartV2,
  refineDataForTreeMap,
  refineDataForWordCloud,
  useStyles,
  checkIfDefaultFilter,
  checkIfOnlyOneMonthIsSelected,
  generateNestedData,
  tableInitialState
};
