import { Button } from '@chakra-ui/react';
import React from 'react';
import { CloudDownload } from '@mui/icons-material';

const DownloadButton = (props) => {
  return (
    <Button
      leftIcon={<CloudDownload />}
      variant={props.variant ? props.variant : 'primary'}
      size={props.size ? props.size : 'sm'}
      {...props}>
      {props.text ? props.text : 'Download All'}
    </Button>
  );
};

export default DownloadButton;
