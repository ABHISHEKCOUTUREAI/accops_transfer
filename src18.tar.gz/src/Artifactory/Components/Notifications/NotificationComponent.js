import { Box, Flex, IconButton, Text } from '@chakra-ui/react';
import { CheckCircleIcon, WarningIcon } from '@chakra-ui/icons';
import AddShoppingCartIcon from '@mui/icons-material/AddShoppingCart';
import { useEffect, useState } from 'react';

export const NotificationComponent = ({ message, onCartClick }) => {
  const [notification, setNotification] = useState({});

  useEffect(() => {
    const statusMap = {
      low_stock: {
        variant: 'warning',
        content: `${message.product_name} is running out of stock!`,
        icon: WarningIcon,
        color: '#C53030',
        backgroundColor: '#FED7D7'
      },
      high_demand: {
        variant: 'success',
        content: `${message.product_name} is having high demand!`,
        icon: CheckCircleIcon,
        color: '#2F855A',
        backgroundColor: '#C6F6D5'
      }
    };

    if (message.status in statusMap) {
      const { variant, content, icon, color, backgroundColor } = statusMap[message.status];
      setNotification({ variant, content, icon, color, backgroundColor });
    }
  }, [message]);

  const IconComponent = notification.icon || WarningIcon; // Default icon if status is unknown

  return (
    <Box backgroundColor={notification.backgroundColor} p={4} borderRadius="md" boxShadow="md">
      <Flex alignItems="center" justifyContent="space-between" width="100%">
        <Flex alignItems="center">
          <IconComponent color={notification.color} />
          <Text ml={2}>{notification.content}</Text>
        </Flex>
        <IconButton
          variant="outline"
          size="sm"
          onClick={onCartClick}
          icon={<AddShoppingCartIcon />}
        />
      </Flex>
    </Box>
  );
};
