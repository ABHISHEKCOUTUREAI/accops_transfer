import { Box, Text, useTheme } from '@chakra-ui/react';
import React, { useState } from 'react';
import PropTypes from 'prop-types';

const HoverTextBox = (props) => {
  const [isHovered, setIsHovered] = useState(false);
  const theme = useTheme();

  const handleMouseEnter = () => {
    setIsHovered(true);
  };

  const handleMouseLeave = () => {
    setIsHovered(false);
  };

  const textColor = isHovered ? theme.colors.blue.main : '';

  return (
    <Box
      borderWidth="2px"
      borderRadius="lg"
      p={'8px 14px'}
      onMouseEnter={handleMouseEnter}
      onMouseLeave={handleMouseLeave}>
      <Text fontSize={'16px'} color={textColor}>
        {props.content}
      </Text>
    </Box>
  );
};

HoverTextBox.propTypes = {
  content: PropTypes.string.isRequired
};

export default HoverTextBox;
