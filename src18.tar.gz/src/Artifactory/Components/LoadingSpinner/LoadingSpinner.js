import { ChakraProvider, Flex, Spinner, useTheme } from '@chakra-ui/react';
import { useEffect, useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import PropTypes from 'prop-types';

const LoadingSpinner = ({ name }) => {
  const cyclingTexts = [
    <>
      Loading
      <Flex
        justifyContent={'center'}
        alignItems={'center'}
        as="span"
        bg="gray.100"
        color="gray.800"
        fontFamily="monospace"
        fontSize="sm"
        px="1"
        borderRadius="md">
        {name}
      </Flex>
    </>,
    'Fetching Info',
    'Please Wait'
  ];
  const [currentTextIndex, setCurrentTextIndex] = useState(0);

  const theme = useTheme();

  useEffect(() => {
    const intervalId = setInterval(() => {
      setCurrentTextIndex((prevIndex) => (prevIndex + 1) % cyclingTexts.length);
    }, 2000); // Change text every 2 seconds

    return () => clearInterval(intervalId);
  }, []);

  return (
    <ChakraProvider>
      <Flex
        bg={`${theme.colors.gray.lighter}`}
        direction="column"
        alignItems="center"
        justifyContent="center"
        height="100%"
        width="100%"
        p={5}
        gap={'20px'}>
        <Spinner size="md" />
        <AnimatePresence mode="wait">
          <motion.div
            key={currentTextIndex}
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            transition={{ duration: 0.5 }}>
            <Flex gap={'5px'} justifyContent={'center'} alignItems={'center'}>
              {cyclingTexts[currentTextIndex]}
            </Flex>
          </motion.div>
        </AnimatePresence>
      </Flex>
    </ChakraProvider>
  );
};

LoadingSpinner.propTypes = {
  name: PropTypes.string.isRequired
};

export default LoadingSpinner;
