import { Box, Button } from '@chakra-ui/react';
import UploadRoundedIcon from '@mui/icons-material/UploadRounded';

const FileUploader = (props) => {
  const onFileChange = (event) => {
    props.handleFiles(event.target.files);
    event.target.value = '';
  };

  const overrideEventDefaults = (event) => {
    event.preventDefault();
    event.stopPropagation();
  };

  const handleDragOver = (event) => {
    event.preventDefault();
    event.stopPropagation();
  };

  const handleDragLeave = (event) => {
    event.preventDefault();
    event.stopPropagation();
  };

  const handleDragAndDropFiles = (event) => {
    overrideEventDefaults(event);
    if (!event.dataTransfer) return;
    props.handleFiles(event.dataTransfer.files);
  };

  return (
    <Box
      onDrop={handleDragAndDropFiles}
      onDragEnter={overrideEventDefaults}
      onDragLeave={handleDragLeave}
      onDragOver={handleDragOver}>
      {/* <Input type="file" hidden ref={props.fileInput} onChange={onFileChange} /> */}
      <input
        type="file"
        accept=".csv"
        onChange={onFileChange}
        ref={props.fileInput}
        style={{ display: 'none' }}
      />
      <Button
        size="sm"
        onClick={props.handleButtonClick}
        leftIcon={<UploadRoundedIcon />}
        variant="outline">
        Upload
      </Button>
    </Box>
  );
};

export default FileUploader;
