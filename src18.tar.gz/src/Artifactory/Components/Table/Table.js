import { Box, Divider, Flex, Spacer, Text } from '@chakra-ui/layout';
import { IconButton, Skeleton, Table, Tbody, Td, Thead, Tr, useTheme } from '@chakra-ui/react';
import { ChevronLeftRounded, ChevronRightRounded } from '@mui/icons-material';
import { useEffect, useState } from 'react';
import { HeaderCell } from './HeaderCell';
import { TableRow } from './TableRow';
const CustomTable = (props) => {
  const chakratheme = useTheme();
  const pageSize = props.page_size ? props.page_size : 20;
  const [paginatedData, setPaginatedData] = useState(null);
  const [headers, setHeaders] = useState(props.headers); // {name: 'Name', id: 'ID', sort: null/''/'asc'}
  const paginate = () => {
    const start = props.page * pageSize - pageSize;
    const end = props.page * pageSize;
    setPaginatedData(props.data && props.data.slice(start, end));
  };

  const [hoveredRow, setHoveredRow] = useState(null);

  // useEffect(() => {
  //   setHeaders(props.headers);
  // }, [props.headers]);

  useEffect(() => {
    paginate();
  }, [pageSize, props.page, props.sortBy, headers, props.data]);
  const tdStyle = {
    fontFamily: 'Arial, sans-serif',
    fontWeight: 'regular', // Replace with your desired font
    padding: '5px 15px',
    fontSize: '13px',
    textAlign: 'left',
    color: `${chakratheme.colors.black[800]}`
  };

  //   const formatNumber = (num) => {
  //     if (String(num).length <= 3) {
  //       return num;
  //     }
  //     if (String(num).length === 4 || String(num).length === 5) {
  //       return String(parseFloat((num / 1000).toFixed(2))) + 'K';
  //     } else if (String(num).length === 6 || String(num).length === 7) {
  //       return String(parseFloat((num / 100000).toFixed(2))) + 'Lk';
  //     } else {
  //       return String(parseFloat((num / 10000000).toFixed(2))) + 'Cr';
  //     }
  //   };

  //   const TruncatedText = ({ text, maxLength, index }) => {
  //     const isHovered = index == hoveredRow;
  //     const truncatedText = isHovered
  //       ? text
  //       : text && text.length > maxLength
  //         ? text.slice(0, maxLength) + '...'
  //         : text;
  //     return <span fontSize="13px">{truncatedText}</span>;
  //   };

  //   const debouncedHandleKeyChange = debounce((variable, value) => {
  //     props.setSearchData({
  //       ...props.searchData,
  //       [variable]: value
  //     });
  //     props.setPage(1);
  //   }, 1000);

  const thStyle = {
    color: 'black',
    padding: '10px 15px',
    fontSize: '13px',
    fontWeight: 'bold',
    borderBottom: `1px solid ${chakratheme.colors.gray.light}`,
    textAlign: 'left',
    textTransform: 'none'
  };

  return (
    <Box
      style={{
        boxShadow: `${chakratheme.colors.shadow} 0 0 20px 10px`,
        display: 'block'
      }}>
      <Box
        overflowY="auto"
        overfloX="scroll"
        height={props.height ? props.height : '600px'}
        w="100%"
        maxHeight={props.height ? props.height : '600px'}>
        <Table
          style={{ borderSpacing: '0 1em' }}
          __css={{ width: 'full' }}
          variant="simple"
          colorScheme="teal">
          <Thead
            style={{
              position: 'sticky',
              top: 0,
              zIndex: 6,
              opacity: 1,
              backgroundColor: `${chakratheme.colors.primary.lighter}`,
              borderRadius: '20px',
              color: `${chakratheme.colors.primary.main}`
            }}>
            <Tr style={{ borderRadius: '20px', color: `${chakratheme.colors.primary.main}` }}>
              {headers &&
                headers.map((title, i) => (
                  <HeaderCell
                    key={i}
                    title={title}
                    index={i}
                    headers={headers}
                    setHeaders={setHeaders}
                    chakratheme={chakratheme}
                    props={props}
                    thStyle={thStyle}
                    // debouncedHandleKeyChange={debouncedHandleKeyChange}
                  />
                ))}
            </Tr>
          </Thead>
          {props.loading ? (
            <Tbody>
              {Array.from(Array(20).keys()).map((item, i) => {
                return (
                  <Tr
                    key={i}
                    _hover={{
                      backgroundColor: `${chakratheme.colors.gray.lighter}`
                    }}
                    style={{
                      padding: '20px 0',
                      borderBottom: `2px solid ${chakratheme.colors.gray.lighter}`
                    }}>
                    {headers &&
                      headers.map((header, index) => {
                        return (
                          <Td
                            key={index}
                            colSpan={header.colSpan ? header.colSpan : 1}
                            style={tdStyle}>
                            <Skeleton
                              variant="rectangular"
                              style={{
                                width: '90%',
                                height: '20px'
                              }}
                            />
                          </Td>
                        );
                      })}
                  </Tr>
                );
              })}
            </Tbody>
          ) : (
            <Tbody>
              {paginatedData &&
                paginatedData.map((item, i) => (
                  <TableRow
                    key={i}
                    item={item}
                    i={i}
                    headers={headers}
                    hoveredRow={hoveredRow}
                    setHoveredRow={setHoveredRow}
                    chakratheme={chakratheme}
                    tdStyle={tdStyle}
                  />
                ))}
            </Tbody>
          )}
        </Table>
      </Box>
      {props.data && props.data.length > 0 && (
        <>
          <Divider />
          <Flex
            style={{
              bottom: '0', // Align the Flex to the bottom
              width: '100%' // Make it take the full width
            }}
            justifyContent="space-between"
            alignItems="center"
            ml={5}>
            <Text fontSize="14px">
              {`Showing  ${(props.page - 1) * pageSize + 1} to  ${Math.min(
                props.page * pageSize,
                props.totalProductsCount
              )} of ${props.totalProductsCount} records`}
            </Text>
            <Spacer />
            <Flex justifyContent="flex-end" alignItems="center" mr={10}>
              <Box h="40px" mx={4}>
                <Divider orientation="vertical" />
              </Box>
              <IconButton
                onClick={() => props.setPage(props.page - 1)}
                isdisabled={props.page === 1}
                size="sm"
                variant="iconOutline"
                icon={<ChevronLeftRounded />}
              />
              <Text fontSize="14px" size="sm" p={5}>
                Page {props.page} of {Math.ceil(props.totalProductsCount / pageSize)}
              </Text>
              <IconButton
                variant="iconOutline"
                onClick={() => {
                  console.log('props.page', props.page);
                  if (
                    props.page !== Math.ceil(props.totalProductsCount / pageSize) &&
                    ((props.page_size === 10 && (props.page % 10 === 0 || props.page === 1)) ||
                      (props.page_size !== 10 && (props.page % 5 === 0 || props.page === 1)))
                  ) {
                    props.setPage(props.page + 1);
                    props.handlePagination();
                  } else {
                    props.setPage(props.page + 1);
                  }
                }}
                isDisabled={props.page === Math.ceil(props.totalProductsCount / pageSize)}
                size="sm"
                icon={<ChevronRightRounded />}
              />
              {/* )} */}
            </Flex>
          </Flex>
        </>
      )}
    </Box>
  );
};
export default CustomTable;
