import {
  Flex,
  Grid,
  GridItem,
  Popover,
  PopoverBody,
  PopoverContent,
  PopoverTrigger,
  Text
} from '@chakra-ui/react';
import React from 'react';
import { Colors } from '../../../Static/properties/properties';
import Card from '../Card/Card';

const GridColumn = ({ items, startIndex, endIndex, onClose, handleProductClick }) => {
  return (
    <GridItem colSpan={1} rowSpan={1}>
      <Flex flexDir="column">
        {items.slice(startIndex, endIndex).map((item) => (
          <Text key={item} cursor={'pointer'} onClick={() => handleProductClick(onClose, item)}>
            {item}
          </Text>
        ))}
      </Flex>
    </GridItem>
  );
};

const PopoverCard = (props) => {
  const splitIndex1 = Math.ceil(props.type.length / 3);
  const splitIndex2 = splitIndex1 * 2;

  return (
    <Popover trigger="hover" placement="bottom-end" initialFocusRef={props.initRef}>
      {({ onClose }) => (
        <>
          <PopoverTrigger>
            <GridItem
              rowSpan={1}
              colSpan={1}
              h="70%"
              cursor={'pointer'}
              onMouseEnter={() => props.setHover(true)}
              onMouseLeave={() => props.setHover(false)}>
              <Card
                style={{
                  display: 'flex',
                  justifyContent: 'center',
                  alignItems: 'center',
                  border: props.hover ? '1px solid #000000' : null,
                  backgroundColor: props.product ? Colors.black : Colors.white
                }}>
                <Flex
                  flexDir="column"
                  my={2}
                  style={{ alignItems: 'center', justifyContent: 'center' }}>
                  {props.icon}
                  <Text
                    style={{
                      color: props.product ? Colors.white : Colors.black
                    }}>
                    {props.text}
                  </Text>
                </Flex>
              </Card>
            </GridItem>
          </PopoverTrigger>
          <PopoverContent style={{ width: 'fit-content' }}>
            <PopoverBody>
              {props.type?.length > 0 ? (
                <Grid templateRows="repeat(1, 1fr)" templateColumns="repeat(3, 1fr)" gap={5}>
                  <GridColumn
                    items={props.type}
                    startIndex={0}
                    endIndex={splitIndex1}
                    onClose={onClose}
                    handleProductClick={props.handleProductClick}
                  />
                  <GridColumn
                    items={props.type}
                    startIndex={splitIndex1}
                    endIndex={splitIndex2}
                    onClose={onClose}
                    handleProductClick={props.handleProductClick}
                  />
                  <GridColumn
                    items={props.type}
                    startIndex={splitIndex2}
                    endIndex={props.type.length}
                    onClose={onClose}
                    handleProductClick={props.handleProductClick}
                  />
                </Grid>
              ) : (
                <Text>No Products</Text>
              )}
            </PopoverBody>
          </PopoverContent>
        </>
      )}
    </Popover>
  );
};

export default PopoverCard;
