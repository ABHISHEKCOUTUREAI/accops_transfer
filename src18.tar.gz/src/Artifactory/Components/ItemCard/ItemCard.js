import { Box, Image, Flex, Text } from '@chakra-ui/react';

export const ItemCard = ({ item, imgSrc, ...props }) => {
  return (
    <Flex boxShadow={'rgb(231, 231, 231) 0px 0px 20px 0px'} borderRadius={'20px'} {...props}>
      <Box
        position="relative"
        width={'40%'}
        borderTopLeftRadius="20px"
        borderBottomLeftRadius="20px"
        overflow="hidden"
        sx={{
          '&::before': {
            content: '""',
            position: 'absolute',
            top: 0,
            left: 0,
            width: '100%',
            height: '100%',
            backgroundColor: 'black',
            opacity: 0,
            transition: 'opacity 0.3s ease',
            borderTopLeftRadius: 'inherit',
            borderBottomLeftRadius: 'inherit'
          },
          '&:hover::before': {
            opacity: 0.5
          }
        }}>
        <Image
          src={imgSrc}
          objectFit="contain"
          style={{
            width: '100%',
            height: '100%',
            borderTopLeftRadius: '20px',
            borderBottomLeftRadius: '20px'
          }}
        />
      </Box>
      <Flex
        direction="column"
        width="60%"
        pl={'30px'}
        pr={'10px'}
        pb={'10px'}
        style={{
          backgroundColor: 'white',
          fontFamily: 'Hanken Grotesk',
          borderTopRightRadius: '20px',
          borderBottomRightRadius: '20px'
        }}>
        <Flex position="relative" direction={'row'} width="100%" alignItems={'center'}>
          <Text m="10px 0 5px 0" fontSize={20} fontWeight={'bold'} color="black">
            {item.brandname}
          </Text>
        </Flex>
        <Flex width="100%" alignItems={'center'}>
          <Text fontFamily="AG2Body-Semibold" fontSize={18} lineHeight={1}>
            {item.title}
          </Text>
        </Flex>
        <Flex position="relative" direction={'row'} width="100%" alignItems={'center'} my="15px">
          <Text fontSize={18} fontWeight="semibold" color={`primary.main`}>
            ₹{item.mrp}
          </Text>
        </Flex>
        <Flex position="relative" direction={'row'} width="100%" alignItems={'center'}>
          <Flex>
            <Box mr={4}>
              <Flex direction={'column'}>
                <Text fontWeight={'bold'} fontSize={14}>
                  UNITS SOLD
                </Text>
                <Box w="20px" h="5px" bg={`green.main`} borderRadius="3px" mt={1} />
              </Flex>
              <Text mt={1} fontWeight={'bold'} fontSize={21}>
                {item.total_qty_sold}
              </Text>
            </Box>
            <Box ml={4}>
              <Flex direction={'column'}>
                <Text fontWeight={'bold'} fontSize={14}>
                  RATE OF SALE
                </Text>
                <Box w="20px" h="5px" bg={`orange.medium`} borderRadius="3px" mt={1} />
              </Flex>
              <Text mt={1} fontWeight={'bold'} fontSize={21}>
                {item.weekly_rate_of_sale}
              </Text>
            </Box>
          </Flex>
        </Flex>
      </Flex>
    </Flex>
  );
};
