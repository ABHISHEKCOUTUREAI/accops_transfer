import { ResponsiveContainer, PieChart, Pie, Cell, Tooltip, Legend } from 'recharts';

const RingPieChart = (props) => {
  const formattedData = props.label.map((label, index) => ({
    name: label,
    value: props.series[index]
  }));

  const COLORS = ['#29145e', '#633ec2', '#9470f1', '#b399f5', '#e0d6fb'];

  const getColors = (category) => {
    // Customize colors based on the category
    return category === 'Non Pharma'
      ? ['#633ec2', '#9470f1', '#b399f5', '#e0d6fb', '#29145e']
      : COLORS;
  };

  // eslint-disable-next-line no-unused-vars
  const formatNumber = (num) => {
    if (String(num).length <= 3) {
      return '₹' + num;
    }
    return '₹' + String(parseFloat((num / 1000).toFixed(3))) + 'K';
  };

  return (
    <ResponsiveContainer width="100%" height={280}>
      <PieChart height={280}>
        <Pie
          data={formattedData}
          cx="50%"
          cy="50%"
          outerRadius={80}
          innerRadius={40}
          dataKey="value"
          // label={({ cx, cy, midAngle, innerRadius, outerRadius, value, index }) => {
          //   const RADIAN = Math.PI / 180;
          //   const radius = 25 + innerRadius + (outerRadius - innerRadius);
          //   const x = cx + radius * Math.cos(-midAngle * RADIAN);
          //   const y = cy + radius * Math.sin(-midAngle * RADIAN);

          //   return (
          //     <text
          //       x={x}
          //       y={y}
          //       fill={COLORS[index % COLORS.length]}
          //       textAnchor={x > cx ? 'start' : 'end'}
          //       dominantBaseline="central"
          //       fontSize={8}>
          //       <tspan x={x} y={y}>
          //         {formattedData[index].name}
          //       </tspan>
          //       <tspan x={x} y={y + 20}>
          //         {formatNumber(value)}
          //       </tspan>
          //     </text>
          //   );
          // }}
        >
          {formattedData.map((entry, index) => (
            <Cell key={`cell-${index}`} fill={getColors(entry.name)[index % COLORS.length]} />
          ))}
        </Pie>
        <Legend
          layout="horizontal" // Set to 'horizontal' for top or bottom alignment
          verticalAlign="top" // Use 'top' or 'bottom'
          align="center"
          iconType="circle"
          formatter={(value, entry) => {
            const { color } = entry;
            return (
              <span style={{ color }}>
                {value} ({formatNumber(entry.payload.value)})
              </span>
            );
          }}
        />
        <Tooltip />
      </PieChart>
    </ResponsiveContainer>
  );
};

export default RingPieChart;
