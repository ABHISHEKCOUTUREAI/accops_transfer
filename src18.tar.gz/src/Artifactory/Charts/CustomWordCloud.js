import React from 'react';
import 'tippy.js/dist/tippy.css';
import 'tippy.js/animations/scale.css';
import WordCloud from 'react-d3-cloud';
import tippy from 'tippy.js';
import PropTypes from 'prop-types';

const CustomWordCloud = ({ data }) => {
  const showTooltip = (event, word) => {
    const tooltip = tippy(event.target, {
      content: `${word.text}: ${word.value.toLocaleString()}`
    });
    tooltip.show();
  };

  return (
    <div className="wordcloud">
      <WordCloud
        data={data}
        width={500}
        height={500}
        fontSize={(word) => Math.log2(word.value) * 2}
        font="Jost"
        rotate={() => 0}
        padding={3}
        onWordClick={(word) => console.log(word)}
        onWordMouseOver={(event, word) => showTooltip(event, word)}
      />
    </div>
  );
};

CustomWordCloud.propTypes = {
  data: PropTypes.array.isRequired
};

export default CustomWordCloud;
