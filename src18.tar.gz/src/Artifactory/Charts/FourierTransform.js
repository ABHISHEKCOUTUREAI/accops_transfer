import React from 'react';
import {
  ResponsiveContainer,
  BarChart,
  Bar,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  Legend,
  Brush
} from 'recharts';

const CustomizedLabel = ({ x, y }) => (
  <g transform={`translate(${x + 1},${y})`}>
    <circle cx={0} r={3} fill="#675cfd" />
  </g>
);

const FourierTransform = (props) => {
  const data = props.fourierData;
  return (
    <ResponsiveContainer width="97%" height={250}>
      <BarChart data={data} margin={{ left: 40 }}>
        <CartesianGrid strokeDasharray="3 3" />
        <XAxis dataKey="frequency" tickFormatter={(value) => value.toFixed(2)} />
        <YAxis />
        <Tooltip />
        <Legend />
        <Bar barSize={2} dataKey="amplitude" fill="#675cfd" label={<CustomizedLabel />} />
        <Brush dataKey="frequency" height={30} stroke="#8884d8" />
      </BarChart>
    </ResponsiveContainer>
  );
};

export default FourierTransform;
