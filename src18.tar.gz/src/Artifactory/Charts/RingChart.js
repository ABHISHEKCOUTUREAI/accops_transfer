// eslint-disable-next-line no-unused-vars
import { Box, Flex, Text } from '@chakra-ui/layout';
import { ResponsiveContainer, PieChart, Pie, Cell, Tooltip, Legend } from 'recharts';

const RingChart = (props) => {
  const formattedData = props.label.map((label, index) => ({
    name: label,
    value: props.series[index]
  }));

  const COLORS = ['#DD6A1F', 'red', '#32a852', '#b399f5', '#e0d6fb'];

  const getColors = (category) => {
    // Customize colors based on the category
    return category === 'Non Pharma'
      ? ['#633ec2', '#9470f1', '#b399f5', '#e0d6fb', '#29145e']
      : COLORS;
  };

  return (
    <ResponsiveContainer width="100%" height={300}>
      <PieChart height={300}>
        <Pie
          cornerRadius={10}
          data={formattedData}
          cx="50%"
          cy="50%"
          outerRadius={100}
          innerRadius={80}
          dataKey="value">
          {formattedData.map((entry, index) => (
            <Cell key={`cell-${index}`} fill={getColors(entry.name)[index % COLORS.length]} />
          ))}
        </Pie>
        <Legend
          verticalAlign="top"
          height={20}
          fontSize={'10px'}
          fontFamily="Hanken Grotesk"
          fontWeight={'bold'}
          iconSize={20}
          iconType="wye"
          content={(props) => {
            const { payload } = props;
            console.log(props);
            return (
              <Flex ml="10px" direction={'row'} gap="10px">
                {payload.map((entry, index) => (
                  <Flex key={index} alignItems={'center'}>
                    <Box w="10px" h="10px" bg={entry.color} borderRadius="50%" margin="5px" />
                    <Text
                      color="#cccccc"
                      fontSize="10px"
                      fontFamily={'Hanken Grotesk'}
                      fontWeight={'bold'}>
                      {entry.value}
                    </Text>
                  </Flex>
                ))}
              </Flex>
            );
          }}
        />
        <Tooltip
          formatter={(value) => {
            const percentage = (value / props.totalproducts) * 100;
            return `${percentage.toFixed(2)}%`;
          }}
        />
      </PieChart>
    </ResponsiveContainer>
  );
};

export default RingChart;
