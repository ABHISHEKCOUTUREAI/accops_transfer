import React, { useEffect, useRef } from 'react';
import * as echarts from 'echarts';

export const CandleStick = ({ data, ...props }) => {
  const candleStickChartRef = useRef(null);

  useEffect(() => {
    if (candleStickChartRef.current) {
      const candleStickChart = echarts.init(chartContainerRef.current);
      candleStickChart.setOption({
        xAxis: {
          data: data.x
        },
        yAxis: {},
        series: [
          {
            type: 'candlestick',
            data: data.y
          }
        ]
      });
    }
  }, [data]);

  return <div ref={candleStickChartRef} style={{ width: '400px', height: '400px' }} />;
};
