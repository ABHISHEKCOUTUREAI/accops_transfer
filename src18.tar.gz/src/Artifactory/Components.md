# 🎨 Component Manual : How to use 📖

## Button
### AddButton

If you want a button with a plus icon and some text, you can use this.

![addbutton](https://github.com/Couture-ai/UI-Artifactory/assets/121786988/4782899e-d0ed-4b69-9777-71a62b36d16b)

#### Props: <br />
text <br />
variant (Takes primary if no variant is passed in props) <br />
size (Takes ‘sm’ if not passed) <br />

You can use other properties like width, onClick(), etc.  normally with the AddButton component.
```
<AddButton size="md" width="15%" text={'Add SKU'}</AddButton>
```

### DownloadButton
For a button with a download icon, you can use this. The variant of the above button is ‘outline’.

![downloadbutton](https://github.com/Couture-ai/UI-Artifactory/assets/121786988/598e7309-fb19-4068-a0f4-fe2ee7b16114)

#### Props:  
text <br />
variant (Takes primary if no variant is passed in props) <br />
size (Takes ‘sm’ if not passed) <br />

```
<DownloadButton size="md" width="15%" variant="outline" text={'Download'}></DownloadButton>
```

### UploadButton
For a button with an upload icon, you can use this. The variant of the above button is ‘outlineSecondary’

![uploadbutton](https://github.com/Couture-ai/UI-Artifactory/assets/121786988/ed864df8-bf8c-48b8-9b48-d839042d9c0a)

#### Props:  
text <br />
variant (Takes primary if no variant is passed in props) <br />
size (Takes ‘sm’ if not passed) <br />

```
UploadButton size="md" width="15%" variant="outlineSecondary" text={'Upload File'}></UploadButton>
```

#### Note: To find what all variants of buttons are available you can look into theme/components/button.js


## Breadcrumb

If you want to use a breadcrumb like this at the top of your page, you can use this component.

![breadcrumb 1](https://github.com/Couture-ai/UI-Artifactory/assets/121786988/3c126ed7-9c49-4be5-8ad7-efa4c6dcc7ab)

#### Props:  
itemList - It is an array of objects name, asLink, toLink, isPortal <br />
portalList - array of objects with name, OnClickParameter <br />
defaultValue - some default array for the portalList option group <br />
handleMenuClick - function to navigate to a page when clicked

```
const breadCrumbItemList = [
    {
      name: 'Online Services',
      asLink: false,
      toLink: null,
      isPortal: false
    },
    {
      name: 'Analytics',
      asLink: true,
      toLink: '/analytics',
      isPortal: false
    },
    {
      name: 'Top Performing Category',
      asLink: false,
      toLink: null,
      isPortal: true
    }
  ];

  const breadCrumbPortalList = [
    {
      name: 'Beauty Kit',
      onClickParameter: 'beauty-kit'
    },
    {
      name: 'Add Beauty Kit',
      onClickParameter: 'addBeautyKit'
    }
  ];
```
Note that the isPortal value is true for the last item in itemList.

![breadcrumb2](https://github.com/Couture-ai/UI-Artifactory/assets/121786988/691d2504-a605-4fe6-9682-7bbcb04ddff2)

If you don't want the dropdown(portalList), pass only itemList in props and change the isPortal value of last item in itemList to false.
```
<BreadCrumb portalList={breadCrumbPortalList} itemList={breadCrumbItemList}></BreadCrumb>
```
You also need to pass a handleMenuClick function to this.

## ChooseLayout/Dropdown
If you want to display a dropdown with a list of options this component will be useful.

![select](https://github.com/Couture-ai/UI-Artifactory/assets/121786988/bd1abc41-abf2-4e86-a7c5-8c145e124f6f)

#### Props:  
optionList - Array of objects with name,value, imageSrc for each option.

```
 const optionList = [
    {
      name: 'Beauty Kit',
      value: '1',
    },
    {
      name: 'Add Beauty Kit',
      value: '2'
    }
  ];

<Dropdown width="15%" optionList={optionList}></Dropdown>
```

## ChooseLayout/RadioGroup
If you want to display radiobuttons this component will be useful.

#### Props:  
optionList - Array of objects with name,value for each option.

```
 const optionList = [
    {
      name: 'Beauty Kit',
      value: '1',
    },
    {
      name: 'Add Beauty Kit',
      value: '2'
    }
  ];

<RadioButtons optionList={optionList} mt={6}></RadioButtons>  

```

## Tooltip
This component is used to give an i button to some heading so that when the user hovers on them, some information is displayed in the popover window.

![tooltip](https://github.com/Couture-ai/UI-Artifactory/assets/121786988/8b23c4ac-52c1-458b-b6df-0435cfa372ea)


#### Props:  
info- Text that you want to display in the box.

```
<Tooltip info="This is the info you want to share!!"></Tooltip>
```

## Tabscommon
To implement Tabs like this, you can call this Component.

![tabscommon](https://github.com/Couture-ai/UI-Artifactory/assets/121786988/ef6f7c72-17e8-4242-8287-347a884bfc1f)

#### Props:  
tabList - Array of names of tabs that you want to display.

```
 const tabList = [
    {
      name: 'Search'
    },
    {
      name: 'Category Pages'
    }
  ];

<TabsCommon w="100%" tabList={tabList}></TabsCommon>
```

## List -> ListItemTeam
For a table like this in which when a username is clicked a window opening in the right drawer, this component can be used.

![team](https://github.com/Couture-ai/UI-Artifactory/assets/121786988/c81ae9af-b085-4bf3-b622-a48a1bcb4abf)

#### Props:  
key <br />
value <br />
isOpen - from useDisclosure() <br />
onClose - from useDisclosure() <br />
btnRef - useRef hook <br />
drawerName - name that is displayed in the right drawer <br />
drawerEmail - emailthat is displayed in the right drawer <br />
drawerAccessLevel - access level that is displayed in the right drawer <br />
drawerAbout - about that is displayed in the right drawer <br />
drawerImageUrl - imagethat is displayed in the right drawer <br />
handleDelete - function to delete a user <br />
onEdit - function to edit info of a user <br />
onClickKey - to set the drawer name email, about, etc. when a username is clicked. <br />

```
<ListItemTeam
   key={value.id}
   value={value}
   isOpen={isOpen}
   onClose={onClose}
   btnRef={btnRef}
   drawerName={drawerName}
   drawerEmail={drawerEmail}
   drawerAccessLevel={drawerAccessLevel}
   drawerAbout={drawerAbout}
   drawerImageUrl={drawerImageUrl}
   handleDelete={handleDelete}
   onEdit={onEdit}
   onClickKey={onClickKey}
 />
```

## Card
Card returns a Box with white background, full width and some box shadow.
It does not take any props.
You can put your content inside a Card component.

```
<Card>
/* Rest of the content */
</Card>
```

## CalendarComp
It is used to display a calendar where user can select a range of dates and it is set to the variable range

![calendarcomp](https://github.com/Couture-ai/UI-Artifactory/assets/121786988/cb245e56-f939-427a-a836-4be2c8bb51ca)

#### Props:  
range - Initially set the end date to the current date and initial date to one week before today’s date and it is updated when user selects a range <br />

setRange - function to update the range <br />

#### Packages needed:
npm install date-fns react-date-range

```
const [range, setRange] = useState([
    {
      startDate: addDays(new Date(), -7),
      endDate: new Date(),
      key: 'selection'
    }
  ]);


<CalendarComp range={range} setRange={setRange} />
```

## Dialog
If you want to open a dialog box/window on click of a button or something, this component will be useful.

![modal](https://github.com/Couture-ai/UI-Artifactory/assets/121786988/c64b3bbf-dd1c-4f6a-b25c-199a38faf8ce)

#### Props:  
open - variable to denote if the dialog box is open or not <br />
onClose - Function to set the open variable to false on clicking close button <br />
handleSubmit - function to describe what happens when user clicks submit in the dialog box <br />
Header - Heading that you want to display in the box. <br />

```
const [open, setOpen] = useState({ open: false, data: null });
  const handleSubmit = () => {
    console.log("submitted!!")
  };


<Dialog
      open={open.open}
      onClose={() => setOpen({ open: false, data: null })}
      handleSubmit={handleSubmit}
      header="Choose SKUs">
      <Box mt={4}>
        hi
      </Box>
    </Dialog>
```

## DialogBox
If you have some search queries results and if you want to open a dialogbox which shows analytics of that query result like clicks, impressions, etc. ypu can use this component.  
#### Props:  
isDialogData  
dialogDataError  
isOpen  
onClose  
isFooter  
dialogData  
query  
searches  
avgClickCount  
ctr  
conversion  
item  
index  
modalHeader  

All these props are the data that is to be displayed in the modal box as shown in the below image.
![dialogbox](https://github.com/Couture-ai/UI-Artifactory/assets/121786988/ba95b349-f24f-41fe-943f-7ed3bb6bec80)

```
<DialogBox
    isDialogData={isDialogData}
    dialogDataError={dialogDataError}
    isOpen={isOpen}
    onClose={onClose}
    isFooter={false}
    dialogData={itemModal}
    query={queryModal}
    searches={searchesModal}
    avgClickCount={avgClickCountModal}
    ctr={ctrModal}
    conversion={conversionModal}
    item={itemModal}
    index={isClickIndex}
    modalHeader={modalHeader}
  />
```

### TableCommon
In a table to get the labels of the columns in a header in first row, you can use this component  

Props:  
header- array of column names with name attribute for each.  

![tablecommon](https://github.com/Couture-ai/UI-Artifactory/assets/121786988/b9f744e6-3a16-4c44-8554-f021d63dccdd)

```
const header = [
    {
      name: 'Kit Name'
    },
    {
      name: 'Kit ID'
    },
    {
      name: 'SKUs Included'
    },
    {
      name: 'Creation'
    },
    {
      name: 'Modification'
    },
    {
      name: 'Actions'
    }
  ];
<TableCommon maxH="64vh" header={header}></TableCommon>
```

## TableCard
To get the common parts of table i.e a download button and pagination of table rows at the end of the table you can use this component.
Props:  
page  
pageSize  
setPage  
setPageSize  
data  
totalData  
isGlobalSearch  

All these props are related to pagination.  

![tablecard](https://github.com/Couture-ai/UI-Artifactory/assets/121786988/5aa700de-ecdb-4e53-b76d-901b55957fc6)
```
<TableCard
  page={page}
  pageSize={pageSize}
  setPage={setPage}
  setPageSize={setPageSize}
  data={itemList ? itemList.zcr : null}
  totalData={totalData}
  isGlobalSearch={false}>
```

## BarGraphChart
#### Props:  
data: The data prop represents the data array that you want to display in the bar chart. Each data point should have properties corresponding to the keys used in other props.  

height: The height prop sets the height of the bar chart component.  

width: The width prop sets the width of the bar chart component.  

marginTop, marginRight, marginLeft, marginBottom: These props define the margins (spacing) around the bar chart component.  

isBarSize: The isBarSize prop is a boolean that determines whether the bar size should be fixed or responsive. If set to true, the bar size will be fixed based on the barSize prop value.  

barSize: The barSize prop specifies the width of each bar in the chart when isBarSize is set to true.  

dataKey: The dataKey prop specifies the key of the data points in the data array that corresponds to the values you want to display as bars.  

isXAxisTick: The isXAxisTick prop is a boolean that determines whether to display the x-axis tick marks.  

dataKeyXAxis: The dataKeyXAxis prop specifies the key of the data points in the data array that corresponds to the values you want to display as labels on the x-axis.  

isLegend: The isLegend prop is a boolean that determines whether to display the legend for the chart.  

isTooltip: The isTooltip prop is a boolean that determines whether to display tooltips when hovering over the bars.  

![bargraphchart](https://github.com/Couture-ai/UI-Artifactory/assets/121786988/28630983-479f-47a7-a843-36d1d535300e)

```
const sessionsData = [
    {
      name: 'M',
      Sessions: 4000,
      color: '#1AADEC'
    },
    {
      name: 'T',
      Sessions: 3000,
      color: '#1AADEC'
    },
    {
      name: 'W',
      Sessions: 2000,
      color: '#1AADEC'
    },
    {
      name: 'T',
      Sessions: 2780,
      color: '#1AADEC'
    },
    {
      name: 'F',
      Sessions: 1890,
      color: '#1AADEC'
    },
    {
      name: 'S',
      Sessions: 2390,
      color: '#1AADEC'
    },
    {
      name: 'S',
      Sessions: 3490,
      color: '#1AADEC'
    }
  ];
  
  <BarGraphChart
      data={sessionsData}
      height={250}
      width={300}
      marginTop={20}
      marginRight={30}
      marginLeft={10}
      marginBottom={5}
      isBarSize={true}
      barSize={10}
      dataKey={'Sessions'}
      isXAxisTick={true}
      dataKeyXAxis={'name'}
      isLegend={false}
      isTooltip={true}
    />
```

## LineGraphChart
#### Props:  
width (number): Specifies the width of the chart in pixels.  

height (number): Specifies the height of the chart in pixels.  

margin (object): Defines the margins around the chart. It contains four properties:  

top (number): Specifies the top margin in pixels.  
right (number): Specifies the right margin in pixels.  
left (number): Specifies the left margin in pixels.  
bottom (number): Specifies the bottom margin in pixels.  
data (array): Represents the data used to plot the line graph. It should be an array of objects, with each object representing a data point.  

label (string or array): Specifies the label(s) for the line(s) in the graph. It can be a single string or an array of strings if multiple lines are being plotted.  

isXAxis (boolean): Determines whether to display the X-axis. If set to true, the X-axis will be shown.  

isYAxis (boolean): Determines whether to display the Y-axis. If set to true, the Y-axis will be shown.  

isTooltip (boolean): Specifies whether to display a tooltip when hovering over data points. If set to true, a tooltip will be shown.  

type (string): Specifies the type of scale to use for the axes. Possible values include 'linear' (default), 'logarithmic', 'pow', 'sqrt', 'time', etc.  

![linegraphchart](https://github.com/Couture-ai/UI-Artifactory/assets/121786988/3dcadba3-62c6-410e-b483-a06dbbfc0aee)

```
const tryoutsAreaData = [
    {
      name: 'M',
      Lipstick: 4000,
      Eyeliner: 3900,
      Concealer: 3800,
      Blush: 3700,
      Eyeshadow: 3600,
      Foundation: 3500,
      Mascara: 3400,
      colorLips: '#2E69AE',
      colorEyeliner: '#099E95',
      colorConcealer: '#CA5D0D',
      colorBlush: '#9C2EAE',
      colorEyeshadow: '#C2354F',
      colorFoundation: '#C98621',
      colorMascara: '#BB5A72'
    },
    {
      name: 'T',
      Lipstick: 3000,
      Eyeliner: 2900,
      Concealer: 2800,
      Blush: 2700,
      Eyeshadow: 2600,
      Foundation: 2500,
      Mascara: 2400,
      colorLips: '#2E69AE',
      colorEyeliner: '#099E95',
      colorConcealer: '#CA5D0D',
      colorBlush: '#9C2EAE',
      colorEyeshadow: '#C2354F',
      colorFoundation: '#C98621',
      colorMascara: '#BB5A72'
    },
    {
      name: 'W',
      Lipstick: 2000,
      Eyeliner: 1900,
      Concealer: 1800,
      Blush: 1700,
      Eyeshadow: 1600,
      Foundation: 1500,
      Mascara: 1400,
      colorLips: '#2E69AE',
      colorEyeliner: '#099E95',
      colorConcealer: '#CA5D0D',
      colorBlush: '#9C2EAE',
      colorEyeshadow: '#C2354F',
      colorFoundation: '#C98621',
      colorMascara: '#BB5A72'
    }
  ];
  <LineGraphChart
        width={900}
        height={500}
        margin={{
          top: 10,
          right: 30,
          left: 0,
          bottom: 0
        }}
        data={tryoutsAreaData}
        label={legendData}
        // checkedItems={checkedItems}
        isXAxis={true}
        isYAxis={true}
        isTooltip={true}
        type={'linear'}></LineGraphChart>
```

## TryoutPie / UsersPieChart

To get a piechart we can use this component.  
#### Props:  
data: Data that you want to display in the piechart with each object containing name, value and color. 

![tryoutpie](https://github.com/Couture-ai/UI-Artifactory/assets/121786988/deaaf46d-dc95-411a-b3cf-29974965dc0b)

```
const data = [
    {
      name: 'Lipstick',
      value: 4000,
      color: '#2E69AE'
    },
    {
      name: 'Eye Liner',
      value: 3000,
      color: '#099E95'
    },
    {
      name: 'Concealer',
      value: 2000,
      color: '#CA5D0D'
    },
    {
      name: 'Blush',
      value: 2780,
      color: '#9C2EAE'
    },
    {
      name: 'Eye Shadow',
      value: 1890,
      color: '#C2354F'
    },
    {
      name: 'Foundation',
      value: 2390,
      color: '#C98621'
    },
    {
      name: 'Mascara',
      value: 3490,
      color: '#BB5A72'
    }
  ];
  <TryoutPie data={data} />
```

## FileUploader

To open a window to select files from your pc to upload, this component can be used.  
![FileUploader](https://github.com/Couture-ai/UI-Artifactory/assets/121786988/d147ab58-6d2d-4f55-93ef-876893cf9b09)

### Props:  
fileInput: This is a ref created using useRef hook that is assigned to null initially.  
handleFiles: You can write your logic/functionality for the uploaded files in this function. It will be called as soon as a file is selected.  
handleButtonClick: This function is to open the file select popup on click of button.

```
const fileInput = useRef(null);

  const handleFiles = (fileList) => {
    if (fileList) {
      console.log(fileList);
    }
  };

  const handleClick = () => {
    if (fileInput && fileInput.current) {
      fileInput.current.click();
    }
  };

<FileUploader handleButtonClick={handleClick} fileInput={fileInput} handleFiles={handleFiles}/>
```


## ProductBox  
To display product cards like this with name, price, etc. you can use this component.    
  
![productbox](https://github.com/Couture-ai/UI-Artifactory/assets/121786988/1bd67fed-5d83-4581-a3a0-c6a6efe0fff7)  

### Props:  
key - key to identify each product uniquely.  
product - looping through products array which contains name, price, brand name, etc. of each product.  

```
{products && Object.keys(products).length > 0 ? (
        <Flex
          w="100%"
          position="relative"
          mt={3}
          mr={4}
          flexDir={"column"}
          style={{ alignItems: "center", justifyContent: "center" }}
        >
          <Grid
            templateColumns={"repeat(4, 1fr)"}
            margin="auto"
            w="100%"
            gap={3}
            marginTop={0}
            mr={4}
          >
            {paginatedData?.map((product, i) => (
              <ProductBox key={keys[i]} product={product} />
            ))}
          </Grid>
```
Note: You need to call each ProducctBox inside a Grid as our ProductBox component displays each card as a Grid Item.  

## Fourier Transform  
Chart for fourier transform with amplitude on x-axis and frequency on y-axis.

### Props: 
fourierData -  an array of objects where each object contains frequency and amplitude values
Example -
const fourierData = [{frequency: 0, amplitude: 0},
{frequency: 0.0027397260273972603, amplitude: 0},
{frequency: 0.005479452054794521, amplitude: 0}, 
{frequency: 0.008219178082191782, amplitude: 0},
{frequency: 0.010958904109589041, amplitude: 0}]

```
<FourierTransform fourierData={props.fourierData} />
```

## Linear Regression
Chart for linear regression with date on x-axis and a specific key on y-axis

### Props: 
seasonalityData - regressionData containing array of objects containing date and the required datakey. For below example, you can disaplay date column on x-axis and a regression line with sales as keyvalue. You can draw multiple lines but duplicating the <Line/>.
0
: 
{date: '2022-05-01T00:00:00', sales: 0}
1
: 
{date: '2022-05-02T00:00:00', sales: 0}
2
: 
{date: '2022-05-03T00:00:00', sales: 0}
3
: 
{date: '2022-05-04T00:00:00', sales: 0}
4
: 
{date: '2022-05-05T00:00:00', sales: 0}

```
<LinearRegression seasonalityData={props.seasonalityData} />
```

## Word Cloud
Word Cloud based on frequency of an item.

```
const [wordCloudData, setWordCloudData] = useState([]);

  useEffect(() => {
    const fetchData = async () => {
      try {
        Papa.parse(csvFile, {
          download: true,
          complete: function (input) {
            const records = input.data;
            setWordCloudData(records);
          }
        });
      } catch (error) {
        console.error('Error reading CSV data:', error);
      }
    };

    fetchData();
  }, []);

  const wordCloudFormattedData = wordCloudData.slice(1).map((row) => ({
    text: row[2], // Assuming 'Attribute set' is the third column
    value: parseInt(row[3], 10) // Assuming 'Number of products' is the fourth column
  }));

  const options = {
    rotations: 0,
    fontSizes: [10, 60], // adjust font size range as needed
    maxFontSize: 20,
    enableOptimizations: true
  };

  return (
    <div style={{ width: '45vw', height: '250px', overflow: 'auto' }}>
      <ReactWordcloud words={wordCloudFormattedData} options={options} />
    </div>
  );
};
```

You need to import the appropriate csvFile from which the wordCloud needs to be created.


## Scatter Chart

### Props: 
data: array of coordinate points with x,y,z dimensions
width: width of chart
height: height of chart
xname: x label when a scatter point is hovered
yname: y label when a scatter point is hovered

```
const data = [
  { x: 100, y: 200, z: 200 },
  { x: 120, y: 100, z: 260 },
  { x: 170, y: 300, z: 400 },
  { x: 140, y: 250, z: 280 },
  { x: 150, y: 400, z: 500 },
  { x: 110, y: 280, z: 200 }
];

<SimpleScatterChart data={data} width="80%" height={400} xname="stature" yname="weight" />
```


## Area Graph Chart

### Props: 
data: array of coordinate points with name, and coordinates
width: width of chart
height: height of chart
area1: name of area1
area2: name of area2
area3: name of area3

```
const data = [
  {
    name: 'Page A',
    uv: 4000,
    pv: 2400,
    amt: 2400
  },
  {
    name: 'Page B',
    uv: 3000,
    pv: 1398,
    amt: 2210
  },
  {
    name: 'Page C',
    uv: 2000,
    pv: 9800,
    amt: 2290
  },
  {
    name: 'Page D',
    uv: 2780,
    pv: 3908,
    amt: 2000
  },
  {
    name: 'Page E',
    uv: 1890,
    pv: 4800,
    amt: 2181
  },
  {
    name: 'Page F',
    uv: 2390,
    pv: 3800,
    amt: 2500
  },
  {
    name: 'Page G',
    uv: 3490,
    pv: 4300,
    amt: 2100
  }
];

<AreaGraphChart data={data} area1="uv" area2="pv" area3="amt" width="500" height="400" />
```


## Map Chart

### Props: 
data: objects containing state name and the number we want to display
maptitle: title of the map
legendtitle: title of the legend below


```
const data = {
  'Andaman & Nicobar Island': {
    value: 150
  },
  'Andhra Pradesh': {
    value: 470
  },
  'Arunanchal Pradesh': {
    value: 248
  },
  Assam: {
    value: 528
  },
  Bihar: {
    value: 755
  },
  Chandigarh: {
    value: 95
  },
  Chhattisgarh: {
    value: 1700
  },
  Delhi: {
    value: 1823
  },
  Goa: {
    value: 508
  },
  Gujarat: {
    value: 624
  },
  Haryana: {
    value: 1244
  },
  'Himachal Pradesh': {
    value: 640
  },
  'Jammu & Kashmir': {
    value: 566
  },
  Jharkhand: {
    value: 814
  },
  Karnataka: {
    value: 2482
  },
  Kerala: {
    value: 899
  },
  Lakshadweep: {
    value: 15
  },
  'Madhya Pradesh': {
    value: 1176
  },
  Maharashtra: {
    value: 727
  },
  Manipur: {
    value: 314
  },
  Meghalaya: {
    value: 273
  },
  Mizoram: {
    value: 306
  },
  Nagaland: {
    value: 374
  },
  Odisha: {
    value: 395
  },
  Puducherry: {
    value: 245
  },
  Punjab: {
    value: 786
  },
  Rajasthan: {
    value: 1819
  },
  Sikkim: {
    value: 152
  },
  'Tamil Nadu': {
    value: 2296
  },
  Telangana: {
    value: 467
  },
  Tripura: {
    value: 194
  },
  'Uttar Pradesh': {
    value: 2944
  },
  Uttarakhand: {
    value: 1439
  },
  'West Bengal': {
    value: 1321
  }
};

<MapChart data={data} maptitle="deployed per state in india" legendtitle="number of ..."></MapChart>
```


## Stacked Bar Chart

### Props: 
data

```
const data = [
  {
    name: 'Page A',
    uv: 4000,
    pv: 2400,
    amt: 2400
  },
  {
    name: 'Page B',
    uv: 3000,
    pv: 1398,
    amt: 2210
  },
  {
    name: 'Page C',
    uv: 2000,
    pv: 9800,
    amt: 2290
  },
  {
    name: 'Page D',
    uv: 2780,
    pv: 3908,
    amt: 2000
  },
  {
    name: 'Page E',
    uv: 1890,
    pv: 4800,
    amt: 2181
  },
  {
    name: 'Page F',
    uv: 2390,
    pv: 3800,
    amt: 2500
  },
  {
    name: 'Page G',
    uv: 3490,
    pv: 4300,
    amt: 2100
  }
];

<StackedBarChart data={data}></StackedBarChart>
```


## Horizontal Stacked Bar Chart

### Props: 
data
categoryNames : category names that should come on x-axis
title: title of the bar chart

```
const horizontalStackData = [
  {
    name: 'Pharma',
    data: [44, 55, 41, 37],
    color: '#001F3F'
  },
  {
    name: 'A',
    data: [53, 32, 33, 52],
    color: '#005B96'
  },
  {
    name: 'B',
    data: [12, 17, 11, 9],
    color: '#4D94DB'
  },
  {
    name: 'C',
    data: [9, 7, 5, 8],
    color: '#71B2E5'
  },
  {
    name: 'Non Pharma',
    data: [25, 12, 19, 32],
    color: '#93C8EF'
  }
];

const categoryNames = ['West', 'South', 'North', 'East Zone'];
const title = 'L0 Category';

<HorizontalStackedBarChart data={horizontalStackData} categoryNames={categoryNames} title={title}></HorizontalStackedBarChart>
```

## Map Chart

Use it to display India Map

![image](https://github.com/Couture-ai/UI-Artifactory/assets/121786988/bcc13252-f087-420d-af5b-97b7ad777834)


### Props:
statesData: contains mapping of eac state name to the ineteger that u want to showcase
zone


## Ring Pie Chart

### Props: 
data
labels : category names that should come on x-axis
title: title of the bar chart

```
const labels: ['Cipla', 'Dr Reddys', 'Apollo', 'Natco', 'Pharma']
const data = [44, 55, 41, 17, 15];
const title = 'L0 Category';

<RingPieChart data={data} title={title} labels={labels}></RingPieChart>
```













