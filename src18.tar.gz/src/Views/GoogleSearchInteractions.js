/* eslint-disable no-unused-vars */

import {
  Accordion,
  AccordionButton,
  AccordionIcon,
  AccordionItem,
  AccordionPanel,
  Box,
  ChakraProvider,
  Divider,
  Flex,
  Grid,
  IconButton,
  Image,
  Select,
  Spacer,
  Text,
  useTheme
} from '@chakra-ui/react';
import { ChevronLeftRounded, ChevronRightRounded } from '@mui/icons-material';
import axios from 'axios';
import React, { useEffect, useState } from 'react';
// import { populateData } from '../api/FetchDataAPI';
import HoverTextBox from '../Artifactory/Components/HoverTextBox/HoverTextBox';

const ImageHandler = (entry, theme) => {
  return (
    <Flex direction={'column'}>
      <Image src={entry.image_url} h={'120px'} w={'100px'} />
      <Flex gap={'0'} direction={'column'} marginTop={'10px'}>
        <Text
          style={{
            fontWeight: 'bold',
            fontSize: '16px',
            color: `${theme.colors.primary.main}`
          }}>
          {entry.brandname}
        </Text>
        <Text
          style={{
            fontSize: '16px',
            color: `${theme.colors.gray.main}`
          }}>
          {entry.productid}
        </Text>
      </Flex>
    </Flex>
  );
};

const GoogleSearchInteractions = () => {
  const theme = useTheme();

  const initialState = {
    loading: false,
    err: false,
    data: []
  };

  const [topQueries, setTopQueries] = useState(initialState);

  useEffect(() => {
    // const requestBody = {
    //   page_no: 1,
    //   page_count: 50
    // };
    // populateData('top-search-interactions', setTopQueries, requestBody);
  }, []);

  const [country, setCountry] = useState('INDIA');

  const handleChange = (event) => {
    const selectedCountry = event.target.value;
    setCountry(selectedCountry);
  };

  const [page, setPage] = useState(1);
  const pageSize = 10;

  const handlePagination = () => {
    if (
      topQueries.data.count === topQueries.data.data.length ||
      page < Math.floor(topQueries.data.data.length / 100)
    ) {
      return;
    }
    const requestBody = {
      page_no: page === 1 ? 2 : Math.floor(page / 5) + 2, // Set the page number
      page_count: 50
    };
    let config = {
      method: 'post',
      url: `${process.env.REACT_APP_API_BASE_URL}/couture/fast-fashion/top-search-interactions`,
      data: requestBody,
      withCredentials: true
    };

    axios(config)
      .then(async (response) => {
        setTopQueries((prevData) => ({
          data: {
            data: [...prevData.data.data, ...response.data.data],
            count: response.data.count // Keep the total_count intact
          }
        }));
      })
      .catch(function () {
        console.log('error');
      });
  };

  const [paginatedData, setPaginatedData] = useState(null);
  const paginate = () => {
    const start = page * pageSize - pageSize;
    const end = page * pageSize;
    setPaginatedData(topQueries?.data?.data?.slice(start, end));
  };

  useEffect(() => {
    paginate();
  }, [pageSize, page, topQueries.data.data]);

  return (
    <Box style={{ padding: '20px 0' }}>
      <Flex direction="column" style={{ padding: '15px' }} gap={'10px'}>
        <Flex direction={'column'}>
          <Text
            style={{
              fontWeight: 'bold',
              fontSize: '22px',
              fontFamily: 'Jost'
            }}>
            Google Search Trends
          </Text>
          <Box
            w="80px"
            h="4px"
            borderRadius={'3px'}
            my={3}
            backgroundColor={theme.colors.primary.main}
          />
        </Flex>
        <Text
          style={{
            fontSize: '16px',
            fontFamily: 'Jost',
            color: `${theme.colors.gray.main}`
          }}>
          Find out what others are searching in Google along with Related Queries and Top Trending
          searches
        </Text>
      </Flex>
      <Flex
        bg={theme.colors.white}
        w={'100%'}
        p={'15px'}
        justifyContent={'center'}
        alignItems={'center'}>
        <Flex direction="column" w="80%" pt={5}>
          <Flex w="100%" alignItems={'center'} justifyContent={'center'} marginBottom={'10px'}>
            <Text
              fontSize={'18px'}
              bg={theme.colors.gray.lighter}
              px={3}
              py={1}
              borderRadius={'15px'}
              color={theme.colors.gray.main}>
              April 25 - May 2, 2024
            </Text>
            <Spacer />
            <ChakraProvider>
              <Flex w="200px">
                <Select placeholder="Select option" value={country} onChange={handleChange}>
                  <option value="INDIA">India</option>
                  <option value="USA">United States of America</option>
                  <option value="UK">United Kingdom</option>
                </Select>
              </Flex>
            </ChakraProvider>
          </Flex>
          <Flex direction="row" alignItems="center" justifyContent={'center'} w="100%" h="100%">
            <Flex direction={'column'} w="100%">
              <Flex
                alignItems="center"
                justifyContent="center"
                style={{
                  fontSize: '24px',
                  backgroundColor: `${theme.colors.white}`,
                  borderRadius: '0'
                }}>
                <Accordion allowToggle w={'100%'}>
                  {paginatedData?.map((entry, index) => {
                    return (
                      <AccordionItem
                        key={index + 1}
                        justifyContent={'center'}
                        alignItems={'center'}
                        style={{
                          fontSize: '24px',
                          backgroundColor: `${theme.colors.white}`,
                          borderTopLeftRadius: '10px',
                          borderTopRightRadius: '10px',
                          boxShadow: '-2px -2px 50px #00000008, 2px 2px 50px #00000008',
                          borderBottom: `1px solid ${theme.colors.gray.light}`,
                          padding: '2%'
                        }}>
                        <AccordionButton>
                          <Flex
                            w={'100%'}
                            direction={'row'}
                            justifyContent={'flex-start'}
                            alignItems={'center'}
                            padding={'5px 20px'}>
                            <Flex w={'100%'} justifyContent={'flex-start'} alignItems={'center'}>
                              <Text fontSize="xl">
                                {entry.category.split(' ').map((e) => {
                                  return e.charAt(0).toUpperCase() + e.slice(1) + '  ';
                                })}
                              </Text>
                            </Flex>
                            <Flex w={'20%'} direction={'column'} alignItems={'flex-start'}>
                              <Text fontSize={'24px'} as="b" textAlign="left">
                                {entry.number_of_searches}
                              </Text>
                              <Text fontSize={'16px'} textAlign="left">
                                Total Searches
                              </Text>
                            </Flex>
                          </Flex>
                          <AccordionIcon color={theme.colors.primary.main} />
                        </AccordionButton>

                        <AccordionPanel p={'25px'} paddingTop={'30px'}>
                          <Flex direction={'column'} gap={'30px'}>
                            <Flex direction={'row'} gap={'50px'}>
                              <Flex direction={'column'} w={'65%'} gap={'20px'}>
                                <Text fontSize={'16px'} color={theme.colors.gray.main}>
                                  Related Top Queries
                                </Text>
                                <Flex direction={'row'} flexWrap="wrap" gap={'20px'}>
                                  {entry.related_top_searches.slice(0, 10).map((query, index) => {
                                    return <HoverTextBox key={index + 1} content={query} />;
                                  })}
                                </Flex>
                              </Flex>
                              <Flex direction={'column'} w={'35%'} gap={'20px'}>
                                <Text fontSize={'16px'} color={theme.colors.gray.main}>
                                  Related Rising Queries
                                </Text>
                                <Flex direction={'row'} flexWrap="wrap" gap={'20px'}>
                                  {entry.related_rising_searches
                                    .filter((query) => query !== null) // Filter out null values
                                    .map((query, index) => (
                                      <HoverTextBox key={index + 1} content={query} />
                                    ))}
                                </Flex>
                              </Flex>
                            </Flex>
                            <Divider borderWidth={'10px'} />
                            <Flex direction={'column'} gap={'20px'}>
                              <Text fontSize={'16px'} color={theme.colors.gray.main}>
                                Top interacted products in this query on AJIO
                              </Text>
                              <Grid templateColumns="repeat(5, 1fr)" gap={'20px'}>
                                {entry.products.map((product) => {
                                  return ImageHandler(product, theme);
                                })}
                              </Grid>
                            </Flex>
                          </Flex>
                        </AccordionPanel>
                      </AccordionItem>
                    );
                  })}
                </Accordion>
              </Flex>
            </Flex>
          </Flex>
          <Flex justifyContent="center" alignItems="center" my={5} mx={10}>
            <IconButton
              onClick={() => setPage(page - 1)}
              disabled={page === 1}
              size="sm"
              variant="iconOutline">
              <ChevronLeftRounded />
            </IconButton>
            <Text fontSize="14px" size="sm" p={5}>
              Page {page} of {Math.ceil(topQueries.data.count / pageSize)}
            </Text>
            <IconButton
              variant="iconOutline"
              onClick={() => {
                if (page !== Math.ceil(topQueries.data.count / pageSize)) {
                  setPage(page + 1);
                  if (pageSize === 10) {
                    if (page % 10 === 0 || page === 1) {
                      handlePagination();
                    }
                  } else if (page % 5 === 0 || page === 1) {
                    handlePagination();
                  }
                }
              }}
              isDisabled={page === Math.ceil(topQueries.data.count / pageSize)}
              size="sm">
              <ChevronRightRounded />
            </IconButton>
          </Flex>
        </Flex>
      </Flex>
    </Box>
  );
};

export default GoogleSearchInteractions;
