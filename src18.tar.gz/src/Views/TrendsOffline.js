/* eslint-disable no-unused-vars */
import {
  Box,
  ChakraProvider,
  Flex,
  Grid,
  ListItem,
  Popover,
  PopoverArrow,
  PopoverContent,
  PopoverTrigger,
  Text,
  UnorderedList,
  useTheme
} from '@chakra-ui/react';
import { InfoOutlined } from '@mui/icons-material';
import axios from 'axios';
import React, { useEffect, useState, useRef } from 'react';
import TreeMap from '../Artifactory/Charts/TreeMap';
import CustomTable from '../Artifactory/Components/Table/Table';
import {
  fetchFiltersGeneric,
  fetchInitialFiltersGeneric,
  handlePaginationFunction,
  populateData,
  populateDataTwice,
  updateFiltersOnClick
} from '../api/FetchDataAPI';
import ShowSelectedFilters from '../components/Filter/ShowSelectedFilters';
import NewPopover from '../components/NewPopover';
import { tableInitialState, useStyles } from '../util/util_functions';
import GoToTopButton from '../Artifactory/Components/GoToTopButton/GoToTopButton';
import CustomSankeyChart from '../Artifactory/Charts/CustomSankeyChart';
import ChartContainer from '../components/ChartContainer';
import SelectCharts from '../components/SelectCharts';
import PaginationButton from '../Artifactory/Components/PaginationButton/PaginationButton';
import ImageContainerSkeleton from '../components/ImageContainer/ImageContainerSkeleton';
import ImageContainer from '../components/ImageContainer/ImageContainer';

const categories = [
  { key: 'brands', label: 'Brands' },
  { key: 'styleTypes', label: 'Style types' },
  { key: 'fabrics', label: 'Fabrics' },
  { key: 'colors', label: 'Colors' },
  { key: 'patterns', label: 'Patterns' },
  { key: 'necklines', label: 'Necklines' },
  { key: 'sleeves', label: 'Sleeve lengths' }
];

const TrendsOffline = () => {
  const chakratheme = useTheme();
  const styles = useStyles(chakratheme);

  const bestSellerHeaders = [
    {
      name: 'Product Image',
      id: 'image_url',
      sort: '',
      colSpan: 3,
      // type: 'image_with_url',
      type: 'image_trends',
      url: true
    },
    { name: 'Item ID', id: 'itemid', sort: '', colSpan: 2, type: 'text' },
    {
      name: 'Brand',
      id: 'brandname',
      sort: '',
      colSpan: 2,
      type: 'text'
    },
    {
      name: 'mh_family',
      id: 'mh_family_desc',
      sort: '',
      colSpan: 2,
      type: 'text'
    },
    {
      name: 'mh_brick',
      id: 'brickname',
      sort: '',
      colSpan: 2,
      type: 'text'
    },
    {
      name: 'mh_class',
      id: 'mh_class_desc',
      sort: '',
      colSpan: 2,
      type: 'text'
    },
    { name: 'Style', id: 'styletype', sort: '', colSpan: 2, type: 'text' },
    {
      name: 'ROS',
      id: 'weekly_rate_of_sale',
      sort: 'desc',
      colSpan: 1,
      type: 'text',
      toolTip: true,
      toolTipText: 'Average number of products sold per week'
    },
    {
      name: 'Total qty',
      id: 'total_qty',
      sort: '',
      colSpan: 2,
      type: 'text'
    },
    {
      name: 'Primary color',
      id: 'primarycolor',
      sort: '',
      colSpan: 2,
      type: 'text'
    },
    { name: 'pattern', id: 'pattern', sort: '', colSpan: 2, type: 'text' },
    {
      name: 'Fabric type',
      id: 'fabrictype',
      sort: '',
      colSpan: 2,
      type: 'text'
    },
    {
      name: 'Material type',
      id: 'materialtype',
      sort: '',
      colSpan: 2,
      type: 'text'
    },
    { name: 'Sleeve', id: 'sleeve', sort: '', colSpan: 2, type: 'text' },
    { name: 'Fit', id: 'fit', sort: '', colSpan: 2, type: 'text' },
    {
      name: 'Neckline',
      id: 'neckline',
      sort: '',
      colSpan: 2,
      type: 'text'
    }
  ];

  const [bestProductsTableState, setBestProductsTableState] = useState(
    tableInitialState(1, 'weekly_rate_of_sale', 'desc')
  );

  const [bestSellersTableState, setBestSellersTableState] = useState(
    tableInitialState(1, 'weekly_rate_of_sale', 'desc')
  );

  const initialState = {
    loading: false,
    err: false,
    data: []
  };

  const [nestedData, setNestedData] = useState(initialState);

  const [filterHeadings, setFilterHeadings] = useState([]);
  const [levelNames, setLevelNames] = useState({});

  const [initialFilters, setInitialFilters] = useState({});

  useEffect(() => {
    if (nestedData?.data) {
      const headings = Object.keys(nestedData.data);
      const updatedLevelNames = {};
      Object.keys(nestedData.data).forEach((filter) => {
        updatedLevelNames[filter] = Object.keys(nestedData.data[filter]);
      });
      setFilterHeadings(headings);
      setLevelNames(updatedLevelNames);
    }
  }, [nestedData]);

  useEffect(() => {
    setSelectedFilters(initialFilters);
    if (Object.keys(initialFilters).length !== 0) {
      fetchFilters(initialFilters);
    }
  }, [initialFilters]);

  const [selectedFilters, setSelectedFilters] = useState(initialFilters);

  const [bestSellerProducts, setBestSellerProducts] = useState(initialState);
  const [trendsFabricData, setTrendsFabricData] = useState(initialState);
  const [trendsBrandData, setTrendsBrandData] = useState(initialState);
  const [trendsPatternData, setTrendsPatternData] = useState(initialState);
  const [trendsColorData, setTrendsColorData] = useState(initialState);
  const [trendsStyleData, setTrendsStyleData] = useState(initialState);
  const [trendsSleeveData, setTrendsSleeveData] = useState(initialState);
  const [trendsNecklineData, setTrendsNecklineData] = useState(initialState);
  const [bestSellerProductsImages, setBestSellerProductsImages] = useState(initialState);

  useEffect(() => {
    if (
      (selectedFilters.duration && selectedFilters.duration.length != 0) ||
      (selectedFilters.demographic && selectedFilters.demographic.length != 0) ||
      (selectedFilters.attributes && selectedFilters.attributes.length != 0) ||
      (selectedFilters.store_filters && selectedFilters.brick_filters.length != 0) ||
      (selectedFilters.category && selectedFilters.category.length != 0)
    ) {
      if (cancelTokenSource1.current) {
        cancelTokenSource1.current.cancel('Operation canceled due to new request.');
      }
      // Create a new cancel token source
      cancelTokenSource1.current = axios.CancelToken.source();

      const token = cancelTokenSource1.current.token;
      const requestBody = {
        nested_data: {
          duration: selectedFilters.duration,
          demography: selectedFilters.demographic,
          attributes: selectedFilters.attributes,
          store_filters: selectedFilters.store_filters,
          category: selectedFilters.category
        },
        page_no: 1, // Set the page number
        sort_param: bestProductsTableState.sort_param,
        sort_type: bestProductsTableState.sort_type
      };

      populateDataTwice(
        'bestsellers-products-trends',
        setBestSellerProducts,
        requestBody,
        setBestSellerProductsImages,
        token
      );
    }
  }, [selectedFilters]);

  useEffect(() => {
    if (
      (selectedFilters.duration && selectedFilters.duration.length != 0) ||
      (selectedFilters.demographic && selectedFilters.demographic.length != 0) ||
      (selectedFilters.attributes && selectedFilters.attributes.length != 0) ||
      (selectedFilters.store_filters && selectedFilters.brick_filters.length != 0) ||
      (selectedFilters.category && selectedFilters.category.length != 0)
    ) {
      if (cancelTokenSource3.current) {
        cancelTokenSource3.current.cancel('Operation canceled due to new request.');
      }
      // Create a new cancel token source
      cancelTokenSource3.current = axios.CancelToken.source();

      const token = cancelTokenSource3.current.token;
      const requestBody = {
        nested_data: {
          duration: selectedFilters.duration,
          demography: selectedFilters.demographic,
          attributes: selectedFilters.attributes,
          store_filters: selectedFilters.store_filters,
          category: selectedFilters.category
        },
        page_no: 1, // Set the page number
        sort_param: bestSellersTableState.sort_param,
        sort_type: bestSellersTableState.sort_type
      };

      populateData(
        'bestsellers-products-trends',
        setBestSellerProducts,
        requestBody,
        null,
        null,
        token
      );
    }
  }, [bestSellersTableState.sort_type, bestSellersTableState.sort_param]);

  const chartConfiguration = {
    primary: {
      brands: {
        state: trendsBrandData,
        name: 'brands',
        ChartComponent: TreeMap
      }
    },
    secondary: {
      styleTypes: {
        state: trendsStyleData,
        name: 'styletype',
        ChartComponent: TreeMap
      },
      fabrics: {
        state: trendsFabricData,
        name: 'fabric',
        ChartComponent: TreeMap
      },
      colors: {
        state: trendsColorData,
        name: 'colors',
        ChartComponent: TreeMap
      },
      patterns: {
        state: trendsPatternData,
        name: 'pattern',
        ChartComponent: TreeMap
      },
      necklines: {
        state: trendsNecklineData,
        name: 'neckline',
        ChartComponent: CustomSankeyChart
      },
      sleeves: {
        state: trendsSleeveData,
        name: 'sleevelength',
        ChartComponent: CustomSankeyChart
      }
    }
  };

  const handleItemChange = (levelName, newState, isValueSelected) => {
    const requestBody = { nested_data: selectedFilters };
    const endpoint = 'trends-filters';
    if (cancelTokenSource2.current) {
      cancelTokenSource2.current.cancel('Operation canceled due to new request.');
    }
    // Create a new cancel token source
    cancelTokenSource2.current = axios.CancelToken.source();

    const token = cancelTokenSource2.current.token;
    if (newState && typeof newState === 'object') {
      updateFiltersOnClick({
        endpoint,
        setFunction: setNestedData,
        requestBody,
        heading,
        prevData: filteredData,
        levelNameToExclude: levelName,
        isValueSelected,
        cancelToken: token,
        setLoading
      });
    }
  };

  const [levelName, setLevelName] = useState();
  const [newState, setNewState] = useState();
  const [isValueSelected, setIsValueSelected] = useState();
  const [heading, setHeading] = useState();
  const [filteredData, setFilteredData] = useState();
  const cancelTokenSource = useRef(null);
  const cancelTokenSource1 = useRef(null);
  const cancelTokenSource2 = useRef(null);
  const cancelTokenSource3 = useRef(null);

  useEffect(() => {
    if (
      (selectedFilters.duration && selectedFilters.duration.length != 0) ||
      (selectedFilters.demographic && selectedFilters.demographic.length != 0) ||
      (selectedFilters.attributes && selectedFilters.attributes.length != 0) ||
      (selectedFilters.store_filters && selectedFilters.brick_filters.length != 0) ||
      (selectedFilters.category && selectedFilters.category.length != 0)
    ) {
      if (cancelTokenSource.current) {
        cancelTokenSource.current.cancel('Operation canceled due to new request.');
      }
      // Create a new cancel token source
      cancelTokenSource.current = axios.CancelToken.source();

      const token = cancelTokenSource.current.token;
      const requestBody = {
        nested_data: {
          duration: selectedFilters.duration,
          demography: selectedFilters.demographic,
          attributes: selectedFilters.attributes,
          store_filters: selectedFilters.store_filters,
          category: selectedFilters.category
        }
      };
      populateData(
        'fabric-bestsellers-trends',
        setTrendsFabricData,
        requestBody,
        'tree-map',
        'Fabric',
        token
      );
      populateData(
        'brandnames-bestsellers-trends',
        setTrendsBrandData,
        requestBody,
        'tree-map',
        'Brands',
        token
      );
      populateData(
        'pattern-bestsellers-trends',
        setTrendsPatternData,
        requestBody,
        'tree-map',
        'Pattern',
        token
      );
      populateData(
        'color-bestsellers-trends',
        setTrendsColorData,
        requestBody,
        'tree-map',
        'Color',
        token
      );
      populateData(
        'styletype-bestsellers-trends',
        setTrendsStyleData,
        requestBody,
        'tree-map',
        'Styletype',
        token
      );
      populateData(
        'sleevelength-bestsellers-trends',
        setTrendsSleeveData,
        requestBody,
        'sankey-chart-v2',
        null,
        token
      );
      populateData(
        'neckline-bestsellers-trends',
        setTrendsNecklineData,
        requestBody,
        'sankey-chart-v2',
        null,
        token
      );
      handleItemChange(levelName, newState, isValueSelected);
      setBestSellersTableState((prev) => ({ ...prev, page_no: 1 }));
      setBestProductsTableState((prev) => ({ ...prev, page_no: 1 }));
    }
  }, [selectedFilters]);

  const [loading, setLoading] = useState(false);

  const pageSize = 9;
  const [paginatedData, setPaginatedData] = useState(null);

  const paginate = () => {
    const start = bestProductsTableState.page_no * pageSize - pageSize;
    const end = bestProductsTableState.page_no * pageSize;
    setPaginatedData(bestSellerProductsImages.data.rows?.slice(start, end));
  };

  useEffect(() => {
    paginate();
  }, [bestProductsTableState.page_no, bestSellerProductsImages.data.rows]);

  const generateNestedData = () => {
    return {
      duration: selectedFilters.duration,
      demography: selectedFilters.demographic,
      attributes: selectedFilters.attributes,
      store_filters: selectedFilters.store_filters,
      category: selectedFilters.category
    };
  };

  const fetchFilters = (initialFilters) => {
    const nd = {
      duration: initialFilters.duration,
      demography: initialFilters.demographic,
      attributes: initialFilters.attributes,
      store_filters: initialFilters.store_filters,
      category: initialFilters.category
    };
    fetchFiltersGeneric(nd, setNestedData, 'trends-filters');
  };

  const fetchInitialFilters = () => {
    const nd = {
      duration: { month: [] }
    };
    fetchInitialFiltersGeneric(nd, setNestedData, setInitialFilters, 'trends-filters');
  };

  useEffect(() => {
    fetchInitialFilters();
  }, []);

  const [visibility, setVisibility] = useState({
    brands: true,
    styleTypes: true,
    colors: true,
    fabrics: true,
    patterns: true,
    necklines: true,
    sleeves: true
  });

  return (
    <Box style={{ padding: '20px 0' }}>
      <Flex direction="column" style={{ padding: '15px' }}>
        <Text
          style={{
            fontWeight: 'bold',
            fontSize: '24px',
            fontFamily: 'Jost'
          }}>
          Trends Offline Stores
        </Text>
        <Box
          w="80px"
          h="4px"
          borderRadius={'3px'}
          my={3}
          backgroundColor={chakratheme.colors.primary.main}
        />
        <Text
          style={{
            fontSize: '16px',
            fontFamily: 'Jost',
            color: `${chakratheme.colors.gray.main}`
          }}>
          Comprehensive analytics and insights into the best selling products in offline TRENDS
          stores.
        </Text>
      </Flex>
      <Flex w="98%" justifyContent={'flex-end'}>
        <NewPopover
          selectedFilters={selectedFilters}
          setSelectedFilters={setSelectedFilters}
          data={nestedData.data}
          setNestedData={setNestedData}
          type="trends"
          setLevelName={setLevelName}
          setNewState={setNewState}
          setIsValueSelected={setIsValueSelected}
          setHeading={setHeading}
          setFilteredData={setFilteredData}
          loading={loading}
          setLoading={setLoading}
        />
      </Flex>
      <ShowSelectedFilters
        setSelectedFilters={setSelectedFilters}
        selectedFilters={selectedFilters}
        fetchFilters={fetchFilters}
        initFilters={initialFilters}
        filterHeadings={filterHeadings}
        levelNames={levelNames}
        nestedData={nestedData}
        month={
          selectedFilters?.duration?.month?.length ? selectedFilters.duration.month[0] : 'April'
        }
      />
      <Flex direction="column" style={{ padding: '15px' }}>
        <Flex
          alignItems="center"
          justifyContent="space-between"
          style={{ marginTop: '10px', padding: '0 15px' }}>
          <Box
            w="100%"
            h="1px"
            borderRadius={'3px'}
            backgroundColor={chakratheme.colors.gray.light}
            my={3}
            mr={3}
          />
          <Text
            w="100%"
            style={{
              textAlign: 'center',
              fontWeight: 'bold',
              fontSize: '22px',
              fontFamily: 'Jost'
            }}>
            Bestsellers Products Insights
          </Text>
          <Box
            w="100%"
            h="1px"
            borderRadius={'3px'}
            backgroundColor={chakratheme.colors.gray.light}
            my={3}
            ml={3}
          />
        </Flex>
        <Flex alignItems="center" justifyContent="center" mt={1}>
          <Text
            style={{
              fontSize: '16px',
              fontFamily: 'Jost',
              color: `${chakratheme.colors.gray.main}`
            }}>
            Insights into the sales analytics of TRENDS&apos; best-selling products
          </Text>
        </Flex>
        <Flex direction={'row'} p="10px 10px 0 10px" gap="30px">
          <Flex direction={'column'} w="100%">
            <Flex alignItems={'flex-start'} direction="column" mb={5}>
              <Text style={styles.H2Title}>Best Seller Products</Text>
              <Flex flexDir="row">
                <Text style={styles.H3Title}>Top-selling products at TRENDS stores</Text>
                <ChakraProvider>
                  <Popover placement="right" trigger="hover">
                    <PopoverTrigger>
                      <InfoOutlined
                        style={{
                          width: '15px',
                          height: '15px'
                        }}
                        cursor={'pointer'}
                      />
                    </PopoverTrigger>
                    <PopoverContent w="fit-content" maxW="40vw" p={3} backgroundColor={'white'}>
                      <PopoverArrow />
                      <UnorderedList styleType="'  •  '">
                        <ListItem>
                          Top-selling products on TRENDS are determined based on their rate of sale.
                        </ListItem>
                        <ListItem>
                          The rate of sale measures how quickly an item is sold over a period of
                          time.
                        </ListItem>
                        <ListItem>
                          Quantity Sold refers to the total number of units purchased.
                        </ListItem>
                      </UnorderedList>
                    </PopoverContent>
                  </Popover>
                </ChakraProvider>
              </Flex>
            </Flex>
            {bestSellerProductsImages.loading ? (
              <ImageContainerSkeleton />
            ) : (
              <Flex
                w="100%"
                wrap="wrap"
                justifyContent="space-between"
                style={{
                  padding: '15px 30px 30px 30px',
                  backgroundColor: 'white',
                  borderRadius: '10px',
                  boxShadow: `${chakratheme.colors.shadow} 0 0 20px 0`
                }}>
                <PaginationButton
                  pg={bestProductsTableState.page_no}
                  pageSize={pageSize}
                  products={bestSellerProductsImages}
                  setPg={(pg) =>
                    setBestProductsTableState((prevState) => ({ ...prevState, page_no: pg }))
                  }
                  handlePagination={() =>
                    handlePaginationFunction(
                      bestSellerProductsImages,
                      setBestSellerProductsImages,
                      generateNestedData(selectedFilters, filterHeadings),

                      'bestsellers-products-trends',
                      bestProductsTableState
                    )
                  }
                />
                <ImageContainer paginatedData={paginatedData} isQty={false} />
              </Flex>
            )}
          </Flex>
        </Flex>
        <Flex style={{ flexDirection: 'column', width: '100%', padding: '20px 10px 20px 10px' }}>
          <Flex alignItems={'flex-start'} direction="column" my={5}>
            <Text style={styles.H2Title}>TRENDS Bestselling Products</Text>
            <Text style={styles.H3Title}>
              Detailed Overview of the top-selling products in TRENDS, indicating popular products
              and customer preferences.
            </Text>
          </Flex>
          <Box mt={4}>
            <CustomTable
              loading={bestSellerProducts.loading}
              data={bestSellerProducts.data?.rows}
              handlePagination={() =>
                handlePaginationFunction(
                  bestSellerProducts,
                  setBestSellerProducts,
                  generateNestedData(selectedFilters, filterHeadings),
                  'bestsellers-products-trends',
                  bestSellersTableState
                )
              }
              sortBy={bestSellersTableState.sort_param}
              setSortBy={(pg) =>
                setBestSellersTableState((prevState) => ({ ...prevState, sort_param: pg }))
              }
              sortOrder={bestSellersTableState.sort_type}
              setSortOrder={(pg) =>
                setBestSellersTableState((prevState) => ({ ...prevState, sort_type: pg }))
              }
              totalProductsCount={bestSellerProducts.data?.total_count}
              page={bestSellersTableState.page_no}
              setPage={(pg) =>
                setBestSellersTableState((prevState) => ({ ...prevState, page_no: pg }))
              }
              headers={bestSellerHeaders}
            />
          </Box>
        </Flex>

        <Flex
          alignItems="center"
          justifyContent="space-between"
          style={{ marginTop: '30px', padding: '0 15px' }}>
          <Box
            w="100%"
            h="1px"
            borderRadius={'3px'}
            backgroundColor={chakratheme.colors.gray.light}
            my={3}
            mr={3}
          />
          <Text
            w="100%"
            style={{
              textAlign: 'center',
              fontWeight: 'bold',
              fontSize: '22px',
              fontFamily: 'Jost'
            }}>
            Bestsellers Attribute Analysis
          </Text>
          <Box
            w="100%"
            h="1px"
            borderRadius={'3px'}
            backgroundColor={chakratheme.colors.gray.light}
            my={3}
            ml={3}
          />
        </Flex>
        <Flex alignItems="center" justifyContent="center" mt={1} mb={5}>
          <Text
            style={{
              fontSize: '16px',
              fontFamily: 'Jost',
              color: `${chakratheme.colors.gray.main}`
            }}>
            Sales Distributions of attributes in TRENDS&apos; best-selling products
          </Text>
        </Flex>
        <Flex gap="15px" p="10px" justifyContent="flex-start" mr={2} alignItems="center">
          <SelectCharts
            categories={categories}
            setVisibility={setVisibility}
            visibility={visibility}
          />
        </Flex>

        <Flex direction={'row'} w={'100%'}>
          {chartConfiguration?.primary &&
            Object.keys(chartConfiguration.primary).map((key) => {
              const attribute = chartConfiguration.primary[key];
              if (visibility[key] === true) {
                return (
                  <ChartContainer
                    key={attribute.name}
                    state={attribute.state}
                    styles={styles}
                    name={attribute.name}
                    ChartComponent={attribute.ChartComponent}
                    takeFullWidth={true}
                  />
                );
              }
            })}
        </Flex>

        <Grid templateColumns="repeat(2, 1fr)" gap={4}>
          {chartConfiguration?.secondary &&
            Object.keys(chartConfiguration.secondary).map((key) => {
              const attribute = chartConfiguration.secondary[key];
              if (visibility[key] === true) {
                return (
                  <ChartContainer
                    key={attribute.name}
                    state={attribute.state}
                    styles={styles}
                    name={attribute.name}
                    ChartComponent={attribute.ChartComponent}
                  />
                );
              }
            })}
        </Grid>

        <GoToTopButton />
      </Flex>
    </Box>
  );
};

export default TrendsOffline;
