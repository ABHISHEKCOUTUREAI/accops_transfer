/* eslint-disable no-unused-vars */
import {
  Accordion,
  AccordionButton,
  AccordionIcon,
  AccordionItem,
  AccordionPanel,
  Box,
  Button,
  Flex,
  IconButton,
  Image,
  Spacer,
  Text,
  useTheme
} from '@chakra-ui/react';
import { AdsClick, Storefront, WorkspacePremium } from '@mui/icons-material';
import ArrowForwardIcon from '@mui/icons-material/ArrowForward';
import GoogleIcon from '@mui/icons-material/Google';
import RadioButtonCheckedIcon from '@mui/icons-material/RadioButtonChecked';
import React, { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import MapChart from '../../Artifactory/Charts/MapChart';
import analytics3 from '../../Static/images/analyticsimg3.png';
import google from '../../Static/images/google.png';
import heroimg2 from '../../Static/images/heroimg2.jpeg';
import retail from '../../Static/images/retail.png';
import vm3 from '../../Static/images/vm3.png';
import { populateData } from '../../api/FetchDataAPI';
import './app.css';
import Container from '../../Artifactory/Components/Container/Container';

const useStyles = (theme) => ({
  cardStyle: {
    flexDirection: 'column',
    width: '50%',
    padding: '10px 20px',
    backgroundColor: 'white',
    borderRadius: '10px',
    boxShadow: `${theme.colors.shadow} 0 0 20px 0`
  },
  H2Title: {
    fontWeight: 'semibold',
    fontSize: '18px',
    padding: '0 0 0 0'
  },
  H3Title: {
    fontSize: '14px',
    padding: '5px 0',
    fontFamily: 'Jost',
    color: `${theme.colors.gray.main}`
  }
});

const Home = () => {
  const theme = useTheme();
  const styles = useStyles(theme);
  const [isMerchandiserHovered, setIsMerchandiserHovered] = useState('');
  const [selectedImage, setSelectedImage] = useState(vm3);

  const handleAccordionChange = (index) => {
    switch (index) {
      case 0:
        setSelectedImage(vm3);
        break;
      case 1:
        setSelectedImage(analytics3);
        break;
      case 2:
        setSelectedImage(retail);
        break;
      case 3:
        setSelectedImage(google);
        break;
      default:
        setSelectedImage(vm3);
    }
  };

  const cards = {
    'AJIO Best Sellers': {
      link: '/fastfashion/ajio-best-sellers',
      description: 'Comprehensive analytics and insights into the best selling products in AJIO.',
      icon: <WorkspacePremium style={{ height: 32, width: 32 }} />,
      image: vm3,
      features: {
        1: 'Best Seller Products',
        2: 'AJIO Bestselling Products',
        3: 'Bestsellers Attribute Analysis: Brands, Styletypes, Fabrics, Colors, Patterns, Necklines, Sleevelengths'
      }
    },
    'AJIO Search Interactions': {
      link: '/fastfashion/ajio-search-interactions',
      description: 'Comprehensive analytics and insights into the search interactions in AJIO.',
      icon: <AdsClick style={{ height: 32, width: 32 }} />,
      image: analytics3,
      features: {
        1: 'Top Interacted Products',
        2: 'Top Interacted Queries',
        3: 'Categories Interacted In Queries',
        4: 'Top Interactions Breakdown: Brands, Products, Sessions',
        5: 'Most Frequently Searched Queries',
        6: 'Most Interacted Products across Queries'
      }
    },
    'TRENDS Offline Stores': {
      link: '/fastfashion/trends-offline',
      description:
        'Comprehensive analytics and insights into the best selling products in offline TRENDS.',
      icon: <Storefront style={{ height: 32, width: 32 }} />,
      image: retail,
      features: {
        1: 'Best Seller Products',
        2: 'TRENDS Bestselling Products',
        3: 'Bestsellers Attribute Analysis: Brands, Styletypes, Fabrics, Colors, Patterns, Necklines, Sleevelengths'
      }
    },
    'GOOGLE Search Interactions': {
      link: '/fastfashion/google-search-interactions',
      description:
        'Find out what others are searching in Google along with Related Queries and Top Trending searches.',
      icon: <GoogleIcon style={{ height: 32, width: 32 }} />,
      image: google,
      features: {
        1: 'GOOGLE Search Trends',
        2: 'Related Top Queries',
        3: 'Related Rising Queries',
        4: 'Top interacted products on AJIO'
      }
    }
  };

  const handleGetStarted = (link) => {
    window.location.href = link;
  };

  const initialFilters = {};
  const initialState = {
    loading: false,
    err: false,
    data: []
  };

  useEffect(() => {
    setSelectedFilters(initialFilters);
  }, [initialFilters]);
  const [selectedFilters, setSelectedFilters] = useState(initialFilters);

  const [stateWise, setStateWise] = useState(initialState);
  const [stateWise2, setStateWise2] = useState(initialState);

  useEffect(() => {
    const requestBody = {
      nested_data: {
        duration: selectedFilters.duration,
        demography: selectedFilters.demographic,
        attributes: selectedFilters.attributes,
        brick_filters: selectedFilters.brick_filters
      }
    };
    populateData('statewise-sales-ajio', setStateWise, requestBody);
  }, []);

  useEffect(() => {
    const requestBody = {
      nested_data: {
        duration: selectedFilters.duration,
        demography: selectedFilters.demographic,
        attributes: selectedFilters.attributes,
        store_filters: selectedFilters.store_filters,
        category: selectedFilters.category
      }
    };
    populateData('statewise-sales-trends', setStateWise2, requestBody);
  }, []);

  const [showAJIO, setShowAJIO] = useState(true);

  return (
    <Container style={{ padding: '20px 0 20px 0' }} bg={theme.colors.white}>
      <Flex pl="40px" pr="150px" w="100% " justifyContent={'flex-start'}>
        <Flex ml={7} direction="column">
          <Text
            style={{
              fontSize: '60px',
              fontWeight: 'bold',
              fontFamily: 'Hanken Grotesk',
              marginTop: '20px'
            }}>
            Fast Fashion Console
          </Text>
          <Text
            mt={4}
            fontFamily={'Hanken Grotesk'}
            w="600px"
            style={{ color: `${theme.colors.gray.dark}` }}
            // color="primary.lighter"
            fontWeight={'regular'}
            fontSize={18}>
            Welcome to the Fast Fashion Console: Elevate your retail experience
          </Text>
          <Button
            borderRadius={'30px'}
            fontSize={18}
            w="300px"
            fontFamily={'Jost'}
            fontWeight={600}
            padding="10px 30px"
            mt="100px"
            onClick={() => {
              document.getElementById('overview').scrollIntoView({ behavior: 'smooth' });
            }}
            bg={theme.colors.black[1000]}
            // rightIcon={<Launch fontSize="20px" />}
            color={theme.colors.white}
            _hover={{ backgroundColor: `${theme.colors.primary.main} !important` }}>
            Overview
          </Button>
        </Flex>
        <Spacer />
        <Image src={heroimg2} height="50vh" />
      </Flex>
      <Flex p="10px 120px" justifyContent={'space-between'} mt={10} mb={10} gap="10px" wrap="wrap">
        {Object.keys(cards).map((e) => {
          const card = cards[e];
          return (
            <Flex
              className="parent"
              style={{
                height: '230px',
                fontSize: '40px',
                boxShadow: `${theme.colors.gray.hover} 0 0 40px 0`,
                borderRadius: '10px',
                width: '45%',
                marginBottom: '15px'
              }}
              _hover={{
                backgroundColor: `${theme.colors.white}`
              }}
              key={e}
              w="32%">
              <Flex p={2} w="60%">
                <Image h="100%" src={card.image} borderRadius={'10px'} />
              </Flex>
              <Flex p={4} gap={3} direction="column" justifyContent={'flex-start'} w="90%">
                <Text fontFamily={'Jost'} fontWeight={'700'} fontSize={20}>
                  {e}
                </Text>
                <Text
                  color={theme.colors.gray.main}
                  fontFamily={'Jost'}
                  fontWeight={'regular'}
                  fontSize={16}>
                  {card.description}
                </Text>
                <Spacer />
                <Link to={card.link}>
                  <a href={card.link} className="get-started-button">
                    <span className="icon">
                      <ArrowForwardIcon />
                    </span>
                    <span className="text">Get Started</span>
                  </a>
                </Link>
              </Flex>
            </Flex>
          );
        })}
      </Flex>
      <Flex
        direction="column"
        style={{ marginTop: '50px' }}
        w="100%"
        justifyContent={'center'}
        alignItems={'center'}
        pb={7}>
        <Flex
          mt="30px"
          justifyContent={'center'}
          alignItems="center"
          w="100%"
          mb="30px"
          direction="column">
          <Text
            id="overview"
            color={theme.colors.black[1000]}
            fontFamily={'Jost'}
            fontWeight={'bold'}
            fontSize={32}>
            Overview
          </Text>
          <Box w="200px" h="4px" borderRadius={'2px'} backgroundColor={theme.colors.primary.main} />
        </Flex>
        <Flex
          direction="row"
          alignItems="center"
          justifyContent="center"
          w="100%"
          h="100%"
          style={{
            padding: '25px 50px',
            margin: '0 0 20px 0'
          }}>
          <Flex w="100%" maxH="60vh" style={styles.cardStyle}>
            <Flex w="100%" margin="10px 0" justifyContent="space-between" alignItems="center">
              <Text style={styles.H2Title}>
                {showAJIO
                  ? 'AJIO Statewise Sales Distribution'
                  : 'TRENDS Statewise Sales Distribution'}
              </Text>
              <Button
                style={{
                  backgroundColor: `${theme.colors.gray.light}`,
                  color: `${theme.colors.white}`,
                  borderRadius: '20px',
                  padding: '5px 15px',
                  fontSize: '12px'
                }}
                onClick={() => setShowAJIO((prevState) => !prevState)}
                _hover={{
                  backgroundColor: `${theme.colors.gray.main} !important`
                }}>
                {showAJIO ? 'Switch to TRENDS' : 'Switch to AJIO'}
              </Button>
            </Flex>
            <Text style={styles.H3Title} mb={5}>
              Visualization showing the geographical distribution of sales trends among
              {showAJIO ? <> AJIO&apos;s </> : <> TRENDS&apos; </>}
              best-selling products.
            </Text>
            {showAJIO && <MapChart statesData={stateWise.data}></MapChart>}
            {!showAJIO && <MapChart statesData={stateWise2.data}></MapChart>}
            {/* <MapChart statesData={showAJIO ? stateWise.data : stateWise2.data}></MapChart> */}
          </Flex>
        </Flex>
      </Flex>
      <Flex
        direction="column"
        style={{ marginTop: '50px' }}
        w="100%"
        justifyContent={'center'}
        alignItems={'center'}
        pb={7}>
        <Flex
          mt="30px"
          justifyContent={'center'}
          alignItems="center"
          w="100%"
          mb="30px"
          direction="column">
          <Text
            color={theme.colors.black[1000]}
            fontFamily={'Jost'}
            fontWeight={'bold'}
            fontSize={32}>
            Our Dashboards
          </Text>
          <Box w="200px" h="4px" borderRadius={'2px'} backgroundColor={theme.colors.primary.main} />
          <Text
            mt="20px"
            maxWidth={'800px'}
            color={theme.colors.gray.dark}
            fontFamily={'Jost'}
            fontWeight={'regular'}
            textAlign="center"
            fontSize={18}>
            Welcome to the Fast Fashion Console: Elevate your retail experience.
          </Text>
        </Flex>

        <Flex
          direction="row"
          alignItems="center"
          justifyContent={'center'}
          w="100%"
          h="100%"
          mb="100px"
          style={{
            padding: '35px 50px 35px 50px',
            margin: '0 0 100px 0'
          }}>
          <Flex direction={'column'} w="50%">
            <Flex
              // as={motion.div}
              alignItems="center"
              justifyContent="center"
              style={{
                fontSize: '24px',
                backgroundColor: `${theme.colors.white}`,
                borderRadius: '0',
                // boxShadow: '-2px -2px 50px #00000008, 2px 2px 50px #00000008',
                // borderBottom: '1px solid #D6D6E7',
                padding: '10px'
              }}>
              <Accordion allowToggle p={2} w="100%">
                {Object.keys(cards).map((e, index) => {
                  const card = cards[e];
                  const features = Object.values(card.features);
                  return (
                    <AccordionItem
                      key={e}
                      justifyContent={'center'}
                      alignItems={'center'}
                      style={{
                        fontSize: '24px',
                        backgroundColor: `${theme.colors.white}`,
                        borderRadius: '0',
                        boxShadow: '-2px -2px 50px #00000008, 2px 2px 50px #00000008',
                        borderBottom: `1px solid ${theme.colors.gray.light}`,
                        padding: '25px'
                      }}
                      onClick={() => handleAccordionChange(index)}>
                      <h2>
                        <AccordionButton _expanded={{ padding: '2' }}>
                          <Flex
                            flex="1"
                            justifyContent={'flex-start'}
                            alignItems={'center'}
                            direction="row"
                            fontFamily={'Jost'}>
                            <IconButton
                              style={{
                                height: 50,
                                width: 50,
                                marginRight: 20,
                                color: `${theme.colors.primary.main}`
                              }}
                              aria-label="Merchandiser">
                              {card.icon}
                            </IconButton>
                            <Text style={{ fontSize: '24px', fontWeight: '600' }}>
                              {e.split(' ').map((e) => {
                                return e.charAt(0).toUpperCase() + e.slice(1) + ' ';
                              })}
                            </Text>
                          </Flex>
                          <AccordionIcon color={theme.colors.primary.main} />
                        </AccordionButton>
                      </h2>
                      <AccordionPanel p="5px 20px 5px 80px">
                        <Text
                          style={{
                            fontSize: '18px',
                            color: `${theme.colors.gray.main}`
                          }}>
                          {card.description}
                        </Text>
                        <Flex
                          style={{
                            fontSize: '20px',
                            margin: '20px 0 0 0',
                            lineHeight: '2'
                          }}>
                          {/* <ul>
                            {features.map((feature, index) => (
                              <li key={index}>{feature}</li>
                            ))}
                          </ul> */}
                          <Flex direction={'column'}>
                            {features.map((feature, index) => (
                              <Flex
                                key={index + 1}
                                style={{ alignItems: 'flex-start', justifyContent: 'flex-start' }}>
                                <Flex
                                  style={{
                                    paddingTop: '10px'
                                  }}>
                                  <RadioButtonCheckedIcon
                                    style={{
                                      marginRight: '15px',
                                      color: `${theme.colors.primary.light}`,
                                      width: '18px',
                                      height: '18px'
                                    }}
                                  />
                                </Flex>
                                <Text m={0} p={0}>
                                  {feature}
                                </Text>
                              </Flex>
                            ))}
                          </Flex>
                        </Flex>
                        <Flex w="100%" justifyContent={'flex-end'}>
                          {/* <Flex
                            style={{
                              width: 'fit-content',
                              marginTop: '20px',
                              justifyContent: 'space-between',
                              alignItems: 'center'
                            }}
                            fontFamily={'Jost'}
                            onMouseEnter={() => setIsMerchandiserHovered(e)}
                            onMouseLeave={() => setIsMerchandiserHovered('')}>
                            <Text
                              fontSize={'22px'}
                              fontWeight={'bold'}
                              color={theme.colors.primary.main}>
                              Get Started
                            </Text>
                            <Button
                              style={{
                                color: isMerchandiserHovered
                                  ? `${theme.colors.white}`
                                  : `${theme.colors.primary.main}`,
                                backgroundColor: isMerchandiserHovered
                                  ? `${theme.colors.primary.main}`
                                  : `${theme.colors.white}`,
                                width: '30px',
                                height: '30px',
                                margin: '0 0 0 20px',
                                border: isMerchandiserHovered
                                  ? 'none'
                                  : `3px solid ${theme.colors.primary.main}`,
                                borderRadius: '50px',
                                transition: 'all 0.4s ease-in-out'
                              }}
                              leftIcon={
                                <ArrowForwardIcon
                                  style={{
                                    transform: 'translate(5px, 0)'
                                  }}
                                />
                              }
                              onClick={() => handleGetStarted(card.link)}></Button>
                          </Flex> */}
                          <Flex
                            style={{
                              width: 'fit-content',
                              marginTop: '20px',
                              padding: '5px 15px',
                              // justifyContent: 'space-between',
                              alignItems: 'center',
                              backgroundColor: `${theme.colors.primary.main}`,
                              borderRadius: '25px'
                            }}
                            fontFamily={'Jost'}
                            onMouseEnter={() => setIsMerchandiserHovered(e)}
                            onMouseLeave={() => setIsMerchandiserHovered('')}>
                            <Text fontSize={'20px'} fontWeight={'bold'} color={theme.colors.white}>
                              Get Started
                            </Text>
                            <Button
                              style={{
                                color: !isMerchandiserHovered
                                  ? `${theme.colors.white}`
                                  : `${theme.colors.primary.main}`,
                                backgroundColor: !isMerchandiserHovered
                                  ? `${theme.colors.primary.main}`
                                  : `${theme.colors.white}`,
                                width: '30px',
                                height: '30px',
                                margin: '0 0 0 20px',
                                border: !isMerchandiserHovered
                                  ? 'none'
                                  : `3px solid ${theme.colors.primary.main}`,
                                borderRadius: '50px',
                                transition: 'all 0.4s ease-in-out'
                              }}
                              leftIcon={
                                <ArrowForwardIcon
                                  style={{
                                    transform: 'translate(5px, 0)'
                                  }}
                                />
                              }
                              onClick={() => handleGetStarted(card.link)}></Button>
                          </Flex>
                        </Flex>
                      </AccordionPanel>
                    </AccordionItem>
                  );
                })}
              </Accordion>
            </Flex>
          </Flex>
          <Flex p={2} w="50%" justifyContent={'center'} alignItems={'center'}>
            <Image h="50vh" src={selectedImage} borderRadius={'10px'} />
          </Flex>
        </Flex>
      </Flex>
    </Container>
  );
};

export default Home;
