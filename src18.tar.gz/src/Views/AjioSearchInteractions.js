/* eslint-disable no-unused-vars */
import { Box, Flex, Text, useTheme } from '@chakra-ui/react';
import axios from 'axios';
import React, { useEffect, useState, useRef, useMemo } from 'react';
import CustomTable from '../Artifactory/Components/Table/Table';
import {
  fetchFiltersGeneric,
  fetchInitialFiltersGeneric,
  handlePaginationFunction,
  populateData,
  updateFiltersOnClick
} from '../api/FetchDataAPI';
import ShowSelectedFilters from '../components/Filter/ShowSelectedFilters';
import NewPopover from '../components/NewPopover';
import {
  generateNestedData,
  processNestedData,
  tableInitialState,
  useStyles
} from '../util/util_functions';
import CustomWordCloud from '../Artifactory/Charts/CustomWordCloud';
import GoToTopButton from '../Artifactory/Components/GoToTopButton/GoToTopButton';
import ChartContainer from '../components/ChartContainer';
import SectionHeading from '../components/SectionHeading';
import ImageContainerSkeleton from '../components/ImageContainer/ImageContainerSkeleton';
import ImageContainer from '../components/ImageContainer/ImageContainer';
import PaginationButton from '../Artifactory/Components/PaginationButton/PaginationButton';

const topIntQueriesHeader = [
  { name: 'Search Term', id: 'normalized_search_term', sort: '', colSpan: 1 },
  { name: 'Total Clicks', id: 'total_clicks_query', sort: 'desc', colSpan: 1, format: 'true' }
];

const topIntCategoriesHeader = [
  { name: 'L1 Name', id: 'l1name', sort: '' },
  { name: 'L2 Name', id: 'l2name', sort: '' },
  { name: 'Brick Name', id: 'brickname', sort: '' },
  { name: 'Total Clicks', id: 'total_clicks_query', sort: 'desc', format: 'true' }
];

const topSearchQueryHeaders = [
  { name: 'Search Term', id: 'normalized_search_term', sort: '' },
  {
    name: 'Search Count',
    id: 'total_clicks_query',
    sort: '',
    toolTip: true,
    toolTipText: 'Number of times query is searched',
    format: 'true'
  },
  { name: 'Month', id: 'month_of_year', sort: '' },
  { name: 'Week', id: 'week_of_year', sort: '' },
  { name: 'Type', id: 'search_type', sort: '', type: 'search_type' }
];

const mostIntProductsHeaders = [
  { name: 'Search Term', id: 'normalized_search_term', sort: '' },
  { name: 'Product ID', id: 'productid', sort: '' },
  { name: 'Title', id: 'title', sort: '' },
  { name: 'Brand Name', id: 'brandname', sort: '' },
  { name: 'L1 Name', id: 'l1name', sort: '' },
  { name: 'L2 Name', id: 'l2name', sort: '' },
  { name: 'Brick Name', id: 'brickname', sort: '' },
  { name: 'Store', id: 'store' },
  { name: 'Month', id: 'month_of_year', sort: '' },
  { name: 'Week', id: 'week_of_year', sort: '' }
];

const topInteractedProductHeaders = [
  { name: 'Product Image', id: 'image_url', type: 'image', sort: '' },
  { name: 'Product Name', id: 'title', sort: '' },
  { name: 'Brand Name', id: 'brandname', sort: '' },
  { name: 'Product ID', id: 'productid', sort: '' },
  { name: 'Total Clicks', id: 'total_clicks', sort: '' }
];

const AjioSearchInteractions = () => {
  const chakratheme = useTheme();
  const styles = useStyles(chakratheme);

  // all states required for graphs
  const initialState = {
    loading: false,
    err: false,
    data: []
  };

  const [nestedData, setNestedData] = useState(initialState);
  const [initialFilters, setInitialFilters] = useState({});
  const [levelNames, setLevelNames] = useState({});
  const [filterHeadings, setFilterHeadings] = useState([]);

  const [topIntQueriesTableState, setTopIntQueriesTableState] = useState(
    tableInitialState(1, 'total_clicks_query', 'desc')
  );

  const [topIntCatTableState, setTopIntCatTableState] = useState(
    tableInitialState(1, 'total_clicks_query', 'desc')
  );

  const [topSearchTableState, setTopSearchTableState] = useState(
    tableInitialState(1, 'total_clicks_query', 'desc')
  );

  const [mostIntProdTableState, setMostIntProdTableState] = useState(
    tableInitialState(1, 'total_clicks_query', 'asc')
  );

  const [topIntProductsTableState, setTopIntProductsTableState] = useState(
    tableInitialState(1, 'total_clicks_query', 'desc')
  );

  const [topIntQueries, setTopIntQueries] = useState(initialState);
  const [topIntCategories, setTopIntCategories] = useState(initialState);
  const [topIntBrands, setTopIntBrands] = useState(initialState);
  const [topIntProductTiles, setTopIntProductTiles] = useState(initialState);
  const [topSearchQueries, setTopSearchQueries] = useState(initialState);
  const [topQueriesBySessions, setTopQueriesBySessions] = useState(initialState);
  const [topIntProducts, setTopIntProducts] = useState(initialState);
  const [mostIntProducts, setMostIntProducts] = useState(initialState);

  useEffect(() => {
    processNestedData(nestedData, setFilterHeadings, setLevelNames);
  }, [nestedData]);

  useEffect(() => {
    setSelectedFilters(initialFilters);
    if (Object.keys(initialFilters).length !== 0) {
      fetchFilters(initialFilters);
    }
  }, [initialFilters]);
  const [loading, setLoading] = useState(false);

  const [selectedFilters, setSelectedFilters] = useState(initialFilters);

  const handleItemChange = (levelName, newState, isValueSelected) => {
    const requestBody = { nested_data: selectedFilters };
    const endpoint = 'search-interactions-filters';
    if (cancelTokenSource5.current) {
      cancelTokenSource5.current.cancel('Operation canceled due to new request.');
    }
    // Create a new cancel token source
    cancelTokenSource5.current = axios.CancelToken.source();

    const token = cancelTokenSource5.current.token;
    if (newState && typeof newState === 'object') {
      updateFiltersOnClick({
        endpoint,
        setFunction: setNestedData,
        requestBody,
        heading,
        prevData: filteredData,
        levelNameToExclude: levelName,
        isValueSelected,
        cancelToken: token,
        setLoading
      });
    }
  };

  const [levelName, setLevelName] = useState();
  const [newState, setNewState] = useState();
  const [isValueSelected, setIsValueSelected] = useState();
  const [heading, setHeading] = useState();
  const [filteredData, setFilteredData] = useState();
  const cancelTokenSource = useRef(null);
  const cancelTokenSource1 = useRef(null);
  const cancelTokenSource2 = useRef(null);
  const cancelTokenSource3 = useRef(null);
  const cancelTokenSource4 = useRef(null);
  const cancelTokenSource5 = useRef(null);

  useEffect(() => {
    if (cancelTokenSource.current) {
      cancelTokenSource.current.cancel('Operation canceled due to new request.');
    }
    // Create a new cancel token source
    cancelTokenSource.current = axios.CancelToken.source();

    const token = cancelTokenSource.current.token;
    if (
      (selectedFilters.duration && selectedFilters.duration.length != 0) ||
      (selectedFilters.search_filters && selectedFilters.search_filters.length != 0) ||
      (selectedFilters.attributes && selectedFilters.attributes.length != 0) ||
      (selectedFilters.brick_filters && selectedFilters.brick_filters.length != 0)
    ) {
      const requestBody = {
        nested_data: {
          duration: selectedFilters.duration,
          search_filters: selectedFilters.search_filters,
          attributes: selectedFilters.attributes,
          brick_filters: selectedFilters.brick_filters
        }
      };
      populateData('top-interacted-products', setTopIntProducts, requestBody, null, null, token);
      populateData(
        'top-interacted-brands',
        setTopIntBrands,
        requestBody,
        'word-cloud',
        null,
        token
      );
      populateData(
        'top-interacted-product-titles',
        setTopIntProductTiles,
        requestBody,
        'word-cloud',
        null,
        token
      );
      populateData(
        'top-queries-session',
        setTopQueriesBySessions,
        requestBody,
        'word-cloud',
        null,
        token
      );
      populateData('most-interacted-products', setMostIntProducts, requestBody, null, null, token);

      setTopIntQueriesTableState((prev) => ({ ...prev, page_no: 1 }));
      setTopIntCatTableState((prev) => ({ ...prev, page_no: 1 }));
      setTopSearchTableState((prev) => ({ ...prev, page_no: 1 }));
      setMostIntProdTableState((prev) => ({ ...prev, page_no: 1 }));
      setTopIntProductsTableState((prev) => ({ ...prev, page_no: 1 }));

      handleItemChange(levelName, newState, isValueSelected);
    }
  }, [selectedFilters]);

  useEffect(() => {
    if (
      (selectedFilters.duration && selectedFilters.duration.length != 0) ||
      (selectedFilters.search_filters && selectedFilters.search_filters.length != 0) ||
      (selectedFilters.attributes && selectedFilters.attributes.length != 0) ||
      (selectedFilters.brick_filters && selectedFilters.brick_filters.length != 0)
    ) {
      if (cancelTokenSource1.current) {
        cancelTokenSource1.current.cancel('Operation canceled due to new request.');
      }
      // Create a new cancel token source
      cancelTokenSource1.current = axios.CancelToken.source();

      const token = cancelTokenSource1.current.token;
      const requestBody = {
        nested_data: {
          duration: selectedFilters.duration,
          search_filters: selectedFilters.search_filters,
          attributes: selectedFilters.attributes,
          brick_filters: selectedFilters.brick_filters
        },
        page_no: 1, // Set the page number
        sort_param: topSearchTableState.sort_param, // Set the sort parameter
        sort_type: topSearchTableState.sort_type // Set the sort type
      };
      populateData('top-search-queries', setTopSearchQueries, requestBody, null, null, token);
    }
  }, [selectedFilters, topSearchTableState.sort_param, topSearchTableState.sort_type]);

  useEffect(() => {
    if (
      (selectedFilters.duration && selectedFilters.duration.length != 0) ||
      (selectedFilters.search_filters && selectedFilters.search_filters.length != 0) ||
      (selectedFilters.attributes && selectedFilters.attributes.length != 0) ||
      (selectedFilters.brick_filters && selectedFilters.brick_filters.length != 0)
    ) {
      if (cancelTokenSource2.current) {
        cancelTokenSource2.current.cancel('Operation canceled due to new request.');
      }
      // Create a new cancel token source
      cancelTokenSource2.current = axios.CancelToken.source();

      const token = cancelTokenSource2.current.token;
      const requestBody = {
        nested_data: {
          duration: selectedFilters.duration,
          search_filters: selectedFilters.search_filters,
          attributes: selectedFilters.attributes,
          brick_filters: selectedFilters.brick_filters
        },
        page_no: 1, // Set the page number
        sort_param: mostIntProdTableState.sort_param, // Set the sort parameter
        sort_type: mostIntProdTableState.sort_type // Set the sort type
      };
      populateData('most-interacted-products', setMostIntProducts, requestBody, null, null, token);
    }
  }, [selectedFilters, mostIntProdTableState.sort_param, mostIntProdTableState.sort_type]);

  useEffect(() => {
    if (
      (selectedFilters.duration && selectedFilters.duration.length != 0) ||
      (selectedFilters.search_filters && selectedFilters.search_filters.length != 0) ||
      (selectedFilters.attributes && selectedFilters.attributes.length != 0) ||
      (selectedFilters.brick_filters && selectedFilters.brick_filters.length != 0)
    ) {
      if (cancelTokenSource3.current) {
        cancelTokenSource3.current.cancel('Operation canceled due to new request.');
      }
      // Create a new cancel token source
      cancelTokenSource3.current = axios.CancelToken.source();

      const token = cancelTokenSource3.current.token;
      const requestBody = {
        nested_data: {
          duration: selectedFilters.duration,
          search_filters: selectedFilters.search_filters,
          attributes: selectedFilters.attributes,
          brick_filters: selectedFilters.brick_filters
        },
        page_no: 1,
        sort_param: topIntQueriesTableState.sort_param,
        sort_type: topIntQueriesTableState.sort_type
      };
      populateData('top-interacted-queries', setTopIntQueries, requestBody, null, null, token);
    }
  }, [selectedFilters, topIntQueriesTableState.sort_param, topIntQueriesTableState.sort_type]);

  useEffect(() => {
    if (
      (selectedFilters.duration && selectedFilters.duration.length != 0) ||
      (selectedFilters.search_filters && selectedFilters.search_filters.length != 0) ||
      (selectedFilters.attributes && selectedFilters.attributes.length != 0) ||
      (selectedFilters.brick_filters && selectedFilters.brick_filters.length != 0)
    ) {
      if (cancelTokenSource4.current) {
        cancelTokenSource4.current.cancel('Operation canceled due to new request.');
      }
      // Create a new cancel token source
      cancelTokenSource4.current = axios.CancelToken.source();

      const token = cancelTokenSource4.current.token;
      const requestBody = {
        nested_data: {
          duration: selectedFilters.duration,
          search_filters: selectedFilters.search_filters,
          attributes: selectedFilters.attributes,
          brick_filters: selectedFilters.brick_filters
        },
        page_no: 1,
        sort_param: topIntCatTableState.sort_param,
        sort_type: topIntCatTableState.sort_type
      };
      populateData(
        'top-interacted-categories',
        setTopIntCategories,
        requestBody,
        null,
        null,
        token
      );
    }
  }, [selectedFilters, topIntCatTableState.sort_param, topIntCatTableState.sort_type]);

  const paginate = () => {
    const start = topIntProductsTableState.page_no * pageSize - pageSize;
    const end = topIntProductsTableState.page_no * pageSize;
    setPaginatedData(topIntProducts?.data?.rows?.slice(start, end));
  };

  useEffect(() => {
    paginate();
  }, [topIntProductsTableState.page_no, topIntProducts.data.rows]);

  const fetchFilters = (initialFilters) => {
    const nestedData = {
      duration: initialFilters.duration,
      search_filters: initialFilters.search_filters,
      attributes: initialFilters.attributes,
      brick_filters: initialFilters.brick_filters
    };
    fetchFiltersGeneric(nestedData, setNestedData, 'search-interactions-filters');
  };

  const fetchInitialFilters = () => {
    const nestedData = {
      duration: { month: [] }
    };
    fetchInitialFiltersGeneric(
      nestedData,
      setNestedData,
      setInitialFilters,
      'search-interactions-filters'
    );
  };

  useEffect(() => {
    fetchInitialFilters();
  }, []);

  const pageSize = 9;
  const [paginatedData, setPaginatedData] = useState(null);

  useEffect(() => {
    paginate();
  }, [
    pageSize,
    topIntProductsTableState.page_no,
    topInteractedProductHeaders,
    topIntProducts.data.rows
  ]);

  const TopInteractedBrandsView = useMemo(() => {
    return (
      <ChartContainer
        state={topIntBrands}
        styles={styles}
        name="Top Interacted Brands"
        ChartComponent={CustomWordCloud}
        takeFullWidth={true}
      />
    );
  }, [topIntBrands]);

  const TopInteractedProductTitlesView = useMemo(() => {
    return (
      <ChartContainer
        state={topIntProductTiles}
        styles={styles}
        name="Top Interacted Product Titles"
        ChartComponent={CustomWordCloud}
        takeFullWidth={true}
      />
    );
  }, [topIntProductTiles]);

  const topQueriesView = useMemo(() => {
    return (
      <ChartContainer
        state={topQueriesBySessions}
        styles={styles}
        name="Top Queries by Session Count"
        ChartComponent={CustomWordCloud}
        takeFullWidth={true}
      />
    );
  }, [topQueriesBySessions]);

  return (
    <Box style={{ padding: '20px 0' }}>
      <Flex direction="column" style={{ padding: '15px' }}>
        <Text
          style={{
            fontWeight: 'bold',
            fontSize: '24px',
            fontFamily: 'Jost'
          }}>
          AJIO Search Interactions Trends
        </Text>
        <Box
          w="80px"
          h="4px"
          my={3}
          borderRadius={'3px'}
          backgroundColor={chakratheme.colors.primary.main}
        />
        <Text
          style={{
            fontSize: '16px',
            fontFamily: 'Jost',
            color: `${chakratheme.colors.gray.main}`
          }}>
          Comprehensive analytics and insights into the search interactions in AJIO.
        </Text>
      </Flex>
      <Flex w="98%" justifyContent={'flex-end'}>
        <NewPopover
          selectedFilters={selectedFilters}
          setSelectedFilters={setSelectedFilters}
          data={nestedData.data}
          setNestedData={setNestedData}
          type="search"
          setLevelName={setLevelName}
          setNewState={setNewState}
          setIsValueSelected={setIsValueSelected}
          setHeading={setHeading}
          setFilteredData={setFilteredData}
          loading={loading}
          setLoading={setLoading}
        />
      </Flex>
      <ShowSelectedFilters
        setSelectedFilters={setSelectedFilters}
        selectedFilters={selectedFilters}
        initFilters={initialFilters}
        levelNames={levelNames}
        fetchFilters={fetchFilters}
        filterHeadings={filterHeadings}
        nestedData={nestedData}
        month={
          selectedFilters?.duration?.month?.length ? selectedFilters.duration.month[0] : 'April'
        }
      />
      <Flex direction="column" style={{ padding: '15px' }}>
        <SectionHeading
          heading="User Interaction Analysis"
          subHeading="This section provides insights into how users interact with AJIO's search feature
            and products catalogue."
        />
        <Flex direction={'row'} p="10px 10px 0 10px" gap="30px">
          <Flex direction={'column'} w="100%">
            <Flex alignItems={'flex-start'} direction="column" mb={5}>
              <Text style={styles.H2Title}>Top Interacted Products</Text>
              <Text style={styles.H3Title}>
                Frequently interacted products on AJIO, indicating high user engagement and
                interest.
              </Text>
            </Flex>
            {/* {topIntProducts.loading ? (
              <LoadingSpinner name="Top Interacted Products Data" />
            ) : ( */}
            {topIntProducts.loading ? (
              <ImageContainerSkeleton />
            ) : (
              <Flex
                w="100%"
                wrap="wrap"
                justifyContent="space-between"
                style={{
                  padding: '15px 30px 30px 30px',
                  backgroundColor: 'white',
                  borderRadius: '10px',
                  boxShadow: `${chakratheme.colors.shadow} 0 0 20px 0`
                }}>
                <PaginationButton
                  pg={topIntProductsTableState.page_no}
                  pageSize={pageSize}
                  products={topIntProducts}
                  setPg={(pg) =>
                    setTopIntProductsTableState((prevState) => ({ ...prevState, page_no: pg }))
                  }
                  handlePagination={() =>
                    handlePaginationFunction(
                      topIntProducts,
                      setTopIntProducts,
                      generateNestedData(selectedFilters, filterHeadings),
                      'top-interacted-products',
                      topIntProductsTableState
                    )
                  }
                />
                <ImageContainer paginatedData={paginatedData} isQty={true} />
              </Flex>
            )}
            {/* )} */}
          </Flex>
        </Flex>
        <Flex w="100%" direction={'row'} p="10px 20px 20px 20px" gap="30px">
          <Flex direction={'column'} w="50%" py="10px">
            <Flex alignItems={'flex-start'} direction="column" mb={5}>
              <Text style={styles.H2Title}>Top Interacted Queries</Text>
              <Text style={styles.H3Title}>
                Queries that generate the most product clicks, indicating accuracy of search
                results.
              </Text>
            </Flex>
            <CustomTable
              loading={topIntQueries.loading}
              data={topIntQueries.data.rows}
              headers={topIntQueriesHeader}
              height="450px"
              page={topIntQueriesTableState.page_no}
              //   setPage={setPage}
              setPage={(pg) =>
                setTopIntQueriesTableState((prevState) => ({ ...prevState, page_no: pg }))
              }
              handlePagination={() =>
                handlePaginationFunction(
                  topIntQueries,
                  setTopIntQueries,
                  generateNestedData(selectedFilters, filterHeadings),
                  `top-interacted-queries`,
                  topIntQueriesTableState
                )
              }
              sortBy={topIntQueriesTableState.sort_param}
              setSortBy={(pg) =>
                setTopIntQueriesTableState((prevState) => ({ ...prevState, sort_param: pg }))
              }
              sortOrder={topIntQueriesTableState.sort_type}
              setSortOrder={(pg) =>
                setTopIntQueriesTableState((prevState) => ({ ...prevState, sort_type: pg }))
              }
              totalProductsCount={topIntQueries?.data?.total_count}
            />
          </Flex>

          <Flex direction={'column'} w="50%" py="10px">
            <Flex alignItems={'flex-start'} direction="column" mb={5}>
              <Text style={styles.H2Title}>Categories Interacted In Queries</Text>
              <Text style={styles.H3Title}>
                Breakdown of product categories that receive the most clicks during user search
                interactions, indicating popular categories.
              </Text>
            </Flex>
            <CustomTable
              loading={topIntCategories.loading}
              data={topIntCategories.data.rows}
              headers={topIntCategoriesHeader}
              height="450px"
              page={topIntCatTableState.page_no}
              setPage={(pg) =>
                setTopIntCatTableState((prevState) => ({ ...prevState, page_no: pg }))
              }
              handlePagination={() =>
                handlePaginationFunction(
                  topIntCategories,
                  setTopIntCategories,
                  generateNestedData(selectedFilters, filterHeadings),
                  `top-interacted-categories`,
                  topIntCatTableState
                )
              }
              sortBy={topIntCatTableState.sort_param}
              setSortBy={(pg) =>
                setTopIntCatTableState((prevState) => ({ ...prevState, sort_param: pg }))
              }
              sortOrder={topIntCatTableState.sort_type}
              setSortOrder={(pg) =>
                setTopIntCatTableState((prevState) => ({ ...prevState, sort_type: pg }))
              }
              totalProductsCount={topIntCategories?.data?.total_count}
            />
          </Flex>
        </Flex>

        {/* Word cloud components come here */}
        <SectionHeading
          heading="Top Interactions Breakdown"
          subHeading="Insights into user engagement with AJIO's search feature, including top brands,
            product titles, and search queries."
        />

        <Flex direction={'row'} p="20px" gap="30px">
          {TopInteractedBrandsView}
          {TopInteractedProductTitlesView}
          {topQueriesView}
        </Flex>

        <Flex direction={'row'} p="0 20px 20px 20px">
          <Flex direction={'column'} w="100%" py="20px">
            <Flex alignItems={'flex-start'} direction="column" mb={5}>
              <Text style={styles.H2Title}>Most Frequently Searched Queries</Text>
              <Text style={styles.H3Title}>
                Search terms that are frequently searched by users, indicating overall popular
                search queries.
              </Text>
            </Flex>
            <CustomTable
              loading={topSearchQueries.loading}
              data={topSearchQueries.data.rows}
              headers={topSearchQueryHeaders}
              height="500px"
              page={topSearchTableState.page_no}
              setPage={(pg) =>
                setTopSearchTableState((prevState) => ({ ...prevState, page_no: pg }))
              }
              handlePagination={() =>
                handlePaginationFunction(
                  topSearchQueries,
                  setTopSearchQueries,
                  generateNestedData(selectedFilters, filterHeadings),
                  `top-search-queries`,
                  topSearchTableState
                )
              }
              sortBy={topSearchTableState.sort_param}
              setSortBy={(pg) =>
                setTopSearchTableState((prevState) => ({ ...prevState, sort_param: pg }))
              }
              sortOrder={topSearchTableState.sort_type}
              setSortOrder={(pg) =>
                setTopSearchTableState((prevState) => ({ ...prevState, sort_type: pg }))
              }
              totalProductsCount={topSearchQueries?.data?.total_count}
            />
          </Flex>
        </Flex>
        <Flex direction={'row'} p="0 20px 20px 20px">
          <Flex direction={'column'} w="100%" py="10px">
            <Flex alignItems={'flex-start'} direction="column" mb={5}>
              <Text style={styles.H2Title}>Most Interacted Products across Queries</Text>
              <Text style={styles.H3Title}>
                Most interacted products for each searched query indicating user interest.
              </Text>
            </Flex>
            <CustomTable
              loading={mostIntProducts.loading}
              data={mostIntProducts.data.rows}
              headers={mostIntProductsHeaders}
              height="500px"
              page={mostIntProdTableState.page_no}
              setPage={(pg) =>
                setMostIntProdTableState((prevState) => ({ ...prevState, page_no: pg }))
              }
              handlePagination={() =>
                handlePaginationFunction(
                  mostIntProducts,
                  setMostIntProducts,
                  generateNestedData(selectedFilters, filterHeadings),
                  `most-interacted-products`,
                  mostIntProdTableState
                )
              }
              sortBy={mostIntProdTableState.sort_param}
              setSortBy={(pg) =>
                setMostIntProdTableState((prevState) => ({ ...prevState, sort_param: pg }))
              }
              sortOrder={mostIntProdTableState.sort_type}
              setSortOrder={(pg) =>
                setMostIntProdTableState((prevState) => ({ ...prevState, sort_type: pg }))
              }
              totalProductsCount={mostIntProducts?.data?.total_count}
            />
          </Flex>
        </Flex>
        <GoToTopButton />
      </Flex>
    </Box>
  );
};

export default AjioSearchInteractions;
