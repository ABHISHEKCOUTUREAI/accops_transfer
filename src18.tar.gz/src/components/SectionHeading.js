import { Box, Flex, Text, useTheme } from '@chakra-ui/react';
import React from 'react';

import PropTypes from 'prop-types';

const SectionHeading = ({ heading, subHeading }) => {
  const chakratheme = useTheme();

  return (
    <>
      <Flex
        alignItems="center"
        justifyContent="space-between"
        style={{ marginTop: '30px', padding: '0 15px' }}>
        <Box
          w="100%"
          h="1px"
          borderRadius={'3px'}
          backgroundColor={chakratheme.colors.gray.light}
          my={3}
          mr={3}
        />
        <Text
          w="100%"
          style={{
            textAlign: 'center',
            fontWeight: 'bold',
            fontSize: '22px',
            fontFamily: 'Jost'
          }}>
          {heading}
        </Text>
        <Box
          w="100%"
          h="1px"
          borderRadius={'3px'}
          backgroundColor={chakratheme.colors.gray.light}
          my={3}
          ml={3}
        />
      </Flex>
      <Flex alignItems="center" justifyContent="center" mt={1} mb={5}>
        <Text
          style={{
            fontSize: '16px',
            fontFamily: 'Jost',
            color: `${chakratheme.colors.gray.main}`
          }}>
          {subHeading}
        </Text>
      </Flex>
    </>
  );
};

SectionHeading.propTypes = {
  heading: PropTypes.string.isRequired,
  subHeading: PropTypes.string
};

export default SectionHeading;
