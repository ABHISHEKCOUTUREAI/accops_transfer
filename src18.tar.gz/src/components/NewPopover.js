import {
  Button,
  ChakraProvider,
  Flex,
  FocusLock,
  Icon,
  Popover,
  PopoverArrow,
  PopoverCloseButton,
  PopoverContent,
  PopoverTrigger,
  useDisclosure
} from '@chakra-ui/react';
import FilterAltOutlinedIcon from '@mui/icons-material/FilterAltOutlined';
import React from 'react';
import NewFilter from './NewFilter';
import PropTypes from 'prop-types';

const NewPopover = (props) => {
  const { onOpen, onClose, isOpen } = useDisclosure();
  return (
    <ChakraProvider>
      <Flex justifyContent="right">
        <Popover
          isOpen={isOpen}
          onOpen={onOpen}
          onClose={onClose}
          placement="bottom-end"
          closeOnBlur={true}
          preventOverflow={true}>
          <PopoverTrigger>
            <Button leftIcon={<Icon as={FilterAltOutlinedIcon} />}>Filters</Button>
          </PopoverTrigger>
          <PopoverContent p={'20px'} w={'50vw'} h={'fit-content'}>
            <FocusLock returnFocus persistentFocus={false}>
              <PopoverArrow />
              <PopoverCloseButton />
              <NewFilter
                data={props.data}
                selectedFilters={props.selectedFilters}
                setSelectedFilters={props.setSelectedFilters}
                type={props.type}
                setNestedData={props.setNestedData}
                setLevelName={props.setLevelName}
                setNewState={props.setNewState}
                setIsValueSelected={props.setIsValueSelected}
                setHeading={props.setHeading}
                setFilteredData={props.setFilteredData}
                setLoading={props.setLoading}
                loading={props.loading}
              />
            </FocusLock>
          </PopoverContent>
        </Popover>
      </Flex>
    </ChakraProvider>
  );
};

NewPopover.propTypes = {
  data: PropTypes.object,
  selectedFilters: PropTypes.object,
  loading: PropTypes.bool,
  setSelectedFilters: PropTypes.func,
  setNestedData: PropTypes.func,
  setLevelName: PropTypes.func,
  setLoading: PropTypes.func,
  setNewState: PropTypes.func,
  setFilteredData: PropTypes.func,
  setIsValueSelected: PropTypes.func,
  setHeading: PropTypes.func,
  type: PropTypes.string
};

export default NewPopover;
