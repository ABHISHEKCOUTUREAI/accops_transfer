import { Flex, Text } from '@chakra-ui/react';
import React from 'react';
import LoadingSpinner from '../Artifactory/Components/LoadingSpinner/LoadingSpinner';
import ErrorLoader from './ErrorLoader/ErrorLoader';
import PropTypes from 'prop-types';
import { capitalizeHeading } from '../util/util_functions';

const ChartContainer = ({ state, takeFullWidth, retryApiCall, styles, name, ChartComponent }) => {
  const content = (state, retryApiCall) => {
    if (state.loading) {
      return <LoadingSpinner name={`${capitalizeHeading(name)} data`} />;
    } else if (state.err) {
      return <ErrorLoader name={`${capitalizeHeading(name)} data`} retryApiCall={retryApiCall} />;
    } else {
      return (
        <>
          <Flex alignItems={'flex-start'} direction="column">
            <Text style={styles.H2Title}>
              Distribution of {capitalizeHeading(name)} in Bestsellers
            </Text>
            <Text style={styles.H3Title}>
              Comparative Sales Distribution of {capitalizeHeading(name)} across bricks
            </Text>
          </Flex>
          {<ChartComponent data={state.data} />}
        </>
      );
    }
  };

  return (
    <Flex
      style={{
        ...styles.cardStyle,
        width: takeFullWidth ? '100%' : undefined
        // minWidth: takeFullWidth ? undefined : '50%'
      }}>
      {content(state, retryApiCall)}
    </Flex>
  );
};

ChartContainer.propTypes = {
  state: PropTypes.object.isRequired,
  takeFullWidth: PropTypes.bool,
  retryApiCall: PropTypes.func.isRequired,
  styles: PropTypes.object.isRequired,
  name: PropTypes.string.isRequired,
  ChartComponent: PropTypes.elementType.isRequired
};

export default ChartContainer;
