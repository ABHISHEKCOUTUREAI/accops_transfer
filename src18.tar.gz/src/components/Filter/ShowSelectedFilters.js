/* eslint-disable no-unused-vars */
import { Button, Flex, Text, useTheme, IconButton, useToast } from '@chakra-ui/react';
import React from 'react';
import {
  capitalizeHeading,
  checkIfDefaultFilter,
  checkIfOnlyOneMonthIsSelected,
  headingIcons
} from '../../util/util_functions';
import { CloseIcon, DeleteIcon } from '@chakra-ui/icons';
import PropTypes from 'prop-types';

const ShowSelectedFilters = (props) => {
  const toast = useToast();
  const chakratheme = useTheme();

  const clearSingleHeadingFilters = (heading) => {
    const checkDefault = checkIfDefaultFilter(props.selectedFilters);
    if (checkDefault === true) {
      toast({
        title: 'Default Month must be selected',
        variant: 'subtle',
        isClosable: true,
        position: 'top'
      });
      return;
    }

    const newFilters = { ...props.selectedFilters };

    if (heading === 'duration') {
      if (checkIfOnlyOneMonthIsSelected(newFilters) === true) {
        return;
      }
    }

    Object.keys(newFilters[heading]).forEach((subFilter) => {
      newFilters[heading][subFilter] = [];
    });

    if (heading === 'duration') {
      newFilters['duration']['month'] = [props.month];
    }

    props.setSelectedFilters(newFilters);
  };

  const handleReset = () => {
    const checkDefault = checkIfDefaultFilter(props.selectedFilters);

    if (checkDefault === false) {
      const newSelectedFilters = JSON.parse(JSON.stringify(props.selectedFilters));
      Object.keys(newSelectedFilters).forEach((filterCategory) => {
        Object.keys(newSelectedFilters[filterCategory]).forEach((subFilter) => {
          newSelectedFilters[filterCategory][subFilter] = [];
        });
        if (filterCategory === 'duration') {
          newSelectedFilters.duration.month = [props.month];
        }
      });
      props.setSelectedFilters(newSelectedFilters);
    }
  };

  return (
    <Flex
      direction="column"
      w="97%"
      style={{
        margin: '5px 15px 15px 15px',
        border: '1px solid #e6e6e6',
        borderRadius: '10px',
        padding: '10px 10px 15px 10px',
        color: `${chakratheme.colors.gray.light}`,
        fontSize: '14px'
      }}>
      {!Object.values(props.selectedFilters).some((filter) =>
        Object.values(filter).some((value) => value.length > 0)
      ) ? (
        <Text fontSize="16px" fontFamily="Jost" style={{ color: 'black' }}>
          Customize your results by choosing filters above
        </Text>
      ) : (
        <Flex w="100%" justifyContent={'space-between'} alignItems="flex-start">
          <Text fontSize="16px" fontFamily="Jost" color="black" alignSelf="center">
            Showing results for
          </Text>
          {!checkIfDefaultFilter(props.selectedFilters) && (
            <Flex direction={'row'} gap={'10px'}>
              <Button
                leftIcon={<CloseIcon boxSize={3} style={{ fontWeight: 'bold' }} />}
                variant="outline"
                style={{
                  padding: '5px 8px',
                  width: 'fit-content',
                  fontSize: '13px',
                  color: `${chakratheme.colors.gray.main}`,
                  border: `1px solid ${chakratheme.colors.gray.main}`,
                  backgroundColor: `${chakratheme.colors.white}`,
                  borderRadius: '4px',
                  fontWeight: 'bold'
                }}
                onClick={handleReset}
                _hover={{
                  backgroundColor: `${chakratheme.colors.gray.lighter} !important`,
                  color: `${chakratheme.colors.gray.dark} !important`,
                  border: `1px solid ${chakratheme.colors.gray.dark} !important`,
                  fontWeight: 'bold'
                }}>
                Reset Filters
              </Button>
            </Flex>
          )}
        </Flex>
      )}

      {props.filterHeadings.map((heading) => {
        const IconComponent = headingIcons[heading];
        return (
          props.selectedFilters[heading] &&
          Object.values(props.selectedFilters[heading]).some((value) => value.length > 0) && (
            <Flex
              key={heading}
              direction="row"
              justifyContent={'space-between'}
              mt="3"
              sx={{
                padding: '5px 10px',
                borderRadius: '20px',
                backgroundColor: `${chakratheme.colors.gray.lighter}`,
                color: `${chakratheme.colors.gray.dark}`,
                '&:hover .delete-button': {
                  opacity: '1 !important',
                  visibility: 'visible !important'
                }
              }}>
              <Flex>
                <Flex alignItems="center" gap={3}>
                  {IconComponent}
                  <Text
                    fontFamily="Jost"
                    fontSize="17px"
                    paddingRight="5px"
                    marginRight="10px"
                    borderRight={'3px solid #eaeaea'}>
                    {capitalizeHeading(heading)}
                  </Text>
                </Flex>
                <Flex direction="row" flexWrap="wrap" gap={3}>
                  {props.selectedFilters[heading] &&
                    Object.keys(props.selectedFilters[heading]).map(
                      (subFilterKey) =>
                        props.selectedFilters[heading][subFilterKey].length > 0 && (
                          <Flex key={subFilterKey} alignItems="center">
                            <Text
                              minWidth="fit-content"
                              fontSize="16px"
                              fontFamily="Jost"
                              fontWeight="bold">
                              {capitalizeHeading(subFilterKey)}:
                            </Text>
                            <Flex flexWrap="wrap" w={'100%'}>
                              {Array.isArray(props.selectedFilters[heading][subFilterKey])
                                ? props.selectedFilters[heading][subFilterKey].map(
                                    (value, index) => (
                                      <React.Fragment key={index + 1}>
                                        <Text fontSize="15px" fontFamily="Jost" ml={1.5}>
                                          {value}
                                        </Text>
                                        {index !==
                                          props.selectedFilters[heading][subFilterKey].length -
                                            1 && (
                                          <Text
                                            fontSize="15px"
                                            fontFamily="Jost"
                                            ml={index !== 0 ? '1' : '0'}>
                                            ,
                                          </Text>
                                        )}
                                      </React.Fragment>
                                    )
                                  )
                                : Object.keys(props.selectedFilters[heading][subFilterKey]).map(
                                    (nestedKey, index) => (
                                      <Flex key={index + 1}>
                                        <Text fontSize="17px" ml="1" fontWeight="bold">
                                          {capitalizeHeading(nestedKey)}
                                        </Text>
                                        <Text fontSize="17px" ml="1">
                                          {props.selectedFilters[heading][subFilterKey][
                                            nestedKey
                                          ].join(', ')}
                                        </Text>
                                      </Flex>
                                    )
                                  )}
                            </Flex>
                          </Flex>
                        )
                    )}
                </Flex>
              </Flex>
              {!(
                heading === 'duration' && checkIfOnlyOneMonthIsSelected(props.selectedFilters)
              ) && (
                <Flex
                  ml={'15px'}
                  justifyContent={'center'}
                  alignItems={'center'}
                  cursor={'pointer'}
                  className="delete-button"
                  style={{
                    opacity: 0,
                    visibility: 'hidden',
                    transition: 'opacity 0.2s ease-in-out, visibility 0.2s ease-in-out'
                  }}>
                  <IconButton
                    w="18px"
                    h="18px"
                    isRound={true}
                    aria-label="Delete"
                    padding="15px"
                    icon={<DeleteIcon />}
                    onClick={() => clearSingleHeadingFilters(heading)}
                    _hover={{
                      backgroundColor: `${chakratheme.colors.gray.bg}`
                    }}
                  />
                </Flex>
              )}
            </Flex>
          )
        );
      })}
    </Flex>
  );
};

ShowSelectedFilters.propTypes = {
  selectedFilters: PropTypes.object.isRequired,
  setSelectedFilters: PropTypes.func.isRequired,
  filterHeadings: PropTypes.array.isRequired,
  month: PropTypes.string.isRequired
};

export default ShowSelectedFilters;
