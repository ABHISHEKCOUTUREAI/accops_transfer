import SideBar from '../../Artifactory/Components/SideBar/SideBar';
import React, { useState, useEffect } from 'react';
import home from '../../Static/images/home.png';
import { Image, useTheme } from '@chakra-ui/react';
import CheckroomIcon from '@mui/icons-material/Checkroom';
import StorefrontIcon from '@mui/icons-material/Storefront';
import WorkspacePremiumIcon from '@mui/icons-material/WorkspacePremium';
import AdsClickIcon from '@mui/icons-material/AdsClick';
import GoogleIcon from '@mui/icons-material/Google';
import { useLocation } from 'react-router-dom';
import PropTypes from 'prop-types';

const CustomSidebar = (props) => {
  const theme = useTheme();
  const [menu, setMenu] = useState([
    {
      variant: 'button',
      icon: (
        <Image
          src={home}
          style={{
            height: 24,
            width: 24,
            marginRight: '10px',
            filter:
              'invert(61%) sepia(12%) saturate(0%) hue-rotate(279deg) brightness(98%) contrast(90%)',
            // transition: 'filter 0.3s',
            ':hover': {
              filter: 'none'
            }
          }}
        />
      ),
      text: 'Home',
      link: '/fastfashion',
      spacing: 2
    },
    {
      variant: 'list',
      // open: location == "/search/vm/visual-merchandiser" ? true : false,

      text: 'Fast Fashion',
      spacing: 2,
      icon: (
        <CheckroomIcon
          style={{
            height: 24,
            width: 24,
            marginRight: '10px',
            color: `${theme.colors.gray.light}`
          }}
        />
      ),
      child: [
        {
          variant: 'button',
          icon: (
            <WorkspacePremiumIcon
              style={{
                height: 30,
                width: 30,
                overflow: 'show',
                // marginRight: '10px',
                // filter: 'invert(61%) sepia(12%) saturate(0%) hue-rotate(279deg) brightness(98%) contrast(90%)',
                transform: 'translate(-27px)',
                backgroundColor: '#f4f2f2',
                borderRadius: '8px',
                padding: '5px'
              }}
            />
          ),
          text: 'AJIO Best Seller Analysis',
          link: '/fastfashion/ajio-best-sellers',
          spacing: 2
        },
        {
          variant: 'button',
          icon: (
            <AdsClickIcon
              style={{
                height: 30,
                width: 30,
                overflow: 'show',
                // marginRight: '10px',
                // filter: 'invert(61%) sepia(12%) saturate(0%) hue-rotate(279deg) brightness(98%) contrast(90%)',
                transform: 'translate(-27px)',
                backgroundColor: '#f4f2f2',
                borderRadius: '8px',
                padding: '5px'
              }}
            />
          ),
          text: 'AJIO Search Interactions',
          link: '/fastfashion/ajio-search-interactions',
          spacing: 2
        },
        {
          variant: 'button',
          icon: (
            <StorefrontIcon
              style={{
                height: 30,
                width: 30,
                overflow: 'show',
                // marginRight: '10px',
                // filter: 'invert(61%) sepia(12%) saturate(0%) hue-rotate(279deg) brightness(98%) contrast(90%)',
                transform: 'translate(-27px)',
                backgroundColor: '#f4f2f2',
                borderRadius: '8px',
                padding: '5px'
              }}
            />
          ),
          text: 'Trends Offline Stores',
          link: '/fastfashion/trends-offline',
          spacing: 2
        },
        {
          variant: 'button',
          icon: (
            <GoogleIcon
              style={{
                height: 30,
                width: 30,
                overflow: 'show',
                // marginRight: '10px',
                // filter: 'invert(61%) sepia(12%) saturate(0%) hue-rotate(279deg) brightness(98%) contrast(90%)',
                transform: 'translate(-27px)',
                backgroundColor: '#f4f2f2',
                borderRadius: '8px',
                padding: '5px'
              }}
            />
          ),
          text: 'Google Search Interactions',
          link: '/fastfashion/google-search-interactions',
          spacing: 2
        }
      ]
    }
  ]);

  const handleCollapseToggle = () => {
    props.setIsCollapsed(!props.isCollapsed);
  };

  const location = useLocation();

  useEffect(() => {
    // Scroll to top when location changes
    window.scrollTo(0, 0);
  }, [location]);

  return (
    <div>
      <SideBar
        handleCollapseToggle={handleCollapseToggle}
        setIsCollapsed={props.setIsCollapsed}
        name={'Fast Fashion'}
        isCollapsed={props.isCollapsed}
        menu={menu}
        setMenu={setMenu}
      />
    </div>
  );
};

CustomSidebar.propTypes = {
  setIsCollapsed: PropTypes.func.isRequired,
  isCollapsed: PropTypes.bool.isRequired
};

export default CustomSidebar;
