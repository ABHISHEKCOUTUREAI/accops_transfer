import React, { useEffect, useState } from 'react';
import { Button, Checkbox, Flex, Grid, GridItem, Text, Box } from '@chakra-ui/react';
import {
  capitalizeHeading,
  checkIfDefaultFilter,
  checkIfOnlyOneMonthIsSelected,
  customOrder
} from '../util/util_functions';

import PropTypes from 'prop-types';

const FilterContent = ({
  levelName,
  selectedFilters,
  setSelectedFilters,
  heading,
  filteredData,
  searched,
  isLevelActive,
  setLevelName,
  setNewState,
  setIsValueSelected,
  setHeading,
  setFilteredData,
  setIsToastVisible,
  setLoading
}) => {
  const [itemsToShow, setItemsToShow] = useState(4);
  const [isExpanded, setIsExpanded] = useState(false);
  const [expandedData, setExpandedData] = useState([]);
  const [initialDataOrder, setInitialDataOrder] = useState([]);

  const handleClick = () => {
    setItemsToShow((prev) => prev + 10);
    setIsExpanded(true);
  };

  const handleViewLess = () => {
    setItemsToShow(4);
    setIsExpanded(false);
    // Restore initial data order when "View Less" is clicked
    setExpandedData(initialDataOrder);
  };

  const compareFunction = (a, b) => {
    if (a < b) {
      return -1;
    }
    if (a > b) {
      return 1;
    }
    return 0;
  };

  const sortDataBySelection = (data) => {
    const selectedItems = [];
    const unselectedItems = [];
    data.forEach((item) => {
      if (selectedFilters[heading][levelName].includes(item)) {
        selectedItems.push(item);
      } else {
        unselectedItems.push(item);
      }
    });
    return [...selectedItems, ...unselectedItems.sort(compareFunction)];
  };

  const pinFilters = (data) => {
    const selectedItems = [];
    const unselectedItems = [];
    data.forEach((item) => {
      if (selectedFilters[heading][levelName].includes(item)) {
        selectedItems.push(item);
      } else {
        unselectedItems.push(item);
      }
    });
    return [...selectedItems, ...unselectedItems];
  };

  useEffect(() => {
    // Initialize expandedData properly based on filteredData and searched
    const filteredEntries = filteredData[heading][levelName];
    const ordered = customOrder(filteredEntries, selectedFilters[heading][levelName]);
    const sortedData = pinFilters(ordered);
    setExpandedData(sortedData);
    // Store the initial order
    setInitialDataOrder(sortedData);
  }, [filteredData, searched, selectedFilters, heading, levelName]);

  useEffect(() => {
    if (isExpanded) {
      const sortedData = sortDataBySelection([...expandedData]);
      setExpandedData(sortedData);
    }
  }, [isExpanded]);

  const handleCheckboxChange = (value) => {
    const isValueSelected = selectedFilters[heading][levelName].includes(value);
    let newState = { ...selectedFilters };
    if (isValueSelected) {
      if (checkIfDefaultFilter(selectedFilters) === true) {
        setIsToastVisible(true);
        return;
      }
      if (checkIfOnlyOneMonthIsSelected(selectedFilters) === true && levelName === 'month') {
        setIsToastVisible(true);
        return;
      }
      setLoading(true);
      newState[heading][levelName] = newState[heading][levelName].filter((item) => item !== value);
    } else {
      setLoading(true);
      newState[heading][levelName] = [...newState[heading][levelName], value];
    }
    setLevelName(levelName);
    setNewState(newState);
    setIsValueSelected(isValueSelected);
    setHeading(heading);
    setFilteredData(filteredData);

    setSelectedFilters(newState);

    // Re-sort data after checkbox change
    const updatedExpandedData = sortDataBySelection(filteredData[heading][levelName]);
    setExpandedData(updatedExpandedData);
  };

  return (
    <>
      {expandedData.length > 0 && (
        <Flex direction="column" alignItems="flex-start" gap={'10px'} w={'100%'}>
          <Flex
            alignItems="center"
            w="100%"
            justifyContent="flex-start"
            style={{ marginTop: '10px', padding: '0' }}>
            <Text
              style={{
                textAlign: 'center',
                fontWeight: 'bold',
                fontSize: '18px',
                fontFamily: 'Jost'
              }}>
              {capitalizeHeading(levelName)}
            </Text>
            {isLevelActive && <Box w="10px" h="10px" bg="#32a852" borderRadius="50%" ml="10px" />}
          </Flex>
          <Grid
            maxHeight="150px"
            overflowY="auto"
            templateColumns="repeat(2, 1fr)"
            minWidth="300px"
            gap={5}>
            {expandedData.slice(0, itemsToShow).map((entry, index) => (
              <GridItem key={index + 1}>
                <Checkbox
                  isChecked={selectedFilters[heading][levelName].includes(entry)}
                  onChange={() => handleCheckboxChange(entry)}
                  key={index + 1}
                  sx={{
                    color: '#333333',
                    fontFamily: 'Jost'
                  }}
                  colorScheme="blue">
                  {entry}
                </Checkbox>
              </GridItem>
            ))}
          </Grid>
          <Flex mt={2} minWidth="300px" justifyContent={'space-between'}>
            {itemsToShow < expandedData.length && (
              <Button
                sx={{ textDecoration: 'underline', fontSize: '13px' }}
                onClick={handleClick}
                variant="link"
                color="blue.500">
                {`+ ${expandedData.length - itemsToShow} more`}
              </Button>
            )}
            {itemsToShow > 4 && (
              <Button
                sx={{ textDecoration: 'underline', fontSize: '13px' }}
                onClick={handleViewLess}
                variant="link"
                color="blue.500">
                View Less
              </Button>
            )}
          </Flex>
        </Flex>
      )}
    </>
  );
};

FilterContent.propTypes = {
  levelName: PropTypes.string.isRequired,
  selectedFilters: PropTypes.object.isRequired,
  setSelectedFilters: PropTypes.func.isRequired,
  heading: PropTypes.string.isRequired,
  filteredData: PropTypes.object.isRequired,
  searched: PropTypes.string.isRequired,
  isLevelActive: PropTypes.bool.isRequired,
  setLevelName: PropTypes.func.isRequired,
  setNewState: PropTypes.func.isRequired,
  setIsValueSelected: PropTypes.func.isRequired,
  setHeading: PropTypes.func.isRequired,
  setFilteredData: PropTypes.func.isRequired,
  setIsToastVisible: PropTypes.func.isRequired,
  setLoading: PropTypes.func.isRequired
};

export default FilterContent;
