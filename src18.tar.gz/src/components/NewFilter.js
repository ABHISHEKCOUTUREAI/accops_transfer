/* eslint-disable no-unused-vars */
import {
  ChakraProvider,
  Flex,
  Text,
  Input,
  Tab,
  TabList,
  TabPanel,
  TabPanels,
  Tabs,
  Box
} from '@chakra-ui/react';
import { headingIcons, capitalizeHeading } from '../util/util_functions';
import React, { useEffect, useState } from 'react';
import FilterContent from './FilterContent';
import { WarningIcon } from '@chakra-ui/icons';
import PropTypes from 'prop-types';
import LoadingSpinner from '../Artifactory/Components/LoadingSpinner/LoadingSpinner';

const CustomToast = ({ title }) => {
  return (
    <Flex
      direction="row"
      justifyContent="center"
      alignItems="center"
      color="red.500"
      p={3}
      bg="white"
      borderWidth="1px"
      borderRadius="md"
      boxShadow="sm"
      textAlign="left">
      <WarningIcon mr={2} />
      <Text fontWeight="bold">{title}</Text>
    </Flex>
  );
};

const NewFilter = (props) => {
  const [filterHeadings, setFilterHeadings] = useState([]);
  const [levelNames, setLevelNames] = useState({});
  const [isToastVisible, setIsToastVisible] = useState(false);
  const [initialLoading, setInitialLoading] = useState(true);

  const refineData = (data) => {
    const headings = Object.keys(data);
    const updatedLevelNames = {};
    Object.keys(data).forEach((filter) => {
      updatedLevelNames[filter] = Object.keys(data[filter]);
    });
    setFilterHeadings(headings);
    setLevelNames(updatedLevelNames);
  };

  const [searched, setSearched] = useState('');
  const [filteredData, setFilteredData] = useState(props.data);

  useEffect(() => {
    refineData(props.data);
    setFilteredData(props.data);
    setInitialLoading(false);
  }, [props.data]);

  useEffect(() => {
    const fd = filterDataOnSearch(props.data, searched, filterHeadings, levelNames);
    setFilteredData(fd);
  }, [searched]);

  function filterDataOnSearch(filter_data, search_term, headings, levelnames) {
    const lowerCaseSearchTerm = search_term.toLowerCase();

    const filterBySearchTerm = (items, searchTerm) => {
      return items.filter((item) => item.toLowerCase().includes(searchTerm));
    };

    const filterLevels = (headingData, levels, searchTerm) => {
      const filteredLevels = {};
      levels.forEach((level) => {
        if (headingData[level]) {
          filteredLevels[level] = filterBySearchTerm(headingData[level], searchTerm);
        }
      });
      return filteredLevels;
    };

    const filterHeadings = (data, headings, levels, searchTerm) => {
      const filteredData = {};
      headings.forEach((heading) => {
        if (data[heading]) {
          filteredData[heading] = filterLevels(data[heading], levels[heading], searchTerm);
        }
      });
      return filteredData;
    };

    return filterHeadings(filter_data, headings, levelnames, lowerCaseSearchTerm);
  }

  const handleSearch = (event) => {
    event.preventDefault();
    setSearched(event.target.value);
  };

  const [activeHeadings, setActiveHeadings] = useState([]);
  const [activeLevelNames, setActiveLevelNames] = useState([]);

  useEffect(() => {
    if (initialLoading) return;

    const active = [];
    const activeLevels = {};
    if (Object.keys(props.selectedFilters).length > 0) {
      Object.entries(props.selectedFilters).forEach(([heading, levels]) => {
        if (Object.values(levels).some((level) => level.length > 0)) {
          active.push(heading);
          activeLevels[heading] = Object.keys(levels).filter((level) => levels[level].length > 0);
        }
      });
    }

    setActiveHeadings(active);
    setActiveLevelNames(activeLevels);
  }, [props.selectedFilters, initialLoading]);

  const handleTabChange = () => {
    setSearched('');
  };

  return (
    <ChakraProvider>
      <Tabs mt={3} isFitted="true" w={'100%'} onChange={handleTabChange}>
        <TabList>
          {filterHeadings.map((heading, index) => {
            const IconComponent = headingIcons[heading];
            const isActive = activeHeadings.includes(heading);
            return (
              <Tab value={index} key={index + 1} justifyContent={'center'} alignItems={'center'}>
                <Flex alignItems={'center'} direction={'row'} gap={'10px'}>
                  {IconComponent}
                  {capitalizeHeading(heading)}
                  {isActive && <Box w="10px" h="10px" bg="#32a852" borderRadius="50%" ml="5px" />}
                </Flex>
              </Tab>
            );
          })}
        </TabList>
        {props.loading ? (
          <LoadingSpinner name="Updated Filters" />
        ) : (
          <TabPanels>
            {filterHeadings.map((heading, index) => {
              return (
                <TabPanel key={index + 1}>
                  <Flex direction={'column'} gap={'20px'}>
                    <Input
                      onChange={handleSearch}
                      value={searched}
                      placeholder={`Enter any ${heading} value`}
                    />
                    <Flex
                      w="100%"
                      maxH={'300px'}
                      h={'fit-content'}
                      overflowY="scroll"
                      direction={'column'}
                      gap={'20px'}>
                      {levelNames[heading].map((ln, ind) => {
                        const isLevelActive = activeLevelNames[heading]?.includes(ln);
                        return (
                          <FilterContent
                            key={ind + 1}
                            heading={heading}
                            levelName={ln}
                            searched={searched}
                            filteredData={filteredData}
                            selectedFilters={props.selectedFilters}
                            setSelectedFilters={props.setSelectedFilters}
                            type={props.type}
                            setNestedData={props.setNestedData}
                            isLevelActive={isLevelActive}
                            setLevelName={props.setLevelName}
                            setNewState={props.setNewState}
                            setIsValueSelected={props.setIsValueSelected}
                            setHeading={props.setHeading}
                            setFilteredData={props.setFilteredData}
                            isToastVisible={isToastVisible}
                            setIsToastVisible={setIsToastVisible}
                            setLoading={props.setLoading}
                          />
                        );
                      })}
                    </Flex>
                  </Flex>
                </TabPanel>
              );
            })}
          </TabPanels>
        )}
      </Tabs>
    </ChakraProvider>
  );
};

CustomToast.propTypes = {
  title: PropTypes.string
};

NewFilter.propTypes = {
  data: PropTypes.object,
  selectedFilters: PropTypes.object,
  loading: PropTypes.bool,
  setSelectedFilters: PropTypes.func,
  setNestedData: PropTypes.func,
  setLevelName: PropTypes.func,
  setLoading: PropTypes.func,
  setNewState: PropTypes.func,
  setFilteredData: PropTypes.func,
  setIsValueSelected: PropTypes.func,
  setHeading: PropTypes.func,
  type: PropTypes.string
};

export default NewFilter;
