import {
  Button,
  ChakraProvider,
  Checkbox,
  Flex,
  Icon,
  Popover,
  PopoverContent,
  PopoverTrigger,
  useDisclosure,
  useToast
} from '@chakra-ui/react';
import React from 'react';
import PropTypes from 'prop-types';
import FilterAltOutlinedIcon from '@mui/icons-material/FilterAltOutlined';

const SelectCharts = ({ visibility, setVisibility, categories }) => {
  const toast = useToast();
  const { onOpen, onClose, isOpen } = useDisclosure();

  const checkIfOnlyOneTrue = (obj) => {
    return Object.values(obj).filter((value) => value === true).length === 1;
  };

  const toggleAllTrue = () => {
    const newState = { ...visibility };
    Object.keys(newState).forEach((key) => (newState[key] = true));
    setVisibility(newState);
  };

  const checkAllTrue = (obj) => Object.values(obj).every((value) => value === true);

  const toggleVisibility = (category) => {
    const newState = { ...visibility };
    if (visibility[category]) {
      const toastId = 'id';
      if (checkIfOnlyOneTrue(visibility) === true) {
        if (!toast.isActive(toastId)) {
          toast({
            id: toastId,
            title: 'Atleast one filter chart must be selected',
            variant: 'subtle',
            isClosable: true,
            position: 'top'
          });
        }
        return;
      }
    }
    newState[category] = !newState[category];
    setVisibility(newState);
  };

  return (
    <ChakraProvider>
      <Popover
        isOpen={isOpen}
        onOpen={onOpen}
        onClose={onClose}
        placement="right"
        closeOnBlur={true}
        preventOverflow={true}>
        <PopoverTrigger>
          <Button leftIcon={<Icon as={FilterAltOutlinedIcon} />}>Show Charts</Button>
        </PopoverTrigger>
        <PopoverContent p={'20px'} w={'fit-content'} h={'fit-content'}>
          <Flex padding={'10px'} direction={'column'} gap={5}>
            <Flex direction={'column'} gap={1}>
              {categories.map((category, index) => (
                <Checkbox
                  isChecked={visibility[category.key]}
                  onChange={() => toggleVisibility(category.key)}
                  key={index + 1}
                  sx={{
                    color: '#333333',
                    fontFamily: 'Jost'
                  }}
                  colorScheme="blue">
                  {category.label}
                </Checkbox>
              ))}
            </Flex>

            <Button
              variant={'outline'}
              size={'sm'}
              onClick={toggleAllTrue}
              isDisabled={checkAllTrue(visibility)}>
              Toggle All
            </Button>
          </Flex>
        </PopoverContent>
      </Popover>
    </ChakraProvider>
  );
};

SelectCharts.propTypes = {
  visibility: PropTypes.object.isRequired,
  setVisibility: PropTypes.func.isRequired,
  categories: PropTypes.array.isRequired
};

export default SelectCharts;
