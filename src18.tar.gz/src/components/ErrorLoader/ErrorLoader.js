/* eslint-disable no-unused-vars */ import {
  Button,
  ChakraProvider,
  Flex,
  Text,
  useTheme
} from '@chakra-ui/react';
import { Warning } from '@mui/icons-material';
import React, { useState } from 'react';
import PropTypes from 'prop-types';

const ErrorLoader = ({ retryApiCall, name }) => {
  const chakratheme = useTheme();
  const [hovered, setHovered] = useState(false);
  return (
    <ChakraProvider>
      <Flex
        bg={`${chakratheme.colors.gray.lighter}`}
        h="100%"
        w="100%"
        p="10px"
        gap={3}
        direction="column"
        justifyContent={'center'}
        alignItems={'center'}
        onMouseEnter={() => setHovered(true)}
        onMouseLeave={() => setHovered(false)}>
        <Warning style={{ color: 'red', fontSize: '30px' }} />
        <Flex gap={2}>
          <Text fontSize={'lg'}>Error occured when retrieving</Text>
          <Flex
            justifyContent={'center'}
            alignItems={'center'}
            as="span"
            bg="gray.100"
            color="gray.800"
            fontFamily="monospace"
            fontSize="md"
            px="1"
            borderRadius="md">
            {name}
          </Flex>
        </Flex>
        <Button mt="5px" colorScheme="teal" size="sm" isDisabled={!hovered} onClick={retryApiCall}>
          Try Again
        </Button>
      </Flex>
    </ChakraProvider>
  );
};

ErrorLoader.propTypes = {
  retryApiCall: PropTypes.func.isRequired,
  name: PropTypes.string.isRequired
};

export default ErrorLoader;
