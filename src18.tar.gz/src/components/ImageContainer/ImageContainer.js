import React from 'react';
import PropTypes from 'prop-types';
import { Box, Flex, Image, Text, useTheme } from '@chakra-ui/react';
import { ExternalLinkIcon } from '@chakra-ui/icons';
import AdsClickIcon from '@mui/icons-material/AdsClick';

const ImageContainer = ({ paginatedData, isQty }) => {
  const chakratheme = useTheme();

  return paginatedData?.map((item, i) => (
    <Flex
      key={i + 1}
      className="card"
      w="30%"
      margin="5px"
      direction="row"
      mt={2}
      style={{
        backgroundColor: 'white',
        color: 'black',
        boxShadow: `${chakratheme.colors.shadow} 0 0 20px 0`,
        borderRadius: '20px',
        fontFamily: 'Hanken Grotesk'
      }}>
      <Flex
        width="40%"
        height="100%"
        direction="column"
        style={{
          backgroundColor: 'white',
          fontFamily: 'Hanken Grotesk',
          borderTopLeftRadius: '20px',
          borderBottomLeftRadius: '20px',
          position: 'relative'
        }}>
        <a
          href={`https://www.ajio.com/p/${item.productid ? item.productid : item.itemid}`}
          target="_blank"
          rel="noopener noreferrer"
          style={{ display: 'block', width: '100%', height: '100%' }}>
          <Box
            position="relative"
            width="100%"
            height="100%"
            borderTopLeftRadius="20px"
            borderBottomLeftRadius="20px"
            overflow="hidden"
            sx={{
              '&::before': {
                content: '""',
                position: 'absolute',
                top: 0,
                left: 0,
                width: '100%',
                height: '100%',
                backgroundColor: 'black',
                opacity: 0,
                transition: 'opacity 0.3s ease',
                borderTopLeftRadius: 'inherit',
                borderBottomLeftRadius: 'inherit'
              },
              '&:hover::before': {
                opacity: 0.5
              }
            }}>
            <Image
              src={
                item.productid
                  ? `https://assets.ajio.com/medias/sys_master/root/${item.imgcode}/${item.id}.jpg`
                  : `https://assets.ajio.com/medias/sys_master/root/${item.imgcode}${item.id}.jpg`
              }
              objectFit="contain"
              style={{
                width: '100%',
                height: '100%',
                borderTopLeftRadius: '20px',
                borderBottomLeftRadius: '20px'
              }}
            />
          </Box>
          <ExternalLinkIcon
            color={chakratheme.colors.white}
            fontSize={'24px'}
            position="absolute"
            bottom="3%"
            right="1%"
            transform="translate(-50%, -50%)"
          />
        </a>
      </Flex>

      <Flex
        direction="column"
        width="60%"
        pl={'30px'}
        pr={'10px'}
        pb={'10px'}
        style={{
          backgroundColor: 'white',
          fontFamily: 'Hanken Grotesk',
          borderTopRightRadius: '20px',
          borderBottomRightRadius: '20px'
        }}>
        <Flex position="relative" direction={'row'} width="100%" alignItems={'center'}>
          <Text m="10px 0 5px 0" fontSize={20} fontWeight={'bold'} color="black">
            {item.brandname}
          </Text>
        </Flex>
        <Flex width="100%" alignItems={'center'}>
          <Text fontFamily="AG2Body-Semibold" fontSize={18} lineHeight={1}>
            {item.title}
          </Text>
        </Flex>
        {isQty === false && (
          <Flex position="relative" direction={'row'} width="100%" alignItems={'center'} my="15px">
            <Text fontSize={18} fontWeight="semibold" color={`${chakratheme.colors.primary.main}`}>
              ₹{item.mrp}
            </Text>
          </Flex>
        )}
        <Flex position="relative" direction={'row'} width="100%" alignItems={'center'}>
          {isQty === false ? (
            <Flex>
              <Box mr={4}>
                <Flex direction={'column'}>
                  <Text fontWeight={'bold'} fontSize={14}>
                    UNITS SOLD
                  </Text>
                  <Box
                    w="20px"
                    h="5px"
                    bg={`${chakratheme.colors.green.main}`}
                    borderRadius="3px"
                    mt={1}
                  />
                </Flex>
                <Text mt={1} fontWeight={'bold'} fontSize={21}>
                  {item.productid ? item.total_qty_sold : item.total_qty}
                </Text>
              </Box>
              <Box ml={4}>
                <Flex direction={'column'}>
                  <Text fontWeight={'bold'} fontSize={14}>
                    RATE OF SALE
                  </Text>
                  <Box
                    w="20px"
                    h="5px"
                    bg={`${chakratheme.colors.orange.medium}`}
                    borderRadius="3px"
                    mt={1}
                  />
                </Flex>
                <Text mt={1} fontWeight={'bold'} fontSize={21}>
                  {item.weekly_rate_of_sale}
                </Text>
              </Box>
            </Flex>
          ) : (
            <Flex mt={4} py={2}>
              <Box>
                <Flex>
                  <AdsClickIcon fontSize="small" />
                  <Flex ml={3} direction={'column'}>
                    <Text fontWeight={'bold'} fontSize={12}>
                      TOTAL CLICKS
                    </Text>
                    <Box
                      w="20px"
                      h="5px"
                      bg={`${chakratheme.colors.orange.medium}`}
                      borderRadius="3px"
                      mt={1}
                    />
                  </Flex>
                </Flex>
                <Text mt={3} fontWeight={'bold'} fontSize={22}>
                  {parseInt(item.total_clicks_query, 10).toLocaleString()}
                </Text>
              </Box>
            </Flex>
          )}
        </Flex>
      </Flex>
    </Flex>
  ));
};

ImageContainer.propTypes = {
  paginatedData: PropTypes.array.isRequired
};

export default ImageContainer;
