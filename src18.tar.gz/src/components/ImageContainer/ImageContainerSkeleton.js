import { Flex, Skeleton, useTheme } from '@chakra-ui/react';
import React from 'react';

const ImageContainerSkeleton = () => {
  const chakratheme = useTheme();
  return (
    <Flex
      wrap="wrap"
      justifyContent="space-between"
      style={{
        padding: '15px 30px 30px 30px',
        backgroundColor: 'white',
        borderRadius: '10px',
        boxShadow: `${chakratheme.colors.shadow} 0 0 20px 0`
      }}>
      {Array(9)
        .fill(null)
        .map((_, i) => (
          <Flex
            key={i + 1}
            className="card"
            w="32%"
            margin="5px"
            direction="row"
            mt={2}
            style={{
              backgroundColor: 'white',
              color: 'black',
              boxShadow: `${chakratheme.colors.shadow} 0 0 20px 0`,
              borderRadius: '20px',
              fontFamily: 'Hanken Grotesk'
            }}>
            <Skeleton variant="rectangular" style={{ width: '100%', height: '220px' }} />
          </Flex>
        ))}
    </Flex>
  );
};

export default ImageContainerSkeleton;
