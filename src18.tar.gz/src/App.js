import React, { useEffect, useState } from 'react';

import { Route, Routes } from 'react-router-dom';

import { Box } from '@chakra-ui/react';
import CustomSidebar from './components/CustomSidebar/CustomSidebar';
import Home from './Views/Home/Home';

import AppBar from './Artifactory/Components/AppBar/AppBar';
import AjioBestSellers from './Views/AjioBestSellers';
import AjioSearchInteractions from './Views/AjioSearchInteractions';
import TrendsOffline from './Views/TrendsOffline';
import GoogleSearchInteractions from './Views/GoogleSearchInteractions';
import Login from './Views/Login';

function App() {
  const [isCollapsed, setIsCollapsed] = useState(true);

  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const isLoggedIn = localStorage.getItem('isLoggedIn');
    const pathname = window.location.pathname;
    if (isLoggedIn === 'true' && (pathname === '/fastfashion/login' || pathname === '/')) {
      window.location.pathname = '/fastfashion/home';
    } else if (isLoggedIn !== 'true' && pathname !== '/fastfashion/login') {
      window.location.pathname = '/fastfashion/login';
    }
    setLoading(false);
  }, []);

  if (loading) {
    return null;
  }

  if (window.location.pathname !== '/fastfashion/login') {
    return (
      <>
        <Box bg={'white'} display="none">
          <AppBar width="100%" name={'Fast Fashion Console'} isCollapsed={isCollapsed} />
          <CustomSidebar isCollapsed={isCollapsed} setIsCollapsed={setIsCollapsed} />
        </Box>
        <Box
          component="main"
          sx={{
            flexGrow: 1,
            transition: 'margin-left 0.3s ease'
          }}>
          <Routes>
            <Route path="/fastfashion" exact element={<Home />} />
            <Route path="/fastfashion/home" exact element={<Home />} />
            <Route path="/fastfashion/trends-offline" exact element={<TrendsOffline />} />
            <Route
              path="/fastfashion/ajio-search-interactions"
              exact
              element={<AjioSearchInteractions />}
            />
            <Route path="/fastfashion/ajio-best-sellers" exact element={<AjioBestSellers />} />
            <Route
              path="/fastfashion/google-search-interactions"
              exact
              element={<GoogleSearchInteractions />}
            />
          </Routes>
        </Box>
      </>
    );
  }

  return (
    <Routes>
      <Route path="/fastfashion/login" element={<Login />} />
    </Routes>
  );
}

export default App;
