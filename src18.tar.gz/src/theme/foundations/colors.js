const colors = {
  white: '#FFFFFF',
  shadow: '#e7e7e7',

  primary: {
    lighter: '#DDE7F1',
    lighter_hover: '#ebf2fa',
    light_hover: '#d0ddeb',
    light: '#59769E',
    main: '#263f5b',
    medium: '#4a5568'
  },

  gray: {
    lighter: '#f5f5f5',
    lighter_hover: '#dddddd',
    light: '#C5C5C5',
    semilight: '#aaaaaa',
    main: '#777777',
    dark: '#333333',
    bg: '#eeeeee',
    hover: '#dddddd',
    filter: 'invert(86%) sepia(0%) saturate(307%) hue-rotate(135deg) brightness(93%) contrast(78%)'
  },

  green: {
    pastel: '#52AF77',
    light: '#E1FCEB',
    main: '#32a852',
    main_hover: '',
    medium: '#37a619',
    dark: '#028525',
    lightbg: '#ecfbdd',
    darkbg: '#c3dbca',
    filter: 'invert(57%) sepia(13%) saturate(2676%) hue-rotate(84deg) brightness(94%) contrast(70%)'
  },

  blue: {
    light: '#caddfc',
    main: '#4287f5',
    dark: '#000ff',
    filter:
      'invert(41%) sepia(74%) saturate(770%) hue-rotate(185deg) brightness(104%) contrast(92%)'
  },

  black: {
    1000: '#000000',
    700: '#444444',
    600: '#555555',
    200: '#aaaaaa'
  },

  orange: {
    light: '#fcf2e1',
    main: '#dd6a1f',
    medium: '#f7cfb5',
    hover: '#eda06d'
  },

  red: {
    pastel: '#ed4c54',
    light: '#fce1e2',
    medium: '#fccbc7',
    main: '#eb4034',
    main_hover: '#e6564c',
    hover: '#e3c7c5',
    filter:
      'invert(34%) sepia(72%) saturate(2087%) hue-rotate(340deg) brightness(92%) contrast(99%)'
  }
};

export default colors;
