import colors from './colors';

const foundations = {
  colors
  //   breakpoints,
  //   blur,
  //   shadow
};

export default foundations;
