import axios from 'axios';
import top_interacted_queries from './mock_data/top_interacted_queries';
import top_interacted_categories from './mock_data/top_interacted_categories';
import top_interacted_brands from './mock_data/top_interacted_brands';
import top_search_queries from './mock_data/top_search_queries';
import top_interacted_product_tiles from './mock_data/top_interacted_product_tiles';
import top_queries_by_session from './mock_data/top_queries_by_session';
import most_interacted_products from './mock_data/most_interacted_products';

import {
  refineDataForSankeyChart,
  refineDataForSankeyChartV2,
  refineDataForTreeMap,
  refineDataForWordCloud
} from '../util/util_functions';
import top_interacted_products from './mock_data/top_interacted_products';
import ajio_best_seller_products from './mock_data/ajio_best_seller_products';
import ajio_best_sellers from './mock_data/ajio_best_sellers';
import neckline_trends from './mock_data/neckline_trends';
import sleevelength_trends from './mock_data/sleevelength_trends';
import google_search_interactions_mock_data from './mock_data/google_search_interactions';

const useMockData = process.env.REACT_APP_USE_MOCK_DATA;

const mockDataMap = {
  //   search interactions products
  'top-interacted-queries': top_interacted_queries,
  'top-interacted-categories': top_interacted_categories,
  'top-interacted-brands': refineDataForWordCloud(top_interacted_brands),
  'top-interacted-product-titles': refineDataForWordCloud(top_interacted_product_tiles),
  'top-queries-by-sessions': refineDataForWordCloud(top_queries_by_session),
  'top-search-queries': top_search_queries,
  'top-interacted-products': top_interacted_products,
  'most-interacted-products': most_interacted_products,

  // ajio pages
  'bestsellers-products-ajio': ajio_best_seller_products,
  'sale-trends-ajio': ajio_best_sellers,
  'neckline-bestsellers-ajio': refineDataForSankeyChart(neckline_trends),
  'sleevelength-bestsellers-ajio': refineDataForSankeyChart(sleevelength_trends),

  // google trends
  'top-search-interactions': google_search_interactions_mock_data
};

const datatypeMap = {
  'sankey-chart': refineDataForSankeyChart,
  'sankey-chart-v2': refineDataForSankeyChartV2,
  'word-cloud': refineDataForWordCloud,
  'tree-map': refineDataForTreeMap
};

const populateData = async (endpoint, setFunction, requestBody, type, name, cancelToken) => {
  setFunction((prev) => {
    return {
      ...prev,
      loading: true
    };
  });
  const url = `${process.env.REACT_APP_API_BASE_URL}/couture/fast-fashion/${endpoint}`;

  let config = {
    method: 'POST',
    url: url,
    data: requestBody,
    withCredentials: true,
    cancelToken: cancelToken
  };

  try {
    const response = await axios(config);
    // data is stored in response.data
    let reqData;
    if (type === null || type === undefined) {
      reqData = response.data;
    } else {
      reqData = datatypeMap[type](response.data, name);
    }
    setFunction(() => {
      return {
        err: false,
        data: reqData,
        loading: false
      };
    });
  } catch (error) {
    if (useMockData === 'true') {
      let mockData = mockDataMap[endpoint];
      setFunction((prev) => {
        return {
          ...prev,
          data: mockData,
          loading: false
        };
      });
    } else if (error.code !== 'ERR_CANCELED') {
      setFunction((prev) => {
        return {
          ...prev,
          err: true,
          loading: false
        };
      });
    }
  }
};

const populateDataTwice = async (endpoint, setFunction, requestBody, setFunction2, cancelToken) => {
  setFunction((prev) => {
    return {
      ...prev,
      loading: true
    };
  });
  setFunction2((prev) => {
    return {
      ...prev,
      loading: true
    };
  });
  const url = `${process.env.REACT_APP_API_BASE_URL}/couture/fast-fashion/${endpoint}`;

  let config = {
    method: 'POST',
    url: url,
    data: requestBody,
    withCredentials: true,
    cancelToken: cancelToken
  };

  try {
    const response = await axios(config);
    // data is stored in response.data
    let reqData = response.data;

    setFunction((prev) => {
      return {
        ...prev,
        data: reqData,
        loading: false
      };
    });
    setFunction2((prev) => {
      return {
        ...prev,
        data: reqData,
        loading: false
      };
    });
  } catch (error) {
    if (useMockData === 'true') {
      let mockData = mockDataMap[endpoint];
      setFunction((prev) => {
        return {
          ...prev,
          data: mockData,
          loading: false
        };
      });
    } else {
      setFunction((prev) => {
        return {
          ...prev,
          err: true,
          loading: false
        };
      });
    }
  }
};

const handlePaginationFunction = async (content, setContent, nestedData, endpoint, tableState) => {
  if (
    content.data.total_count === content.data.rows.length ||
    tableState.page_no < Math.floor(content.data.rows.length / 100)
  ) {
    return;
  }

  let rq = {
    nested_data: {
      ...nestedData
    },
    ...tableState,
    page_no: tableState.page_no === 1 ? 2 : Math.floor(tableState.page_no / 5) + 2
  };

  let config = {
    method: 'POST',
    url: `${process.env.REACT_APP_API_BASE_URL}/couture/fast-fashion/${endpoint}`,
    data: rq,
    withCredentials: true
  };

  axios(config)
    .then(async (response) => {
      setContent((prevData) => ({
        data: {
          rows: [...prevData.data.rows, ...response.data.rows],
          total_count: response.data.total_count // Keep the total_count intact
        }
      }));
    })
    .catch(function () {
      console.log(`error while paginating ${endpoint}`);
    });
};

const updateFiltersOnClick = async (params) => {
  const {
    endpoint,
    setFunction,
    requestBody,
    heading,
    prevData,
    levelNameToExclude,
    isValueSelected,
    cancelToken,
    setLoading
  } = params;
  setFunction((prev) => {
    return {
      ...prev,
      loading: true
    };
  });
  const url = `${process.env.REACT_APP_API_BASE_URL}/couture/fast-fashion/${endpoint}`;

  let config = {
    method: 'POST',
    url: url,
    data: requestBody,
    withCredentials: true,
    cancelToken: cancelToken
  };

  try {
    const response = await axios(config);
    const responseData = response.data;
    let updatedData = {};
    if (!isValueSelected) {
      // Exclude the specific levelName from the updated data
      updatedData = {
        ...responseData,
        [heading]: {
          ...responseData[heading],
          [levelNameToExclude]: prevData[heading][levelNameToExclude]
        }
      };
      updatedData = {
        ...updatedData,
        ['duration']: {
          ...prevData['duration'],
          ['month']: prevData['duration']['month']
        }
      };
    } else {
      updatedData = {
        ...responseData,
        ['duration']: {
          ...responseData['duration'],
          ['month']: prevData['duration']['month']
        }
      };
    }

    setFunction((prev) => ({
      ...prev,
      data: updatedData,
      loading: false
    }));
    setLoading(false);
  } catch (error) {
    console.log('error');
  }
};

const fetchInitialFiltersGeneric = async (
  nestedData,
  setNestedData,
  setInitialFilters,
  endpoint
) => {
  const requestBody = { nested_data: nestedData };

  const config = {
    method: 'post',
    url: `${process.env.REACT_APP_API_BASE_URL}/couture/fast-fashion/${endpoint}`,
    data: requestBody,
    withCredentials: true
  };

  const heading = Object.keys(nestedData)[0];
  const levelName = Object.keys(nestedData[heading])[0];

  try {
    const response = await axios(config);
    setNestedData((prevState) => ({
      ...prevState,
      data: response.data
    }));

    // construct initial filter object from response.data
    if (response.data) {
      const updatedLevelNames = {};
      Object.keys(response.data).forEach((filter) => {
        updatedLevelNames[filter] = Object.keys(response.data[filter]);
      });

      const newInitialFilters = Object.keys(updatedLevelNames).reduce((acc, key) => {
        acc[key] = updatedLevelNames[key].reduce((subAcc, subKey) => {
          if (subKey.toLowerCase() === levelName) {
            subAcc[subKey] = [response.data[heading][levelName][0]];
          } else {
            subAcc[subKey] = [];
          }
          return subAcc;
        }, {});
        return acc;
      }, {});
      setInitialFilters(newInitialFilters);
    }
  } catch (error) {
    console.log('error');
  }
};

const fetchFiltersGeneric = async (nestedData, setNestedData, endpoint) => {
  const requestBody = { nested_data: nestedData };

  const config = {
    method: 'post',
    url: `${process.env.REACT_APP_API_BASE_URL}/couture/fast-fashion/${endpoint}`,
    data: requestBody,
    withCredentials: true
  };

  try {
    const response = await axios(config);
    const responseData = response.data;

    // Remove the month property from duration in responseData
    const { duration, ...otherData } = responseData;
    if (duration) {
      delete duration.month;
    }
    setNestedData((prevState) => ({
      ...prevState,
      data: {
        ...prevState.data,
        ...otherData,
        duration: {
          ...prevState.data.duration,
          ...duration
        }
      }
    }));
  } catch (error) {
    console.log('error');
  }
};

export {
  populateData,
  populateDataTwice,
  handlePaginationFunction,
  updateFiltersOnClick,
  fetchFiltersGeneric,
  fetchInitialFiltersGeneric
};
