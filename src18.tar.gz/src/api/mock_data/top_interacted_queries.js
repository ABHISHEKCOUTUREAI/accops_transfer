const top_interacted_queries = [
  {
    search_term: 'jeans for women',
    total_clicks: 2310923
  },
  {
    search_term: 'kurti',
    total_clicks: 2500123
  },
  {
    search_term: 'shoes',
    total_clicks: 1998192
  },
  {
    search_term: 'kurti',
    total_clicks: 2500123
  },
  {
    search_term: 'shoes',
    total_clicks: 1998192
  }
];

export default top_interacted_queries;
