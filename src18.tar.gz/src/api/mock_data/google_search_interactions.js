const google_search_interactions_mock_data = [
  {
    title: 'Shirts for men',
    number_of_searches: 1273971,
    related_top_searches: [
      'Shirts for women',
      'Shirts for couples',
      'Shirts under 500',
      'T-Shirts',
      'Checked Shirts',
      'Plain T-shirts',
      'V Neck Tshirts under 400'
    ],
    related_rising_searches: [
      'Women T-shirts',
      'Kids T-shirts',
      'dnmx shirts',
      'T-Shirts',
      'Casual t-shirts',
      'Full sleeve t-shirts',
      'V Neck Tshirts under 400'
    ],
    top_interacted_products: [
      {
        id: 23127,
        product_name: 'Wuxi shirt',
        brand: 'wuxi',
        img_url:
          'https://assets.ajio.com/medias/sys_master/root/20231121/5RT6/655cde47ddf7791519931446/-1117Wx1400H-466817674-white-MODEL.jpg'
      },
      {
        id: 23127,
        product_name: 'Wuxi shirt',
        brand: 'wuxi',
        img_url:
          'https://assets.ajio.com/medias/sys_master/root/20231121/5RT6/655cde47ddf7791519931446/-1117Wx1400H-466817674-white-MODEL.jpg'
      },
      {
        id: 23127,
        product_name: 'Wuxi shirt',
        brand: 'wuxi',
        img_url:
          'https://assets.ajio.com/medias/sys_master/root/20231121/5RT6/655cde47ddf7791519931446/-1117Wx1400H-466817674-white-MODEL.jpg'
      },
      {
        id: 23127,
        product_name: 'Wuxi shirt',
        brand: 'wuxi',
        img_url:
          'https://assets.ajio.com/medias/sys_master/root/20231121/5RT6/655cde47ddf7791519931446/-1117Wx1400H-466817674-white-MODEL.jpg'
      },
      {
        id: 23127,
        product_name: 'Wuxi shirt',
        brand: 'wuxi',
        img_url:
          'https://assets.ajio.com/medias/sys_master/root/20231121/5RT6/655cde47ddf7791519931446/-1117Wx1400H-466817674-white-MODEL.jpg'
      }
    ]
  },

  {
    title: 'Denim Jackets for Men',
    number_of_searches: 935621,
    related_top_searches: [
      'Denim Jackets for Women',
      'Denim Jackets for Couples',
      'Denim Jackets under 1000',
      'Hooded Denim Jackets',
      'Distressed Denim Jackets',
      'Oversized Denim Jackets',
      'Black Denim Jackets'
    ],
    related_rising_searches: [
      "Women's Denim Jackets",
      "Kids' Denim Jackets",
      'Blue Denim Jackets',
      "Levi's Denim Jackets",
      'Vintage Denim Jackets',
      'Sleeveless Denim Jackets',
      'White Denim Jackets'
    ],
    top_interacted_products: [
      {
        id: 45783,
        product_name: "Levi's Denim Jacket",
        brand: "Levi's",
        img_url: 'example.com/levis_denim_jacket'
      }
      // More top interacted products for Denim Jackets
    ]
  },
  {
    title: 'Formal Shirts for Men',
    number_of_searches: 784512,
    related_top_searches: [
      'Formal Shirts for Women',
      'Formal Shirts for Couples',
      'Formal Shirts under 1000',
      'Slim Fit Formal Shirts',
      'Plain Formal Shirts',
      'White Formal Shirts',
      'Linen Formal Shirts'
    ],
    related_rising_searches: [
      "Women's Formal Shirts",
      "Kids' Formal Shirts",
      'Cotton Formal Shirts',
      'Black Formal Shirts',
      'Blue Formal Shirts',
      'Printed Formal Shirts',
      'Striped Formal Shirts'
    ],
    top_interacted_products: [
      {
        id: 87623,
        product_name: 'Arrow Formal Shirt',
        brand: 'Arrow',
        img_url: 'example.com/arrow_formal_shirt'
      }
      // More top interacted products for Formal Shirts
    ]
  }
  // Three more entries follow the same pattern
];

export default google_search_interactions_mock_data;
