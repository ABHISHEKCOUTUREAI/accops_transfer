const bar_horizontal_mock_data = {
  dnmx: {
    tshirts: 12381,
    skirts: 13923,
    shoes: 31207,
    jeans: '',
    dresses: 8921,
    hoodies: 6723
  },
  'Pepe Jeans': {
    tshirts: 9823,
    skirts: 732,
    shoes: 20932,
    jeans: 421,
    dresses: 235,
    hoodies: 147
  },
  Fig: {
    tshirts: 30123,
    skirts: 5023,
    shoes: 10045,
    jeans: 3100,
    dresses: 1723,
    hoodies: 935
  },
  Netplay: {
    tshirts: 4567,
    skirts: 789,
    shoes: 3456,
    jeans: 2345,
    dresses: 123,
    hoodies: 678
  },
  'Fashion-Booms': {
    tshirts: 19876,
    skirts: 1234,
    shoes: 5432,
    jeans: 9876,
    dresses: 345,
    hoodies: 321
  },
  TeamSpirit: {
    tshirts: 7023,
    skirts: 456,
    shoes: 6789,
    jeans: 2345,
    dresses: 987,
    hoodies: 543
  }
};

export default bar_horizontal_mock_data;
