const neckline_trends = {
  Mandarin: {
    tshirts: 1654,
    kurtas: 13712,
    shirts: 1231
  },
  V: {
    tshirts: 7567,
    kurtas: 12312,
    shirts: 7689
  }
};
export default neckline_trends;
