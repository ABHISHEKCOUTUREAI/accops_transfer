const sleevelength_trends = [
  {
    puff: {
      tshirts: 12315623,
      shirts: 13712,
      kurtas: 129381263
    },
    'short sleeve': {
      tshirts: 12315623,
      shirts: 13712,
      kurtas: 129381263
    }
  }
];

export default sleevelength_trends;
