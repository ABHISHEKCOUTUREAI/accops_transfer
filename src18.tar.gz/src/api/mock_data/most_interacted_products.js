const most_interacted_products = [
  {
    search_term: "men's shoes",
    month_of_year: 'April',
    week_of_year: 16,
    l1_name: 'men',
    l2_name: 'footwear',
    brick_name: 'casual shoes',
    product_id: 'MS001',
    title: "Men's Paneled Lace Up Shoes",
    brand_name: 'Asian',
    store: 'AJIO',
    row_number_rank: 1,
    total_clicks: 21361
  },
  {
    search_term: "men's shoes",
    month_of_year: 'April',
    week_of_year: 16,
    l1_name: 'men',
    l2_name: 'footwear',
    brick_name: 'casual shoes',
    product_id: 'MS001',
    title: "Men's Paneled Lace Up Shoes",
    brand_name: 'Asian',
    store: 'AJIO',
    row_number_rank: 1,
    total_clicks: 21361
  },
  {
    search_term: "men's shoes",
    month_of_year: 'April',
    week_of_year: 16,
    l1_name: 'men',
    l2_name: 'footwear',
    brick_name: 'casual shoes',
    product_id: 'MS001',
    title: "Men's Paneled Lace Up Shoes",
    brand_name: 'Asian',
    store: 'AJIO',
    row_number_rank: 1,
    total_clicks: 21361
  },
  {
    search_term: "men's shoes",
    month_of_year: 'April',
    week_of_year: 16,
    l1_name: 'men',
    l2_name: 'footwear',
    brick_name: 'casual shoes',
    product_id: 'MS001',
    title: "Men's Paneled Lace Up Shoes",
    brand_name: 'Asian',
    store: 'AJIO',
    row_number_rank: 1,
    total_clicks: 21361
  },
  {
    search_term: "men's shoes",
    month_of_year: 'April',
    week_of_year: 16,
    l1_name: 'men',
    l2_name: 'footwear',
    brick_name: 'casual shoes',
    product_id: 'MS001',
    title: "Men's Paneled Lace Up Shoes",
    brand_name: 'Asian',
    store: 'AJIO',
    row_number_rank: 1,
    total_clicks: 21361
  }
];

export default most_interacted_products;
