const top_interacted_products = [
  {
    id: 23127,
    product_name: 'Wuxi shirt',
    brand: 'wuxi',
    img_url:
      'https://assets.ajio.com/medias/sys_master/root/20231121/5RT6/655cde47ddf7791519931446/-1117Wx1400H-466817674-white-MODEL.jpg'
  },
  {
    id: 23127,
    product_name: 'Wuxi shirt',
    brand: 'wuxi',
    img_url:
      'https://assets.ajio.com/medias/sys_master/root/20231121/5RT6/655cde47ddf7791519931446/-1117Wx1400H-466817674-white-MODEL.jpg'
  },
  {
    id: 23127,
    product_name: 'Wuxi shirt',
    brand: 'wuxi',
    img_url:
      'https://assets.ajio.com/medias/sys_master/root/20231121/5RT6/655cde47ddf7791519931446/-1117Wx1400H-466817674-white-MODEL.jpg'
  },
  {
    id: 23127,
    product_name: 'Wuxi shirt',
    brand: 'wuxi',
    img_url:
      'https://assets.ajio.com/medias/sys_master/root/20231121/5RT6/655cde47ddf7791519931446/-1117Wx1400H-466817674-white-MODEL.jpg'
  },
  {
    id: 23127,
    product_name: 'Wuxi shirt',
    brand: 'wuxi',
    img_url:
      'https://assets.ajio.com/medias/sys_master/root/20231121/5RT6/655cde47ddf7791519931446/-1117Wx1400H-466817674-white-MODEL.jpg'
  },
  {
    id: 23127,
    product_name: 'Wuxi shirt',
    brand: 'wuxi',
    img_url:
      'https://assets.ajio.com/medias/sys_master/root/20231121/5RT6/655cde47ddf7791519931446/-1117Wx1400H-466817674-white-MODEL.jpg'
  }
];

export default top_interacted_products;
