const top_search_queries = [
  {
    month_of_year: 'January',
    week_of_year: 5,
    search_type: 'auto suggestion',
    search_term: 'shirts',
    total_clicks: 65000
  },
  {
    month_of_year: 'January',
    week_of_year: 5,
    search_type: 'auto suggestion',
    search_term: 'shirts',
    total_clicks: 65000
  },
  {
    month_of_year: 'January',
    week_of_year: 5,
    search_type: 'auto suggestion',
    search_term: 'shirts',
    total_clicks: 65000
  },
  {
    month_of_year: 'January',
    week_of_year: 5,
    search_type: 'auto suggestion',
    search_term: 'shirts',
    total_clicks: 65000
  },
  {
    month_of_year: 'January',
    week_of_year: 5,
    search_type: 'auto suggestion',
    search_term: 'shirts',
    total_clicks: 65000
  }
];

export default top_search_queries;
