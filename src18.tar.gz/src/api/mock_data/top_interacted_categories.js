const top_interacted_categories = [
  {
    l1_name: 'Women',
    l2_name: 'Ethnic Wear',
    brick_name: 'Kurtas',
    total_clicks: 163299931
  },
  {
    l1_name: 'Women',
    l2_name: 'Ethnic Wear',
    brick_name: 'Kurtas',
    total_clicks: 163299931
  },
  {
    l1_name: 'Women',
    l2_name: 'Ethnic Wear',
    brick_name: 'Kurtas',
    total_clicks: 163299931
  }
];

export default top_interacted_categories;
