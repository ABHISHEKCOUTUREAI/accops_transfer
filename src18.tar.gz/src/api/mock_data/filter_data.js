const filter_data = {
  duration: {
    month: { March: 1297, February: 1239 },
    week: { 9: 987, 13: 1023, 12: 876, 11: 954, 10: 1015 }
  },
  search_filters: {
    search_type: { 'user completed search': 1574 },
    search_query: { 'formal shirt men': 1120, 't shirts for women': 1389 }
  },
  brick_filters: {
    l1_name: {
      Men: 1435,
      Infants: 1280,
      'Home & Kitchen': 1325,
      Women: 1567,
      Tech: 1478,
      nan: 0,
      'Junior Boys': 1392,
      'Toys & Baby Care': 1347,
      Boys: 1294,
      Girls: 1268
    },
    l2_name: {
      'Fashion Jewellery': 1145,
      Makeup: 1201,
      'Toys & Games': 1256,
      Footwear: 1309,
      Timewear: 1198
    },
    brick_name: { 'Suit Sets': 1132, Skirts: 1107, Tshirts: 1289 }
  },
  attributes: {
    brand: {
      'froh-feet': 1223,
      joven: 1345,
      smiggle: 1197,
      'every-de-by-amante': 1304
    }
  }
};

export default filter_data;
