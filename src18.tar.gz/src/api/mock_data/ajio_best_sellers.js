const ajio_best_sellers = [
  {
    l1_name: 'Category F',
    l2_name: 'Subcategory 6',
    brick_name: 'Brick 6',
    style_type: 'Casual',
    brand_name: 'Brand Z',
    color_family: 'Yellow',
    fit: 'Regular',
    neckline: 'Crew Neck',
    qty_sold: 65
  },
  {
    l1_name: 'Category F',
    l2_name: 'Subcategory 6',
    brick_name: 'Brick 6',
    style_type: 'Casual',
    brand_name: 'Brand Z',
    color_family: 'Yellow',
    fit: 'Regular',
    neckline: 'Crew Neck',
    qty_sold: 65
  },
  {
    l1_name: 'Category F',
    l2_name: 'Subcategory 6',
    brick_name: 'Brick 6',
    style_type: 'Casual',
    brand_name: 'Brand Z',
    color_family: 'Yellow',
    fit: 'Regular',
    neckline: 'Crew Neck',
    qty_sold: 65
  },
  {
    l1_name: 'Category F',
    l2_name: 'Subcategory 6',
    brick_name: 'Brick 6',
    style_type: 'Casual',
    brand_name: 'Brand Z',
    color_family: 'Yellow',
    fit: 'Regular',
    neckline: 'Crew Neck',
    qty_sold: 65
  },
  {
    l1_name: 'Category F',
    l2_name: 'Subcategory 6',
    brick_name: 'Brick 6',
    style_type: 'Casual',
    brand_name: 'Brand Z',
    color_family: 'Yellow',
    fit: 'Regular',
    neckline: 'Crew Neck',
    qty_sold: 65
  },
  {
    l1_name: 'Category F',
    l2_name: 'Subcategory 6',
    brick_name: 'Brick 6',
    style_type: 'Casual',
    brand_name: 'Brand Z',
    color_family: 'Yellow',
    fit: 'Regular',
    neckline: 'Crew Neck',
    qty_sold: 65
  },
  {
    l1_name: 'Category F',
    l2_name: 'Subcategory 6',
    brick_name: 'Brick 6',
    style_type: 'Casual',
    brand_name: 'Brand Z',
    color_family: 'Yellow',
    fit: 'Regular',
    neckline: 'Crew Neck',
    qty_sold: 65
  },
  {
    l1_name: 'Category F',
    l2_name: 'Subcategory 6',
    brick_name: 'Brick 6',
    style_type: 'Casual',
    brand_name: 'Brand Z',
    color_family: 'Yellow',
    fit: 'Regular',
    neckline: 'Crew Neck',
    qty_sold: 65
  }
];

export default ajio_best_sellers;
