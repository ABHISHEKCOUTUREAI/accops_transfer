const ajio_best_seller_products = [
  {
    id: '443007128_white',
    product_name: 'floral print top with spread collar',
    brand: 'fig',
    'weekly rate of sale': 3.25,
    price: 699.0,
    qty_sold: 13,
    image_url:
      'https://assets.ajio.com/medias/sys_master/root/20230111/IQyP/63be9134aeb269c651d778c5/443007128_white.jpg'
  },
  {
    id: '443007128_white',
    product_name: 'floral print top with spread collar',
    brand: 'fig',
    'weekly rate of sale': 3.25,
    price: 699.0,
    qty_sold: 13,
    image_url:
      'https://assets.ajio.com/medias/sys_master/root/20230111/IQyP/63be9134aeb269c651d778c5/443007128_white.jpg'
  },
  {
    id: '441136322_black',
    product_name: 'printed shirt with patch pocket',
    brand: 'fig',
    'weekly rate of sale': 2.75,
    price: 699.0,
    qty_sold: 11,
    image_url:
      'https://assets.ajio.com/medias/sys_master/root/20220211/jN7X/6206801bf997dd03e2cc531b/441136322_black.jpg'
  },
  {
    id: '441136322_black',
    product_name: 'printed shirt with patch pocket',
    brand: 'fig',
    'weekly rate of sale': 2.75,
    price: 699.0,
    qty_sold: 11,
    image_url:
      'https://assets.ajio.com/medias/sys_master/root/20220211/jN7X/6206801bf997dd03e2cc531b/441136322_black.jpg'
  },
  {
    id: '443007128_white',
    product_name: 'floral print top with spread collar',
    brand: 'fig',
    'weekly rate of sale': 2.0,
    price: 699.0,
    qty_sold: 8,
    image_url:
      'https://assets.ajio.com/medias/sys_master/root/20230111/IQyP/63be9134aeb269c651d778c5/443007128_white.jpg'
  },
  {
    id: '443007128_white',
    product_name: 'floral print top with spread collar',
    brand: 'fig',
    'weekly rate of sale': 2.0,
    price: 699.0,
    qty_sold: 8,
    image_url:
      'https://assets.ajio.com/medias/sys_master/root/20230111/IQyP/63be9134aeb269c651d778c5/443007128_white.jpg'
  },
  {
    id: '443007128_white',
    product_name: 'floral print top with spread collar',
    brand: 'fig',
    'weekly rate of sale': 2.0,
    price: 699.0,
    qty_sold: 8,
    image_url:
      'https://assets.ajio.com/medias/sys_master/root/20230111/IQyP/63be9134aeb269c651d778c5/443007128_white.jpg'
  },
  {
    id: '443007128_white',
    product_name: 'floral print top with spread collar',
    brand: 'fig',
    'weekly rate of sale': 2.0,
    price: 699.0,
    qty_sold: 8,
    image_url:
      'https://assets.ajio.com/medias/sys_master/root/20230111/IQyP/63be9134aeb269c651d778c5/443007128_white.jpg'
  },
  {
    id: '443007128_white',
    product_name: 'floral print top with spread collar',
    brand: 'fig',
    'weekly rate of sale': 1.75,
    price: 699.0,
    qty_sold: 7,
    image_url:
      'https://assets.ajio.com/medias/sys_master/root/20230111/IQyP/63be9134aeb269c651d778c5/443007128_white.jpg'
  },
  {
    id: '443007128_white',
    product_name: 'floral print top with spread collar',
    brand: 'fig',
    'weekly rate of sale': 1.75,
    price: 699.0,
    qty_sold: 7,
    image_url:
      'https://assets.ajio.com/medias/sys_master/root/20230111/IQyP/63be9134aeb269c651d778c5/443007128_white.jpg'
  },
  {
    id: '443007128_white',
    product_name: 'floral print top with spread collar',
    brand: 'fig',
    'weekly rate of sale': 1.25,
    price: 699.0,
    qty_sold: 5,
    image_url:
      'https://assets.ajio.com/medias/sys_master/root/20230111/IQyP/63be9134aeb269c651d778c5/443007128_white.jpg'
  },
  {
    id: '443007128_white',
    product_name: 'floral print top with spread collar',
    brand: 'fig',
    'weekly rate of sale': 1.25,
    price: 699.0,
    qty_sold: 5,
    image_url:
      'https://assets.ajio.com/medias/sys_master/root/20230111/IQyP/63be9134aeb269c651d778c5/443007128_white.jpg'
  },
  {
    id: '469189608_black',
    product_name: 'polka-dot round-neck top',
    brand: 'fyre-rose',
    'weekly rate of sale': 1.0,
    price: 999.0,
    qty_sold: 4,
    image_url:
      'https://assets.ajio.com/medias/sys_master/root/20240319/pwia/65f94f8305ac7d77bbc48d20/469189608_black.jpg'
  },
  {
    id: '443008253_peach',
    product_name: 'ditsy print striper top',
    brand: 'rio',
    'weekly rate of sale': 1.0,
    price: 499.0,
    qty_sold: 4,
    image_url:
      'https://assets.ajio.com/medias/sys_master/root/20230227/wNuG/63fcdc6ff997dde6f4cb897d/443008253_peach.jpg'
  },
  {
    id: '443008064_ltblue',
    product_name: 'polka-dot ribbed square-neck top',
    brand: 'rio',
    'weekly rate of sale': 1.0,
    price: 599.0,
    qty_sold: 4,
    image_url:
      'https://assets.ajio.com/medias/sys_master/root/20230315/5Knr/64116615f997dde6f4faca1e/443008064_ltblue.jpg'
  },
  {
    id: '469189608_black',
    product_name: 'polka-dot round-neck top',
    brand: 'fyre-rose',
    'weekly rate of sale': 1.0,
    price: 999.0,
    qty_sold: 4,
    image_url:
      'https://assets.ajio.com/medias/sys_master/root/20240319/pwia/65f94f8305ac7d77bbc48d20/469189608_black.jpg'
  },
  {
    id: '443008253_peach',
    product_name: 'ditsy print striper top',
    brand: 'rio',
    'weekly rate of sale': 1.0,
    price: 499.0,
    qty_sold: 4,
    image_url:
      'https://assets.ajio.com/medias/sys_master/root/20230227/wNuG/63fcdc6ff997dde6f4cb897d/443008253_peach.jpg'
  },
  {
    id: '443008253_peach',
    product_name: 'ditsy print striper top',
    brand: 'rio',
    'weekly rate of sale': 1.0,
    price: 499.0,
    qty_sold: 4,
    image_url:
      'https://assets.ajio.com/medias/sys_master/root/20230227/wNuG/63fcdc6ff997dde6f4cb897d/443008253_peach.jpg'
  },
  {
    id: '443008253_peach',
    product_name: 'ditsy print striper top',
    brand: 'rio',
    'weekly rate of sale': 1.0,
    price: 499.0,
    qty_sold: 4,
    image_url:
      'https://assets.ajio.com/medias/sys_master/root/20230227/wNuG/63fcdc6ff997dde6f4cb897d/443008253_peach.jpg'
  },
  {
    id: '443008064_ltblue',
    product_name: 'polka-dot ribbed square-neck top',
    brand: 'rio',
    'weekly rate of sale': 1.0,
    price: 599.0,
    qty_sold: 4,
    image_url:
      'https://assets.ajio.com/medias/sys_master/root/20230315/5Knr/64116615f997dde6f4faca1e/443008064_ltblue.jpg'
  },
  {
    id: '443008253_peach',
    product_name: 'ditsy print striper top',
    brand: 'rio',
    'weekly rate of sale': 1.0,
    price: 499.0,
    qty_sold: 4,
    image_url:
      'https://assets.ajio.com/medias/sys_master/root/20230227/wNuG/63fcdc6ff997dde6f4cb897d/443008253_peach.jpg'
  },
  {
    id: '441693105_navyblue',
    product_name: 'striped v-neck top',
    brand: 'jdy-by-only',
    'weekly rate of sale': 1.0,
    price: 1499.0,
    qty_sold: 4,
    image_url:
      'https://assets.ajio.com/medias/sys_master/root/20221209/Nm2e/63935a25f997ddfdbdca89b5/441693105_navyblue.jpg'
  },
  {
    id: '443008253_peach',
    product_name: 'ditsy print striper top',
    brand: 'rio',
    'weekly rate of sale': 1.0,
    price: 499.0,
    qty_sold: 4,
    image_url:
      'https://assets.ajio.com/medias/sys_master/root/20230227/wNuG/63fcdc6ff997dde6f4cb897d/443008253_peach.jpg'
  },
  {
    id: '443008253_peach',
    product_name: 'ditsy print striper top',
    brand: 'rio',
    'weekly rate of sale': 1.0,
    price: 499.0,
    qty_sold: 4,
    image_url:
      'https://assets.ajio.com/medias/sys_master/root/20230227/wNuG/63fcdc6ff997dde6f4cb897d/443008253_peach.jpg'
  },
  {
    id: '443008253_peach',
    product_name: 'ditsy print striper top',
    brand: 'rio',
    'weekly rate of sale': 1.0,
    price: 499.0,
    qty_sold: 4,
    image_url:
      'https://assets.ajio.com/medias/sys_master/root/20230227/wNuG/63fcdc6ff997dde6f4cb897d/443008253_peach.jpg'
  },
  {
    id: '441693105_navyblue',
    product_name: 'striped v-neck top',
    brand: 'jdy-by-only',
    'weekly rate of sale': 1.0,
    price: 1499.0,
    qty_sold: 4,
    image_url:
      'https://assets.ajio.com/medias/sys_master/root/20221209/Nm2e/63935a25f997ddfdbdca89b5/441693105_navyblue.jpg'
  },
  {
    id: '443008253_peach',
    product_name: 'ditsy print striper top',
    brand: 'rio',
    'weekly rate of sale': 0.75,
    price: 499.0,
    qty_sold: 3,
    image_url:
      'https://assets.ajio.com/medias/sys_master/root/20230227/wNuG/63fcdc6ff997dde6f4cb897d/443008253_peach.jpg'
  }
];

export default ajio_best_seller_products;
