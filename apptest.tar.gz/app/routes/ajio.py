from fastapi import APIRouter, Depends
from fastapi.responses import JSONResponse
from static import setup_logging
from utils import (
    get_ajio_bestseller_month_count,
    get_ajio_bestseller_month_level,
    get_ajio_bestseller_week_count,
    get_ajio_bestseller_week_level,
    get_ajio_filters_service,
    get_attributes_bestsellers_ajio,
    get_statewise_sales_ajio,
)

AjioRouter = APIRouter(tags=["Ajio"])


@AjioRouter.post("/ajio-filters")
async def get_ajio_filters(
    request_data: dict,
    logger=Depends(setup_logging),
):
    try:
        return await get_ajio_filters_service(request_data)
    except Exception as e:
        logger.error(e, exc_info=True)
        return JSONResponse(content={"error": "Internal Server Error"}, status_code=500)


@AjioRouter.post("/bestsellers-products-ajio")
async def bestseller_ajio(
    request_data: dict,
    logger=Depends(setup_logging),
):
    try:
        if request_data.get("nested_data", {}).get("duration", {}).get("week"):
            result = await get_ajio_bestseller_week_level(request_data)
        else:
            result = await get_ajio_bestseller_month_level(request_data)
        return result
    except Exception as e:
        logger.error(e, exc_info=True)
        return JSONResponse(content={"error": "Internal Server Error"}, status_code=500)


@AjioRouter.post("/bestsellers-ajio-count")
async def bestsellers_count_ajio(
    request_data: dict,
    logger=Depends(setup_logging),
):
    try:
        if request_data.get("nested_data", {}).get("duration", {}).get("week"):
            result = await get_ajio_bestseller_week_count(request_data)
        else:
            result = await get_ajio_bestseller_month_count(request_data)
        return result
    except Exception as e:
        logger.error(e, exc_info=True)
        return JSONResponse(content={"error": "Internal Server Error"}, status_code=500)


@AjioRouter.post("/statewise-sales-ajio")
async def get_statewise_sales(
    request_data: dict,
    logger=Depends(setup_logging),
):
    try:
        return await get_statewise_sales_ajio(request_data)
    except Exception as e:
        logger.error(e, exc_info=True)
        return JSONResponse(content={"error": "Internal Server Error"}, status_code=500)


@AjioRouter.post("/fabric-bestsellers-ajio")
async def get_fabric_bestsellers_ajio(
    request_data: dict,
    logger=Depends(setup_logging),
):
    try:
        result = await get_attributes_bestsellers_ajio(
            request_data,
            attribute="fabrictype",
        )

        return result

    except Exception as e:
        logger.error(e, exc_info=True)
        return JSONResponse(content={"error": "Internal Server Error"}, status_code=500)


@AjioRouter.post("/brandnames-bestsellers-ajio")
async def brandnames_bestsellers_ajio(
    request_data: dict,
    logger=Depends(setup_logging),
):
    try:
        result = await get_attributes_bestsellers_ajio(
            request_data,
            attribute="brandname",
        )
        return result
    except Exception as e:
        logger.error(e, exc_info=True)
        return JSONResponse(content={"error": "Internal Server Error"}, status_code=500)


@AjioRouter.post("/styletype-bestsellers-ajio")
async def styletype_bestsellers_ajio(
    request_data: dict,
    logger=Depends(setup_logging),
):
    try:
        result = await get_attributes_bestsellers_ajio(
            request_data,
            attribute="styletype",
        )
        return result
    except Exception as e:
        logger.error(e, exc_info=True)
        return JSONResponse(content={"error": "Internal Server Error"}, status_code=500)


@AjioRouter.post("/neckline-bestsellers-ajio")
async def neckline_bestsellers_ajio(
    request_data: dict,
    logger=Depends(setup_logging),
):
    try:
        result = await get_attributes_bestsellers_ajio(
            request_data,
            attribute="neckline",
        )
        return result
    except Exception as e:
        logger.error(e, exc_info=True)
        return JSONResponse(content={"error": "Internal Server Error"}, status_code=500)


@AjioRouter.post("/pattern-bestsellers-ajio")
async def pattern_bestsellers_ajio(
    request_data: dict,
    logger=Depends(setup_logging),
):
    try:
        result = await get_attributes_bestsellers_ajio(
            request_data,
            attribute="pattern",
        )
        return result
    except Exception as e:
        logger.error(e, exc_info=True)
        return JSONResponse(content={"error": "Internal Server Error"}, status_code=500)


@AjioRouter.post("/color-bestsellers-ajio")
async def color_bestsellers_ajio(
    request_data: dict,
    logger=Depends(setup_logging),
):
    try:
        result = await get_attributes_bestsellers_ajio(
            request_data,
            attribute="colorfamily",
        )

        return result
    except Exception as e:
        logger.error(e, exc_info=True)
        return JSONResponse(content={"error": "Internal Server Error"}, status_code=500)


@AjioRouter.post("/sleevelength-bestsellers-ajio")
async def sleevelength_bestsellers_ajio(
    request_data: dict,
    logger=Depends(setup_logging),
):
    try:
        result = await get_attributes_bestsellers_ajio(
            request_data,
            attribute="sleevelength",
        )
        return result
    except Exception as e:
        logger.error(e, exc_info=True)
        return JSONResponse(content={"error": "Internal Server Error"}, status_code=500)
