from fastapi import APIRouter

HealthCheckRouter = APIRouter(tags=["HealthCheck"])


@HealthCheckRouter.get("/_healthz")
async def healthz():
    return {"success": True}


@HealthCheckRouter.get("/_readyz")
async def readyz():
    return {"success": True}
