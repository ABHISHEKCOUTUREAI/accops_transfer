from typing import Optional

from fastapi import Query
from pydantic import BaseModel


class ProductQueryParams(BaseModel):
    page: int = Query(1, ge=1)
    page_size: int = Query(100, ge=1)
    gender: Optional[str] = Query(None)
    category: Optional[str] = None
    zone: Optional[str] = None
    state: Optional[str] = None
    city: Optional[str] = None
    pincode: Optional[str] = None
    min_mrp: Optional[int] = Query(None, ge=0)
    max_mrp: Optional[int] = Query(None, ge=0)
    attribute_key: Optional[str] = None
    attribute_value: Optional[str] = None
    sort_attribute: Optional[str] = None
    sort_order: Optional[str] = Query("desc", regex="^(asc|desc)$")


class CategoryQueryParams(BaseModel):
    gender: str = Query("Men")


class AttributeQueryParams(BaseModel):
    page: int = Query(1, ge=1)
    page_size: int = Query(10, ge=1)
    category: Optional[str] = "Ethnic Wear"
    attribute: Optional[str] = "all"
    week: Optional[int] = None


class SearchTrends(BaseModel):
    page: int = Query(1, ge=1)
    page_size: int = Query(5, ge=1)
    num_days: Optional[int] = 35
    category: Optional[str] = None
    brickname: Optional[str] = None


class SearchParams(BaseModel):
    page: int = Query(1, ge=1)
    page_size: int = Query(5, ge=1)
    num_days: Optional[int] = 35
    category: Optional[str] = None
    brickname: Optional[str] = None
    attribute: Optional[str] = "all"


class FilterQuery(BaseModel):
    brandname: Optional[str] = None
    city: Optional[str] = None
    state: Optional[str] = None
    zone: Optional[str] = None
    min_mrp: Optional[int] = None
    max_mrp: Optional[int] = None
