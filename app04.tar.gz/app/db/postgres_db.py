from sqlalchemy import create_engine, MetaData
from sqlalchemy.ext.asyncio import async_scoped_session, create_async_engine, async_sessionmaker
import asyncpg
import asyncio
from concurrent.futures import ThreadPoolExecutor, as_completed
from settings import settings
from  models import AjioBestSellers,  AjioBrickDetails, AjioDemographicDetails, AjioProductAttributes, AjioSearchQueriesTopInteractedProducts,  TrendsBestSellers, TrendsBrickDetails, TrendsProductAttributes, TrendsStoreDetails,  SearchInteractions

SQLALCHEMY_DATABASE_URL = "postgresql://" + settings.postgres_user + ":" + settings.postgres_password + "@" + settings.postgres_service + ":"  + settings.postgres_port +"/" + settings.postgres_db
SQLALCHEMY_DATABASE_URL_ASYNC  = "postgresql+asyncpg://" + settings.postgres_user + ":" + settings.postgres_password + "@" + settings.postgres_service + ":" + settings.postgres_port +"/" + settings.postgres_db

postgres_engine = create_engine(
    SQLALCHEMY_DATABASE_URL,
)

def create_async_factory(url):
    postgres_engine_async = create_async_engine(
        url,
        pool_size=settings.postgres_pool_size, #Number of connections that can be used by the application
        max_overflow=settings.postgres_max_overflow, #Max nu of additional connections that can be created
    )

    async_session_factory = async_sessionmaker(
        expire_on_commit=False,
        bind=postgres_engine_async
    )

    meta = MetaData()
    meta.bind = postgres_engine_async

    async_session_db = async_scoped_session(
        session_factory=async_session_factory,
        scopefunc=asyncio.current_task
    )

    return async_session_db

async def psql_session():
    retry_count = 0
    while retry_count<=2:
        try:
            sessionfactory = create_async_factory(SQLALCHEMY_DATABASE_URL_ASYNC)
            session = sessionfactory()
            yield session
            await session.close()
            break
        except asyncpg.exceptions.TooManyConnectionsError as e:
            print("Too many connections error: ", e)
            retry_count += 1
            if retry_count > 2:
                retry_count = 0
                raise e
            await asyncio.sleep(2)
        except Exception as e:
            raise e

async def psql_execute_multiple(session, query_list):
    with ThreadPoolExecutor(max_workers=20) as executor:
        # Pair each query with its index
        futures = {executor.submit(session.execute, query): index for index, query in enumerate(query_list)}
        result = [None] * len(query_list)  # Prepare a list to store results in the original order

        for future in as_completed(futures):
            try:
                index = futures[future]  # Get the index of the completed future
                result[index] = (await future.result()).fetchall()  # Store the result in the correct position
            except Exception as e:
                print("Error in fetching data: ", e)
                raise e
        
        return result
    
async def psql_execute_single(query):
    retry_count = 0
    while retry_count<=2:
        try:
            sessionfactory = create_async_factory(SQLALCHEMY_DATABASE_URL_ASYNC)
            session = sessionfactory()
            result = (await session.execute(query)).fetchall()
            await session.close()
        except asyncpg.exceptions.TooManyConnectionsError as e:
            print("Too many connections error: ", e)
            retry_count += 1
            if retry_count > 2:
                retry_count = 0
                raise e
                raise e
            await asyncio.sleep(2)
        finally:
            break
    return result

AjioBestSellers.__table__.create(bind=postgres_engine, checkfirst=True)
AjioProductAttributes.__table__.create(bind=postgres_engine, checkfirst=True)
AjioBrickDetails.__table__.create(bind=postgres_engine, checkfirst=True)
AjioDemographicDetails.__table__.create(bind=postgres_engine, checkfirst=True)
AjioSearchQueriesTopInteractedProducts.__table__.create(bind=postgres_engine, checkfirst=True)
TrendsBestSellers.__table__.create(bind=postgres_engine, checkfirst=True)
TrendsBrickDetails.__table__.create(bind=postgres_engine, checkfirst=True)
TrendsProductAttributes.__table__.create(bind=postgres_engine, checkfirst=True)
TrendsStoreDetails.__table__.create(bind=postgres_engine, checkfirst=True)        
SearchInteractions.__table__.create(bind=postgres_engine, checkfirst=True)
print("Postgres table created")
