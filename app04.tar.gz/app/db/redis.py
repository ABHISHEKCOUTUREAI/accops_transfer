from redis import asyncio as aioredis
from settings import settings

try:
    redis_url = f'redis://{settings.redis_service}:{settings.redis_port}/{settings.redis_db}'
    redis_db = aioredis.from_url(redis_url)
    print("Connected to Redis")
except Exception as e:
    print(f"Error connecting to Redis: {e}")
    redis_db = None

async def set_redis_state(flush_db: bool = settings.redis_state):
    if flush_db:
        await redis_db.flushdb()
        print("Redis state set to initial state")
    else:
        print("Redis state retained")

async def flush_redis_key(key: str):
    keys = await redis_db.keys(f"{key}*")
    await redis_db.delete(*keys)
    print(f"Deleted keys starting with {key}")

async def check_in_redis(cache_key):
    try:
        cached_data = await redis_db.get(cache_key)
    except Exception as e:
        print("Not connected to redis: ", e)
        cached_data = None

    return cached_data
