from sqlalchemy import Column, String, Float, Integer, BigInteger
from sqlalchemy.ext.declarative import declarative_base

Base = declarative_base()

class AjioBestSellers(Base):
    __tablename__ = "ajio_bestsellers_pincodes_top500"
    year = Column(Integer, primary_key=True)
    month_of_year = Column(Integer, primary_key=True)
    quarter_of_year = Column(Integer)
    week_of_year = Column(Integer, primary_key=True)
    pincode = Column(String, primary_key=True)
    productid = Column(String, primary_key=True)
    mrp = Column(Float)
    availablequantity_in_a_week = Column(BigInteger)
    sold_quantity_in_a_week = Column(BigInteger)

class AjioProductAttributes(Base):
    __tablename__ = "ajio_product_attributes"
    productid = Column(String, primary_key=True)
    similargrouplevel = Column(String, primary_key=True)
    colorfamily = Column(String)
    fabrictype = Column(String)
    materialtype = Column(String)
    pattern = Column(String)
    sleevelength = Column(String)
    brandname = Column(String)
    occasion = Column(String)
    bodytype = Column(String)
    fit = Column(String)
    distress = Column(String)
    traditionalweave = Column(String)
    neckline = Column(String)
    hemline = Column(String)
    styletype = Column(String)
    title = Column(String)
    catalogid = Column(String)
    imgcode = Column(String)


class AjioBrickDetails(Base):
    __tablename__ = "ajio_brick_details"
    similargrouplevel = Column(String, primary_key=True)
    l1name = Column(String)
    l2name = Column(String)
    brickname = Column(String)


class AjioDemographicDetails (Base):
    __tablename__ = "ajio_demographic_details"
    pincode = Column(String, primary_key=True)
    state = Column(String)
    city = Column(String)
    districtsname = Column(String)
    zone = Column(String)


class AjioSearchQueriesTopInteractedProducts(Base):
    __tablename__ = "ajio_search_queries_top_interacted_products"
    year = Column(Integer, primary_key=True)
    month_of_year = Column(Integer, primary_key=True)
    week_of_year = Column(Integer, primary_key=True)
    search_type = Column(String, primary_key=True)
    normalized_search_term = Column(String, primary_key=True)
    productid = Column(String, primary_key=True)
    sum_session_counts = Column(BigInteger)
    impressions_product = Column(BigInteger)
    clicks_product = Column(BigInteger)
    total_clicks_query = Column(BigInteger)


class TrendsBestSellers(Base):
    __tablename__ = "trends_bestsellers_storeids_zonelevel_top100"
    year = Column(Integer, primary_key=True)
    quarter_of_year = Column(Integer)
    month_of_year = Column(Integer, primary_key=True)
    week_of_year = Column(Integer, primary_key=True)
    itemid = Column(String, primary_key=True)
    store_id = Column(String, primary_key=True)
    sold_quantity_in_a_week = Column(BigInteger)
    availablequantity_in_a_week = Column(BigInteger)


class TrendsProductAttributes(Base):
    __tablename__ = "trends_product_attributes"
    itemid = Column(String, primary_key=True)
    similargrouplevel = Column(String)
    primarycolor = Column(String)
    fabrictype = Column(String)
    materialtype = Column(String)
    pattern = Column(String)
    sleeve = Column(String)
    fit = Column(String)
    neckline = Column(String)
    styletype = Column(String)
    fashion_grade_description = Column(String)
    mrp = Column(Float)
    brandname = Column(String)
    imgcode = Column(String)
    extension = Column(String)

class TrendsStoreDetails(Base):
    __tablename__ = "trendsstoredetails"
    store_id = Column(String, primary_key=True)
    pin_code = Column(String)
    format_cd = Column(String)
    format_desc = Column(String)
    city = Column(String)
    region = Column(String)
    location = Column(String)
    store_short_name = Column(String)
    store_area = Column(String)
    state = Column(String)
    zone_desc = Column(String)
    store_class_desc = Column(String)
    districtsname = Column(String)


class TrendsBrickDetails(Base):
    __tablename__ = "trendsbrickdetails"
    similargrouplevel = Column(String, primary_key=True)
    mh_family_desc = Column(String)
    mh_class_desc = Column(String)
    brickname = Column(String)


class SearchInteractions(Base):
    __tablename__ = "search_interactions"
    id = Column(Integer, primary_key=True, auto_increment=True)
    category = Column(String)
    related_top_searches = Column(String)
    number_of_top_searches = Column(Integer)
    related_rising_searches = Column(String)
    number_of_rising_searches = Column(Integer)

request_column_model_map  = {
    'month': {
        'model': {
            'ajio': AjioBestSellers,
            'trends': TrendsBestSellers,
            'ajio-search': AjioSearchQueriesTopInteractedProducts
        },
        'column': 'month_of_year'
    },
    'week': {
        'model': {
            'ajio-search': AjioSearchQueriesTopInteractedProducts
        },
        'column': 'week_of_year'
    },
    'search_type': {
        'model': {
            'ajio-search': AjioSearchQueriesTopInteractedProducts
        },
        'column': 'search_type'
    },
    'search_query': {
        'model': {
            'ajio-search': AjioSearchQueriesTopInteractedProducts
        },
        'column': 'normalized_search_term'
    },
    'quarter': {
        'model': {
            'ajio': AjioBestSellers,
            'trends': TrendsBestSellers
        },
        'column': 'quarter_of_year'
    },
    'zone': {
        'model': {
            'ajio': AjioDemographicDetails,
            'trends': TrendsStoreDetails
        },
        'column': 'zone'
    },
    'state': {
        'model': {
            'ajio': AjioDemographicDetails,
            'trends': TrendsStoreDetails
        },
        'column': 'state'
    },
    'city': {
        'model': {
            'ajio': AjioDemographicDetails,
            'trends': TrendsStoreDetails
        },
        'column': 'city'
    },
    'pincode': {
        'model': {
            'ajio': AjioDemographicDetails,
            'trends': TrendsStoreDetails
        },
        'column': 'pincode'
    },
    'district': {
        'model': {
            'ajio': AjioDemographicDetails,
            'trends': TrendsStoreDetails
        },
        'column': 'districtsname'
    },
    'brand': {
        'model': {
            'ajio': AjioProductAttributes,
            'trends': TrendsProductAttributes,
            'ajio-search': AjioProductAttributes
        },
        'column': 'brandname'
    },
    'styletype': {
        'model': {
            'ajio': AjioProductAttributes,
            'trends': TrendsProductAttributes
        },
        'column': 'styletype'
    },
    'neckline': {
        'model': {
            'ajio': AjioProductAttributes,
            'trends': TrendsProductAttributes
        },
        'column': 'neckline'
    },
    'pattern': {
        'model': {
            'ajio': AjioProductAttributes,
            'trends': TrendsProductAttributes
        },
        'column': 'pattern'
    },
    'fabric_type': {
        'model': {
            'ajio': AjioProductAttributes,
            'trends': TrendsProductAttributes
        },
        'column': 'fabrictype'
    },
    'sleeve': {
        'model': {
            'ajio': AjioProductAttributes,
            'trends': TrendsProductAttributes
        },
        'column': 'sleevelength'
    },
    'fit': {
        'model': {
            'ajio': AjioProductAttributes,
            'trends': TrendsProductAttributes
        },
        'column': 'fit'
    },
    'color': {
        'model': {
            'ajio': AjioProductAttributes,
            'trends': TrendsProductAttributes
        },
        'column': 'colorfamily'
    },
    'l1_name': {
        'model': {
            'ajio': AjioBrickDetails,
            'ajio-search': AjioBrickDetails
        },
        'column': 'l1name'
    },
    'l2_name': {
        'model': {
            'ajio': AjioBrickDetails,
            'ajio-search': AjioBrickDetails
        },
        'column': 'l2name'
    },
    'brick_name': {
        'model': {
            'ajio': AjioBrickDetails,
            'ajio-search': AjioBrickDetails
        },
        'column': 'brickname'
    },
    'occasion': {
        'model': {
            'ajio': AjioProductAttributes
        },
        'column': 'occasion'
    },
    'bodytype': {
        'model': {
            'ajio': AjioProductAttributes
        },
        'column': 'bodytype'
    },
    'materialtype': {
        'model': {
            'ajio': AjioProductAttributes
        },
        'column': 'materialtype'
    },
    'distress': {
        'model': {
            'ajio': AjioProductAttributes
        },
        'column': 'distress'
    },
    'traditionalweave': {
        'model': {
            'ajio': AjioProductAttributes
        },
        'column': 'traditionalweave'
    },
    'hemline': {
        'model': {
            'ajio': AjioProductAttributes
        },
        'column': 'hemline'
    },
    'store_id': {
        'model': {
            'trends': TrendsBestSellers
        },
        'column': 'store_id'
    },
    'category': {
        'model': {
            'trends': TrendsBrickDetails
        },
        'column': 'brickname'
    },
    'category_class': {
        'model': {
            'trends': TrendsBrickDetails
        },
        'column': 'mh_class_desc'
    },
    'category_family': {
        'model': {
            'trends': TrendsBrickDetails
        },
        'column': 'mh_family_desc'
    },
}
