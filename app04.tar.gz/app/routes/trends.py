from fastapi import APIRouter, Depends
from collections import defaultdict
import asyncio
import json
from sqlalchemy import select, func, and_, cast, Numeric
from .commons import select_filter_subquery, build_filter_condition
from models import TrendsBestSellers, TrendsBrickDetails, TrendsProductAttributes, TrendsStoreDetails
from utils import  indian_states, create_filter_query, sort_and_paginate, month_mapping, sort_response_using_cache
from db import redis_db, psql_session, psql_execute_multiple, psql_execute_single, check_in_redis

TrendsRouter = APIRouter(
    prefix="/couture/fast-fashion",
    tags=["Trends"],
    responses={404: {"description": "Not found"}},
)

async def get_attributes_bestsellers_trends(
    request_data,
    attribute: str,
    postgres_db
):
    
    product_filter, brick_filter, duration_filter, demographic_filter = await asyncio.gather(
        build_filter_condition(type = 'trends', request_filters = request_data, filter_flag = 'products'),
        build_filter_condition(type = 'trends', request_filters = request_data, filter_flag = 'category'),
        build_filter_condition(type = 'trends', request_filters = request_data, filter_flag = 'bestsellers'),
        build_filter_condition(type = 'trends', request_filters = request_data, filter_flag = 'store_filters')
    )

    product_query = select(
        getattr(TrendsProductAttributes, attribute),
        TrendsProductAttributes.itemid,
        TrendsProductAttributes.similargrouplevel,
    ).where(and_(*product_filter, getattr(TrendsProductAttributes, attribute) != None)).subquery()
    
    brick_query = select(
        TrendsBrickDetails.brickname,
        TrendsBrickDetails.similargrouplevel
    ).where(and_(*brick_filter)).subquery()
    
    sold_in_week_query = select(
        TrendsBestSellers.sold_quantity_in_a_week,
        TrendsBestSellers.itemid,
        TrendsBestSellers.store_id
    ).where(and_(*duration_filter)).subquery()

    store_query = select(
        TrendsStoreDetails.store_id,
    ).where(and_(*demographic_filter)).subquery()
    
    # join all three queries
    query = select(
        getattr(product_query.c, attribute),
        brick_query.c.brickname,
        func.sum(sold_in_week_query.c.sold_quantity_in_a_week).label("quantity"),
    ).join(
        brick_query,
        product_query.c.similargrouplevel == brick_query.c.similargrouplevel
    ).join(
        sold_in_week_query,
        product_query.c.itemid == sold_in_week_query.c.itemid
    ).join(
        store_query,
        sold_in_week_query.c.store_id == store_query.c.store_id
    ).group_by(
        getattr(product_query.c, attribute),
        brick_query.c.brickname,
    ).order_by(
        func.sum(sold_in_week_query.c.sold_quantity_in_a_week).desc()
    )

    rows = (await postgres_db.execute(query)).fetchall()
    result = defaultdict(dict)
    for row in rows:
        if row[0]:
            result[row[1]][row[0]] = float(row[2])

    return result

@TrendsRouter.post("/trends-filters-structure")
async def get_filters_structure(
    request_data: dict
):
    cache_key = f"trends-filters-structure-{json.dumps(request_data)}"
    cached_data = await check_in_redis(cache_key)
        
    if cached_data:
        return json.loads(cached_data)
    
    response_data = defaultdict(dict)
    response_data['attributes'] = {
        "brand": [],
        "styletype": [],
        "neckline": [], 
        "pattern": [], 
        "fabric_type": [], 
        "sleeve": [], 
        "fit": [],
        "color": []
    }
    response_data['category'] = {
        "category": [],
        "category_class": [],
        "category_family": [],
    }
    response_data['demographic'] = {
        "zone": [], 
        "state": [], 
        "city": [], 
        "district": [],
    }
    response_data['duration'] = {
        "month": [], 
        "quarter": [], 
    }
    response_data['store_filters'] = {
        "pincode": [], 
        "store_id": [],
    }

    return await build_filter_condition(
        request_filters = request_data,
        initial = True, 
        initial_filters_body = response_data,
        type = 'trends'
    )
    

async def create_trends_filter_query(request_data):

    duration_filter, store_filter, brick_filter, product_filter = await asyncio.gather(
        build_filter_condition(type = 'trends', request_filters = request_data, filter_flag = 'bestsellers'),
        build_filter_condition(type = 'trends', request_filters = request_data, filter_flag = 'store_filters'),
        build_filter_condition(type = 'trends', request_filters = request_data, filter_flag = 'category'),
        build_filter_condition(type = 'trends', request_filters = request_data, filter_flag = 'products')
    )
    
    duration_columns = ['month_of_year', 'quarter_of_year', 'itemid', 'store_id']
    store_columns = ['zone_desc', 'state', 'city', 'districtsname', 'pin_code', 'store_id']
    brick_columns = ['mh_family_desc', 'mh_class_desc', 'brickname', 'similargrouplevel']
    product_columns = ['similargrouplevel', 'itemid', 'styletype', 'neckline', 'pattern', 'fabrictype', 'sleeve', 'fit', 'primarycolor', 'brandname']

    duration_query, store_query, brick_query, product_query = await asyncio.gather(
        select_filter_subquery(TrendsBestSellers, list(duration_filter), duration_columns),
        select_filter_subquery(TrendsStoreDetails, list(store_filter), store_columns),
        select_filter_subquery(TrendsBrickDetails, list(brick_filter), brick_columns),
        select_filter_subquery(TrendsProductAttributes, list(product_filter), product_columns)
    )

    query = select(
        duration_query.c.month_of_year,
        duration_query.c.quarter_of_year,
        store_query.c.zone_desc,
        store_query.c.state,
        store_query.c.city,
        store_query.c.districtsname,
        store_query.c.pin_code,
        store_query.c.store_id,
        brick_query.c.mh_family_desc,
        brick_query.c.mh_class_desc,
        brick_query.c.brickname,
        product_query.c.styletype,
        product_query.c.neckline,
        product_query.c.pattern,
        product_query.c.fabrictype,
        product_query.c.sleeve,
        product_query.c.fit,
        product_query.c.primarycolor,
        product_query.c.brandname
    ).join(
        store_query,
        duration_query.c.store_id == store_query.c.store_id 
    ).join(
        product_query,
        product_query.c.itemid == duration_query.c.itemid
    ).join(
        brick_query,
        brick_query.c.similargrouplevel == product_query.c.similargrouplevel
    )

    return query

@TrendsRouter.post("/trends-filters-cache")
async def get_trends_filters_cache(
    request_data: dict,
    postgres_db = Depends(psql_session)
):
    cache_key = "trends_filters_cache"
    cached_data = await check_in_redis(cache_key)
        
    if cached_data:
        return json.loads(cached_data)

    query = await create_trends_filter_query(request_data)

    query_list = await asyncio.gather(
        create_filter_query(query, 'month_of_year'),
        create_filter_query(query, 'quarter_of_year'),
        create_filter_query(query, 'zone_desc'),
        create_filter_query(query, 'state'),
        create_filter_query(query, 'city'),
        create_filter_query(query, 'districtsname'),
        create_filter_query(query, 'pin_code'),
        create_filter_query(query, 'store_id'),
        create_filter_query(query, 'mh_family_desc'),
        create_filter_query(query, 'mh_class_desc'),
        create_filter_query(query, 'brickname'),
        create_filter_query(query, 'styletype'),
        create_filter_query(query, 'neckline'),
        create_filter_query(query, 'pattern'),
        create_filter_query(query, 'fabrictype'),
        create_filter_query(query, 'sleeve'),
        create_filter_query(query, 'fit'),
        create_filter_query(query, 'primarycolor'),
        create_filter_query(query, 'brandname')
    )

    result = [(await postgres_db.execute(query)).fetchall() for query in query_list]

    response = defaultdict(dict)

    response['demographic'] = {
        "zone": [val[0] for val in result[2] if val[0] != 'nan'], 
        "state": [val[0]for val in result[3] if val[0] != 'nan'],
        "city": [val[0]for val in result[4] if val[0] != 'nan'],
        "district": [val[0]for val in result[5] if val[0] != 'nan']
    }
    response['category'] = {
        "category_family": [val[0]for val in result[8] if val[0] != 'nan'],
        "category_class": [val[0]for val in result[9] if val[0] != 'nan'],
        "category": [val[0]for val in result[10] if val[0] != 'nan']
    }
    response['attributes'] = {
        "styletype": [val[0]for val in result[11] if val[0] != 'nan'],
        "neckline": [val[0]for val in result[12] if val[0] != 'nan'],
        "pattern": [val[0]for val in result[13] if val[0] != 'nan'],
        "fabric_type": [val[0]for val in result[14] if val[0] != 'nan'],
        "sleeve": [val[0]for val in result[15] if val[0] != 'nan'],
        "fit": [val[0]for val in result[16] if val[0] != 'nan'],
        "color": [val[0]for val in result[17] if val[0] != 'nan'],
        "brand": [val[0]for val in result[18] if val[0] != 'nan']
    }  
    response['store_filters'] = {
        "pincode": [val[0]for val in result[6] if val[0] != 'nan'],
        "store_id": [val[0]for val in result[7] if val[0] != 'nan']
    }
    response['duration'] = {
       "month" :  [month_mapping[val[0]]for val in result[0] if val[0] != 'nan'],
       "quarter": [str(val[0]) for val in result[1] if val[0] != 'nan']
    }

    try:
        await redis_db.set(cache_key, json.dumps(response, default=str))
    except Exception as e:
        print("Error while writing to redis: ", e)

    return response


@TrendsRouter.post("/trends-filters")
async def get_trends_filters(
    request_data: dict,
    postgres_db = Depends(psql_session)
):
    cache_key = f"trends_filters{json.dumps(request_data)}"
    cached_data = await check_in_redis(cache_key)
        
    if cached_data:
        return json.loads(cached_data)
    
    query = await create_trends_filter_query(request_data)

    result = (await postgres_db.execute(query)).fetchall()
    
    
    response = {
        'demographic': {
            'zone': list(set([val[2] for val in result if val[2] != 'nan'])), 
            'state': list(set([val[3] for val in result if val[3] != 'nan'])),
            'city': list(set([val[4] for val in result if val[4] != 'nan'])),
            'district': list(set([val[5] for val in result if val[5] != 'nan']))
        },
        'category': {
            'category_family': list(set([val[8] for val in result if val[8] != 'nan'])),
            'category_class': list(set([val[9] for val in result if val[9] != 'nan'])),
            'category': list(set([val[10] for val in result if val[10] != 'nan']))
        },
        'attributes': {
            'styletype': list(set([val[11] for val in result if val[11] != 'nan'])),
            'neckline': list(set([val[12] for val in result if val[12] != 'nan'])),
            'pattern': list(set([val[13] for val in result if val[13] != 'nan'])),
            'fabric_type': list(set([val[14] for val in result if val[14] != 'nan'])),
            'sleeve': list(set([val[15] for val in result if val[15] != 'nan'])),
            'fit': list(set([val[16] for val in result if val[16] != 'nan'])),
            'color': list(set([val[17] for val in result if val[17] != 'nan'])),
            'brand': list(set([val[18] for val in result if val[18] != 'nan']))
        },
        'store_filters': {
            'pincode': list(set([val[6] for val in result if val[6] != 'nan'])),
            'store_id': list(set([val[7] for val in result if val[7] != 'nan']))
        },
        'duration': {
            'month': list(set([month_mapping[val[0]] for val in result if val[0] != 'nan'])),
            'quarter': list(set([str(val[1]) for val in result if val[1] != 'nan']))
        }
    }

    cache_response = await check_in_redis("trends_filters_cache")
    if cache_response:
        cache_response = json.loads(cache_response)
    else:
        cache_response = defaultdict(dict)

    # Sort the response using the cache_response
    response = await sort_response_using_cache(response, cache_response)

    try:
        await redis_db.set(cache_key, json.dumps(response, default=str))
    except Exception as e:
        print("Error while writing to redis: ", e)

    return response


@TrendsRouter.post("/bestsellers-products-trends")
async def bestsellers_products_trends(
    request_data: dict,
    postgres_db = Depends(psql_session)
):

    cache_key = f"bestsellers-products-trends-{json.dumps(request_data)}"
    cached_data = await check_in_redis(cache_key)
        
    if cached_data:
        return json.loads(cached_data)

    bestseller_filter, product_filter, store_filter, brick_filter = await asyncio.gather(
        build_filter_condition(type = 'trends', request_filters = request_data, filter_flag = 'bestsellers'),
        build_filter_condition(type = 'trends', request_filters = request_data, filter_flag = 'products'),
        build_filter_condition(type = 'trends', request_filters = request_data, filter_flag = 'store_filters'),
        build_filter_condition(type = 'trends', request_filters = request_data, filter_flag = 'category')
    )

    bestseller_query = select(
        TrendsBestSellers.itemid,
        TrendsBestSellers.week_of_year,
        TrendsBestSellers.store_id,
        TrendsBestSellers.sold_quantity_in_a_week,
    ).where(
        and_(*bestseller_filter)
    ).subquery()

    product_query = select(
        TrendsProductAttributes.itemid,
        TrendsProductAttributes.brandname,
        TrendsProductAttributes.styletype,
        TrendsProductAttributes.primarycolor,
        TrendsProductAttributes.pattern,
        TrendsProductAttributes.fabrictype,
        TrendsProductAttributes.materialtype,
        TrendsProductAttributes.sleeve,
        TrendsProductAttributes.fit,
        TrendsProductAttributes.neckline,
        TrendsProductAttributes.imgcode,
        TrendsProductAttributes.extension,
        TrendsProductAttributes.mrp,
        TrendsProductAttributes.similargrouplevel
    ).where(
        and_(*product_filter)
    ).subquery()
    
    store_query = select(
        TrendsStoreDetails.store_id,
    ).where(
        and_(*store_filter)
    ).subquery()

    brick_query = select(
        TrendsBrickDetails.mh_family_desc,
        TrendsBrickDetails.mh_class_desc,
        TrendsBrickDetails.brickname,
        TrendsBrickDetails.similargrouplevel,
    ).where(
        and_(*brick_filter)
    ).subquery()

    query = select(
        product_query.c.itemid,
        product_query.c.brandname,
        product_query.c.styletype,
        product_query.c.primarycolor,
        product_query.c.pattern,
        product_query.c.fabrictype,
        product_query.c.materialtype,
        product_query.c.sleeve,
        product_query.c.fit,
        product_query.c.neckline,
        product_query.c.imgcode,
        product_query.c.extension,
        brick_query.c.mh_family_desc,  
        brick_query.c.mh_class_desc,
        brick_query.c.brickname,
        bestseller_query.c.week_of_year,
        func.avg(product_query.c.mrp).label("mrp"),
        func.sum(bestseller_query.c.sold_quantity_in_a_week).label("total_qty"),
    ).join(
        bestseller_query,
        bestseller_query.c.itemid == product_query.c.itemid
    ).join(
        store_query,
        store_query.c.store_id == bestseller_query.c.store_id
    ).join(
        brick_query,
        brick_query.c.similargrouplevel == product_query.c.similargrouplevel
    ).group_by(
        product_query.c.itemid,
        product_query.c.brandname,
        product_query.c.styletype,
        product_query.c.primarycolor,
        product_query.c.pattern,
        product_query.c.fabrictype,
        product_query.c.materialtype,
        product_query.c.sleeve,
        product_query.c.fit,
        product_query.c.neckline,
        product_query.c.imgcode,
        product_query.c.extension,
        bestseller_query.c.week_of_year,
        brick_query.c.mh_family_desc,
        brick_query.c.mh_class_desc,
        brick_query.c.brickname
    ).subquery()

    query = select(
        query.c.itemid,
        query.c.brandname,
        query.c.styletype,
        query.c.primarycolor,
        query.c.pattern,
        query.c.fabrictype,
        query.c.materialtype,
        query.c.sleeve,
        query.c.fit,
        query.c.neckline,
        query.c.imgcode,
        query.c.extension,
        query.c.mh_family_desc,
        query.c.mh_class_desc,
        query.c.brickname,
        func.round(cast(func.avg(query.c.mrp), Numeric), 2).label("mrp"),
        func.sum(query.c.total_qty).label('total_qty'),
        func.round(cast(func.avg(query.c.total_qty), Numeric), 2).label('weekly_rate_of_sale'),
    ).group_by(
        query.c.itemid,
        query.c.brandname,
        query.c.styletype,
        query.c.primarycolor,
        query.c.pattern,
        query.c.fabrictype,
        query.c.materialtype,
        query.c.sleeve,
        query.c.fit,
        query.c.neckline,
        query.c.imgcode,
        query.c.extension,
        query.c.mh_family_desc,
        query.c.mh_class_desc,
        query.c.brickname
    )

    # count the total number of rows
    total_count_query = select(func.count()).select_from(query)
    bestseller_query = await sort_and_paginate(query, request_data, 'weekly_rate_of_sale')

    query_list = [bestseller_query, total_count_query]
    
    result = await psql_execute_multiple(postgres_db, query_list)

    result = {
        'total_count': result[1][0][0],
        'rows': [
            {
                'itemid': row[0],
                'brandname': row[1],
                'styletype': row[2],
                'primarycolor': row[3],
                'pattern': row[4],
                'fabrictype': row[5],
                'materialtype': row[6],
                'sleeve': row[7],
                'fit': row[8],
                'neckline': row[9],
                'imgcode': row[10],
                'extension': row[11],
                'mh_family_desc': row[12],
                'mh_class_desc': row[13],
                'brickname': row[14],
                'mrp': float(row[15]),
                'total_qty': float(row[16]),
                'weekly_rate_of_sale': float(row[17])
            }
            for row in result[0]
        ]
    }

    try:
        await redis_db.set(cache_key, json.dumps(result, default=str))
    except Exception as e:
        print("Error while writing to redis: ", e)

    return result
    

@TrendsRouter.post("/statewise-sales-trends")
async def get_statewise_sales(
    request_data: dict,
    postgres_db = Depends(psql_session)
):
    cache_key = f"statewise-sales-{json.dumps(request_data)}"
    cached_data = await check_in_redis(cache_key)
        
    if cached_data:
        return json.loads(cached_data)

    sold_in_week_query = select(
        TrendsStoreDetails.state,
        func.sum(TrendsBestSellers.sold_quantity_in_a_week).label('quantity'),   
    ).join(
        TrendsBestSellers,
        TrendsStoreDetails.store_id == TrendsBestSellers.store_id
    ).group_by(
        TrendsStoreDetails.state
    )

    maps_rows_state = (await postgres_db.execute(sold_in_week_query)).fetchall()
    map_data = [
        {
            'state': row[0],
            'statecode': indian_states.get(row[0].lower(), {}).get('statecode', 'Not Found'),
            'quantity_sold': float(row[1]),
        }
        for row in maps_rows_state
    ]

    try:
        await redis_db.set(cache_key, json.dumps(map_data, default=str))
    except Exception as e:
        print("Error while writing to redis: ", e)

    return map_data

@TrendsRouter.post("/fabric-bestsellers-trends")
async def get_fabric_bestsellers_trends(
    request_data: dict,
    postgres_db = Depends(psql_session)
):
    cache_key = f"fabric-bestsellers-trends-{json.dumps(request_data)}"
    cached_data = await check_in_redis(cache_key)
        
    if cached_data:
        return json.loads(cached_data)
    
    result = await get_attributes_bestsellers_trends(request_data, 'fabrictype', postgres_db = postgres_db)
    
    try:
        await redis_db.set(cache_key, json.dumps(result, default=str))
    except Exception as e:
        print("Error while writing to redis: ", e)

    return result

@TrendsRouter.post("/brandnames-bestsellers-trends")
async def brandnames_bestsellers_trends(
    request_data: dict,
    postgres_db = Depends(psql_session)
):
    cache_key = f"brandnames-bestsellers-trends-{json.dumps(request_data)}"
    cached_data = await check_in_redis(cache_key)
        
    if cached_data:
        return json.loads(cached_data)  
 
    result = await get_attributes_bestsellers_trends(request_data, 'brandname', postgres_db = postgres_db)
    
    try:
        await redis_db.set(cache_key, json.dumps(result, default=str))
    except Exception as e:
        print("Error while writing to redis: ", e)

    return result


@TrendsRouter.post("/neckline-bestsellers-trends")
async def neckline_bestsellers_trends(
    request_data: dict,
    postgres_db = Depends(psql_session)
):
    cache_key = f"neckline-bestsellers-trends-{json.dumps(request_data)}"
    cached_data = await check_in_redis(cache_key)
        
    if cached_data:
        return json.loads(cached_data)  
    
    result = await get_attributes_bestsellers_trends(request_data, 'neckline', postgres_db = postgres_db)
 
    try:
        await redis_db.set(cache_key, json.dumps(result, default=str))
    except Exception as e:
        print("Error while writing to redis: ", e)

    return result


@TrendsRouter.post("/styletype-bestsellers-trends")
async def styletype_bestsellers_trends(
    request_data: dict,
    postgres_db = Depends(psql_session)
):
    cache_key = f"styletype-bestsellers-trends-{json.dumps(request_data)}"
    cached_data = await check_in_redis(cache_key)
        
    if cached_data:
        return json.loads(cached_data)
    
    result = await get_attributes_bestsellers_trends(request_data, 'styletype', postgres_db = postgres_db)
 
    try:
        await redis_db.set(cache_key, json.dumps(result, default=str))
    except Exception as e:
        print("Error while writing to redis: ", e)

    return result


@TrendsRouter.post("/sleevelength-bestsellers-trends")
async def sleevelength_bestsellers_trends(
    request_data: dict,
    postgres_db = Depends(psql_session)
):
    cache_key = f"sleevelength-bestsellers-trends-{json.dumps(request_data)}"
    cached_data = await check_in_redis(cache_key)
        
    if cached_data:
        return json.loads(cached_data)
    
    result = await get_attributes_bestsellers_trends(request_data, 'sleeve', postgres_db = postgres_db)

    try:
        await redis_db.set(cache_key, json.dumps(result, default=str))
    except Exception as e:
        print("Error while writing to redis: ", e)

    return result


@TrendsRouter.post("/pattern-bestsellers-trends")
async def pattern_bestsellers_trends(
    request_data: dict,
    postgres_db = Depends(psql_session)
):
    cache_key = f"pattern-bestsellers-trends-{json.dumps(request_data)}"
    cached_data = await check_in_redis(cache_key)
        
    if cached_data:
        return json.loads(cached_data)
    
    result = await get_attributes_bestsellers_trends(request_data, 'pattern', postgres_db = postgres_db)

    try:
        await redis_db.set(cache_key, json.dumps(result, default=str))
    except Exception as e:
        print("Error while writing to redis: ", e)

    return result


@TrendsRouter.post("/color-bestsellers-trends")
async def color_bestsellers_trends(
    request_data: dict,
    postgres_db = Depends(psql_session)
):
    cache_key = f"color-bestsellers-trends-{json.dumps(request_data)}"
    cached_data = await check_in_redis(cache_key)
        
    if cached_data:
        return json.loads(cached_data)
    
    result = await get_attributes_bestsellers_trends(request_data, 'primarycolor', postgres_db = postgres_db)

    try:
        await redis_db.set(cache_key, json.dumps(result, default=str))
    except Exception as e:
        print("Error while writing to redis: ", e)

    return result
