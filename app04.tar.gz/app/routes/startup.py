from fastapi import APIRouter

StartUpRouter = APIRouter(
    prefix="/couture/fast-fashion",
    tags=["Startup"],
    responses={404: {"description": "Not found"}},
)

@StartUpRouter.get("/_healthz")
async def healthz():
    return {'success': True}

@StartUpRouter.get("/_readyz")
async def readyz():
    return {'success': True}
