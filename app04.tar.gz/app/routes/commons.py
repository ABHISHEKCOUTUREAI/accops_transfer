from fastapi import Request
from sqlalchemy import select, and_
from settings import Settings
from collections import defaultdict
from db import psql_execute_single
from models import request_column_model_map
from utils import month_mapping, reverse_month_mapping, filter_flag_model_map

async def select_filter_subquery(
        model,
        filters: list = [],
        columns: list = []
):
    query = select(
        *[
            getattr(model, column) for column in columns
        ]
    ).where(
        and_(
            *filters,
            *[
                getattr(model, column) != None for column in columns
            ]
        )
    ).subquery()

    return query

def get_settings(request: Request) -> Settings:
    return request.app.state.settings

async def build_filter_condition(
        filter_flag: str = '',
        initial: bool = False,
        initial_filters_body: dict = defaultdict(dict),
        request_filters: dict = defaultdict(dict),
        type: str = 'ajio'
) -> dict | list:
    request_filters = request_filters.get('nested_data', {})
    response_filters = {
        'bestsellers' : [],
        'demographic' : [],
        'brick' : [],
        'store_filters' : [],
        'category' : [],
        'products' : [],
    }
    for structure_key, structure_value in request_filters.items():
        for key, values in structure_value.items():
            if initial:
                initial_filters_body[structure_key][key] = []
                distinct_result = await psql_execute_single(
                    select(
                        getattr(request_column_model_map[key]['model'][type], request_column_model_map[key]['column'])
                    ).distinct()
                )
                if key == 'month':
                    for month in distinct_result:
                        initial_filters_body[structure_key][key].append(month_mapping[month[0]])
                else:
                    for value in distinct_result:
                        initial_filters_body[structure_key][key].append(str(value[0]))
                return initial_filters_body
            if key == 'month':
                if values and hasattr(filter_flag_model_map[filter_flag][type], request_column_model_map[key]['column']):
                    month_values = [reverse_month_mapping[val] for val in values]
                    response_filters[filter_flag].append(getattr(filter_flag_model_map[filter_flag][type], request_column_model_map[key]['column']).in_(month_values))
            elif key == 'quarter':
                if values and hasattr(filter_flag_model_map[filter_flag][type], request_column_model_map[key]['column']):
                    response_filters[filter_flag].append(getattr(filter_flag_model_map[filter_flag][type], request_column_model_map[key]['column']).in_(list(map(int, values))))
            else:
                if values and hasattr(filter_flag_model_map[filter_flag][type], request_column_model_map[key]['column']):
                    response_filters[filter_flag].append(getattr(filter_flag_model_map[filter_flag][type], request_column_model_map[key]['column']).in_(values))
            
            if values and hasattr(filter_flag_model_map[filter_flag][type], request_column_model_map[key]['column']):
                response_filters[filter_flag].append(getattr(request_column_model_map[key]['model'][type], request_column_model_map[key]['column']).isnot(None))
    
    return response_filters[filter_flag]
