from fastapi import APIRouter, Form, Depends
from asyncio import gather
import pandas as pd
from models import AjioBestSellers, AjioBrickDetails, AjioDemographicDetails, AjioProductAttributes, AjioSearchQueriesTopInteractedProducts, TrendsBestSellers, TrendsBrickDetails, TrendsProductAttributes, TrendsStoreDetails, SearchInteractions
from utils import insert_into_db, load_google_search_interactions
from db import set_redis_state, flush_redis_key, psql_session, postgres_engine

DBRouter = APIRouter(
    prefix="/couture/fast-fashion",
    tags=["DB Utils"],
    responses={404: {"description": "Not found"}},
)

@DBRouter.get("/update-db")
async def update_db(
    table_name: str = Form(...),
    postgres_db = Depends(psql_session),
):
    if table_name == "ajio_bestsellers":
        await insert_into_db(AjioBestSellers, "ajio_bestsellers.csv", postgres_db)
        return {"message": "Ajio Bestsellers loaded successfully"}
    elif table_name == "ajio_brick_details":
        await insert_into_db(AjioBrickDetails, "ajio_brick_details.csv", postgres_db)
        return {"message": "Ajio Brick Details loaded successfully"}
    elif table_name == "ajio_demographic_details":
        await insert_into_db(AjioDemographicDetails, "ajio_demographic_details.csv", postgres_db)
        return {"message": "Ajio Demographic Details loaded successfully"}
    elif table_name == "ajio_product_attributes":
        await insert_into_db(AjioProductAttributes, "ajio_product_attributes.csv", postgres_db)
        return {"message": "Ajio Product Attributes loaded successfully"}
    elif table_name == "ajio_search_queries_top_interacted_products":
        await insert_into_db(AjioSearchQueriesTopInteractedProducts, "ajio_search_queries_top_interacted_products.csv", postgres_db)
        return {"message": "Ajio Search Queries Top Interacted Products loaded successfully"}
    elif table_name == "trends_bestsellers":
        await insert_into_db(TrendsBestSellers, "trends_bestsellers.csv", postgres_db)
        return {"message": "Trends Bestsellers loaded successfully"}
    elif table_name == "trends_brick_details":
        await insert_into_db(TrendsBrickDetails, "trendsbrickdetails.csv", postgres_db)
        return {"message": "Trends Brick Details loaded successfully"}
    elif table_name == "trends_product_attributes":
        await insert_into_db(TrendsProductAttributes, "trends_product_attributes.csv", postgres_db)
        return {"message": "Trends Product Attributes loaded successfully"}
    elif table_name == "trends_store_details":
        await insert_into_db(TrendsStoreDetails, "trendsstoredetails.csv", postgres_db)
        return {"message": "Trends Store Details loaded successfully"}
    elif table_name == "search_interactions":
        await load_google_search_interactions(postgres_db)
        return {"message": "Google Search Interactions loaded successfully"}
    elif table_name == "all":
        await gather(
            insert_into_db(AjioBestSellers, "ajio_bestsellers.csv", postgres_db),
            insert_into_db(AjioBrickDetails, "ajio_brick_details.csv", postgres_db),
            insert_into_db(AjioDemographicDetails, "ajio_demographic_details.csv", postgres_db),
            insert_into_db(AjioProductAttributes, "ajio_product_attributes.csv", postgres_db),
            insert_into_db(AjioSearchQueriesTopInteractedProducts, "ajio_search_queries_top_interacted_products.csv", postgres_db),
            insert_into_db(TrendsBestSellers, "trends_bestsellers.csv", postgres_db),
            insert_into_db(TrendsBrickDetails, "trendsbrickdetails.csv", postgres_db),
            insert_into_db(TrendsProductAttributes, "trends_product_attributes.csv", postgres_db),
            insert_into_db(TrendsStoreDetails, "trendsstoredetails.csv", postgres_db),
            load_google_search_interactions(SearchInteractions, postgres_db),
        )
        return {"message": "All tables loaded successfully"}
    else:
        return {"message": "Invalid table name"}
    
@DBRouter.get("/flush-redis")
async def flush_redis(key_prefix: str):
    if key_prefix == "all":
        await set_redis_state(flush_db=True)
        return {"message": "Redis flushed successfully"}
    else:
        await flush_redis_key(key_prefix)
        return {"message": f"Redis keys starting with {key_prefix} flushed successfully"}

@DBRouter.post("/gcs-to-postgres")
async def gcs_to_postgres(
        gcs_bucket_name: str = Form(...),
        gcs_file_name: str = Form(...),
        postgres_username: str = Form(...),
        postgres_password: str = Form(...),
        postgres_host: str = Form(...),
        postgres_port: str = Form(...),
        postgres_database: str = Form(...),
        postgres_table_name: str = Form(...)
):
    try:
        engine = postgres_engine(f'postgresql://{postgres_username}:{postgres_password}@{postgres_host}:{postgres_port}/{postgres_database}')
        df = pd.read_csv(f'gs://{gcs_bucket_name}/{gcs_file_name}')
        df.to_sql(postgres_table_name, con=engine, if_exists='append', index=False, chunksize=1000)
        return 'Data written to postgres successfully'
    except Exception as e:
        raise e
