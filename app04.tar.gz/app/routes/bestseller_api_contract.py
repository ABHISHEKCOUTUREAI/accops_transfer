from fastapi import APIRouter
from fastapi.responses import JSONResponse
from static import filters_response
import math

BestSellerAPIContractRouter = APIRouter(
    prefix="/coutureapi/fast-fashion/bestsellers",
    tags=["best_sellers"],
    responses={404: {"description": "Not found"}},
)

async def get_response(sample, page_size):
    response = []
    response_length = math.ceil(len(sample)/page_size)

    for i in range (0, response_length):
        for j in sample:
            response.append(j)
    
    return response[:page_size]

@BestSellerAPIContractRouter.post('/filters')
async def get_filters(
    month: list[str] = None,
    quarter: list[str] = None,
    zone: list[str] = None,
    state: list[str] = None,
    city: list[str] = None,
    district: list[str] = None,
    styletype: list[str] = None,
    neckline: list[str] = None,
    pattern: list[str] = None,
    fabric_type: list[str] = None,
    sleeve: list[str] = None,
    fit: list[str] = None,
    color: list[str] = None,
    brand: list[str] = None,
    occasion: list[str] = None,
    bodytype: list[str] = None,
    materialtype: list[str] = None,
    distress: list[str] = None,
    traditionalweave: list[str] = None,
    hemline: list[str] = None,
    l1_name: list[str] = None,
    l2_name: list[str] = None,
    brick_name: list[str] = None
):

    return JSONResponse(content=filters_response)

@BestSellerAPIContractRouter.get("/products")
async def get_best_sellers(
    store_class: str = 'ajio',
    gender:  str = None,
    category: str = None, 
    brandname: str =  None, 
    fashion_grade: str = None, 
    zone: str = None,
    state: str = None,
    city: str = None,
    pincode: str = None,
    min_mrp: int = None,
    max_mrp: int = None,
    attribute_key: str = None,
    attribute_value: str = None,
    sort_attribute: str =  'weekly_rate_of_sale',
    sort_order: str = 'desc',
    page: int =  1,
    page_size: int = 20
):
   
    sample = [
        {
            "item_id": 1,
            "title": "Wide Joggers",
            "brand_name": "gap",
            "mrp": 499.99,
            "ajio_weekly_ros": "75%",
            "trends_weekly_ros": "75%",
            "image_url": "https://placehold.co/400"
        },
        {
            "item_id": 2,
            "title": "Wide Joggers",
            "brand_name": "gap",
            "mrp": 499.99,
            "ajio_weekly_ros": "75%",
            "trends_weekly_ros": "75%",
            "image_url": "https://placehold.co/400"
        }
    ]

    return JSONResponse(content=await get_response(sample, page_size))

@BestSellerAPIContractRouter.get("/categories")
async def get_categories(
    gender: str = 'Men',
    page: int = 1,
    page_size: int = 20
):
    
    sample = [
        {
            "id": 1,
            "category": "Topwear",
            "gender": "male",
            "image_url": "https://image_url"
        },
        {
            "id": 2,
            "category": "Dress",
            "gender": "female",
            "image_url": "https://image_url"
        }
    ]

    return JSONResponse(content=await get_response(sample, page_size))

@BestSellerAPIContractRouter.get('/attributes')
async def get_filters(
    page: int = 1,
    page_size: int = 20,
    category: str = 'Topwear',
    attribute_key: str = 'fabric',
    week: str = '2'
):
    
    sample =  [
        {
            "attribute": "FABRIC",
            "values": [
                {
                    "name": "100% Cotton",
                    "current_sales": 100,
                    "previous_sales": 80,
                    "precentage_change": 20,
                    "image_url": "https://image_url"
                },
                {
                    "name": "Cotton Blend",
                    "current_sales": 100,
                    "previous_sales": 80,
                    "precentage_change": 20,
                    "image_url": "https://image_url"
                }
            ]
        }
    ]

    return JSONResponse(content=await get_response(sample, page_size))

@BestSellerAPIContractRouter.get('/most-searched-trends')
async def get_most_searched_trends(
    page: int = 1,
    page_size: int = 20,
    num_days: int = 7,
    category: str = 'jeans',
    city: str = 'Bangalore',
    state: str = 'Karnataka',
    zone: str = 'South'
):
    
    sample = [
        {
            "name": "Silver Maxi Dress",
            "last_searched_timestamp": 2,  # hours
            "search_distribution": {
                "divisions": 12,
                "data": [12, 23, 23, 23, 45, 45, 44, 34, 2, 445, 34, 34]
            },
            "total_searches": 2000
        },
        {
            "name": "Black Mini Dress",
            "last_searched_timestamp": 2,
            "search_distribution": {
                "divisions": 12,
                "data": [12, 23, 23, 23, 45, 45, 44, 34, 2, 445, 34, 34]
            },
            "total_searches": 2000
        }
    ]

    return JSONResponse(content=await get_response(sample, page_size))

@BestSellerAPIContractRouter.get('/most-searched-attributes')  
async def get_most_searched_attributes(
    page: int = 1,
    page_size: int = 20,
    num_days: int = 7,
    category: str = 'jeans',
    city: str = 'Bangalore',
    state: str = 'Karnataka',
    zone: str = 'South'
):
    
    sample = [
        {
            "attribute": "COLOR",
            "distribution": [
                { "name": "Pistachio", "percentage": 10 },
                { "name": "Powder blue", "percentage": 20 }
            ]
        },
        {
            "attribute": "PATTERN",
            "distribution": [
                { "name": "Draping", "percentage": 10 },
                { "name": "Workwear", "percentage": 20 }
            ]
        }
    ]

    return JSONResponse(content=await get_response(sample, page_size))
