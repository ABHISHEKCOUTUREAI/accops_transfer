from fastapi import APIRouter, Depends
import json
import asyncio
from collections import defaultdict
from sqlalchemy import select, func, and_, cast, Numeric
from models import AjioBestSellers, AjioProductAttributes, AjioDemographicDetails, AjioBrickDetails
from utils import  indian_states, sort_response_using_cache
from db import redis_db, psql_session, psql_execute_multiple, check_in_redis
from .commons import select_filter_subquery, build_filter_condition
from utils import month_mapping, reverse_month_mapping, create_filter_query, sort_and_paginate

AjioRouter = APIRouter(
    prefix="/couture/fast-fashion",
    tags=["Ajio"],
    responses={404: {"description": "Not found"}},
)

async def get_attributes_bestsellers_ajio(
    request_data,
    attribute: str,
    postgres_db
):
    
    product_filter, brick_filter, demographic_filter, bestseller_filter = await asyncio.gather(
        build_filter_condition(request_filters=request_data, filter_flag='products'),
        build_filter_condition(request_filters=request_data, filter_flag='brick'),
        build_filter_condition(request_filters=request_data, filter_flag='demographic'),
        build_filter_condition(request_filters=request_data, filter_flag='bestsellers')
    )

    product_query = select(
        getattr(AjioProductAttributes, attribute),
        AjioProductAttributes.productid,
        AjioProductAttributes.similargrouplevel
    ).where(and_(*product_filter, getattr(AjioProductAttributes, attribute).isnot(None))).subquery()

    brick_query = select(
        AjioBrickDetails.brickname,
        AjioBrickDetails.similargrouplevel
    ).where(and_(*brick_filter)).subquery()

    sold_in_week_query = select(
        AjioBestSellers.sold_quantity_in_a_week,
        AjioBestSellers.productid,
        AjioBestSellers.pincode,
    ).where(and_(*bestseller_filter)).subquery()

    demographic_query = select(
        AjioDemographicDetails.pincode,
    ).where(and_(*demographic_filter)).subquery()
    
    query = select(
        getattr(product_query.c, attribute),
        brick_query.c.brickname,
        func.sum(sold_in_week_query.c.sold_quantity_in_a_week).label("quantity"),
    ).join(
        brick_query,
        product_query.c.similargrouplevel == brick_query.c.similargrouplevel
    ).join(
        sold_in_week_query,
        product_query.c.productid == sold_in_week_query.c.productid
    ).join(
        demographic_query,
        demographic_query.c.pincode == sold_in_week_query.c.pincode
    ).group_by(
            getattr(product_query.c, attribute),
            brick_query.c.brickname,
    ).order_by(
            func.sum(sold_in_week_query.c.sold_quantity_in_a_week).desc()
    )
    
    rows = (await postgres_db.execute(query)).fetchall()

    result = defaultdict(dict)
    for row in rows:
        if row[0]:
            result[row[1]][row[0]] = float(row[2])

    return result

@AjioRouter.post("/ajio-filters-structure")
async def get_filters_structure(
    request_data: dict
):
    cache_key = f"ajio-filters-structure-{json.dumps(request_data)}"
    cached_data = await check_in_redis(cache_key)
    if cached_data:
        return json.loads(cached_data)
    
    response_data = defaultdict(dict)
    response_data['demographic'] = {
        "zone": [],
        "state": [],
        "city": [],
        "district": [],
    }
    response_data['brick_filters'] = {
        "l1_name": [],
        "l2_name": [],
        "brick_name": [],
    }
    response_data['attributes'] = {
        "styletype": [],
        "neckline": [],
        "pattern": [],
        "fabric_type": [],
        "sleeve": [],
        "fit": [],
        "color": [],
        "brand": [],
        "occasion": [],
        "bodytype": [],
        "materialtype": [],
        "distress": [],
        "traditionalweave": [],
        "hemline": []
    } 
    response_data['duration'] = {
        "month": [],
        "quarter": [],
    }
    
    return await build_filter_condition(
        request_filters = request_data,
        initial = True,
        initial_filters_body = response_data
    )


async def create_ajio_filters_query(request_data):

    duration_filter, demography_filter, brick_filter, product_filter = await asyncio.gather(
        build_filter_condition(request_filters = request_data, filter_flag='bestsellers'),
        build_filter_condition(request_filters = request_data, filter_flag='demographic'),
        build_filter_condition(request_filters = request_data, filter_flag='brick'),
        build_filter_condition(request_filters = request_data, filter_flag='products')
    )

    duration_columns = ['month_of_year', 'quarter_of_year', 'pincode', 'pincode', 'productid']
    demography_columns = ['zone', 'state', 'city', 'districtsname','pincode']
    brick_columns = ['l1name', 'l2name', 'brickname', 'similargrouplevel']
    product_columns = ["productid", "styletype", "neckline", "pattern", "fabrictype", "sleevelength", "fit", "colorfamily", "brandname", "occasion", "bodytype", "materialtype", "distress", "traditionalweave", "hemline", "similargrouplevel"]

    duration_query, demographic_query, brick_query, product_query = await asyncio.gather(
        select_filter_subquery(AjioBestSellers, list(duration_filter), duration_columns),
        select_filter_subquery(AjioDemographicDetails, list(demography_filter), demography_columns),
        select_filter_subquery(AjioBrickDetails, list(brick_filter), brick_columns),
        select_filter_subquery(AjioProductAttributes, list(product_filter), product_columns)
    )
    
    # join all 4 queries to get the final result
    query = select(
        duration_query.c.month_of_year,
        duration_query.c.quarter_of_year,
        demographic_query.c.zone,
        demographic_query.c.state,
        demographic_query.c.city,
        demographic_query.c.districtsname,
        brick_query.c.l1name,
        brick_query.c.l2name,
        brick_query.c.brickname,
        product_query.c.styletype,
        product_query.c.neckline,
        product_query.c.pattern,
        product_query.c.fabrictype,
        product_query.c.sleevelength,
        product_query.c.fit,
        product_query.c.colorfamily,
        product_query.c.brandname,
        product_query.c.occasion,
        product_query.c.bodytype,
        product_query.c.materialtype,
        product_query.c.distress,
        product_query.c.traditionalweave,
        product_query.c.hemline,
    ).join(
        demographic_query,
        demographic_query.c.pincode == duration_query.c.pincode
    ).join(
        product_query,
        product_query.c.productid == duration_query.c.productid
    ).join(
        brick_query,
        brick_query.c.similargrouplevel == product_query.c.similargrouplevel
    )

    return query


@AjioRouter.post("/ajio-filters-cache")
async def get_ajio_cached_filters(
    request_data: dict,
    postgres_db = Depends(psql_session)
):

    cache_key = "ajio_filters_cache"
    cached_data = await check_in_redis(cache_key)
    if cached_data:
        return json.loads(cached_data)
    
    query = await create_ajio_filters_query(request_data)

    # crate a list and push all queries there 
    query_list = await asyncio.gather(
        create_filter_query(query, parameter = 'zone'),
        create_filter_query(query, parameter = 'state'),
        create_filter_query(query, parameter = 'city'),
        create_filter_query(query, parameter = 'districtsname'),
        create_filter_query(query, parameter = 'l1name'),
        create_filter_query(query, parameter = 'l2name'),
        create_filter_query(query, parameter = 'brickname'),
        create_filter_query(query, parameter = 'styletype'),
        create_filter_query(query, parameter = 'neckline'),
        create_filter_query(query, parameter = 'pattern'),
        create_filter_query(query, parameter = 'fabrictype'),
        create_filter_query(query, parameter = 'sleevelength'),
        create_filter_query(query, parameter = 'fit'),
        create_filter_query(query, parameter = 'colorfamily'),
        create_filter_query(query, parameter = 'brandname'),
        create_filter_query(query, parameter = 'occasion'),
        create_filter_query(query, parameter = 'bodytype'),
        create_filter_query(query, parameter = 'materialtype'),
        create_filter_query(query, parameter = 'distress'),
        create_filter_query(query, parameter = 'traditionalweave'),
        create_filter_query(query, parameter = 'hemline'),
        create_filter_query(query, parameter = 'month_of_year'),
        create_filter_query(query, parameter = 'quarter_of_year')
    )

    result = await psql_execute_multiple(postgres_db, query_list)

    response_data = defaultdict(dict)
    response_data['demographic'] = {
        "zone": [val[0]for val in result[0] if val[0] != 'nan'],
        "state": [val[0]for val in result[1] if val[0] != 'nan'],
        "city": [val[0]for val in result[2] if val[0] != 'nan'],
        "district": [val[0]for val in result[3] if val[0] != 'nan'],
    }
    response_data['brick_filters'] = {
        "l1_name": [val[0]for val in result[4] if val[0] != 'nan'],
        "l2_name": [val[0]for val in result[5] if val[0] != 'nan'],
        "brick_name": [val[0]for val in result[6] if val[0] != 'nan'],
    }
    response_data['attributes'] = {
        "styletype": [val[0]for val in result[7] if val[0] != 'nan'],
        "neckline": [val[0]for val in result[8] if val[0] != 'nan'],
        "pattern": [val[0]for val in result[9] if val[0] != 'nan'],
        "fabric_type": [val[0]for val in result[10] if val[0] != 'nan'],
        "sleeve": [val[0]for val in result[11] if val[0] != 'nan'],
        "fit": [val[0]for val in result[12] if val[0] != 'nan'],
        "color": [val[0]for val in result[13] if val[0] != 'nan'],
        "brand": [val[0]for val in result[14] if val[0] != 'nan'],
        "occasion": [val[0]for val in result[15] if val[0] != 'nan'],
        "bodytype": [val[0]for val in result[16] if val[0] != 'nan'],
        "materialtype": [val[0]for val in result[17] if val[0] != 'nan'],
        "distress": [val[0]for val in result[18] if val[0] != 'nan'],
        "traditionalweave": [val[0]for val in result[19] if val[0] != 'nan'],
        "hemline": [val[0]for val in result[20] if val[0] != 'nan'],
    }
    response_data['duration'] = {
        "month": [month_mapping[val[0]] for val in result[21] if val[0] != 'nan'],
        "quarter": [str(val[0]) for val in result[22] if val[0] != 'nan'],
    }

    try:
        await redis_db.set(cache_key, json.dumps(response_data, default=str))
    except Exception as e:
        print("Error while writing to redis: ", e)

    return response_data


@AjioRouter.post("/ajio-filters")
async def get_ajio_filters(
    request_data: dict,
    postgres_db = Depends(psql_session)
):
    cache_key = f"ajio_filters{json.dumps(request_data)}"
    cached_data = await check_in_redis(cache_key)
        
    if cached_data:
        return json.loads(cached_data)
    
    query = await create_ajio_filters_query(request_data)

    result = (await postgres_db.execute(query)).fetchall()
    
    response = {
        'demographic': {
            'zone': list(set([val[2] for val in result if val[2] != 'nan'])), 
            'state': list(set([val[3] for val in result if val[3] != 'nan'])),
            'city': list(set([val[4] for val in result if val[4] != 'nan'])),
            'district': list(set([val[5] for val in result if val[5] != 'nan'])),
        },
        'brick_filters': {
            'l1_name': list(set([val[6] for val in result if val[6] != 'nan'])),
            'l2_name': list(set([val[7] for val in result if val[7] != 'nan'])),
            'brick_name': list(set([val[8] for val in result if val[8] != 'nan'])),
        },
        'attributes': {
            'styletype': list(set([val[9] for val in result if val[9] != 'nan'])),
            'neckline': list(set([val[10] for val in result if val[10] != 'nan'])),
            'pattern': list(set([val[11] for val in result if val[11] != 'nan'])),
            'fabric_type': list(set([val[12] for val in result if val[12] != 'nan'])),
            'sleeve': list(set([val[13] for val in result if val[13] != 'nan'])),
            'fit': list(set([val[14] for val in result if val[14] != 'nan'])),
            'color': list(set([val[15] for val in result if val[15] != 'nan'])),
            'brand': list(set([val[16] for val in result if val[16] != 'nan'])),
            'occasion': list(set([val[17] for val in result if val[17] != 'nan'])),
            'bodytype': list(set([val[18] for val in result if val[18] != 'nan'])),
            'materialtype': list(set([val[19] for val in result if val[19] != 'nan'])),
            'distress': list(set([val[20] for val in result if val[20] != 'nan'])),
            'traditionalweave': list(set([val[21] for val in result if val[21] != 'nan'])),
            'hemline': list(set([val[22] for val in result if val[22] != 'nan'])),
        },
        'duration': {
            'month': list(set([month_mapping[val[0]] for val in result if val[0] != 'nan'])),
            'quarter': list(set([str(val[1]) for val in result if val[1] != 'nan'])),
        }
    }

    cache_response = await check_in_redis("ajio_filters_cache")
    if cache_response:
        cache_response = json.loads(cache_response)
    else:
        cache_response = defaultdict(dict)

    # Sort the response using the cache_response
    response = await sort_response_using_cache(response, cache_response)

    try:
        await redis_db.set(cache_key, json.dumps(response, default=str))
    except Exception as e:
        print("Error while writing to redis: ", e)

    return response


@AjioRouter.post("/bestsellers-products-ajio")
async def bestseller_ajio(
    request_data: dict,
    postgres_db = Depends(psql_session)
):

    cache_key = f"sale_trends_ajio_{json.dumps(request_data)}"
    cached_data = await check_in_redis(cache_key)
    if cached_data:
        return json.loads(cached_data)

    bestseller_filter, demographic_filter, product_filter, brick_filter = await asyncio.gather(
        build_filter_condition(request_filters=request_data, filter_flag='bestsellers'),
        build_filter_condition(request_filters=request_data, filter_flag='demographic'),
        build_filter_condition(request_filters=request_data, filter_flag='products'),
        build_filter_condition(request_filters=request_data, filter_flag='brick')
    )

    bestseller_query = select(
        AjioBestSellers.productid,
        AjioBestSellers.week_of_year,
        AjioBestSellers.mrp,
        AjioBestSellers.sold_quantity_in_a_week,
        AjioBestSellers.pincode,
    ).where(
        and_(*bestseller_filter)
    ).subquery()
    
    demographic_query = select(
        AjioDemographicDetails.pincode,
    ).where(
        and_(*demographic_filter)
    ).subquery()
  
    ros_query = select(
        bestseller_query.c.productid,
        bestseller_query.c.week_of_year,
        func.avg(bestseller_query.c.mrp).label("mrp"),
        func.sum(bestseller_query.c.sold_quantity_in_a_week).label("qty_sold"),
    ).join(
        demographic_query,
        demographic_query.c.pincode == bestseller_query.c.pincode
    ).group_by(
        bestseller_query.c.productid,
        bestseller_query.c.week_of_year,
    ).subquery()

    ros_query = select(
        ros_query.c.productid,
        func.sum(ros_query.c.qty_sold).label("total_qty_sold"),
        func.round(cast(func.avg(ros_query.c.mrp), Numeric), 2).label("mrp"),
        func.round(func.avg(ros_query.c.qty_sold), 2).label("weekly_rate_of_sale"),
    ).group_by(
        ros_query.c.productid,
    ).subquery()

    product_query = select(
        AjioProductAttributes.productid,
        AjioProductAttributes.similargrouplevel,
        AjioProductAttributes.title,
        AjioProductAttributes.brandname,
        AjioProductAttributes.imgcode,
        AjioProductAttributes.styletype,
        AjioProductAttributes.colorfamily,
        AjioProductAttributes.pattern,
        AjioProductAttributes.neckline,
    ).where(
        and_(*product_filter)
    ).subquery()

    brick_query = select(
        AjioBrickDetails.similargrouplevel,
        AjioBrickDetails.l1name,
        AjioBrickDetails.l2name,
        AjioBrickDetails.brickname,
    ).where(
        and_(*brick_filter)
    ).subquery()
    
    query = select(
        product_query.c.productid,
        product_query.c.title,
        product_query.c.brandname,
        product_query.c.imgcode,
        product_query.c.styletype,
        product_query.c.colorfamily,
        product_query.c.pattern,
        product_query.c.neckline,
        brick_query.c.l1name,
        brick_query.c.l2name,
        brick_query.c.brickname,
        ros_query.c.total_qty_sold,
        ros_query.c.mrp,
        ros_query.c.weekly_rate_of_sale,
    ).join(
        ros_query,
        ros_query.c.productid == product_query.c.productid
    ).join(
        brick_query,
        brick_query.c.similargrouplevel == product_query.c.similargrouplevel
    )

    # count the total number of rows
    total_count_query = select(func.count()).select_from(ros_query)
    query = await sort_and_paginate(query, request_data, default_sort_param='weekly_rate_of_sale')

    query_list = [query, total_count_query]
    
    result = await psql_execute_multiple(postgres_db, query_list)

    result = {
        'total_count': result[1][0][0], 
        "rows": [
            {
                "productid": row[0],
                "title": row[1],
                "brandname": row[2],
                "imgcode": row[3],
                "styletype": row[4],
                "colorfamily": row[5],
                "pattern": row[6],
                "neckline": row[7],
                "l1name": row[8],
                "l2name": row[9],
                "brickname": row[10],
                "total_qty_sold": row[11],
                "mrp": row[12],
                "weekly_rate_of_sale": row[13],
            }
            for row in result[0]
        ]
    }

    try:
        await redis_db.set(cache_key, json.dumps(result, default=str))
    except Exception as e:
        print("Error while writing to redis: ", e)


    return result

@AjioRouter.post("/statewise-sales-ajio")
async def get_statewise_sales(
    request_data: dict,
    postgres_db = Depends(psql_session)
):

    cache_key = f"statewise_sales_{json.dumps(request_data)}"
    try:
        cached_data = await redis_db.get(cache_key)
    except Exception as e:
        print("Not connected to redis: ", e)
        cached_data = None
    if cached_data:
        return json.loads(cached_data)
    
    sold_in_week_query = select(
        AjioDemographicDetails.state,
        func.sum(AjioBestSellers.sold_quantity_in_a_week).label('quantity'),
    ).join(
        AjioDemographicDetails,
        AjioDemographicDetails.pincode == AjioBestSellers.pincode
    ).group_by(
        AjioDemographicDetails.state,
    )

    maps_rows_state = (await postgres_db.execute(sold_in_week_query)).fetchall()

    map_data = [
        {
            'state': row[0],
            'statecode': indian_states.get(row[0].lower(), {}).get('statecode', 'Not Found'),
            'quantity_sold': row[1],
        }
        for row in maps_rows_state
    ]

    try:
        await redis_db.set(cache_key, json.dumps(map_data, default=str))
    except Exception as e:
        print("Error while writing to redis: ", e)
    
    return map_data

@AjioRouter.post("/fabric-bestsellers-ajio")
async def get_fabric_bestsellers_ajio(
    request_data: dict,
    postgres_db = Depends(psql_session)
):
    cache_key = f"fabric_bestsellers_ajio_{json.dumps(request_data)}"
    try:
        cached_data = await redis_db.get(cache_key)
    except Exception as e:
        print("Not connected to redis: ", e)
        cached_data = None

    if cached_data:
        return json.loads(cached_data)

    result = await get_attributes_bestsellers_ajio(request_data,  attribute = 'fabrictype', postgres_db = postgres_db)

    try:
        await redis_db.set(cache_key, json.dumps(result, default=str))
    except Exception as e:
        print("Error while writing to redis: ", e)

    return result

@AjioRouter.post("/brandnames-bestsellers-ajio")
async def brandnames_bestsellers_ajio(
    request_data: dict,
    postgres_db = Depends(psql_session)
):
    cache_key = f"brandnames_bestsellers_ajio_{json.dumps(request_data)}"
    try:
        cached_data = await redis_db.get(cache_key)
    except Exception as e:
        print("Not connected to redis: ", e)
        cached_data = None

    if cached_data:
        return json.loads(cached_data)

    result = await get_attributes_bestsellers_ajio(request_data, attribute = 'brandname', postgres_db = postgres_db)

    try:
        await redis_db.set(cache_key, json.dumps(result, default=str))
    except Exception as e:
        print("Error while writing to redis: ", e)

    return result

@AjioRouter.post("/styletype-bestsellers-ajio")
async def styletype_bestsellers_ajio(
    request_data: dict,
    postgres_db = Depends(psql_session)
):
    
    cache_key = f"styletype_bestsellers_ajio_{json.dumps(request_data)}"
    try:
        cached_data = await redis_db.get(cache_key)
    except Exception as e:
        print("Not connected to redis: ", e)
        cached_data = None

    if cached_data:
        return json.loads(cached_data)

    result = await get_attributes_bestsellers_ajio(request_data,  attribute = 'styletype', postgres_db = postgres_db)
 
    try:
        await redis_db.set(cache_key, json.dumps(result, default=str))
    except Exception as e:
        print("Error while writing to redis: ", e)

    return result

@AjioRouter.post("/neckline-bestsellers-ajio")
async def neckline_bestsellers_ajio(
    request_data: dict,
    postgres_db = Depends(psql_session)
):
    
    cache_key = f"neckline_bestsellers_ajio_{json.dumps(request_data)}"
    try:
        cached_data = await redis_db.get(cache_key)
    except Exception as e:
        print("Not connected to redis: ", e)
        cached_data = None

    if cached_data:
        return json.loads(cached_data)

    result = await get_attributes_bestsellers_ajio(request_data, attribute = 'neckline', postgres_db = postgres_db)

    try:
        await redis_db.set(cache_key, json.dumps(result, default=str))
    except Exception as e:
        print("Error while writing to redis: ", e)

    return result

@AjioRouter.post("/pattern-bestsellers-ajio")
async def pattern_bestsellers_ajio(
    request_data: dict,
    postgres_db = Depends(psql_session)
):

    cache_key = f"pattern_bestsellers_ajio_{json.dumps(request_data)}"
    try:
        cached_data = await redis_db.get(cache_key)
    except Exception as e:
        print("Not connected to redis: ", e)
        cached_data = None

    if cached_data:
        return json.loads(cached_data)
 
    result = await get_attributes_bestsellers_ajio(request_data, attribute = 'pattern', postgres_db = postgres_db)

    try:
        await redis_db.set(cache_key, json.dumps(result, default=str))
    except Exception as e:
        print("Error while writing to redis: ", e)
    return result

@AjioRouter.post("/color-bestsellers-ajio")
async def color_bestsellers_ajio(
    request_data: dict,
    postgres_db = Depends(psql_session)
):
    cache_key = f"color_bestsellers_ajio_{json.dumps(request_data)}"
    try:
        cached_data = await redis_db.get(cache_key)
    except Exception as e:
        print("Not connected to redis: ", e)
        cached_data = None

    if cached_data:
        return json.loads(cached_data)
    
    result = await get_attributes_bestsellers_ajio(request_data, attribute = 'colorfamily', postgres_db = postgres_db)

    try:
        await redis_db.set(cache_key, json.dumps(result, default=str))
    except Exception as e:
        print("Error while writing to redis: ", e)

    return result

@AjioRouter.post("/sleevelength-bestsellers-ajio")
async def sleevelength_bestsellers_ajio(
    request_data: dict,
    postgres_db = Depends(psql_session)
):
    cache_key = f"sleevelength_bestsellers_ajio_{json.dumps(request_data)}"
    try:
        cached_data = await redis_db.get(cache_key)
    except Exception as e:
        print("Not connected to redis: ", e)
        cached_data = None

    if cached_data:
        return json.loads(cached_data)

    result = await get_attributes_bestsellers_ajio(request_data, attribute = 'sleevelength', postgres_db = postgres_db)

    try:
        await redis_db.set(cache_key, json.dumps(result, default=str))
    except Exception as e:
        print("Error while writing to redis: ", e)

    return result
