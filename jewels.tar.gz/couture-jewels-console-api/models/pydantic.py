from pydantic import BaseModel
from typing import Optional

class SimilarProductsRequest(BaseModel):
    itemid: str
class FilterRequest(BaseModel):
    metal_and_stone: Optional[str] = None
    gross_weight: Optional[str] = None
    category: Optional[str] = None
    sub_category: Optional[str] = None
    search_col: str = None

