from sqlalchemy import Column, Integer, String, Float
from sqlalchemy.ext.declarative import declarative_base

# Define the base class for declarative models
Base = declarative_base()

# Define the model for the table
class ImageSimilarity(Base):
    __tablename__ = 'image_similarity'

    id = Column(Integer, primary_key=True, autoincrement=True)
    itemid = Column(String)
    itemid_category_name = Column(String)
    rank = Column(Integer)
    similar_items = Column(String)
    similar_item_category_name = Column(String)
    metal_and_stone = Column(String)


class VisualSearch(Base):
    __tablename__ = 'VisualSearch'

    id = Column(Integer, primary_key=True, autoincrement=True)
    rrl_code = Column(String)
    base_code = Column(String)
    category_code = Column(String)
    category = Column(String)
    sub_category = Column(String)
    buying_complexity = Column(String)
    diamond_clarity = Column(String)
    diamond_color = Column(String)
    diamond_pcs = Column(Integer)
    diamond_shape = Column(String)
    diamond_size = Column(String)
    dimension = Column(String)
    gross_weight = Column(Float)
    launch_year = Column(Integer)
    metal_and_stone = Column(String)
    metal_color = Column(String)
    metal_purity = Column(String)
    net_weight = Column(Float)
    package_content = Column(String)
    plating_type = Column(String)
    product_description = Column(String)
    product_name = Column(String)
    product_size = Column(String)
    selling_complexity = Column(String)
    setting_type = Column(String)
    suitable_for = Column(String)
    total_stone_weight = Column(Float)
    total_stones = Column(Integer)
    hsn_code = Column(String)
    mfg_code = Column(String)
    code = Column(Float)
