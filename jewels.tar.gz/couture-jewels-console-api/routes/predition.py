from fastapi import APIRouter, HTTPException
import pandas as pd
import numpy as np
from models import FilterRequest, SimilarProductsRequest
# from typing import List
# import io
# from PIL import Image
# import torch
# import faiss
# import os
# from transformers import CLIPProcessor, CLIPModel
from settings import CSV_FILE_PATH
prediction_router = APIRouter(prefix="", tags=["prediction"])

@prediction_router.post("/filters")
async def get_filters(
    request: FilterRequest,
):
    try:
        # Read the CSV file into a DataFrame
        df = pd.read_csv(CSV_FILE_PATH)
        if request.metal_and_stone:
            df = df[df['itemid_metal_and_stone'] == request.metal_and_stone]
        if request.gross_weight:
            df = df[df['itemid_gross_weight'] == request.gross_weight]
        if request.category:
            df = df[df['itemid_category'] == request.category]
        if request.sub_category:
            df = df[df['itemid_sub_category'] == request.sub_category]

        ## get the unique lements of the column request.search_col and return as json
        unique_elements = df[request.search_col].unique()
        return {"unique_elements": unique_elements.tolist()}
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"An error occurred: {e}")


@prediction_router.post("/similar-products")
async def filter_products(request: SimilarProductsRequest):
    try:
        # Read the CSV file into a DataFrame
        df = pd.read_csv(CSV_FILE_PATH)
        df = df[df['itemid'] == request.itemid]

        ## get the unique lements of the column request.search_col and return as json
        unique_elements = df["similar_itemid"].unique()
        return {"unique_elements": unique_elements.tolist()}
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"An error occurred: {e}")


# # Load the embeddings and initialize Faiss index
# embeddings_df = pd.read_parquet("./image_embeddings.parquet")
# product_ids = embeddings_df["itemid"].values
# product_embeddings = np.stack(embeddings_df["inferred_vector"].values)
# index = faiss.IndexFlatL2(product_embeddings.shape[1])
# index.add(product_embeddings.astype(np.float32))

# # Load the CLIP model and processor
# device = "cuda" if torch.cuda.is_available() else "cpu"
# model_name = "/data/ajiob2c/models/clip-vit-large-patch14"
# model = CLIPModel.from_pretrained(model_name).to(device)
# processor = CLIPProcessor.from_pretrained(model_name)


# # Function to get image embedding
# def get_image_embedding(image: Image.Image):
#     inputs = processor(images=image, return_tensors="pt").to(device)
#     with torch.no_grad():
#         embedding = model.get_image_features(**inputs).cpu().numpy()
#     return embedding

# # Function to retrieve similar products
# def get_similar_products(embedding, k=20):
#     D, I = index.search(embedding.astype(np.float32), k)
#     return product_ids[I[0]]

# # Function to generate image file path
# def get_image_path(product_id):
#     image_dir = "/data/retail/jewels/images/imgs"
#     return os.path.join(image_dir, f"{product_id}", f"{product_id}.png")

# # Function to get item name and metal and stone
# def get_item_details(product_id):
#     image_path = get_image_path(product_id)
#     if os.path.exists(image_path):
#         jewels_data = pd.read_csv("/app/Ankit/jewels_img_search/csv/jewels_visual_search.csv")
#         category_code = jewels_data.loc[jewels_data['base_code'] == product_id, 'category_code'].values[0]
#         item_name = category_mapping.get(category_code, 'Unknown')
#         metal_and_stone = jewels_data.loc[jewels_data['base_code'] == product_id, 'metal_and_stone'].values[0]
#         return item_name, metal_and_stone
#     else:
#         raise HTTPException(status_code=404, detail=f"Image file not found for product ID {product_id}")

# @app.post("/process-image/")
# async def process_image(file: UploadFile = File(...)):
#     try:
#         image = Image.open(io.BytesIO(await file.read()))

#         # Generate embedding
#         embedding = get_image_embedding(image)

#         # Retrieve similar products
#         similar_product_ids = get_similar_products(embedding)

#         # Check if top 5 similar items have score > 0.8
#         results = []
#         for product_id in similar_product_ids:
#             item_name, metal_and_stone = get_item_details(product_id)
#             similarity_score = 1 - np.linalg.norm(embedding - product_embeddings[product_ids == product_id])
#            # if similarity_score > 0:
#             print(type(similarity_score), similarity_score)
#             results.append({"product_id": product_id, "category": item_name, "metal_and_stone": metal_and_stone})

#         return results

#     except Exception as e:
#         raise HTTPException(status_code=500, detail=f"Error processing image: {str(e)}")

