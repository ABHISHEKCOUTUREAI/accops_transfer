CSV_FILE_PATH = "./data/jewels_sim_search_concat.csv"
