# couture-jewels-console-api

## Prerequisites
Ensure you have the following prerequisites:    
1. Docker and Docker Compose installed on your machine.
2. A PostgreSQL service running and accessible within the same network as the application.

## Settings
- Currently not used    
place the following file with the name '.env' in the main folder(where main.py is present)
```
POSTGRES_USER=<username>
POSTGRES_PASSWORD=<password>
POSTGRES_DB=<database_name>
POSTGRES_SERVICE=<service_name as per the container>
POSTGRES_PORT=<port as per the psql service>
```
## Running the app
run the following commands
```
docker compose build
docker compose up
```