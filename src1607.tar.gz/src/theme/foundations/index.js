import colors from './colors';
import breakpoints from './breakpoints';
import blur from './blur';
import shadow from './shadow';
import { chakraColors } from '../../Static/properties/properties';

const foundations = {
  colors: { ...colors, ...chakraColors },
  breakpoints,
  blur,
  shadow
};

export default foundations;
