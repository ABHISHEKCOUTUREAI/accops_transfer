const shadow = {
  shadow1: '2px 2px 50px rgba(0, 0, 0, 0.03), -2px -2px 50px rgba(0, 0, 0, 0.03)',
  shadow12: '4px 4px 50px rgba(0, 0, 0, 0.05), -4px -4px 50px rgba(0, 0, 0, 0.05)'
};

export default shadow;
