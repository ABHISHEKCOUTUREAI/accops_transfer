const colors = {
  // framebg: '#ededed',
  hyperlink: '#0101FF',
  hoverColor: '#3452C9',
  white: '#FFFFFF',
  shadow: '#e7e7e7',
  hoverShadow: '#aaaaaa',
  heroColor: 'black',
  heroColorHover: '#f9f9f9',
  tableHeaderBg: '#f9f9f9',

  primary: {
    lighter: '#dde7f1',
    light: '#d0ddeb',
    main: '#263F5B',
    hover: '#32455c'
  },

  // primary: {
  //   lightest: '#FB4E0B80',
  //   lighter: '#fcab8b',
  //   light: '#fa9269',
  //   main: '#FB4E0B',
  //   dark: '#e2470a',
  //   darker: '#fa7948'
  // },

  gray: {
    lighter: '#f4f2f2',
    light: '#C5C5C5',
    light_filter:
      'brightness(0) saturate(100%) invert(91%) sepia(0%) saturate(65%) hue-rotate(135deg) brightness(88%) contrast(91%)',
    main: '#777777',
    dark: '#333333',
    darker: '#4a5568',
    semilight: '#aaaaaa',
    100: '#e2e6f0',
    300: '#eaeaea',
    400: '#cbd0e0',
    500: '#e6e6e6',
    600: '#f9f9f9',
    700: '#fdfdfd'
  },
  success: {
    light: '#e1fceb',
    main: '#5A9808',
    dark: '#028525',
    darker: '#37a619'
  },

  warning: {
    light: '#FFE16A',
    main: '#FFC107',
    dark: '#B78103'
  },

  error: {
    light: '#FBCBC6',
    main: '#EB3F34',
    dark: '#B72136'
  },

  brown: {
    light: '#866428'
  },

  black: {
    1000: '#000000',
    800: '#2B2B2B',
    600: '#555555',
    400: '#808080',
    200: '#AAAAAA',
    100: '#aaaaaa33'
  },
  skyblue: '#97c3f0',
  lightorange: '#fcf2e1',
  orange: '#dd6a1f',
  lightred: '#fce1e2',
  // red: '#ff0000',
  blue: '#4287f5',
  pastsales: ['#001F3F', '#005B96', '#4D94DB', '#71B2E5', '#93C8EF'],
  // barchart: ['#001F3F', '#2BB45B', '#4D94DB', '#71B2E5', '#93C8EF']
  // yellow: '#fff5e3',
  // darkyellow: 'fffd37a',
  // lightpink: '#ff968c'
  green: {
    main: '#32a852',
    light: '#c3dbca'
  }
};
export default colors;
