import { Box, Flex } from '@chakra-ui/layout';
import { Skeleton, useTheme, Button, Text } from '@chakra-ui/react';
import React, { useContext, useState } from 'react';
import { LocationContext } from '../Contexts/LocationContext';
// import { attachGlobalFilters, attachTableData } from '../Utils/misc';
// import axios from 'axios';
import { NewReleases, RemoveShoppingCart, ReportProblem, Check } from '@mui/icons-material';
import { Chip } from '@mui/material';
import statusColors from './statusColors';
import { XTable, useXTableState } from '../components/CommonTable';
import { useLocation } from 'react-router-dom';
import { getCartAPI } from '../Utils/CartAPI';
import DownloadIcon from '@mui/icons-material/Download';

const OrderDetails = () => {
  const chakratheme = useTheme();
  const location = useLocation();
  const id = location.pathname.split('/')[location.pathname.split('/').length - 1];

  const { consoleState } = useContext(LocationContext);
  const cartAPI = getCartAPI(consoleState);
  const [order, setOrder] = useState(null);
  const [productsOrdered, setProductsOrdered] = useState([]);

  const handleDataFetch = async (reqBody) => {
    try {
      const res = await cartAPI.getOrderDetails(reqBody);
      setOrder({
        count: res.data.count,
        order_status: res.data.order_status,
        ordered_at: res.data.ordered_at,
        fulfilled_at: res.data.fulfilled_at,
        total_order_value: res.data.total_order_value
      });
      return res;
    } catch (e) {
      console.log(e);
    }
  };

  const handlePagination = async (state, page) => {
    const reqBody = {
      order_id: id,
      page_no: page,
      page_count: state.pagination.pageSize,
      filters: []
    };

    // let formData = new FormData();
    // formData = attachTableData(formData, assortmentTableState);
    // let dataObj = Object.fromEntries(formData)

    const response = await handleDataFetch(reqBody);
    setProductsOrdered(response.data.products);
    return {
      data: response.data.products.map((x) => ({ ...x, total: x.price * x.ordered_quantity })),
      totalRecords: response.data.count
    };
    // return {
    //   data: response.data[consoleState.state.assortmentTable.types['assortment'].apiKey].map(
    //     (data) => {
    //       return {
    //         ...data,
    //         order_status:
    //           data.minimum_replenishment > 0
    //             ? 'notplaced'
    //             : ['fulfilled', 'notplaced', 'progress', ''][Math.floor(Math.random() * 4)]
    //       };
    //     }
    //   ),
    //   totalRecords: response.data[`assortment_count`]
    // };
  };

  const convertToCSV = (data, keys) => {
    const csvRows = [];

    // Add the headers
    csvRows.push(keys.join(','));

    // Add the rows
    for (const row of data) {
      const values = keys.map((key) => `"${row[key]}"`);
      csvRows.push(values.join(','));
    }

    return csvRows.join('\n');
  };

  // Function to download the CSV file
  const downloadCSV = (csvData, filename) => {
    const blob = new Blob([csvData], { type: 'text/csv' });
    const url = window.URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.setAttribute('hidden', '');
    a.setAttribute('href', url);
    a.setAttribute('download', filename);
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
  };

  //   const formatInternationalStandard = (num) => {
  //     // remove decimal from number
  //     if (num > 0) {
  //       const numStr = num.toString().split('.')[0];
  //       // add commas to number
  //       return numStr.replace(/(\d)(?=(\d{3})+(?!\d))/g, '$1,');
  //     } else {
  //       return num;
  //     }
  //   };

  const tableConfig = {
    maxHeight: '800px',
    rows: {
      rowDatakey: 'product_id'
    },
    columns: {
      headers: [
        {
          title: 'Inventory Status',
          id: 'status',
          dataIndex: 'status_label',
          colSpan: 1,
          sort: {
            allow: true
          },
          transformer: ({ value }) => {
            const statusToBgColor = {
              '0_new': '#caddfc',
              '9_excess': '#f7cfb5',
              '1_replenish': '#fccbc7',
              '2_no_replenishment': '#c3dbca'
            };
            const statusToColor = {
              '0_new': '#4287f5',
              '9_excess': '#Dd6A1F',
              '1_replenish': '#eb4034',
              '2_no_replenishment': '#32a852'
            };
            const statusToName = {
              '0_new': 'New',
              '9_excess': 'Excess',
              '1_replenish': 'Low Stock',
              '2_no_replenishment': 'Optimal'
            };
            const statusToIcon = {
              '0_new': NewReleases,
              '9_excess': RemoveShoppingCart,
              '1_replenish': ReportProblem,
              '2_no_replenishment': Check
            };
            const Icon = statusToIcon[value];
            return (
              <Chip
                icon={
                  <Icon
                    style={{
                      color: statusToColor[value],
                      fontSize: '14px'
                    }}
                  />
                }
                key={value}
                label={statusToName[value]}
                style={{
                  fontWeight: 'bold',
                  backgroundColor: statusToBgColor[value],
                  color: statusToColor[value]
                }}
                size="small"
              />
            );
          },
          filters: {
            filterType: 'discrete',
            filterID: 'status_label',
            discrete: {
              multiple: true,
              options: [
                { label: 'New', value: '0_new' },
                { label: 'Excess', value: '9_excess' },
                { label: 'Low Stock', value: '1_replenish' },
                { label: 'Optimal', value: '2_no_replenishment' }
              ],
              optionTransformer: ({ value }) => {
                const statusToBgColor = {
                  '0_new': '#caddfc',
                  '9_excess': '#f7cfb5',
                  '1_replenish': '#fccbc7',
                  '2_no_replenishment': '#c3dbca'
                };
                const statusToColor = {
                  '0_new': '#4287f5',
                  '9_excess': '#Dd6A1F',
                  '1_replenish': '#eb4034',
                  '2_no_replenishment': '#32a852'
                };
                const statusToName = {
                  '0_new': 'New',
                  '9_excess': 'Excess',
                  '1_replenish': 'Low Stock',
                  '2_no_replenishment': 'Optimal'
                };
                const statusToIcon = {
                  '0_new': NewReleases,
                  '9_excess': RemoveShoppingCart,
                  '1_replenish': ReportProblem,
                  '2_no_replenishment': Check
                };
                const Icon = statusToIcon[value];
                return (
                  <Chip
                    icon={
                      <Icon
                        style={{
                          color: statusToColor[value],
                          fontSize: '14px'
                        }}
                      />
                    }
                    key={value}
                    label={statusToName[value]}
                    style={{
                      fontWeight: 'bold',
                      backgroundColor: statusToBgColor[value],
                      color: statusToColor[value]
                    }}
                    size="small"
                  />
                );
              }
            }
          }
        },
        {
          title: 'Product ID',
          id: 'product_id',
          dataIndex: 'product_id',
          colSpan: 1
        },
        {
          title: 'Name',
          sort: {
            allow: true
          },
          id: 'product_name',
          dataIndex: 'product_name',
          colSpan: 1,
          filters: {
            filterType: 'search',
            filterID: 'product_name'
          }
        },
        {
          title: 'Molecule',
          sort: {
            allow: true
          },
          dataIndex: 'description',
          colSpan: 1,
          filters: {
            filterType: 'search',
            filterID: 'description'
          }
        },
        {
          title: 'SBU',
          sort: {
            allow: true
          },
          id: 'L0',
          dataIndex: 'L0',
          colSpan: 1
        },
        {
          title: 'Segment',
          id: 'L3',
          dataIndex: 'L3',
          colSpan: 1
        },
        {
          title: 'Price',
          id: 'price',
          dataIndex: 'price',
          colSpan: 1,
          filters: {
            filterType: 'range',
            filterID: 'price',
            range: {
              defaultMin: 0,
              defaultMax: 10000
            }
          }
        },

        {
          title: 'Ordered Quantity',
          id: 'ordered_quantity',
          dataIndex: 'ordered_quantity',
          colSpan: 1,
          filters: {
            filterType: 'range',
            filterID: 'ordered_quantity',
            range: {
              defaultMin: 0,
              defaultMax: 1000
            }
          }
        },
        {
          title: 'Total',
          id: 'total',
          dataIndex: 'total',
          colSpan: 1
        },
        {
          title: 'Order Status',
          dataIndex: 'order_status',
          colSpan: 1,
          transformer: ({ value }) => {
            if (!value) return null;
            const { statusToBgColor, statusToColor, statusToIcon } = statusColors;
            const valueToKey = {
              progress: 'partial',
              unfulfilled: 'pending',
              fulfilled: 'done'
            };
            const valueToLabel = {
              progress: 'In Progress',
              unfulfilled: 'Unfulfilled',
              fulfilled: 'Fulfilled'
            };
            const _key = valueToKey[value];
            const Icon = statusToIcon[_key];
            return (
              <Chip
                icon={
                  <Icon
                    style={{
                      color: statusToColor[_key],
                      fontSize: '14px'
                    }}
                  />
                }
                label={valueToLabel[value]}
                style={{
                  fontWeight: 'bold',
                  backgroundColor: statusToBgColor[_key],
                  color: statusToColor[_key]
                }}
                size="small"
              />
            );
          }
        }

        // {
        //   title: 'Recommended Replenishment',
        //   id: 'recommended_replenishment',
        //   dataIndex: 'minimum_replenishment',
        //   colSpan: 1,
        //   cellBackground: ({ row }) => {
        //     const statusToBgColor = {
        //       '0_new': '#caddfc',
        //       '9_excess': '#f7cfb5',
        //       '1_replenish': '#fccbc7',
        //       '2_no_replenishment': '#c3dbca'
        //     };
        //     return statusToBgColor[row['status_label']];
        //   },
        //   transformer: ({ value, row }) => {
        //     const statusToBgColor = {
        //       '0_new': '#caddfc',
        //       '9_excess': '#f7cfb5',
        //       '1_replenish': '#fccbc7',
        //       '2_no_replenishment': '#c3dbca'
        //     };
        //     const statusToColor = {
        //       '0_new': '#4287f5',
        //       '9_excess': '#Dd6A1F',
        //       '1_replenish': '#eb4034',
        //       '2_no_replenishment': '#32a852'
        //     };

        //     const statusToIcon = {
        //       '0_new': NewReleases,
        //       '9_excess': RemoveShoppingCart,
        //       '1_replenish': ReportProblem,
        //       '2_no_replenishment': Check
        //     };
        //     const Icon = statusToIcon[row['status_label']];
        //     return (
        //       <Flex
        //         h="100%"
        //         p="5px 20px"
        //         bg={statusToBgColor[row['status_label']]}
        //         alignItems={'center'}
        //         gap="5px"
        //         color={statusToColor[row['status_label']]}>
        //         <Icon style={{ fontSize: '12px' }} />
        //         {value}
        //       </Flex>
        //     );
        //   }
        // }
      ],
      groups: {
        allowGroups: true,
        groups: [
          {
            name: 'Product Details',
            columns: ['Product ID', 'Name', 'Molecule', 'SBU', 'Segment'],
            collapsible: true,
            defaultCollapsed: true,
            collapsedName: 'Summary',
            collapsedTransformer: ({ row }) => {
              return (
                <Flex direction="column" gap="5px" w="100%">
                  <Text fontWeight={'bold'}>{row['product_id']}</Text>
                  <Text
                    w="100%"
                    style={{
                      wordBreak: 'break-word !important',
                      whiteSpace: 'normal'
                    }}>
                    {row['product_name']}
                  </Text>
                </Flex>
              );
            }
          }
        ]
      },
      unhideableColumns: ['Cart', 'Order Status', 'Product ID'],
      defaultHiddenColumns: ['Inventory Status', 'SBU', 'Segment', 'Order Status']
    },
    pagination: {
      infiniteScroll: false,
      allowPagination: true,
      defaultPageNumber: 1,
      defaultPageSize: 20,
      defaultFetchSize: 100,
      pageSizeOptions: [10, 20, 50, 100],
      fetch: handlePagination
    }
  };

  const { state: tableState, setState: setTableState } = useXTableState(tableConfig);
  return (
    <Flex
      direction="column"
      alignItems="flex-start"
      justifyContent="center"
      gap="20px"
      width="100%"
      style={{ padding: '50px 20px 20px 20px' }}>
      <Flex direction="column" id="overview" gap="0px" width={'100%'}>
        <Text
          style={{
            fontSize: '22px',
            fontFamily: 'Poppins',
            fontWeight: 'bold',
            marginTop: '0px'
          }}>
          Order Details <span style={{ color: '#dddddd' }}>#{id}</span>
        </Text>
        <Box w="50px" h="5px" bg={`${chakratheme.colors.primary.main}`} borderRadius="3px" mt={2} />
        {order ? (
          <Flex justifyContent={'space-between'} alignItems={'end'}>
            <Flex
              flex="2"
              // justifyContent="space-between"
              alignItems="center"
              mt={2}
              gap={5}>
              <Text
                fontSize="14px"
                color="#999999"
                p={'8px'}
                background={'#f2f2f2'}
                borderRadius={'8px'}>
                Number of items:{' '}
                <span style={{ color: '#555555', fontWeight: 'bold' }}>{order?.count}</span>
                {/* {order?.count > 1 ? 's' : ''} */}
              </Text>
              <Text
                fontSize="14px"
                color="#999999"
                p={'8px'}
                background={'#f2f2f2'}
                borderRadius={'8px'}>
                <span style={{ color: '#555555', fontWeight: 'bold' }}>
                  {new Date(order?.ordered_at).toString().split(' ').slice(0, 4).join(' ')}
                </span>
              </Text>
              <Text
                fontSize="14px"
                color="#999999"
                p={'8px'}
                background={'#f2f2f2'}
                borderRadius={'8px'}>
                <span style={{ color: '#555555', fontWeight: 'bold' }}>
                  {`₹ ${order?.total_order_value}`}
                </span>
              </Text>
              <Flex
                maxWidth="150px"
                flex="1"
                p="5px 10px"
                alignItems="center"
                justifyContent={'space-around'}
                style={{
                  color:
                    order?.order_status === 'unfulfilled'
                      ? statusColors.statusToColor.partial
                      : statusColors.statusToColor.done,
                  backgroundColor:
                    order?.order_status === 'unfulfilled'
                      ? statusColors.statusToBgColor.partial
                      : statusColors.statusToBgColor.done,
                  borderRadius: '20px'
                }}>
                {/* <Icon fontSize="12px" /> */}
                <Text fontSize="12px" fontWeight="bold">
                  {order?.order_status === 'unfulfilled' ? 'Delivery Expected' : 'Delievered'}
                </Text>
              </Flex>

              {/* <Text fontSize="13px" fontWeight="bold">
                                Fulfilled At: {JSON.stringify(order?.fulfilled_at)}
                              </Text> */}
            </Flex>
            <Flex h={'max-content'}>
              <Button
                padding={'5px 10px'}
                background={chakratheme.colors.primary.main}
                color={'white'}
                borderRadius={'20px'}
                onClick={() => {
                  let csvData = convertToCSV(productsOrdered, Object.keys(productsOrdered[0]));
                  downloadCSV(csvData, 'order_details.csv');
                }}>
                <Text fontSize={'14px'}> Download</Text> <DownloadIcon />
              </Button>
            </Flex>
          </Flex>
        ) : (
          <Skeleton height={'50px'} width={'200px'} />
        )}
      </Flex>

      <Box
        w="100%"
        style={{
          borderRadius: '20px',
          boxShadow: `${chakratheme.colors.shadow} 0px 0px 20px 0px`,
          padding: '20px'
        }}>
        <Flex
          w="100%"
          justifyContent="space-between"
          alignItems={'center'}
          // marginTop="10px"
          fontFamily={'Poppins'}>
          <Box flex="7">
            <Text mb={0} fontWeight={'bold'} fontSize="15px" textAlign="left">
              Items
            </Text>
          </Box>
        </Flex>

        <XTable
          state={tableState}
          setState={setTableState}
          config={tableConfig}
          style={{ fontFamily: 'Hanken Grotesk' }}
          hideFilters={true}
        />
      </Box>
    </Flex>
  );
};

export default OrderDetails;
