import { Box, Flex, Text, useTheme } from '@chakra-ui/react';
import DownloadIcon from '@mui/icons-material/Download';
import IconButton from '@mui/material/IconButton';
import { Tooltip, createTheme } from '@mui/material';
import React, { useContext, useEffect, useState } from 'react';
import axios from 'axios';
import './sticky.css';
import AssortmentTable from '../components/Table';
import DrawerFilters from './DrawerFilters';
import Container from '../Artifactory/Components/Container/Container';
import { Button as ButtonJoy, ThemeProvider } from '@mui/joy';
import { Tune } from '@mui/icons-material';
import { LocationContext } from '../Contexts/LocationContext';
const levelNames = ['Zone', 'State', 'Distribution Center'];

const categoryLevelNames = ['L0', 'L1', 'L2', 'L3'];
const brandLevelNames = ['Manufacturer', 'Brand'];

const NewAssortment = (props) => {
  const chakratheme = useTheme();
  const { consoleState } = useContext(LocationContext);
  const [totalProductsCount3, setTotalProductsCount3] = useState();
  const [stateDataLoading, setStateDataLoading] = useState(false);

  const [headers, setHeaders] = useState([
    {
      name: 'Product ID',
      id: 'product_id',
      sort: '',
      colSpan: 3
    },
    {
      name: 'Product Name',
      id: 'product_name',
      sort: '',
      colSpan: 5,
      type: 'text'
    },
    {
      name: 'Molecule',
      id: 'description',
      sort: '',
      colSpan: 3,
      type: 'text'
    },
    {
      name: 'SBU',
      id: 'L0',
      sort: '',
      colSpan: 2,
      type: 'text'
    },
    {
      name: 'Segment',
      id: 'L3',
      sort: '',
      colSpan: 3,
      type: 'text'
    },
    {
      name: `Retail Price (${consoleState.state.currency || '$'})`,
      id: 'mrp',
      sort: '',
      colSpan: 2,
      type: 'text'
    },
    {
      name: 'Min Qty',
      id: 'min_qty',
      sort: '',
      colSpan: 2,
      type: 'text',
      toolTip: true,
      toolTipText: 'Expected sales in next 2 weeks'
    },
    {
      name: 'Max Qty',
      id: 'max_qty',
      sort: '',
      colSpan: 2,
      type: 'text',
      toolTip: true,
      toolTipText: 'Expected sales in next 3 weeks'
    },
    {
      name: 'Actual Sales',
      id: 'qty_sold',
      sort: 'desc',
      colSpan: 2,
      toolTip: true,
      toolTipText: 'Actual sales in specified time period'
    },
    {
      name: 'Total Amount',
      id: 'total_amount',
      sort: '',
      colSpan: 2
    },
    {
      name: 'Margin',
      id: 'total_margin',
      sort: '',
      colSpan: 2
    },
    {
      name: 'Number of stores',
      id: 'num_stores_product_part_of_assortment',
      sort: '',
      colSpan: 2
    }
  ]);

  const _assortmentTableState = {
    filtersData: {
      filter_type: consoleState.state?.assortmentTable?.defaults.filterData.filter_type || '',
      filter_params: []
    },
    searchData: headers.reduce((acc, header) => {
      if (header.search) acc[header.search_variable] = '';
      return acc;
    }, {}),
    sortData: {
      sort_param: 'qty_sold',
      sort_type: 'desc'
    }
  };
  const [assortmentTableState, setAssortmentTableState] = useState(_assortmentTableState);
  function mapKeyToDisplay(key) {
    switch (key) {
      case 'large':
        return 'Large';
      case 'medium':
        return 'Mid';
      case 'small':
        return 'Small';
      default:
        return key; // Default to the original key if no mapping is specified
    }
  }

  function getCountByKey(key) {
    console.log('key', key);
    const countKey = `${mapKeyToDisplay(key)}Sized_count`;
    if (completeData) {
      return completeData[countKey] !== undefined ? completeData[countKey] : 0;
    } else {
      return 0;
    }
  }

  const handleChange = (event, reset) => {
    // if (newValue == 1) {
    // setStateDataLoading(true);
    const formData = new FormData();
    if (selectedRegions[2] !== null) {
      formData.append('region_type', 'City');
      formData.append('region_name', selectedRegions[2]);
    } else if (selectedRegions[1] !== null) {
      formData.append('region_type', 'State');
      formData.append('region_name', selectedRegions[1]);
    } else {
      return;
    }
    if (selectedCategories[0]) formData.append('L0', selectedCategories[0]);
    if (selectedCategories[1]) formData.append('L1', selectedCategories[1]);
    if (selectedCategories[2]) formData.append('L2', selectedCategories[2]);
    if (selectedCategories[3]) formData.append('L3', selectedCategories[3]);
    formData.append('page_no', 1);
    formData.append('sort_param', assortmentTableState.sortData?.sort_param || '');
    formData.append('sort_type', assortmentTableState.sortData?.sort_type || '');
    if (selectedBrands[0]) formData.append('mfac_name', selectedBrands[0]);
    if (selectedBrands[1]) formData.append('brand_name', selectedBrands[1]);
    console.log(assortmentTableState.sortData?.sort_param, 'CALLING');
    let config = {
      method: 'post',
      url: `${process.env.REACT_APP_API_BASE_URL}/new-store-assortment`,
      data: formData
    };
    axios(config)
      .then(async (response) => {
        setCompleteData(response.data);
        const newOptionKeys = [];
        if (response.data.LargeSized_count !== 0) {
          newOptionKeys.push('large');
        }

        if (response.data.MidSized_count !== 0) {
          newOptionKeys.push('medium');
        }

        if (response.data.SmallSized_count !== 0) {
          newOptionKeys.push('small');
        }

        // Now newOptionKeys contains only non-null values
        setOptionKeys(newOptionKeys);
        if (reset === 0) {
          if (response.data.LargeSized_count !== 0 && selectedOption === 'large') {
            setDataSize(response.data.LargeSized);
            setTotalProductsCount3(response.data.LargeSized_count);
          } else if (response.data.MidSized_count !== 0 && selectedOption === 'medium') {
            setDataSize(response.data.MidSized);
            setTotalProductsCount3(response.data.MidSized_count);
          } else if (response.data.SmallSized_count !== 0 && selectedOption === 'small') {
            setDataSize(response.data.SmallSized);
            setTotalProductsCount3(response.data.SmallSized_count);
          } else {
            let capitalizedKey =
              newOptionKeys[0].charAt(0).toUpperCase() + newOptionKeys[0].slice(1);
            if (capitalizedKey === 'Medium') {
              capitalizedKey = 'Mid';
            }
            setDataSize(response.data[`${capitalizedKey}Sized`]);
            setTotalProductsCount3(response.data[`${capitalizedKey}Sized_count`]);
            setSelectedOption(newOptionKeys[0]);
          }
        } else if (reset === 1) {
          setSelectedOption(newOptionKeys[0]);
          if (response.data.LargeSized_count !== 0) {
            setDataSize(response.data.LargeSized);
            setTotalProductsCount3(response.data.LargeSized_count);
          } else if (response.data.MidSized_count !== 0) {
            setDataSize(response.data.MidSized);
            setTotalProductsCount3(response.data.MidSized_count);
          } else {
            setDataSize(response.data.SmallSized);
            setTotalProductsCount3(response.data.SmallSized_count);
          }
        }
        setStateDataLoading(false);
      })
      .catch(function () {
        setStateDataLoading(false);
        console.log('error');
      });
  };

  const handlePagination3 = () => {
    if (totalProductsCount3 === dataSize.length || page3 < Math.floor(dataSize.length / 100)) {
      return;
    }
    const formData = new FormData();
    if (selectedRegions[2] !== null) {
      formData.append('region_type', 'City');
      formData.append('region_name', selectedRegions[2]);
    } else if (selectedRegions[1] !== null) {
      formData.append('region_type', 'State');
      formData.append('region_name', selectedRegions[1]);
    } else {
      formData.append('region_type', null);
      formData.append('region_name', null);
    }

    if (selectedCategories[0]) formData.append('L0', selectedCategories[0]);
    if (selectedCategories[1]) formData.append('L1', selectedCategories[1]);
    if (selectedCategories[2]) formData.append('L2', selectedCategories[2]);
    if (selectedCategories[3]) formData.append('L3', selectedCategories[3]);
    formData.append('page_no', page3 === 1 ? 2 : Math.floor(page3 / 5) + 2);
    formData.append('sort_param', assortmentTableState.sortData?.sort_param || '');
    formData.append('sort_type', assortmentTableState.sortData?.sort_type || '');
    if (selectedBrands[0]) formData.append('mfac_name', selectedBrands[0]);
    if (selectedBrands[1]) formData.append('brand_name', selectedBrands[1]);
    let config = {
      method: 'post',
      url: `${process.env.REACT_APP_API_BASE_URL}/new-store-assortment`,
      data: formData
    };

    axios(config)
      .then(async (response) => {
        if (selectedOption === 'large') {
          setDataSize((prevData) => [...prevData, ...response.data.LargeSized]);
        } else if (selectedOption === 'medium') {
          setDataSize((prevData) => [...prevData, ...response.data.MidSized]);
        } else {
          setDataSize((prevData) => [...prevData, ...response.data.SmallSized]);
        }
      })
      .catch(function () {
        console.log('error');
      });
  };

  const [uploadedFile, setUploadedFile] = useState(null);
  const [page3, setPage3] = useState(1);
  const [regions_nested, setRegionsNested] = useState([]);
  const [categoryNested, setCategoryNested] = useState([]);
  const [brandData, setBrandData] = useState([]);

  const lastIndex = (array) => {
    let i = array.length - 1;
    while (i >= 0 && array[i] === null) {
      i--;
    }
    return i;
  };
  const [sortBy3, setSortBy3] = useState('qty_sold');
  const [sortOrder3, setSortOrder3] = useState('desc');

  const [selectedRegions, setSelectedRegions] = useState(
    consoleState.state.globalFilters.region.selected
  );
  console.log(consoleState.state, 'HERE');

  const [selectedCategories, setSelectedCategories] = useState(
    Array(categoryLevelNames.length).fill(null)
  );

  const [selectedBrands, setSelectedBrands] = useState(Array(brandLevelNames.length).fill(null));

  useEffect(() => {
    fetchNewStoreFilters();
  }, [selectedRegions, selectedBrands, selectedCategories]);

  useEffect(() => {
    if (initial) {
      fetchFilters('');
      setInitial(false);
    }
  }, [selectedRegions, selectedBrands, selectedCategories]);

  const handleSelectedBranch = () => {};

  useEffect(() => {
    if (!props.open) handleChange(null, 0);
  }, [sortBy3, assortmentTableState.sortData, selectedBrands, selectedCategories, props.open]);

  useEffect(
    () => {
      if (!props.open) handleChange(null, 1);
    },
    [selectedRegions[1], selectedRegions[2], selectedRegions[3]],
    props.open
  );

  const [pinFilters, setPinFilters] = useState(false);

  useEffect(() => {
    window.addEventListener('scroll', isSticky);
    return () => {
      window.removeEventListener('scroll', isSticky);
    };
  });

  const [downloadLoad4, setDownloadLoad4] = useState(false);
  const downloadCSV4 = () => {
    setDownloadLoad4(true);
    const formData = new FormData();
    if (selectedRegions[2] !== null) {
      formData.append('region_type', 'City');
      formData.append('region_name', selectedRegions[2]);
    } else if (selectedRegions[1] !== null) {
      formData.append('region_type', 'State');
      formData.append('region_name', selectedRegions[1]);
    } else {
      return;
    }
    if (selectedCategories[0]) formData.append('L0', selectedCategories[0]);
    if (selectedCategories[1]) formData.append('L1', selectedCategories[1]);
    if (selectedCategories[2]) formData.append('L2', selectedCategories[2]);
    if (selectedCategories[3]) formData.append('L3', selectedCategories[3]);
    formData.append('sort_param', assortmentTableState.sortData?.sort_param || '');
    formData.append('sort_type', assortmentTableState.sortData?.sort_type || '');
    formData.append('store_size', selectedOption);
    if (selectedBrands[0]) formData.append('mfac_name', selectedBrands[0]);
    if (selectedBrands[1]) formData.append('brand_name', selectedBrands[1]);
    let config = {
      method: 'post',
      url: `${process.env.REACT_APP_API_BASE_URL}/new-store-assortment-csv`,
      data: formData,
      responseType: 'blob'
    };
    axios(config)
      .then(function (response) {
        const csvFile = new Blob([response.data], { type: 'text/csv' });

        if (csvFile) {
          const anchor = document.createElement('a');
          anchor.href = URL.createObjectURL(csvFile);
          anchor.download = 'New Store Assortment.csv';
          anchor.style.display = 'none';

          document.body.appendChild(anchor);

          anchor.click();

          URL.revokeObjectURL(anchor.href);

          document.body.removeChild(anchor);
        }
        setDownloadLoad4(false);
      })
      .catch(function () {
        console.log('error');
      });
  };

  const [filterCount, setFilterCount] = useState();
  const [saveRegions, setSaveRegions] = useState();
  const [initial, setInitial] = useState(true);

  const fetchFilters = () => {
    const formData = new FormData();
    const lastIndexNonNull = lastIndex(selectedRegions);

    if (lastIndexNonNull != -1)
      formData.append(
        'region_type',
        levelNames[lastIndexNonNull] === 'Store' ? 'Branch' : levelNames[lastIndexNonNull]
      );
    else formData.append('region_type', null);
    if (lastIndexNonNull != -1) formData.append('region_name', selectedRegions[lastIndexNonNull]);
    else formData.append('region_name', null);
    if (selectedBrands[0]) formData.append('mfac_name', selectedBrands[0]);
    if (selectedBrands[1]) formData.append('brand_name', selectedBrands[1]);
    if (selectedCategories[0]) formData.append('L0', selectedCategories[0]);
    if (selectedCategories[1]) formData.append('L1', selectedCategories[1]);
    if (selectedCategories[2]) formData.append('L2', selectedCategories[2]);
    if (selectedCategories[3]) formData.append('L3', selectedCategories[3]);
    let configStat = {
      method: 'post',
      url: `${process.env.REACT_APP_API_BASE_URL}/fetch-filters`,
      data: formData
    };
    axios(configStat)
      .then(async (response) => {
        setRegionsNested(response.data.location);
        // setCategoryNested(response.data.category);
        // setBrandData(response.data.mfac);
        // setFilterCount(response.data.filters_count);
        // if (initial) {
        setSaveRegions(response.data.location);
        //   setInitial(false);
        // }
      })
      .catch(function () {
        console.log('error');
      });
  };

  const fetchNewStoreFilters = (selectedValue) => {
    const formData = new FormData();
    const lastIndexNonNull = lastIndex(selectedRegions);
    if (selectedValue == 'large') {
      formData.append('store_size', 'NewStore-LargeSized');
    } else if (selectedValue == 'medium') {
      formData.append('store_size', 'NewStore-MidSized');
    } else if (selectedValue == 'small') {
      formData.append('store_size', 'NewStore-SmallSized');
    } else {
      formData.append('store_size', '');
    }

    if (lastIndexNonNull != -1)
      formData.append(
        'region_type',
        levelNames[lastIndexNonNull] === 'Store' ? 'Branch' : levelNames[lastIndexNonNull]
      );
    else formData.append('region_type', null);
    if (lastIndexNonNull != -1) formData.append('region_name', selectedRegions[lastIndexNonNull]);
    else formData.append('region_name', null);
    if (selectedBrands[0]) formData.append('mfac_name', selectedBrands[0]);
    if (selectedBrands[1]) formData.append('brand_name', selectedBrands[1]);
    if (selectedCategories[0]) formData.append('L0', selectedCategories[0]);
    if (selectedCategories[1]) formData.append('L1', selectedCategories[1]);
    if (selectedCategories[2]) formData.append('L2', selectedCategories[2]);
    if (selectedCategories[3]) formData.append('L3', selectedCategories[3]);

    let configStat = {
      method: 'post',
      url: `${process.env.REACT_APP_API_BASE_URL}/new-store-filters`,
      data: formData
    };
    axios(configStat)
      .then(async (response) => {
        setCategoryNested(response.data.category);
        setBrandData(response.data.mfac);
        if (initial === false) {
          setRegionsNested(saveRegions);
        }
        setFilterCount(response.data.filters_count);
      })
      .catch(function () {
        console.log('error');
      });
  };

  /* Method that will fix header after a specific scrollable */
  const isSticky = () => {
    const filler = document.querySelector('.filler');
    const header = document.querySelector('.header-section');
    const scrollTop = window.scrollY;
    if (pinFilters) {
      scrollTop >= 150 ? header.classList.add('is-sticky') : header.classList.remove('is-sticky');
      scrollTop >= 150 ? filler.classList.remove('no-display') : filler.classList.add('no-display');
    }
  };
  //   useEffect(() => {
  //     const filler = document.querySelector('.filler');

  //     if (pinFilters) {
  //       const header = document.querySelector('.header-section');
  //       const scrollTop = window.scrollY;
  //       if (scrollTop >= 150) header.classList.add('is-sticky');
  //       if (scrollTop >= 150) filler.classList.remove('no-display');
  //     } else {
  //       const header = document.querySelector('.header-section');
  //       header.classList.remove('is-sticky');
  //       filler.classList.add('no-display');
  //     }
  //   }, [pinFilters]);

  const [completeData, setCompleteData] = useState();

  const [selectedOption, setSelectedOption] = useState('large');

  const [dataSize, setDataSize] = useState();

  const handleSelectChange = (event) => {
    const selectedValue = event.target.value;

    if (selectedValue === 'large') {
      setDataSize(completeData.LargeSized);
      setPage3(1);
      setTotalProductsCount3(completeData.LargeSized_count);
    } else if (selectedValue === 'medium') {
      setDataSize(completeData.MidSized);
      setTotalProductsCount3(completeData.MidSized_count);
      setPage3(1);
    } else if (selectedValue === 'small') {
      setDataSize(completeData.SmallSized);
      setTotalProductsCount3(completeData.SmallSized_count);
      setPage3(1);
    }
    setSelectedOption(selectedValue);
    fetchNewStoreFilters(selectedValue);
  };

  const capitalizeFirstLetter = (string) => {
    return string.replace(/\b\w/g, (match) => match.toUpperCase());
  };

  const [optionKeys, setOptionKeys] = useState([]);

  useEffect(() => {
    console.log(assortmentTableState, 'HEREE');
  }, [assortmentTableState]);

  return (
    <Container h="100%">
      <Flex direction="column" id="overview">
        <Text
          style={{
            fontSize: '22px',
            fontFamily: 'Poppins',
            fontWeight: 'bold',
            marginTop: '0px'
          }}>
          New Store Assortment
        </Text>
        <Box
          w="100px"
          h="5px"
          bg={`${chakratheme.colors.primary.main}`}
          borderRadius="3px"
          mt={2}
        />
      </Flex>
      <DrawerFilters
        open={props.open}
        setOpen={props.setOpen}
        isCollapsed={props.isCollapsed}
        fetchFilters={fetchFilters}
        fetchNewStoreFilters={fetchNewStoreFilters}
        nonedit={false}
        uploadedFile={uploadedFile}
        setUploadedFile={setUploadedFile}
        pinFilters={pinFilters}
        setPinFilters={setPinFilters}
        categoryNested={categoryNested}
        categoryLevelNames={categoryLevelNames}
        selectedCategories={selectedCategories}
        setSelectedCategories={setSelectedCategories}
        regions_nested={regions_nested}
        filterCount={filterCount}
        levelNames={levelNames}
        selectedRegions={selectedRegions}
        setSelectedRegions={setSelectedRegions}
        handleSelectedBranch={handleSelectedBranch}
        brandData={brandData}
        brandLevelNames={brandLevelNames}
        selectedBrands={selectedBrands}
        setSelectedBrands={setSelectedBrands}
        levelExamples={props.levelExamples}
        hideFilters={localStorage.getItem('role') === 'store manager' ? ['region'] : []}
      />
      <Text
        mt={3}
        style={{
          color: `${chakratheme.colors.black[400]}`,
          fontSize: '13px',
          fontFamily: 'sans-serif'
        }}>
        Assortment for opening a new store in the chosen distribution center or state.
      </Text>
      <Flex
        alignItems={'center'}
        style={{
          marginTop: '20px'
        }}>
        <ThemeProvider theme={() => createTheme()}>
          <ButtonJoy
            variant="outlined"
            color="neutral"
            startDecorator={<Tune />}
            onClick={() => props.setOpen(true)}>
            Change filters
          </ButtonJoy>
        </ThemeProvider>
        <Flex
          id="analysis"
          ml={5}
          color={`${chakratheme.colors.gray.main}`}
          style={{
            backgroundColor: `${chakratheme.colors.gray.lighter}`,
            borderRadius: '5px',
            padding: '7px 20px',
            fontSize: '13px'
          }}
          justifyContent={'flex-start'}>
          {/* <HourglassTop style={{ marginRight: '10px' }} /> */}
          <Text fontWeight={'bold'} fontSize="13px">
            Duration of Assortment -
          </Text>
          <Text ml={1} fontWeight={'bold'} fontSize="13px">
            July 25-31, 2023
          </Text>
        </Flex>
      </Flex>
      <Flex flexDir={'column'} mt={4} w="99%" mb={50}>
        <div
          className="filler no-display"
          style={{
            height: '400px',
            width: '100%'
          }}></div>
        <Box mt={5} w="100%" h="100%">
          <Box>
            <Box>
              {selectedRegions[2] ? (
                <Text mb={3} fontWeight={900} fontSize="17px" textAlign="left">
                  New Store Assortment of{' '}
                  <span
                    style={{
                      color: 'green',
                      fontWeight: 'bold',
                      backgroundColor: `${chakratheme.colors.success.light}`,
                      padding: '2px 3px',
                      borderRadius: '4px'
                    }}>
                    {capitalizeFirstLetter(selectedRegions[2])}{' '}
                  </span>{' '}
                  Distribution Center
                </Text>
              ) : selectedRegions[1] ? (
                <Text mb={3} fontWeight={900} fontSize="19px" textAlign="left">
                  New Store Assortment of{' '}
                  <span
                    style={{
                      color: 'green',
                      fontWeight: 'bold',
                      backgroundColor: `${chakratheme.colors.success.light}`,
                      padding: '2px 3px',
                      borderRadius: '4px'
                    }}>
                    {capitalizeFirstLetter(selectedRegions[1])}{' '}
                  </span>{' '}
                  State
                </Text>
              ) : (
                <Text mb={3} fontWeight={900} fontSize="19px" textAlign="left"></Text>
              )}
            </Box>
            {selectedRegions[1] ? (
              <Box>
                <Flex
                  style={{ cursor: 'pointer' }}
                  justifyContent="space-between"
                  alignItems={'center'}
                  marginTop="20px"
                  mb={6}>
                  <Flex w="100%">
                    <Text fontSize="14px" mr={5} fontWeight={800} mb={1}>
                      Store Type:
                    </Text>
                    <select width="10%" onChange={handleSelectChange} value={selectedOption}>
                      {optionKeys.map((key) => (
                        <option key={key} value={key}>
                          {key}
                        </option>
                      ))}
                    </select>
                    <Text ml={5} mb={1}>
                      The store will have : {getCountByKey(selectedOption)} items
                    </Text>
                  </Flex>
                  <Flex>
                    <Text marginTop="15px">{downloadLoad4 && 'Downloading...'}</Text>
                    <Tooltip title="Download assortment" placement="top" arrow>
                      <IconButton
                        variant="contained"
                        sx={{
                          cursor: 'pointer',
                          backgroundColor: 'white',
                          color: `${chakratheme.colors.primary.main}`,
                          transition: 'color 0.1s',
                          boxShadow: `0 0 20px 0 ${chakratheme.colors.shadow}`,
                          borderRadius: '50px',
                          width: '35px',
                          height: '35px',
                          '&:hover': {
                            backgroundColor: `${chakratheme.colors.primary.main}`,
                            color: 'white'
                          }
                        }}
                        onClick={() => downloadCSV4()}>
                        <DownloadIcon sx={{ fontSize: '22px' }} />
                      </IconButton>
                    </Tooltip>
                  </Flex>
                </Flex>
                <AssortmentTable
                  data={dataSize}
                  handlePagination={handlePagination3}
                  totalProductsCount={totalProductsCount3}
                  page={page3}
                  loading={stateDataLoading}
                  setPage={setPage3}
                  sortBy={sortBy3}
                  setSortBy={setSortBy3}
                  sortOrder={sortOrder3}
                  setSortOrder={setSortOrder3}
                  headers={headers}
                  setHeaders={setHeaders}
                  assortmentTableState={assortmentTableState}
                  setAssortmentTableState={setAssortmentTableState}
                />
              </Box>
            ) : (
              <Text
                color={`${chakratheme.colors.black[400]}`}
                mt={1}
                fontSize="17px"
                fontFamily="sans-serif">
                * Apply state or distribution center filter to view New Store Assortment
              </Text>
            )}
          </Box>
        </Box>
      </Flex>
    </Container>
  );
};

export default NewAssortment;
