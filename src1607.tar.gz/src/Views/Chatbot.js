/* eslint-disable no-unused-vars */
/* eslint-disable react/no-unescaped-entities */
import {
  Text,
  Box,
  Flex,
  useTheme,
  InputGroup,
  Input,
  IconButton,
  Spacer,
  Image,
  CircularProgress,
  Button
} from '@chakra-ui/react';
import talktome from '../Static/talktome.webp';
import model from '../Static/model_.png';
import query from '../Static/query_.png';
import React, { useEffect, useState } from 'react';
import axios from 'axios';
import { RestartAlt, Send, Stop } from '@mui/icons-material';
import { useLocation } from 'react-router-dom';

const Chatbot = (props) => {
  const chakratheme = useTheme();
  const [dataLoading, setDataLoading] = useState(false);
  const location = useLocation();
  const [enteredQuery, setEnteredQuery] = useState(location?.state?.query || '');
  const [typedQuery, setTypedQuery] = useState('');
  const [hovered, setHovered] = useState(null);
  const [queriesLoading, setQueriesLoading] = useState({});

  const exampleQueries = [
    ['Give top 5 items', ' with maximum existing inventory'],
    ['What are the top 5 items with', ' the highest bounce rates along with product names'],
    ['What is the revenue generated', ' in each zone?'],
    ['What is the revenue generated', ' in in each distribution center ?']
  ];
  console.log(`${process.env.REACT_APP_API_NL_QUERY}/query`, 'HELLo');
  const [data, setData] = useState([]);
  const fetchDataForQuery = async (query) => {
    const config = {
      url: `${process.env.REACT_APP_API_NL_QUERY}/query`,
      method: 'POST',
      headers: {
        'Content-Type': 'application/json'
      },
      data: {
        query: query
      }
    };
    const res = await axios(config);
    return res.data;
  };
  const fetchImageQuery = async (query, query_output, chat_history) => {
    try {
      const config = {
        method: 'POST',
        url: `${process.env.REACT_APP_API_NL_QUERY}/query_image`,
        data: {
          query: query,
          query_output: query_output,
          chat_history: chat_history
        }
      };
      const response = await axios(config);
      const base64Regex = /^[A-Za-z0-9+/]+={0,2}$/;
      const url = base64Regex.test(response.data.image)
        ? `data:image/jpeg;base64,${response.data.image}`
        : null;
      setData((prev) => {
        const index = prev.findIndex((itm) => itm.query == query);
        prev[index] = { ...prev[index], image: url };
        return prev;
      });
    } catch (err) {
      console.log(err);
    }
  };
  const regenerate = (index) => {
    const query = data[index].query;
    setQueriesLoading({ ...queriesLoading, [index]: true });
    fetchDataForQuery(query).then((response) => {
      const updatedData = [...data];
      updatedData[index] = { query: query, response: response.result };

      setData(updatedData);
      fetchImageQuery(query, response.result, response.chat_history);
      setQueriesLoading({ ...queriesLoading, [index]: false });
    });
  };
  useEffect(() => {
    console.log('HELL0', `${process.env.REACT_APP_API_NL_QUERY}/query`);
    const config = {
      url: `${process.env.REACT_APP_API_NL_QUERY}/query`,
      method: 'POST',
      headers: {
        'Content-Type': 'application/json'
      },
      data: {
        query: enteredQuery
      }
    };
    if (enteredQuery !== '') {
      setData([
        ...data,
        {
          query: enteredQuery,
          response: null
        }
      ]);
      setDataLoading(true);
      axios(config)
        .then((response) => {
          setData([
            ...data,
            {
              query: enteredQuery,
              response: response.data['result']
            }
          ]);
          fetchImageQuery(enteredQuery, response.data['result'], response.data['chat_history']);
          setEnteredQuery('');
        })
        .catch((error) => {
          console.log(error);
        })
        .finally(() => {
          setDataLoading(false);
          // scroll to question-i div
        });
    }
  }, [enteredQuery]);
  useEffect(() => {
    console.log(data, 'DATAA');
    const element = document.getElementById(`question-${data.length - 1}`);
    if (element) element.scrollIntoView({ behavior: 'smooth' });
  }, [data]);

  return (
    <Flex direction={'column'} bg="white" px="50px" h="calc(100vh - 80px)" overflow="auto">
      <Flex direction="column">
        <Text
          style={{
            fontSize: '22px',
            fontFamily: 'Poppins',
            fontWeight: 'bold'
            // marginTop: '50px'
          }}>
          Retail AI Engine
        </Text>
        <Box
          ml={6}
          w="50px"
          h="5px"
          bg={`${chakratheme.colors.primary.main}`}
          borderRadius="3px"
          mt={2}
        />
      </Flex>
      <Flex w="100%" h="100%" direction={'column'} pt="40px">
        {enteredQuery == '' && data.length <= 0 ? (
          <Flex
            direction="column"
            h="100%"
            w="100%"
            justifyContent={'center'}
            alignItems={'center'}>
            <Spacer />
            <Flex h="100%">
              <Image src={talktome} alt="talktome" h="100%" objectFit={'contain'} />
            </Flex>
            <Flex
              h="100%"
              w="100%"
              gap="10px"
              wrap="wrap"
              alignContent={'stretch'}
              alignItems={'center'}
              justifyContent={'center'}>
              {exampleQueries.map((query, index) => {
                return (
                  <Flex
                    fontFamily={'Jost'}
                    _hover={{
                      backgroundColor: '#f5f5f5 !important'
                    }}
                    w="45%"
                    direction={'column'}
                    style={{
                      border: '1px solid #E6E6E6',
                      borderRadius: '5px',
                      padding: '10px',
                      margin: '5px',
                      cursor: 'pointer'
                    }}
                    onClick={() => {
                      setEnteredQuery(query.join(''));
                    }}
                    key={index}>
                    <Text color="#333333" fontWeight={'bold'}>
                      {query[0]}
                    </Text>
                    <Text color="#888888">{query[1]}</Text>
                  </Flex>
                );
              })}
            </Flex>
          </Flex>
        ) : null}
        {data.length > 0 ? (
          <Flex position={'relative'} h="100%" w="100%">
            <Flex
              overflowY={'auto'}
              direction={'column'}
              w="100%"
              h="100%"
              position="absolute"
              alignItems={'center'}
              pt="10px"
              gap="20px"
              fontFamily={'Jost'}>
              {data.map((item, index) => {
                return (
                  <Flex
                    onMouseEnter={() => {
                      setHovered(index);
                    }}
                    onMouseLeave={() => {
                      setHovered(null);
                    }}
                    gap="5px"
                    id={`question-${index}`}
                    direction={'column'}
                    style={{
                      //   border: '1px solid #E6E6E6',
                      borderRadius: '5px',
                      padding: '10px',
                      //   margin: '5px',
                      width: '100%'
                      //   backgroundColor: '#f5f5f5'
                    }}
                    key={index}>
                    <Flex gap="10px" alignItems={'flex-start'} maxW="70%" minW="40%">
                      {' '}
                      <Image src={query} alt="model" h="30px" m="0px" />
                      <Flex direction="column">
                        <Text fontWeight={'bold'}>{item.query}</Text>
                        <Flex>
                          {' '}
                          <Button
                            display={
                              (enteredQuery == item.query && dataLoading) || queriesLoading[index]
                                ? 'none'
                                : 'block'
                            }
                            visibility={hovered === index ? 'visible' : 'hidden'}
                            leftIcon={
                              <RestartAlt
                                style={{
                                  fontSize: '12px'
                                  // color: chakratheme.colors.gray[600]
                                }}
                              />
                            }
                            onClick={() => {
                              regenerate(index);
                            }}
                            style={{
                              backgroundColor: `transparent`,
                              fontSize: '12px',
                              color: chakratheme.colors.gray.light,
                              border: `1px solid ${chakratheme.colors.gray.light}`,
                              borderRadius: '5px',
                              padding: '5px 0px',
                              width: '100px'
                            }}>
                            Regenerate
                          </Button>
                          <Button
                            display={
                              (enteredQuery == item.query && dataLoading) || queriesLoading[index]
                                ? 'block'
                                : 'none'
                            }
                            //   visibility={hovered === index ? 'visible' : 'hidden'}
                            leftIcon={
                              <Stop
                                style={{
                                  fontSize: '12px'
                                  // color: chakratheme.colors.gray[600]
                                }}
                              />
                            }
                            onClick={() => {
                              // regenerate(index);
                            }}
                            style={{
                              backgroundColor: `transparent`,
                              fontSize: '12px',
                              color: chakratheme.colors.gray.light,
                              border: `1px solid ${chakratheme.colors.gray.light}`,
                              borderRadius: '5px',
                              padding: '5px 0px',
                              width: '80px'
                            }}>
                            Stop
                          </Button>
                        </Flex>
                      </Flex>
                    </Flex>

                    {/* <Text>{item.response[0]}</Text> */}
                    <Flex gap="10px" w="100%" justify={'flex-end'}>
                      <Flex w="70%">
                        <Flex
                          w="100%"
                          direction="column"
                          bg="#f5f5f5"
                          p="20px"
                          gap="20px"
                          borderRadius={'12px'}>
                          {(item.query == enteredQuery && dataLoading) || queriesLoading[index] ? (
                            <Flex w="100%" justify="center" align="center" p="20px">
                              <CircularProgress size="12" isIndeterminate color="green.300" />
                            </Flex>
                          ) : (
                            <>
                              {item?.response?.split('\n').map((line, index) => (
                                <Text key={index}>{line}</Text>
                              ))}

                              {item.image && (
                                <Flex>
                                  <Image src={item.image} objectFit={'fill'} />
                                </Flex>
                              )}
                            </>
                          )}
                        </Flex>
                      </Flex>
                      <Image src={model} alt="model" h="30px" m="0px" />
                    </Flex>
                  </Flex>
                );
              })}
            </Flex>
          </Flex>
        ) : null}
      </Flex>
      <Flex position={'sticky'} bottom={'40px'} alignItems={'center'} pt="40px" w="100%">
        <InputGroup>
          <Input
            value={typedQuery}
            onChange={(e) => setTypedQuery(e.target.value)}
            onKeyDown={(e) => {
              if (e.key === 'Enter') {
                setEnteredQuery(typedQuery);
                setTypedQuery('');
              }
              // on up arrow, previous query
              // on down arrow, next query
              if (e.key === 'ArrowUp') {
                setTypedQuery(data[data.length - 1].query);
              }
              if (e.key === 'ArrowDown') {
                console.log('down arrow');
              }
            }}
            sx={{
              width: '100%',
              //   height: '50px',
              borderRadius: '12px',
              border: '1px solid #E6E6E6',
              // boxShadow: '0px 4px 4px rgba(0, 0, 0, 0.25)',
              fontSize: '16px',
              fontWeight: 'normal',
              fontFamily: 'Jost',
              color: '#000000',
              padding: '10px',
              '&:focus': {
                borderColor: `${chakratheme.colors.primary.main} !important`
              }
              //   marginTop: '20px'
            }}
            variant="outline"
            placeholder="Ask Follow up"
          />
        </InputGroup>
        <IconButton
          icon={<Send />}
          onClick={() => {
            setEnteredQuery(typedQuery);
            setTypedQuery('');
          }}
          style={{
            backgroundColor: `${chakratheme.colors.primary.main}`,
            color: 'white',
            padding: '10px',
            borderRadius: '50%',
            marginLeft: '10px'
          }}
        />
      </Flex>
    </Flex>
  );
};

export default Chatbot;
