import { Box, Flex, Text, useTheme } from '@chakra-ui/react';
import { HourglassTop, Tune } from '@mui/icons-material';
import { useToast } from '@chakra-ui/react';
import { createTheme } from '@mui/material';
import { Button as ButtonJoy, ThemeProvider } from '@mui/joy';
import React, { useEffect, useState, useContext } from 'react';
import axios from 'axios';
import './sticky.css';
import Container from '../Artifactory/Components/Container/Container';
import DrawerFilters from './DrawerFilters';
import MfacCharts from '../Containers/Store Assortment/MfacCharts';
import ProductsAssortment from '../Containers/Store Assortment/ProductsAssortment';
import { fetch_past_sales } from '../Utils/fetch_past_sales';
import { top_brands } from '../Utils/top_brands';
import { mfacRevenue } from '../Utils/mfaRevenue';
import { LocationContext } from '../Contexts/LocationContext';
import { attachGlobalFilters, attachTableData } from '../Utils/misc';
import { formatNumber } from '../Utils/formatNumberMillionBillion';

const AssortmentPlanning = (props) => {
  const chakratheme = useTheme();
  const number_style = {
    fontSize: '30px',
    fontWeight: 'bold',
    fontFamily: 'Sans-Serif',
    color: `${chakratheme.colors.black[600]}`
  };

  const {
    globalFiltersLevelNames,
    filterIDs,
    consoleState,
    // setConsoleState,
    // setGlobalFilterSelections,
    // setDefaultFilterValue,
    selectedRegions,
    setSelectedRegions,
    selectedCategories,
    setSelectedCategories,
    selectedBrands,
    setSelectedBrands
  } = useContext(LocationContext);

  const levelNames = globalFiltersLevelNames('region');
  const categoryLevelNames = globalFiltersLevelNames('category');
  const brandLevelNames = globalFiltersLevelNames('manufacturer');

  const toast = useToast();

  const [hits_misses_data, set_hits_misses_data] = useState([]);
  const [categoryNames, setCategoryNames] = useState([]);
  const [horizontalStackData, setHorizontalStackData] = useState([]);
  const [uploadedFile, setUploadedFile] = useState(null);
  const [page1, setPage1] = useState(1);

  const [finaladdedproducts, setfinaladdedproducts] = useState([]);
  const [filterDataForCategoryAnalytics, setFilterDataForCategoryAnalytics] = useState();

  const lastIndex = (array) => {
    let i = array.length - 1;
    while (i >= 0 && array[i] === null) {
      i--;
    }
    return i;
  };

  const [sortBy1, setSortBy1] = useState('num_qty_sold');
  const [sortOrder1, setSortOrder1] = useState('desc');

  const [assortmentStatusFilter, setAssortmentStatusFilter] = useState([]);

  const [topMfacLoading, setTopMfacLoading] = useState(false);

  const [isEdit, setIsEdit] = useState(false);

  const handleSave = () => {
    if (finaladdedproducts?.length > 0) {
      const formData = new FormData();
      finaladdedproducts.forEach((item, index) => {
        formData.append(`request_data[${index}][sap_id]`, item.sap_id);
        formData.append(`request_data[${index}][item_name]`, item.item_name);
        formData.append(`request_data[${index}][total_amount]`, item.total_amount);
        formData.append(`request_data[${index}][total_margin]`, item.total_margin);
        formData.append(`request_data[${index}][num_qty_sold]`, item.num_qty_sold);
        formData.append(`request_data[${index}][min_qty]`, item.min_qty);
        formData.append(`request_data[${index}][max_qty]`, item.max_qty);
      });
      formData.append('br_code', selectedRegions[3] ? selectedRegions[3] : '');
      formData.append('zone', selectedRegions[0] ? selectedRegions[0] : '');
      formData.append('state', selectedRegions[1] ? selectedRegions[1] : '');
      formData.append('city', selectedRegions[2] ? selectedRegions[2] : '');
      formData.append('L0', selectedCategories[0] ? selectedCategories[0] : '');
      formData.append('L1', selectedCategories[1] ? selectedCategories[1] : '');
      formData.append('L2', selectedCategories[2] ? selectedCategories[2] : '');
      formData.append('L3', selectedCategories[3] ? selectedCategories[3] : '');
      let configg = {
        method: 'post',
        headers: {
          Accept: 'application/json',
          'Content-Type': 'application/json'
        },
        url: `${consoleState.state.api.BASE_URL}/${consoleState.state.api.APPEND_ASSORTMENT}`,
        data: formData
      };

      axios(configg)
        .then(async (response) => {
          hits_and_misses('recommended');
          console.log(response);
          const productCount = props.finaladdedproducts.length;
          const productWord = productCount === 1 ? 'product' : 'products';
          toast({
            position: 'top-middle',
            title: `${productCount} ${productWord} added to the recommended assortment`,
            status: 'success',
            duration: 3000,
            isClosable: true
          });
          setfinaladdedproducts([]);
        })
        .catch(function () {
          console.log('error');
        });
    }
    setIsEdit(false);
  };

  const [brandCategoryNames, setBrandCategoryNames] = useState([]);
  const [brandStackData, setBrandStackData] = useState([]);
  const [fullData, setFullData] = useState([]);

  const [selectedRegions2, setSelectedRegions2] = useState(Array(levelNames.length).fill(null));

  const [selectedCategories2, setSelectedCategories2] = useState(
    Array(categoryLevelNames.length).fill(null)
  );

  const [inventoryStatus, setInventoryStatus] = useState({});
  const [totalassortmentcount, settotalassortmentcount] = useState(0);
  const [hitsMissesLoading, setHitsMissesLoading] = useState(false);

  const [headers, setHeaders] = useState(
    consoleState.state?.assortmentTable?.headers(chakratheme) || []
  );

  const [totalProductsCount, setTotalProductsCount] = useState(0);

  const _productsCount = Object.keys(consoleState.state?.assortmentTable?.types ?? {}).reduce(
    (acc, type) => {
      acc[type] = 0;
      return acc;
    },
    {}
  );

  const [productsCountByType, setProductsCountByType] = useState(_productsCount);

  const _assortmentTableState = {
    filtersData: {
      filter_type: consoleState.state?.assortmentTable?.defaults.filterData.filter_type || '',
      filter_params: []
    },
    searchData: headers.reduce((acc, header) => {
      if (header.search) acc[header.search_variable] = '';
      return acc;
    }, {}),
    sortData: {
      sort_param: consoleState.state?.assortmentTable?.defaults.sortData.sort_param || '',
      sort_type: consoleState.state?.assortmentTable?.defaults.sortData.sort_type || ''
    }
  };
  const [assortmentTableState, setAssortmentTableState] = useState(_assortmentTableState);
  const hits_and_misses = (hits, nocountflag) => {
    if (!consoleState.state.features.assortmentTable) return;
    setHitsMissesLoading(true);

    let formData = new FormData();
    formData = attachGlobalFilters(formData, consoleState);
    formData = attachTableData(formData, assortmentTableState);

    formData.append('page_no', 1);
    formData.append('counts_flag', nocountflag);

    let config = {
      method: 'post',
      url: `${consoleState.state.api.BASE_URL}${consoleState.state.api.ASSORTMENT}`,
      data: formData,
      cancelToken: source.token
    };
    setInventoryStatus({});
    axios(config)
      .then(async (response) => {
        setFullData(response.data);

        const __productsCount = {};
        Object.keys(consoleState.state.assortmentTable.types).forEach((type) => {
          __productsCount[type] = response.data[`${type}_count`];
        });
        setProductsCountByType(__productsCount);

        set_hits_misses_data(response.data[consoleState.state.assortmentTable.types[hits].apiKey]);
        setTotalProductsCount(response.data[`${hits}_count`]);

        setHitsMissesLoading(false);
        if (response.data.excess_count !== undefined) {
          const newInventoryStatus = {
            excess: response.data.excess_count,
            replenish: response.data.replenish_count,
            optimal: response.data.optimal_count,
            new: response.data.new_count || 0,
            inhand_assortment_width: response.data.inhand_assortment_width,
            inhand_inventory_cost: response.data.inhand_inventory_cost,
            recommended_assortment_width: response.data.recommended_assortment_width,
            recommended_inventory_cost: response.data.recommended_inventory_cost
            // inhand_assortment_width: 22488
            // inhand_inventory_cost: 314915814.55
            // recommended_assortment_width: 32114
            // recommended_inventory_cost: 291988372.2
          };
          setInventoryStatus(newInventoryStatus);
        }
        if (response.data.total_assortment_count !== undefined) {
          settotalassortmentcount(response.data.total_assortment_count);
        }
      })
      .catch(function () {
        if (axios.isCancel()) {
          console.log('Request canceled');
        }
        console.log('error');
        setHitsMissesLoading(false);
      });
  };

  const [salesData, setSalesData] = useState(null);

  const fetchBulkData = (file) => {
    const finalFormData = new FormData();
    finalFormData.append('file', file);
    let config = {
      method: 'post',
      url: `${consoleState.state.api.BASE_URL}/${consoleState.state.api.BULK_ASSORTMENT}`,
      data: finalFormData
    };
    axios(config)
      .then(async (response) => {
        // setBulkData(response.data);
        set_hits_misses_data(response.data);
      })
      .catch(function () {
        console.log('error');
      });
  };
  const [stats, setStats] = useState([]);

  const [alignment] = React.useState('assortment');
  useEffect(() => {
    setHits(alignment);
    setTotalProductsCount(productsCountByType[alignment]);
    setPage1(1);
  }, [alignment]);

  useEffect(() => {
    setSelectedCategories2(selectedCategories);
    setSelectedRegions2(selectedRegions);
  }, [...filterIDs.map((filter) => consoleState.state.globalFilters[filter].selected)]);

  useEffect(() => {
    setPage1(1);
  }, [...filterIDs.map((filter) => consoleState.state.globalFilters[filter].selected)]);

  useEffect(() => {
    // fetchFilters();

    return () => {
      source.cancel('Operation canceled by the user.');
    };
  }, [...filterIDs.map((filter) => consoleState.state.globalFilters[filter].selected)]);

  useEffect(() => {
    fetch_past_sales(setSalesData, consoleState, source.token);
  }, [selectedRegions, selectedCategories]);

  useEffect(() => {
    console.log('assortmentTableState', assortmentTableState);
    hits_and_misses(hits, true);
  }, [
    assortmentTableState.sortData,
    ...filterIDs.map((filter) => consoleState.state.globalFilters[filter].selected),
    assortmentTableState.filtersData,
    assortmentTableState.searchData
  ]);

  useEffect(() => {
    if (!consoleState.state.features.manufacturerCharts) return;

    mfacRevenue(consoleState, setStats, source.token);
    top_brands(
      // selectedRegions,
      // levelNames,
      // selectedCategories,
      // selectedBrands,
      consoleState,
      setHorizontalStackData,
      setBrandStackData,
      setBrandCategoryNames,
      setTopMfacLoading,
      // lastIndex,
      setCategoryNames,
      source.token
    );
  }, [selectedBrands, selectedRegions, selectedCategories]);

  useEffect(() => {
    let formData = new FormData();
    formData = attachGlobalFilters(formData, consoleState);
    setFilterDataForCategoryAnalytics(formData);
  }, [...filterIDs.map((filter) => consoleState.state.globalFilters[filter].selected)]);

  // useEffect(() => {
  //   console.log('FilterDataForCategoryAnalytics', filterDataForCategoryAnalytics);
  // }, [filterDataForCategoryAnalytics]);

  const [hits, setHits] = useState('assortment');

  useEffect(() => {
    if (!consoleState.state.features.assortmentTable) return;
    set_hits_misses_data(fullData[consoleState.state.assortmentTable.types[hits].apiKey]);
    setTotalProductsCount(productsCountByType[hits]);
  }, [hits]);

  const [pinFilters, setPinFilters] = useState(false);

  const [hitmisscsvloading, sethitmisscsvloading] = useState(false);

  const downloadCSV3 = () => {
    sethitmisscsvloading(true);
    let formData = new FormData();

    formData = attachGlobalFilters(formData, consoleState);
    formData = attachTableData(formData, assortmentTableState);

    let config = {
      method: 'post',
      url: `${consoleState.state.api.BASE_URL}${consoleState.state.api.ASSORTMENT_CSV}`,
      data: formData,
      responseType: 'blob'
    };
    axios(config)
      .then(function (response) {
        const csvFile = new Blob([response.data], { type: 'text/csv' });

        if (csvFile) {
          const anchor = document.createElement('a');
          anchor.href = URL.createObjectURL(csvFile);
          if (selectedRegions[selectedRegions.length - 1] === null) {
            anchor.download = `Assortment.csv`;
          } else {
            anchor.download = `Assortment - ${selectedRegions[selectedRegions.length - 1]}.csv`;
          }
          anchor.style.display = 'none';

          document.body.appendChild(anchor);

          anchor.click();

          URL.revokeObjectURL(anchor.href);

          document.body.removeChild(anchor);
        }
        sethitmisscsvloading(false);
      })
      .catch(function () {
        sethitmisscsvloading(false);
        console.log('error');
      });
  };

  const source = axios.CancelToken.source(); // Create a cancel token source

  // const formatNumber = (num) => {
  //   if (String(num).length <= 3) {
  //     return num.toLocaleString();
  //   }

  //   if (String(num).length === 4 || String(num).length === 5) {
  //     return (num / 1000).toFixed(2).toLocaleString('en-US', { minimumFractionDigits: 2 }) + 'K';
  //   } else if (String(num).length === 6 || String(num).length === 7) {
  //     return (num / 100000).toFixed(2).toLocaleString('en-US', { minimumFractionDigits: 2 }) + 'Lk';
  //   } else {
  //     return (
  //       (num / 10000000).toFixed(2).toLocaleString('en-US', { minimumFractionDigits: 2 }) + 'Cr'
  //     );
  //   }
  // };

  const handlePagination = () => {
    if (
      productsCountByType[hits] === hits_misses_data.length ||
      page1 < Math.floor(hits_misses_data.length / 100)
    )
      return;

    let formData = new FormData();

    formData.append('page_no', page1 === 1 ? 2 : Math.floor(page1 / 5) + 2);

    formData = attachGlobalFilters(formData, consoleState);
    formData = attachTableData(formData, assortmentTableState);

    let config = {
      method: 'post',
      url: `${consoleState.state.api.BASE_URL}${consoleState.state.api.ASSORTMENT}`,
      data: formData
    };

    axios(config)
      .then(async (response) => {
        set_hits_misses_data((prevData) => [
          ...prevData,
          ...response.data[consoleState.state.assortmentTable.types[hits].apiKey]
        ]);
        setTotalProductsCount(response.data[`${hits}_count`]);
      })
      .catch(function () {
        console.log('error');
      });
  };

  const capitalizeFirstLetter = (string) => {
    return string.replace(/\b\w/g, (match) => match.toUpperCase());
  };
  const l = ['Excess Products', 'Low Stock Products', 'Optimal Products', 'New Products'];
  const anySelectedFilter = (filter) =>
    consoleState.state.globalFilters[filter].selected.some((f) => f);
  const anySelected = filterIDs.some((filter) => anySelectedFilter(filter));
  return (
    <Container h="100%">
      <Flex direction="column" id="overview">
        <Text
          style={{
            fontSize: '22px',
            fontFamily: 'Poppins',
            fontWeight: 'bold',
            marginTop: '0px'
          }}>
          {consoleState.state.constants.storeAssortment.TITLE}
        </Text>
        <Box
          w="100px"
          h="5px"
          bg={`${chakratheme.colors.primary.main}`}
          borderRadius="3px"
          mt={2}
        />
      </Flex>
      <DrawerFilters
        lastIndex={lastIndex}
        open={props.open}
        setOpen={props.setOpen}
        isCollapsed={props.isCollapsed}
        nonedit={isEdit}
        hits_misses_data={hits_misses_data}
        fetchBulkData={fetchBulkData}
        uploadedFile={uploadedFile}
        setUploadedFile={setUploadedFile}
        pinFilters={pinFilters}
        setPinFilters={setPinFilters}
        categoryLevelNames={categoryLevelNames}
        selectedCategories={selectedCategories}
        setSelectedCategories={setSelectedCategories}
        levelNames={levelNames}
        selectedRegions={selectedRegions}
        setSelectedRegions={setSelectedRegions}
        brandLevelNames={brandLevelNames}
        selectedBrands={selectedBrands}
        setSelectedBrands={setSelectedBrands}
        levelExamples={props.levelExamples}
        setSelectedRegionsdefault={props.setSelectedRegionsdefault}
        selectedRegionsdefault={props.selectedRegionsdefault}
        default={true}
        hideFilters={localStorage.getItem('role') === 'store manager' ? ['region'] : []}
      />

      <Text
        // ml={6}
        mt={3}
        style={{
          color: `${chakratheme.colors.black[400]}`,
          fontSize: '13px',
          fontFamily: 'sans-serif'
        }}>
        Comprehensive insights into product distribution and assortment strategies to elevate your
        merchandising strategy.
      </Text>
      <Flex
        alignItems={'center'}
        style={{
          marginTop: '20px'
        }}>
        <ThemeProvider theme={() => createTheme()}>
          <ButtonJoy
            variant="outlined"
            color="neutral"
            startDecorator={<Tune />}
            onClick={() => props.setOpen(true)}>
            Change filters
          </ButtonJoy>
        </ThemeProvider>
        <Flex
          id="analysis"
          ml={5}
          color={`${chakratheme.colors.gray.main}`}
          style={{
            // backgroundColor: `${chakratheme.colors.gray.lighter}`,
            borderRadius: '5px',
            padding: '7px 20px',
            fontSize: '13px'
          }}
          alignItems={'center'}
          justifyContent={'flex-start'}>
          <HourglassTop style={{ marginRight: '10px' }} />
          <Text fontWeight={'bold'} fontSize="13px">
            Duration of Assortment -
          </Text>
          <Text ml={1} fontWeight={'bold'} fontSize="13px">
            July 25-31, 2023
          </Text>
        </Flex>
      </Flex>
      <Flex
        direction="column"
        w="100%"
        style={{
          border: `1px solid ${chakratheme.colors.gray[500]}`,
          borderRadius: '10px',
          padding: '10px',
          color: `${chakratheme.colors.gray.light}`,
          fontSize: '14px',
          marginTop: '5px'
        }}>
        <Text color="black" fontWeight={'bold'}>
          {anySelected ? ' Showing results for' : 'Showing Global Results. '}{' '}
          {!anySelected ? (
            <span style={{ color: `${chakratheme.colors.black[400]}` }}>
              Change filters to search for a particular region, category and/or brand.
            </span>
          ) : null}
        </Text>

        {filterIDs.map((filter) => {
          if (!anySelectedFilter(filter)) return null;
          return (
            <Flex
              key={filter}
              style={{
                padding: '5px 10px',
                marginTop: '5px',
                borderRadius: '20px',
                backgroundColor: `${chakratheme.colors.gray.lighter}`,
                color: `${chakratheme.colors.gray.dark}`
              }}>
              <Text
                borderRight={`3px solid ${chakratheme.colors.gray[300]}`}
                paddingRight="5px"
                marginRight="10px">
                {capitalizeFirstLetter(filter)}
              </Text>
              {consoleState.state.globalFilters[filter].selected.map((item, index) => {
                return item ? (
                  <Text marginRight={'10px'} key={index}>
                    <span style={{ fontWeight: 'bold', marginLeft: '3px' }}>
                      {consoleState.state.globalFilters[filter].levelNames[index]}
                    </span>{' '}
                    {item}
                  </Text>
                ) : null;
              })}
            </Flex>
          );
        })}
      </Flex>
      <Flex flexDir={'column'} mt={0} w="100%" mb={0} pb="50px">
        <Flex className="header-section"></Flex>

        {consoleState.state.features.assortmentTable ? (
          <ProductsAssortment
            selectedRegions={selectedRegions}
            capitalizeFirstLetter={capitalizeFirstLetter}
            lastIndex={lastIndex}
            levelNames={levelNames}
            isEdit={isEdit}
            alignment={alignment}
            setIsEdit={setIsEdit}
            hits_and_misses={hits_and_misses}
            handleSave={handleSave}
            selectedCategories={selectedCategories}
            hitmisscsvloading={hitmisscsvloading}
            downloadCSV3={downloadCSV3}
            hits_misses_data={hits_misses_data}
            set_hits_misses_data={set_hits_misses_data}
            handlePagination={handlePagination}
            totalProductsCount={totalProductsCount}
            setTotalProductsCount={setTotalProductsCount}
            finaladdedproducts={finaladdedproducts}
            setfinaladdedproducts={setfinaladdedproducts}
            page1={page1}
            hitsMissesLoading={hitsMissesLoading}
            // table state
            assortmentTableState={assortmentTableState}
            setAssortmentTableState={setAssortmentTableState}
            //
            setPage1={setPage1}
            sortBy1={sortBy1}
            setSortBy1={setSortBy1}
            sortOrder1={sortOrder1}
            setSortOrder1={setSortOrder1}
            headers={headers}
            setHeaders={setHeaders}
            fetchBulkData={fetchBulkData}
            uploadedFile={uploadedFile}
            setUploadedFile={setUploadedFile}
            pinFilters={pinFilters}
            setPinFilters={setPinFilters}
            categoryLevelNames={categoryLevelNames}
            selectedCategories2={selectedCategories2}
            setSelectedCategories2={setSelectedCategories2}
            selectedRegions2={selectedRegions2}
            setSelectedRegions2={setSelectedRegions2}
            showCircle={true}
            assortmentStatusFilter={assortmentStatusFilter}
            setAssortmentStatusFilter={setAssortmentStatusFilter}
            // searchData={searchData}
            // setSearchData={setSearchData}
            brandLevelNames={brandLevelNames}
            selectedBrands={selectedBrands}
            setSelectedBrands={setSelectedBrands}
            totalassortmentcount={totalassortmentcount}
            l={l}
            inventoryStatus={inventoryStatus}
          />
        ) : null}
        {consoleState.state.features.manufacturerCharts ? (
          <MfacCharts
            selectedBrands={selectedBrands}
            loading={topMfacLoading}
            // brandData={brandData}
            brandLevelNames={brandLevelNames}
            setSelectedBrands={setSelectedBrands}
            stats={stats}
            formatNumber={formatNumber}
            number_style={number_style}
            horizontalStackData={horizontalStackData}
            brandStackData={brandStackData}
            brandCategoryNames={brandCategoryNames}
            categoryNames={categoryNames}
            salesData={salesData}
            filterDataForCategoryAnalytics={filterDataForCategoryAnalytics}
            hideActionableItems={!consoleState.state.features.actionableItems.display}
          />
        ) : null}
      </Flex>
    </Container>
  );
};

export default AssortmentPlanning;
