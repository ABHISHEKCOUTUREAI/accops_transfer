import { Box, Flex, Text, Button, IconButton, Image, useTheme } from '@chakra-ui/react';
import Container from '../Artifactory/Components/Container/Container';
import DownloadIcon from '@mui/icons-material/Download';
import { Tooltip } from '@mui/material';
import React, { useEffect, useState } from 'react';
import { HourglassTop } from '@mui/icons-material';
// import NestedFilters from '../components/NestedFilters';
// import L0 from '../Static/L0.png';
// import L1 from '../Static/L1.png';
import axios from 'axios';
import L2Assort from '../Containers/Assortment Analysis/L2Assort';
import { CopyBlock, atomOneDark } from 'react-code-blocks';
import { ToggleButton, ToggleButtonGroup } from '@mui/material';
import CircularProgress from '@mui/material/CircularProgress';
import { ThumbDown, ThumbUp, Close, ArrowRightAlt } from '@mui/icons-material';
import { FileUploader } from 'react-drag-drop-files';
import AssortmentTable from '../components/Table';
import { Button as ButtonJoy, ThemeProvider } from '@mui/joy';
import { Tune } from '@mui/icons-material';
import { createTheme } from '@mui/material';
import PropTypes from 'prop-types';
import Typography from '@mui/material/Typography';
import CustomTable from './CustomTable';
import DrawerFilters from './DrawerFilters';
import CSVLogo from '../Static/csvv.jpg';
import fileLogo from '../Static/upload-logo-1.jpg';
// eslint-disable-next-line no-unused-vars
import past from '../Static/past.png';

const jsx = `
Required Schema of CSV
{
    "sap_id":Number (required),
    "br_code":String (required),
    "max_Qty":Number (required),
    "min_Qty":Number (required)
}
`;

function TabPanel(props) {
  const { children, value, index, ...other } = props;

  return (
    <Typography
      component="div"
      role="tabpanel"
      hidden={value !== index}
      id={`scrollable-auto-tabpanel-${index}`}
      aria-labelledby={`scrollable-auto-tab-${index}`}
      {...other}>
      <Box p={3}>{children}</Box>
    </Typography>
  );
}

TabPanel.propTypes = {
  children: PropTypes.node,
  index: PropTypes.any.isRequired,
  value: PropTypes.any.isRequired
};

const levelNames = ['Zone', 'State', 'Distribution Center', 'Store'];

const lastIndex = (array) => {
  let i = array.length - 1;
  while (i >= 0 && array[i] === null) {
    i--;
  }
  return i;
};
const categoryLevelNames = ['L0', 'L1', 'L2', 'L3'];
const brandLevelNames = ['Manufacturer', 'Brand'];
const AssortmentCustom = (props) => {
  const chakratheme = useTheme();
  const [hits_misses_data, set_hits_misses_data] = useState([]);
  const [page1, setPage1] = useState(1);
  const [page2, setPage2] = useState(1);
  const [totalProductsCount, setTotalProductsCount] = useState(0);
  const [totalProductsCounthits, setTotalProductsCounthits] = useState(0);
  const [totalProductsCountmisses, setTotalProductsCountmisses] = useState(0);
  const [regions_nested, setRegionsNested] = useState([]);
  const [categoryNested, setCategoryNested] = useState([]);
  const [uploadedFile, setUploadedFile] = useState(null);
  const [brandData, setBrandData] = useState([]);

  const [sortBy1, setSortBy1] = useState('num_qty_sold');
  const [sortOrder1, setSortOrder1] = useState('desc');
  const [sortBy2, setSortBy2] = useState('probability');
  const [sortOrder2, setSortOrder2] = useState('desc');
  const [load, setLoad] = useState(false);

  const [fullData, setFullData] = useState([]);

  const [selectedRegions, setSelectedRegions] = useState(Array(levelNames.length).fill(null));
  const [selectedCategories, setSelectedCategories] = useState(
    Array(categoryLevelNames.length).fill(null)
  );

  const handlePagination = () => {
    if (
      (hits === true && totalProductsCounthits === hits_misses_data.length) ||
      (hits === true && page1 < Math.floor(hits_misses_data.length / 100))
    ) {
      return;
    }
    if (
      (hits === false && totalProductsCountmisses === hits_misses_data.length) ||
      (hits === false && page1 < Math.floor(hits_misses_data.length / 100))
    ) {
      return;
    }

    const formData = new FormData();
    const lastIndexNonNull = lastIndex(selectedRegions);

    if (lastIndexNonNull != -1)
      formData.append(
        'region_type',
        levelNames[lastIndexNonNull] === 'Store' ? 'Branch' : levelNames[lastIndexNonNull]
      );
    else formData.append('region_type', null);
    if (lastIndexNonNull != -1) formData.append('region_name', selectedRegions[lastIndexNonNull]);
    else formData.append('region_name', null);

    if (selectedCategories[0]) formData.append('L0', selectedCategories[0]);
    if (selectedCategories[1]) formData.append('L1', selectedCategories[1]);
    if (selectedCategories[2]) formData.append('L2', selectedCategories[2]);
    if (selectedCategories[3]) formData.append('L3', selectedCategories[3]);
    // formData.append("page_no", page1+1);
    formData.append('page_no', page1 === 1 ? 2 : Math.floor(page1 / 5) + 2);
    formData.append('sort_param', sortBy1);
    formData.append('sort_type', sortOrder1);
    // formData.append("flag", flag);
    let config = {
      method: 'post',
      url: `${process.env.REACT_APP_API_BASE_URL}/hit-and-miss`,
      data: formData
    };

    axios(config)
      .then(async (response) => {
        // setPage1(page1+1);
        // setFullData(prevData => [...prevData, ...response.data]);
        if (hits === true) {
          set_hits_misses_data((prevData) => [...prevData, ...response.data.hits]);
          setTotalProductsCount(response.data.hit_count);
          // setTotalProductsCounthits(response.data.hit_count);
        } else if (hits === false) {
          set_hits_misses_data((prevData) => [...prevData, ...response.data.misses]);
          setTotalProductsCount(response.data.miss_count);
          // setTotalProductsCountmisses(response.data.miss_count);
        }
      })
      .catch(function () {
        console.log('error');
      });
  };

  const handlePagination2 = () => {
    if (customLength === customData.length || page2 < Math.floor(customData.length / 100)) {
      return;
    }

    const finalFormData = new FormData();
    finalFormData.append('request_csv', uploadedFile);
    const lastIndexNonNull = lastIndex(selectedRegions);
    if (lastIndexNonNull != -1) finalFormData.append('region_type', levelNames[lastIndexNonNull]);
    if (lastIndexNonNull != -1)
      finalFormData.append('region_name', selectedRegions[lastIndexNonNull]);
    if (selectedCategories[0]) finalFormData.append('L0', selectedCategories[0]);
    if (selectedCategories[1]) finalFormData.append('L1', selectedCategories[1]);
    if (selectedCategories[2]) finalFormData.append('L2', selectedCategories[2]);
    if (selectedCategories[3]) finalFormData.append('L3', selectedCategories[3]);
    // finalFormData.append("page_no", page1);
    finalFormData.append('page_no', page2 === 1 ? 2 : Math.floor(page2 / 5) + 2);
    finalFormData.append('sort_param', sortBy2);
    finalFormData.append('sort_type', sortOrder2);
    let config = {
      method: 'post',
      url: `${process.env.REACT_APP_API_BASE_URL}/probability`,
      data: finalFormData
    };
    axios(config)
      .then(async (response) => {
        // setBulkData(response.data);
        // setPage1(page1+1);
        setCustomData((prevData) => [...prevData, ...response.data.data]);
      })
      .catch(function () {
        console.log('error');
      });
  };

  const [hitsMissesLoading, setHitsMissesLoading] = useState(false);
  const hits_and_misses = (hits) => {
    setHitsMissesLoading(true);
    const lastIndexNonNull = lastIndex(selectedRegions);

    const formData = new FormData();
    formData.append('request_csv', uploadedFile);
    if (lastIndexNonNull != -1)
      formData.append(
        'region_type',
        levelNames[lastIndexNonNull] === 'Store' ? 'Branch' : levelNames[lastIndexNonNull]
      );
    else formData.append('region_type', null);
    if (lastIndexNonNull != -1) formData.append('region_name', selectedRegions[lastIndexNonNull]);
    else formData.append('region_name', null);
    if (selectedCategories[0]) formData.append('L0', selectedCategories[0]);
    if (selectedCategories[1]) formData.append('L1', selectedCategories[1]);
    if (selectedCategories[2]) formData.append('L2', selectedCategories[2]);
    if (selectedCategories[3]) formData.append('L3', selectedCategories[3]);
    formData.append('page_no', 1);
    formData.append('sort_param', sortBy1);
    formData.append('sort_type', sortOrder1);

    let config = {
      method: 'post',
      url: `${process.env.REACT_APP_API_BASE_URL}/hit-and-miss`,
      data: formData
    };

    axios(config)
      .then(async (response) => {
        setFullData(response.data);
        if (hits === true) {
          set_hits_misses_data(response.data.hits);
          setTotalProductsCount(response.data.hit_count);
        } else {
          set_hits_misses_data(response.data.misses);
          setTotalProductsCount(response.data.miss_count);
        }
        // setTotalProductsCount(response.data.hit_count);
        setTotalProductsCounthits(response.data.hit_count);
        // setTotalProductsCount(response.data.miss_count);
        setTotalProductsCountmisses(response.data.miss_count);
        setHitsMissesLoading(false);
      })
      .catch(function () {
        console.log('error');
        setHitsMissesLoading(false);
      });
  };

  const [alignment, setAlignment] = React.useState('custom');
  useEffect(() => {
    if (alignment === 'hits') {
      setHits(true);
      setTotalProductsCount(totalProductsCounthits);
      setPage1(1);
    } else if (alignment === 'misses') {
      setHits(false);
      setTotalProductsCount(totalProductsCountmisses);
      setPage1(1);
    }
  }, [alignment]);

  // useEffect(() => {
  //   // const index = lastIndex(selectedRegions);
  //   // const regionName = index === -1 ? null : levelNames[index];
  //   // const regionValue = index === -1 ? null : selectedRegions[index];

  //   // hits_and_misses(hits, true);
  //   // sankeyapi(regionValue, regionName);
  //   // hitmiss_ratio();
  //   if (load) {
  //     top_brands();
  //   }
  //   // if (document.readyState === 'complete') {
  //   //   fetchBulk();
  //   // }
  // }, [selectedRegions, selectedCategories, load]);

  // useEffect(() => {
  //     fetchBulk();
  // }, [sortBy2, sortOrder2, selectedRegions, selectedCategories]);
  const [initialRender, setInitialRender] = useState(true);

  useEffect(() => {
    if (initialRender) {
      setInitialRender(false); // Update the state after the initial render
    } else {
      // Perform fetchBulk on subsequent renders
      fetchBulkData();
    }
  }, [sortBy2, sortOrder2, selectedRegions, selectedCategories]);

  useEffect(() => {
    if (load) {
      hits_and_misses(hits, true);
    }
  }, [sortBy1, sortOrder1, selectedRegions, selectedCategories, load]);

  useEffect(() => {
    if (load) {
      l2l3();
    }
  }, [selectedRegions, load]);

  const [hits, setHits] = useState(true);

  useEffect(() => {
    if (hits === true) {
      set_hits_misses_data(fullData.hits);
      setTotalProductsCount(totalProductsCounthits);
    } else {
      set_hits_misses_data(fullData.misses);
      setTotalProductsCount(totalProductsCountmisses);
    }
  }, [hits]);

  const [selectedBrands, setSelectedBrands] = useState(Array(brandLevelNames.length).fill(null));

  const [pinFilters, setPinFilters] = useState(false);

  // useEffect(() => {
  //   window.addEventListener('scroll', isSticky);
  //   return () => {
  //     window.removeEventListener('scroll', isSticky);
  //   };
  // });

  // /* Method that will fix header after a specific scrollable */
  // const isSticky = () => {
  //   const filler = document.querySelector('.filler');
  //   const header = document.querySelector('.header-section');
  //   const scrollTop = window.scrollY;
  //   if (pinFilters) {
  //     scrollTop >= 150 ? header.classList.add('is-sticky') : header.classList.remove('is-sticky');
  //     scrollTop >= 150 ? filler.classList.remove('no-display') : filler.classList.add('no-display');
  //   }
  // };
  // useEffect(() => {
  //   const filler = document.querySelector('.filler');
  //   if (pinFilters) {
  //     const header = document.querySelector('.header-section');
  //     const scrollTop = window.scrollY;
  //     if (scrollTop >= 150) header.classList.add('is-sticky');
  //     if (scrollTop >= 150) filler.classList.remove('no-display');
  //   } else {
  //     const header = document.querySelector('.header-section');
  //     header.classList.remove('is-sticky');
  //     filler.classList.add('no-display');
  //   }
  // }, [pinFilters]);

  const [customLength, setCustomLength] = useState();
  const [customLoader, setCustomLoader] = useState(false);

  const fetchBulkData = () => {
    // url is couture/assortment/bulk-assortment
    if (uploadedFile) {
      setCustomLoader(true);
    }

    // setCustomLoader(true);

    const finalFormData = new FormData();
    // setCustomFile(file);

    finalFormData.append('request_csv', uploadedFile);
    const lastIndexNonNull = lastIndex(selectedRegions);
    if (lastIndexNonNull != -1) finalFormData.append('region_type', levelNames[lastIndexNonNull]);
    else finalFormData.append('region_type', null);
    if (lastIndexNonNull != -1)
      finalFormData.append('region_name', selectedRegions[lastIndexNonNull]);
    else finalFormData.append('region_name', null);
    if (selectedCategories[0]) finalFormData.append('L0', selectedCategories[0]);
    if (selectedCategories[1]) finalFormData.append('L1', selectedCategories[1]);
    if (selectedCategories[2]) finalFormData.append('L2', selectedCategories[2]);
    if (selectedCategories[3]) finalFormData.append('L3', selectedCategories[3]);
    finalFormData.append('page_no', 1);
    finalFormData.append('sort_param', sortBy2);
    finalFormData.append('sort_type', sortOrder2);
    var config = {
      method: 'post',
      url: `${process.env.REACT_APP_API_BASE_URL}/probability`,
      data: finalFormData
    };
    axios(config)
      .then(async (response) => {
        // setBulkData(response.data);
        setCustomData(response.data.data);
        setCustomLength(response.data.total_count);
        setLoad(true);
        setCustomLoader(false);
      })
      .catch(function () {
        console.log('error');
      });
  };

  // const fetchBulk = () => {
  //   // url is couture/assortment/bulk-assortment
  //   setCustomLoader(true);
  //   const finalFormData = new FormData();

  //   finalFormData.append("request_csv", customFile);
  //   const lastIndexNonNull = lastIndex(selectedRegions);
  // if (lastIndexNonNull != -1)
  //   finalFormData.append("region_type", levelNames[lastIndexNonNull]);
  // if (lastIndexNonNull != -1)
  //   finalFormData.append("region_name", selectedRegions[lastIndexNonNull]);
  // if (selectedCategories[0]) finalFormData.append("L0", selectedCategories[0]);
  // if (selectedCategories[1]) finalFormData.append("L1", selectedCategories[1]);
  // if (selectedCategories[2]) finalFormData.append("L2", selectedCategories[2]);
  // if (selectedCategories[3]) finalFormData.append("L3", selectedCategories[3]);
  //   finalFormData.append("page_no", 1);
  // finalFormData.append("sort_param", sortBy2);
  // finalFormData.append("sort_type", sortOrder2);

  //   var config = {
  //     method: "post",
  //     url: `${process.env.REACT_APP_API_BASE_URL}/probability`,
  //     data: finalFormData,
  //   };
  //   axios(config)
  //     .then(async (response) => {
  //       // setBulkData(response.data);
  //       setCustomData(response.data.data);
  //       setCustomLoader(false);
  //     })
  //     .catch(function () {
  //       console.log("error");
  //     });
  // };

  const [l2missdata, setl2missData] = useState([]);
  const [l2data, setl2data] = useState([]);
  const [l3missdata, setl3missData] = useState([]);
  const [l3data, setl3data] = useState([]);
  const [customData, setCustomData] = useState([]);

  const [l2l3loading, setl2l3loading] = useState(false);

  const l2l3 = () => {
    setl2l3loading(true);
    const lastIndexNonNull = lastIndex(selectedRegions);

    const formData = new FormData();
    formData.append('request_csv', uploadedFile);
    if (lastIndexNonNull != -1)
      formData.append(
        'region_type',
        levelNames[lastIndexNonNull] === 'Store' ? 'Branch' : levelNames[lastIndexNonNull]
      );
    else formData.append('region_type', null);
    if (lastIndexNonNull != -1) formData.append('region_name', selectedRegions[lastIndexNonNull]);
    else formData.append('region_name', null);
    let config = {
      method: 'post',
      url: `${process.env.REACT_APP_API_BASE_URL}/l2l3`,
      data: formData
    };
    axios(config)
      .then(async (response) => {
        setl2missData(response.data.l2_assort_dist_miss);
        setl3missData(response.data.l3_assort_dist_miss);
        setl2data(response.data.l2_assort_comp);
        setl3data(response.data.l3_assort_comp);
        setl2l3loading(false);
      })
      .catch(function () {
        console.log('error');
        setl2l3loading(false);
      });
  };

  const [downloadLoad4, setDownloadLoad4] = useState(false);

  const downloadCustomCSV = () => {
    if (uploadedFile == null) {
      alert('Please upload CSV file before downloading');
      return;
    }
    if (uploadedFile) {
      setDownloadLoad4(true);
    }
    const formData = new FormData();
    formData.append('request_csv', uploadedFile);
    const lastIndexNonNull = lastIndex(selectedRegions);

    if (lastIndexNonNull != -1)
      formData.append(
        'region_type',
        levelNames[lastIndexNonNull] === 'Store' ? 'Branch' : levelNames[lastIndexNonNull]
      );
    else formData.append('region_type', null);
    if (lastIndexNonNull != -1) formData.append('region_name', selectedRegions[lastIndexNonNull]);
    else formData.append('region_name', null);

    if (selectedCategories[0]) formData.append('L0', selectedCategories[0]);
    if (selectedCategories[1]) formData.append('L1', selectedCategories[1]);
    if (selectedCategories[2]) formData.append('L2', selectedCategories[2]);
    if (selectedCategories[3]) formData.append('L3', selectedCategories[3]);
    formData.append('sort_param', sortBy2);
    formData.append('sort_type', sortOrder2);
    let config = {
      method: 'post',
      url: `${process.env.REACT_APP_API_BASE_URL}/probability-csv`,
      data: formData,
      responseType: 'blob'
    };
    axios(config)
      .then(function (response) {
        const csvFile = new Blob([response.data], { type: 'text/csv' });

        if (csvFile) {
          const anchor = document.createElement('a');
          anchor.href = URL.createObjectURL(csvFile);
          anchor.download = 'Products.csv';
          anchor.style.display = 'none';

          document.body.appendChild(anchor);

          anchor.click();

          URL.revokeObjectURL(anchor.href);

          document.body.removeChild(anchor);
        }
        setDownloadLoad4(false);
      })
      .catch(function () {
        console.log('error');
      });
  };

  const [downloadLoad3, setDownloadLoad3] = useState(false);

  const downloadCSV3 = () => {
    setDownloadLoad3(true);
    const formData = new FormData();
    const lastIndexNonNull = lastIndex(selectedRegions);
    formData.append('request_csv', uploadedFile);

    if (lastIndexNonNull != -1)
      formData.append(
        'region_type',
        levelNames[lastIndexNonNull] === 'Store' ? 'Branch' : levelNames[lastIndexNonNull]
      );
    else formData.append('region_type', null);
    if (lastIndexNonNull != -1) formData.append('region_name', selectedRegions[lastIndexNonNull]);
    else formData.append('region_name', null);

    if (selectedCategories[0]) formData.append('L0', selectedCategories[0]);
    if (selectedCategories[1]) formData.append('L1', selectedCategories[1]);
    if (selectedCategories[2]) formData.append('L2', selectedCategories[2]);
    if (selectedCategories[3]) formData.append('L3', selectedCategories[3]);
    formData.append('sort_param', sortBy1);
    formData.append('sort_type', sortOrder1);
    formData.append('csv_flag', alignment);
    let config = {
      method: 'post',
      url: `${process.env.REACT_APP_API_BASE_URL}/hit-miss-csv`,
      data: formData,
      responseType: 'blob'
    };
    axios(config)
      .then(function (response) {
        const csvFile = new Blob([response.data], { type: 'text/csv' });

        if (csvFile) {
          const anchor = document.createElement('a');
          anchor.href = URL.createObjectURL(csvFile);
          anchor.download = 'Products.csv';
          anchor.style.display = 'none';

          document.body.appendChild(anchor);

          anchor.click();

          URL.revokeObjectURL(anchor.href);

          document.body.removeChild(anchor);
        }
        setDownloadLoad3(false);
      })
      .catch(function () {
        console.log('error');
      });
  };

  // const lastapi = () => {
  //   if(l3data && l3missdata && l2data && l2missdata && hits_misses_data)
  //   {
  //     hits_and_misses(hits, false);
  //   }
  // }

  // useEffect(() => {
  //   lastapi();
  // }, []);

  const [filterCount, setFilterCount] = useState();
  // useEffect(() => {
  //   var configStat = {
  //     method: 'get',
  //     url: `${process.env.REACT_APP_API_BASE_URL}/fetch-filters`
  //   };
  //   axios(configStat)
  //     .then(async (response) => {
  //       setRegionsNested(response.data.location);
  //       setCategoryNested(response.data.category);
  //       setBrandData(response.data.mfac);
  //       setFilterCount(response.data.filters_count);
  //     })
  //     .catch(function () {
  //       console.log('error');
  //     });
  // }, []);

  const fetchFilters = () => {
    const formData = new FormData();
    const lastIndexNonNull = lastIndex(selectedRegions);
    formData.append('request_csv', uploadedFile);

    if (lastIndexNonNull != -1)
      formData.append(
        'region_type',
        levelNames[lastIndexNonNull] === 'Store' ? 'Branch' : levelNames[lastIndexNonNull]
      );
    else formData.append('region_type', null);
    if (lastIndexNonNull != -1) formData.append('region_name', selectedRegions[lastIndexNonNull]);
    else formData.append('region_name', null);
    if (selectedBrands[0]) formData.append('mfac_name', selectedBrands[0]);
    if (selectedBrands[1]) formData.append('brand_name', selectedBrands[1]);
    if (selectedCategories[0]) formData.append('L0', selectedCategories[0]);
    if (selectedCategories[1]) formData.append('L1', selectedCategories[1]);
    if (selectedCategories[2]) formData.append('L2', selectedCategories[2]);
    if (selectedCategories[3]) formData.append('L3', selectedCategories[3]);
    let configStat = {
      method: 'post',
      url: `${process.env.REACT_APP_API_BASE_URL}/fetch-filters`,
      data: formData
    };
    axios(configStat)
      .then(async (response) => {
        setRegionsNested(response.data.location);
        setCategoryNested(response.data.category);
        setBrandData(response.data.mfac);
        setFilterCount(response.data.filters_count);
      })
      .catch(function () {
        console.log('error');
      });
  };

  useEffect(() => {
    setPage1(1);
  }, [selectedRegions, selectedCategories, selectedBrands]);

  useEffect(() => {
    if (load) {
      fetchFilters();
    }
  }, [selectedRegions, selectedBrands, selectedCategories, load]);

  // useEffect(() => {
  //   if (load) {
  //     top_brands();
  //   }
  // }, [selectedBrands, load]);

  return (
    <Container w="100%">
      {!load && (
        <Flex w="100%" justifyContent={'space-between'}>
          <Box>
            <Flex direction="column" id="overview">
              <Text
                style={{
                  fontSize: '22px',
                  fontFamily: 'Poppins',
                  fontWeight: 'bold',
                  marginTop: '0px'
                }}>
                Catalogue Assessment
              </Text>
              <Box
                w="100px"
                h="5px"
                bg={`${chakratheme.colors.primary.main}`}
                borderRadius="3px"
                mt={2}
              />
            </Flex>
            <DrawerFilters
              open={props.open}
              setOpen={props.setOpen}
              hits_misses_data={hits_misses_data}
              fetchBulkData={fetchBulkData}
              uploadedFile={uploadedFile}
              setUploadedFile={setUploadedFile}
              pinFilters={pinFilters}
              setPinFilters={setPinFilters}
              categoryNested={categoryNested}
              categoryLevelNames={categoryLevelNames}
              selectedCategories={selectedCategories}
              setSelectedCategories={setSelectedCategories}
              regions_nested={regions_nested}
              levelNames={levelNames}
              selectedRegions={selectedRegions}
              setSelectedRegions={setSelectedRegions}
              brandData={brandData}
              brandLevelNames={brandLevelNames}
              selectedBrands={selectedBrands}
              setSelectedBrands={setSelectedBrands}
              filterCount={filterCount}
              levelExamples={props.levelExamples}
              hideFilters={localStorage.getItem('role') === 'store manager' ? ['region'] : []}
            />
            <Text
              mt={3}
              style={{
                color: `${chakratheme.colors.black[400]}`,
                fontSize: '13px',
                fontFamily: 'sans-serif'
              }}>
              Probability insights for each product&apos;s likelihood of getting sold.
            </Text>
            <Text
              textAlign={'start'}
              ml={6}
              style={{
                marginTop: '75px',
                fontSize: '16px'
              }}>
              {' '}
              Visualise the Probability of a product getting sold by uploading a CSV with given
              Schema below.
            </Text>
            {/* <Text
              textAlign={'start'}
              mt={4}
              style={{
                fontSize: '19px'
              }}>
              {' '}
              Visualise the Probability of a product getting sold by uploading a CSV with given
              Schema below.
            </Text> */}
            <Box ml={6} style={{ marginTop: '50px' }}>
              <Box
                sx={{
                  width: 800,
                  bgcolor: 'background.paper',
                  boxShadow: '0 2px 10px rgba(0, 0, 0, 0.2)',
                  borderRadius: 3,
                  marginTop: '30px',
                  padding: '20px 10px',
                  display: 'flex',
                  flexDirection: 'column',
                  alignItems: 'center'
                }}>
                <Flex direction="row" w="100%">
                  <Flex
                    flex="1"
                    h="100%"
                    direction={'column'}
                    alignItems={'center'}
                    justifyContent={'center'}
                    position={'relative'}
                    style={{
                      borderRight: `1px solid ${chakratheme.colors.gray.light}`
                    }}>
                    {uploadedFile ? (
                      <IconButton
                        position="absolute"
                        top="0"
                        right="9"
                        borderRadius="50%"
                        bg="gray.200"
                        zIndex={1000}
                        color="black"
                        icon={<Close style={{ transform: 'scale(0.8)' }} />}
                        onClick={(event) => {
                          event.stopPropagation();
                          event.preventDefault();
                          setUploadedFile(null);
                        }}></IconButton>
                    ) : null}
                    <FileUploader
                      multiple={false}
                      handleChange={(e) => {
                        setUploadedFile(e);
                      }}
                      name="file"
                      types={['csv']}
                      label="Upload or drop two CSV files here">
                      <Box
                        style={{
                          width: '300px',
                          height: '200px',
                          // position: 'relative',
                          borderRadius: '20px',
                          backgroundColor: `${chakratheme.colors.gray.lighter}`,
                          border: `1px dashed ${chakratheme.colors.gray.light}`
                        }}>
                        <Flex
                          w="100%"
                          h="100%"
                          direction={'column'}
                          justifyContent={'center'}
                          alignItems={'center'}>
                          {uploadedFile ? (
                            <Image src={CSVLogo} w="100px" />
                          ) : (
                            <Image src={fileLogo} w="100px" />
                          )}

                          {uploadedFile ? (
                            <Text
                              color="blue"
                              cursor="pointer"
                              mt={4}
                              fontSize="18px"
                              onClick={() => {
                                // window.open(props.uploadedFile.fileUrl);
                                // open selected csv file in windows
                                window.open(URL.createObjectURL(uploadedFile));
                              }}>
                              {uploadedFile.name}
                            </Text>
                          ) : (
                            <Text mt={4} color={`${chakratheme.colors.gray.light}`} fontSize="13px">
                              Drag and Drop A CSV File
                            </Text>
                          )}
                        </Flex>
                      </Box>
                    </FileUploader>
                  </Flex>
                  <Flex flex="1" h="100%" justifyContent={'center'} alignItems={'center'}>
                    <Box>
                      {/* <Text mb={5} fontSize="16px" fontWeight="bold" lineHeight="1.4">
                      Required Schema of CSV
                    </Text> */}
                      <CopyBlock
                        language={'json'}
                        showLineNumbers={false}
                        text={jsx}
                        theme={atomOneDark}
                      />
                      <Text
                        mt={2}
                        fontSize="14px"
                        color="gray.600"
                        fontStyle="italic"
                        fontWeight="medium"
                        lineHeight="1.4">
                        * Multiple store codes (br_code) can be uploaded.
                      </Text>
                    </Box>
                  </Flex>
                </Flex>
                <Flex w="100%" justifyContent={'center'} alignItems={'center'}>
                  {uploadedFile && (
                    <Button
                      mt={3}
                      ml={3}
                      _hover={{
                        backgroundColor: `${chakratheme.colors.primary.main}`, // Adjust the color as needed
                        boxShadow: `0 0 20px 0 ${chakratheme.colors.shadow}`
                      }}
                      style={{
                        backgroundColor: `${chakratheme.colors.primary.main}`,
                        color: 'white',
                        cursor: 'pointer',
                        // padding: '10px',
                        borderRadius: '20px',
                        marginBottom: '5px',
                        boxShadow: `0 0 20px 0 ${chakratheme.colors.shadow}`,
                        fontWeight: 'bold',
                        padding: '10px 30px'
                        // marginRight: "20px",
                      }}
                      rightIcon={<ArrowRightAlt />}
                      onClick={() => {
                        fetchBulkData(uploadedFile);
                      }}>
                      Analyse uploaded data
                    </Button>
                  )}
                </Flex>
              </Box>
            </Box>
          </Box>
          <Image src={past}></Image>
        </Flex>
      )}
      {load && (
        <Box>
          <Text
            textAlign={'start'}
            mt={4}
            style={{
              fontSize: '22px',
              fontWeight: 'bold'
            }}>
            {' '}
            Custom Recommendation Analysis
          </Text>
          <Flex
            alignItems={'center'}
            style={{
              marginTop: '20px'
            }}>
            <ThemeProvider theme={() => createTheme()}>
              <ButtonJoy
                variant="outlined"
                color="neutral"
                startDecorator={<Tune />}
                onClick={() => props.setOpen(true)}>
                Change filters
              </ButtonJoy>
            </ThemeProvider>
            <Flex
              id="analysis"
              ml={5}
              color={`${chakratheme.colors.gray.main}`}
              style={{
                backgroundColor: `${chakratheme.colors.gray.lighter}`,
                borderRadius: '5px',
                padding: '7px 20px',
                fontSize: '13px'
              }}
              justifyContent={'flex-start'}>
              {/* <HourglassTop style={{ marginRight: '10px' }} /> */}
              <Text fontWeight={'bold'} fontSize="13px">
                Duration of Assortment -
              </Text>
              <Text ml={1} fontWeight={'bold'} fontSize="13px">
                July 25-31, 2023
              </Text>
            </Flex>
          </Flex>
          <Flex flexDir={'column'} mt={4} w="99%" mb={50}>
            <div
              className="filler no-display"
              style={{
                height: '400px',
                width: '100%'
              }}></div>
            <Flex
              p="3"
              id="analysis"
              w="35%"
              mt={10}
              color={`${chakratheme.colors.primary.main}`}
              style={{
                borderRadius: '20px',
                padding: '10px 0 10px 0px'
              }}
              justifyContent={'flex-start'}>
              <HourglassTop style={{ marginRight: '10px' }} />
              <Text fontWeight={'bold'} fontSize="14px">
                Duration of Assortment -
              </Text>
              <Text ml={1} fontWeight={'bold'} fontSize="14px">
                July 25-31, 2023
              </Text>
            </Flex>
            <Flex mt={4} w="100%" h="100%">
              <Box flex="7">
                <Text mb={3} fontWeight={900} fontSize="19px" textAlign="left">
                  Products Assortment
                </Text>
                <Box>
                  <Flex
                    style={{ cursor: 'pointer' }}
                    justifyContent="space-between"
                    alignItems={'center'}
                    marginTop="20px"
                    mb={6}>
                    <Flex>
                      <ToggleButtonGroup
                        sx={{
                          marginRight: '10px',
                          '& .MuiToggleButton-root ': {
                            color: `${chakratheme.colors.primary.main}`,
                            backgroundColor: 'white',
                            borderRadius: '30px',
                            boxShadow: `0 0 20px 0 ${chakratheme.colors.shadow}`
                          },
                          '& .MuiToggleButton-root.Mui-selected, & .MuiToggleButton-root.Mui-selected:hover':
                            {
                              color: 'white',
                              backgroundColor: `${chakratheme.colors.primary.main}`
                            }
                        }}
                        value={alignment}
                        exclusive
                        onChange={(event, newAlignment) => {
                          if (newAlignment == null) return;
                          setAlignment(newAlignment);
                        }}
                        aria-label="text alignment">
                        <ToggleButton value="custom" aria-label="left aligned">
                          <Tooltip title="" placement="bottom">
                            Custom Recommendation Analysis
                          </Tooltip>
                        </ToggleButton>
                      </ToggleButtonGroup>
                      <ToggleButtonGroup
                        sx={{
                          marginRight: '10px',
                          '& .MuiToggleButton-root ': {
                            color: `${chakratheme.colors.primary.main}`,
                            backgroundColor: 'white',
                            borderRadius: '30px',
                            boxShadow: `0 0 20px 0 ${chakratheme.colors.shadow}`
                          },
                          '& .MuiToggleButton-root.Mui-selected': {
                            color: 'white',
                            backgroundColor: `${chakratheme.colors.primary.main}`
                          }
                        }}
                        value={alignment}
                        exclusive
                        onChange={(event, newAlignment) => {
                          if (newAlignment == null) return;
                          setAlignment(newAlignment);
                        }}
                        aria-label="text alignment">
                        <ToggleButton value="hits" aria-label="left aligned">
                          <ThumbUp style={{ marginRight: '10px' }} />
                          <Tooltip
                            title="Products part of Assortment list and sold in target period."
                            placement="bottom">
                            Hits
                          </Tooltip>
                        </ToggleButton>
                        <ToggleButton value="misses" aria-label="justified">
                          <ThumbDown style={{ marginRight: '10px' }} />{' '}
                          <Tooltip
                            title="Products not part of Assortment list but sold in target period."
                            placement="bottom">
                            Misses
                          </Tooltip>
                        </ToggleButton>
                      </ToggleButtonGroup>
                    </Flex>
                    <Flex>
                      <Text marginTop="15px">{downloadLoad3 && 'Downloading...'}</Text>
                      <Text marginTop="15px">{downloadLoad4 && 'Downloading 1000 rows...'}</Text>
                      <IconButton
                        variant="contained"
                        // className={classes.button}
                        sx={{
                          cursor: 'pointer',
                          backgroundColor: 'white',
                          color: `${chakratheme.colors.primary.main}`,
                          //marginTop: isEdit === true ? '20px' : '17px',
                          transition: 'color 0.1s',
                          //marginRight: '30px',
                          boxShadow: `0 0 20px 0 ${chakratheme.colors.shadow}`,
                          borderRadius: '50px',
                          width: '35px',
                          height: '35px',
                          '&:hover': {
                            backgroundColor: `${chakratheme.colors.primary.main}`,
                            color: 'white'
                          }
                        }}
                        onClick={() => {
                          alignment === 'custom' ? downloadCustomCSV() : downloadCSV3();
                        }}
                        // onMouseOver={handleMouseOver}
                        // onMouseOut={handleMouseOut}
                      >
                        <DownloadIcon sx={{ fontSize: '22px' }} />
                      </IconButton>
                    </Flex>
                  </Flex>
                  {alignment === 'custom' ? (
                    customData && customData.length > 0 ? (
                      <CustomTable
                        loading={customLoader}
                        data={customData && customData}
                        handlePagination={handlePagination2}
                        totalProductsCount={customLength}
                        page={page2}
                        setPage={setPage2}
                        sortBy={sortBy2}
                        setSortBy={setSortBy2}
                        sortOrder={sortOrder2}
                        setSortOrder={setSortOrder2}
                        headers={[
                          {
                            name: 'Product SAP',
                            id: 'sap_id',
                            sort: '',
                            colSpan: 2
                          },
                          {
                            name: 'Item Name',
                            id: 'item_name',
                            sort: '',
                            colSpan: 3
                          },
                          {
                            name: 'Barcode',
                            id: 'br_code',
                            sort: '',
                            colSpan: 3,
                            type: 'text'
                          },
                          {
                            name: 'Probability',
                            id: 'probability',
                            sort: 'desc',
                            colSpan: 4
                          }
                        ]}
                      />
                    ) : customLoader ? (
                      <Box
                        sx={{
                          display: 'flex',
                          justifyContent: 'center',
                          alignItems: 'center',
                          height: '50vh'
                        }}>
                        <CircularProgress color="inherit" />
                      </Box>
                    ) : (
                      <div
                        style={{
                          textAlign: 'center',
                          marginTop: '20px',
                          fontSize: '18px',
                          color: `${chakratheme.colors.black[600]}`
                        }}>
                        Upload a CSV above to get Custom Assortment Analysis
                      </div>
                    )
                  ) : (
                    <AssortmentTable
                      loading={hitsMissesLoading}
                      data={hits_misses_data}
                      handlePagination={handlePagination}
                      totalProductsCount={totalProductsCount}
                      page={page1}
                      setPage={setPage1}
                      sortBy={sortBy1}
                      setSortBy={setSortBy1}
                      sortOrder={sortOrder1}
                      setSortOrder={setSortOrder1}
                      headers={[
                        {
                          name: 'Product SAP',
                          id: 'sap_id',
                          sort: '',
                          colSpan: 2
                        },
                        {
                          name: 'Item Name',
                          id: 'item_name',
                          sort: '',
                          colSpan: 3
                        },
                        {
                          name: 'Barcode',
                          id: 'br_code',
                          sort: '',
                          colSpan: 3,
                          type: 'text'
                        },
                        {
                          name: 'Probability',
                          id: 'probability',
                          sort: 'desc',
                          colSpan: 4
                        }
                      ]}
                    />
                  )}
                </Box>
              </Box>
            </Flex>
            {/* <Flex w="100%">
              <TopBrands
                loading={topMfacLoading}
                categoryNames={categoryNames1}
                categories={categories}
                values1={values1}
                values2={values2}
                categories2={categories2}
                categories3={categories3}
                values3={values3}
                categories4={categories4}
                values4={values4}
                categories5={categories5}
                values5={values5}
                categories6={categories6}
                values6={values6}
                categories7={categories7}
                values7={values7}
                categories8={categories8}
                values8={values8}
                categories9={categories9}
                values9={values9}
                categories10={categories10}
                values10={values10}></TopBrands>
            </Flex> */}
            <Box w="100%">
              <L2Assort
                loading={l2l3loading}
                l2data={l2data}
                l2missdata={l2missdata}
                l3data={l3data}
                l3missdata={l3missdata}></L2Assort>
            </Box>
          </Flex>
        </Box>
      )}
    </Container>
  );
};

export default AssortmentCustom;
