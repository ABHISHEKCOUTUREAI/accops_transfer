import { useContext, useEffect, useState } from 'react';
import { LocationContext } from '../Contexts/LocationContext';
import {
  Box,
  Button,
  Flex,
  Menu,
  MenuButton,
  MenuItemOption,
  MenuList,
  Spacer,
  Text,
  useTheme
} from '@chakra-ui/react';
import { ChevronDownIcon } from '@chakra-ui/icons';
import { attachGlobalFilters } from '../Utils/misc';
import axios from 'axios';
import PieeChart from '../Artifactory/Charts/PieChart';

const AssortmentComposition = () => {
  const chakratheme = useTheme();
  const { consoleState } = useContext(LocationContext);
  const [category, setCategory] = useState('sbu');
  const [data, setData] = useState([]);
  const categoryList = consoleState.state.features.assortmentComposition.categoryList;

  const fetchAssortmentComposition = (_category) => {
    let formData = new FormData();
    formData = attachGlobalFilters(formData, consoleState);
    formData.append('category', _category);

    let config = {
      method: 'post',
      url: `${consoleState.state.api.BASE_URL}${consoleState.state.api.ASSORTMENT_COMPOSITION}`,
      data: formData
    };

    axios(config)
      .then(async (response) => {
        console.log('assortment composition response', response.data);
        setData(response.data[category]);
      })
      .catch(function () {
        console.log('error');
        setData([]);
      });
  };
  useEffect(() => {
    fetchAssortmentComposition(category);
  }, [category, consoleState.state.globalFilters.region.selected]);

  return (
    <Box w="100%" mt="5">
      {' '}
      <Flex
        mr="20px"
        width="50%"
        direction="column"
        padding="20px"
        style={{
          boxShadow: `0 0 20px 0 ${chakratheme.colors.shadow}`,
          borderRadius: '20px'
        }}>
        <Flex justifyContent={'center'} alignItems="center">
          <Text
            style={{
              fontFamily: 'Poppins',
              fontWeight: 'bold'
            }}>
            {'Assortment Composition (Top 10)'}
            <span style={{ color: `${chakratheme.colors.gray.light}`, fontWeight: 'normal' }}>
              {category} wise
            </span>
          </Text>
          <Spacer />
          <Menu matchWidth={true}>
            <MenuButton
              as={Button}
              sx={{
                display: 'flex',
                width: '100px',
                alignItems: 'center',
                backgroundColor: `${chakratheme.colors.gray.lighter}`,
                borderRadius: '20px',
                padding: '5px 10px'
              }}
              // leftIcon={view === 'module' ? <ViewModule /> : <ViewList />}
              rightIcon={<ChevronDownIcon color={`${chakratheme.colors.gray.darker}`} />}>
              <Text color={`${chakratheme.colors.gray.darker}`} fontSize={'12px'}>
                {' '}
                {category}{' '}
              </Text>
            </MenuButton>
            <MenuList
              alignItems={'center'}
              onMouseEnter={(e) => {
                e.stopPropagation();
              }}
              zIndex="100"
              fontSize={'12px'}
              borderRadius={'10px'}
              paddingTop="10px"
              paddingBottom="10px"
              backgroundColor={'white'}
              boxShadow={`0 0 10px 0 ${chakratheme.colors.shadow}`}>
              {categoryList.map((_category) => (
                <MenuItemOption
                  cursor="pointer"
                  _hover={{
                    backgroundColor: `${chakratheme.colors.gray[300]}`
                  }}
                  key={_category}
                  value={_category}
                  onClick={(e) => {
                    e.stopPropagation();
                    setCategory(_category);
                  }}>
                  {_category}
                </MenuItemOption>
              ))}
            </MenuList>
          </Menu>
        </Flex>
        <PieeChart
          label={category}
          value={consoleState.state.features.assortmentComposition.apiValueKey}
          data={data}
        />
      </Flex>
    </Box>
  );
};
export default AssortmentComposition;
