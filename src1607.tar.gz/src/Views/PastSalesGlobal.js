import { Box, Flex, Text } from '@chakra-ui/react';
import React, { useEffect, useState } from 'react';
import ReactApexChart from 'react-apexcharts';
const fullMonthNameToIndexStartingWithZero = {
  January: 0,
  February: 1,
  March: 2,
  April: 3,
  May: 4,
  June: 5,
  July: 6,
  August: 7,
  September: 8,
  October: 9,
  November: 10,
  December: 11
};

const LineChart = (props) => {
  const sales_data = props.data;
  const sortedData = Object.keys(sales_data)
    .map((key) => {
      return {
        date: new Date(
          key.split(' ')[1],
          fullMonthNameToIndexStartingWithZero[key.split(' ')[0]],
          1
        ),
        value: sales_data[key]
      };
    })
    .sort((a, b) => a.date - b.date);
  const _series = Object.keys(sortedData[0].value)
    .sort((a, b) => sortedData[0].value[a] - sortedData[0].value[b])
    .map((key) => {
      return {
        name: key,
        data: sortedData.map((item) => [item.date.getTime(), item.value[key]])
      };
    });
  console.log('sales', _series);
  const duration = props.duration;
  const _dataAll = _series[0].data.map((item, index) => {
    return [
      item[0],
      _series.reduce((acc, _item) => {
        return acc + _item.data[index][1];
      }, 0)
    ];
  });
  // sum all the values for each month
  const [series, setSeries] = useState([
    {
      name: props.name,
      data: _dataAll.slice(_series[0].data.length - duration - 1, _series[0].data.length)
    }
  ]);

  const state = {
    // series: series,
    options: {
      chart: {
        type: 'line',
        height: 150,
        //   stacked: true,
        events: {
          selection: function () {}
        },
        toolbar: {
          show: false // Hide toolbar icons
        },
        zoom: {
          enabled: false // Disable zooming
        }
      },
      colors: ['#001F3F', '#005B96', '#4D94DB', '#71B2E5', '#93C8EF'],
      dataLabels: {
        enabled: false
      },
      stroke: {
        curve: 'smooth'
      },
      grid: {
        show: false
      },

      // legend: {
      //   position: 'top',
      //   horizontalAlign: 'left'
      // },
      xaxis: {
        type: 'datetime'
      },
      yaxis: {
        //   show: false,
        labels: {
          formatter: function (val) {
            return val + 'k';
          }
        }
      }
    }
  };
  useEffect(() => {
    setSeries([
      {
        name: props.name,
        data: _dataAll.slice(_series[0].data.length - duration - 1, _series[0].data.length)
      }
    ]);
  }, [props.duration]);

  return (
    <div id="chart">
      <ReactApexChart options={state.options} series={series.reverse()} type="area" height={350} />
    </div>
  );
};

const PastSalesGlobal = (props) => {
  return (
    <Box style={{ flex: '100%', padding: '20px 0' }}>
      <Box width="100%">
        {props.salesData && Object.keys(props.salesData).length > 0 ? (
          <LineChart
            width="100%"
            data={props.salesData}
            name={props.name}
            duration={props.duration}
          />
        ) : (
          <Flex justifyContent={'center'} alignItems="center" h="400px" w="100%">
            <Text>
              {props.salesData && Object.keys(props.salesData).length == 0
                ? 'No Data to display for the selected regions'
                : 'Please Select a Region'}
            </Text>
          </Flex>
        )}
      </Box>{' '}
    </Box>
  );
};
export default PastSalesGlobal;
