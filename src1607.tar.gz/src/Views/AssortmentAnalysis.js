import { Box, Flex, Text, useTheme } from '@chakra-ui/react';

import { Button as ButtonJoy, ThemeProvider } from '@mui/joy';
import {
  //  GppBadOutlined, GppGoodOutlined, PlaylistAddCheck,
  Tune
} from '@mui/icons-material';
import Container from '../Artifactory/Components/Container/Container';
import { createTheme } from '@mui/material';
import React, { useEffect, useState, useContext } from 'react';
import MfacCharts from '../Containers/Store Assortment/MfacCharts';
import L2Assort from '../Containers/Assortment Analysis/L2Assort';
import axios from 'axios';
import PropTypes from 'prop-types';
import Typography from '@mui/material/Typography';
import DrawerFilters from './DrawerFilters';
import NewProducts from '../Containers/Assortment Analysis/NewProducts';
import DemandAnalysis from '../Containers/Assortment Analysis/DemandAnalysis';
import ProductsAssortment from '../Containers/Assortment Analysis/ProductsAssortment';
import { formatNumber } from '../Utils/formatNumberMillionBillion';
import { fetch_past_sales } from '../Utils/fetch_past_sales';
import { mfacRevenue } from '../Utils/mfaRevenue';
import { top_brands } from '../Utils/top_brands';
import { newProductStats } from '../Utils/newProductStats';
import l2l3table from '../Utils/l2l3table';
import { LocationContext } from '../Contexts/LocationContext';
import { attachGlobalFilters, attachTableData } from '../Utils/misc';
import { useLocation } from 'react-router-dom';
import AssortmentComposition from './Composition';
import { HourglassTop } from '@mui/icons-material';

function TabPanel(props) {
  const { children, value, index, ...other } = props;

  return (
    <Typography
      component="div"
      role="tabpanel"
      hidden={value !== index}
      id={`scrollable-auto-tabpanel-${index}`}
      aria-labelledby={`scrollable-auto-tab-${index}`}
      {...other}>
      <Box p={3}>{children}</Box>
    </Typography>
  );
}

TabPanel.propTypes = {
  children: PropTypes.node,
  index: PropTypes.any.isRequired,
  value: PropTypes.any.isRequired
};
const lastIndex = (array) => {
  let i = array.length - 1;
  while (i >= 0 && array[i] === null) {
    i--;
  }
  return i;
};
const AssortmentAnalysis = (props) => {
  const location = useLocation();
  const { stateName, zone } = location.state ? location.state : {};
  const chakratheme = useTheme();
  const number_style = {
    fontSize: '30px',
    fontWeight: 'bold',
    fontFamily: 'Sans-Serif',
    color: `${chakratheme.colors.black[600]}`
  };

  const {
    globalFiltersLevelNames,
    filterIDs,
    consoleState,

    //
    selectedRegions,
    setSelectedRegions,
    selectedCategories,
    setSelectedCategories,
    selectedBrands,
    setSelectedBrands
  } = useContext(LocationContext);
  const levelNames = globalFiltersLevelNames('region');
  const categoryLevelNames = globalFiltersLevelNames('category');
  console.log(categoryLevelNames);
  const brandLevelNames = globalFiltersLevelNames('manufacturer');

  const source = axios.CancelToken.source(); // Create a cancel token source

  const [hits_misses_data, set_hits_misses_data] = useState([]);
  const [page1, setPage1] = useState(1);
  const [page2, setPage2] = useState(1);
  const [page3, setPage3] = useState(1);
  const [page4, setPage4] = useState(1);
  const [page5, setPage5] = useState(1);
  const [totalProductsCount, setTotalProductsCount] = useState(0);
  const [totalProductsCount2, setTotalProductsCount2] = useState(0);

  const [searchData, setSearchData] = useState({
    molecule: ''
  });
  const [categoryNames, setCategoryNames] = useState([]);
  const [horizontalStackData, setHorizontalStackData] = useState([]);
  const [uploadedFile, setUploadedFile] = useState(null);
  const [tableData, setTableData] = useState([]);
  const headers2 = [
    {
      name: 'Product ID',
      id: 'product_id',
      sort: 'asc',
      colSpan: 2
    },
    {
      name: 'Description',
      id: 'item_name',
      sort: '',
      colSpan: 5,
      type: 'text'
    },
    {
      name: 'Segment',
      id: 'L3',
      sort: '',
      colSpan: 3
    }
  ];

  const [topMfacLoading, setTopMfacLoading] = useState(false);
  const [brandCategoryNames, setBrandCategoryNames] = useState([]);
  const [brandStackData, setBrandStackData] = useState([]);

  const [fullData, setFullData] = useState([]);
  const [newProducts, setNewProducts] = useState([]);
  const [newProductsStat, setNewProductsStat] = useState(null);
  const [newProductsLoading, setNewProductsLoading] = useState(false);

  const new_products_api = () => {
    setNewProductsLoading(true);

    let formData = new FormData();
    formData = attachGlobalFilters(formData, consoleState);
    formData = attachTableData(formData, assortmentTableState);

    formData.append('page_no', 1);
    formData.append('bounce_sort_param', sortBy3);
    formData.append('bounce_sort_type', sortOrder3);

    let config = {
      method: 'post',
      url: `${process.env.REACT_APP_API_BASE_URL}/new-products`,
      data: formData,
      cancelToken: source.token
    };

    axios(config)
      .then(async (response) => {
        setNewProducts(response.data.product_result);
        setTableData(response.data.bounce_result);
        setTotalProductsCount2(response.data.product_count);
        setBouncesCount(response.data.bounce_count);
        setNewProductsLoading(false);
      })
      .catch(function () {
        console.log('error');
        setNewProductsLoading(false);
      });
  };
  useEffect(() => {
    if (stateName) {
      setSelectedRegions([zone.toLowerCase(), stateName.toLowerCase(), null, null]);
    }
  }, []);

  const [bouncesCount, setBouncesCount] = useState();

  const [sortBy4, setSortBy4] = useState('count_comp');
  const [sortOrder4, setSortOrder4] = useState('desc');
  const [sortBy5, setSortBy5] = useState('count_comp');
  const [sortOrder5, setSortOrder5] = useState('desc');
  const [sortBy3, setSortBy3] = useState('sap_id');
  const [sortOrder3, setSortOrder3] = useState('asc');
  const [sortBy2, setSortBy2] = useState('num_qty_sold');
  const [sortOrder2, setSortOrder2] = useState('desc');
  // const [sortBy1, setSortBy1] = useState('num_qty_sold');
  // const [sortOrder1, setSortOrder1] = useState('desc');

  const handlePagination3 = () => {
    if (bouncesCount === tableData.length || page3 < Math.floor(tableData.length / 100)) {
      return;
    }
    const formData = new FormData();
    const lastIndexNonNull = lastIndex(selectedRegions);

    if (lastIndexNonNull != -1)
      formData.append(
        'region_type',
        levelNames[lastIndexNonNull] === 'Store' ? 'Branch' : levelNames[lastIndexNonNull]
      );
    else formData.append('region_type', null);
    if (lastIndexNonNull != -1) formData.append('region_name', selectedRegions[lastIndexNonNull]);
    else formData.append('region_name', null);

    if (selectedCategories[0]) formData.append('L0', selectedCategories[0]);
    if (selectedCategories[1]) formData.append('L1', selectedCategories[1]);
    if (selectedCategories[2]) formData.append('L2', selectedCategories[2]);
    if (selectedCategories[3]) formData.append('L3', selectedCategories[3]);
    formData.append('page_no', page3 === 1 ? 2 : Math.floor(page3 / 5) + 2);
    formData.append('bounce_sort_param', sortBy3);
    formData.append('bounce_sort_type', sortOrder3);
    formData.append('bounce_sort_param', sortBy2);
    formData.append('bounce_sort_type', sortOrder2);
    let config = {
      method: 'post',
      url: `${process.env.REACT_APP_API_BASE_URL}/new-products`,
      data: formData
    };

    axios(config)
      .then(async (response) => {
        if (response?.data?.bounce) {
          setTableData((prevData) => [...prevData, ...response.data.bounce]);
        }
      })
      .catch(function () {
        console.log('error');
      });
  };

  const [selectedRegions2, setSelectedRegions2] = useState(Array(levelNames.length).fill(null));

  const [selectedCategories2, setSelectedCategories2] = useState(
    Array(categoryLevelNames.length).fill(null)
  );
  const [headers, setHeaders] = useState(
    consoleState.state?.assortmentTable?.analysisHeaders || []
  );

  const _assortmentTableState = {
    filtersData: {
      filter_type: consoleState.state?.assortmentTable?.defaults.filterData.filter_type || '',
      filter_params: []
    },
    searchData: headers.reduce((acc, header) => {
      if (header.search) acc[header.search_variable] = '';
      return acc;
    }, {}),
    sortData: {
      sort_param: consoleState.state?.assortmentTable?.defaults.sortData.sort_param || '',
      sort_type: consoleState.state?.assortmentTable?.defaults.sortData.sort_type || ''
    }
  };
  const [assortmentTableState, setAssortmentTableState] = useState(_assortmentTableState);

  const handlePagination = () => {
    if (
      totalProductsCount2 === newProducts.length ||
      page2 < Math.floor(newProducts.length / 100)
    ) {
      return;
    }
    const formData = new FormData();
    const lastIndexNonNull = lastIndex(selectedRegions);

    if (lastIndexNonNull != -1)
      formData.append(
        'region_type',
        levelNames[lastIndexNonNull] === 'Store' ? 'Branch' : levelNames[lastIndexNonNull]
      );
    else formData.append('region_type', null);
    if (lastIndexNonNull != -1) formData.append('region_name', selectedRegions[lastIndexNonNull]);
    else formData.append('region_name', null);

    if (selectedCategories[0]) formData.append('L0', selectedCategories[0]);
    if (selectedCategories[1]) formData.append('L1', selectedCategories[1]);
    if (selectedCategories[2]) formData.append('L2', selectedCategories[2]);
    if (selectedCategories[3]) formData.append('L3', selectedCategories[3]);
    formData.append('page_no', page2 === 1 ? 2 : Math.floor(page2 / 5) + 2);
    formData.append('bounce_sort_param', sortBy3);
    formData.append('bounce_sort_type', sortOrder3);
    formData.append('bounce_sort_param', sortBy2);
    formData.append('bounce_sort_type', sortOrder2);
    const config = {
      method: 'post',
      url: `${process.env.REACT_APP_API_BASE_URL}/new-products`,
      data: formData
    };

    axios(config)
      .then(async (response) => {
        setNewProducts((prevData) => [...prevData, ...response.data.product_result]);
      })
      .catch(function () {
        console.log('error');
      });
  };

  const handlePagination2 = () => {
    if (
      productsCountByType[hits] === hits_misses_data.length ||
      page1 < Math.floor(hits_misses_data.length / 100)
    )
      return;

    let formData = new FormData();

    formData = attachGlobalFilters(formData, consoleState);
    formData = attachTableData(formData, assortmentTableState);

    // formData.append("page_no", page1+1);
    formData.append('page_no', page1 === 1 ? 2 : Math.floor(page1 / 5) + 2);

    let config = {
      method: 'post',
      url: `${consoleState.state.api.BASE_URL}${consoleState.state.api.ASSORTMENT}`,
      data: formData
    };

    axios(config)
      .then(async (response) => {
        set_hits_misses_data((prevData) => [
          ...prevData,
          ...response.data[consoleState.state.assortmentTable.types[hits].apiKey]
        ]);
        setTotalProductsCount(response.data[`${hits}_count`]);
      })
      .catch(function () {
        console.log('error');
      });
  };
  const _productsCount = Object.keys(consoleState.state?.assortmentTable?.types).reduce(
    (acc, type) => {
      acc[type] = 0;
      return acc;
    },
    {}
  );

  const [productsCountByType, setProductsCountByType] = useState(_productsCount);

  const [hitsMissesLoading, setHitsMissesLoading] = useState(false);
  const hits_and_misses = (hits) => {
    setHitsMissesLoading(true);
    let formData = new FormData();

    formData = attachGlobalFilters(formData, consoleState);
    formData = attachTableData(formData, assortmentTableState);

    formData.append('page_no', 1);
    let config = {
      method: 'post',
      url: `${consoleState.state.api.BASE_URL}${consoleState.state.api.ASSORTMENT}`,
      data: formData,
      cancelToken: source.token
    };

    axios(config)
      .then(async (response) => {
        setFullData(response.data);

        const __productsCount = {};
        Object.keys(consoleState.state.assortmentTable.types).forEach((type) => {
          __productsCount[type] = response.data[`${type}_count`];
        });
        setProductsCountByType(__productsCount);

        setTotalProductsCount(response.data[`${hits}_count`]);
        set_hits_misses_data(response.data[consoleState.state.assortmentTable.types[hits].apiKey]);

        setHitsMissesLoading(false);
      })
      .catch(function () {
        console.log('error');
        setHitsMissesLoading(false);
      });
  };

  const [salesData, setSalesData] = useState(null);
  const [bucketsData, setBucketsData] = useState();

  const fetch_buckets = () => {
    let formData = new FormData();
    formData.append('checkbox', false);
    formData = attachGlobalFilters(formData, consoleState);
    let config = {
      method: 'post',
      url: `${process.env.REACT_APP_API_BASE_URL}/margin-buckets`,
      data: formData
    };

    axios(config)
      .then(async (response) => {
        setBucketsData(response.data);
      })
      .catch(function () {
        console.log('error');
      });
  };

  const [stats, setStats] = useState([]);

  const [alignment, setAlignment] = React.useState('assortment');
  useEffect(() => {
    setHits(alignment);
    setTotalProductsCount(productsCountByType[alignment]);
    setPage1(1);
  }, [alignment]);

  useEffect(() => {
    const index = lastIndex(selectedRegions);
    const regionName = index === -1 ? null : levelNames[index];
    const regionValue = index === -1 ? null : selectedRegions[index];
    newProductStats(regionValue, regionName, selectedCategories, setNewProductsStat);
    fetch_past_sales(setSalesData, consoleState);
    fetch_buckets();
  }, [selectedRegions, selectedCategories]);

  useEffect(() => {
    if (!props.open) {
      setSelectedCategories2(selectedCategories);
      setSelectedRegions2(selectedRegions);
    }
  }, [selectedRegions, selectedCategories, props.open]);

  useEffect(() => {
    hits_and_misses(hits, true);
  }, [
    assortmentTableState.sortData,
    ...filterIDs.map((filter) => consoleState.state.globalFilters[filter].selected),
    assortmentTableState.filtersData,
    assortmentTableState.searchData
  ]);

  useEffect(() => {
    if (!consoleState.state.features.categoryComposition) return;
    l2l3();
    l2l3table({
      selectedRegions,
      levelNames,
      sortBy4,
      sortOrder4,
      sortBy5,
      sortOrder5,
      setL3tabledata,
      setL2tabledata,
      setL2count,
      setL3count,
      setL2l3loading,
      lastIndex
    });
  }, [sortBy4, sortOrder4, sortBy5, sortOrder5, selectedRegions]);
  const [hits, setHits] = useState('assortment');

  // eslint-disable-next-line no-unused-vars
  const [newProductStatsLoading, setNewProductStatsLoading] = useState(false);

  useEffect(() => {
    setPage1(1);
  }, [...filterIDs.map((filter) => consoleState.state.globalFilters[filter].selected)]);

  useEffect(() => {
    // fetchFilters();

    return () => {
      source.cancel('Cancelling the request');
    };
  }, [...filterIDs.map((filter) => consoleState.state.globalFilters[filter].selected)]);

  useEffect(() => {
    set_hits_misses_data(fullData[consoleState.state.assortmentTable.types[hits].apiKey]);
    setTotalProductsCount(productsCountByType[hits]);
  }, [hits]);

  useEffect(() => {
    mfacRevenue(consoleState, setStats, source.token);
    top_brands(
      // selectedRegions,
      // levelNames,
      // selectedCategories,
      // selectedBrands,
      consoleState,
      setHorizontalStackData,
      setBrandStackData,
      setBrandCategoryNames,
      setTopMfacLoading,
      // lastIndex,
      setCategoryNames,
      source.token
    );
  }, [...filterIDs.map((filter) => consoleState.state.globalFilters[filter].selected)]);

  const [pinFilters, setPinFilters] = useState(false);

  useEffect(() => {
    window.addEventListener('scroll', isSticky);
    return () => {
      window.removeEventListener('scroll', isSticky);
    };
  });

  /* Method that will fix header after a specific scrollable */
  const isSticky = () => {
    const filler = document.querySelector('.filler');
    const header = document.querySelector('.header-section');
    const scrollTop = window.scrollY;
    if (pinFilters) {
      scrollTop >= 150 ? header.classList.add('is-sticky') : header.classList.remove('is-sticky');
      scrollTop >= 150 ? filler.classList.remove('no-display') : filler.classList.add('no-display');
    }
  };
  useEffect(() => {
    const filler = document.querySelector('.filler');
    if (pinFilters) {
      const header = document.querySelector('.header-section');
      const scrollTop = window.scrollY;
      if (scrollTop >= 150) header.classList.add('is-sticky');
      if (scrollTop >= 150) filler.classList.remove('no-display');
    } else {
      const header = document.querySelector('.header-section');
      header.classList.remove('is-sticky');
      filler.classList.add('no-display');
    }
  }, [pinFilters]);

  const fetchBulkData = (file) => {
    // url is/bulk-assortment
    const finalFormData = new FormData();
    finalFormData.append('file', file);
    let config = {
      method: 'post',
      url: `${process.env.REACT_APP_API_BASE_URL}/bulk-assortment`,
      data: finalFormData
    };
    axios(config)
      .then(async (response) => {
        set_hits_misses_data(response.data);
      })
      .catch(function () {
        console.log('error');
      });
  };

  const [l2missdata, setL2missData] = useState([]);
  const [l2data, setL2data] = useState([]);
  const [l3missdata, setL3missData] = useState([]);
  const [l3data, setL3data] = useState([]);
  const [l2tabledata, setL2tabledata] = useState();
  const [l3tabledata, setL3tabledata] = useState();
  const [l2count, setL2count] = useState(0);
  const [l3count, setL3count] = useState(0);

  const [l2l3loading, setL2l3loading] = useState(false);
  const handlePagination4 = () => {
    if (l2count === l2tabledata.length || page4 < Math.floor(l2tabledata.length / 100)) {
      return;
    }
    let formData = new FormData();
    formData = attachGlobalFilters(formData, consoleState);

    formData.append('page_no_l2', page4 === 1 ? 2 : Math.floor(page4 / 5) + 2);
    formData.append('page_no_l3', page5 === 1 ? 2 : Math.floor(page5 / 5) + 2);
    formData.append('sort_param_l2', sortBy4);
    formData.append('sort_type_l2', sortOrder4);
    formData.append('sort_param_l3', sortBy5);
    formData.append('sort_type_l3', sortOrder5);
    let config = {
      method: 'post',
      url: `${process.env.REACT_APP_API_BASE_URL}/l2l3-table`,
      data: formData
    };

    axios(config)
      .then(async (response) => {
        setL2tabledata((prevData) => [...prevData, ...response.data.l2_table]);
      })
      .catch(function () {
        console.log('error');
      });
  };
  const handlePagination5 = () => {
    if (l3count === l3tabledata.length || page5 < Math.floor(l3tabledata.length / 100)) {
      return;
    }
    let formData = new FormData();
    formData = attachGlobalFilters(formData, consoleState);
    formData.append('page_no_l2', page4 === 1 ? 2 : Math.floor(page4 / 5) + 2);
    formData.append('page_no_l3', page5 === 1 ? 2 : Math.floor(page5 / 5) + 2);
    formData.append('sort_param_l2', sortBy4);
    formData.append('sort_type_l2', sortOrder4);
    formData.append('sort_param_l3', sortBy5);
    formData.append('sort_type_l3', sortOrder5);
    let config = {
      method: 'post',
      url: `${process.env.REACT_APP_API_BASE_URL}/l2l3-table`,
      data: formData
    };

    axios(config)
      .then(async (response) => {
        setL3tabledata((prevData) => [...prevData, ...response.data.l3_table]);
      })
      .catch(function () {
        console.log('error');
      });
  };

  const l2l3 = () => {
    setL2l3loading(true);

    let formData = new FormData();
    formData = attachGlobalFilters(formData, consoleState);

    let config = {
      method: 'post',
      url: `${process.env.REACT_APP_API_BASE_URL}/l2l3`,
      data: formData
    };
    axios(config)
      .then(async (response) => {
        setL2missData(response.data.l2_assort_dist_miss);
        setL3missData(response.data.l3_assort_dist_miss);
        setL2data(response.data.l2_assort_comp);
        setL3data(response.data.l3_assort_comp);
        setL2l3loading(false);
      })
      .catch(function () {
        console.log('error');
        setL2l3loading(false);
      });
  };

  const [newproductsload, setnewproductsload] = useState(false);

  const downloadCSV = () => {
    setnewproductsload(true);
    let formData = new FormData();
    formData = attachGlobalFilters(formData, consoleState);
    formData.append('sort_param', sortBy2);
    formData.append('sort_type', sortOrder2);
    let config = {
      method: 'post',
      url: `${process.env.REACT_APP_API_BASE_URL}/new-products-csv`,
      data: formData,
      responseType: 'blob'
    };
    axios(config)
      .then(function (response) {
        const csvFile = new Blob([response.data], { type: 'text/csv' });

        if (csvFile) {
          const anchor = document.createElement('a');
          anchor.href = URL.createObjectURL(csvFile);
          anchor.download = 'NewProducts.csv';
          anchor.style.display = 'none';

          document.body.appendChild(anchor);

          anchor.click();

          URL.revokeObjectURL(anchor.href);

          document.body.removeChild(anchor);
        }
      })
      .catch(function () {
        console.log('error');
      });
  };

  const [newproductsbounceload, setnewproductsbounceload] = useState(false);

  const downloadCSV2 = () => {
    setnewproductsbounceload(true);
    let formData = new FormData();
    formData = attachGlobalFilters(formData, consoleState);
    formData.append('bounce_sort_param', sortBy3);
    formData.append('bounce_sort_type', sortOrder3);
    let config = {
      method: 'post',
      url: `${process.env.REACT_APP_API_BASE_URL}/new-products-bounce-csv`,
      data: formData,
      responseType: 'blob'
    };
    axios(config)
      .then(function (response) {
        const csvFile = new Blob([response.data], { type: 'text/csv' });

        if (csvFile) {
          const anchor = document.createElement('a');
          anchor.href = URL.createObjectURL(csvFile);
          anchor.download = 'NewProductsBounce.csv';
          anchor.style.display = 'none';

          document.body.appendChild(anchor);

          anchor.click();

          URL.revokeObjectURL(anchor.href);

          document.body.removeChild(anchor);
        }
        setnewproductsbounceload(false);
      })
      .catch(function () {
        setnewproductsbounceload(false);
        console.log('error');
      });
  };

  const [downloadLoad3, setDownloadLoad3] = useState(false);

  const downloadCSV3 = () => {
    setDownloadLoad3(true);

    let formData = new FormData();

    formData = attachGlobalFilters(formData, consoleState);
    formData = attachTableData(formData, assortmentTableState);
    formData.append('csv_flag', alignment);

    let config = {
      method: 'post',
      url: `${process.env.REACT_APP_API_BASE_URL}/hit-miss-csv`,
      data: formData,
      responseType: 'blob'
    };
    axios(config)
      .then(function (response) {
        const csvFile = new Blob([response.data], { type: 'text/csv' });

        if (csvFile) {
          const anchor = document.createElement('a');
          anchor.href = URL.createObjectURL(csvFile);
          if (selectedRegions[selectedRegions.length - 1] === null) {
            anchor.download = `Assortment.csv`;
          } else {
            anchor.download = `Assortment - ${selectedRegions[selectedRegions.length - 1]}.csv`;
          }
          anchor.style.display = 'none';

          document.body.appendChild(anchor);

          anchor.click();

          URL.revokeObjectURL(anchor.href);

          document.body.removeChild(anchor);
        }
        setDownloadLoad3(false);
      })
      .catch(function () {
        console.log('error');
      });
  };

  useEffect(() => {
    new_products_api();
  }, [sortBy2, sortBy3, sortOrder2, sortOrder3, selectedRegions, selectedCategories]);

  const capitalizeFirstLetter = (string) => {
    return string.replace(/\b\w/g, (match) => match.toUpperCase());
  };

  const anySelectedFilter = (filter) =>
    consoleState.state.globalFilters[filter].selected.some((f) => f);
  const anySelected = filterIDs.some((filter) => anySelectedFilter(filter));

  return (
    <Container>
      <Flex direction="column" id="overview">
        <Text
          style={{
            fontSize: '22px',
            fontFamily: 'Poppins',
            fontWeight: 'bold',
            marginTop: '0px'
          }}>
          {consoleState.state.constants.assortmentAnalysis.TITLE}
        </Text>
        <Box
          w="100px"
          h="5px"
          bg={`${chakratheme.colors.primary.main}`}
          borderRadius="3px"
          mt={2}
        />
      </Flex>
      <DrawerFilters
        lastIndex={lastIndex}
        open={props.open}
        setOpen={props.setOpen}
        hits_misses_data={hits_misses_data}
        fetchBulkData={fetchBulkData}
        uploadedFile={uploadedFile}
        setUploadedFile={setUploadedFile}
        pinFilters={pinFilters}
        setPinFilters={setPinFilters}
        // categoryNested={categoryNested}
        categoryLevelNames={categoryLevelNames}
        selectedCategories={selectedCategories}
        setSelectedCategories={setSelectedCategories}
        // regions_nested={regions_nested}
        levelNames={levelNames}
        selectedRegions={selectedRegions}
        setSelectedRegions={setSelectedRegions}
        // brandData={brandData}
        brandLevelNames={brandLevelNames}
        selectedBrands={selectedBrands}
        setSelectedBrands={setSelectedBrands}
        // filterCount={filterCount}
        levelExamples={props.levelExamples}
        setSelectedRegionsdefault={props.setSelectedRegionsdefault}
        selectedRegionsdefault={props.selectedRegionsdefault}
        default={true}
        hideFilters={localStorage.getItem('role') === 'store manager' ? ['region'] : []}
      />
      <Text
        mt={3}
        style={{
          color: `${chakratheme.colors.black[400]}`,
          fontSize: '13px',
          fontFamily: 'sans-serif'
        }}>
        Comprehensive analytics and valuable insights to illuminate the performance of your product
        assortments.
      </Text>
      <Flex
        alignItems={'center'}
        style={{
          marginTop: '20px'
        }}>
        <ThemeProvider theme={() => createTheme()}>
          <ButtonJoy
            variant="outlined"
            color="neutral"
            startDecorator={<Tune />}
            onClick={() => props.setOpen(true)}>
            Change filters
          </ButtonJoy>
        </ThemeProvider>
        <Flex
          id="analysis"
          ml={5}
          color={`${chakratheme.colors.gray.main}`}
          style={{
            // backgroundColor: `${chakratheme.colors.gray.lighter}`,
            borderRadius: '5px',
            padding: '7px 20px',
            fontSize: '13px'
          }}
          alignItems={'center'}
          justifyContent={'flex-start'}>
          <HourglassTop style={{ marginRight: '10px' }} />
          <Text fontWeight={'bold'} fontSize="13px">
            Duration of Assortment -
          </Text>
          <Text ml={1} fontWeight={'bold'} fontSize="13px">
            July 25-31, 2023
          </Text>
        </Flex>
      </Flex>
      <Flex
        direction="column"
        w="100%"
        style={{
          border: `1px solid ${chakratheme.colors.gray[500]}`,
          borderRadius: '10px',
          padding: '10px',
          color: `${chakratheme.colors.gray.light}`,
          fontSize: '14px',
          marginTop: '5px'
        }}>
        <Text color="black" fontWeight={'bold'}>
          {anySelected ? ' Showing results for' : 'Showing Global Results. '}{' '}
          {!anySelected ? (
            <span style={{ color: `${chakratheme.colors.black[400]}` }}>
              Change filters to search for a particular region, category and/or brand.
            </span>
          ) : null}
        </Text>
        {filterIDs.map((filter) => {
          if (!anySelectedFilter(filter)) return null;
          return (
            <Flex
              key={filter}
              style={{
                padding: '5px 10px',
                marginTop: '5px',
                borderRadius: '20px',
                backgroundColor: `${chakratheme.colors.gray.lighter}`,
                color: `${chakratheme.colors.gray.dark}`
              }}>
              <Text
                borderRight={`3px solid ${chakratheme.colors.gray[300]}`}
                paddingRight="5px"
                marginRight="10px">
                {capitalizeFirstLetter(filter)}
              </Text>
              {consoleState.state.globalFilters[filter].selected.map((item, index) => {
                return item ? (
                  <Text marginRight={'10px'} key={index}>
                    <span style={{ fontWeight: 'bold', marginLeft: '3px' }}>
                      {consoleState.state.globalFilters[filter].levelNames[index]}
                    </span>{' '}
                    {item}
                  </Text>
                ) : null;
              })}
            </Flex>
          );
        })}
      </Flex>
      <Flex flexDir={'column'} mt={4} w="100%" mb={50}>
        <Flex className="header-section"></Flex>
        <div
          className="filler no-display"
          style={{
            height: '400px',
            width: '100%'
          }}></div>
        {consoleState.state.features.assortmentAnalysisTable ? (
          <ProductsAssortment
            setHeaders={setHeaders}
            assortmentTableState={assortmentTableState}
            setAssortmentTableState={setAssortmentTableState}
            selectedRegions={selectedRegions}
            alignment={alignment}
            downloadLoad3={downloadLoad3}
            hits_misses_data={hits_misses_data}
            handlePagination2={handlePagination2}
            totalProductsCount={totalProductsCount}
            page1={page1}
            hitsMissesLoading={hitsMissesLoading}
            setPage1={setPage1}
            // sortBy1={sortBy1}
            // setSortBy1={setSortBy1}
            // sortOrder1={sortOrder1}
            // setSortOrder1={setSortOrder1}
            headersnew={headers}
            fetchBulkData={fetchBulkData}
            uploadedFile={uploadedFile}
            setUploadedFile={setUploadedFile}
            pinFilters={pinFilters}
            setPinFilters={setPinFilters}
            // categoryNested={categoryNested}
            categoryLevelNames={categoryLevelNames}
            selectedCategories2={selectedCategories2}
            setSelectedCategories2={setSelectedCategories2}
            // regions_nested={regions_nested}
            levelNames={levelNames}
            selectedRegions2={selectedRegions2}
            setSelectedRegions2={setSelectedRegions2}
            searchData={searchData}
            setSearchData={setSearchData}
            bucketsData={bucketsData}
            set_hits_misses_data={set_hits_misses_data}
            downloadCSV3={downloadCSV3}
            setAlignment={setAlignment}
            capitalizeFirstLetter={capitalizeFirstLetter}
            lastIndex={lastIndex}
          />
        ) : null}
        {consoleState.state.features.manufacturerCharts ? (
          <MfacCharts
            selectedBrands={selectedBrands}
            loading={topMfacLoading}
            // brandData={brandData}
            brandLevelNames={brandLevelNames}
            setSelectedBrands={setSelectedBrands}
            stats={stats}
            formatNumber={formatNumber}
            number_style={number_style}
            horizontalStackData={horizontalStackData}
            brandStackData={brandStackData}
            brandCategoryNames={brandCategoryNames}
            categoryNames={categoryNames}
            salesData={salesData}
            hideActionableItems={true}
          />
        ) : null}
        {consoleState.state.features.assortmentComposition ? <AssortmentComposition /> : null}

        {consoleState.state.features.categoryComposition ? (
          <L2Assort
            loading={l2l3loading}
            l2data={l2data}
            l2tabledata={l2tabledata}
            l3tabledata={l3tabledata}
            sortBy4={sortBy4}
            setSortBy4={setSortBy4}
            sortOrder4={sortOrder4}
            setSortOrder4={setSortOrder4}
            sortBy5={sortBy5}
            setSortBy5={setSortBy5}
            sortOrder5={sortOrder5}
            setSortOrder5={setSortOrder5}
            page4={page4}
            setPage4={setPage4}
            page5={page5}
            setPage5={setPage5}
            handlePagination4={handlePagination4}
            handlePagination5={handlePagination5}
            l2count={l2count}
            l3count={l3count}
            l2missdata={l2missdata}
            l3data={l3data}
            l3missdata={l3missdata}></L2Assort>
        ) : null}
        {consoleState.state.features.newProducts ? (
          <NewProducts
            newproductsbounceload={newproductsbounceload}
            downloadCSV2={downloadCSV2}
            newProductsLoading={newProductsLoading}
            tableData={tableData}
            handlePagination3={handlePagination3}
            sortBy3={sortBy3}
            setSortBy3={setSortBy3}
            sortOrder3={sortOrder3}
            setSortOrder3={setSortOrder3}
            page3={page3}
            setPage3={setPage3}
            headers2={headers2}
            newproductsload={newproductsload}
            downloadCSV={downloadCSV}
            newProducts={newProducts}
            handlePagination={handlePagination}
            totalProductsCount2={totalProductsCount2}
            sortBy2={sortBy2}
            setSortBy2={setSortBy2}
            sortOrder2={sortOrder2}
            setSortOrder2={setSortOrder2}
            page2={page2}
            setPage2={setPage2}
            newProductsStat={newProductsStat}
            consoleState={consoleState}
          />
        ) : null}
        {consoleState.state.features.demandAnalysis ? (
          <DemandAnalysis
            newProductStatsLoading={newProductStatsLoading}
            newProductsStat={newProductsStat}
          />
        ) : null}
      </Flex>
    </Container>
  );
};

export default AssortmentAnalysis;
