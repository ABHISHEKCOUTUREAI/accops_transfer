/* eslint-disable no-unused-vars */
import * as React from 'react';
import Drawer from '@mui/joy/Drawer';
import Button from '@mui/joy/Button';
import DialogTitle from '@mui/joy/DialogTitle';
import DialogContent from '@mui/joy/DialogContent';
import ModalClose from '@mui/joy/ModalClose';
import Divider from '@mui/joy/Divider';
import Sheet from '@mui/joy/Sheet';
import { ThemeProvider } from '@mui/joy';
import { createTheme } from '@mui/material';
import { Flex, Spacer } from '@chakra-ui/layout';
import FiltersSide from '../components/FiltersSide';

import { ChevronDownIcon, ChevronUpIcon } from '@chakra-ui/icons';
import { useTheme } from '@chakra-ui/react';
import { useEffect } from 'react';
import axios from 'axios';
import { LocationContext } from '../Contexts/LocationContext';
import { useLocation } from 'react-router-dom';
const lastIndex = (array) => {
  let i = array.length - 1;
  while (i >= 0 && array[i] === null) {
    i--;
  }
  return i;
};
export default function DrawerFilters(props) {
  const { filterIDs, consoleState, setConsoleState, globalFiltersLevelNames } =
    React.useContext(LocationContext);

  const chakratheme = useTheme();
  const open = props.open;
  const setOpen = props.setOpen;
  const location = useLocation();

  const [dataNested, setDataNested] = React.useState(
    filterIDs.reduce((acc, curr) => {
      acc[curr] = [];
      return acc;
    }, {})
  );
  const [expand, setExpand] = React.useState(
    filterIDs.reduce((acc, curr, index) => {
      acc[curr] = index === 0;
      return acc;
    }, {})
  );
  const [_selectedFilters, _setSelectedFilters] = React.useState(
    filterIDs.reduce((acc, curr) => {
      acc[curr] = consoleState.state.globalFilters[curr].selected;
      return acc;
    }, {})
  );
  const [_filtersCount, _setFiltersCount] = React.useState(
    filterIDs.reduce((acc, curr) => {
      acc[curr] = consoleState.state.globalFilters[curr].countApiKey ? {} : null;
      return acc;
    }, {})
  );

  const _setSelectedFilter = (filter) => (value) => {
    _setSelectedFilters({
      ..._selectedFilters,
      [filter]: value
    });
  };

  const [filterCount, setFilterCount] = React.useState();

  const fetchFilters = () => {
    const formData = new FormData();

    filterIDs.forEach((filter) => {
      if (filter == 'region') {
        const lastIndexNonNull = lastIndex(_selectedFilters['region']);
        if (lastIndexNonNull != -1)
          formData.append('region_type', globalFiltersLevelNames('region')[lastIndexNonNull]);
        else formData.append('region_type', null);
        if (lastIndexNonNull != -1)
          formData.append('region_name', _selectedFilters['region'][lastIndexNonNull]);
        else formData.append('region_name', null);
      } else {
        _selectedFilters[filter].forEach((item, index) => {
          if (item) formData.append(consoleState.state.globalFilters[filter].apiKeys[index], item);
        });
      }
    });

    let configStat = {
      method: 'post',
      url: `${consoleState.state.api.BASE_URL}${consoleState.state.api.GET_FILTERS}`,
      data: formData
    };
    axios(configStat)
      .then(async (response) => {
        const _dataNested = {};
        filterIDs.forEach((filter) => {
          _dataNested[filter] = response.data[consoleState.state.globalFilters[filter].responseKey];
        });
        setDataNested(_dataNested);
        const countFilter = filterIDs.find(
          (filter) => consoleState.state.globalFilters[filter].countApiKey === 'filters_count'
        );
        const countFilterObject = consoleState.state.globalFilters[countFilter];

        const output = {};

        Object.keys(response.data.filters_count).forEach((key, index) => {
          output[countFilterObject.levelNames[index]] = response.data.filters_count[key];
        });

        _setFiltersCount({ ..._filtersCount, filters_count: output });
        setFilterCount(response.data.filters_count);
      })
      .catch(function (e) {
        if (axios.isCancel(e)) {
          console.log('Request canceled', e.message);
        } else {
          console.log('error');
        }
      });
  };

  useEffect(() => {
    fetchFilters();
  }, [_selectedFilters]);

  return (
    <ThemeProvider theme={() => createTheme()}>
      <Drawer
        size="md"
        variant="plain"
        anchor="right"
        open={open}
        onClose={() => setOpen(false)}
        slotProps={{
          content: {
            sx: {
              bgcolor: 'transparent',
              p: { md: 3, sm: 0 },
              boxShadow: 'none'
            }
          }
        }}>
        <Sheet
          sx={{
            borderRadius: 'md',
            p: 2,
            display: 'flex',
            flexDirection: 'column',
            gap: 2,
            height: '100%',
            overflow: 'auto'
          }}>
          <DialogTitle>Filters</DialogTitle>
          <ModalClose />
          <Divider sx={{ mt: 'auto' }} />
          <DialogContent sx={{ gap: 2 }}>
            <Flex w="100%" direction="column">
              {filterIDs.map((filter) => {
                if (props.hideFilters?.includes(filter)) return null;
                return (
                  <Flex key={filter} w={'100%'} direction={'column'}>
                    <Flex>
                      <Button
                        style={{
                          marginTop: '10px',
                          borderBottomRightRadius: expand[filter] ? 0 : null,
                          borderBottomLeftRadius: expand[filter] ? 0 : null,
                          borderBottom: expand[filter] ? '1px solid white' : null,
                          transform: 'translate(0,1px)',
                          zIndex: '100'
                        }}
                        onClick={() => {
                          setExpand({ ...expand, [filter]: !expand[filter] });
                        }}
                        variant="outlined"
                        endDecorator={expand[filter] ? <ChevronUpIcon /> : <ChevronDownIcon />}>
                        {consoleState.state.globalFilters[filter].filterGroup}
                      </Button>
                    </Flex>
                    {expand[filter] ? (
                      <Flex
                        w="100%"
                        alignItems={'center'}
                        h="100%"
                        style={{
                          border: `1px solid ${chakratheme.colors.primary.light}`,
                          borderBottomLeftRadius: '5px',
                          borderBottomRightRadius: '5px'
                        }}
                        mb="5">
                        <FiltersSide
                          filterCount={
                            _filtersCount[consoleState.state.globalFilters[filter].countApiKey]
                          }
                          nonedit={props.nonedit}
                          nestedData={dataNested[filter]}
                          type={filter}
                          filter={props.filter}
                          levelNames={globalFiltersLevelNames(filter)}
                          selectedItems={_selectedFilters[filter]}
                          setSelectedItems={_setSelectedFilter(filter)}
                          levelExamples={props.levelExamples}
                          icons={consoleState.state.globalFilters[filter].icons}></FiltersSide>
                      </Flex>
                    ) : null}
                  </Flex>
                );
              })}
            </Flex>
          </DialogContent>

          <Divider sx={{ mt: 'auto' }} />
          <Flex direction="row" justifyContent="space-between" useFlexGap spacing={1}>
            <Button
              variant="outlined"
              color="neutral"
              onClick={() => {
                const __selectedFilters = {
                  ..._selectedFilters
                };
                filterIDs.forEach((filter) => {
                  __selectedFilters[filter] = Array(
                    consoleState.state.globalFilters[filter].levelNames.length
                  ).fill(null);
                });
                _setSelectedFilters(__selectedFilters);
              }}>
              Clear All
            </Button>
            <Spacer />
            <Button
              // variant="outlined"
              color="success"
              disabled={
                filterIDs.every((filter) =>
                  _selectedFilters[filter].every(
                    (val, index) => val === consoleState.state.globalFilters[filter].selected[index]
                  )
                ) ||
                (!_selectedFilters['region'].every((element) => element !== null) &&
                  !location.pathname.includes('new-assortment'))
              }
              onClick={() => {
                props.setSelectedRegions(_selectedFilters['region']);
                props.setSelectedBrands(_selectedFilters.manufacturer);
                props.setSelectedCategories(_selectedFilters.category);
                const _consoleState = {
                  ...consoleState
                };
                filterIDs.forEach((filter) => {
                  _consoleState.state.globalFilters[filter].selected = _selectedFilters[filter];
                });
                setConsoleState(_consoleState);

                setOpen(false);
              }}>
              Apply Filters
            </Button>
            {/* <Button onClick={() => setOpen(false)}>Apply Filters</Button> */}
          </Flex>
        </Sheet>
      </Drawer>
    </ThemeProvider>
  );
}
