import { Box, Divider, Flex, Spacer, Text } from '@chakra-ui/layout';
import { Image, Table, Tbody, Td, Th, Thead, Tr, useTheme } from '@chakra-ui/react';
import { ChevronLeftRounded, ChevronRightRounded } from '@mui/icons-material';
import { IconButton, Skeleton } from '@mui/material';
import { useEffect, useState } from 'react';
import Ascending from '../Static/ascending.png';
import Descending from '../Static/descending.png';
import { FilterList } from '@mui/icons-material';
const CustomTable = (props) => {
  const chakratheme = useTheme();
  const pageSize = 20;
  const [paginatedData, setPaginatedData] = useState(null);
  const [headers, setHeaders] = useState(props.headers); // {name: 'Name', id: 'ID', sort: null/''/'asc'}
  const paginate = () => {
    const start = props.page * pageSize - pageSize;
    const end = props.page * pageSize;
    setPaginatedData(props.data && props.data.slice(start, end));
  };
  useEffect(() => {
    paginate();
  }, [pageSize, props.page, headers, props.data]);
  const tdStyle = {
    fontFamily: 'Arial, sans-serif',
    fontWeight: 'regular', // Replace with your desired font
    padding: '5px 30px',
    fontSize: '12px',
    textAlign: 'left',
    color: `${chakratheme.colors.black[800]}`
  };

  const thStyle = {
    color: 'black',
    padding: '10px 30px',
    fontSize: '13px',
    fontWeight: 'bold',
    borderBottom: `1px solid ${chakratheme.colors.gray.light}`,
    textAlign: 'left'
  };
  return (
    <Box
      //   w="65%"
      // h="100%"
      style={{
        boxShadow: `${chakratheme.colors.shadow} 0px 0px 20px 10px`,
        display: 'block'
      }}>
      <Box overflowY="auto" height="600px" w="100%" maxHeight="600px">
        <Table
          style={{ borderSpacing: '0 1em' }}
          __css={{ 'table-layout': 'fixed', width: 'full' }}
          variant="simple"
          colorScheme="teal">
          <Thead
            style={{
              position: 'sticky',
              top: 0,
              zIndex: 6,
              opacity: 1,
              backgroundColor: `${chakratheme.colors.primary.main}`,
              borderRadius: '20px',
              color: 'white'
            }}>
            <Tr style={{ borderRadius: '20px', color: 'white' }}>
              {headers?.map((title, i) => {
                return (
                  <Th
                    _hover={{
                      backgroundColor: `${chakratheme.colors.primary.light}`
                    }}
                    colSpan={title.colSpan ? title.colSpan : 1}
                    onClick={() => {
                      props.setPage(1);
                      let ls = ['', 'asc', 'desc'];
                      const currentSortOrder = props.sortOrder === 'asc' ? 'desc' : 'asc'; // Toggle the sorting order
                      props.setSortOrder(currentSortOrder); // Update the sort order state
                      props.setSortBy(title.id);
                      let _headers;
                      let index = ls.indexOf(title.sort);
                      _headers = [
                        ...headers.slice(0, i).map((item) => {
                          return {
                            ...item,
                            sort: item.sort || item.sort == '' ? '' : null
                          };
                        }),
                        { ...title, sort: ls[(index + 1) % 3] },
                        ...headers.slice(i + 1).map((item) => {
                          return {
                            ...item,
                            sort: item.sort || item.sort == '' ? '' : null
                          };
                        })
                      ];
                      setHeaders(_headers);
                    }}
                    key={i}
                    style={thStyle}>
                    <Flex
                      color="white"
                      fontWeight={'bold'}
                      alignItems="center"
                      justifyContent="flex-start"
                      cursor={'pointer'}>
                      {title.name}
                      {title.sort == '' || title.sort == 'asc' || title.sort == 'desc' ? (
                        <Flex ml={1}>
                          {title.sort == 'asc' ? (
                            <Image w="20px" h="20px" m="2px" src={Ascending} />
                          ) : // <KeyboardDoubleArrowUp style={{ color: 'black' }} />
                          title.sort == 'desc' ? (
                            <Image w="20px" h="20px" m="2px" src={Descending} />
                          ) : (
                            <FilterList style={{ color: `${chakratheme.colors.gray.light}` }} />
                          )}
                        </Flex>
                      ) : null}
                    </Flex>
                  </Th>
                );
              })}
            </Tr>
          </Thead>
          {props.loading ? (
            <Tbody>
              {Array.from(Array(20).keys()).map((item, i) => {
                return (
                  <Tr
                    key={i}
                    _hover={{
                      backgroundColor: `${chakratheme.colors.gray.lighter}`
                    }}
                    style={{
                      padding: '20px 0px',
                      borderBottom: `2px solid ${chakratheme.colors.gray.lighter}`
                    }}>
                    {headers &&
                      headers.map((header, index) => {
                        return (
                          <Td
                            key={index}
                            colSpan={header.colSpan ? header.colSpan : 1}
                            style={tdStyle}>
                            <Skeleton
                              variant="rectangular"
                              style={{
                                width: '90%',
                                height: '20px'
                              }}
                            />
                          </Td>
                        );
                      })}
                  </Tr>
                );
              })}
            </Tbody>
          ) : (
            <Tbody>
              {paginatedData &&
                paginatedData.map((item, i) => (
                  <Tr
                    key={i}
                    _hover={{
                      backgroundColor: `${chakratheme.colors.gray.lighter}`
                    }}
                    style={{
                      padding: '20px 0px',
                      borderBottom: `2px solid ${chakratheme.colors.gray.lighter}`
                    }}>
                    {headers &&
                      headers.map((header, index) => {
                        return (
                          <Td
                            key={index}
                            colSpan={header.colSpan ? header.colSpan : 1}
                            style={tdStyle}>
                            {item[header.id]}
                          </Td>
                        );
                      })}
                  </Tr>
                ))}
            </Tbody>
          )}
        </Table>
      </Box>
      {props.data && props.data.length > 0 && (
        <>
          <Divider />
          <Flex
            style={{
              //   position: "absolute", // Set the Flex's position to absolute
              bottom: '0', // Align the Flex to the bottom
              width: '90%' // Make it take the full width
            }}
            justifyContent="space-between"
            alignItems="center"
            ml={5}>
            <Text>
              {`Showing  ${(props.page - 1) * pageSize + 1} to  ${Math.min(
                props.page * pageSize,
                props.totalProductsCount
              )} of ${props.totalProductsCount} records`}
            </Text>
            <Spacer />
            <Flex justifyContent="flex-end" alignItems="center" mr={10}>
              <Box h="40px" mx={4}>
                <Divider orientation="vertical" />
              </Box>
              <IconButton
                onClick={() => props.setPage(props.page - 1)}
                disabled={props.page === 1}
                size="sm"
                variant="iconOutline">
                <ChevronLeftRounded />
              </IconButton>
              <Text size="sm" p={5}>
                Page {props.page} of {Math.ceil(props.totalProductsCount / pageSize)}
              </Text>
              <IconButton
                variant="iconOutline"
                onClick={() => {
                  if (props.page !== Math.ceil(props.totalProductsCount / pageSize)) {
                    props.setPage(props.page + 1);
                    if (props.page % 5 === 0 || props.page === 1) {
                      props.handlePagination();
                    }
                  }
                }}
                isDisabled={props.page === Math.ceil(props.totalProductsCount / pageSize)}
                size="sm">
                <ChevronRightRounded />
              </IconButton>
            </Flex>
          </Flex>
        </>
      )}
    </Box>
  );
};
export default CustomTable;
