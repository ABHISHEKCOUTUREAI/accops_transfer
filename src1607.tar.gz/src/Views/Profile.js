import { ArrowBackIcon } from '@chakra-ui/icons';
import {
  Button,
  Flex,
  Input,
  Text,
  FormControl,
  FormLabel,
  InputGroup,
  useTheme,
  Container,
  useToast
} from '@chakra-ui/react';
import axios from 'axios';
import Zone from '../Static/zone.png';
import State from '../Static/state.png';
import City from '../Static/city.png';
import Branch from '../Static/store.png';
import NestedFilters from '../components/NestedFilters';

import React, { useEffect, useState } from 'react';
import profileimg from '../Static/profile.jpeg';

const Profile = (props) => {
  const toast = useToast();
  const themee = useTheme();
  const [regions_nested, setRegionsNested] = useState([]);
  const [selectedRegions, setSelectedRegions] = useState(props.selectedRegions);
  const [buttonColor, setButtonColor] = useState(`${themee.colors.primary.main}`);

  const lastIndex = (array) => {
    let i = array.length - 1;
    while (i >= 0 && array[i] === null) {
      i--;
    }
    return i;
  };

  const fetchFilters = () => {
    const formData = new FormData();
    const lastIndexNonNull = lastIndex(selectedRegions);

    if (lastIndexNonNull != -1) formData.append('region_type', props.levelNames[lastIndexNonNull]);
    else formData.append('region_type', null);
    if (lastIndexNonNull != -1) formData.append('region_name', selectedRegions[lastIndexNonNull]);
    else formData.append('region_name', null);
    let configStat = {
      method: 'post',
      url: `${process.env.REACT_APP_API_BASE_URL}/fetch-filters`,
      data: formData
    };
    axios(configStat)
      .then(async (response) => {
        setRegionsNested(response.data.location);
      })
      .catch(function () {
        console.log('error');
      });
  };

  useEffect(() => {
    fetchFilters();
  }, [selectedRegions]);

  console.log('selectedregions', selectedRegions);

  return (
    <Container padding={0}>
      <Flex
        direction="column"
        alignItems="flex-start"
        justifyContent="center"
        width="100%"
        style={{ padding: '40px 100px 20px 100px' }}>
        <Flex w="100%" direction="column" alignItems={'flex-start'} justifyContent={'flex-start'}>
          <Button
            style={{
              background: 'transparent',
              border: `1px solid ${themee.colors.gray.light}`,
              borderColor: `${themee.colors.gray.light}`,
              borderRadius: '20px',
              color: `${themee.colors.black[400]}`,
              fontSize: '14px',
              fontWeight: '400',
              padding: '10px',
              margin: '0px 0 0 0',
              boxShadow: `0 0 0px 0 ${themee.colors.shadow}`
            }}
            onClick={() => {
              props.handleNavigation('/home');
            }}>
            <ArrowBackIcon style={{ marginRight: '20px' }} />
            Go back to Home
          </Button>
        </Flex>
        <Flex position="relative" flexDirection="column" alignItems="center" mt={10} mb="4">
          <Flex>
            <div className="profile-container">
              <img
                src={profileimg}
                alt="model-face"
                style={{
                  borderRadius: '50%',
                  objectFit: 'cover',
                  width: '220px',
                  height: '220px'
                }}
              />
            </div>
            <Flex direction="column" ml="10" alignItems={'center'} justifyContent={'center'}>
              <Text
                style={{
                  fontSize: '40px',
                  fontFamily: 'Raleway',
                  fontWeight: 'bold'
                }}>
                John Doe
              </Text>
            </Flex>
          </Flex>
        </Flex>
        <Flex
          w="100%"
          direction={'column'}
          p={10}
          mt={30}
          borderRadius={'20px'}
          boxShadow={`0 0 10px 0 ${themee.colors.shadow}`}>
          <Text
            style={{
              fontWeight: 'bold',
              fontSize: '20px'
            }}>
            Basic Information
          </Text>
          <FormControl>
            <Flex mt="4">
              <Flex
                w="100%"
                alignItems="flex-start"
                justifyContent={'flex-start'}
                direction={'column'}>
                <FormLabel
                  style={{
                    color: `${themee.colors.gray.main}`,
                    fontWeight: 'bold',
                    fontSize: '16px',
                    marginBottom: '2px'
                  }}>
                  First Name
                </FormLabel>
                <InputGroup>
                  <Input
                    variant={'outline'}
                    backgroundColor={'white'}
                    w="100%"
                    h="40px"
                    borderWidth="1px"
                    borderRadius="10px"
                    color="black"
                    paddingLeft={'10px'}
                    placeholder="Eg. John"
                    _placeholder={{
                      color: `${themee.colors.gray.light}`
                    }}
                    _focus={{
                      outline: 'none'
                    }}
                    // value={_profile.firstName}
                    // onChange={(e) => {
                    //   _setProfile({ ..._profile, firstName: e.target.value });
                    // }}
                  />
                </InputGroup>
              </Flex>
              <Flex
                ml="2"
                w="100%"
                alignItems="flex-start"
                justifyContent={'flex-start'}
                direction={'column'}>
                <FormLabel
                  style={{
                    color: `${themee.colors.gray.main}`,
                    fontWeight: 'bold',
                    fontSize: '16px',
                    marginBottom: '2px'
                  }}>
                  Last Name
                </FormLabel>
                <InputGroup>
                  <Input
                    variant={'outline'}
                    _placeholder={{
                      color: `${themee.colors.gray.light}`
                    }}
                    placeholder="Eg. Doe"
                    w="100%"
                    h="40px"
                    borderRadius="10px"
                    borderWidth="1px"
                    color="black"
                    _focus={{
                      outline: 'none'
                    }}
                    paddingLeft={'10px'}
                    // value={_profile.lastName}
                    // onChange={(e) => {
                    //   _setProfile({ ..._profile, lastName: e.target.value });
                    // }}
                  />
                </InputGroup>
              </Flex>
            </Flex>
          </FormControl>
        </Flex>
        <Flex
          w="100%"
          direction={'column'}
          bg="white"
          p={10}
          mt={30}
          borderRadius={'20px'}
          boxShadow={`0 0 10px 0 ${themee.colors.shadow}`}>
          <Text
            mb={8}
            style={{
              fontWeight: 'bold',
              fontSize: '20px'
            }}>
            Store Details
          </Text>
          <Flex
            w="100%"
            alignItems={'center'}
            h="100%"
            style={{
              borderRadius: '20px',
              boxShadow: `${themee.colors.shadow} 0px 0px 40px 0px`
            }}
            mb="5">
            <NestedFilters
              nestedData={regions_nested}
              type="region"
              levelNames={props.levelNames}
              selectedItems={selectedRegions}
              setSelectedItems={setSelectedRegions}
              onBranchSelected={props.handleSelectedBranch}
              nonedit={localStorage.getItem('role') === 'store manager'}
              icons={{
                Zone: Zone,
                State: State,
                City: City,
                Branch: Branch
              }}></NestedFilters>
          </Flex>
        </Flex>
        <Flex mt={3} w="100%" justifyContent={'flex-end'}>
          <Button
            onClick={() => {
              if (selectedRegions[3]) {
                localStorage.setItem('selectedRegions', selectedRegions);
                props.setSelectedRegions(selectedRegions);
                toast({
                  title: 'Profile saved successfully',
                  status: 'success',
                  duration: 3000,
                  isClosable: true
                });
                // Temporarily change the button color
                setButtonColor(`${themee.colors.primary.hover}`);
                setTimeout(() => {
                  setButtonColor(`${themee.colors.primary.main}`);
                }, 200); // Duration in milliseconds
              } else {
                alert('Select a store code to to save');
              }
            }}
            style={{
              color: 'white',
              padding: '10px 30px',
              borderRadius: '20px',
              boxShadow: 'none',
              fontSize: '14px'
            }}
            background={buttonColor}
            // _hover={{
            //   background: `${themee.colors.primary.hover}`
            // }}
            ml={2}>
            Save Changes
          </Button>
        </Flex>
      </Flex>
    </Container>
  );
};

export default Profile;
