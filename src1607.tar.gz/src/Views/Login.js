import {
  Grid,
  GridItem,
  Image,
  Box,
  Text,
  Button,
  Input,
  Checkbox,
  Flex,
  Spacer,
  Heading,
  VStack,
  useToast
} from '@chakra-ui/react';
import React, { useState } from 'react';
import bgImage from '../Static/loginBg4.jpg';
import logo from '../Static/logo.png';
import { ToggleSelector } from '../components/ToogleSelecctor';

const Login = () => {
  const toast = useToast();
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [role, setRole] = useState('admin');

  const handleLogin = () => {
    if (email !== 'rilpharma@couture.ai') {
      toast({
        title: 'Invalid email address.',
        status: 'error',
        duration: 1000,
        position: 'top',
        isClosable: true
      });
    } else if (password !== 'Rilpharma@2023') {
      toast({
        title: 'Invalid password.',
        status: 'error',
        duration: 1000,
        position: 'top',
        isClosable: true
      });
    } else {
      localStorage.setItem('isLoggedIn', 'true');
      localStorage.setItem('role', role);
      // window.location.pathname = '/assortment/home';
      window.location.pathname = '/assortment/store-assortment';
    }
  };

  return (
    <Grid templateColumns="repeat(2, 1fr)" gap={0}>
      <GridItem w="100%" h="100vh">
        <Box>
          <Box w={'100%'} px={'25%'} pt={'10%'}>
            <Image w="80%" src={logo}></Image>
            <Box pb={'30px'} pt="50px">
              <Heading variant="h4">Welcome Back</Heading>
              <Text variant="body1Regular">Please enter your details</Text>
            </Box>
            <Box id="loginForm">
              <Flex justifyContent={'space-around'} mb={'20px'}>
                <ToggleSelector role={role} toggleCallback={(role) => setRole(role)} />
              </Flex>
              <Box pb={'20px'}>
                <Input
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  variant={'outline'}
                  placeholder={'Email'}></Input>
              </Box>
              <Box pb={'15px'}>
                <Input
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  variant={'outline'}
                  type={'password'}
                  placeholder={'Password'}></Input>
              </Box>
              <Flex pb={'20px'}>
                <Checkbox colorScheme="gray">Remember me</Checkbox>
                <Spacer />
                <Text>Forgot Password?</Text>
              </Flex>
              <Box pb={'20px'}>
                <Button
                  variant={'menuSolid'}
                  bg={'black'}
                  color={'white'}
                  w={'100%'}
                  onClick={handleLogin}>
                  <Text fontSize="md" fontWeight="400">
                    Log in
                  </Text>
                </Button>
              </Box>
              <Flex w={'100%'} justify={'center'} alignItems="center">
                <Text variant="body2">{`Don't have account?`}</Text>
                <Text pl={'4px'} variant="body2semiBold">{`Sign up for free`}</Text>
              </Flex>
            </Box>
          </Box>
        </Box>
      </GridItem>
      <GridItem w="100%" h="100vh">
        <VStack h="100vh" w="100%">
          <Image objectFit="cover" h="100%" w="100%" src={bgImage}></Image>
        </VStack>
      </GridItem>
    </Grid>
  );
};

export default Login;
