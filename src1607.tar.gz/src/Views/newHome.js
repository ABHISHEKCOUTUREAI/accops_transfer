/* eslint-disable no-unused-vars */
/* eslint-disable react/no-unescaped-entities */

import {
  Container,
  Flex,
  Image,
  Spacer,
  Text,
  Box,
  Button,
  Skeleton,
  Menu,
  MenuButton,
  MenuList,
  MenuItemOption,
  useTheme,
  Input,
  InputGroup,
  InputLeftElement,
  InputRightElement,
  ChakraProvider,
  theme,
  Icon,
  Divider
} from '@chakra-ui/react';
import Table from '@mui/material/Table';
import CloseIcon from '@mui/icons-material/Close';
import SearchIcon from '@mui/icons-material/Search';
import TrendingUpIcon from '@mui/icons-material/TrendingUp';
import TableBody from '@mui/material/TableBody';
import TableCell from '@mui/material/TableCell';
import TableContainer from '@mui/material/TableContainer';
import TableHead from '@mui/material/TableHead';
import TableRow from '@mui/material/TableRow';
import Paper from '@mui/material/Paper';
import React, { useEffect, useRef, useState } from 'react';
import axios from 'axios';
import planning from '../Static/planning.png';
import analysis from '../Static/analysis.png';
import past from '../Static/past.png';
import { ArrowForwardIcon, ChevronDownIcon } from '@chakra-ui/icons';
import { Link, useNavigate } from 'react-router-dom';
import MapChart from './IndiaMap/MapChart';
import { fetchPastSales } from '../adapters/analytics';
import { ArrowUpward } from '@mui/icons-material';
import './app.css';
import assortmentHome from '../Static/aassortment-home.png';
import PastSalesGlobal from './PastSalesGlobal';
import { BarChartStates } from '../components/charts/BarChartStates';
import { formatNumber } from '../Utils/formatNumberMillionBillion';
import { LocationContext } from '../Contexts/LocationContext';
const Homenew = () => {
  const { consoleState } = React.useContext(LocationContext);

  const [statewise, setStatewise] = useState([]);
  const [salesData, setSalesData] = useState(null);
  const [search, setSearch] = useState('');
  const [show, setShow] = useState(false);
  const navigate = useNavigate();
  const [salesDataLoading, setSalesDataLoading] = useState(false);
  const inputRef = useRef();

  const isStoreManager = () => {
    return localStorage.getItem('role') === 'store manager';
  };

  useEffect(() => {
    if (isStoreManager()) navigate('/store-assortment');
  }, []);
  useEffect(() => {
    setSalesDataLoading(true);
    fetchPastSales(consoleState).then((data) => {
      setSalesData(data);
      console.log('salesData', data);
      setSalesDataLoading(false);
    });
  }, []);

  const [totalRevenue, setTotalRevenue] = useState(0);
  const [totalMargin, setTotalMargin] = useState(0);
  const [totalQuantity, setTotalQuantity] = useState(0);
  const [totalStore, setTotalStore] = useState(0);

  useEffect(() => {
    let configStat = {
      method: 'get',
      url: `${consoleState.state.api.BASE_URL}${consoleState.state.api.MAP}`
    };
    axios(configStat)
      .then(async (response) => {
        setStatewise(response.data.state);
        setTotalMargin(response.data.total_margin);
        setTotalRevenue(response.data.total_revenue);
        setTotalQuantity(response.data.total_quantity_sold);
        setTotalStore(response.data.total_store);
      })
      .catch(function () {
        console.log('error');
      });
  }, []);

  const formatInternationalStandard = (num) => {
    // remove decimal from number
    const numStr = num.toString().split('.')[0];
    // add commas to number
    return numStr.replace(/(\d)(?=(\d{3})+(?!\d))/g, '$1,');
  };

  const cardNames = ['margin', 'sales', 'stores'];
  const cardMap = {
    margin: {
      name: 'Total Margin',
      value: totalMargin,
      change: '2.5%',
      description: 'from the last month',
      ext: consoleState.state.currency || '$'
    },
    sales: {
      name: 'Total Quantity Sold',
      value: totalQuantity,
      change: '2.5%',
      description: 'from the last month',
      ext: ''
    },
    stores: {
      name: 'Total Stores',
      value: totalStore,
      change: '10%',
      description: 'from the last month',
      ext: ''
    }
  };
  const [topPerformersCriteria, setTopPerformersCriteria] = useState('Revenue');
  const topPerformersCriteriaMap = {
    Revenue: {
      id: 'revenue',
      ext: consoleState.state.currency || '$'
    },
    Margin: {
      id: 'margin',
      ext: consoleState.state.currency || '$'
    },
    'Quantity Sold': {
      id: 'quantity_sold',
      ext: ' # '
    }
  };
  const [graphDuration, setGraphDuration] = useState({
    revenue: 100,
    margin: 100
  });
  const durationList = [3, 6, 12, 100];

  const cards = {
    [consoleState.state.constants.homepage.ASSORTMENT_CARD]: [
      'Click to view Store level Assortment details',
      `/store-assortment`,
      planning
    ],
    [consoleState.state.constants.homepage.ANALYSIS_CARD]: [
      'Click to view Store level Assortment comparative analysis with respect to past Assortment',
      `/assortment-analysis`,
      analysis
    ],
    [consoleState.state.constants.homepage.CUSTOM_CARD]: [
      'Visualise the probabibility of a product getting sold',
      `/assortment-custom`,
      past
    ]
  };
  const chakratheme = useTheme();

  return (
    <Container style={{ padding: '20px 40px 20px 40px' }} bg="white">
      {!isStoreManager() && (
        <ChakraProvider theme={theme}>
          <>
            <Flex h={'calc(100vh - 100px)'} direction="column">
              <Flex w="100%">
                <Spacer />
                <Image src={assortmentHome} height="45vh" zIndex={0} />
                <Flex direction="column" position={'absolute'}>
                  <Text
                    style={{
                      fontSize: '60px',
                      fontWeight: 'bold',
                      fontFamily: 'Hanken Grotesk',
                      marginTop: '20px'
                    }}>
                    {consoleState.state.homeScreenTitle}
                  </Text>
                  <Text
                    mt={4}
                    fontFamily={'Hanken Grotesk'}
                    w="600px"
                    style={{ color: 'primary.main' }}
                    // color="primary.lighter"
                    fontWeight={'regular'}
                    fontSize={18}>
                    Elevate Retail Merchandising and Business Performance
                  </Text>

                  <Flex
                    position={'absolute'}
                    zIndex={1000}
                    w="100%"
                    onClick={() => {
                      setShow(true);
                    }}>
                    <Flex direction={'column'} position={'relative'} top={'220px'} left={0}>
                      <Flex align="center" gap={'10px'}>
                        <InputGroup size="lg" w="75vw">
                          <InputLeftElement>
                            <Icon as={SearchIcon} fontSize={'16px'} />
                          </InputLeftElement>
                          <Input
                            bg="white"
                            borderColor={chakratheme.colors.gray[200]}
                            color={chakratheme.colors.gray.dark}
                            border="0px"
                            boxShadow={`${chakratheme.colors.shadow} 0px 0px 10px 0px, ${chakratheme.colors.shadow} 0px 0px 10px 0px`}
                            borderBottom={show && '0'}
                            borderTopLeftRadius={show ? '25px' : '50px'}
                            borderTopRightRadius={show ? '25px' : '50px'}
                            borderBottomLeftRadius={show ? '0' : '50px'}
                            borderBottomRightRadius={show ? '0' : '50px'}
                            fontSize={'18px'}
                            mr={'5px'}
                            _focus={{
                              border: '0px',
                              borderColor: chakratheme.colors.gray[200], // Use the default border color on focus
                              boxShadow: 'none', // Remove the focus shadow
                              bg: chakratheme.colors.gray[50]
                            }}
                            value={search}
                            placeholder="Search for any data across Store Assortments & Forecasts."
                            onChange={(e) => {
                              setSearch(e.target.value);
                            }}
                            onKeyDown={(e) => {
                              if (e.key === 'Enter') {
                                navigate('/assistant', {
                                  state: {
                                    query: e.target.value
                                  }
                                });
                              }
                            }}
                            ref={inputRef}
                            onFocus={() => {
                              setShow(true);
                            }}
                            onBlur={() => {
                              setTimeout(() => {
                                setShow(false);
                              }, 200);
                            }}
                          />
                          {search !== '' && (
                            <InputRightElement cursor={'pointer'}>
                              <Icon
                                as={CloseIcon}
                                fontSize={'16px'}
                                mr={'5px'}
                                onClick={() => {
                                  setSearch('');
                                }}
                              />
                            </InputRightElement>
                          )}
                        </InputGroup>
                      </Flex>
                      {show && (
                        <Flex
                          h="auto"
                          w={'calc(75vw - 5px)'}
                          p={2}
                          pb="15px"
                          bg={chakratheme.colors.gray[50]}
                          borderBottomLeftRadius="50px"
                          borderBottomRightRadius="50px"
                          direction="column"
                          boxShadow={`${chakratheme.colors.shadow} 0px 0px 10px 0px`}>
                          <Flex w="100%" justifyContent="center" mb="15px">
                            <Divider borderColor={chakratheme.colors.gray[200]} w="90%" />
                          </Flex>

                          <Flex gap="20px">
                            <Flex w="50%" direction="column" fontSize="12px" gap="10px" p={'10px'}>
                              <Flex
                                cursor="pointer"
                                align="center"
                                gap="10px"
                                onClick={() => {
                                  navigate('/assistant', {
                                    state: {
                                      query:
                                        'What is the top 5 products at the store 6R36T3 with the highest GMROI?'
                                    }
                                  });
                                }}>
                                <Icon as={TrendingUpIcon} />
                                <Text>
                                  What is the top 5 products at the store 6R36T3 with the highest
                                  GMROI?
                                </Text>
                              </Flex>
                              <Flex
                                cursor="pointer"
                                align="center"
                                gap="10px"
                                onClick={() => {
                                  navigate('/assistant', {
                                    state: {
                                      query: 'What is the ROI on products similar to CROCIN?'
                                    }
                                  });
                                }}>
                                <Icon as={TrendingUpIcon} />
                                <Text>What is the ROI on products similar to CROCIN?</Text>
                              </Flex>
                              <Flex
                                cursor="pointer"
                                align="center"
                                gap="10px"
                                onClick={() => {
                                  navigate('/assistant', {
                                    state: {
                                      query: 'What is the Stock-Out Rate for CROCIN like products?'
                                    }
                                  });
                                }}>
                                <Icon as={TrendingUpIcon} />
                                <Text>What is the Stock-Out Rate for CROCIN like products?</Text>
                              </Flex>
                              <Flex
                                cursor="pointer"
                                align="center"
                                gap="10px"
                                onClick={() => {
                                  navigate('/assistant', {
                                    state: {
                                      query:
                                        'What is the daily sales number between November and December 2015'
                                    }
                                  });
                                }}>
                                <Icon as={TrendingUpIcon} />
                                <Text>
                                  What is the daily sales number between November and December 2015
                                </Text>
                              </Flex>
                              <Flex
                                cursor="pointer"
                                align="center"
                                gap="10px"
                                onClick={() => {
                                  navigate('/assistant', {
                                    state: {
                                      query:
                                        'What are the 5 products at the store 3N93T9 with the highest number of orders?'
                                    }
                                  });
                                }}>
                                <Icon as={TrendingUpIcon} />
                                <Text>
                                  What are the 5 products at the store 3N93T9 with the highest
                                  number of orders?
                                </Text>
                              </Flex>
                              <Flex
                                cursor="pointer"
                                align="center"
                                gap="10px"
                                onClick={() => {
                                  navigate('/assistant', {
                                    state: {
                                      query:
                                        'What are the top 15 products projected to sell well next month?'
                                    }
                                  });
                                }}>
                                <Icon as={TrendingUpIcon} />
                                <Text>
                                  What are the top 15 products projected to sell well next month?
                                </Text>
                              </Flex>
                            </Flex>

                            <Flex w="50%" direction="column" fontSize="10px" gap="10px" wrap="wrap">
                              <Flex>
                                <Text>Suggestions</Text>
                              </Flex>
                              <Flex
                                w="100%"
                                wrap="wrap"
                                columnGap="20px"
                                gap="20px"
                                fontSize="12px">
                                <Flex
                                  cursor="pointer"
                                  w="40%"
                                  bg="white"
                                  boxShadow={`${chakratheme.colors.shadow} 0px 0px 10px 0px`}
                                  p="10px"
                                  onClick={() => {
                                    navigate('/assistant', {
                                      state: {
                                        query:
                                          'Could you plot a chart between stock-out rate and ROI for 50 different products, to see if there is any correlation?'
                                      }
                                    });
                                  }}>
                                  <span>
                                    <span>
                                      Could you plot a chart between stock-out rate and ROI for 50
                                      different products, to see if there is any correlation?
                                    </span>
                                  </span>
                                </Flex>
                                <Flex
                                  cursor="pointer"
                                  w="40%"
                                  bg="white"
                                  boxShadow={`${chakratheme.colors.shadow} 0px 0px 10px 0px`}
                                  p="10px"
                                  onClick={() => {
                                    navigate('/assistant', {
                                      state: {
                                        query:
                                          'Could you show the correlation between stock-out rate and ROI for 50 different products with positive stock-out rate?'
                                      }
                                    });
                                  }}>
                                  <span>
                                    <span>
                                      Could you show the correlation between stock-out rate and ROI
                                      for 50 different products with positive stock-out rate?
                                    </span>
                                  </span>
                                </Flex>
                                <Flex
                                  cursor="pointer"
                                  w="40%"
                                  bg="white"
                                  boxShadow={`${chakratheme.colors.shadow} 0px 0px 10px 0px`}
                                  p="10px"
                                  onClick={() => {
                                    navigate('/assistant', {
                                      state: {
                                        query:
                                          'What is the GMROI on VEET HAIR REMOVAL CREAM - NORMAL SKIN 100 GM'
                                      }
                                    });
                                  }}>
                                  <span>
                                    <span>
                                      What is the GMROI on VEET HAIR REMOVAL CREAM - NORMAL SKIN 100
                                      GM
                                    </span>
                                  </span>
                                </Flex>

                                <Flex
                                  cursor="pointer"
                                  w="40%"
                                  bg="white"
                                  boxShadow={`${chakratheme.colors.shadow} 0px 0px 10px 0px`}
                                  p="10px"
                                  onClick={() => {
                                    navigate('/assistant', {
                                      state: {
                                        query:
                                          'Show the correlation between the revenue generated in different zones and the number of stores in that zone'
                                      }
                                    });
                                  }}>
                                  <span>
                                    <span>
                                      Show the correlation between the revenue generated in
                                      different zones and the number of stores in that zone
                                    </span>
                                  </span>
                                </Flex>
                                <Flex
                                  cursor="pointer"
                                  w="40%"
                                  bg="white"
                                  boxShadow={`${chakratheme.colors.shadow} 0px 0px 10px 0px`}
                                  p="10px"
                                  onClick={() => {
                                    navigate('/assistant', {
                                      state: {
                                        query:
                                          'Get the distribution chart of “Retail price” of each “Segment”.'
                                      }
                                    });
                                  }}>
                                  <span>
                                    <span>
                                      Get the distribution chart of “Retail price” of each “Segment
                                    </span>
                                  </span>
                                </Flex>
                                <Flex
                                  cursor="pointer"
                                  w="40%"
                                  bg="white"
                                  boxShadow={`${chakratheme.colors.shadow} 0px 0px 10px 0px`}
                                  p="10px"
                                  onClick={() => {
                                    navigate('/assistant', {
                                      state: {
                                        query:
                                          'What are the top 15 products projected to sell well next month?'
                                      }
                                    });
                                  }}>
                                  <span>
                                    <span>
                                      What are the top 15 products projected to sell well next
                                      month?
                                    </span>
                                  </span>
                                </Flex>
                              </Flex>
                            </Flex>
                          </Flex>
                        </Flex>
                      )}
                    </Flex>
                  </Flex>
                </Flex>
              </Flex>
              {/* ['Give top 5 items', ' with maximum existing inventory'], ['What are the top
                        5 items with', ' the highest bounce rates along with product names'], ['What
                        is the revenue generated', ' in each zone?'], ['What is the revenue
                        generated', ' in in each distribution center ?'] */}
              <Flex justifyContent={'space-between'} mt={10}>
                {Object.keys(cards).map((e) => (
                  <Flex
                    className="parent"
                    style={{
                      padding: '0px',
                      fontSize: '40px',
                      boxShadow: `${chakratheme.colors.shadow} 0px 0px 20px 10px`,
                      borderRadius: '20px'
                    }}
                    _hover={{
                      backgroundColor: 'white'
                    }}
                    key={e}
                    w="32%">
                    <Image w="200px" h="100%" src={cards[e][2]} mr={2} />
                    <Flex direction={'column'} padding={'20px 10px 20px 10px'}>
                      <Text ml={0} style={{ color: 'black', fontWeight: 'bold', fontSize: '17px' }}>
                        {e}
                      </Text>
                      <div style={{ color: 'grey', fontSize: '13px' }}>{cards[e][0]}</div>
                      <Spacer />
                      <Link to={cards[e][1]}>
                        <a
                          href={cards[e][1]}
                          className="get-started-button"
                          style={{ background: chakratheme.colors.primary.main }}>
                          <span className="icon">
                            <ArrowForwardIcon />
                          </span>
                          <span className="text">Get Started</span>
                        </a>
                      </Link>
                    </Flex>
                  </Flex>
                ))}
              </Flex>
            </Flex>
            <Flex direction="column" id="overview">
              <Text
                style={{
                  fontSize: '25px',
                  fontFamily: 'Poppins',
                  fontWeight: 'bold',
                  marginTop: '30px'
                }}>
                Overview
              </Text>
              <Box
                w="100px"
                h="5px"
                bg={`${chakratheme.colors.primary.main}`}
                borderRadius="3px"
                mt={2}
              />
            </Flex>
            <Flex>
              <Flex
                margin="5px"
                w="25%"
                direction="column"
                mt={10}
                style={{
                  backgroundColor: `${chakratheme.colors.heroColor}`,
                  color: 'white',
                  padding: '20px',
                  borderRadius: '20px',
                  fontFamily: 'Hanken Grotesk'
                }}>
                <Text fontWeight={'bold'} mb="20px">
                  Total Revenue
                </Text>
                <Flex alignItems={'center'} wrap="wrap">
                  <Text fontSize={'36px'}>
                    {`${consoleState.state.currency || '$'} ${formatInternationalStandard(totalRevenue)}`}
                  </Text>
                  <Flex
                    ml={2}
                    padding="2px 10px"
                    fontSize={'12px'}
                    borderRadius={'10px'}
                    alignItems="center"
                    fontWeight={'bold'}
                    color={`${chakratheme.colors.success.main}`}
                    backgroundColor={`${chakratheme.colors.success.light}`}>
                    <ArrowUpward style={{ fontSize: '15px' }} /> <Text>12.5%</Text>
                  </Flex>
                </Flex>
                <Text
                  style={{
                    fontSize: '15px',
                    // color: `${chakratheme.colors.black[400]}`,
                    color: 'white',
                    marginTop: '10px',
                    fontStyle: 'italic'
                  }}>
                  from the last month
                </Text>
              </Flex>
              {cardNames.map((card) => (
                <Flex
                  key={card}
                  w="25%"
                  margin="5px"
                  direction="column"
                  mt={10}
                  style={{
                    backgroundColor: 'white',
                    color: 'black',
                    boxShadow: `${chakratheme.colors.shadow} 0px 0px 20px 0px`,
                    padding: '20px',
                    borderRadius: '20px',
                    fontFamily: 'Hanken Grotesk'
                  }}>
                  <Text fontWeight={'bold'} mb="20px">
                    {cardMap[card].name}
                  </Text>
                  <Flex alignItems={'center'} wrap="wrap">
                    <Text fontSize={'36px'}>
                      {cardMap[card].ext}
                      {formatInternationalStandard(cardMap[card].value)}
                    </Text>
                    <Flex
                      ml={2}
                      padding="2px 10px"
                      fontSize={'12px'}
                      borderRadius={'10px'}
                      alignItems="center"
                      fontWeight={'bold'}
                      color={`${chakratheme.colors.success.main}`}
                      backgroundColor={`${chakratheme.colors.success.light}`}>
                      <ArrowUpward style={{ fontSize: '15px' }} />{' '}
                      <Text>{cardMap[card].change}</Text>
                    </Flex>
                  </Flex>
                  <Text
                    style={{
                      fontSize: '15px',
                      color: `${chakratheme.colors.gray.light}`,
                      marginTop: '10px',
                      fontStyle: 'italic'
                    }}>
                    from the last month
                  </Text>
                </Flex>
              ))}
            </Flex>

            {salesDataLoading ? (
              <Skeleton w="100%" h="500px"></Skeleton>
            ) : (
              <Flex mt="40px" justifyContent={'space-between'} gap="10px">
                {['revenue', 'margin'].map((card) => (
                  <Flex
                    key={card}
                    mr="20px"
                    width="35%"
                    direction="column"
                    padding="20px"
                    style={{
                      boxShadow: `0 0 20px 0 ${chakratheme.colors.shadow}`,
                      borderRadius: '20px'
                    }}>
                    <Flex justifyContent={'center'} alignItems="center">
                      <Text
                        style={{
                          fontFamily: 'Poppins',
                          fontWeight: 'bold'
                        }}>
                        Total {card.charAt(0).toUpperCase() + card.slice(1)}
                        <span
                          style={{
                            color: `${chakratheme.colors.gray.light}`,
                            fontWeight: 'normal'
                          }}>
                          {' '}
                          over time
                        </span>
                      </Text>
                      <Spacer />
                      <Menu matchWidth={true}>
                        <MenuButton
                          as={Button}
                          sx={{
                            display: 'flex',
                            width: '100px',
                            alignItems: 'center',
                            backgroundColor: `${chakratheme.colors.gray.lighter}`,
                            borderRadius: '20px',
                            padding: '5px 10px'
                          }}
                          // leftIcon={view === 'module' ? <ViewModule /> : <ViewList />}
                          rightIcon={
                            <ChevronDownIcon color={`${chakratheme.colors.gray.darker}`} />
                          }>
                          <Text color={`${chakratheme.colors.gray.darker}`} fontSize={'12px'}>
                            {' '}
                            {graphDuration[card] === 100
                              ? 'All time'
                              : `${graphDuration[card]} months`}{' '}
                          </Text>
                        </MenuButton>
                        <MenuList
                          alignItems={'center'}
                          onMouseEnter={(e) => {
                            e.stopPropagation();
                          }}
                          zIndex="100"
                          fontSize={'12px'}
                          borderRadius={'10px'}
                          paddingTop="10px"
                          paddingBottom="10px"
                          backgroundColor={'white'}
                          boxShadow={`0 0 10px 0 ${chakratheme.colors.shadow}`}>
                          {durationList.map((duration) => (
                            <MenuItemOption
                              cursor="pointer"
                              _hover={{
                                backgroundColor: `${chakratheme.colors.gray[300]}`
                              }}
                              key={duration}
                              value={duration}
                              onClick={(e) => {
                                e.stopPropagation();
                                setGraphDuration((prev) => ({ ...prev, [card]: duration }));
                              }}>
                              {duration === 100 ? 'All time' : `${duration} months`}
                            </MenuItemOption>
                          ))}
                        </MenuList>
                      </Menu>
                    </Flex>
                    <PastSalesGlobal
                      duration={graphDuration[card]}
                      salesData={card == 'revenue' ? salesData?.revenue : salesData?.margin}
                      name={card}
                    />
                  </Flex>
                ))}
                <Box
                  width="30%"
                  direction="column"
                  padding="20px"
                  style={{
                    backgroundColor: `${chakratheme.colors.gray.lighter}`,
                    borderRadius: '20px'
                  }}
                  h="auto">
                  <Box ml={4} mb="20px">
                    <Text
                      style={{
                        fontFamily: 'Poppins',
                        fontWeight: 'bold'
                      }}>
                      Revenue by State
                    </Text>
                  </Box>
                  <MapChart statesData={statewise} chakratheme={chakratheme}></MapChart>
                </Box>
              </Flex>
            )}
            <Flex
              mt="20px"
              direction="column"
              // ml="30px"
              // direction="column"
              style={{
                width: '100%',
                padding: '20px',
                borderRadius: '20px',
                boxShadow: `${chakratheme.colors.shadow} 0px 0px 20px 0px`
              }}>
              <Text
                style={{
                  // fontSize: '25px',
                  fontFamily: 'Poppins',
                  fontWeight: 'bold'
                }}>
                Top Performing States
              </Text>
              <Flex mt="10px" justifyContent={''}>
                {['Revenue', 'Quantity Sold'].map((card) => (
                  <Button
                    key="card"
                    onClick={() => {
                      setTopPerformersCriteria(card);
                    }}
                    mr="10px"
                    _hover={{
                      backgroundColor:
                        topPerformersCriteria == card
                          ? `${chakratheme.colors.heroColor} !important`
                          : `${chakratheme.colors.gray[300]} !important`
                    }}
                    style={{
                      borderRadius: '20px',
                      padding: '5px 20px',
                      backgroundColor:
                        topPerformersCriteria == card
                          ? `${chakratheme.colors.heroColor}`
                          : `${chakratheme.colors.gray.lighter}`,
                      color: topPerformersCriteria == card ? 'white' : 'black',
                      fontFamily: 'Montserrat'
                    }}>
                    {card}
                  </Button>
                ))}
              </Flex>
              <Flex>
                <Flex direction="column">
                  <Flex>
                    <TableContainer
                      component={Paper}
                      style={{
                        marginTop: '20px',
                        borderRadius: '4px',
                        boxShadow: 'rgb(231, 231, 231) 0px 0px 4px 0px'
                      }}>
                      <Table sx={{ minWidth: 650 }} aria-label="simple table">
                        <TableHead>
                          {topPerformersCriteria == 'Revenue' ? (
                            <TableRow>
                              <TableCell>State</TableCell>

                              <TableCell align="right">{topPerformersCriteria}</TableCell>
                              <TableCell align="right">Margin</TableCell>
                              <TableCell align="right">Margin Percent</TableCell>
                            </TableRow>
                          ) : (
                            <TableRow>
                              <TableCell>State</TableCell>

                              <TableCell align="right">{topPerformersCriteria}</TableCell>
                              <TableCell align="right">
                                {topPerformersCriteria} as % of whole
                              </TableCell>
                            </TableRow>
                          )}
                        </TableHead>
                        <TableBody>
                          {statewise
                            .toSorted(
                              (a, b) =>
                                -parseInt(a[topPerformersCriteriaMap[topPerformersCriteria].id]) +
                                parseInt(b[topPerformersCriteriaMap[topPerformersCriteria].id])
                            )
                            .slice(0, 5)
                            .map((row, id) => {
                              const _data = {
                                Revenue: row.revenue,
                                Margin: row.margin,
                                'Quantity Sold': row.quantity_sold,
                                'Total Revenue': statewise.reduce(
                                  (acc, curr) =>
                                    acc + (parseInt(curr.revenue) ? parseInt(curr.revenue) : 0),
                                  0
                                ),
                                'Total Margin': statewise.reduce(
                                  (acc, curr) =>
                                    acc + (parseInt(curr.margin) ? parseInt(curr.margin) : 0),
                                  0
                                ),
                                'Total Quantity Sold': statewise.reduce(
                                  (acc, curr) =>
                                    acc +
                                    (parseInt(curr.quantity_sold)
                                      ? parseInt(curr.quantity_sold)
                                      : 0),
                                  0
                                )
                              };
                              console.log('_data', _data);
                              return topPerformersCriteria == 'Revenue' ? (
                                <TableRow
                                  key={id}
                                  sx={{ '&:last-child td, &:last-child th': { border: 0 } }}>
                                  <TableCell component="th" scope="row">
                                    {row.state.charAt(0).toUpperCase() + row.state.slice(1)}
                                  </TableCell>
                                  <TableCell align="right">
                                    {formatNumber(Math.floor(row.revenue))}
                                  </TableCell>
                                  <TableCell align="right">
                                    {formatNumber(Math.floor(row.margin))}
                                  </TableCell>
                                  <TableCell align="right">
                                    {((parseInt(row.margin) / parseInt(row.revenue)) * 100).toFixed(
                                      2
                                    )}
                                    %
                                  </TableCell>
                                </TableRow>
                              ) : (
                                <TableRow
                                  key={id}
                                  sx={{ '&:last-child td, &:last-child th': { border: 0 } }}>
                                  <TableCell component="th" scope="row">
                                    {row.state.charAt(0).toUpperCase() + row.state.slice(1)}
                                  </TableCell>
                                  <TableCell align="right">
                                    {formatNumber(Math.floor(_data[topPerformersCriteria]))}
                                  </TableCell>
                                  <TableCell align="right">
                                    {(
                                      (parseInt(_data[topPerformersCriteria]) /
                                        _data[`Total ${topPerformersCriteria}`]) *
                                      100
                                    ).toFixed(2)}
                                    %
                                  </TableCell>
                                </TableRow>
                              );
                            })}
                        </TableBody>
                      </Table>
                    </TableContainer>
                  </Flex>
                </Flex>
                <Flex
                  ml="30px"
                  direction="column"
                  style={{
                    width: '50%',
                    padding: '20px',
                    borderRadius: '20px',
                    backgroundColor: `${chakratheme.colors.gray.lighter}`
                  }}>
                  {statewise.length ? (
                    topPerformersCriteria == 'Revenue' ? (
                      <BarChartStates
                        id="revenue"
                        data1={statewise
                          .toSorted(
                            (a, b) =>
                              -parseInt(a[topPerformersCriteriaMap[topPerformersCriteria].id]) +
                              parseInt(b[topPerformersCriteriaMap[topPerformersCriteria].id])
                          )
                          .slice(0, 5)
                          .map((row) => row.revenue)}
                        data2={statewise
                          .toSorted(
                            (a, b) =>
                              -parseInt(a[topPerformersCriteriaMap[topPerformersCriteria].id]) +
                              parseInt(b[topPerformersCriteriaMap[topPerformersCriteria].id])
                          )
                          .slice(0, 5)
                          .map((row) => row.margin)}
                        labels={statewise
                          .sort(
                            (a, b) =>
                              -parseInt(a[topPerformersCriteriaMap[topPerformersCriteria].id]) +
                              parseInt(b[topPerformersCriteriaMap[topPerformersCriteria].id])
                          )
                          .slice(0, 5)
                          .map((row) => {
                            return row.state.charAt(0).toUpperCase() + row.state.slice(1);
                          })}
                      />
                    ) : (
                      <BarChartStates
                        id="quantity_sold"
                        data1={
                          statewise
                            .toSorted(
                              (a, b) =>
                                -parseInt(a[topPerformersCriteriaMap[topPerformersCriteria].id]) +
                                parseInt(b[topPerformersCriteriaMap[topPerformersCriteria].id])
                            )
                            .slice(0, 5)
                            .map((row) => row.quantity_sold) || []
                        }
                        labels={
                          statewise
                            .toSorted(
                              (a, b) =>
                                -parseInt(a[topPerformersCriteriaMap[topPerformersCriteria].id]) +
                                parseInt(b[topPerformersCriteriaMap[topPerformersCriteria].id])
                            )
                            .slice(0, 5)
                            .map((row) => {
                              return row.state.charAt(0).toUpperCase() + row.state.slice(1);
                            }) || []
                        }
                      />
                    )
                  ) : null}
                </Flex>
              </Flex>
            </Flex>
          </>
        </ChakraProvider>
      )}
    </Container>
  );
};

export default Homenew;
