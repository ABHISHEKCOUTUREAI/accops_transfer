/* eslint-disable no-unused-vars */
/* eslint-disable react/no-unescaped-entities */
import { Container, Text, Box, Flex, useTheme, Skeleton } from '@chakra-ui/react';
import React, { useContext, useEffect, useState } from 'react';
import axios from 'axios';
import AssortmentTable from '../components/Table';
import { Button as ButtonJoy, ThemeProvider } from '@mui/joy';
import { Tune } from '@mui/icons-material';
import { createTheme } from '@mui/material';
// import HomeFilters from './HomeFilters';
import DrawerFilters from './DrawerFilters';
// import topCategories from './market-trends';
import PieeChart from '../Artifactory/Charts/PieChart';
import { Tab } from '@mui/material';
import { TabPanel, TabContext, TabList } from '@mui/lab';
import { LocationContext } from '../Contexts/LocationContext';
import { HourglassTop } from '@mui/icons-material';

const MarketTrends = (props) => {
  const chakratheme = useTheme();
  const { consoleState } = useContext(LocationContext);
  const [categoryNested, setCategoryNested] = useState([]);
  const [page1, setPage1] = useState(1);
  const [page2, setPage2] = useState(1);
  const [sortBy2, setSortBy2] = useState('aiocd_level_rank');
  const [sortOrder2, setSortOrder2] = useState('');
  const [totalProductsCount, setTotalProductsCount] = useState();
  const [totalProductsCount2, setTotalProductsCount2] = useState();
  const [selectedTab, setSelectedTab] = useState(
    consoleState.state.features.marketTrends?.[0].toLowerCase() || null
  );

  const categoryLevelNames = ['Filter level', 'L0', 'L1', 'L2', 'L3', 'Sap ID'];

  const [selectedCategories, setSelectedCategories] = useState([
    ...Array(categoryLevelNames.length).fill(null)
  ]);

  const [iqvia_data, set_iqvia_data] = useState([]);
  const [iqvialoading, setiqvialoading] = useState(false);

  const [aiocd_data, set_aiocd_data] = useState([]);
  const [aiocdloading, setaiocdloading] = useState(false);

  const [headers, setHeaders] = useState([
    {
      name: 'SBU',
      id: 'L0',
      sort: '',
      colSpan: 2
    },
    {
      name: 'Family',
      id: 'L1',
      sort: '',
      colSpan: 3,
      type: 'text'
    },
    {
      name: 'Class',
      id: 'L2',
      sort: '',
      colSpan: 3
    },
    {
      name: 'Segment',
      id: 'L3',
      sort: '',
      colSpan: 3
    },
    {
      name: 'Product ID',
      id: 'sap_id',
      sort: '',
      colSpan: 3
    },
    {
      name: 'Item Name',
      id: 'item_name',
      sort: '',
      colSpan: 3
    },
    {
      name: 'Iqvia Revenue',
      id: 'iqvia_revenue',
      sort: '',
      colSpan: 2
    },
    {
      name: 'Revenue',
      id: 'revenue',
      sort: '',
      colSpan: 3
    },
    {
      name: 'Fractional Revenue',
      id: 'fraction_revenue',
      sort: '',
      colSpan: 3
    },
    {
      name: 'Level Rank',
      id: 'internal_level_rank',
      sort: '',
      colSpan: 2
    },
    {
      name: 'Iqvia Level Rank',
      id: 'iqvia_level_rank',
      sort: 'desc',
      colSpan: 3
    }
  ]);
  const _assortmentTableState = {
    filtersData: {
      filter_type: consoleState.state?.assortmentTable?.defaults.filterData.filter_type || '',
      filter_params: []
    },
    searchData: headers.reduce((acc, header) => {
      if (header.search) acc[header.search_variable] = '';
      return acc;
    }, {}),
    sortData: {
      sort_param: 'qty_sold',
      sort_type: 'desc'
    }
  };
  const [assortmentTableState, setAssortmentTableState] = useState(_assortmentTableState);

  const aiocd_sales = () => {
    setaiocdloading(true);
    const formData = new FormData();
    if (selectedCategories[0]) formData.append('ranking_level', selectedCategories[0]);
    if (selectedCategories[1]) formData.append('L0', selectedCategories[1]);
    if (selectedCategories[2]) formData.append('L1', selectedCategories[2]);
    if (selectedCategories[3]) formData.append('L2', selectedCategories[3]);
    if (selectedCategories[4]) formData.append('L3', selectedCategories[4]);
    if (selectedCategories[5]) formData.append('sap_id', selectedCategories[5]);
    formData.append('page_no', 1);
    sortBy2 !== ''
      ? formData.append('sort_param', sortBy2)
      : formData.append('sort_param', 'aiocd_level_rank');
    sortOrder2 !== ''
      ? formData.append('sort_type', sortOrder2)
      : formData.append('sort_type', 'desc');

    let config = {
      method: 'post',
      url: `${consoleState.state.api.BASE_URL}${consoleState.state.api.AIOCD_SALES}`,
      data: formData
    };

    axios(config)
      .then(async (response) => {
        set_aiocd_data(response.data.aiocd_sales_result);
        setTotalProductsCount2(response.data.aiocd_sales_count);
        setaiocdloading(false);
      })
      .catch(function () {
        setaiocdloading(false);
        console.log('error');
      });
  };

  const [topCategories, setTopCategories] = useState();

  useEffect(() => {
    let configStat = {
      method: 'get',
      url: `${consoleState.state.api.BASE_URL}${consoleState.state.api.MARKET_TREND}`
    };
    axios(configStat)
      .then(async (response) => {
        setTopCategories(response.data);
      })
      .catch(function () {
        console.log('error');
      });
  }, []);

  const handlePagination1 = () => {
    if (totalProductsCount2 === aiocd_data.length || page2 < Math.floor(aiocd_data.length / 100)) {
      return;
    }

    const formData = new FormData();
    if (selectedCategories[0]) formData.append('ranking_level', selectedCategories[0]);
    if (selectedCategories[1]) formData.append('L0', selectedCategories[1]);
    if (selectedCategories[2]) formData.append('L1', selectedCategories[2]);
    if (selectedCategories[3]) formData.append('L2', selectedCategories[3]);
    if (selectedCategories[4]) formData.append('L3', selectedCategories[4]);
    if (selectedCategories[5]) formData.append('sap_id', selectedCategories[5]);
    // formData.append("page_no", page1+1);
    formData.append('page_no', page2 === 1 ? 2 : Math.floor(page2 / 5) + 2);
    sortBy2 !== ''
      ? formData.append('sort_param', sortBy2)
      : formData.append('sort_param', 'aiocd_level_rank');
    sortOrder2 !== ''
      ? formData.append('sort_type', sortOrder2)
      : formData.append('sort_type', 'desc');

    let config = {
      method: 'post',
      url: `${consoleState.state.api.BASE_URL}${consoleState.state.api.SALES_FILTER}`,
      data: formData
    };

    axios(config)
      .then(async (response) => {
        set_aiocd_data((prevData) => [...prevData, ...response.data.aiocd_sales_result]);
        setTotalProductsCount2(response.data.aiocd_sales_count);
      })
      .catch(function () {
        console.log('error');
      });
  };

  const iqvia_sales = () => {
    setiqvialoading(true);
    const formData = new FormData();
    if (selectedCategories[0]) formData.append('ranking_level', selectedCategories[0]);
    if (selectedCategories[1]) formData.append('L0', selectedCategories[1]);
    if (selectedCategories[2]) formData.append('L1', selectedCategories[2]);
    if (selectedCategories[3]) formData.append('L2', selectedCategories[3]);
    if (selectedCategories[4]) formData.append('L3', selectedCategories[4]);
    if (selectedCategories[5]) formData.append('sap_id', selectedCategories[5]);
    formData.append('page_no', 1);
    assortmentTableState.sortData.sort_param !== ''
      ? formData.append('sort_param', assortmentTableState.sortData.sort_param)
      : formData.append('sort_param', 'iqvia_level_rank');
    assortmentTableState.sortData.sort_type !== ''
      ? formData.append('sort_type', assortmentTableState.sortData.sort_type)
      : formData.append('sort_type', 'desc');

    let config = {
      method: 'post',
      url: `${consoleState.state.api.BASE_URL}/${consoleState.state.api.IQVIA_SALES}`,
      data: formData
    };

    axios(config)
      .then(async (response) => {
        set_iqvia_data(response.data.iqvia_sales_results);
        setTotalProductsCount(response.data.iqvia_sales_count);
        setiqvialoading(false);
      })
      .catch(function () {
        setiqvialoading(false);
        console.log('error');
      });
  };

  const handlePagination2 = () => {
    if (totalProductsCount === iqvia_data.length || page1 < Math.floor(iqvia_data.length / 100)) {
      return;
    }

    const formData = new FormData();
    if (selectedCategories[0]) formData.append('ranking_level', selectedCategories[0]);
    if (selectedCategories[1]) formData.append('L0', selectedCategories[1]);
    if (selectedCategories[2]) formData.append('L1', selectedCategories[2]);
    if (selectedCategories[3]) formData.append('L2', selectedCategories[3]);
    if (selectedCategories[4]) formData.append('L3', selectedCategories[4]);
    if (selectedCategories[5]) formData.append('sap_id', selectedCategories[5]);
    formData.append('page_no', page1 === 1 ? 2 : Math.floor(page1 / 5) + 2);
    assortmentTableState.sortData.sort_param !== ''
      ? formData.append('sort_param', assortmentTableState.sortData.sort_param)
      : formData.append('sort_param', 'iqvia_level_rank');
    assortmentTableState.sortData.sort_type !== ''
      ? formData.append('sort_type', assortmentTableState.sortData.sort_type)
      : formData.append('sort_type', 'desc');
    let config = {
      method: 'post',
      url: `${consoleState.state.api.BASE_URL}${consoleState.state.api.IQVIA_SALES}`,
      data: formData
    };

    axios(config)
      .then(async (response) => {
        set_iqvia_data((prevData) => [...prevData, ...response.data.iqvia_sales_results]);
        setTotalProductsCount(response.data.iqvia_sales_count);
      })
      .catch(function () {
        console.log('error');
      });
  };

  useEffect(() => {
    if (consoleState.state.features.marketTrends.includes('IQVIA')) {
      iqvia_sales();
    }
  }, [
    assortmentTableState.sortData.sort_type,
    assortmentTableState.sortData.sort_param,
    selectedCategories
  ]);

  useEffect(() => {
    if (consoleState.state.features.marketTrends.includes('AIOCD')) {
      aiocd_sales();
    }
    // top_categories();
  }, [sortBy2, sortOrder2, selectedCategories]);

  const [pinFilters, setPinFilters] = useState(false);

  useEffect(() => {
    let configStat = {
      method: 'get',
      url: `${consoleState.state.api.BASE_URL}${consoleState.state.api.SALES_FILTER}`
    };
    axios(configStat)
      .then(async (response) => {
        setCategoryNested(response.data.filters);
      })
      .catch(function () {
        console.log('error');
      });
  }, []);

  const lvlExamplesObj = {};
  consoleState.state.globalFilters.category.levelNames.map((item, index) => {
    lvlExamplesObj[item] = consoleState.state.globalFilters.category.levelExamples[index];
  });

  const levelExamples = {
    'Filter level': 'L0',
    ...lvlExamplesObj,
    'Sap ID': '493924135'
  };

  return (
    <Container bg="white">
      <Flex direction="column" id="overview">
        <Text
          ml={6}
          style={{
            fontSize: '22px',
            fontFamily: 'Poppins',
            fontWeight: 'bold',
            marginTop: '50px'
          }}>
          Market Trends
        </Text>
        <Box
          ml={6}
          w="100px"
          h="5px"
          bg={`${chakratheme.colors.primary.main}`}
          borderRadius="3px"
          mt={2}
        />
      </Flex>
      <DrawerFilters
        open={props.open}
        setOpen={props.setOpen}
        pinFilters={pinFilters}
        setPinFilters={setPinFilters}
        categoryNested={categoryNested}
        categoryLevelNames={categoryLevelNames}
        selectedCategories={selectedCategories}
        setSelectedCategories={setSelectedCategories}
        filter="markettrends"
        hideFilters={['region', 'manufacturer']}
        nomfac={true}
        noregion={true}
        levelExamples={levelExamples}
      />
      <Text
        mt={3}
        ml={6}
        style={{
          color: `${chakratheme.colors.black[400]}`,
          fontSize: '13px',
          fontFamily: 'sans-serif'
        }}>
        Insights into current market dynamics and sales trends.
      </Text>
      <Flex
        alignItems={'center'}
        ml={6}
        style={{
          marginTop: '20px'
        }}>
        <ThemeProvider theme={() => createTheme()}>
          <ButtonJoy
            variant="outlined"
            color="neutral"
            startDecorator={<Tune />}
            onClick={() => props.setOpen(true)}>
            Change filters
          </ButtonJoy>
        </ThemeProvider>
        <Flex
          id="analysis"
          ml={5}
          color={`${chakratheme.colors.gray.main}`}
          style={{
            // backgroundColor: `${chakratheme.colors.gray.lighter}`,
            borderRadius: '5px',
            padding: '7px 20px',
            fontSize: '13px'
          }}
          alignItems={'center'}
          justifyContent={'flex-start'}>
          <HourglassTop style={{ marginRight: '10px' }} />
          <Text fontWeight={'bold'} fontSize="13px">
            Duration of Assortment -
          </Text>
          <Text ml={1} fontWeight={'bold'} fontSize="13px">
            July 25-31, 2023
          </Text>
        </Flex>
      </Flex>
      <Box p={5}>
        <div
          className="filler no-display"
          style={{
            height: '400px',
            width: '100%'
          }}></div>
        <Text
          style={{ marginTop: '20px' }}
          mb={4}
          fontWeight={900}
          fontSize="16px"
          textAlign="left">
          Rank Comparison of Categories
        </Text>
        <TabContext value={selectedTab}>
          <TabList
            textColor="black"
            indicatorColor="black"
            // backgroundColor="secondary"
            onChange={(e, tab) => setSelectedTab(tab)}>
            <Tab
              label="AIOCD"
              value="aiocd"
              sx={{
                '&:hover': {
                  backgroundColor:
                    selectedTab === 'aiocd'
                      ? `${chakratheme.colors.primary.lighter}`
                      : `${chakratheme.colors.gray[500]}`
                },
                backgroundColor:
                  selectedTab === 'aiocd'
                    ? `${chakratheme.colors.primary.lighter}`
                    : `${chakratheme.colors.gray.lighter}`
              }}
            />
            <Tab
              label="IQVIA"
              value="iqvia"
              sx={{
                '&:hover': {
                  backgroundColor:
                    selectedTab === 'iqvia'
                      ? `${chakratheme.colors.primary.lighter}`
                      : `${chakratheme.colors.gray[500]}`
                },
                backgroundColor:
                  selectedTab === 'iqvia'
                    ? `${chakratheme.colors.primary.lighter}`
                    : `${chakratheme.colors.gray.lighter}`
              }}
            />
          </TabList>
          <TabPanel style={{ paddingLeft: 0, paddingRight: 0 }} value="aiocd">
            <Text
              style={{
                fontWeight: 'bold',
                color: `${chakratheme.colors.black[400]}`,
                fontSize: '14px',
                fontFamily: 'sans-serif'
              }}>
              Pharmaceutical category performance and product sales insights in India based upon
              AIOCD data.
            </Text>
            <Text fontSize="14px" m={2}>
              Jan'22 -Dec'22
            </Text>
            <AssortmentTable
              data={aiocd_data}
              loading={aiocdloading}
              page_size={10}
              height="700px"
              handlePagination={handlePagination1}
              totalProductsCount={totalProductsCount2}
              page={page2}
              setPage={setPage2}
              sortBy={sortBy2}
              setSortBy={setSortBy2}
              sortOrder={sortOrder2}
              setSortOrder={setSortOrder2}
              headers={headers}
              setHeaders={setHeaders}
              assortmentTableState={assortmentTableState}
              setAssortmentTableState={setAssortmentTableState}
            />
            <Text
              style={{ marginTop: '20px' }}
              mb={4}
              fontWeight={900}
              fontSize="16px"
              textAlign="left">
              Top Categories by AIOCD Revenue
            </Text>
            <Flex direction="column" gap="10px">
              <Flex w="100%" mt={3} gap="10px">
                <Box
                  borderRadius={'20px'}
                  w="50%"
                  style={{
                    boxShadow: `${chakratheme.colors.shadow} 0px 0px 20px 10px`
                  }}>
                  <Text ml={2} mt={2} p="3" fontWeight={'bold'} fontSize="15px" textAlign="left">
                    L0 Category
                  </Text>
                  {topCategories ? (
                    <PieeChart
                      label="L0"
                      value="revenue"
                      data={topCategories.aiocd_result_l0?.slice(0, 3) || []}></PieeChart>
                  ) : (
                    <Skeleton
                      variant="rectangular"
                      width="100%"
                      height="400px"
                      style={{ margin: '10px', borderRadius: '20px' }}
                    />
                  )}
                </Box>
                <Box
                  borderRadius={'20px'}
                  w="50%"
                  style={{
                    boxShadow: `${chakratheme.colors.shadow} 0px 0px 20px 10px`
                  }}
                  ml={2}>
                  <Text ml={2} mt={2} p="3" fontWeight={'bold'} fontSize="15px" textAlign="left">
                    L1 Category
                  </Text>
                  {topCategories ? (
                    <PieeChart
                      label="L1"
                      value="revenue"
                      data={topCategories.aiocd_result_l1}></PieeChart>
                  ) : (
                    <Skeleton
                      variant="rectangular"
                      width="100%"
                      height="400px"
                      style={{ margin: '10px', borderRadius: '20px' }}
                    />
                  )}
                </Box>
              </Flex>
              <Flex w="100%" mt={3} gap="10px">
                <Box
                  borderRadius={'20px'}
                  w="50%"
                  style={{
                    boxShadow: `${chakratheme.colors.shadow} 0px 0px 20px 10px`
                  }}>
                  <Text ml={2} mt={2} p="3" fontWeight={'bold'} fontSize="15px" textAlign="left">
                    L2 Category
                  </Text>
                  {topCategories ? (
                    <PieeChart
                      label="L2"
                      value="revenue"
                      data={topCategories.aiocd_result_l2}></PieeChart>
                  ) : (
                    <Skeleton
                      variant="rectangular"
                      width="100%"
                      height="400px"
                      style={{ margin: '10px', borderRadius: '20px' }}
                    />
                  )}
                </Box>
                <Box
                  borderRadius={'20px'}
                  w="50%"
                  style={{
                    boxShadow: `${chakratheme.colors.shadow} 0px 0px 20px 10px`
                  }}
                  ml={2}>
                  <Text ml={2} mt={2} p="3" fontWeight={'bold'} fontSize="15px" textAlign="left">
                    L3 Category
                  </Text>
                  {topCategories ? (
                    <PieeChart
                      label="L3"
                      value="revenue"
                      data={topCategories.aiocd_result_l3}></PieeChart>
                  ) : (
                    <Skeleton
                      variant="rectangular"
                      width="100%"
                      height="400px"
                      style={{ margin: '10px', borderRadius: '20px' }}
                    />
                  )}
                </Box>
              </Flex>
            </Flex>
          </TabPanel>
          <TabPanel style={{ paddingLeft: 0, paddingRight: 0 }} value="iqvia">
            <Text
              style={{
                fontWeight: 'bold',
                color: `${chakratheme.colors.black[400]}`,
                fontSize: '14px',
                fontFamily: 'sans-serif'
              }}>
              Pharmaceutical category performance and product sales insights in India based upon
              IQVIA data.
            </Text>
            <Text m={2} variant="body1">
              Jan'23 - Jun'23
            </Text>
            <AssortmentTable
              data={iqvia_data}
              loading={iqvialoading}
              handlePagination={handlePagination2}
              totalProductsCount={totalProductsCount}
              page={page1}
              setPage={setPage1}
              page_size={10}
              height="700px"
              headers={headers}
              setHeaders={setHeaders}
              assortmentTableState={assortmentTableState}
              setAssortmentTableState={setAssortmentTableState}
            />
            <Text
              style={{ marginTop: '20px' }}
              mb={4}
              fontWeight={900}
              fontSize="16px"
              textAlign="left">
              Top Categories by IQVIA Revenue
            </Text>
            <>
              <Flex w="100%" mt={3}>
                <Box
                  w="50%"
                  style={{
                    boxShadow: `${chakratheme.colors.shadow} 0px 0px 20px 10px`
                  }}>
                  <Text ml={2} mt={2} p="3" fontWeight={'bold'} fontSize="15px" textAlign="left">
                    L0 Category
                  </Text>
                  {topCategories ? (
                    <PieeChart
                      label="L0"
                      value="revenue"
                      data={topCategories.iqvia_result_l0?.slice(0, 3) || []}></PieeChart>
                  ) : (
                    <Skeleton
                      variant="rectangular"
                      width="100%"
                      height="400px"
                      style={{ margin: '10px', borderRadius: '20px' }}
                    />
                  )}
                </Box>
                <Box
                  w="50%"
                  style={{
                    boxShadow: `${chakratheme.colors.shadow} 0px 0px 20px 10px`
                  }}
                  ml={2}>
                  <Text ml={2} mt={2} p="3" fontWeight={'bold'} fontSize="15px" textAlign="left">
                    L1 Category
                  </Text>
                  {topCategories ? (
                    <PieeChart
                      label="L1"
                      value="revenue"
                      data={topCategories.iqvia_result_l1}></PieeChart>
                  ) : (
                    <Skeleton
                      variant="rectangular"
                      width="100%"
                      height="400px"
                      style={{ margin: '10px', borderRadius: '20px' }}
                    />
                  )}
                </Box>
              </Flex>
              <Flex w="100%" mt={3}>
                <Box
                  w="50%"
                  style={{
                    boxShadow: `${chakratheme.colors.shadow} 0px 0px 20px 10px`
                  }}>
                  <Text ml={2} mt={2} p="3" fontWeight={'bold'} fontSize="15px" textAlign="left">
                    L2 Category
                  </Text>
                  {topCategories ? (
                    <PieeChart
                      label="L2"
                      value="revenue"
                      data={topCategories.iqvia_result_l2}></PieeChart>
                  ) : (
                    <Skeleton
                      variant="rectangular"
                      width="100%"
                      height="400px"
                      style={{ margin: '10px', borderRadius: '20px' }}
                    />
                  )}
                </Box>
                <Box
                  w="50%"
                  style={{
                    boxShadow: `${chakratheme.colors.shadow} 0px 0px 20px 10px`
                  }}
                  ml={2}>
                  <Text ml={2} mt={2} p="3" fontWeight={'bold'} fontSize="15px" textAlign="left">
                    L3 Category
                  </Text>
                  {topCategories ? (
                    <PieeChart
                      label="L3"
                      value="revenue"
                      data={topCategories.iqvia_result_l3}></PieeChart>
                  ) : (
                    <Skeleton
                      variant="rectangular"
                      width="100%"
                      height="400px"
                      style={{ margin: '10px', borderRadius: '20px' }}
                    />
                  )}
                </Box>
              </Flex>
            </>
          </TabPanel>
        </TabContext>
      </Box>
    </Container>
  );
};

export default MarketTrends;
