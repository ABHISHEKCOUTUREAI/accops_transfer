import colors from '../colors.json';
import constantValues from '../constants.json';

export const Colors = {
  blue: '#6734eb',
  white: '#FFFFFF',
  black: '#000000'
};

export const chakraColors = colors[process.env.REACT_APP_BRANDING]?.chakraColors || {};
export const constants = constantValues[process.env.REACT_APP_BRANDING];
