interface ITableState {
  data?: object[];
  fetchVariables?: {
    loading?: boolean;
    error?: boolean;
    started?: boolean;
    errorMessage?: boolean;
  };
  pagination?: {
    scrolledToBottom?: boolean;
    pageSize?: number;
    pageNumber?: number;
    totalPages?: number;
    totalRecords?: number;
  };
  filters?: Array<{
    filterName?: string;
    discrete?: {
      values: any[] | any;
    };
    range?: {
      min?: any;
      max?: any;
    };
    search?: {
      searchTerm?: string;
    };
  }>;
  rows?: {
    selectionMode?: string;
    selectedRows?: number[];
  };
  columns?: {
    visibibleColumns?: string[];
  };
}

interface ITableConfiguration {
  title?: string;
  maxHeight?: string;
  columns: {
    headers: Array<{
      title: string;
      id: string;
      dataIndex: string;
      dataType?: Array<any> | string | number | object | any;
      key: string;
      tooltip?: string;
      colSpan: number;
      cellBackground?: (obj: object) => string;
      transformer?: (obj: object) => object;
      sort?: {
        allow: boolean;
        defaultOrder?: 'asc' | 'desc';
        sortID?: string;
      };
      filters?: {
        filterType: 'range' | 'discrete' | 'search';
        filterID: string;
        discrete?: {
          multiple?: boolean;
          options?: any[];
          optionTransformer?: (obj: object) => object;
        };
        range?: {
          defaultMin?: any;
          defaultMax?: any;
        };
        search?: {};
      };
      search?: {
        searchID: string;
      };
    }>;
    groups: {
      allowGroups: boolean;
      groups: Array<{
        name: string;
        columns: string[];
        collapsible?: boolean;
        defaultCollapsed?: boolean;
        collapsedName?: string;
        collapsedTransformer?: (obj: object) => object;
      }>;
    };
    unhideableColumns: string[];
    defaultHiddenColumns: string[];
    allowHeadersSelection: boolean | false;
    allowHeadersRearrangement: boolean | false;
  };
  rows: {
    allowMultipleRowsSelection: boolean | false;
  };
  pagination?: {
    infiniteScroll?: boolean;
    showPaginationBar?: boolean;
    defaultPageNumber?: number;
    defaultFetchSize?: number;
    defaultPageSize?: number;
    position?: 'top' | 'bottom';
    allowCustomPageSize?: boolean;
    fetch : (obj: object) => Promise<object>;
  };
  menu?: {
    filters?: {
      allowedHeaders: '*' | string[];
    };
    search?: {
      collapsible: boolean;
      allowedHeaders: '*' | string[];
    };
    sort?: {
      allowedHeaders: string[];
    };
    download?: {
      position: 'bar' | 'dropdown';
    };
    upload?: {
      position: 'bar' | 'dropdown';
    };
  };
}
