export const lowStockCategoriesData = [
  {
    category: 'pain relievers',
    total_deficit: 17754,
    fulfillment: { added: 120, status: 'partial' }
  },
  {
    category: 'antibiotics',
    total_deficit: 17602,
    fulfillment: { added: 0, status: 'unfulfilled' }
  },
  {
    category: 'antacids',
    total_deficit: 17587,
    fulfillment: { added: 17587, status: 'fulfilled' }
  },
  {
    category: 'cough syrup',
    total_deficit: 17460,
    fulfillment: { added: 0, status: 'unfulfilled' }
  },
  {
    category: 'antihistamines',
    total_deficit: 17327,
    fulfillment: { added: 0, status: 'unfulfilled' }
  },
  {
    category: 'anti-inflammatory',
    total_deficit: 17261,
    fulfillment: { added: 0, status: 'unfulfilled' }
  },
  {
    category: 'vitamin supplements',
    total_deficit: 17184,
    fulfillment: { added: 0, status: 'unfulfilled' }
  },
  {
    category: 'cold medications',
    total_deficit: 17168,
    fulfillment: { added: 0, status: 'unfulfilled' }
  },
  {
    category: 'blood pressure medication',
    total_deficit: 17163,
    fulfillment: { added: 120, status: 'partial' }
  },
  {
    category: 'cholesterol medication',
    total_deficit: 17148,
    fulfillment: { added: 120, status: 'partial' }
  },
  {
    category: 'diabetes medication',
    total_deficit: 17045,
    fulfillment: { added: 120, status: 'partial' }
  },
  {
    category: 'antidepressants',
    total_deficit: 16728,
    fulfillment: { added: 120, status: 'partial' }
  },
  {
    category: 'antifungal creams',
    total_deficit: 16592,
    fulfillment: { added: 120, status: 'partial' }
  },
  {
    category: 'antiviral drugs',
    total_deficit: 16431,
    fulfillment: { added: 120, status: 'partial' }
  },
  {
    category: 'eye drops',
    total_deficit: 16414,
    fulfillment: { added: 120, status: 'partial' }
  },
  {
    category: 'ear drops',
    total_deficit: 16098,
    fulfillment: { added: 120, status: 'partial' }
  },
  {
    category: 'inhalers',
    total_deficit: 15977,
    fulfillment: { added: 120, status: 'partial' }
  },
  {
    category: 'stomach acid reducers',
    total_deficit: 15918,
    fulfillment: { added: 120, status: 'partial' }
  },
  {
    category: 'antidiarrheal drugs',
    total_deficit: 15697,
    fulfillment: { added: 120, status: 'partial' }
  },
  {
    category: 'laxatives',
    total_deficit: 15696,
    fulfillment: { added: 120, status: 'partial' }
  },
  {
    category: 'antipsychotics',
    total_deficit: 15691,
    fulfillment: { added: 120, status: 'partial' }
  },
  {
    category: 'hormone replacements',
    total_deficit: 15684,
    fulfillment: { added: 120, status: 'partial' }
  },
  {
    category: 'antimalarials',
    total_deficit: 15519,
    fulfillment: { added: 120, status: 'partial' }
  },
  {
    category: 'antithrombotic drugs',
    total_deficit: 15463,
    fulfillment: { added: 120, status: 'partial' }
  },
  {
    category: 'immunosuppressants',
    total_deficit: 15451,
    fulfillment: { added: 120, status: 'partial' }
  },
  {
    category: 'vaccines',
    total_deficit: 15420,
    fulfillment: { added: 120, status: 'partial' }
  },
  {
    category: 'antiseptics',
    total_deficit: 15101,
    fulfillment: { added: 120, status: 'partial' }
  },
  {
    category: 'oral contraceptives',
    total_deficit: 15079,
    fulfillment: { added: 120, status: 'partial' }
  },
  {
    category: 'sleep aids',
    total_deficit: 14966,
    fulfillment: { added: 120, status: 'partial' }
  },
  {
    category: 'allergy medication',
    total_deficit: 14891,
    fulfillment: { added: 120, status: 'partial' }
  },
  {
    category: 'antipyretics',
    total_deficit: 14851,
    fulfillment: { added: 120, status: 'partial' }
  },
  {
    category: 'muscle relaxants',
    total_deficit: 14736,
    fulfillment: { added: 120, status: 'partial' }
  },
  {
    category: 'topical analgesics',
    total_deficit: 14718,
    fulfillment: { added: 120, status: 'partial' }
  },
  {
    category: 'weight loss drugs',
    total_deficit: 14680,
    fulfillment: { added: 120, status: 'partial' }
  },
  {
    category: 'anesthetics',
    total_deficit: 14612,
    fulfillment: { added: 120, status: 'partial' }
  },
  {
    category: 'anticonvulsants',
    total_deficit: 14470,
    fulfillment: { added: 120, status: 'partial' }
  },
  {
    category: 'thyroid medication',
    total_deficit: 14423,
    fulfillment: { added: 120, status: 'partial' }
  },
  {
    category: 'antiglaucoma',
    total_deficit: 14318,
    fulfillment: { added: 120, status: 'partial' }
  },
  {
    category: 'oral rehydration salts',
    total_deficit: 14181,
    fulfillment: { added: 120, status: 'partial' }
  },
  {
    category: 'antihypertensives',
    total_deficit: 14070,
    fulfillment: { added: 120, status: 'partial' }
  },
  {
    category: 'antiparasitics',
    total_deficit: 14048,
    fulfillment: { added: 120, status: 'partial' }
  },
  {
    category: 'bronchodilators',
    total_deficit: 13892,
    fulfillment: { added: 120, status: 'partial' }
  },
  {
    category: 'antimigraine drugs',
    total_deficit: 13769,
    fulfillment: { added: 120, status: 'partial' }
  },
  {
    category: 'anticoagulants',
    total_deficit: 13750,
    fulfillment: { added: 120, status: 'partial' }
  },
  {
    category: 'antihyperlipidemics',
    total_deficit: 13724,
    fulfillment: { added: 120, status: 'partial' }
  },
  {
    category: 'stimulants',
    total_deficit: 13701,
    fulfillment: { added: 120, status: 'partial' }
  },
  {
    category: 'antiretrovirals',
    total_deficit: 13666,
    fulfillment: { added: 120, status: 'partial' }
  },
  {
    category: 'anticholinergics',
    total_deficit: 13532,
    fulfillment: { added: 120, status: 'partial' }
  },
  {
    category: 'hypnotics',
    total_deficit: 13425,
    fulfillment: { added: 120, status: 'partial' }
  },
  {
    category: 'osteoporosis medication',
    total_deficit: 13348,
    fulfillment: { added: 120, status: 'partial' }
  },
  {
    category: 'antineoplastics',
    total_deficit: 13341,
    fulfillment: { added: 120, status: 'partial' }
  },
  {
    category: 'local anesthetics',
    total_deficit: 13307
  },
  {
    category: 'anthelmintics',
    total_deficit: 13281
  },
  {
    category: 'antidotes',
    total_deficit: 12826
  },
  {
    category: 'antifibrotics',
    total_deficit: 12668
  },
  {
    category: 'antispasmodics',
    total_deficit: 12621
  },
  {
    category: 'antihistamine nasal sprays',
    total_deficit: 12476
  },
  {
    category: 'oral antifungals',
    total_deficit: 12476
  },
  {
    category: 'probiotics',
    total_deficit: 12439
  },
  {
    category: 'digestive enzymes',
    total_deficit: 12383
  },
  {
    category: 'antitussives',
    total_deficit: 12218
  },
  {
    category: 'serotonin antagonists',
    total_deficit: 12184
  },
  {
    category: 'antiemetics',
    total_deficit: 12070
  },
  {
    category: 'antimetabolites',
    total_deficit: 12026
  },
  {
    category: 'anticoagulant nasal sprays',
    total_deficit: 12018
  },
  {
    category: 'anxiolytics',
    total_deficit: 11911
  },
  {
    category: 'ureteral dilators',
    total_deficit: 11889
  },
  {
    category: 'topical steroids',
    total_deficit: 11819
  },
  {
    category: 'antidiabetic drugs',
    total_deficit: 11621
  },
  {
    category: 'antipsoriatics',
    total_deficit: 11602
  },
  {
    category: 'antihyperuricemics',
    total_deficit: 11515
  },
  {
    category: 'antirheumatics',
    total_deficit: 11416
  },
  {
    category: 'immunoglobulins',
    total_deficit: 11403
  },
  {
    category: 'antivenoms',
    total_deficit: 11378
  },
  {
    category: 'antiviral nasal sprays',
    total_deficit: 11357
  },
  {
    category: 'antituberculosis',
    total_deficit: 11326
  },
  {
    category: 'antihyperkinesia drugs',
    total_deficit: 11278
  },
  {
    category: 'antidyskinetics',
    total_deficit: 11261
  },
  {
    category: 'antihyperoxalurics',
    total_deficit: 11259
  },
  {
    category: 'antileprosy drugs',
    total_deficit: 11259
  },
  {
    category: 'antitumor antibiotics',
    total_deficit: 11247
  },
  {
    category: 'antiparkinsonians',
    total_deficit: 11246
  },
  {
    category: 'antigout agents',
    total_deficit: 11164
  },
  {
    category: 'antihyperphosphatemics',
    total_deficit: 11034
  },
  {
    category: 'antiglaucoma nasal sprays',
    total_deficit: 11026
  },
  {
    category: 'antihyperhidrosis',
    total_deficit: 10929
  },
  {
    category: 'antiallergic nasal sprays',
    total_deficit: 10912
  },
  {
    category: 'antiepileptics',
    total_deficit: 10872
  },
  {
    category: 'antileukotrienes',
    total_deficit: 10810
  },
  {
    category: 'topical antineoplastics',
    total_deficit: 10765
  },
  {
    category: 'antiglaucoma eye drops',
    total_deficit: 10714
  },
  {
    category: 'hemostatic agents',
    total_deficit: 10466
  },
  {
    category: 'antiprotozoals',
    total_deficit: 10464
  },
  {
    category: 'antiparasitic eye drops',
    total_deficit: 10458
  },
  {
    category: 'antibacterial nasal sprays',
    total_deficit: 10448
  },
  {
    category: 'antimigraine nasal sprays',
    total_deficit: 10445
  },
  {
    category: 'antiallergic eye drops',
    total_deficit: 10443
  },
  {
    category: 'antirheumatic nasal sprays',
    total_deficit: 10430
  },
  {
    category: 'antibacterial eye drops',
    total_deficit: 10420
  }
];

export const criticalReplenishmentData = [
  {
    category: 'pain relievers',
    required_replenishment: 17754
  },
  {
    category: 'antibiotics',
    required_replenishment: 17602
  },
  {
    category: 'antacids',
    required_replenishment: 17587
  },
  {
    category: 'cough syrup',
    required_replenishment: 17460
  },
  {
    category: 'antihistamines',
    required_replenishment: 17327
  },
  {
    category: 'anti-inflammatory',
    required_replenishment: 17261
  },
  {
    category: 'vitamin supplements',
    required_replenishment: 17184
  },
  {
    category: 'cold medications',
    required_replenishment: 17168
  },
  {
    category: 'blood pressure medication',
    required_replenishment: 17163
  },
  {
    category: 'cholesterol medication',
    required_replenishment: 17148
  },
  {
    category: 'diabetes medication',
    required_replenishment: 17045
  },
  {
    category: 'antidepressants',
    required_replenishment: 16728
  },
  {
    category: 'antifungal creams',
    required_replenishment: 16592
  },
  {
    category: 'antiviral drugs',
    required_replenishment: 16431
  },
  {
    category: 'eye drops',
    required_replenishment: 16414
  },
  {
    category: 'ear drops',
    required_replenishment: 16098
  },
  {
    category: 'inhalers',
    required_replenishment: 15977
  },
  {
    category: 'stomach acid reducers',
    required_replenishment: 15918
  },
  {
    category: 'antidiarrheal drugs',
    required_replenishment: 15697
  },
  {
    category: 'laxatives',
    required_replenishment: 15696
  },
  {
    category: 'antipsychotics',
    required_replenishment: 15691
  },
  {
    category: 'hormone replacements',
    required_replenishment: 15684
  },
  {
    category: 'antimalarials',
    required_replenishment: 15519
  },
  {
    category: 'antithrombotic drugs',
    required_replenishment: 15463
  },
  {
    category: 'immunosuppressants',
    required_replenishment: 15451
  },
  {
    category: 'vaccines',
    required_replenishment: 15420
  },
  {
    category: 'antiseptics',
    required_replenishment: 15101
  },
  {
    category: 'oral contraceptives',
    required_replenishment: 15079
  },
  {
    category: 'sleep aids',
    required_replenishment: 14966
  },
  {
    category: 'allergy medication',
    required_replenishment: 14891
  },
  {
    category: 'antipyretics',
    required_replenishment: 14851
  },
  {
    category: 'muscle relaxants',
    required_replenishment: 14736
  },
  {
    category: 'topical analgesics',
    required_replenishment: 14718
  },
  {
    category: 'weight loss drugs',
    required_replenishment: 14680
  },
  {
    category: 'anesthetics',
    required_replenishment: 14612
  },
  {
    category: 'anticonvulsants',
    required_replenishment: 14470
  },
  {
    category: 'thyroid medication',
    required_replenishment: 14423
  },
  {
    category: 'antiglaucoma',
    required_replenishment: 14318
  },
  {
    category: 'oral rehydration salts',
    required_replenishment: 14181
  },
  {
    category: 'antihypertensives',
    required_replenishment: 14070
  },
  {
    category: 'antiparasitics',
    required_replenishment: 14048
  },
  {
    category: 'bronchodilators',
    required_replenishment: 13892
  },
  {
    category: 'antimigraine drugs',
    required_replenishment: 13769
  },
  {
    category: 'anticoagulants',
    required_replenishment: 13750
  },
  {
    category: 'antihyperlipidemics',
    required_replenishment: 13724
  },
  {
    category: 'stimulants',
    required_replenishment: 13701
  },
  {
    category: 'antiretrovirals',
    required_replenishment: 13666
  },
  {
    category: 'anticholinergics',
    required_replenishment: 13532
  },
  {
    category: 'hypnotics',
    required_replenishment: 13425
  },
  {
    category: 'osteoporosis medication',
    required_replenishment: 13348
  },
  {
    category: 'antineoplastics',
    required_replenishment: 13341
  },
  {
    category: 'local anesthetics',
    required_replenishment: 13307
  },
  {
    category: 'anthelmintics',
    required_replenishment: 13281
  },
  {
    category: 'antidotes',
    required_replenishment: 12826
  },
  {
    category: 'antifibrotics',
    required_replenishment: 12668
  },
  {
    category: 'antispasmodics',
    required_replenishment: 12621
  },
  {
    category: 'antihistamine nasal sprays',
    required_replenishment: 12476
  },
  {
    category: 'oral antifungals',
    required_replenishment: 12476
  },
  {
    category: 'probiotics',
    required_replenishment: 12439
  },
  {
    category: 'digestive enzymes',
    required_replenishment: 12383
  },
  {
    category: 'antitussives',
    required_replenishment: 12218
  },
  {
    category: 'serotonin antagonists',
    required_replenishment: 12184
  },
  {
    category: 'antiemetics',
    required_replenishment: 12070
  },
  {
    category: 'antimetabolites',
    required_replenishment: 12026
  },
  {
    category: 'anticoagulant nasal sprays',
    required_replenishment: 12018
  },
  {
    category: 'anxiolytics',
    required_replenishment: 11911
  },
  {
    category: 'ureteral dilators',
    required_replenishment: 11889
  },
  {
    category: 'topical steroids',
    required_replenishment: 11819
  },
  {
    category: 'antidiabetic drugs',
    required_replenishment: 11621
  },
  {
    category: 'antipsoriatics',
    required_replenishment: 11602
  },
  {
    category: 'antihyperuricemics',
    required_replenishment: 11515
  },
  {
    category: 'antirheumatics',
    required_replenishment: 11416
  },
  {
    category: 'immunoglobulins',
    required_replenishment: 11403
  },
  {
    category: 'antivenoms',
    required_replenishment: 11378
  },
  {
    category: 'antiviral nasal sprays',
    required_replenishment: 11357
  },
  {
    category: 'antituberculosis',
    required_replenishment: 11326
  },
  {
    category: 'antihyperkinesia drugs',
    required_replenishment: 11278
  },
  {
    category: 'antidyskinetics',
    required_replenishment: 11261
  },
  {
    category: 'antihyperoxalurics',
    required_replenishment: 11259
  },
  {
    category: 'antileprosy drugs',
    required_replenishment: 11259
  },
  {
    category: 'antitumor antibiotics',
    required_replenishment: 11247
  },
  {
    category: 'antiparkinsonians',
    required_replenishment: 11246
  },
  {
    category: 'antigout agents',
    required_replenishment: 11164
  },
  {
    category: 'antihyperphosphatemics',
    required_replenishment: 11034
  },
  {
    category: 'antiglaucoma nasal sprays',
    required_replenishment: 11026
  },
  {
    category: 'antihyperhidrosis',
    required_replenishment: 10929
  },
  {
    category: 'antiallergic nasal sprays',
    required_replenishment: 10912
  },
  {
    category: 'antiepileptics',
    required_replenishment: 10872
  },
  {
    category: 'antileukotrienes',
    required_replenishment: 10810
  },
  {
    category: 'topical antineoplastics',
    required_replenishment: 10765
  },
  {
    category: 'antiglaucoma eye drops',
    required_replenishment: 10714
  },
  {
    category: 'hemostatic agents',
    required_replenishment: 10466
  },
  {
    category: 'antiprotozoals',
    required_replenishment: 10464
  },
  {
    category: 'antiparasitic eye drops',
    required_replenishment: 10458
  },
  {
    category: 'antibacterial nasal sprays',
    required_replenishment: 10448
  },
  {
    category: 'antimigraine nasal sprays',
    required_replenishment: 10445
  },
  {
    category: 'antiallergic eye drops',
    required_replenishment: 10443
  },
  {
    category: 'antirheumatic nasal sprays',
    required_replenishment: 10430
  },
  {
    category: 'antibacterial eye drops',
    required_replenishment: 10420
  }
];
