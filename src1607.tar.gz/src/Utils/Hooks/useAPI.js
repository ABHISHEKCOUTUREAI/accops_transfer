import axios from 'axios';
import { useState } from 'react';

export const useFetch = (url) => {
  const [data, setData] = useState(null);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState(null);

  const source = axios.CancelToken.source();
  const cancel = source.cancel;

  const fetch = async () => {
    setLoading(true);
    try {
      const options = {
        method: 'GET',
        url: url
      };
      const res = await axios(options);
      setData(res.data);
    } catch (e) {
      setError(e);
    }
    setLoading(false);
  };

  return { fetch, data, loading, error, cancel };
};

export const usePost = (url) => {
  const [data, setData] = useState(null);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState(null);

  const source = axios.CancelToken.source();
  const cancel = source.cancel;

  const post = async (body) => {
    setLoading(true);
    try {
      const options = {
        method: 'POST',
        url: url,
        data: body,
        cancelToken: source.token
      };
      const res = await axios(options);
      setData(res.data);
    } catch (e) {
      setError(e);
    }
    setLoading(false);
  };

  return { post, data, loading, error, cancel };
};

export const usePatch = (url) => {
  const [data, setData] = useState(null);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState(null);

  const source = axios.CancelToken.source();
  const cancel = source.cancel;

  const patch = async (body) => {
    setLoading(true);
    try {
      const options = {
        method: 'PATCH',
        url: url,
        data: body
      };
      const res = await axios(options);
      setData(res.data);
    } catch (e) {
      setError(e);
    }
    setLoading(false);
  };

  return { patch, data, loading, error, cancel };
};
