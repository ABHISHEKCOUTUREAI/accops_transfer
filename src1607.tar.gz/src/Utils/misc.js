const lastIndex = (array) => {
  let i = array.length - 1;
  while (i >= 0 && array[i] === null) {
    i--;
  }
  return i;
};

export const attachGlobalFilters = (formData, consoleState) => {
  const filterIDs = Object.keys(consoleState.state.globalFilters);
  const _selectedFilters = Object.keys(consoleState.state.globalFilters).reduce((acc, filter) => {
    acc[filter] = consoleState.state.globalFilters[filter].selected;
    return acc;
  }, {});

  const levelNames = (filterID) => {
    return consoleState.state.globalFilters[filterID].levelNames;
  };
  // apply global filters
  filterIDs.forEach((filter) => {
    if (filter == 'region') {
      const lastIndexNonNull = lastIndex(_selectedFilters['region']);
      if (lastIndexNonNull != -1)
        formData.append('region_type', levelNames('region')[lastIndexNonNull]);
      else formData.append('region_type', null);
      if (lastIndexNonNull != -1)
        formData.append('region_name', _selectedFilters['region'][lastIndexNonNull]);
      else formData.append('region_name', null);
    } else {
      _selectedFilters[filter].forEach((item, index) => {
        if (item) formData.append(consoleState.state.globalFilters[filter].apiKeys[index], item);
      });
    }
  });
  return formData;
};

export const attachTableData = (formData, assortmentTableState) => {
  formData.append('sort_param', assortmentTableState.sortData.sort_param);
  formData.append('sort_type', assortmentTableState.sortData.sort_type);

  // apply search data
  if (assortmentTableState.filtersData?.filter_params?.length > 0) {
    formData.append('filter_type', assortmentTableState.filtersData.filter_type);
    assortmentTableState.filtersData.filter_params.map((item) => {
      formData.append('filter_params', item);
    });
  }

  //apply search data
  Object.keys(assortmentTableState.searchData).forEach((key) => {
    if (assortmentTableState.searchData[key]) {
      formData.append(key, assortmentTableState.searchData[key]);
    }
  });
  return formData;
};

export const attachSortFilterData = (formData, state) => {
  if (state.sort.dataIndex) {
    formData.append('sort_param', state.sort.dataIndex);
    formData.append('sort_type', state.sort.order);
  }

  // apply search data
  if (state.filters.product_name) formData.append('item_name', state.filters.product_name);
  if (state.filters.description) formData.append('molecule', state.filters.description);

  // apply price filter
  // if (state.filters.price) formData.append('price', state.filters.price);

  if (state.filters.status_label.length > 0) {
    formData.append('filter_type', 'status_label');
    state.filters.status_label.map((item) => {
      formData.append('filter_params', item);
    });
  }
  return formData;
};

export const numberToMonth = (num) => {
  const months = [
    'January',
    'February',
    'March',
    'April',
    'May',
    'June',
    'July',
    'August',
    'September',
    'October',
    'November',
    'December'
  ];
  return months[num - 1];
};
