import axios from 'axios';

export const getSurgeDipAPI = (consoleState) => ({
  getSurge: (body) => {
    let config = {
      method: 'POST',
      url: `${consoleState.state.api.BASE_URL}${consoleState.state.api.DEMAND_SURGE_PRODUCTS}`,
      data: body
    };
    return axios(config);
  },
  getDip: (body) => {
    let config = {
      method: 'POST',
      url: `${consoleState.state.api.BASE_URL}${consoleState.state.api.DEMAND_DIP_PRODUCTS}`,
      data: body
    };
    return axios(config);
  }
});
