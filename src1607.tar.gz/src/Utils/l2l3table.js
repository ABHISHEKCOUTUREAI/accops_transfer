import axios from 'axios';
import configuration from '../config/configuration';

const l2l3table = ({
  selectedRegions,
  levelNames,
  sortBy4,
  sortOrder4,
  sortBy5,
  sortOrder5,
  setL3tabledata,
  setL2tabledata,
  setL2count,
  setL3count,
  setL2l3loading,
  lastIndex
}) => {
  setL2l3loading(true);
  const lastIndexNonNull = lastIndex(selectedRegions);

  const formData = new FormData();
  if (lastIndexNonNull !== -1)
    formData.append(
      'region_type',
      levelNames[lastIndexNonNull] === 'Store' ? 'Branch' : levelNames[lastIndexNonNull]
    );
  else formData.append('region_type', null);
  if (lastIndexNonNull !== -1) formData.append('region_name', selectedRegions[lastIndexNonNull]);
  else formData.append('region_name', null);
  formData.append('page_no_l2', 1);
  formData.append('page_no_l3', 1);
  formData.append('sort_param_l2', sortBy4);
  formData.append('sort_type_l2', sortOrder4);
  formData.append('sort_param_l3', sortBy5);
  formData.append('sort_type_l3', sortOrder5);

  let config = {
    method: 'post',
    url: `${configuration.api.BASE_URL}${configuration.api.L2L3_TABLE}`,
    data: formData
  };

  axios(config)
    .then(async (response) => {
      setL3tabledata(response.data.l3_table);
      setL2tabledata(response.data.l2_table);
      setL2count(response.data.l2_count);
      setL3count(response.data.l3_count);
      setL2l3loading(false);
    })
    .catch(function () {
      console.log('error');
      setL2l3loading(false);
    });
};

export default l2l3table;
