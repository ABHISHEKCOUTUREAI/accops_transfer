import axios from 'axios';
import { attachGlobalFilters } from './misc';

export const top_brands = (
  consoleState,

  setHorizontalStackData,
  setBrandStackData,
  setBrandCategoryNames,
  setTopMfacLoading,
  setCategoryNames,
  cancelToken = null
) => {
  setTopMfacLoading(true);
  // const lastIndexNonNull = lastIndex(selectedRegions);

  let formData = new FormData();
  formData = attachGlobalFilters(formData, consoleState);

  // if (lastIndexNonNull !== -1) formData.append('region_type', levelNames[lastIndexNonNull]);
  // else formData.append('region_type', null);
  // if (lastIndexNonNull !== -1) formData.append('region_name', selectedRegions[lastIndexNonNull]);
  // else formData.append('region_name', null);
  // if (selectedCategories[0]) formData.append('L0', selectedCategories[0]);
  // if (selectedCategories[1]) formData.append('L1', selectedCategories[1]);
  // if (selectedCategories[2]) formData.append('L2', selectedCategories[2]);
  // if (selectedCategories[3]) formData.append('L3', selectedCategories[3]);
  // if (selectedBrands[0]) formData.append('mfac_name', selectedBrands[0]);
  // if (selectedBrands[1]) formData.append('brand_name', selectedBrands[1]);
  let config = {
    method: 'post',
    url: `${consoleState.state.api.BASE_URL}${consoleState.state.api.TOP_MFAC}`,
    data: formData,
    cancelToken: cancelToken
  };

  axios(config).then(async (response) => {
    const categorySet = new Set();
    Object.values(response.data.mfac).forEach((vals) => {
      Object.keys(vals).forEach((key) => {
        categorySet.add(key);
      });
    });
    Object.values(response.data.brand).forEach((vals) => {
      Object.keys(vals).forEach((key) => {
        categorySet.add(key);
      });
    });
    const categoriesMfac = Array.from(categorySet);
    console.log('categories', categoriesMfac);
    setCategoryNames(Object.keys(response.data.mfac).slice(0, 10));
    const sliced = Object.fromEntries(Object.entries(response.data.mfac).slice(0, 5));
    const _data = [];
    categoriesMfac.forEach((key) => {
      const item = {
        name: key,
        data: []
      };
      for (let [category] of Object.entries(sliced)) {
        const value = response.data.mfac[category][key];
        item.data.push(value !== undefined ? value : 0);
      }

      _data.push(item);
    });

    // const firsttObject = response.data.mfac[Object.keys(response.data.mfac)[0]];
    // // eslint-disable-next-line no-prototype-builtins
    // if (firsttObject && !firsttObject.hasOwnProperty('Pharma')) {
    //   firsttObject['Pharma'] = 0;
    // }

    // Check if Non Pharma key exists, otherwise push 0
    // eslint-disable-next-line no-prototype-builtins
    // if (firsttObject && !firsttObject.hasOwnProperty('Non Pharma')) {
    //   firsttObject['Non Pharma'] = 0;
    // }
    // const data = [];
    // if (firsttObject) {
    //   for (let index = 0; index < Object.keys(firsttObject).length; index++) {
    //     const key = Object.keys(firsttObject)[index];
    //     if (key !== 'total') {
    //       const item = {
    //         name: key,
    //         data: []
    //       };
    //       for (let [category] of Object.entries(sliced)) {
    //         const value = response.data.mfac[category][key];
    //         item.data.push(value !== undefined ? value : 0);
    //       }

    //       data.push(item);
    //     }
    //   }
    // }
    console.log('data', _data);
    setHorizontalStackData(_data);

    setBrandCategoryNames(Object.keys(response.data.brand).slice(0, 10));
    const sliced_brand = Object.fromEntries(Object.entries(response.data.brand).slice(0, 5));

    // const firsttObject_brand = response.data.brand[Object.keys(response.data.brand)[0]];
    // // eslint-disable-next-line no-prototype-builtins
    // if (firsttObject_brand && !firsttObject_brand.hasOwnProperty('Pharma')) {
    //   firsttObject_brand['Pharma'] = 0;
    // }

    // // Check if Non Pharma key exists, otherwise push 0
    // // eslint-disable-next-line no-prototype-builtins
    // if (firsttObject_brand && !firsttObject_brand.hasOwnProperty('Non Pharma')) {
    //   firsttObject_brand['Non Pharma'] = 0;
    // }
    // const data_brand = [];
    // if (firsttObject) {
    //   for (let index = 0; index < Object.keys(firsttObject_brand).length; index++) {
    //     const key = Object.keys(firsttObject_brand)[index];
    //     if (key !== 'total') {
    //       const item = {
    //         name: key,
    //         data: []
    //       };
    //       for (let [category] of Object.entries(sliced_brand)) {
    //         const value = response.data.brand[category][key];
    //         item.data.push(value !== undefined ? value : 0);
    //       }

    //       data_brand.push(item);
    //     }
    //   }
    // }
    // const categorybrandSet = new Set();
    // Object.values(response.data.brand).forEach((vals) => {
    //   Object.keys(vals).forEach((key) => {
    //     categorybrandSet.add(key);
    //   });
    // });
    // const categoriesBrand = Array.from(categorybrandSet);
    const _data_brand = [];
    categoriesMfac.forEach((key) => {
      const item = {
        name: key,
        data: []
      };
      for (let [category] of Object.entries(sliced_brand)) {
        const value = response.data.brand[category][key];
        item.data.push(value !== undefined ? value : 0);
      }

      _data_brand.push(item);
    });

    setBrandStackData(_data_brand);
    setTopMfacLoading(false);
  });
};
