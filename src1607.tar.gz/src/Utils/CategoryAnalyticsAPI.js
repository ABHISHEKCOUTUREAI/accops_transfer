import axios from 'axios';
export const getCategoryAnalyticsAPI = (consoleState) => ({
  getCategoryAnalytics: async (formData) => {
    let config = {
      method: 'post',
      url: `${consoleState.state.api.BASE_URL}${consoleState.state.api.CRITICAL_LOW_STOCK}`,
      data: formData
    };
    return await axios(config);
  },
  getCategoryLowStockTreeMap: async (formData) => {
    let config = {
      method: 'post',
      url: `${consoleState.state.api.BASE_URL}${consoleState.state.api.CATEGORY_TREEMAP}`,
      data: formData
    };
    return await axios(config);
  },
  getCategoryDistributionDonut: async (formData) => {
    let config = {
      method: 'post',
      url: `${consoleState.state.api.BASE_URL}${consoleState.state.api.CATEGORY_DISTRIBUTION}`,
      data: formData
    };
    return await axios(config);
  }
});
