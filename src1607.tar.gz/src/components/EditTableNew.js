import { useContext, useEffect } from 'react';
import { useXTableState, XTable } from './CommonTable';
import { LocationContext } from '../Contexts/LocationContext';
import { attachGlobalFilters, attachSortFilterData } from '../Utils/misc';
import {
  Flex,
  HStack,
  Input,
  // Button,
  Spinner,
  ChakraProvider,
  IconButton,
  Text,
  useToast
} from '@chakra-ui/react';
import EditIcon from '@mui/icons-material/Edit';
import CheckIcon from '@mui/icons-material/Check';
import CloseIcon from '@mui/icons-material/Close';
import { useState } from 'react';
import axios from 'axios';
// import statusColors from '../Views/statusColors';
import {
  // ExpandCircleDown,
  NewReleases,
  RemoveShoppingCart,
  ReportProblem,
  Check
} from '@mui/icons-material';
import { getCartAPI } from '../Utils/CartAPI';
import { useTheme } from '@chakra-ui/react';
import { Chip } from '@mui/material';

export const EditTableNew = ({ assortmentTableStateExternal }) => {
  const { filterIDs, consoleState } = useContext(LocationContext);
  const chakratheme = useTheme();
  const cartAPI = getCartAPI(consoleState);
  const toast = useToast();
  const handlePagination = async (state, page) => {
    let formData = new FormData();

    formData.append('page_no', page);

    formData = attachGlobalFilters(formData, consoleState);
    formData = attachSortFilterData(formData, state);

    let config = {
      method: 'post',
      url: `${consoleState.state.api.BASE_URL}${consoleState.state.api.ASSORTMENT}`,
      data: formData
    };

    const response = await axios(config);
    return {
      data: response.data[consoleState.state.assortmentTable.types['assortment'].apiKey].map(
        (data) => {
          // const _cart =
          //   data.minimum_replenishment <= 0
          //     ? 0
          //     : [
          //         0,
          //         Math.floor(Math.random() * data.minimum_replenishment),
          //         data.minimum_replenishment
          //       ][Math.floor(Math.random() * 3)];
          return {
            ...data,
            cart: data.cart_quantity,
            update_button_loading: false,
            cart_mode: 'disabled', // In this case, show edit icon. In editing show 'x' and 'check' icon
            order_status:
              data.minimum_replenishment > 0
                ? 'notplaced'
                : ['fulfilled', 'notplaced', 'progress', ''][Math.floor(Math.random() * 4)]
          };
        }
      ),
      totalRecords: response.data[`assortment_count`]
    };
  };
  const ElementForCartColumn = ({ row, setRow, value }) => {
    const [_value, _setValue] = useState(value);
    return (
      <HStack>
        <Input
          w="50px"
          type="number"
          h="40px"
          border="1px solid #dddddd"
          borderRadius={'5px'}
          padding="0px 5px"
          value={_value}
          isDisabled={row.cart_mode === 'disabled'}
          onChange={(e) => {
            _setValue(e.target.value);
            // setRow({ ...row, cart: e.target.value });
          }}
        />
        {row.update_button_loading ? (
          <Spinner />
        ) : (
          <Flex gap={'5px'}>
            <IconButton
              variant={row.cart_mode === 'disabled' ? 'outline' : 'solid'}
              icon={row.cart_mode === 'disabled' ? <EditIcon /> : <CheckIcon />}
              style={{
                background: row.cart_mode !== 'disabled' ? chakratheme.colors.green.light : '',
                // padding: '10px 10px',
                borderRadius: '8px',
                color:
                  row.cart_mode !== 'disabled'
                    ? chakratheme.colors.green.main
                    : chakratheme.colors.gray.semilight,
                fontWeight: '400'
              }}
              isDisabled={row.cart_mode !== 'disabled' && _value <= 0}
              onClick={
                row.cart_mode !== 'disabled'
                  ? async () => {
                      try {
                        const data = {
                          quantity: _value,
                          store_id: row.store_id,
                          product_id: row.product_id
                        };
                        setRow({ ...row, update_button_loading: true });
                        const res = await cartAPI.addToCart(data);
                        setRow({
                          ...row,
                          update_button_loading: false,
                          cart_mode: 'disabled',
                          cart: _value
                        });
                        console.log(res.data);
                        toast({
                          title: 'Success.',
                          description: 'Cart updated successfully',
                          status: 'success',
                          duration: 3000,
                          isClosable: true
                        });
                      } catch (e) {
                        setRow({ ...row, update_button_loading: false, cart_mode: 'disabled' });
                        console.log(e);
                        toast({
                          title: 'Failed.',
                          description: 'Cart updated failed',
                          status: 'error',
                          duration: 3000,
                          isClosable: true
                        });
                      }
                    }
                  : () => {
                      setRow({ ...row, cart_mode: 'enabled' });
                    }
              }></IconButton>
            <IconButton
              visibility={row.cart_mode === 'disabled' ? 'hidden' : 'visible'}
              icon={<CloseIcon />}
              style={{
                backgroundColor: chakratheme.colors.error.light,
                color: chakratheme.colors.error.main
              }}
              onClick={() => {
                _setValue(row.cart);
                setRow({ ...row, cart_mode: 'disabled' });
              }}></IconButton>
          </Flex>
        )}
      </HStack>
    );
  };
  const config = {
    maxHeight: '600px',
    rows: {
      rowDatakey: 'product_id'
    },
    columns: {
      headers: [
        {
          title: 'Inventory Status',
          id: 'status',
          dataIndex: 'status_label',
          colSpan: 1,
          sort: {
            allow: true
          },
          transformer: ({ value }) => {
            const statusToBgColor = {
              '0_new': '#caddfc',
              '9_excess': '#f7cfb5',
              '1_replenish': '#fccbc7',
              '2_no_replenishment': '#c3dbca'
            };
            const statusToColor = {
              '0_new': '#4287f5',
              '9_excess': '#Dd6A1F',
              '1_replenish': '#eb4034',
              '2_no_replenishment': '#32a852'
            };
            const statusToName = {
              '0_new': 'New',
              '9_excess': 'Excess',
              '1_replenish': 'Low Stock',
              '2_no_replenishment': 'Optimal'
            };
            const statusToIcon = {
              '0_new': NewReleases,
              '9_excess': RemoveShoppingCart,
              '1_replenish': ReportProblem,
              '2_no_replenishment': Check
            };
            const Icon = statusToIcon[value];
            return (
              <Chip
                icon={
                  <Icon
                    style={{
                      color: statusToColor[value],
                      fontSize: '14px'
                    }}
                  />
                }
                key={value}
                label={statusToName[value]}
                style={{
                  fontWeight: 'bold',
                  backgroundColor: statusToBgColor[value],
                  color: statusToColor[value]
                }}
                size="small"
              />
            );
          }
          // filters: {
          //   filterType: 'discrete',
          //   filterID: 'status_label',
          //   discrete: {
          //     multiple: true,
          //     options: [
          //       { label: 'New', value: '0_new' },
          //       { label: 'Excess', value: '9_excess' },
          //       { label: 'Low Stock', value: '1_replenish' },
          //       { label: 'Optimal', value: '2_no_replenishment' }
          //     ],
          //     optionTransformer: ({ value }) => {
          //       const statusToBgColor = {
          //         '0_new': '#caddfc',
          //         '9_excess': '#f7cfb5',
          //         '1_replenish': '#fccbc7',
          //         '2_no_replenishment': '#c3dbca'
          //       };
          //       const statusToColor = {
          //         '0_new': '#4287f5',
          //         '9_excess': '#Dd6A1F',
          //         '1_replenish': '#eb4034',
          //         '2_no_replenishment': '#32a852'
          //       };
          //       const statusToName = {
          //         '0_new': 'New',
          //         '9_excess': 'Excess',
          //         '1_replenish': 'Low Stock',
          //         '2_no_replenishment': 'Optimal'
          //       };
          //       const statusToIcon = {
          //         '0_new': NewReleases,
          //         '9_excess': RemoveShoppingCart,
          //         '1_replenish': ReportProblem,
          //         '2_no_replenishment': Check
          //       };
          //       const Icon = statusToIcon[value];
          //       return (
          //         <Chip
          //           icon={
          //             <Icon
          //               style={{
          //                 color: statusToColor[value],
          //                 fontSize: '14px'
          //               }}
          //             />
          //           }
          //           key={value}
          //           label={statusToName[value]}
          //           style={{
          //             fontWeight: 'bold',
          //             backgroundColor: statusToBgColor[value],
          //             color: statusToColor[value]
          //           }}
          //           size="small"
          //         />
          //       );
          //     }
          //   }
          // }
        },
        {
          title: 'Product ID',
          id: 'product_id',
          dataIndex: 'product_id',
          colSpan: 1
        },
        {
          title: 'Name',
          sort: {
            allow: true
          },
          id: 'product_name',
          dataIndex: 'product_name',
          colSpan: 1,
          filters: {
            filterType: 'search',
            filterID: 'product_name'
          }
        },
        {
          title: 'Description',
          sort: {
            allow: true
          },
          dataIndex: 'description',
          colSpan: 1,
          filters: {
            filterType: 'search',
            filterID: 'description'
          }
        },
        {
          title: 'Brand Name',
          sort: {
            allow: true
          },
          id: 'brandname',
          dataIndex: 'brandname',
          colSpan: 1
        },
        {
          title: 'L0',
          sort: {
            allow: true
          },
          id: 'L0',
          dataIndex: 'L0',
          colSpan: 1
        },
        {
          title: 'L3',
          id: 'L3',
          dataIndex: 'L3',
          colSpan: 1,
          sort: {
            allow: true
          }
        },
        {
          title: 'Channel',
          id: 'channel',
          dataIndex: 'channel',
          colSpan: 1,
          sort: {
            allow: true
          }
        },
        {
          title: `Retail Price`,
          id: 'price',
          dataIndex: 'price',
          colSpan: 1,
          sort: {
            allow: true
          },
          filters: {
            filterType: 'range',
            filterID: 'price',
            range: {
              defaultMin: 0,
              defaultMax: 10000
            }
          }
        },
        {
          title: 'Existing Inventory',
          id: 'current_inventory',
          dataIndex: 'current_inventory',
          colSpan: 1,
          sort: {
            allow: true
          },
          filters: {
            filterType: 'range',
            filterID: 'current_inventory',
            range: {
              defaultMin: 0,
              defaultMax: 1000
            }
          }
        },
        // {
        //   title: 'Order trigger qty',
        //   id: 'order_trigger_qty',
        //   colSpan: 1,
        //   dataIndex: 'min_qty',
        //   sort: {
        //     allow: true
        //   }
        // },
        {
          title: 'Max stocked qty',
          id: 'max_stocked_qty',
          colSpan: 1,
          dataIndex: 'max_qty',
          sort: {
            allow: true
          }
        },
        // {
        //   title: 'Recommended Replenishment',
        //   id: 'recommended_replenishment',
        //   dataIndex: 'minimum_replenishment',
        //   colSpan: 1,
        //   sort: {
        //     allow: true
        //   },
        //   cellBackground: ({ row }) => {
        //     const statusToBgColor = {
        //       '0_new': '#caddfc',
        //       '9_excess': '#f7cfb5',
        //       '1_replenish': '#fccbc7',
        //       '2_no_replenishment': '#c3dbca'
        //     };
        //     return statusToBgColor[row['status_label']];
        //   },
        //   transformer: ({ value, row }) => {
        //     const statusToBgColor = {
        //       '0_new': '#caddfc',
        //       '9_excess': '#f7cfb5',
        //       '1_replenish': '#fccbc7',
        //       '2_no_replenishment': '#c3dbca'
        //     };
        //     const statusToColor = {
        //       '0_new': '#4287f5',
        //       '9_excess': '#Dd6A1F',
        //       '1_replenish': '#eb4034',
        //       '2_no_replenishment': '#32a852'
        //     };

        //     const statusToIcon = {
        //       '0_new': NewReleases,
        //       '9_excess': RemoveShoppingCart,
        //       '1_replenish': ReportProblem,
        //       '2_no_replenishment': Check
        //     };
        //     const Icon = statusToIcon[row['status_label']];
        //     return (
        //       <Flex
        //         h="100%"
        //         p="5px 20px"
        //         bg={statusToBgColor[row['status_label']]}
        //         alignItems={'center'}
        //         gap="5px"
        //         color={statusToColor[row['status_label']]}>
        //         <Icon style={{ fontSize: '12px' }} />
        //         {value}
        //       </Flex>
        //     );
        //   }
        // },
        {
          title: 'Cart',
          dataIndex: 'cart',
          colSpan: 1,
          transformer: ({ value, row, setRow }) => {
            // const _cartStatus = row.cart == 0 ? ''
            return <ElementForCartColumn value={value} row={row} setRow={setRow} />;
          }
        },
        {
          title: 'Order in Process',
          dataIndex: 'order_quantity',
          id: 'order_quantity',
          colSpan: 1
        }
        // {
        //   title: 'Order Status',
        //   dataIndex: 'order_status',
        //   colSpan: 1,
        //   transformer: ({ value }) => {
        //     // Return a Button that is going to call the cart API
        //     if (!value) return null;
        //     const { statusToBgColor, statusToColor, statusToIcon } = statusColors;
        //     const valueToKey = {
        //       progress: 'partial',
        //       notplaced: 'pending',
        //       fulfilled: 'done'
        //     };
        //     const valueToLabel = {
        //       progress: 'In Progress',
        //       notplaced: 'Not Placed',
        //       fulfilled: 'Fulfilled'
        //     };
        //     const _key = valueToKey[value];
        //     const Icon = statusToIcon[_key];
        //     return (
        //       <Chip
        //         icon={
        //           <Icon
        //             style={{
        //               color: statusToColor[_key],
        //               fontSize: '14px'
        //             }}
        //           />
        //         }
        //         label={valueToLabel[value]}
        //         style={{
        //           fontWeight: 'bold',
        //           backgroundColor: statusToBgColor[_key],
        //           color: statusToColor[_key]
        //         }}
        //         size="small"
        //       />
        //     );
        //   }
        // }
      ],
      groups: {
        allowGroups: true,
        groups: [
          {
            name: 'Product Details',
            columns: ['Product ID', 'Name', 'Description', 'L0', 'L3', 'Channel', 'Retail Price'],
            collapsible: true,
            defaultCollapsed: false,
            collapsedName: 'Summary',
            collapsedTransformer: ({ row }) => {
              return (
                <Flex direction="column" gap="5px" w="100%">
                  <Text fontWeight={'bold'}>{row['product_id']}</Text>
                  <Text
                    w="100%"
                    style={{
                      wordBreak: 'break-word !important',
                      whiteSpace: 'normal'
                    }}>
                    {row['product_name']}
                  </Text>
                </Flex>
              );
            }
          },
          {
            name: 'Predictions',
            columns: ['Order trigger qty', 'Max stocked qty', 'Recommended Replenishment']
            // collapsible: true,
            // collapsedName: 'Summary'
          }
        ]
      },
      unhideableColumns: ['Recommended Replenishment', 'Product ID', 'Order in Process'],
      defaultHiddenColumns: ['Inventory Status']
    },
    pagination: {
      infiniteScroll: false,
      allowPagination: true,
      defaultPageNumber: 1,
      defaultPageSize: 20,
      defaultFetchSize: 100,
      pageSizeOptions: [10, 20, 50, 100],
      fetch: handlePagination
    }
  };
  const { state: tableState, setState: setTableState } = useXTableState(config);

  useEffect(() => {
    setTableState((state) => ({
      ...state,
      filters: {
        ...state.filters,
        status_label: assortmentTableStateExternal.filtersData.filter_params || []
      }
    }));
  }, [assortmentTableStateExternal.filtersData]);

  useEffect(() => {
    // // console.log('Inside EditTableNew: Filters changed');
    // // setStoreId(consoleState?.state?.globalFilters?.region?.selected[3]);
    // // setTableState(() => ({
    // //   ...state,
    // //   pagination: {...state.pagination, pageNumber}
    // // }))
    // handlePagination(tableState, 1);
    console.log('External hook triggered');
    setTableState((prev) => ({ ...prev, trigger: prev.trigger + 1 }));
  }, [...filterIDs.map((filter) => consoleState.state.globalFilters[filter].selected)]);

  // on change of global filters, handlepaginataion with params
  // useEffect(() => {
  //   handlePagination(tableState, 1);
  // }, []);

  return (
    <ChakraProvider>
      <XTable
        state={tableState}
        setState={setTableState}
        config={config}
        style={{ fontFamily: 'Hanken Grotesk' }}
      />
    </ChakraProvider>
  );
};
