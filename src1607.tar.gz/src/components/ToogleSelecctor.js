import { Button, Flex, Text } from '@chakra-ui/react';
import { useEffect, useState } from 'react';

export const ToggleSelector = ({ role, toggleCallback }) => {
  const [admin, setAdmin] = useState(role === 'admin');

  useEffect(() => {
    if (admin) toggleCallback('admin');
    else toggleCallback('store manager');
  }, [admin]);

  return (
    <Flex
      position="relative"
      p={'2px'}
      w={'max-content'}
      borderRadius={'20px'}
      overflow="hidden"
      bg={'lightgray'}>
      <Flex
        position="absolute"
        top="8%"
        left={admin ? '1%' : '49%'}
        width="50%"
        height="84%"
        bg="gray"
        borderRadius={'20px'}
        transition="0.3s ease"
        zIndex="0"
      />
      <Button
        position="relative"
        zIndex="1"
        bg="transparent"
        _hover={{ bg: 'transparent' }}
        onClick={() => setAdmin(true)}
        flex="1">
        <Text color={admin ? 'white' : 'black'} mx={'24px'}>
          Admin
        </Text>
      </Button>
      <Button
        position="relative"
        zIndex="1"
        bg="transparent"
        _hover={{ bg: 'transparent' }}
        onClick={() => setAdmin(false)}
        flex="1">
        <Text color={!admin ? 'white' : 'black'} mx={'24px'}>
          Store Manager
        </Text>
      </Button>
    </Flex>
  );
};
