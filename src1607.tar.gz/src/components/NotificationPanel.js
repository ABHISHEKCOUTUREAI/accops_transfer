import { NotificationSidePanel } from '../Artifactory/Components/Notifications/NotificationSidePanel';
import { getNotificationsAPI } from '../Utils/NotificationsAPI';
import theme from '../theme';
import { ChakraProvider } from '@chakra-ui/react';
import { useContext, useState, useEffect } from 'react';
import { LocationContext } from '../Contexts/LocationContext';

export const NotificationsPanel = () => {
  const { consoleState } = useContext(LocationContext);
  const [storeId] = useState(consoleState?.state?.globalFilters?.region?.selected[3]);
  const [notificationResponse, setNotificationResponse] = useState([]);
  const [notifications, setNotifications] = useState([]);
  const notificationAPI = getNotificationsAPI(consoleState);
  const fetchNotifications = async () => {
    try {
      const body = {
        store_id: storeId,
        num_products: 2
      };
      const res = await notificationAPI.getNotifications(body);
      setNotificationResponse(res.data);
    } catch (e) {
      console.log(e);
    }
  };

  useEffect(() => {
    let { replenishment, surge } = notificationResponse;
    if (replenishment && surge)
      setNotifications(
        [...replenishment, ...surge].map((n) => ({
          product_id: n.product_id,
          status: n.replenishment == null ? 'high_demand' : 'low_stock',
          product_name: n.product_name
        }))
      );
  }, [notificationResponse]);

  useEffect(() => {
    fetchNotifications();
  }, []);
  return (
    <>
      <ChakraProvider theme={theme}>
        <NotificationSidePanel notifications={notifications} />
      </ChakraProvider>
    </>
  );
};
