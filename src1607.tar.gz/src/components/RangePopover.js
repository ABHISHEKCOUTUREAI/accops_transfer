import React, { useState } from 'react';
import {
  Box,
  Button,
  Popover,
  PopoverTrigger,
  PopoverContent,
  PopoverHeader,
  PopoverBody,
  PopoverFooter,
  PopoverArrow,
  PopoverCloseButton,
  useDisclosure,
  RangeSlider,
  RangeSliderTrack,
  RangeSliderFilledTrack,
  RangeSliderThumb,
  useTheme,
  Text,
  Flex,
  Spacer,
  HStack,
  IconButton
} from '@chakra-ui/react';
import { FilterAltOutlined } from '@mui/icons-material';

const RangePopover = ({ title, sliders, applyFilterCallback }) => {
  const { isOpen, onOpen, onClose } = useDisclosure();
  const [_sliders, _setSliders] = useState(sliders);
  const chakratheme = useTheme();

  const handleSliderChange = (val, index) => {
    _setSliders((prevValues) =>
      prevValues.map((item, i) => (i === index ? { ...item, min: val[0], max: val[1] } : item))
    );
  };

  return (
    <Box>
      <Popover isOpen={isOpen} onOpen={onOpen} onClose={onClose}>
        <PopoverTrigger>
          <IconButton
            onClick={onOpen}
            icon={<FilterAltOutlined style={{ color: 'gray' }} />}
            variant="outline"
          />
        </PopoverTrigger>
        <PopoverContent>
          <PopoverArrow />
          <PopoverCloseButton />
          <PopoverHeader>
            <Text color="#777777">{title}</Text>
          </PopoverHeader>
          <PopoverBody>
            {_sliders.map((s, i) => (
              <div key={i}>
                <Flex>
                  <Text color="#777777" fontFamily={'Hanken Grotesk'} fontSize={'14px'}>
                    {sliders[i].label}
                  </Text>
                  <Spacer />
                  <Text
                    color="#777777"
                    fontFamily={'Hanken Grotesk'}
                    fontSize={'12px'}
                    cursor={'pointer'}
                    onClick={() => handleSliderChange([sliders[i].min, sliders[i].max], i)} // Clear functionality
                  >
                    clear
                  </Text>
                </Flex>
                <HStack>
                  <Text color="#777777" fontFamily={'Hanken Grotesk'} fontSize={'12px'}>
                    {s.min}
                  </Text>
                  <RangeSlider
                    aria-label={['min', 'max']}
                    value={[s.min, s.max]}
                    min={sliders[i].min}
                    max={sliders[i].max}
                    step={1}
                    onChange={(val) => handleSliderChange(val, i)}>
                    <RangeSliderTrack>
                      <RangeSliderFilledTrack bg={chakratheme.colors.primary.main} />
                    </RangeSliderTrack>
                    <RangeSliderThumb index={0} />
                    <RangeSliderThumb index={1} />
                  </RangeSlider>
                  <Text color="#777777" fontFamily={'Hanken Grotesk'} fontSize={'12px'}>
                    {s.max}
                  </Text>
                </HStack>
              </div>
            ))}
          </PopoverBody>
          <PopoverFooter>
            <Flex>
              <Button variant={'outline'} onClick={() => _setSliders(sliders)}>
                Reset
              </Button>
              <Spacer />
              <Button onClick={() => applyFilterCallback(_sliders)}>Apply</Button>
            </Flex>
          </PopoverFooter>
        </PopoverContent>
      </Popover>
    </Box>
  );
};

export default RangePopover;
