import {
  Box,
  Flex,
  Text,
  Spacer,
  MenuItemOption,
  MenuList,
  useTheme,
  Menu,
  Button,
  MenuButton
} from '@chakra-ui/react';
import { InfoOutlined } from '@mui/icons-material';
import AreaGraphChart from '../Artifactory/Charts/AreaGraphChart';
import { useContext, useState } from 'react';
import { ChevronDownIcon } from '@chakra-ui/icons';
import { Tooltip } from '@mui/material';
import { LocationContext } from '../Contexts/LocationContext';
const PastSales = (props) => {
  const [duration, setDuration] = useState(100);
  const [category, setCategory] = useState('All Categories');
  const { consoleState } = useContext(LocationContext);
  const durations = [3, 6, 12, 100];
  const categories = ['All Categories', 'Pharma', 'Non Pharma', 'Generics', 'Surgical', 'Devices'];
  // const categoriesData = {
  //   'All Categories': props.salesData.map()
  // }
  console.log('_salesData', props.salesData);
  const chakratheme = useTheme();
  return (
    <Box
      mt="10"
      style={{
        flex: '100%',
        padding: '20px',
        borderRadius: '20px',
        boxShadow: `${chakratheme.colors.shadow} 0px 0px 20px 0px`
      }}>
      <Flex flexDir={'row'} alignItems="center" gap="10px">
        <Text fontWeight={'bold'} fontSize="16px" textAlign="left" fontFamily={'Poppins'}>
          Store Level Past Sales Revenue{' '}
          <span style={{ color: `${chakratheme.colors.gray.light}` }}>
            {consoleState.state.currency || '$'}
          </span>
        </Text>
        <Tooltip title={'Store SBU category level past sales'}>
          {' '}
          <InfoOutlined
            style={{
              width: '15px',
              height: '15px'
            }}
            cursor={'pointer'}
          />
        </Tooltip>

        <Spacer />
        <Menu ml="20px" matchWidth={true}>
          <MenuButton
            as={Button}
            variant={'menu'}
            sx={{
              display: 'flex',
              width: '100px',
              alignItems: 'center',
              backgroundColor: `${chakratheme.colors.gray.lighter}`,
              borderRadius: '20px',
              padding: '5px 10px'
            }}
            // leftIcon={view === 'module' ? <ViewModule /> : <ViewList />}
            rightIcon={<ChevronDownIcon color={`${chakratheme.colors.gray.darker}`} />}>
            <Text color={`${chakratheme.colors.gray.darker}`} fontSize={'12px'}>
              {' '}
              {duration === 100 ? 'All time' : `${duration} months`}{' '}
            </Text>
          </MenuButton>
          <MenuList
            alignItems={'center'}
            onMouseEnter={(e) => {
              e.stopPropagation();
            }}
            zIndex="100"
            fontSize={'12px'}
            borderRadius={'10px'}
            paddingTop="10px"
            paddingBottom="10px"
            backgroundColor={'white'}
            boxShadow={`0 0 10px 0 ${chakratheme.colors.shadow}`}>
            {durations.map((_duration) => (
              <MenuItemOption
                cursor="pointer"
                _hover={{
                  backgroundColor: `${chakratheme.colors.gray[300]}`
                }}
                key={_duration}
                value={_duration}
                onClick={(e) => {
                  e.stopPropagation();
                  setDuration(_duration);
                }}>
                {_duration === 100 ? 'All time' : `${_duration} months`}
              </MenuItemOption>
            ))}
          </MenuList>
        </Menu>
        <Menu ml="20px" matchWidth={true}>
          <MenuButton
            as={Button}
            variant={'menu'}
            sx={{
              display: 'flex',
              width: '150px',
              alignItems: 'center',
              backgroundColor: `${chakratheme.colors.gray.lighter}`,
              borderRadius: '20px',
              padding: '5px 10px',
              marginRight: '20px'
            }}
            // leftIcon={view === 'module' ? <ViewModule /> : <ViewList />}
            rightIcon={<ChevronDownIcon color={`${chakratheme.colors.gray.darker}`} />}>
            <Text color={`${chakratheme.colors.gray.darker}`} fontSize={'12px'}>
              {' '}
              {category}{' '}
            </Text>
          </MenuButton>
          <MenuList
            alignItems={'center'}
            onMouseEnter={(e) => {
              e.stopPropagation();
            }}
            zIndex="100"
            fontSize={'12px'}
            borderRadius={'10px'}
            paddingTop="10px"
            paddingBottom="10px"
            backgroundColor={'white'}
            boxShadow={`0 0 10px 0 ${chakratheme.colors.shadow}`}>
            {categories.map((_category) => (
              <MenuItemOption
                cursor="pointer"
                _hover={{
                  backgroundColor: `${chakratheme.colors.gray[300]}`
                }}
                key={_category}
                value={_category}
                onClick={(e) => {
                  e.stopPropagation();
                  setCategory(_category);
                }}>
                {_category}
              </MenuItemOption>
            ))}
          </MenuList>
        </Menu>
      </Flex>
      <Box width="100%">
        <Flex mt={2} w="100%" justifyContent={'flex-start'}>
          <Text mt={2} color={`${chakratheme.colors.black[400]}`} fontSize={14}>
            * Hover on the chart to see month-wise revenue
          </Text>
        </Flex>
        {props.salesData && Object.keys(props.salesData).length > 0 ? (
          <AreaGraphChart
            width="100%"
            data={props.salesData}
            duration={duration}
            category={category}></AreaGraphChart>
        ) : (
          <Flex justifyContent={'center'} alignItems="center" h="400px" w="100%">
            <Text>
              {props.salesData && Object.keys(props.salesData).length == 0
                ? 'No Data to display for the selected regions'
                : 'Please Select a Region'}
            </Text>
          </Flex>
        )}
      </Box>{' '}
    </Box>
  );
};
export default PastSales;
