import { TrendingDownRounded } from '@mui/icons-material';
import { BaseChakraTableComponent } from './BaseChakraTableComponent';
import {
  Flex,
  Card,
  ChakraProvider,
  Text,
  Spinner,
  // useNumberInput,
  HStack,

  // Input,
  useTheme,
  // Select,
  IconButton,
  Input,
  useToast
} from '@chakra-ui/react';
import EditIcon from '@mui/icons-material/Edit';
import CheckIcon from '@mui/icons-material/Check';
import CloseIcon from '@mui/icons-material/Close';

import { useContext, useEffect, useState } from 'react';
import { Tooltip } from '@mui/material';
// import { ArrowDropUpIcon, ArrowDropDownIcon } from '@mui/icons-material';
import ArrowDropDownIcon from '@mui/icons-material/ArrowDropDown';
import ArrowDropUpIcon from '@mui/icons-material/ArrowDropUp';
import theme from '../theme';
import AddShoppingCartIcon from '@mui/icons-material/AddShoppingCart';
// import KeyboardDoubleArrowRightIcon from '@mui/icons-material/KeyboardDoubleArrowRight';
import RangePopover from './RangePopover';
import { getSurgeDipAPI } from '../Utils/SurgeDipAPI';
import { LocationContext } from '../Contexts/LocationContext';
import { getCartAPI } from '../Utils/CartAPI';

export const DemandDipTable = () => {
  const chakratheme = useTheme();
  const toast = useToast();
  const { filterIDs, consoleState } = useContext(LocationContext);
  const surgeDipAPI = getSurgeDipAPI(consoleState);
  const cartAPI = getCartAPI(consoleState);
  const [storeId, setStoreId] = useState(consoleState?.state?.globalFilters?.region?.selected[3]);
  const [data, setData] = useState([]);
  const [itemsPerPage] = useState(4);
  const [totalPages, setTotalPages] = useState(0);
  const [totalItems, setTotalItems] = useState(0);
  const [currentPage, setCurrentPage] = useState(1);
  const [startIndex, setStartIndex] = useState(0);
  const [endIndex, setEndIndex] = useState(0);
  const [filters, setFilters] = useState(null);
  const [sort, setSort] = useState(null);
  const [loading, setLoading] = useState(false);

  const ElementForCartColumn = ({ row }) => {
    console.log(row.product_id, row.cart_quantity);
    const [_value, _setValue] = useState(row.cart_quantity);
    return (
      <HStack>
        <Input
          w="50px"
          type="number"
          h="40px"
          border="1px solid #dddddd"
          borderRadius={'5px'}
          padding="0px 5px"
          value={_value}
          isDisabled={row.cart_mode === 'disabled'}
          onChange={(e) => {
            _setValue(e.target.value);
            // setRow({ ...row, cart: e.target.value });
          }}
        />
        {row.update_button_loading ? (
          <Spinner />
        ) : (
          <Flex gap={'5px'}>
            <IconButton
              variant={row.cart_mode === 'disabled' ? 'outline' : 'solid'}
              icon={row.cart_mode === 'disabled' ? <EditIcon /> : <CheckIcon />}
              style={{
                background: row.cart_mode !== 'disabled' ? chakratheme.colors.green.light : '',
                // padding: '10px 10px',
                borderRadius: '8px',
                color:
                  row.cart_mode !== 'disabled'
                    ? chakratheme.colors.green.main
                    : chakratheme.colors.gray.semilight,
                fontWeight: '400'
              }}
              isDisabled={row.cart_mode !== 'disabled' && _value <= 0}
              onClick={async () =>
                // If it is check icon, then modify the data and rowData, send API call,
                // and disable on completion of request.
                {
                  if (row.cart_mode === 'disabled')
                    setRowData((prev) =>
                      prev.map((r) =>
                        r.product_id === row.product_id ? { ...r, cart_mode: 'enabled' } : { ...r }
                      )
                    );
                  else {
                    try {
                      const data = {
                        quantity: _value,
                        store_id: storeId,
                        product_id: row.product_id
                      };

                      setRowData((prev) =>
                        prev.map((r) =>
                          r.product_id === row.product_id
                            ? { ...r, update_button_loading: true }
                            : { ...r }
                        )
                      );
                      const res = await cartAPI.addToCart(data);
                      console.log(res.data);
                      setData((prev) =>
                        prev.map((r) =>
                          r.product_id === row.product_id
                            ? { ...r, cart_quantity: _value }
                            : { ...r }
                        )
                      );
                      setRowData((prev) =>
                        prev.map((r) =>
                          r.product_id === row.product_id
                            ? { ...r, cart_quantity: _value, update_button_loading: false }
                            : { ...r }
                        )
                      );
                      toast({
                        title: 'Success.',
                        description: 'Cart updated successfully',
                        status: 'success',
                        duration: 3000,
                        isClosable: true
                      });
                    } catch (e) {
                      setRowData((prev) =>
                        prev.map((r) =>
                          r.product_id === row.product_id
                            ? { ...r, update_button_loading: false }
                            : { ...r }
                        )
                      );
                      console.log(e);
                      toast({
                        title: 'Failed.',
                        description: 'Cart updated failed',
                        status: 'error',
                        duration: 3000,
                        isClosable: true
                      });
                    }
                  }
                }
              }></IconButton>
            <IconButton
              visibility={row.cart_mode === 'disabled' ? 'hidden' : 'visible'}
              icon={<CloseIcon />}
              onClick={() =>
                setRowData((prev) =>
                  prev.map((r) =>
                    r.product_id === row.product_id ? { ...r, cart_mode: 'disabled' } : { ...r }
                  )
                )
              }
              style={{
                backgroundColor: chakratheme.colors.error.light,
                color: chakratheme.colors.error.main
              }}></IconButton>
          </Flex>
        )}
      </HStack>
    );
  };

  const headers = [
    {
      title: 'SAP ID',
      key: 'product_id'
      // sort: 'default'
    },
    {
      title: 'Last week sales',
      key: 'items_sold_last_week',
      sort: 'default'
    },
    {
      title: 'Current week sales',
      key: 'items_sold_this_week',
      sort: 'default'
    },
    {
      title: 'Dip',
      key: 'percentage_change',
      sort: 'default'
    },
    {
      title: 'Name',
      key: 'product_name',
      sort: 'default'
    },
    {
      title: 'L0',
      key: 'l0',
      sort: 'default'
    },
    {
      title: 'L3',
      key: 'l3',
      sort: 'default'
    },
    {
      title: 'Recommended Replenishment',
      key: 'recommended_replenishment',
      sort: 'default'
    }
    // {
    //   title: 'Cart',
    //   key: 'cart_quantity',
    //   width: '175px',
    //   maxW: '175px'
    //   // sort: 'default'
    // },
    // {
    //   title: 'Order in process',
    //   key: 'ordered_quantity'
    //   // sort: 'default'
    // }
  ];
  // const statusToBgColor = {
  //   // '0_new': '#caddfc',
  //   partial: '#f7cfb5',
  //   unfulfilled: '#fccbc7',
  //   fulfilled: '#c3dbca'
  // };
  // const statusToColor = {
  //   // '0_new': '#4287f5',
  //   partial: '#Dd6A1F',
  //   unfulfilled: '#eb4034',
  //   fulfilled: '#32a852'
  // };
  // const statusToName = {
  //   // '0_new': 'New',
  //   partial: 'Partial',
  //   unfulfilled: 'Pending',
  //   fulfilled: 'Fulfilled'
  // };
  // const statusToIcon = {
  //   // '0_new': NewReleases,
  //   partial: RemoveShoppingCart,
  //   unfulfilled: FiberManualRecord,
  //   fulfilled: Check
  // };

  const [rowData, setRowData] = useState([]);

  const fakeServerCall = (i) => {
    setRowData((prev) => {
      const newData = [...prev];
      // Update the specific item in the copied array
      newData[i] = { ...newData[i], loading: !newData[i].loading };
      // Return the new array to setRowData
      return newData;
    });
  };

  const fetchDipData = async (searchText = '') => {
    try {
      let reqBody = {
        store_id: storeId,
        num_products: 100,
        filters: filters || [],
        globalSearch: searchText
      };
      if (sort) {
        reqBody.sort = sort;
      }
      setLoading(true);
      const res = await surgeDipAPI.getDip(reqBody);
      setData(
        res.data.map((x) => ({
          ...x,
          cart: data.cart_quantity,
          update_button_loading: false,
          cart_mode: 'disabled'
        }))
      );
      setTotalPages(Math.ceil(res.data?.length / itemsPerPage));
      setTotalItems(res.data?.length);
      setLoading(false);
    } catch (e) {
      setLoading(false);
      console.log(e);
    }
  };

  const nextPage = (pageNumber) => {
    const startIndex = (pageNumber - 1) * itemsPerPage;
    const endIndex = startIndex + itemsPerPage;
    console.log('start', startIndex, 'end', endIndex);
    setRowData(data.slice(startIndex, endIndex));
    setCurrentPage(pageNumber);
    setStartIndex(startIndex + 1);
    setEndIndex(endIndex);
  };

  useEffect(() => {
    nextPage(1);
  }, [data]);

  useEffect(() => {
    setStoreId(consoleState?.state?.globalFilters?.region?.selected[3]);
  }, [...filterIDs.map((filter) => consoleState.state.globalFilters[filter].selected)]);

  useEffect(() => {
    fetchDipData();
  }, [storeId]);

  useEffect(() => {
    fetchDipData();
  }, []);

  useEffect(() => {
    fetchDipData();
  }, [sort, filters]);

  const columDataTransformers = {
    // contains all the functions that is needed for every column
    add_to_inventory: (row, i) => (
      // <Button onClick={() => console.log(id)} bg={'green'}>
      //   Add
      // </Button>
      <Flex gap={2}>
        <Tooltip title={row.status ? 'Remove from cart' : 'Add to cart'}>
          {!row.loading ? (
            <AddShoppingCartIcon
              onClick={() => {
                setRowData((prev) => {
                  const newData = [...prev];
                  // Update the specific item in the copied array
                  newData[i] = { ...newData[i], add_to_inventory: !newData[i].add_to_inventory };
                  // Return the new array to setRowData
                  return newData;
                });
                // Call to the backend to add item to the cart (fake simulation of animation)
                fakeServerCall(i);
                setTimeout(() => fakeServerCall(i), 1000);
              }}
              style={
                row.status
                  ? {
                      color: 'green',
                      border: '2px solid',
                      borderRadius: '5px',
                      padding: '2px'
                    }
                  : { cursor: 'pointer', color: 'gray' }
              }
            />
          ) : (
            <Spinner />
          )}
        </Tooltip>
      </Flex>
    ),
    cart_quantity: (row, i) => {
      return <ElementForCartColumn row={row} i={i} />;
    },
    ordered_quantity: (row) => {
      return row.ordered_quantity || 0;
    },
    percentage_change: (row) =>
      row.percentage_change >= 0 ? (
        <>
          <Flex>
            {row.percentage_change} % <ArrowDropUpIcon style={{ color: 'green' }} />
          </Flex>
        </>
      ) : (
        <>
          <Flex>
            {Math.abs(row.percentage_change)} % <ArrowDropDownIcon style={{ color: 'red' }} />
          </Flex>
        </>
      )
  };

  return (
    <ChakraProvider theme={theme}>
      <Card
        borderRadius={'20px'}
        p="20px"
        mt="20px"
        boxShadow={'rgb(231, 231, 231) 0px 0px 20px 0px'}
        pt="0">
        <Flex direction="column" my={5}>
          <Flex justifyContent={'space-between'} alignItems={'center'}>
            <Flex gap="5px">
              <TrendingDownRounded style={{ color: chakratheme.colors.error.main }} />
              <Text
                style={{
                  fontSize: '16px',
                  fontFamily: 'Poppins',
                  fontWeight: 'bold',
                  marginTop: '0px'
                }}>
                Demand Dip
              </Text>
            </Flex>
            <Flex gap={2}>
              <RangePopover
                title={'Filters'}
                sliders={[
                  {
                    label: 'Current weeek sales',
                    key: 'items_sold_this_week',
                    min: 0,
                    max: 10000
                  }
                ]}
                applyFilterCallback={(sliders) => {
                  setFilters(
                    sliders.map((s) => ({ id: s.key, type: 'range', min: s.min, max: s.max }))
                  );
                }}
              />
            </Flex>
          </Flex>
          {data ? (
            <BaseChakraTableComponent
              colorScheme={'gray'}
              rowData={rowData}
              columDataTransformers={columDataTransformers}
              headers={headers}
              layout={'fixed'}
              currentPage={currentPage}
              recordFrom={startIndex}
              totalRecords={totalItems}
              recordTo={endIndex}
              loading={loading}
              style={{
                fontFamily: 'Arial, sans-serif',
                fontSize: '14px',
                height: '400px',
                overflow: 'auto',
                borderRadius: '0px',
                marginTop: '10px',
                border: '1px solid #eeeeee'
              }}
              nexPageCallback={(i) => nextPage(i)}
              sortCallBack={(hid, sortType) => {
                sortType !== 'default' ? setSort({ field: hid, order: sortType }) : setSort(null);
              }}
              totalPages={totalPages}
            />
          ) : (
            <Text>No data available</Text>
          )}
        </Flex>
      </Card>
    </ChakraProvider>
  );
};
