import React from 'react';
import { Box, Divider, Flex, Spacer, Text } from '@chakra-ui/layout';
import { Image, Table, Tbody, Td, Th, Thead, Tr, useTheme } from '@chakra-ui/react';
import {
  Cancel,
  Check,
  ChevronLeftRounded,
  ChevronRightRounded,
  Expand,
  NewReleases,
  NoteAdd,
  RemoveShoppingCart,
  ReportProblem,
  Search,
  UnfoldLess
} from '@mui/icons-material';
import DeleteIcon from '@mui/icons-material/Delete';
import ArrowForwardIcon from '@mui/icons-material/ArrowForward';
import {
  Chip,
  InputAdornment,
  InputLabel,
  MenuItem,
  OutlinedInput,
  Select,
  Tooltip
  // debounce
} from '@mui/material';
import Typography from '@mui/material/Typography';
import Autocomplete from '@mui/material/Autocomplete';
import FilterScreen from '../Views/FilterScreen';
import TextField from '@mui/material/TextField';
import CloseIcon from '@mui/icons-material/Close';
import { useToast } from '@chakra-ui/react';

import axios from 'axios';
import { Editable, Button } from '@chakra-ui/react';
import { IconButton, Skeleton } from '@mui/material';
// import { AddCircleOutline } from '@mui/icons-material';
import { useEffect, useState } from 'react';
import Ascending from '../Static/ascending.png';
import Descending from '../Static/descending.png';
import { FilterList } from '@mui/icons-material';
import Modal from '@mui/material/Modal';
import { Stack, FormControl } from '@mui/material';
import { LocationContext } from '../Contexts/LocationContext';
const ITEM_HEIGHT = 48;
const ITEM_PADDING_TOP = 0;
const MenuProps = {
  PaperProps: {
    style: {
      maxHeight: ITEM_HEIGHT * 4.5 + ITEM_PADDING_TOP,
      width: 150
    }
  }
};
// const minimizableItems = ['molecule', 'L0', 'L3', 'mrp'];
const statusToBgColor = {
  '0_new': '#caddfc',
  '9_excess': '#f7cfb5',
  '1_replenish': '#fccbc7',
  '2_no_replenishment': '#c3dbca'
};
const statusToColor = {
  '0_new': '#4287f5',
  '9_excess': '#Dd6A1F',
  '1_replenish': '#eb4034',
  '2_no_replenishment': '#32a852'
};
const statusToName = {
  '0_new': 'New',
  '9_excess': 'Excess',
  '1_replenish': 'Low Stock',
  '2_no_replenishment': 'Optimal'
};
const statusToIcon = {
  '0_new': NewReleases,
  '9_excess': RemoveShoppingCart,
  '1_replenish': ReportProblem,
  '2_no_replenishment': Check
};
const EditableTable = (props) => {
  const chakratheme = useTheme();
  const { consoleState } = React.useContext(LocationContext);
  const pageSize = props.page_size ? props.page_size : 20;
  const [paginatedData, setPaginatedData] = useState(null);
  const [totalProductsCount, setTotalProductsCount] = useState(props.totalProductsCount);
  const [open, setOpen] = React.useState(false);
  const handleOpen = () => setOpen(true);
  const handleClose = () => setOpen(false);
  // const [minimized, setMinimized] = useState(true);
  const toast = useToast();

  const style = {
    position: 'absolute',
    top: '50%',
    left: '50%',
    transform: 'translate(-50%, -50%)',
    width: 1500,
    maxHeight: 700,
    backgroundColor: 'white',
    overflowY: 'auto',
    p: 4
  };
  const headers = props.headers; // {name: 'Name', id: 'ID', sort: null/''/'asc'}
  const setHeaders = props.setHeaders;
  const paginate = () => {
    setTotalProductsCount(props.totalProductsCount);
    const start = props.page * pageSize - pageSize;
    const end = props.page * pageSize;

    setPaginatedData(props.data && props.data.slice(start, end));
  };

  useEffect(() => {
    paginate();
  }, [pageSize, props.page, props.sortBy, headers, props.data]);
  const tdStyle = {
    fontFamily: 'Arial, sans-serif',
    fontWeight: 'regular', // Replace with your desired font
    padding: '5px 15px',
    fontSize: '12px',
    textAlign: 'left',
    color: `${chakratheme.colors.black[800]}`
  };

  const [newRows, setNewRows] = useState(0);

  const thStyle = {
    color: 'black',
    padding: '10px 15px',
    fontSize: '13px',
    fontWeight: 'bold',
    borderBottom: `1px solid ${chakratheme.colors.gray.light}`,
    textAlign: 'left'
  };
  const handleAutocompleteChange = (value, rowIndex, fieldId) => {
    handleNewRowValueChange(rowIndex, fieldId, value);
  };

  const handleNewRowValueChange = () => {
    // setNewRowsData((prevNewRowsData) =>
    //   prevNewRowsData.map((row, index) => (index === rowIndex ? { ...row, [fieldId]: value } : row))
    // );
  };

  const addNewRow = () => {
    setNewRows(newRows + 1);
    setTotalProductsCount((prevTotalProductsCount) => prevTotalProductsCount + 1);
  };

  const rows = [];
  for (let i = 0; i < newRows; i++) {
    const rowCells = headers.map((header, index) => (
      <Td key={index} colSpan={header.colSpan ? header.colSpan : 1} style={tdStyle}>
        <Editable defaultValue={'-'}>
          <Autocomplete
            // id="free-solo-demo"
            size="small"
            id={`autocomplete-${i}`}
            onChange={(event, value) => handleAutocompleteChange(value, i, header.id)}
            onInputChange={(event, newInputValue) =>
              handleAutocompleteChange(newInputValue, i, header.id)
            }
            style={{
              width: header.id === 'item_name' || header.id === 'description' ? '230px' : '100px',
              borderRadius: '5px',
              padding: '5px'
            }}
            freeSolo
            options={props.autocompleteData.map((option) => option.sap_id)}
            renderInput={(params) => <TextField {...params} color="secondary" label="" />}
          />
        </Editable>
      </Td>
    ));
    rows.push(<Tr>{rowCells}</Tr>);
  }

  const [hoveredRow, setHoveredRow] = useState(null);

  const [addedProducts, setAddedProducts] = useState([]);
  const [selectedSapId, setSelectedSapId] = useState('');
  const [selectedItemName, setSelectedItemName] = useState('');
  const [selectedActualSales, setSelectedActualSales] = useState('');
  const [selectedTotalAmount, setSelectedTotalAmount] = useState('');
  const [selectedMargin, setSelectedMargin] = useState('');
  const [selectedMinQuantity, setSelectedMinQuantity] = useState('');
  const [selectedMrp, setSelectedMrp] = useState('');
  const [selectedMaxQuantity, setSelectedMaxQuantity] = useState('');
  const [isSapValid, setIsSapValid] = useState(true);
  const [isMrpValid, setIsMrpValid] = useState(true);
  const [isSapEntered, setIsSapEntered] = useState(true);
  const [isMrpEntered, setIsMrpEntered] = useState(true);
  const [isDescEntered, setIsDescEntered] = useState(true);
  const [isMinQuantityValid, setIsMinQuantityValid] = useState(true);
  const [isMaxQuantityValid, setIsMaxQuantityValid] = useState(true);

  const handleAdd = () => {
    if (
      selectedSapId === '' ||
      selectedItemName === '' ||
      selectedSapId === null ||
      selectedItemName === null ||
      selectedMrp === null ||
      selectedMrp === ''
    ) {
      if (selectedSapId === '' || selectedSapId === null) {
        setIsSapEntered(false);
      }
      if (selectedItemName === '' || selectedItemName === null) {
        setIsDescEntered(false);
      }
      if (selectedMrp === '' || selectedMrp === null) {
        setIsMrpEntered(false);
      }
      return;
    }

    const existingProduct = addedProducts.find((product) => product.sap_id === selectedSapId);

    if (existingProduct) {
      alert(`SAP ID ${existingProduct.sap_id} already exists in added products!`);
      return;
    }

    const newProduct = {
      sap_id: selectedSapId,
      item_name: selectedItemName,
      mrp: selectedMrp,
      L0: props.L0,
      L3: props.L3,
      min_qty: selectedMinQuantity,
      max_qty: selectedMaxQuantity,
      num_qty_sold: selectedActualSales,
      total_amount: selectedTotalAmount,
      total_margin: selectedMargin
    };

    setAddedProducts([...addedProducts, newProduct]);

    // Clear the selected values after adding the product
    setSelectedSapId('');
    setSelectedItemName('');
    setSelectedActualSales('');
    setSelectedTotalAmount('');
    setSelectedMargin('');
    setSelectedMrp('');
    setSelectedMinQuantity('');
    setSelectedMaxQuantity('');
  };

  const append_rows = () => {
    props.setfinaladdedproducts((prevfinalproducts) => [...addedProducts, ...prevfinalproducts]);
    props.setData((prevProdcuts) => [...addedProducts, ...prevProdcuts]);
    props.setTotalProductsCount(
      (prevTotalProductsCount) => prevTotalProductsCount + addedProducts.length
    );
    handleClose();
    setAddedProducts([]);
  };

  const [deletedProducts, setDeletedProducts] = useState([]);

  const handleRowDeletion = (rowData) => {
    const isSapIdInAddedProducts = props.finaladdedproducts.some(
      (item) => item.sap_id === rowData.sap_id
    );

    if (isSapIdInAddedProducts) {
      const updatedAddedProducts = props.finaladdedproducts.filter(
        (item) => item.sap_id !== rowData.sap_id
      );
      props.setfinaladdedproducts(updatedAddedProducts);
      const updatedPaginatedData = paginatedData.filter((item) => item.sap_id !== rowData.sap_id);
      setPaginatedData(updatedPaginatedData);
      setTotalProductsCount((prevCount) => prevCount - 1);
      return;
    }
    const updatedPaginatedData = paginatedData.filter((item) => item.sap_id !== rowData.sap_id);
    setPaginatedData(updatedPaginatedData);
    setTotalProductsCount((prevCount) => prevCount - 1);
    setDeletedProducts((prevDeletedProducts) => [
      ...prevDeletedProducts,
      ...paginatedData.filter((item) => item.sap_id === rowData.sap_id).map((item) => item.sap_id)
    ]);
  };

  useEffect(() => {
    if (!props.isEdit) {
      if (deletedProducts.length > 0) {
        const formData = new FormData();
        for (let i = 0; i < deletedProducts.length; i++) {
          formData.append('sap_ids', deletedProducts[i]);
        }
        formData.append('br_code', props.selectedRegions[3]);
        let config = {
          method: 'delete',
          url: `${consoleState.state.api.BASE_URL}${consoleState.state.api.DELETE_ASSORTMENT}`,
          data: formData
        };

        axios(config)
          .then(async () => {
            props.hits_and_misses('recommended');
            const productCount = deletedProducts.length;
            const productWord = productCount === 1 ? 'product' : 'products';

            toast({
              position: 'top-middle',
              title: `${productCount} ${productWord} deleted from the recommended assortment`,
              status: 'success',
              duration: 3000,
              isClosable: true
            });
            setDeletedProducts([]);
          })
          .catch(function () {
            console.log('error');
          });
      }
    }
  }, [props.isEdit]);

  const [autocompleteData, setAutocompleteData] = useState([]);
  const [sapids, setsapids] = useState([]);

  const autocompleteapisap = (event, newInputValue) => {
    if (newInputValue !== null || newInputValue !== '') {
      const formDataStat = new FormData();
      formDataStat.append('br_code', props.selectedRegions[3]);
      formDataStat.append('sap_id', newInputValue);
      formDataStat.append('flag', true);
      if (props.selectedCategories[0]) formDataStat.append('L0', props.selectedCategories[0]);
      if (props.selectedCategories[1]) formDataStat.append('L1', props.selectedCategories[1]);
      if (props.selectedCategories[2]) formDataStat.append('L2', props.selectedCategories[2]);
      if (props.selectedCategories[3]) formDataStat.append('L3', props.selectedCategories[3]);
      let configStat = {
        method: 'post',
        url: `${consoleState.state.api.BASE_URL}${consoleState.state.api.AUTOCOMPLETE_SAP_ID}`,
        data: formDataStat
      };
      axios(configStat)
        .then(async (response) => {
          setsapids(response.data);
        })
        .catch(function () {
          console.log('error');
        });
    }
  };

  const autocompleteapi = async (event, newInputValue, callback) => {
    const formDataStat = new FormData();
    formDataStat.append('br_code', props.selectedRegions[3]);
    formDataStat.append('sap_id', newInputValue);
    formDataStat.append('flag', false);
    if (props.selectedCategories[0]) formDataStat.append('L0', props.selectedCategories[0]);
    if (props.selectedCategories[1]) formDataStat.append('L1', props.selectedCategories[1]);
    if (props.selectedCategories[2]) formDataStat.append('L2', props.selectedCategories[2]);
    if (props.selectedCategories[3]) formDataStat.append('L3', props.selectedCategories[3]);

    try {
      // Make the API call
      const response = await axios({
        method: 'post',
        url: `${consoleState.state.api.BASE_URL}${consoleState.state.api.AUTOCOMPLETE_SAP_ID}`,
        data: formDataStat
      });

      // Extract the data
      const data = response.data;

      // Call the callback function with the data
      callback(data);
    } catch (error) {
      // Handle errors
      console.error('Error:', error);
    }
  };
  const primaryColor = 'black';

  const handleAutocompleteeChange = async (event, newValue) => {
    try {
      await autocompleteapi(event, newValue, (data) => {
        // Update the state after the API call
        setAutocompleteData(data);
        setSelectedSapId(newValue);

        const selectedProduct = data.find((film) => film.sap_id === newValue);
        if (selectedProduct) {
          setSelectedItemName(selectedProduct.item_name);
          setSelectedActualSales(selectedProduct.num_qty_sold);
          setSelectedTotalAmount(selectedProduct.total_amount);
          setSelectedMargin(selectedProduct.total_margin);
        }
      });
    } catch (error) {
      // Handle errors from the autocompleteapi function
      console.error('Error:', error);
    }
  };

  const handleDelete = (index) => {
    const updatedProducts = addedProducts.filter((_, i) => i !== index);
    setAddedProducts(updatedProducts);
  };

  // eslint-disable-next-line no-unused-vars
  const TruncatedText = ({ text, maxLength, index }) => {
    // const isHovered = index == hoveredRow;
    const truncatedText =
      // isHovered
      // ? text
      // :
      text && text.length > maxLength ? text.slice(0, maxLength) + '...' : text;
    return (
      <Tooltip title={text} arrow placement="top">
        <span fontSize={'13px'}>{truncatedText}</span>
      </Tooltip>
    );
  };
  // const debouncedHandleKeyChange = debounce((variable, value) => {
  //   // props.setSearchData({
  //   //   ...props.searchData,
  //   //   [variable]: value
  //   // });
  //   props.setAssortmentTableState({
  //     ...props.assortmentTableState,
  //     searchData: {
  //       ...props.assortmentTableState.searchData,
  //       [variable]: value
  //     }
  //   });
  //   props.setPage(1);
  // }, 1000);

  return (
    <>
      <Box
        style={{
          display: 'block'
          // borderRadius: '20px'
        }}>
        <Box
          // borderRadius="20px"
          overflowY="auto"
          overfloX="scroll"
          height={props.height ? props.height : '600px'}
          w="100%"
          maxHeight={props.height ? props.height : '600px'}>
          <Table
            // borderRadius="20px"
            style={{ borderSpacing: '0 1em' }}
            __css={{ width: 'full' }}
            variant="simple"
            colorScheme="teal">
            <Thead
              style={{
                position: 'sticky',
                top: 0,
                zIndex: 6,
                opacity: 1,
                backgroundColor: chakratheme.colors.tableHeaderBg,
                // borderRadius: '20px',
                color: 'white',
                fontWeight: 'bold'
              }}>
              <Tr style={{ borderRadius: '20px', color: primaryColor }}>
                {headers &&
                  headers.map((title, i) => {
                    if (title.name == 'Minimize') {
                      return (
                        <Th
                          key={i}
                          style={{
                            // border: '2px solid black'
                            backgroundColor: `${chakratheme.colors.gray.lighter}`
                          }}
                          _hover={{
                            backgroundColor: `${chakratheme.colors.gray[300]} !important`
                          }}
                          onClick={() => {
                            const newTitle = {
                              ...title,
                              minimized: !title.minimized
                            };
                            const titleIndex = headers.findIndex((item) => item.id === title.id);
                            const newHeaders = [
                              ...headers.slice(0, titleIndex),
                              newTitle,
                              ...headers.slice(titleIndex + 1)
                            ];
                            setHeaders(newHeaders);
                            // setMinimized(!minimized);
                          }}>
                          <Button>
                            {title.minimized ? (
                              <Flex
                                direction="column"
                                justifyContent={'center'}
                                alignItems={'center'}>
                                <Expand
                                  style={{
                                    color: 'grey',
                                    transform: 'rotate(90deg)'
                                  }}
                                />
                                <Text
                                  fontSize={'10px'}
                                  width="50px"
                                  wordWrap="break-all"
                                  textAlign={'center'}
                                  wordBreak={'true'}>
                                  {/* Categories, <br /> MRP &<br />
                                  Molecule */}
                                  {title.minimizeName.map((item) => {
                                    return (
                                      <>
                                        <span style={{ margin: 0 }}>{item}</span>
                                        <br />
                                      </>
                                    );
                                  })}
                                </Text>
                              </Flex>
                            ) : (
                              <UnfoldLess
                                style={{
                                  color: 'grey',
                                  transform: 'rotate(90deg)'
                                }}
                              />
                            )}
                          </Button>
                        </Th>
                      );
                    }
                    const minimizableHeaders = headers.find(
                      (header) =>
                        header.name == 'Minimize' && header.minimizableItems.includes(title.id)
                    );
                    if (minimizableHeaders && minimizableHeaders.minimized) return null;
                    return (
                      <Tooltip
                        arrow
                        placement="top-start"
                        key={i}
                        title={title?.toolTip ? title.toolTipText : null}>
                        <Th
                          _hover={{
                            backgroundColor: `${chakratheme.colors.gray[300]} !important`
                          }}
                          colSpan={title.colSpan ? title.colSpan : 1}
                          onClick={
                            !props.isEdit && title.sort !== undefined
                              ? () => {
                                  props.setPage(1);

                                  let currentSortOrder = '';
                                  if (props.sortOrder === '') {
                                    currentSortOrder = 'desc';
                                  } else if (props.sortOrder === 'desc') {
                                    currentSortOrder = 'asc';
                                  }
                                  console.log(currentSortOrder, props.sortOrder, 'Hello');
                                  props.setSortOrder(currentSortOrder); // Update the sort order state
                                  props.setAssortmentTableState({
                                    ...props.assortmentTableState,
                                    sortData: {
                                      ...props.assortmentTableState.sortData,
                                      sort_param: currentSortOrder !== '' ? title.id : '',
                                      sort_order: currentSortOrder
                                    }
                                  });
                                  props.currentSortOrder !== ''
                                    ? props.setSortBy(title.id)
                                    : props.setSortBy('');
                                  let _headers;
                                  _headers = [
                                    ...headers.slice(0, i).map((item) => {
                                      return {
                                        ...item,
                                        sort: item.sort || item.sort == '' ? '' : null
                                      };
                                    }),
                                    { ...title, sort: currentSortOrder },
                                    ...headers.slice(i + 1).map((item) => {
                                      return {
                                        ...item,
                                        sort: item.sort || item.sort == '' ? '' : null
                                      };
                                    })
                                  ];
                                  setHeaders(_headers);
                                }
                              : !props.isEdit && title.filter != null
                                ? () => {}
                                : null
                          }
                          key={i}
                          style={{
                            ...thStyle,
                            backgroundColor: minimizableHeaders
                              ? `${chakratheme.colors.gray.lighter}`
                              : null
                          }}>
                          <Flex
                            color={primaryColor}
                            fontWeight={'bold'}
                            alignItems="center"
                            justifyContent="flex-start"
                            cursor={'pointer'}>
                            {title.filter == null && title.search == null ? (
                              title.name
                            ) : title.search != null ? (
                              <FormControl
                                sx={{ m: 1, width: title.name === 'Description' ? '30ch' : '15ch' }}
                                variant="outlined">
                                <InputLabel
                                  htmlFor="outlined-adornment-password"
                                  style={{
                                    color: primaryColor,
                                    fontWeight: 'bold',
                                    fontSize: '13px'
                                  }}>
                                  {/* TODO: Get the attribute from backend */}
                                  {title.name === 'Molecule' ? 'Attributes' : title.name}
                                </InputLabel>
                                <OutlinedInput
                                  sx={{
                                    color: primaryColor,
                                    '.MuiOutlinedInput-notchedOutline': {
                                      borderColor: `${chakratheme.colors.gray.light}`
                                    },
                                    '&.Mui-focused .MuiOutlinedInput-notchedOutline': {
                                      borderColor: `${chakratheme.colors.gray.light}`
                                    },
                                    '&:hover .MuiOutlinedInput-notchedOutline': {
                                      borderColor: `${chakratheme.colors.gray.light}`
                                    },
                                    '& > .MuiSvgIcon-root ': {
                                      fill: primaryColor
                                    }
                                  }}
                                  onClick={(e) => {
                                    e.stopPropagation();
                                  }}
                                  id="outlined-adornment-password"
                                  type={'text'}
                                  onChange={(e) => {
                                    const val = e.target.value;
                                    setHeaders(
                                      headers.map((item) => {
                                        if (item.id === title.id) {
                                          return {
                                            ...item,
                                            search_query: val
                                          };
                                        }
                                        return item;
                                      })
                                    );
                                    // debouncedHandleKeyChange(title.search_variable, val);
                                  }}
                                  onKeyDown={(e) => {
                                    console.log(e);
                                    if (e.key === 'Enter') {
                                      const val = headers.find(
                                        (item) => item.id === title.id
                                      ).search_query;
                                      // props.setSearchData({
                                      //   ...props.searchData,
                                      //   [title.search_variable]: val
                                      // });
                                      props.setAssortmentTableState({
                                        ...props.assortmentTableState,
                                        searchData: {
                                          ...props.assortmentTableState.searchData,
                                          [title.search_variable]: val
                                        }
                                      });
                                    }
                                    props.setPage(1);
                                  }}
                                  endAdornment={
                                    <InputAdornment position="end">
                                      <IconButton
                                        aria-label="toggle password visibility"
                                        onClick={(e) => {
                                          console.log(e);
                                          const val = headers.find(
                                            (item) => item.id === title.id
                                          ).search_query;
                                          if (val === '') return;
                                          props.setAssortmentTableState({
                                            ...props.assortmentTableState,
                                            searchData: {
                                              ...props.assortmentTableState.searchData,
                                              [title.search_variable]: val
                                            }
                                          });
                                        }}
                                        edge="end">
                                        <Search style={{ color: primaryColor }} />
                                      </IconButton>
                                    </InputAdornment>
                                  }
                                  label={title.name}
                                />
                              </FormControl>
                            ) : (
                              <Flex direction="column">
                                <FormControl
                                  style={{
                                    minWidth: '120px',
                                    color: primaryColor
                                  }}>
                                  <InputLabel
                                    id="demo-multiple-chip-label"
                                    sx={{
                                      color: primaryColor,
                                      fontSize: '13px',
                                      fontWeight: 600,
                                      '&.Mui-focused': {
                                        color: primaryColor // Change color on focus
                                      }
                                    }}>
                                    Status
                                  </InputLabel>
                                  <Select
                                    labelId="demo-multiple-chip-label"
                                    id="demo-multiple-chip"
                                    multiple
                                    labelStyle={{ color: primaryColor }}
                                    sx={{
                                      color: primaryColor,
                                      '.MuiOutlinedInput-notchedOutline': {
                                        borderColor: `${chakratheme.colors.gray.light}`
                                      },
                                      '&.Mui-focused .MuiOutlinedInput-notchedOutline': {
                                        borderColor: `${chakratheme.colors.gray.light}`
                                      },
                                      '&:hover .MuiOutlinedInput-notchedOutline': {
                                        borderColor: `${chakratheme.colors.gray.light}`
                                      },
                                      '& > .MuiSvgIcon-root ': {
                                        fill: primaryColor
                                      }
                                    }}
                                    fullWidth
                                    value={title.filter}
                                    onChange={(e) => {
                                      const val = e.target.value;
                                      setHeaders(
                                        headers.map((item) => {
                                          if (item.id === title.id) {
                                            return {
                                              ...item,
                                              filter: val
                                            };
                                          }
                                          return item;
                                        })
                                      );
                                      props.setAssortmentStatusFilter(val);
                                      props.setAssortmentTableState({
                                        ...props.assortmentTableState,
                                        filtersData: {
                                          ...props.assortmentTableState.filterData,
                                          filter_type: 'status_label',
                                          filter_params: val
                                        }
                                      });
                                    }}
                                    input={<OutlinedInput id="select-multiple-chip" label="Chip" />}
                                    renderValue={(selected) => (
                                      <Box sx={{ display: 'flex', flexWrap: 'wrap', gap: 0.5 }}>
                                        {selected.map((value) => {
                                          const Icon = statusToIcon[value];
                                          return (
                                            <Chip
                                              icon={
                                                <Icon
                                                  style={{
                                                    color: statusToColor[value],
                                                    fontSize: '14px'
                                                  }}
                                                />
                                              }
                                              onClick={(e) => {
                                                e.stopPropagation();
                                              }}
                                              onMouseDown={(e) => {
                                                e.stopPropagation();
                                              }}
                                              key={value}
                                              label={
                                                title.filterData.find((e) => e.value === value).name
                                              }
                                              deleteIcon={
                                                <Cancel
                                                  style={{
                                                    color: statusToColor[value]
                                                  }}
                                                />
                                              }
                                              onDelete={(e) => {
                                                e.stopPropagation();
                                                setHeaders(
                                                  headers.map((item) => {
                                                    if (item.id === title.id) {
                                                      return {
                                                        ...item,
                                                        filter: item.filter.filter(
                                                          (e) => e !== value
                                                        )
                                                      };
                                                    }
                                                    return item;
                                                  })
                                                );
                                                props.setAssortmentStatusFilter(
                                                  title.filter.filter((e) => e !== value)
                                                );
                                                props.setAssortmentTableState({
                                                  ...props.assortmentTableState,
                                                  filtersData: {
                                                    ...props.assortmentTableState.filterData,
                                                    filter_type: 'status_label',
                                                    filter_params: title.filter.filter(
                                                      (e) => e !== value
                                                    )
                                                  }
                                                });
                                              }}
                                              style={{
                                                fontWeight: 'bold',
                                                backgroundColor: statusToBgColor[value],
                                                color: statusToColor[value]
                                              }}
                                              size="small"
                                            />
                                          );
                                        })}
                                      </Box>
                                    )}
                                    MenuProps={MenuProps}>
                                    {title.filterData.map((ele) => {
                                      const Icon = statusToIcon[ele.value];
                                      return (
                                        <MenuItem
                                          key={ele.value}
                                          value={ele.value}
                                          _hover={{
                                            backgroundColor: ele.bg
                                          }}
                                          style={{
                                            backgroundColor: headers
                                              .find((e) => e.id === title.id)
                                              .filter.includes(ele.value)
                                              ? statusToBgColor[ele.value]
                                              : null,
                                            color: headers
                                              .find((e) => e.id === title.id)
                                              .filter.includes(ele.value)
                                              ? statusToColor[ele.value]
                                              : `${chakratheme.colors.black[400]}`,
                                            fontSize: '13px'
                                          }}>
                                          <Icon
                                            style={{
                                              color: statusToColor[ele.value],
                                              fontSize: '15px',
                                              marginRight: '10px'
                                            }}
                                          />
                                          {ele.name}
                                        </MenuItem>
                                      );
                                    })}
                                  </Select>
                                </FormControl>
                              </Flex>
                            )}
                            {props.isEdit === false &&
                            title.sort != null &&
                            title.sort != undefined ? (
                              <>
                                {title.sort == '' || title.sort == 'asc' || title.sort == 'desc' ? (
                                  <Flex ml={1}>
                                    {title.sort == 'asc' ? (
                                      <Image w="20px" h="20px" m="2px" src={Ascending} />
                                    ) : // <KeyboardDoubleArrowUp style={{ color: 'black' }} />
                                    title.sort == 'desc' ? (
                                      <Image w="20px" h="20px" m="2px" src={Descending} />
                                    ) : (
                                      <FilterList style={{ color: primaryColor }} />
                                    )}
                                  </Flex>
                                ) : null}
                              </>
                            ) : null}
                          </Flex>
                        </Th>
                      </Tooltip>
                    );
                  })}
              </Tr>
            </Thead>
            {props.loading ? (
              <Tbody>
                {Array.from(Array(20).keys()).map((item, i) => {
                  return (
                    <Tr
                      key={i}
                      _hover={{
                        backgroundColor: `${chakratheme.colors.gray.lighter}`
                      }}
                      style={{
                        padding: '20px 0px',
                        borderBottom: `2px solid ${chakratheme.colors.gray.lighter}`
                      }}>
                      {headers &&
                        headers.map((header, index) => {
                          return (
                            <Td
                              key={index}
                              colSpan={header.colSpan ? header.colSpan : 1}
                              style={tdStyle}>
                              <Skeleton
                                variant="rectangular"
                                style={{
                                  width: '90%',
                                  height: '20px'
                                }}
                              />
                            </Td>
                          );
                        })}
                    </Tr>
                  );
                })}
              </Tbody>
            ) : (
              <Tbody w="100%">
                {props.isEdit === true && (
                  <Flex w="100%">
                    <div width="100%">
                      <Flex mb={3} w="100%" justifyContent={'flex-end'}>
                        <Flex onClick={handleOpen}>
                          <Button
                            variant="contained"
                            size="medium"
                            leftIcon={<NoteAdd />}
                            sx={{
                              '&:hover': {
                                backgroundColor: `${chakratheme.colors.gray.lighter}` // Change the hover color as desired
                              },
                              backgroundColor: 'white',
                              color: `${chakratheme.colors.gray.semilight}`,
                              borderRadius: '5px',
                              marginTop: '10px',
                              marginLeft: '10px',
                              marginRight: '20px',
                              boxShadow: 'none',
                              border: `1px solid ${chakratheme.colors.gray.light}`,
                              paddingLeft: '10px',
                              paddingRight: '10px',
                              paddingTop: '5px',
                              paddingBottom: '5px',
                              fontSize: '14px'
                            }}
                            onClick={handleOpen}>
                            Add new product
                          </Button>
                        </Flex>
                        {/* </Tooltip> */}
                      </Flex>
                      <Modal
                        open={open}
                        onClose={handleClose}
                        aria-labelledby="modal-modal-title"
                        aria-describedby="modal-modal-description">
                        <Box sx={style}>
                          <IconButton onClick={handleClose} variant="iconOutline" size="sm">
                            <CloseIcon />
                          </IconButton>
                          <FilterScreen
                            lastIndex={props.lastIndex}
                            fetchBulkData={props.fetchBulkData}
                            uploadedFile={props.uploadedFile}
                            nonedit={true}
                            setUploadedFile={props.setUploadedFile}
                            categoryNested={props.categoryNested} //
                            categoryLevelNames={props.categoryLevelNames}
                            selectedCategories={props.selectedCategories}
                            setSelectedCategories={props.setSelectedCategories}
                            regions_nested={props.regions_nested} //
                            levelNames={props.levelNames}
                            selectedRegions={props.selectedRegions}
                            setSelectedRegions={props.setSelectedRegions}
                            handleSelectedBranch={props.handleSelectedBranch}
                            brandData={props.brandData} //
                            brandLevelNames={props.brandLevelNames}
                            selectedBrands={props.selectedBrands}
                            setSelectedBrands={props.setSelectedBrands}
                            nomfac={true}
                          />
                          <Stack w="100%" direction="row" spacing={2} mt={4}>
                            <FormControl sx={{ marginTop: '50px', width: '50%' }}>
                              <Flex>
                                <Text
                                  component="div"
                                  sx={{
                                    color: `${chakratheme.colors.black[400]}`,
                                    fontWeight: 'bold',
                                    fontSize: '16px'
                                  }}>
                                  Product SAP
                                </Text>
                                <Text
                                  component="div"
                                  sx={{
                                    color: 'red',
                                    fontWeight: 'bold',
                                    fontSize: '18px'
                                  }}>
                                  *
                                </Text>
                              </Flex>
                              <Autocomplete
                                value={selectedSapId}
                                size="medium"
                                onChange={handleAutocompleteeChange}
                                onInputChange={(event, newValue) => {
                                  autocompleteapisap(event, newValue);
                                  /^[0-9]+$/.test(newValue) || newValue === ''
                                    ? setIsSapValid(true)
                                    : setIsSapValid(false);
                                  setSelectedSapId(newValue);
                                  setIsSapEntered(true);
                                }}
                                style={{
                                  borderRadius: '5px',
                                  padding: '5px'
                                }}
                                freeSolo
                                options={sapids && sapids.map((option) => option.sap_id)}
                                renderInput={(params) => (
                                  <TextField
                                    {...params}
                                    error={!isSapValid || !isSapEntered}
                                    helperText={
                                      !isSapEntered
                                        ? 'This is a required field'
                                        : !isSapValid && 'Not a valid number'
                                    }
                                    color="secondary"
                                    label=""
                                    id="sapid"
                                  />
                                )}
                              />
                            </FormControl>
                            <FormControl sx={{ marginTop: '50px', width: '50%' }}>
                              <Flex>
                                <Text
                                  component="div"
                                  sx={{
                                    color: `${chakratheme.colors.black[400]}`,
                                    fontWeight: 'bold',
                                    fontSize: '16px'
                                  }}>
                                  Description
                                </Text>
                                <Text
                                  component="div"
                                  sx={{
                                    color: 'red',
                                    fontWeight: 'bold',
                                    fontSize: '18px'
                                  }}>
                                  *
                                </Text>
                              </Flex>
                              <Autocomplete
                                value={selectedItemName}
                                size="medium"
                                onChange={(event, newValue) => {
                                  setSelectedItemName(newValue);
                                }}
                                onInputChange={(event, newValue) => {
                                  setSelectedItemName(newValue);
                                  newValue !== '' && setIsDescEntered(true);
                                }}
                                style={{
                                  borderRadius: '5px',
                                  padding: '5px'
                                }}
                                freeSolo
                                options={
                                  autocompleteData &&
                                  autocompleteData.map((option) => option.item_name)
                                }
                                renderInput={(params) => (
                                  <TextField
                                    {...params}
                                    error={!isDescEntered}
                                    helperText={!isDescEntered && 'This is a required field'}
                                    color="secondary"
                                    label=""
                                    id="sapid"
                                  />
                                )}
                              />
                            </FormControl>
                          </Stack>
                          <Stack w="100%" direction="row" spacing={2} mt={4}>
                            <FormControl sx={{ marginTop: '50px', width: '33%' }}>
                              <Flex>
                                <Text
                                  component="div"
                                  sx={{
                                    color: `${chakratheme.colors.black[400]}`,
                                    fontWeight: 'bold',
                                    fontSize: '16px'
                                  }}>
                                  {`Retail Price (${consoleState.state.currency || '$'})`}
                                </Text>
                                <Text
                                  component="div"
                                  sx={{
                                    color: 'red',
                                    fontWeight: 'bold',
                                    fontSize: '18px'
                                  }}>
                                  *
                                </Text>
                              </Flex>
                              <Autocomplete
                                value={selectedMrp}
                                size="medium"
                                onChange={handleAutocompleteeChange}
                                onInputChange={(event, newValue) => {
                                  /^[0-9]+$/.test(newValue) || newValue === ''
                                    ? setIsMrpValid(true)
                                    : setIsMrpValid(false);
                                  setSelectedMrp(newValue);
                                  setIsMrpEntered(true);
                                }}
                                style={{
                                  borderRadius: '5px',
                                  padding: '5px'
                                }}
                                freeSolo
                                options={
                                  autocompleteData && autocompleteData.map((option) => option.mrp)
                                }
                                renderInput={(params) => (
                                  <TextField
                                    {...params}
                                    error={!isMrpValid || !isMrpEntered}
                                    helperText={
                                      !isMrpEntered
                                        ? 'This is a required field'
                                        : !isMrpValid && 'Not a valid number'
                                    }
                                    color="secondary"
                                    label=""
                                    id="sapid"
                                  />
                                )}
                              />
                            </FormControl>
                            <FormControl sx={{ marginTop: '50px', width: '33%' }}>
                              <Text
                                component="div"
                                sx={{
                                  color: `${chakratheme.colors.black[400]}`, // Change the color as desired
                                  fontWeight: 'bold',
                                  fontSize: '16px' // Adjust the font size
                                }}>
                                Min Quantity:
                              </Text>
                              <Autocomplete
                                value={selectedMinQuantity}
                                size="medium"
                                onChange={(event, newValue) => setSelectedMinQuantity(newValue)}
                                onInputChange={(event, newValue) => {
                                  setSelectedMinQuantity(newValue);
                                  const isValidNumber = /^(0|[1-9]\d*)(\.\d+)?$/.test(newValue);
                                  isValidNumber || newValue === ''
                                    ? setIsMinQuantityValid(true)
                                    : setIsMinQuantityValid(false);
                                }}
                                style={{
                                  borderRadius: '5px',
                                  padding: '5px'
                                }}
                                freeSolo
                                options={
                                  autocompleteData &&
                                  autocompleteData.map((option) => option.total_margin)
                                }
                                renderInput={(params) => (
                                  <TextField
                                    {...params}
                                    error={!isMinQuantityValid}
                                    helperText={
                                      !isMinQuantityValid && 'Should be a valid positive number'
                                    }
                                    color="secondary"
                                    label=""
                                    id="sapid"
                                  />
                                )}
                              />
                            </FormControl>
                            <FormControl sx={{ marginTop: '50px', width: '33%' }}>
                              <Text
                                component="div"
                                sx={{
                                  color: `${chakratheme.colors.black[400]}`, // Change the color as desired
                                  fontWeight: 'bold',
                                  fontSize: '16px' // Adjust the font size
                                }}>
                                Max Quantity:
                              </Text>
                              <Autocomplete
                                value={selectedMaxQuantity}
                                size="medium"
                                onChange={(event, newValue) => setSelectedMaxQuantity(newValue)}
                                onInputChange={(event, newValue) => {
                                  setSelectedMaxQuantity(newValue);
                                  const isValidNumber = /^(0|[1-9]\d*)(\.\d+)?$/.test(newValue);
                                  isValidNumber || newValue === ''
                                    ? setIsMaxQuantityValid(true)
                                    : setIsMaxQuantityValid(false);
                                }}
                                style={{
                                  borderRadius: '5px',
                                  padding: '5px'
                                }}
                                freeSolo
                                options={
                                  autocompleteData &&
                                  autocompleteData.map((option) => option.total_margin)
                                }
                                renderInput={(params) => (
                                  <TextField
                                    {...params}
                                    error={!isMaxQuantityValid}
                                    helperText={
                                      !isMaxQuantityValid && 'Should be a valid positive number'
                                    }
                                    color="secondary"
                                    label=""
                                    id="sapid"
                                  />
                                )}
                              />
                            </FormControl>
                          </Stack>
                          <Flex w="100%" justifyContent={'flex-end'}>
                            <Button
                              marginTop="15px"
                              variant="contained"
                              onClick={handleAdd}
                              isDisabled={!isSapValid || !isMinQuantityValid || !isMaxQuantityValid}
                              color="primary"
                              sx={{
                                backgroundColor: primaryColor,
                                '&:hover': {
                                  backgroundColor: `${chakratheme.colors.primary.main}` // Change the hover color as desired
                                },
                                '&:active': {
                                  backgroundColor: `${chakratheme.colors.primary.main}` // Change the active color as desired
                                },
                                '&:disabled': {
                                  backgroundColor: `${chakratheme.colors.gray.light}`, // Change the disabled background color as desired
                                  cursor: 'not-allowed' // Change the cursor to indicate not clickable
                                },
                                borderRadius: '35px', // Set the desired border radius
                                padding: '8px 35px', // Adjust padding as needed
                                color: 'white'
                              }}>
                              Add
                            </Button>
                          </Flex>
                          {addedProducts.length > 0 && (
                            <Box mt={2} mb={2}>
                              <Typography variant="h6" mt={2} mb={2}>
                                Added Products
                              </Typography>
                              <Box>
                                <Table
                                  variant="simple"
                                  width="100%"
                                  borderWidth="1px"
                                  borderRadius="md">
                                  <Thead bgColor={`${chakratheme.colors.gray.lighter}`}>
                                    <Tr>
                                      <Th>SAP ID</Th>
                                      <Th>Item Name</Th>
                                      <Th>{`Price(${consoleState.state.currency || '$'})`}</Th>
                                      <Th>Min QTY</Th>
                                      <Th>Max QTY</Th>
                                      <Th></Th>
                                    </Tr>
                                  </Thead>
                                  <Tbody>
                                    {addedProducts.map((product, index) => (
                                      <Tr
                                        key={index}
                                        textAlign="center"
                                        _hover={{ bgColor: `${chakratheme.colors.gray.lighter}` }}>
                                        <Td>{product.sap_id}</Td>
                                        <Td>{product.item_name}</Td>
                                        <Td>{product.mrp}</Td>
                                        <Td>{product.min_qty}</Td>
                                        <Td>{product.max_qty}</Td>
                                        <Td>
                                          <span
                                            className="delete-icon"
                                            style={{
                                              color: `${chakratheme.colors.black[400]}`,
                                              cursor: 'pointer',
                                              display: 'inline-block',
                                              marginLeft: '5px' // Adjust the margin as needed
                                            }}
                                            onClick={() => handleDelete(index)}>
                                            <DeleteIcon />
                                          </span>
                                        </Td>
                                      </Tr>
                                    ))}
                                  </Tbody>
                                </Table>
                              </Box>
                            </Box>
                          )}
                          {addedProducts.length > 0 && (
                            <Flex mt={3} w="100%" justifyContent="flex-end">
                              <Button
                                marginTop="15px"
                                variant="contained"
                                rightIcon={<ArrowForwardIcon />}
                                onClick={append_rows}
                                isDisabled={addedProducts.length === 0}
                                color="primary"
                                sx={{
                                  backgroundColor: `${chakratheme.colors.success.dark}`,
                                  '&:hover': {
                                    backgroundColor: `${chakratheme.colors.success.dark}` // Change the hover color as desired
                                  },
                                  '&:active': {
                                    backgroundColor: `${chakratheme.colors.success.dark}` // Change the active color as desired
                                  },
                                  borderRadius: '35px', // Set the desired border radius
                                  padding: '8px 35px', // Adjust padding as needed
                                  color: 'white',
                                  cursor: addedProducts.length === 0 ? 'not-allowed' : 'pointer'
                                }}>
                                Append
                              </Button>
                            </Flex>
                          )}
                        </Box>
                      </Modal>
                    </div>
                    <Box cursor={'pointer'} onClick={addNewRow}></Box>
                  </Flex>
                )}
                {rows.map((row, index) => (
                  <React.Fragment key={index}>{row}</React.Fragment>
                ))}
                {paginatedData &&
                  paginatedData.map((item, i) => {
                    return (
                      <Tr
                        key={i}
                        onMouseEnter={() => setHoveredRow(i)}
                        onMouseLeave={() => setHoveredRow(null)}
                        style={{
                          padding: '20px 0px',
                          borderBottom: `2px solid ${chakratheme.colors.gray.lighter}`,
                          backgroundColor: props.finaladdedproducts.some(
                            (product) => product['sap_id'] === item['sap_id']
                          )
                            ? `${chakratheme.colors.success.light}`
                            : hoveredRow === i
                              ? `${chakratheme.colors.gray.lighter}`
                              : 'white'
                        }}>
                        {headers &&
                          headers.map((header, index) => {
                            const Icon = statusToIcon[item['status_label']];
                            const minimizableHeader = headers.find(
                              (item) =>
                                item.name === 'Minimize' &&
                                item.minimizableItems.includes(header.id)
                            );
                            if (minimizableHeader && minimizableHeader.minimized) return null;
                            if (header.name == 'Minimize')
                              return (
                                <Td
                                  key={header.id}
                                  border={`2px dashed ${chakratheme.colors.gray[300]}`}
                                  colSpan={header.colSpan ? header.colSpan : 1}></Td>
                              );
                            return (
                              <Td
                                key={header.id}
                                colSpan={header.colSpan ? header.colSpan : 1}
                                bg={
                                  props.showCircle && header.id == 'minimum_replenishment'
                                    ? statusToBgColor[item['status_label']]
                                    : null
                                }
                                alignItems={'center'}
                                style={{
                                  ...tdStyle,
                                  color:
                                    props.showCircle && header.id == 'minimum_replenishment'
                                      ? statusToColor[item['status_label']]
                                      : null,
                                  fontWeight:
                                    props.showCircle && header.id == 'minimum_replenishment'
                                      ? '900'
                                      : 'normal'
                                }}>
                                {props.showCircle && header.id == 'minimum_replenishment' ? (
                                  <Flex alignItems={'center'}>
                                    <Icon style={{ fontSize: '15px' }} />
                                    <Text fontSize={'15px'} ml="10px">
                                      {item[header.id]}
                                    </Text>
                                  </Flex>
                                ) : null}
                                {!props.showCircle ||
                                (header.id !== 'status_label' &&
                                  header.id !== 'molecule' &&
                                  header.id !== 'minimum_replenishment')
                                  ? item[header.id]
                                  : null}
                                {header.id === 'molecule' && (
                                  <Tooltip title={item[header.id]} placement="left">
                                    <TruncatedText
                                      text={item[header.id]}
                                      maxLength={35}
                                      index={i}
                                    />
                                  </Tooltip>
                                )}
                                {props.showCircle && header.id === 'status_label' ? (
                                  <Flex>
                                    <Flex
                                      // w="20px"
                                      // h="2px"
                                      // ml="40px"
                                      borderRadius="20px"
                                      padding="5px 20px"
                                      alignItems={'center'}
                                      fontWeight={'bold'}
                                      bg={statusToBgColor[item['status_label']]}
                                      color={statusToColor[item['status_label']]}>
                                      {<Icon style={{ fontSize: '15px' }} />}
                                      <Spacer />
                                      <Text ml="5px">{statusToName[item['status_label']]}</Text>
                                    </Flex>
                                  </Flex>
                                ) : null}
                                <Tooltip title={'Delete row'} placement="top">
                                  {props.isEdit &&
                                    index === headers.length - 1 &&
                                    i === hoveredRow && (
                                      <span
                                        className="delete-icon"
                                        style={{
                                          color: `${chakratheme.colors.black[400]}`,
                                          cursor: 'pointer',
                                          display: 'inline-block',
                                          marginLeft: '60px',
                                          marginTop: index === headers.length - 1 ? '5px' : '13px'
                                        }}
                                        onClick={() => handleRowDeletion(item)}>
                                        <DeleteIcon />
                                      </span>
                                    )}
                                </Tooltip>
                                {/* } */}
                              </Td>
                            );
                          })}
                      </Tr>
                    );
                  })}
                <style>
                  {`
      .hovered-row .delete-icon {
        visibility: hidden;
      }
    `}
                </style>
              </Tbody>
            )}
          </Table>
        </Box>
        <Divider w="100%" />

        {props.data && props.data.length > 0 && (
          <>
            <Divider />
            <Flex
              style={{
                bottom: '0',
                width: '90%'
              }}
              justifyContent="space-between"
              alignItems="center"
              ml={5}>
              <Text fontSize="14px">
                {`Showing  ${(props.page - 1) * pageSize + 1} to  ${Math.min(
                  props.page * pageSize,
                  totalProductsCount
                )} of ${totalProductsCount} records`}
              </Text>
              <Spacer />
              <Flex justifyContent="flex-end" alignItems="center" mr={10}>
                <Box h="40px" mx={4}>
                  <Divider orientation="vertical" />
                </Box>
                <IconButton
                  onClick={() => props.setPage(props.page - 1)}
                  disabled={props.page === 1}
                  size="sm"
                  variant="iconOutline">
                  <ChevronLeftRounded />
                </IconButton>
                <Text fontSize="14px" size="sm" p={5}>
                  Page {props.page} of {Math.ceil(totalProductsCount / pageSize)}
                </Text>
                <IconButton
                  variant="iconOutline"
                  onClick={() => {
                    if (props.page !== Math.ceil(totalProductsCount / pageSize)) {
                      props.setPage(props.page + 1);
                      if (props.page % 5 === 0 || props.page === 1) {
                        props.handlePagination();
                      }
                    }
                  }}
                  isDisabled={props.page === Math.ceil(totalProductsCount / pageSize)}
                  size="sm">
                  <ChevronRightRounded />
                </IconButton>
              </Flex>
            </Flex>
          </>
        )}
      </Box>
    </>
  );
};
export default EditableTable;
