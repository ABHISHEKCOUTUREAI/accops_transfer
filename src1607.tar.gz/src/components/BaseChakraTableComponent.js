import {
  TableContainer,
  Table,
  Thead,
  Tr,
  Tbody,
  Td,
  Flex,
  Text,
  IconButton,
  Skeleton
} from '@chakra-ui/react';
import { SortButtonComponent } from './SortButtonComponent';
import { useState } from 'react';
import { ChevronLeftRounded, ChevronRightRounded } from '@mui/icons-material';

export const BaseChakraTableComponent = ({
  headers,
  rowData,
  columDataTransformers,
  totalRecords = 100,
  recordFrom = 1,
  recordTo = 10,
  totalPages = 10,
  currentPage = 1,
  nexPageCallback = () => {},
  sortCallBack = () => {},
  loading = false,
  ...props
}) => {
  const [localHeaders, setLocalHeaders] = useState(headers);

  const toggleSort = (curr) => {
    if (curr === 'default') return 'asc';
    if (curr === 'asc') return 'desc';
    if (curr === 'desc') return 'default';
  };

  return (
    <>
      <TableContainer {...props}>
        <Table variant={props.variant || 'simple'} layout={props.layout || 'auto'}>
          {/* <TableCaption>Imperial to metric conversion factors</TableCaption> */}
          <Thead
            bg="#fafafa"
            style={{
              position: 'sticky',
              top: 0,
              zIndex: 6,
              opacity: 1
            }}>
            <Tr>
              {localHeaders &&
                localHeaders.map((h, i) => (
                  <Td
                    color={'black'}
                    cursor={'pointer'}
                    key={i}
                    onClick={() => {
                      setLocalHeaders((prevHeaders) =>
                        prevHeaders.map((header) =>
                          header.key === h.key
                            ? { ...header, sort: toggleSort(header.sort) }
                            : { ...header, sort: header.sort ? 'default' : null }
                        )
                      );
                      // Make an api call wiTd sort filters added
                    }}
                    maxW={h.maxW || '200px'}
                    style={h.width ? { width: h.width } : {}}>
                    <Flex
                      style={{ textWrap: 'wrap' }}
                      onClick={() => {
                        if (h.sort) sortCallBack(h.key, toggleSort(h.sort));
                      }}>
                      <Text alignContent={'center'} fontSize={'14px'} fontWeight={'700'}>
                        {h.title}{' '}
                      </Text>
                      {h.sort && (
                        <Flex>
                          <SortButtonComponent state={h.sort} />
                        </Flex>
                      )}
                    </Flex>
                  </Td>
                ))}
            </Tr>
          </Thead>
          <Tbody>
            {rowData &&
              rowData.map((t, index) => (
                <Tr key={index}>
                  {localHeaders.map((h, ind) => (
                    <Td key={ind}>
                      <Text style={{ textWrap: 'wrap' }}>
                        {columDataTransformers[h.key]
                          ? columDataTransformers[h.key](t, index)
                          : t[h.key]}
                      </Text>
                    </Td>
                  ))}
                </Tr>
              ))}
            {loading &&
              [1, 2, 3, 4, 5].map((t, index) => (
                <Tr key={index}>
                  {localHeaders.map((h, ind) => (
                    <Td key={ind}>
                      <Skeleton width={'100px'} height={'50px'} />
                    </Td>
                  ))}
                </Tr>
              ))}
          </Tbody>
        </Table>
      </TableContainer>
      <Flex p={2} justifyContent={'space-between'}>
        <Text
          fontSize="14px"
          alignContent={
            'space-evenly'
          }>{`Showing ${recordFrom} to ${recordTo} of ${totalRecords}`}</Text>
        <Flex gap={2}>
          <IconButton
            border={'none'}
            _hover={{
              background: '#f2f2f2',
              borderRadius: '50%'
            }}
            variant="iconOutline"
            isDisabled={currentPage <= 1}
            onClick={() => nexPageCallback(currentPage - 1)}>
            <ChevronLeftRounded />
          </IconButton>
          <Text
            fontSize="14px"
            alignContent={'space-evenly'}>{`Page ${currentPage} of ${totalPages}`}</Text>
          <IconButton
            border={'none'}
            _hover={{
              background: '#f2f2f2',
              borderRadius: '50%'
            }}
            isDisabled={currentPage >= totalPages}
            variant="iconOutline"
            onClick={() => nexPageCallback(currentPage + 1)}>
            <ChevronRightRounded />
          </IconButton>
        </Flex>
      </Flex>
    </>
  );
};
