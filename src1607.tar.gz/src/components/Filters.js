import { Image } from '@chakra-ui/image';
import { Flex } from '@chakra-ui/layout';
import { Tune } from '@mui/icons-material';
import {
  Autocomplete,
  Divider,
  //   IconButton,
  //   InputLabel,
  TextField
} from '@mui/material';
import { useTheme } from '@chakra-ui/react';
import React from 'react';

export default function Filters(props) {
  const chakratheme = useTheme();
  return (
    <Flex alignItems="center">
      <Tune style={{ marginLeft: '10px' }} />
      {Object.keys(props.filters).map((filter) => {
        return (
          <Flex ml={10} p={5} key={filter}>
            <Divider orientation="vertical" flexItem style={{ marginRight: '20px' }} />
            <Autocomplete
              sx={{
                // border: "1px solid blue",
                '& .MuiOutlinedInput-root': {
                  border: '0px'
                  // border: "1px solid yellow",
                  // borderRadius: '0',
                  // padding: '10px'
                },
                '& .MuiOutlinedInput-root .MuiOutlinedInput-notchedOutline': {
                  border: `0px solid ${chakratheme.colors.gray.light}`
                },
                '& .MuiOutlinedInput-root.Mui-focused .MuiOutlinedInput-notchedOutline': {
                  border: `0px solid ${chakratheme.colors.gray.light}`
                },
                width: '300px',
                height: '50px',
                padding: '0px'
              }}
              popupIcon={null}
              disablePortal
              id={`combo-box-demo-${filter}`}
              options={props.options[filter]}
              renderInput={(params) => {
                return (
                  <Flex alignItems={'center'}>
                    <Image src={props.icons[filter]} boxSize={'25px'} />
                    <TextField {...params} label={`Select ${filter}`} />
                  </Flex>
                );
              }}
            />
          </Flex>
        );
      })}
    </Flex>
  );
}
