import React from 'react';
import ReactApexChart from 'react-apexcharts';
import { formatNumber } from '../../Utils/formatNumberMillionBillion';

// const formatNumber = (num) => {
//   if (String(num).length <= 3) {
//     return num.toLocaleString();
//   }

//   if (String(num).length === 4 || String(num).length === 5) {
//     return (num / 1000).toFixed(2).toLocaleString('en-US', { minimumFractionDigits: 2 }) + 'K';
//   } else if (String(num).length === 6 || String(num).length === 7) {
//     return (num / 100000).toFixed(2).toLocaleString('en-US', { minimumFractionDigits: 2 }) + 'Lk';
//   } else {
//     return (num / 10000000).toFixed(2).toLocaleString('en-US', { minimumFractionDigits: 2 }) + 'Cr';
//   }
// };

export class BarChartStates extends React.Component {
  constructor(props) {
    super(props);
    console.log('data', this.props.data);
    console.log('labels', this.props.labels);
    // sum all the values for each month

    this.state = {
      series: [
        {
          data: this.props.data1,
          name: 'Total Revenue'
        },
        this.props.data2 === undefined
          ? undefined
          : {
              data: this.props.data2,
              name: 'Total Margin'
            }
      ],
      options: {
        chart: {
          type: 'bar',
          height: 200,
          //   stacked: true,
          events: {
            selection: function () {}
          },
          toolbar: {
            show: false // Hide toolbar icons
          },
          zoom: {
            enabled: false // Disable zooming
          }
        },
        colors: ['#001F3F', '#2BB45B', '#4D94DB', '#71B2E5', '#93C8EF'],
        dataLabels: {
          enabled: false
        },
        plotOptions: {
          bar: {
            borderRadius: 5,
            horizontal: true
          }
        },
        stroke: {
          curve: 'smooth'
        },
        grid: {
          show: false
        },

        legend: {
          position: 'top',
          horizontalAlign: 'left'
        },
        xaxis: {
          categories: this.props.labels,
          labels: {
            formatter: function (val) {
              return formatNumber(val);
            }
          }
        },
        // yaxis: {
        //   labels: {
        //     formatter: function (val) {
        //       return formatNumber(val);
        //     }
        //   }
        // },
        tooltip: {
          y: {
            formatter: function (val) {
              return formatNumber(val);
            }
          }
        }
        // yaxis: {
        //   //   show: false,
        //   labels: {
        //     formatter: function (val) {
        //       return val + 'k';
        //     }
        //   }
        // }
      }
    };
  }

  render() {
    return (
      <div id="chart" style={{ width: '100%' }}>
        <ReactApexChart
          options={this.state.options}
          series={this.state.series}
          type="bar"
          height={350}
          width={'100%'}
        />
      </div>
    );
  }
}
