import {
  Button,
  AlertDialog,
  AlertDialogOverlay,
  AlertDialogHeader,
  AlertDialogContent,
  AlertDialogBody,
  AlertDialogFooter,
  useDisclosure
} from '@chakra-ui/react';
import React, { useState } from 'react';

export const useHardResetCofirmationDialogState = (isDisabled, handleConfirm) => {
  const [state, setState] = useState({
    buttonText: 'Hard Reset',
    header: 'Hard Reset',
    message: 'Do you want to reset orders for the store?',
    confirmButtonText: 'Reset',
    isDisabled: isDisabled,
    onConfirm: handleConfirm
  });

  const setIsDisabled = (status) => {
    setState((s) => ({
      ...s,
      isDisabled: status
    }));
  };
  return [state, setIsDisabled];
};

export const ConfirmationDialog = ({ state }) => {
  const { buttonText, header, message, confirmButtonText, isDisabled, onConfirm } = state;
  const { isOpen, onOpen, onClose } = useDisclosure();
  const cancelRef = React.useRef();

  return (
    <>
      <Button
        onClick={onOpen}
        isDisabled={isDisabled}
        background={'gray.500'}
        _hover={{ background: 'gray' }}>
        {buttonText}
      </Button>
      <AlertDialog isOpen={isOpen} leastDestructiveRef={cancelRef} onClose={onClose}>
        <AlertDialogOverlay>
          <AlertDialogContent>
            <AlertDialogHeader fontSize="lg" fontWeight="bold">
              {header}
            </AlertDialogHeader>

            <AlertDialogBody>{message}</AlertDialogBody>

            <AlertDialogFooter>
              <Button ref={cancelRef} onClick={onClose} variant={'outline'} fontWeight={'400'}>
                Cancel
              </Button>
              <Button
                background={'crimson'}
                _hover={{ background: 'darkred' }}
                onClick={onConfirm}
                ml={3}>
                {confirmButtonText}
              </Button>
            </AlertDialogFooter>
          </AlertDialogContent>
        </AlertDialogOverlay>
      </AlertDialog>
    </>
  );
};
