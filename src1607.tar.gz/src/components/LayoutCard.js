import { Flex, Text } from '@chakra-ui/layout';
import { Popover, PopoverArrow, PopoverContent, PopoverTrigger } from '@chakra-ui/react';
import { InfoOutlined } from '@mui/icons-material';
import { StatUpArrow, StatDownArrow } from '@chakra-ui/react';
import React from 'react';

export default function LayoutCard(props) {
  const heading = props.heading;
  const value = props.value;
  const tooltip = props.tooltip;
  const layoutStyle = props.layoutStyle;
  const preffix = props.preffix;
  const suffix = props.suffix;
  return (
    <Flex direction="column" style={layoutStyle}>
      <Flex flexDir={'row'} justifyContent={'center'}>
        <Text>{heading}</Text>
        <Popover placement="right" trigger="hover">
          <PopoverTrigger>
            <InfoOutlined
              style={{
                width: '15px',
                height: '15px'
              }}
              cursor={'pointer'}
            />
          </PopoverTrigger>
          <PopoverContent maxW="30vh" p={3}>
            <PopoverArrow />
            <Text
              color="black.1000"
              backgroundColor={'white'}
              fontSize="11px"
              wordBreak="break-word"
              wordWrap="break-word"
              ml={1}
              maxW="20vh">
              {tooltip}
            </Text>
          </PopoverContent>
        </Popover>
      </Flex>
      <Flex w="100%" h="100%" justifyContent={'center'} alignItems={'center'}>
        <Text mr={2} fontSize="30px" fontWeight={600} fontFamily={'Sans-Serif'}>
          {preffix}
          {value}
          {suffix}
        </Text>
        {props.icon && props.value ? (
          props.value < 1.0 ? (
            <StatDownArrow boxSize={'30px'} color={'red'} />
          ) : (
            <StatUpArrow boxSize={'30px'} color={'green'} />
          )
        ) : null}
        {/* {props.icon ? props.icon : null} */}
      </Flex>
    </Flex>
  );
}
