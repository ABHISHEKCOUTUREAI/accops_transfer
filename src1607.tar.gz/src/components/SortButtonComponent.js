import { Image, useTheme } from '@chakra-ui/react';
import Ascending from '../Static/ascending.png';
import Descending from '../Static/descending.png';
import { FilterList } from '@mui/icons-material';
export const SortButtonComponent = ({ state = 'default' }) => {
  const chakratheme = useTheme();
  return (
    <>
      {state === 'asc' && <Image w="20px" h="20px" m="2px" src={Ascending} />}
      {state === 'desc' && <Image w="20px" h="20px" m="2px" src={Descending} />}
      {state === 'default' && (
        <FilterList style={{ color: `${chakratheme.colors.primary.main}` }} />
      )}
    </>
  );
};
