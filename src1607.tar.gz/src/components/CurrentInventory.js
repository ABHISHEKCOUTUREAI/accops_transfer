import { Box, Flex, Text, useTheme, Stack, Heading } from '@chakra-ui/react';
import { InfoOutlined } from '@mui/icons-material';
import RingChart from '../Artifactory/Charts/RingChart';
import { Skeleton, Tooltip } from '@mui/material';
import {
  ArrowUpward,
  Launch,
  NewReleases,
  RemoveShoppingCart,
  ReportProblem,
  Check,
  ArrowDownward,
  UnfoldMore
} from '@mui/icons-material';
import { useContext, useEffect, useState } from 'react';
import { LocationContext } from '../Contexts/LocationContext';
import { useMemo } from 'react';
import { CategoryDonutView } from './CategoryDonutView';
import { formatInternationalStandard } from '../Utils/formatInternationalStandard';
import { getCategoryAnalyticsAPI } from '../Utils/CategoryAnalyticsAPI';
// import { ArrowUpward } from '@mui/icons-material';
const statusToIcon = {
  '0_new': NewReleases,
  '9_excess': RemoveShoppingCart,
  '1_replenish': ReportProblem,
  '2_no_replenishment': Check
};
const CurrentInventory = (props) => {
  const { consoleState } = useContext(LocationContext);
  const chakratheme = useTheme();
  const cardNames = ['replenish', 'excess', 'optimal', 'new'];
  const [localFilters, setLocalFilters] = useState(props.globalFilters);
  const [donutChartData, setDonutChartData] = useState([]);
  const cardMap = {
    excess: {
      name: 'Excess Products',
      value: props.values['excess'],
      change: '12.5%',
      color: `${chakratheme.colors.orange}`,
      id: '9_excess',
      tooltip: 'Products with existing inventory greater than maximum recommended quantity.'
    },
    replenish: {
      name: 'Low Stock Products',
      value: props.values['replenish'],
      change: '12.5%',
      color: 'red',
      id: '1_replenish',
      tooltip:
        'Products with existing inventory less than minimum recommended quantity (These require replenishment)'
    },
    optimal: {
      name: 'Optimal Products',
      value: props.values['optimal'],
      change: '12.5%',
      color: `${chakratheme.colors.success.main}`,
      id: '2_no_replenishment',
      tooltip:
        'Products with existing inventory in between minimum and maximum recommended quantity (These dont require any action)'
    },
    new: {
      name: 'New Products',
      value: props.values['new'],
      change: '12.5%',
      color: 'blue',
      id: '0_new',
      tooltip:
        "Products not in the Store's existing inventory, but are recommended by our assortment."
    }
  };
  const categoryAnalyticsAPI = getCategoryAnalyticsAPI(consoleState);
  const inventoryStats = ['inventory_value', 'inventory_units'];
  const inventoryStatsMap = {
    inventory_value: {
      name: 'Recommended Inventory Value',
      value: props.values.recommended_inventory_cost,
      from: props.values.inhand_inventory_cost,
      ext: consoleState.state.currency || '$'
    },
    inventory_units: {
      name: 'Reccomended Inventory Width',
      value: props.values.recommended_assortment_width,
      from: props.values.inhand_assortment_width,
      ext: ''
    }
  };
  const [cardHovered, setCardHovered] = useState(null);
  const [assortmentStatusFilter, setAssortmentStatusFilter] = useState(null);

  const categoryDonutView = useMemo(() => {
    return <CategoryDonutView data={donutChartData} />;
  }, [donutChartData]);

  const fetchPieChartData = async (formData) => {
    try {
      let res = await categoryAnalyticsAPI.getCategoryDistributionDonut(formData);
      setDonutChartData(res.data);
    } catch (e) {
      console.log(e);
    }
  };

  const attachParamToLocalFilter = (param) => {
    setLocalFilters((prevFilters) => {
      let formData = new FormData();
      // Copy previous filter parameters to the new FormData object
      for (let [key, value] of prevFilters.entries()) {
        if (key !== 'filter_params') {
          formData.append(key, value);
        }
      }
      if (param) formData.append('filter_params', param);
      return formData;
    });
  };

  useEffect(() => {
    if (localFilters) fetchPieChartData(localFilters);
  }, [localFilters]);

  useEffect(() => {
    // Global filters override the local ones when changed
    setLocalFilters(props.globalFilters);
  }, [props.globalFilters]);

  return (
    <Box w="100%">
      <Flex justifyContent={'space-between'} gap="20px">
        <Flex flex={1} gap={'20px'} direction={'column'}>
          {consoleState.state.features.totalInventoryInfo.display && (
            <Flex flex={1} gap="20px">
              <Flex
                w={'66%'}
                gap={'20px'}
                style={{
                  boxShadow: `${chakratheme.colors.shadow} 0px 0px 20px 0px`,
                  margin: '0px 0px',
                  padding: '20px',
                  borderRadius: '20px'
                }}>
                <Flex
                  w={'50%'}
                  borderRadius={'20px'}
                  direction={'column'}
                  fontFamily={'Hanken Grotesk'}>
                  <Text fontWeight={'bold'} mb="20px">
                    Total Inventory Information
                  </Text>
                  <Stack gap={'20px'}>
                    <Box bg={'#f2f2f2'} p={'10px'}>
                      <Heading size="sm">Recommended Inventory Value</Heading>
                      <Text pt="2" fontSize="14px" color={'#808080'} fontStyle={'italic'}>
                        Sum of cost price of maximum recommended quantity of each inventory item
                        {/* <p>&Sigma;(max_qty &times; det_cogs)</p> */}
                      </Text>
                    </Box>
                    <Box bg={'#f2f2f2'} p={'10px'}>
                      <Heading size="sm">Recommended Inventory Width</Heading>
                      <Text pt="2" fontSize="14px" color={'#808080'} fontStyle={'italic'}>
                        Total number of unique recommended inventory items
                      </Text>
                    </Box>
                  </Stack>
                </Flex>
                <Flex direction={'column'} justifyContent={'space-between'} w={'50%'} gap={'20px'}>
                  {inventoryStats.map((card) => {
                    const delta = (
                      ((inventoryStatsMap[card].value - inventoryStatsMap[card].from) /
                        inventoryStatsMap[card].from) *
                      100
                    ).toFixed(2);
                    const deltaPercent = delta > 0 ? `+${delta}` : delta;
                    return (
                      <Flex
                        w="100%"
                        key={card}
                        // w="24%"
                        direction="column"
                        style={{
                          backgroundColor: 'white',
                          color: 'black',
                          boxShadow: `${chakratheme.colors.shadow} 0px 0px 8px 0px`,
                          padding: '20px',
                          borderRadius: '20px',
                          fontFamily: 'Hanken Grotesk'
                        }}>
                        <Text fontWeight={'bold'} mb="20px">
                          {inventoryStatsMap[card].name}
                        </Text>
                        {inventoryStatsMap[card].value ? (
                          <>
                            <Flex alignItems={'center'} wrap="wrap">
                              <Text fontSize={'32px'}>
                                {
                                  inventoryStatsMap[card].ext // add currency symbol
                                }
                                {formatInternationalStandard(inventoryStatsMap[card].value)}
                              </Text>
                              <Flex
                                ml={2}
                                padding="2px 10px"
                                fontSize={'12px'}
                                borderRadius={'10px'}
                                alignItems="center"
                                fontWeight={'bold'}
                                color={
                                  delta > 0
                                    ? `${chakratheme.colors.success.main}`
                                    : delta < 0
                                      ? `${chakratheme.colors.red}`
                                      : `${chakratheme.colors.black[400]}`
                                }
                                backgroundColor={
                                  delta > 0
                                    ? `${chakratheme.colors.success.light}`
                                    : delta < 0
                                      ? `${chakratheme.colors.lightred}`
                                      : `${chakratheme.colors.gray.lighter}`
                                }>
                                {delta > 0 ? (
                                  <ArrowUpward style={{ fontSize: '15px' }} />
                                ) : delta < 0 ? (
                                  <ArrowDownward style={{ fontSize: '15px' }} />
                                ) : (
                                  <UnfoldMore style={{ fontSize: '15px' }} />
                                )}{' '}
                                <Text>{deltaPercent}%</Text>
                              </Flex>
                            </Flex>
                            <Text
                              style={{
                                fontSize: '15px',
                                color: `${chakratheme.colors.black[400]}`,
                                marginTop: '10px',
                                fontStyle: 'italic'
                              }}>
                              {delta > 0 ? 'Up' : delta < 0 ? 'Down' : 'Same as'} from{' '}
                              <span
                                style={{
                                  color: `${chakratheme.colors.primary.main}`,
                                  fontWeight: 'bold',
                                  fontSize: '20px'
                                }}>
                                {
                                  inventoryStatsMap[card].ext // add currency symbol
                                }
                                {formatInternationalStandard(inventoryStatsMap[card].from)}
                              </span>{' '}
                              in the existing inventory
                            </Text>
                          </>
                        ) : (
                          <Skeleton height={'100px'} width={'100%'} />
                        )}
                      </Flex>
                    );
                  })}
                </Flex>
              </Flex>

              <Flex
                // w="400px"
                w={'33%'}
                direction="column"
                borderRadius={'20px'}
                style={{
                  boxShadow: `${chakratheme.colors.shadow} 0px 0px 20px 0px`,
                  margin: '0px 0px',
                  backgroundColor: `${chakratheme.colors.primary.main}`
                }}>
                <Text
                  fontWeight="bold"
                  color={'white'}
                  padding={'20px'}
                  style={{
                    fontFamily: 'Hanken Grotesk'
                  }}>
                  Inventory Status
                </Text>
                {!props.loading ? (
                  <RingChart
                    totalproducts={props.totalproducts}
                    series={[
                      props.values['excess'],
                      props.values['replenish'],
                      props.values['optimal'],
                      props.values['new']
                    ]}
                    width="100%"
                    label={props.categories}
                    title=""
                  />
                ) : (
                  <Skeleton
                    variant="rectangular"
                    width="200px"
                    height="400px"
                    style={{ margin: '10px', borderRadius: '20px' }}
                  />
                )}
              </Flex>
            </Flex>
          )}

          <Flex w={'100%'} gap={'20px'} h={'400px'}>
            {consoleState.state.features.inventoryStockStatus.display && (
              <Flex gap={'20px'}>
                <Flex
                  direction={'column'}
                  gap={'20px'}
                  boxShadow={`${chakratheme.colors.shadow} 0px 0px 32px 0px`}
                  padding={'20px'}
                  // pb={'20px'}
                  borderRadius={'20px'}>
                  <Flex>
                    <Text
                      style={{
                        fontSize: '16px',
                        fontFamily: 'Poppins',
                        fontWeight: 'bold',
                        marginTop: '0px'
                      }}>
                      Inventory Stock Status
                    </Text>
                  </Flex>

                  <Flex
                    wrap="wrap"
                    flex={1}
                    // gap="2%"
                    columnGap={'2%'}
                    rowGap={'20px'}
                    justifyContent={'space-between'}>
                    {cardNames.map((card, i) => {
                      const Icon = statusToIcon[cardMap[card].id];
                      return (
                        <Flex
                          key={card}
                          w="48%"
                          // w="250px"
                          // marginLeft="5px"
                          // marginRight="5px"
                          direction="column"
                          cursor={'pointer'}
                          _hover={
                            cardMap[card].id !== assortmentStatusFilter
                              ? {
                                  backgroundColor: `${chakratheme.colors.heroColorHover} !important`
                                }
                              : {}
                          }
                          onMouseEnter={() => setCardHovered(card)}
                          onMouseLeave={() => setCardHovered(null)}
                          onClick={() => {
                            // props.setAssortmentStatusFilter([cardMap[card].id]);
                            if (cardMap[card].id !== assortmentStatusFilter) {
                              setAssortmentStatusFilter(cardMap[card].id);
                              attachParamToLocalFilter(cardMap[card].id);
                              props.setAssortmentTableState({
                                ...props.assortmentTableState,
                                filtersData: {
                                  ...props.assortmentTableState.filtersData,
                                  filter_params: [cardMap[card].id]
                                }
                              });
                              props.setHeaders([
                                {
                                  ...props.headers[0],
                                  filter: [cardMap[card].id]
                                },
                                ...props.headers.slice(1)
                              ]);
                              props.handleScroll();
                            } else {
                              setAssortmentStatusFilter(null);
                              attachParamToLocalFilter(null);

                              props.setAssortmentTableState((prev) => {
                                let newFiltersData = { ...prev.filtersData };
                                delete newFiltersData.filter_params;
                                return {
                                  // ...props.assortmentTableState,
                                  ...prev,
                                  filtersData: newFiltersData
                                };
                              });
                              props.setHeaders([
                                {
                                  ...props.headers[0],
                                  filter: [cardMap[card].id]
                                },
                                ...props.headers.slice(1)
                              ]);
                              props.handleScroll();
                            }
                          }}
                          style={{
                            backgroundColor:
                              cardMap[card].id === assortmentStatusFilter
                                ? `${chakratheme.colors.primary.light}`
                                : 'white',
                            // backgroundColor: 'white',
                            // color: cardMap[card].id === assortmentStatusFilter ? 'white' : 'black',
                            color: 'black',
                            // color: 'black',
                            boxShadow: `${chakratheme.colors.shadow} 0px 0px 8px 0px`,
                            padding: '20px 20px 10px 20px',
                            borderRadius: '20px',
                            // borderTopLeftRadius: 0,
                            // borderBottomLeftRadius: 0,
                            fontFamily: 'Hanken Grotesk',
                            // borderLeft: '5px solid',
                            border:
                              cardMap[card].id === assortmentStatusFilter
                                ? `1px solid ${chakratheme.colors.gray['400']}`
                                : 'none'
                          }}>
                          <Flex alignItems={'flex-start'} mb="10px" direction={'column'}>
                            <Box
                              mr="2"
                              style={{
                                backgroundColor: cardMap[card].color,
                                width: '20px',
                                height: '5px',
                                borderRadius: '5px'
                              }}></Box>
                            <Flex fir={'row'}>
                              <Text fontWeight={'bold'}>{cardMap[card].name}</Text>
                              {cardMap[card].tooltip && (
                                <Tooltip arrow placement="top-start" title={cardMap[card].tooltip}>
                                  <InfoOutlined
                                    style={{
                                      width: '15px',
                                      height: '15px'
                                    }}
                                    cursor={'pointer'}
                                  />
                                </Tooltip>
                              )}
                            </Flex>
                          </Flex>
                          <Flex alignItems={'center'} wrap="wrap">
                            <Icon
                              style={{
                                fontSize: '30px',
                                marginRight: '10px',
                                color: cardMap[card].color,
                                opacity: 0.3
                              }}
                            />
                            {cardMap[card].value ? (
                              <>
                                <Text
                                  fontSize={'35px'}
                                  // color={i == 0 ? 'white' : null}
                                  fontWeight={i == 0 ? 'bold' : null}>
                                  {formatInternationalStandard(cardMap[card].value)}
                                </Text>
                                <Launch
                                  style={{
                                    visibility: cardHovered === card ? 'visible' : 'hidden',
                                    color:
                                      i == 0
                                        ? `${chakratheme.colors.black[400]}`
                                        : `${chakratheme.colors.gray.light}`,
                                    marginLeft: '10px'
                                  }}
                                />
                              </>
                            ) : (
                              <Skeleton height={'60px'} width={'100px'} />
                            )}
                          </Flex>
                        </Flex>
                      );
                    })}
                  </Flex>
                </Flex>
              </Flex>
            )}
            <Flex flex={1}>{categoryDonutView}</Flex>
          </Flex>
        </Flex>
      </Flex>
    </Box>
  );
};
export default CurrentInventory;
