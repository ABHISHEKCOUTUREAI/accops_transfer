import axios from 'axios';
export const fetchPastSales = async (consoleState) => {
  const formData = new FormData();
  formData.append('checkbox', false);

  let config = {
    method: 'post',
    url: `${consoleState.state.api.BASE_URL}${consoleState.state.api.PAST_SALES}`,
    data: formData
  };

  const response = await axios(config);

  const _data = response.data;
  const topCategory = consoleState.state.globalFilters.category.levelNames[0];
  const revenueKey = consoleState.state.pastSales.keys.revenue;
  const marginKey = consoleState.state.pastSales.keys.margin;
  const keyProcessor = consoleState.state.pastSales.keyProcessor;
  const data = Object.keys(_data).reduce((acc, key) => {
    const _key = keyProcessor(key);
    acc[_key] = _data[key];
    return acc;
  }, {});

  const categorySet = new Set();
  Object.values(data).forEach((item) => {
    item.forEach((key) => {
      categorySet.add(key[topCategory]);
    });
  });

  const categories = Array.from(categorySet);
  // const categories_l0 = ['Surgical', 'Devices', 'Pharma', 'Generics', 'Non Pharma'];
  const newDataRevenue = Object.keys(data).reduce((acc, key) => {
    const item = data[key];
    let temp = {};
    item.map((dict) => {
      if (temp[dict[topCategory]]) temp[dict[topCategory]] += Math.round(dict[revenueKey] / 1000);
      else temp[dict[topCategory]] = Math.round(dict[revenueKey] / 1000);
    });
    categories.forEach((category) => {
      if (!temp[category]) temp[category] = 0;
    });
    acc[key] = temp;
    return acc;
  }, {});
  const newDataMargin = Object.keys(data).reduce((acc, key) => {
    const item = data[key];
    let temp = {};
    item.map((dict) => {
      if (temp[dict[topCategory]]) temp[dict[topCategory]] += Math.round(dict[marginKey] / 1000);
      else temp[dict[topCategory]] = Math.round(dict[marginKey] / 1000);
    });
    categories.forEach((category) => {
      if (!temp[category]) temp[category] = 0;
    });
    acc[key] = temp;
    return acc;
  }, {});
  console.log('salesData', {
    revenue: newDataRevenue,
    margin: newDataMargin
  });
  return {
    revenue: newDataRevenue,
    margin: newDataMargin
  };
};
