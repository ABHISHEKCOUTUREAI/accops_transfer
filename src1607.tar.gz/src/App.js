import { ThemeProvider, createTheme } from '@mui/material';
import './App.css';
import Main from './Main';

function App() {
  const theme = createTheme({
    palette: {
      primary: {
        main: '#28268C',
        dark: '#001064'
      },
      secondary: {
        main: '#ffffff',
        dark: '#ba000d'
      }
    }
  });
  return (
    <div className="App">
      <ThemeProvider theme={theme}>
        <Main />
      </ThemeProvider>
    </div>
  );
}

export default App;
