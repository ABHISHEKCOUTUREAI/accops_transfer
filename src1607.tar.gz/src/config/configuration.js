/* eslint-disable no-unused-vars */
import fmcg from './fmcg';
import pharma from './pharma';
import electronics from './electronics';
// import pharmaSTD from './pharmaSTD';

const configs = { pharma: pharma, fmcg: fmcg, electronics: electronics };
const configuration = configs[process.env.REACT_APP_CONSOLE_TYPE || 'fmcg'];

export default configuration;
