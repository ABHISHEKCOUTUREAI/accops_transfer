import State from '../Static/state.png';
import City from '../Static/city.png';
import Branch from '../Static/store.png';
import L0 from '../Static/L0.png';
import L1 from '../Static/L1.png';
import L2 from '../Static/L2.png';
import L3 from '../Static/L3.png';
import brand from '../Static/brand.png';
import manufacturer from '../Static/manufacturer.png';
import { PlaylistAddCheck } from '@mui/icons-material';
import { numberToMonth } from '../Utils/misc';
import { constants } from '../Static/properties/properties';
const config = {
  name: 'FMCG',
  homeScreenTitle: 'Product Recommender',
  constants: constants,
  currency: '$',
  api: {
    BASE_URL: process.env.REACT_APP_API_BASE_FMCG_URL,
    GET_FILTERS: '/fetch-filters',
    ASSORTMENT: '/hit-and-miss',
    ASSORTMENT_CSV: '/hit-miss-csv',
    PAST_SALES: '/past-sales',
    TOP_MFAC: '/top-mfac-brand',
    MFAC_REVENUE: '/mfac-revenue',
    ASSORTMENT_COMPOSITION: '/category-distribution',
    MAP: '/map',
    APPEND_ASSORTMENT: '/append',
    BULK_ASSORTMENT: '/bulk-assortment',
    AIOCD_SALES: '/aiocd-sales',
    IQVIA_SALES: '/iqvia-sales',
    MARKET_TREND: '/market-trends-l2l3',
    SALES_FILTER: '/sales-filters',
    AUTOCOMPLETE_SAP_ID: '/autocomplete-sap-id',
    DELETE_ASSORTMENT: '/delete',
    L2L3_TABLE: '/l2l3-table',
    NEW_PRODUCT_STATS: '/new-product-stats',
    NEW_PRODUCTS: '/new-products',
    NEW_PRODUCTS_CSV: '/new-products-csv',
    MARGIN_BUCKETS: '/margin-buckets',
    CRITICAL_LOW_STOCK: '/critical-low-stock',
    CATEGORY_TREEMAP: '/category-treemap',
    CATEGORY_DISTRIBUTION: '/category-distribution',
    GET_CART: '/get-cart',
    ADD_TO_CART: '/cart',
    ORDERS: '/orders',
    PLACE_ORDER: '/place-order',
    ORDER_DETAILS: '/order-details',
    HARD_RESET_ORDER: '/hard-reset',
    DEMAND_SURGE_PRODUCTS: '/demand/get-surging-products',
    DEMAND_DIP_PRODUCTS: '/demand/get-dipping-products',
    NOTIFICATIONS: '/notifications/'
  },
  pages: {
    storeAssortment: {
      display: true
    },
    assortmentAnalysis: {
      display: true
    },
    assortmentCustom: {
      display: true
    },
    marketTrends: {
      display: true
    },
    freshStore: {
      display: true
    },
    chatbot: {
      display: true
    }
  },
  globalFilters: {
    region: {
      filterGroup: 'Select Region',
      level: true,
      keepDefault: true,
      default: ['West', 'California', 'Sacramento'],
      levelNames: ['Zone', 'State', 'City', 'Branch'],
      levelData: {
        Zone: {
          State: {
            City: {
              Branch: {}
            }
          }
        }
      },
      responseKey: 'location',
      icons: [State, City, Branch],
      selected: ['West', 'California', 'Sacramento']
    },
    category: {
      countApiKey: 'filters_count',
      filterGroup: 'Select Category',
      level: true,
      levelNames: ['L0', 'L1', 'L2', 'L3'],
      levelExamples: ['Non Pharma', 'Nutrition', 'Electrolytes', 'Supplements'],
      apiKeys: ['L0', 'L1', 'L2', 'L3'],
      responseKey: 'category',
      levelData: {
        L0: {
          L1: {
            L2: {
              L3: {}
            }
          }
        }
      },
      icons: [L0, L1, L2, L3, L3],
      selected: [null, null, null, null, null]
    },
    manufacturer: {
      filterGroup: 'Select Manufacturer',
      level: true,
      levelNames: ['Manufacturer', 'Brand'],
      apiKeys: ['mfac_name', 'brand_name'],
      responseKey: 'mfac',
      levelData: {
        Manufacturer: {
          Brand: {}
        }
      },
      icons: [manufacturer, brand],
      selected: [null, null, null, null]
    }
  },
  globalFiltersExample: {
    Zone: 'West Bengal',
    City: 'Kolkata',
    Branch: '2316',
    sbu: 'home',
    segment: 'steel',
    family: 'kitchenware',
    class: 'cutlery',
    brick: 'cutlery spoon',
    Brand: 'PRANDIAL M',
    Manufacturer: 'BIOCON LTD'
  },

  pastSales: {
    keyProcessor: (key) => {
      const month = numberToMonth(parseInt(key.split('-')[1]));
      const year = key.split('-')[0];
      key = `${month} ${year}`;
      return key;
    },
    keys: {
      margin: 'margin',
      revenue: 'net_amount',
      quantity: 'total_quantity'
    }
  },
  features: {
    assortmentTable: {
      display: true
    },
    assortmentAnalysisTable: {
      display: true,
      productSpread: false
    },
    manufacturerCharts: {
      display: true,
      topMfacs: true,
      pastSales: true
    },
    pastSales: {
      display: true
    },
    marketTrends: ['AIOCD', 'IQVIA']
  },
  assortmentTable: {
    editable: true,
    types: {
      assortment: {
        name: 'Recommended',
        apiKey: 'assortment',
        icon: PlaylistAddCheck,
        color: 'blue'
      }
    },
    defaults: {
      type: 'assortment',
      sortData: {
        sort_param: 'num_qty_sold',
        sort_type: 'desc'
      },
      filterData: {
        filter_type: 'status_label'
      }
    },
    headers: (theme) => {
      return [
        {
          name: 'Status',
          id: 'status_label',
          filter: [],
          filterData: [
            {
              name: 'Excess',
              value: '9_excess',
              color: 'red',
              bg: `${theme.colors.lightred}`
            },
            {
              name: 'New',
              value: '0_new',
              color: 'green',
              bg: `${theme.colors.success.light}`
            },
            {
              name: 'Low Stock',
              value: '1_replenish',
              color: 'orange',
              bg: `1px solid ${theme.colors.lightorange}`
            },
            {
              name: 'Optimal',
              value: '2_no_replenishment',
              color: `${theme.colors.gray.light}`,
              bg: `${theme.colors.gray.lighter}`
            }
          ],

          colSpan: 3
        },
        {
          name: 'ID',
          id: 'product_id',
          sort: '',
          colSpan: 0,
          search: true,
          search_query: '',
          search_variable: 'product_id'
        },
        {
          name: 'Name',
          id: 'product_name',
          sort: '',
          colSpan: 4,
          type: 'text',
          search: true,
          search_query: '',
          search_variable: 'product_name'
        },

        {
          name: 'Minimize',
          colSpan: 1,
          id: 'minimize_info',
          minimizableItems: ['L0', 'L3'],
          minimizeName: ['Categories'],
          minimized: false
        },
        {
          name: 'SBU',
          id: 'L0',
          // sort: '',
          colSpan: 2,
          type: 'text',
          toolTip: true,
          toolTipText: 'Strategic Business Unit: A fully-functional unit of a business'
        },
        {
          name: 'Segment',
          id: 'L3',
          // sort: '',
          colSpan: 2,
          type: 'text',
          toolTip: true,
          toolTipText: 'Segment: The Product Segment'
        },
        {
          name: 'Retail Price ($)',
          id: 'price',
          sort: '',
          colSpan: 2,
          type: 'text'
        },
        {
          name: 'Existing Inventory',
          id: 'current_inventory',
          sort: '',
          colSpan: 2,
          type: 'text'
        },

        {
          name: 'Minimize',
          colSpan: 1,
          id: 'minimize_qty',
          minimizableItems: ['min_qty', 'max_qty'],
          minimizeName: ['Predicted', 'Quantities'],
          minimized: true
        },
        {
          name: 'Order trigger qty',
          id: 'min_qty',
          sort: '',
          colSpan: 2,
          type: 'text',
          toolTip: true,
          toolTipText: 'Quantity at which the order replenishment is triggered'
        },
        {
          name: 'Max stocked qty',
          id: 'max_qty',
          sort: '',
          colSpan: 2,
          type: 'text',
          toolTip: true,
          toolTipText: 'Max Quantity which can be stocked'
        },
        {
          name: 'Recommended Replenishment',
          id: 'minimum_replenishment',
          sort: '',
          colSpan: 2,
          toolTip: true,
          colorScheme: true,
          toolTipText:
            'Minimum replenishment required. If current inventory is less than the min quantity, \n then replenishment is min quantity - current inventory\n, if current inventory is greater than min quantity and less than max quantity, then replenishment is 0, else replenishment is max quantity - current inventory'
        }
      ];
    },
    analysisHeaders: [
      {
        name: 'ID',
        id: 'product_id',
        sort: '',
        colSpan: 4,
        search: true,
        search_query: '',
        search_variable: 'product_id'
      },
      {
        name: 'Name',
        id: 'product_name',
        sort: '',
        colSpan: 5,
        type: 'text',
        search: true,
        search_query: '',
        search_variable: 'product_name'
      },

      {
        name: 'SBU',
        id: 'L0',
        colSpan: 2,
        type: 'text',
        tooltip: true,
        toolTipText: 'Strategic Business Unit: A fully-functional unit of a business'
      },
      {
        name: 'Segment',
        id: 'L3',
        colSpan: 2,
        type: 'text',
        toolTip: true,
        toolTipText: 'Segment: The Product Segment'
      },
      {
        name: 'Retail Price ($)',
        id: 'price',
        sort: '',
        colSpan: 2,
        type: 'text'
      },
      {
        name: 'Pre-existing Inventory',
        id: 'current_inventory',
        sort: '',
        colSpan: 2,
        type: 'text'
      },

      {
        name: 'Suggested Order trigger qty',
        id: 'min_qty',
        sort: '',
        colSpan: 2,
        type: 'text',
        toolTip: true,
        toolTipText: 'Quantity at which the order replenishment is triggered'
      },
      {
        name: 'Suggested Max stocked qty',
        id: 'max_qty',
        sort: '',
        colSpan: 3,
        type: 'text',
        toolTip: true,
        toolTipText: 'Max Quantity which can be stocked'
      },
      {
        name: 'Recommended Replenishment',
        id: 'minimum_replenishment',
        sort: '',
        colSpan: 2,
        toolTip: true,
        colorScheme: true,
        toolTipText:
          'Minimum replenishment required. If current inventory is less than the min quantity, \n then replenishment is min quantity - current inventory\n, if current inventory is greater than min quantity and less than max quantity, then replenishment is 0, else replenishment is max quantity - current inventory'
      },
      {
        name: 'Sales',
        id: 'num_qty_sold',
        sort: 'desc',
        colSpan: 2,
        toolTip: true,
        toolTipText: 'Total quantities sold in the specified time period'
      },
      {
        name: 'Revenue',
        id: 'total_amount',
        sort: '',
        colSpan: 2,
        toolTip: true,
        toolTipText: 'Total revenue in the specified time period'
      },
      {
        name: 'Margin %',
        id: 'total_margin',
        sort: '',
        colSpan: 2,
        toolTip: true,
        toolTipText: 'Gross Profit Margin'
      }
    ]
  }
};
export default config;
