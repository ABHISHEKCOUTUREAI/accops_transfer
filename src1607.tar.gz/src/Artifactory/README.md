# 🎨 UI-Artifactory 🧰
A repository for managing and organizing UI-related artifacts. It's a centralized platform for storing, versioning, and distributing UI components, design assets, style guides, or any other Fronted-related resources used in the development process.

## Components Guide
You can find the documentation for all the components in [Components.md](./Components.md).


## Usage

To use the artifactory in a project, set it up as a submodule in /src directory.
To set up a repo as a submodule run the following command in the src directory of the project:

```
git submodule add https://github.com/Couture-ai/UI-Artifactory.git ./Artifactory
```

To push the submodule to the project repository run the following commands:

```
git commit -m "Added submodule: https://github.com/Couture-ai/UI-Artifactory.git"

git push
```
