import { useState } from 'react';
import { Popover, PopoverTrigger, PopoverContent, PopoverArrow, Text } from '@chakra-ui/react';
import { InfoOutlined } from '@mui/icons-material';

const Tooltip = (props) => {
  const [isHover, setIsHover] = useState(false);

  const handleInfo = () => {
    setIsHover(true);
  };

  const handleInfoLeave = () => {
    setIsHover(false);
  };
  return (
    <Popover placement="right" trigger="hover" {...props}>
      <PopoverTrigger>
        <InfoOutlined
          style={{
            color: isHover ? 'black.400' : '#C5C5C5',
            width: '15px',
            height: '15px'
          }}
          onMouseEnter={handleInfo}
          onMouseLeave={handleInfoLeave}
          cursor={'pointer'}
        />
      </PopoverTrigger>
      <PopoverContent maxW="30vh" p={2}>
        <PopoverArrow />
        <Text
          color="black.1000"
          fontSize="10px"
          wordBreak="break-word"
          wordWrap="break-word"
          ml={1}
          maxW="20vh">
          {props.info}
        </Text>
      </PopoverContent>
    </Popover>
  );
};

export default Tooltip;
