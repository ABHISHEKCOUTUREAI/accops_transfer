import React, { useEffect, useRef, useState } from 'react';
import { DateRangePicker } from 'react-date-range';
import format from 'date-fns/format';
import { Input, Flex, Box, InputGroup, InputLeftElement, Icon } from '@chakra-ui/react';
import 'react-date-range/dist/styles.css'; // main css file
import 'react-date-range/dist/theme/default.css'; // theme css file
import { CalendarMonth } from '@mui/icons-material';

const CalendarComp = (props) => {
  const [open, setOpen] = useState(false);

  const refOne = useRef(null);

  useEffect(() => {
    document.addEventListener('keydown', hideOnEscape, true);
    document.addEventListener('click', hideOnClickOutside, true);
  }, []);

  const hideOnEscape = (event) => {
    if (event.key === 'Escape') {
      setOpen(false);
    }
  };

  const hideOnClickOutside = (event) => {
    if (refOne.current && !refOne.current.contains(event.target)) {
      setOpen(false);
    }
  };

  return (
    <Flex mt={2} position="relative" display={'inline-block'}>
      <InputGroup w="100%">
        <InputLeftElement pointerEvents="none" fontSize="1.2em">
          <Icon color={'#c5c5c5'}>
            <CalendarMonth color="gray.grey" />
          </Icon>
        </InputLeftElement>
        <Input
          value={`${format(props.range[0].startDate, 'dd/MM/yyyy')} to ${format(
            props.range[0].endDate,
            'dd/MM/yyyy'
          )}`}
          readOnly
          bgColor={'#FFFFFF'}
          fontSize={'12px'}
          onClick={() => setOpen((open) => !open)}
        />
      </InputGroup>
      <Box ref={refOne} top={'50px'} position="absolute" left={'20%'} zIndex={999}>
        {open && (
          <DateRangePicker
            onChange={(item) => props.setRange([item.selection])}
            editableDateInputs={true}
            moveRangeOnFirstSelection={false}
            ranges={props.range}
            months={1}
            direction={'vertical'}></DateRangePicker>
        )}
      </Box>
    </Flex>
  );
};

export default CalendarComp;
