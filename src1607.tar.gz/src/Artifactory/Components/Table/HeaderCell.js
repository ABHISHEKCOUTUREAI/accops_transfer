import { Flex } from '@chakra-ui/layout';
import { Image, Th, Tooltip } from '@chakra-ui/react';

import Ascending from '../../../Static/ascending.png';
import Descending from '../../../Static/descending.png';
import { FilterList } from '@mui/icons-material';

// const ITEM_HEIGHT = 48;
// const ITEM_PADDING_TOP = 0;

export const HeaderCell = ({ title, index, headers, setHeaders, chakratheme, props, thStyle }) => {
  const handleSortClick = () => {
    props.setPage(1);
    let currentSortOrder = '';
    if (props.sortOrder === '') {
      currentSortOrder = 'desc';
    } else if (props.sortOrder === 'desc') {
      currentSortOrder = 'asc';
    }
    props.setSortOrder(currentSortOrder); // Update the sort order state
    currentSortOrder !== '' ? props.setSortBy(title.id) : props.setSortBy('');
    const updatedHeaders = headers.map((item, i) => ({
      ...item,
      sort: i === index ? currentSortOrder : item.sort || item.sort === '' ? '' : null
    }));
    setHeaders(updatedHeaders);
  };

  //   const handleSearchChange = (e) => {
  //     const val = e.target.value;
  //     setHeaders(
  //       headers.map((item) => (item.id === title.id ? { ...item, search_query: val } : item))
  //     );
  //     debouncedHandleKeyChange(title.search_variable, val);
  //   };

  //   const handleSearchKeyDown = (e) => {
  //     if (e.key === 'Enter') {
  //       const val = headers.find((item) => item.id === title.id).search_query;
  //       props.setSearchData({
  //         ...props.searchData,
  //         [title.search_variable]: val
  //       });
  //       props.setPage(1);
  //     }
  //   };

  //   const handleFilterChange = (e) => {
  //     const val = e.target.value;
  //     setHeaders(headers.map((item) => (item.id === title.id ? { ...item, filter: val } : item)));
  //     props.setAssortmentStatusFilter(val);
  //   };

  //   const handleDeleteFilter = (value) => {
  //     setHeaders(
  //       headers.map((item) => {
  //         if (item.id === title.id) {
  //           return { ...item, filter: item.filter.filter((e) => e !== value) };
  //         }
  //         return item;
  //       })
  //     );
  //     props.setAssortmentStatusFilter(title.filter.filter((e) => e !== value));
  //   };

  return (
    <Tooltip
      key={index}
      arrow
      placement="top-start"
      label={title?.toolTip ? title.toolTipText : null}>
      <Th
        _hover={{ backgroundColor: `${chakratheme.colors.primary.light_hover}` }}
        colSpan={title.colSpan ? title.colSpan : 1}
        onClick={handleSortClick}
        key={index}
        style={thStyle}>
        <Flex
          color={`${chakratheme.colors.primary.main}`}
          fontWeight={'bold'}
          alignItems="center"
          justifyContent="flex-start"
          cursor={'pointer'}>
          {title.filter == null && title.search == null ? (
            title.name
          ) : title.search != null ? (
            <>
              {/* <FormControl
                sx={{ m: 1, width: title.name === 'Description' ? '30ch' : '15ch' }}
                variant="outlined">
                <InputLabel
                  htmlFor="outlined-adornment-password"
                  style={{
                    color: `${chakratheme.colors.primary.main}`,
                    fontWeight: 'bold',
                    fontSize: '13px'
                  }}>
                  {title.name}
                </InputLabel>
                <OutlinedInput
                  sx={{
                    color: `${chakratheme.colors.primary.main}`,
                    '.MuiOutlinedInput-notchedOutline': {
                      borderColor: `${chakratheme.colors.gray.light}`
                    },
                    '&.Mui-focused .MuiOutlinedInput-notchedOutline': {
                      borderColor: `${chakratheme.colors.gray.light}`
                    },
                    '&:hover .MuiOutlinedInput-notchedOutline': {
                      borderColor: `${chakratheme.colors.gray.light}`
                    },
                    '& > .MuiSvgIcon-root ': { fill: `${chakratheme.colors.primary.main}` }
                  }}
                  onClick={(e) => e.stopPropagation()}
                  id="outlined-adornment-password"
                  type={'text'}
                  onChange={handleSearchChange}
                  onKeyDown={handleSearchKeyDown}
                  endAdornment={
                    <InputAdornment position="end">
                      <IconButton
                        aria-label="toggle password visibility"
                        onClick={() => {
                          const val = headers.find((item) => item.id === title.id).search_query;
                          if (val === '') return;
                          props.setSearchData({
                            ...props.searchData,
                            [title.search_variable]: val
                          });
                        }}
                        edge="end">
                        <Search style={{ color: `${chakratheme.colors.primary.main}` }} />
                      </IconButton>
                    </InputAdornment>
                  }
                  label={title.name}
                />
              </FormControl> */}
            </>
          ) : (
            <Flex direction="column">
              {/* <FormControl style={{ minWidth: '150px', color: 'white' }}>
                <InputLabel
                  id="demo-multiple-chip-label"
                  sx={{
                    color: `${chakratheme.colors.primary.main}`,
                    fontWeight: 'bold',
                    fontSize: '13px'
                  }}>
                  Status
                </InputLabel>
                <Select
                  labelId="demo-multiple-chip-label"
                  id="demo-multiple-chip"
                  multiple
                  labelStyle={{ color: `${chakratheme.colors.red}` }}
                  sx={{
                    color: 'white',
                    '.MuiOutlinedInput-notchedOutline': {
                      borderColor: 'rgba(228, 219, 233, 0.25)'
                    },
                    '&.Mui-focused .MuiOutlinedInput-notchedOutline': {
                      borderColor: 'rgba(228, 219, 233, 0.25)'
                    },
                    '&:hover .MuiOutlinedInput-notchedOutline': {
                      borderColor: 'rgba(228, 219, 233, 0.25)'
                    },
                    '& > .MuiSvgIcon-root ': { fill: 'white' }
                  }}
                  fullWidth
                  value={title.filter}
                  onChange={handleFilterChange}
                  input={<OutlinedInput id="select-multiple-chip" label="Chip" />}
                  renderValue={(selected) => (
                    <Box sx={{ display: 'flex', flexWrap: 'wrap', gap: 0.5 }}>
                      {selected.map((value) => (
                        <Chip
                          onClick={(e) => e.stopPropagation()}
                          onMouseDown={(e) => e.stopPropagation()}
                          key={value}
                          label={title.filterData.find((e) => e.value === value).name}
                          deleteIcon={
                            <Cancel
                              style={{
                                color: title.filterData.find((e) => e.value === value).color
                              }}
                            />
                          }
                          onDelete={(e) => {
                            e.stopPropagation();
                            handleDeleteFilter(value);
                          }}
                          style={{
                            fontWeight: 'bold',
                            backgroundColor: title.filterData.find((e) => e.value === value).bg,
                            color: title.filterData.find((e) => e.value === value).color
                          }}
                          size="small"
                        />
                      ))}
                    </Box>
                  )}
                  MenuProps={MenuProps}>
                  {title.filterData.map((ele) => (
                    <MenuItem
                      key={ele.value}
                      value={ele.value}
                      _hover={{ backgroundColor: ele.bg }}
                      style={{
                        backgroundColor: headers
                          .find((e) => e.id === title.id)
                          .filter.includes(ele.value)
                          ? `${chakratheme.colors.primary.main}`
                          : null,
                        color: headers.find((e) => e.id === title.id).filter.includes(ele.value)
                          ? 'white'
                          : 'black'
                      }}>
                      <Box
                        style={{
                          backgroundColor: ele.color,
                          width: '10px',
                          height: '10px',
                          borderRadius: '50%',
                          display: 'inline-block',
                          marginRight: '5px'
                        }}></Box>{' '}
                      {ele.name}
                    </MenuItem>
                  ))}
                </Select>
              </FormControl> */}
            </Flex>
          )}
          {title.sort != null && true && (
            <Flex ml={1}>
              {title.sort === 'asc' ? (
                <Image w="20px" h="20px" m="2px" src={Ascending} />
              ) : title.sort === 'desc' ? (
                <Image w="20px" h="20px" m="2px" src={Descending} />
              ) : (
                <FilterList style={{ color: `${chakratheme.colors.primary.main}` }} />
              )}
            </Flex>
          )}
        </Flex>
      </Th>
    </Tooltip>
  );
};
