import { Tr } from '@chakra-ui/react';

import { Image, Td } from '@chakra-ui/react';

const TableCell = ({ item, header, chakratheme, tdStyle }) => {
  //   console.log('header', header);
  const cellContent = () => {
    switch (header.type) {
      case 'image':
        return (
          <a
            href={`https://www.ajio.com/p/${item['productid']}`}
            target="_blank"
            rel="noopener noreferrer">
            <Image
              src={`https://assets.ajio.com/medias/sys_master/root/${item['imgcode']}/${item['itemid']}.jpg`}
              h={100}
              w={100}
            />
          </a>
        );
      case 'image_with_url':
        return (
          <a
            href={`https://www.ajio.com/p/${item['itemid']}`}
            target="_blank"
            rel="noopener noreferrer">
            <Image src={item[header.id]} h={100} w={100} />
          </a>
        );
      case 'image_trends':
        return (
          <a
            href={`https://www.ajio.com/p/${item['itemid']}`}
            target="_blank"
            rel="noopener noreferrer">
            <Image
              src={`https://assets.ajio.com/medias/sys_master/root/${item.imgcode}${item.id}-MODEL.${item.extension}`}
              h={100}
              w={100}
            />
          </a>
        );
      default:
        if (header.format === 'true' && item[header.id] != null) {
          const intValue = parseInt(item[header.id], 10);
          return intValue.toLocaleString();
        }
        return item[header.id];
    }
  };

  return (
    <Td
      colSpan={header.colSpan ? header.colSpan : 1}
      style={{
        ...tdStyle,
        color: `${chakratheme.colors.black[800]}`,
        backgroundColor:
          header.id === 'weekly_rate_of_sale' ? `${chakratheme.colors.primary.lighter}` : 'initial'
      }}>
      {cellContent()}
    </Td>
  );
};

export const TableRow = ({ item, i, headers, hoveredRow, setHoveredRow, chakratheme, tdStyle }) => {
  return (
    <Tr
      key={i}
      _hover={{
        backgroundColor: `${chakratheme.colors.gray.lighter}`
      }}
      onMouseEnter={() => setHoveredRow(i)}
      onMouseLeave={() => setHoveredRow(null)}
      style={{
        padding: '20px 0',
        borderBottom: `2px solid ${chakratheme.colors.gray.lighter}`,
        backgroundColor: hoveredRow === i ? `${chakratheme.colors.gray.lighter}` : 'white'
      }}>
      {headers.map((header, index) => (
        <TableCell
          key={index}
          item={item}
          header={header}
          chakratheme={chakratheme}
          tdStyle={tdStyle}
        />
      ))}
    </Tr>
  );
};
