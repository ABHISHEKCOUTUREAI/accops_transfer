import React from 'react';
import { Tab, TabList, TabPanels, Tabs } from '@chakra-ui/react';

const TabsCommon = (props) => {
  return (
    <Tabs colorScheme={'black'} {...props}>
      <TabList>
        {props.tabList &&
          props.tabList.map((tab) => {
            return (
              <Tab
                key={tab.name}
                _selected={{
                  fontWeight: '700',
                  color: 'black',
                  borderBottom: '2px solid black'
                }}>
                {tab.name}
              </Tab>
            );
          })}
      </TabList>
      <TabPanels>{props.children}</TabPanels>
    </Tabs>
  );
};

export default TabsCommon;
