/* eslint-disable no-unused-vars */
import { Box, Button, Flex, Image, Spacer, Stack, Text, useTheme } from '@chakra-ui/react';
import {
  CircleRounded,
  KeyboardArrowDownRounded,
  KeyboardArrowUpRounded
} from '@mui/icons-material';
import { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import couturelogo from '../../../Static/coutureai_logo.jpeg';
import settings from '../../../Static/settings.png';

const useStyles = (chakratheme) => ({
  sidenav: {
    height: '100%',
    position: 'fixed',
    zIndex: 1000,
    top: 0,
    left: 0,
    overflowX: 'hidden',
    transition: 'width 0.5s',
    boxShadow: `${chakratheme.colors.shadow} 0 0 10px 0`,
    display: 'flex',
    flexDirection: 'column',
    background: 'rgba(255, 255, 255, 0.8)',
    backdropFilter: 'blur(6px)'
  },
  button: {
    padding: '13px 11px',
    margin: '10px 17px',
    width: 'calc(100% - 34px)',
    textAlign: 'left',
    justifyContent: 'left',
    borderRadius: '8px',
    fontWeight: '400',
    fontSize: '14px',
    transition: 'background-color 0.3s',
    ':hover': {
      backgroundColor: `${chakratheme.colors.gray.lighter}`,
      color: `${chakratheme.colors.gray.dark}`,
      fontWeight: '600'
    }
  },
  stackHeader: {
    padding: '22px 11px',
    margin: '2px 17px',
    width: 'calc(100% - 34px)',
    textAlign: 'left',
    justifyContent: 'left',
    alignItems: 'center',
    borderRadius: '8px',
    color: `${chakratheme.colors.black[600]}`,
    fontWeight: '400',
    fontSize: '14px',
    transition: 'background-color 0.3s',
    ':hover': {
      backgroundColor: `${chakratheme.colors.gray.lighter}`,
      color: `${chakratheme.colors.gray.dark}`,
      fontWeight: '600'
    }
  },
  stackButton: {
    padding: '12px 11px',
    margin: '2px 20px 2px 0',
    width: 'calc(100%)',
    textAlign: 'left',
    justifyContent: 'left',
    borderRadius: '8px',
    color: `${chakratheme.colors.black[600]}`,
    fontWeight: '400',
    fontSize: '14px',
    transition: 'background-color 0.3s',
    ':hover': {
      backgroundColor: `${chakratheme.colors.gray.lighter}`,
      color: `${chakratheme.colors.gray.dark}`,
      fontWeight: '600'
    }
  },
  icon: {
    height: 24,
    width: 24,
    marginRight: '10px'
  },
  stackIcon: {
    height: 30,
    width: 30,
    overflow: 'show',
    transform: 'translate(-27px)',
    backgroundColor: `${chakratheme.colors.primary.lighter}`,
    borderRadius: '8px',
    padding: '5px'
  }
});

const MenuButton = ({ tab, isOpen, styles, location, handleMenuClick, chakratheme }) => (
  <Button
    onClick={() => handleMenuClick(tab)}
    variant="menu"
    backgroundColor={
      location === tab.link && !isOpen ? `${chakratheme.colors.primary.lighter}` : 'white'
    }
    sx={styles.button}>
    <Flex
      filter={
        location === tab.link && !isOpen
          ? 'invert(28%) sepia(95%) saturate(7170%) hue-rotate(257deg) brightness(97%) contrast(90%)'
          : null
      }>
      {tab.icon}
    </Flex>
    {isOpen && <Box ml={tab.spacing}>{tab.text}</Box>}
  </Button>
);

const MenuHeader = ({ i, tab, isOpen, styles, props, chakratheme }) => (
  <Flex
    transition="width 0.2s"
    alignItems="center"
    cursor="pointer"
    onClick={() => {
      props.setMenu([
        ...props.menu.slice(0, i),
        { ...tab, open: !tab.open },
        ...props.menu.slice(i + 1)
      ]);
    }}>
    <Flex direction="row" sx={styles.stackHeader}>
      {tab.icon}
      {isOpen && <Box ml={tab.spacing}>{tab.text}</Box>}
      <Spacer />
      {isOpen &&
        (tab.open ? (
          <KeyboardArrowUpRounded style={{ color: `${chakratheme.colors.gray.light}` }} />
        ) : (
          <KeyboardArrowDownRounded style={{ color: `${chakratheme.colors.gray.light}` }} />
        ))}
    </Flex>
  </Flex>
);

const MenuItems = ({ tab, isOpen, styles, location, handleMenuClick, chakratheme }) =>
  tab.open && (
    <Stack
      direction="row"
      mt={2}
      mb={2}
      borderLeft={`1px solid ${chakratheme.colors.gray[300]}`}
      ml="40px">
      <Flex direction="column" w="100%">
        {tab.child.map((child, index) => (
          <Box key={index} p="0 10px 0 0" w="100%">
            <Button
              h="50px"
              w="30px"
              onClick={() => handleMenuClick(child)}
              variant="menu"
              style={{
                backgroundColor: isOpen
                  ? location === child.link
                    ? `${chakratheme.colors.primary.lighter}`
                    : 'white'
                  : 'white',
                color:
                  location === child.link && !isOpen ? `${chakratheme.colors.primary.main}` : null
              }}
              sx={styles.stackButton}>
              {location === child.link && !isOpen ? (
                <Box w="30px" h="30px">
                  {child.icon}
                </Box>
              ) : (
                <CircleRounded
                  style={{
                    transform: 'translate(-14px)',
                    fontSize: '4px',
                    color: 'rgba(180, 180, 180, 1)'
                  }}
                />
              )}
              {isOpen && <Box ml={child.spacing}>{child.text}</Box>}
            </Button>
          </Box>
        ))}
      </Flex>
    </Stack>
  );

const MenuStack = ({ i, tab, isOpen, styles, location, handleMenuClick, props, chakratheme }) => (
  <>
    <MenuHeader
      i={i}
      tab={tab}
      isOpen={isOpen}
      styles={styles}
      props={props}
      chakratheme={chakratheme}
    />
    <MenuItems
      tab={tab}
      isOpen={isOpen}
      styles={styles}
      location={location}
      handleMenuClick={handleMenuClick}
      chakratheme={chakratheme}
    />
  </>
);

const SideBar = (props) => {
  const chakratheme = useTheme();
  const styles = useStyles(chakratheme);
  const navigate = useNavigate();
  const [isOpen, setIsOpen] = useState(false);
  const location = `${window.location.pathname.slice(window.location.pathname.indexOf('/'))}`;

  const downMenu = [
    {
      variant: 'button',
      icon: (
        <Image
          src={settings}
          style={{
            height: 24,
            width: 24,
            marginRight: '10px',
            filter:
              'invert(61%) sepia(12%) saturate(0%) hue-rotate(279deg) brightness(98%) contrast(90%)',
            ':hover': { filter: 'none' }
          }}
        />
      ),
      text: 'Settings',
      link: '/settings',
      spacing: 2
    }
  ];

  const handleMenuClick = (tab) => {
    navigate(`${tab.link}`);
  };

  return (
    <Box
      style={{ ...styles.sidenav, width: isOpen ? '250px' : '80px' }}
      onMouseEnter={() => {
        setIsOpen(true);
        props.setIsCollapsed(false);
      }}
      onMouseLeave={() => {
        setIsOpen(false);
        props.setIsCollapsed(true);
      }}>
      <Box sx={{ flexGrow: 1 }}>
        <Flex direction="column" pt={4} h="100%" pb="30px">
          <Flex mb="15px">
            <Image
              src={couturelogo}
              w="40px"
              style={{
                filter:
                  'invert(100%) sepia(0%) saturate(0%) hue-rotate(93deg) brightness(103%) contrast(103%)',
                margin: '2px 10px 2px 18px',
                backgroundColor: 'black',
                borderRadius: '8px'
              }}></Image>
            {isOpen && (
              <Flex
                direction="column"
                w="100%"
                justifyContent={'center'}
                alignItems={'flex-start'}
                fontFamily={'Poppins'}>
                <Flex direction={'column'}>
                  <Text style={{ fontSize: '12px', color: `${chakratheme.colors.black[400]}` }}>
                    Couture.ai
                  </Text>
                  <Text style={{ fontSize: '16px', fontWeight: 'bold' }}>
                    {props.name}
                    <span style={{ color: `${chakratheme.colors.black[400]}` }}>Console</span>
                  </Text>
                </Flex>
              </Flex>
            )}
          </Flex>
          {props.menu.map((tab, i) => (
            <Box key={i}>
              {tab.variant === 'button' ? (
                <MenuButton
                  i={i}
                  tab={tab}
                  isOpen={isOpen}
                  styles={styles}
                  location={location}
                  handleMenuClick={handleMenuClick}
                  chakratheme={chakratheme}
                />
              ) : (
                <MenuStack
                  i={i}
                  tab={tab}
                  isOpen={isOpen}
                  styles={styles}
                  location={location}
                  handleMenuClick={handleMenuClick}
                  props={props}
                  chakratheme={chakratheme}
                />
              )}
            </Box>
          ))}
          <Spacer />
          {downMenu.map((tab, i) => (
            <Box key={i}>
              <MenuButton
                tab={tab}
                isOpen={isOpen}
                styles={styles}
                location={location}
                handleMenuClick={handleMenuClick}
              />
            </Box>
          ))}
        </Flex>
      </Box>
    </Box>
  );
};

export default SideBar;
