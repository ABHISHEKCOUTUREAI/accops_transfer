import {
  Drawer,
  DrawerOverlay,
  DrawerCloseButton,
  DrawerHeader,
  DrawerBody,
  DrawerContent,
  useDisclosure,
  Flex
} from '@chakra-ui/react';
import { useRef } from 'react';
import { NotificationComponent } from './NotificationComponent';
import NotificationsIcon from '@mui/icons-material/Notifications';
export const NotificationSidePanel = ({ notifications }) => {
  const { isOpen, onOpen, onClose } = useDisclosure();
  const btnRef = useRef();

  return (
    <>
      <NotificationsIcon
        ref={btnRef}
        onClick={onOpen}
        aria-label="Notifications"
        style={{ cursor: 'pointer' }}
      />
      <Drawer size="md" isOpen={isOpen} placement="right" onClose={onClose} finalFocusRef={btnRef}>
        <DrawerOverlay />
        <DrawerContent>
          <DrawerCloseButton />
          <DrawerHeader>Notifications</DrawerHeader>
          <DrawerBody>
            <Flex gap={5} direction={'column'}>
              {notifications.map((n, i) => (
                <NotificationComponent key={i} message={n} />
              ))}
            </Flex>
          </DrawerBody>
        </DrawerContent>
      </Drawer>
    </>
  );
};
