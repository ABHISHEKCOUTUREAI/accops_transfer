import {
  Box,
  Flex,
  GridItem,
  Image,
  Spacer,
  Table,
  Tbody,
  Text,
  Th,
  Thead,
  Tr
} from '@chakra-ui/react';
import React from 'react';

const ProductBox = ({ product }) => {
  const { brandname, image, name, price, mrp, sku_data } = product;

  return (
    <GridItem
      colSpan={1}
      rowSpan={1}
      style={{
        boxShadow: '#f0f0f0 0 0 20px 10px'
      }}>
      <Flex
        backgroundColor="white"
        borderRadius="md"
        justifyContent="flex-start"
        alignItems="flex-start"
        w="100%"
        h="100%"
        mb={2}>
        <Box display="flex" justifyContent="center" alignItems="center">
          <Image src={image} h="250px" />
        </Box>
        <Flex direction="column" p="4" position="relative" w="80%">
          <Flex
            direction={'row'}
            alignContent={'center'}
            justifyContent={'center'}
            alignItems={'center'}
            justifyItems={'center'}>
            <Text fontSize="sm" color="#5C469C">
              {`${brandname}`}
            </Text>
            <Spacer />
          </Flex>
          <Flex>
            <Text fontFamily="AG2Body-Semibold" fontSize="md" fontWeight="bold">
              {name}
            </Text>
          </Flex>
          <Flex alignItems="baseline">
            <Text fontFamily="AG2Body-Semibold" fontSize="sm" fontWeight="semibold" color="#1D267D">
              {`Rs. ${price}`}
            </Text>
            {mrp ? (
              <Text
                as="s"
                fontFamily="AG2Body-Semibold"
                fontSize="sm"
                fontWeight="semibold"
                color="#6067a4"
                mt={1}
                mb={5}
                ml={2}>
                {`Rs. ${mrp}`}
              </Text>
            ) : (
              <Text
                as="s"
                fontFamily="AG2Body-Semibold"
                fontSize="sm"
                fontWeight="semibold"
                color="#6067a4"
                mt={1}
                mb={5}
                ml={2}>
                -
              </Text>
            )}
          </Flex>
          <Box ml={5} h="50%">
            <Table
              colorScheme="gray"
              style={{ margin: '0 -15px' }}
              variant="simple"
              mt={3}
              // ml={3}
              size="sm">
              <Thead>
                <Tr>
                  <Th></Th>
                  {sku_data?.map((row) => (
                    <Th fontSize="9px" pr={2} px={1} key={row.size}>
                      {row.size}
                    </Th>
                  ))}
                </Tr>
              </Thead>
              <Tbody>
                <Tr>
                  <Th fontSize="9px">Predictions</Th>
                  {sku_data?.map((row) => (
                    <Th pr={2} px={1} fontSize="9px" key={row.size}>
                      {row.prediction}
                    </Th>
                  ))}
                </Tr>
                <Tr>
                  <Th fontSize="9px">Available Quantities</Th>
                  {sku_data?.map((row) => (
                    <Th pr={2} px={1} fontSize="9px" key={row.size}>
                      {row.availablequantity}
                    </Th>
                  ))}
                </Tr>
              </Tbody>
            </Table>
          </Box>
        </Flex>
      </Flex>
    </GridItem>
  );
};
export default ProductBox;
