import { Text, Flex } from '@chakra-ui/react';
import { ArrowUpward, ArrowDownward } from '@mui/icons-material';

const formatInternationalStandard = (num) => {
  // remove decimal from number
  if (num > 0) {
    const numStr = num.toString().split('.')[0];
    // add commas to number
    return numStr.replace(/(\d)(?=(\d{3})+(?!\d))/g, '$1,');
  } else {
    return num;
  }
};

export const StatsCard = ({ header, number, variation, footer, ...props }) => {
  return (
    <Flex
      margin="5px"
      w="100%%"
      direction="column"
      mt={10}
      style={{
        padding: '20px',
        borderRadius: '20px',
        fontFamily: 'Hanken Grotesk',
        boxShadow: 'rgb(231, 231, 231) 0px 0px 20px 0px'
      }}
      {...props}>
      <Text fontWeight={'bold'} mb="20px">
        {header}
      </Text>
      <Flex alignItems={'center'} wrap="wrap">
        <Text fontSize={'36px'}>&#8377; {formatInternationalStandard(number)} </Text>
        <Flex
          ml={2}
          padding="2px 10px"
          fontSize={'12px'}
          borderRadius={'10px'}
          alignItems="center"
          fontWeight={'bold'}
          color={variation >= 0 ? `${'success.main'}` : `${'error.main'}`}
          backgroundColor={variation >= 0 ? `${'success.light'}` : `${'error.light'}`}>
          {variation > 0 ? (
            <ArrowUpward style={{ fontSize: '15px' }} />
          ) : variation < 0 ? (
            <ArrowDownward style={{ fontSize: '15px' }} />
          ) : (
            <></>
          )}
          <Text>{`${variation} %`}</Text>
        </Flex>
      </Flex>
      <Text
        style={{
          fontSize: '15px',
          color: 'white',
          marginTop: '10px',
          fontStyle: 'italic'
        }}>
        {footer}
      </Text>
    </Flex>
  );
};
