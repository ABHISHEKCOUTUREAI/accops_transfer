import { RadioGroup, Radio, HStack } from '@chakra-ui/react';

const RadioButtons = (props) => {
  return (
    <RadioGroup onChange={props.onChange}>
      <HStack>
        {props.optionList &&
          props.optionList.map((option) => (
            <Radio value={option.value} key={option.name}>
              {option.name}
            </Radio>
          ))}
      </HStack>
    </RadioGroup>
  );
};

export default RadioButtons;
