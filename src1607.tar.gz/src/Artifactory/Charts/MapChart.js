/* eslint-disable no-unused-vars */
import React, { useState, useEffect } from 'react';
import India from '@svg-maps/india';
import { SVGMap } from 'react-svg-map';
import { useNavigate } from 'react-router-dom';
import 'react-svg-map/lib/index.css';
import { Flex, useTheme, Box, Text, Card, CardHeader } from '@chakra-ui/react';
import './IndiaMap.css';
import { formatNumber } from './functions';

function onLocationMouseOver(
  event,
  props,
  setStateCode,
  setStateName,
  setDetail,
  chakratheme,
  isHovered
) {
  const clickedStateCode = event.target.id.toUpperCase();
  const clickedStateName = event.target.getAttribute('name');
  const clickedStateData = props.statesData.find((data) => data.statecode === clickedStateCode);
  const clickedDetail = clickedStateData || {};

  setStateCode(clickedStateCode);
  setStateName(clickedStateName);
  setDetail(clickedDetail);

  const element = document.getElementById(event.target.id);
  if (element) {
    element.style.fill = `${chakratheme.colors.gray.light}`;
  }
  if (isHovered) {
    element.style.fill = `${chakratheme.colors.gray.light}`;
  }
}

function onLocationMouseOut(event, props, idIntensityMapping) {
  const stateCodee = event.target.id.toLowerCase();
  const element = document.getElementById(stateCodee);

  if (element) {
    let intensity = idIntensityMapping[stateCodee] || 0;
    element.style.fill = `rgba(43, 181, 91, ${intensity})`;

    // if (props.selectedZone) {
    //   const stateInSelectedZone = props.statesData.find(
    //     (state) => state.statecode.toLowerCase() === stateCodee && state.zone === props.selectedZone
    //   );
    //   if (stateInSelectedZone) {
    //     element.style.fill = `rgba(43, 181, 91, ${intensity})`;
    //   } else {
    //     element.style.fill = 'white';
    //   }
    // } else {
    //   const stateInSelectedState = props.statesData.find(
    //     (state) =>
    //       state.statecode.toLowerCase() === stateCodee && state.state === props.selectedState
    //   );
    //   if (stateInSelectedState) {
    //     element.style.fill = `rgba(43, 181, 91, ${intensity})`;
    //   } else {
    //     element.style.fill = 'white';
    //   }
    // }
  }
}

function handleClick(stateName, detail, navigate) {
  sessionStorage.setItem('redirectFlag', true);
  sessionStorage.setItem('stateName', stateName);
  sessionStorage.setItem('zone', detail && detail.zone);

  navigate('/assortment/assortment-analysis');
}

function MapChart(props) {
  const chakratheme = useTheme();
  const [stateCode, setStateCode] = useState('jk');
  const [stateName, setStateName] = useState('');
  const [detail, setDetail] = useState({});

  const iconPosition = { x: -100, y: -100 }; // Off-screen initially

  const [idIntensityMapping, setIdIntensityMapping] = useState({});

  const revenues = props.statesData.map((state) => state.quantity_sold);
  const highestRevenue = Math.max(...revenues);

  const changeColorOnClick = () => {
    const updatedMapping = {};

    props.statesData.forEach((state) => {
      const element = document.getElementById(state.statecode.toLowerCase());
      if (element) {
        const intensity = state.quantity_sold / highestRevenue;
        element.style.fill = `rgba(43, 181, 91, ${intensity})`;
        updatedMapping[state.statecode.toLowerCase()] = intensity;
      }
    });

    // Update the state with the new mapping
    setIdIntensityMapping(updatedMapping);
  };
  useEffect(() => {
    const interval = setInterval(waitForDOM, 100);
    function waitForDOM() {
      const element = document.getElementById('or');
      if (element) {
        if (props?.statesData.length !== 0) {
          clearInterval(interval);
          changeColorOnClick();
        }
      }
    }
  }, [props?.statesData]);

  const [isHovered, setIsHovered] = useState(false);

  return (
    <>
      <div
        //  className="square"
        style={{
          position: 'absolute',
          marginLeft: '450px',
          marginTop: '80px'
        }}>
        {stateCode && stateName && (
          <Card>
            <CardHeader style={{ fontSize: '0.75rem', marginLeft: '5px', padding: '5px' }}>
              <strong>{stateName}</strong>
            </CardHeader>
            <Flex
              mr={2}
              ml={2}
              style={{
                // width: '50px',
                // height: '20px',
                color: `${chakratheme.colors.blue}`,
                backgroundColor: `${chakratheme.colors.primary.lighter}`,
                marginBottom: '10px',
                padding: '5px 10px',
                borderRadius: '20px',
                fontWeight: 'bold',
                fontSize: '13px'
              }}>
              Quantity Sold -
              <span
                style={{
                  fontSize: '13px',
                  fontWeight: 'bold',
                  marginLeft: '5px'
                }}>
                &#8377; {formatNumber(Math.floor(detail.quantity_sold))}
              </span>
            </Flex>
          </Card>
        )}
      </div>
      <SVGMap
        map={India}
        className="svg-map"
        onLocationMouseOut={(event) => onLocationMouseOut(event, props, idIntensityMapping)}
        onLocationMouseOver={(event) =>
          onLocationMouseOver(
            event,
            props,
            setStateCode,
            setStateName,
            setDetail,
            chakratheme,
            isHovered
          )
        }
      />
      {iconPosition.x !== -100 && (
        <div
          style={{
            position: 'absolute',
            left: iconPosition.x,
            top: iconPosition.y,
            cursor: 'pointer',
            zIndex: 999
          }}
          onMouseEnter={() => setIsHovered(true)}
          onMouseLeave={() => setIsHovered(false)}
          onClick={() => {
            handleClick();
          }}></div>
      )}
      <Flex alignItems="center">
        <Box w="20px" h="20px" bg={'#2BB55B'} mr="10px"></Box>
        <Text fontSize="md">{'High'}</Text>
      </Flex>
      <Flex alignItems="center">
        <Box w="20px" h="20px" bg={'#b6eeca'} mr="10px"></Box>
        <Text fontSize="md">{'Low'}</Text>
      </Flex>
    </>
  );
}

export default MapChart;
