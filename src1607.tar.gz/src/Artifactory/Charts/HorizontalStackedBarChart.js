import React, { useEffect, useState } from 'react';
import ReactApexChart from 'react-apexcharts';

const HorizontalStackedBarChart = (props) => {
  const formatNumber = (num) => {
    if (num === 0) {
      return;
    }
    if (String(num).length <= 3) {
      return '₹' + num;
    }
    return '₹' + String(parseFloat((num / 1000).toFixed(0))) + 'K';
  };

  const calculateChartHeight = () => {
    const numCategories = props.categoryNames.length;
    // Adjust these values according to your preference
    if (numCategories <= 2) {
      return 180; // Set a lower height for fewer categories
    } else {
      return 300; // Set a higher height for more categories
    }
  };

  const [chartOptions, setChartOptions] = useState({});
  useEffect(() => {
    const options = {
      chart: {
        type: 'bar',
        height: 350,
        stacked: true,
        colors: ['#263F5B', '#263F5B', '#263F5B', '#263F5B', '#263F5B']
      },
      plotOptions: {
        bar: {
          borderRadius: 10,
          horizontal: true,
          dataLabels: {
            enabled: true,
            formatter: function (val) {
              return formatNumber(val); // Call your formatNumber function
            },
            total: {
              enabled: false,
              offsetX: 0,
              style: {
                fontSize: '13px',
                fontWeight: 900
              }
            }
          }
        }
      },
      stroke: {
        width: 1,
        colors: ['#fff']
      },
      title: {
        text: props.title
      },
      xaxis: {
        categories: props.categoryNames,
        labels: {
          formatter: function (val) {
            return formatNumber(val);
          }
        }
      },
      yaxis: {
        title: {
          text: undefined
        }
      },
      tooltip: {
        y: {
          formatter: function (val) {
            return formatNumber(val);
          }
        }
      },
      fill: {
        opacity: 1,
        colors: ['#263F5B', '#263F5B', '#263F5B', '#263F5B', '#263F5B']
      },
      legend: {
        show: true,
        position: 'bottom',
        horizontalAlign: 'left',
        offsetX: 40,
        labels: {
          useSeriesColors: false
        }
      }
    };

    const updatedOptions = {
      ...options,
      plotOptions: {
        ...options.plotOptions,
        bar: {
          ...options.plotOptions.bar,
          dataLabels: {
            ...options.plotOptions.bar.dataLabels,
            formatter: function (val) {
              return formatNumber(val); // Call your formatNumber function
            }
          }
        }
      }
    };
    setChartOptions(updatedOptions);
  }, [props.data]);

  return (
    <div id="chart">
      <ReactApexChart
        options={chartOptions}
        series={props.data}
        type="bar"
        height={calculateChartHeight()}
      />
    </div>
  );
};

export default HorizontalStackedBarChart;
