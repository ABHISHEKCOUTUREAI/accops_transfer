import React from 'react';
import { Pie, PieChart, Cell, Tooltip } from 'recharts';

const SinglePieChart = (props) => {
  return (
    <PieChart width={props.width} height={props.height}>
      <Pie
        activeIndex={props.activeIndex}
        activeShape={props.renderActiveShape}
        isAnimationActive={true}
        label={props.isLabel}
        data={props.data}
        cx="50%"
        cy="50%"
        innerRadius={props.innerRadius}
        outerRadius={props.outerRadius}
        fill="color"
        dataKey={props.dataKey ? props.dataKey : 'value'}
        onMouseEnter={props.onPieEnter}>
        {props.data &&
          props.data.map((item) => {
            return <Cell key={item.name} fill={item.color} />;
          })}
      </Pie>
      {props.isTooltip ? <Tooltip /> : null}
      {props.children}
    </PieChart>
  );
};

export default SinglePieChart;
