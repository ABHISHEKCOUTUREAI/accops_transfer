import React from 'react';
import ReactApexChart from 'react-apexcharts';

const HalfRingPieChart = (props) => {
  const options = {
    chart: {
      type: 'donut'
    },
    labels: ['Misses', 'Hits'],
    colors: props.color,
    plotOptions: {
      pie: {
        startAngle: -90,
        endAngle: 90,
        donut: {
          size: '45%',
          labels: {
            show: true,
            name: {
              show: true,
              fontSize: '22px',
              fontFamily: 'Helvetica, Arial, sans-serif',
              fontWeight: 600,
              color: undefined,
              offsetY: -10
            },
            value: {
              show: true,
              fontSize: '16px',
              fontFamily: 'Helvetica, Arial, sans-serif',
              fontWeight: 400,
              color: undefined,
              offsetY: 16
            },
            total: {
              show: true,
              showAlways: false,
              color: '#373d3f',
              fontSize: '16px',
              fontFamily: 'Helvetica, Arial, sans-serif',
              fontWeight: 400,
              formatter: function (w) {
                return w.globals.seriesTotals.reduce((a, b) => {
                  return a + b;
                }, 0);
              }
            }
          }
        }
      }
    },
    title: {
      text: props.title
    },
    responsive: [
      {
        breakpoint: 480,
        options: {
          chart: {
            width: 200
          },
          legend: {
            position: 'bottom'
          }
        }
      }
    ]
  };

  return (
    <div id="chart">
      <ReactApexChart options={options} series={props.series} type="donut" />
    </div>
  );
};

export default HalfRingPieChart;
