import React, { useRef, useEffect } from 'react';
import * as echarts from 'echarts';

export const SunBurst = ({ data, ...props }) => {
  const chartContainerRef = useRef(null);

  useEffect(() => {
    if (chartContainerRef.current) {
      const myChart = echarts.init(chartContainerRef.current);
      myChart.setOption({
        series: {
          type: 'sunburst',
          // emphasis: {
          //     focus: 'ancestor'
          // },
          data: data,
          radius: [0, '90%'],
          label: {
            rotate: 'radial'
          }
        },
        color: [
          '#6a9cc8',
          '#7b75a7',
          '#f08484',
          '#ebc157',
          '#73c0de',
          '#3ba272',
          '#fc8452',
          '#9a60b4',
          '#ea7ccc'
        ],
        tooltip: {
          formatter:
            props.formatter ||
            function (params) {
              return `${params.name}:${params.value}`;
            }
        }
      });
    }

    return () => {
      myChart.dispose();
    };
  }, [data]);
  return <div ref={chartContainerRef} style={{ width: '100%', height: '400px' }} />;
};
