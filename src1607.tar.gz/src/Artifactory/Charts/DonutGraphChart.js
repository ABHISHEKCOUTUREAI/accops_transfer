import React, { useRef, useEffect } from 'react';
import { useTheme } from '@chakra-ui/react';
import * as echarts from 'echarts';

const DonutGraphChart = ({ formattedData }) => {
  const chartContainerRef = useRef(null);
  const chakratheme = useTheme();

  const getLevelOption = () => {
    return [
      {
        // itemStyle: {
        // //   borderColor: "#e7e7e7",
        //   borderWidth: 1,
        //   gapWidth: 1,
        // },
        upperLabel: {
          show: false
        }
      },
      {
        itemStyle: {
          borderColor: `${chakratheme.colors.primary.lighter}`,
          borderWidth: 1,
          gapWidth: 1
        },
        emphasis: {
          itemStyle: {
            borderColor: `${chakratheme.colors.primary.lighter}`
          }
        }
      },
      {
        colorSaturation: [0.35, 0.5],
        itemStyle: {
          borderWidth: 1,
          gapWidth: 1,
          borderColorSaturation: 0.6
        }
      }
    ];
  };

  useEffect(() => {
    if (chartContainerRef.current) {
      const myChart = echarts.init(chartContainerRef.current);
      myChart.setOption({
        series: [
          {
            name: formattedData.name,
            type: 'pie',
            radius: ['40%', '70%'],
            roam: 'move',
            visibleMin: 300,
            levels: getLevelOption(),
            data: formattedData.data,
            label: {
              show: true,
              formatter: '{b}',
              fontSize: 16
            },
            upperLabel: {
              show: true,
              height: 30,
              color: '#333333',
              fontSize: 15,
              fontWeight: 'bold',
              padding: 5
            },
            itemStyle: {
              borderColor: '#fff'
            }
          }
        ],
        color: [
          '#6a9cc8',
          '#7b75a7',
          '#f08484',
          '#ebc157',
          '#73c0de',
          '#3ba272',
          '#fc8452',
          '#9a60b4',
          '#ea7ccc'
        ],
        tooltip: {
          formatter: function (params) {
            const value = params.value;
            const categoryName =
              params.treePathInfo && params.treePathInfo.length > 1
                ? `${params.treePathInfo[1].name}: `
                : '';
            const subcategoryName = params.name;
            return `${categoryName}${subcategoryName}<br/>${formattedData.tooltipPrefix}: ${value}`;
          }
        }
      });

      return () => {
        myChart.dispose();
      };
    }
  }, [formattedData]);

  return <div ref={chartContainerRef} style={{ width: '100%', height: '100%' }} />;
};

export default DonutGraphChart;
