import React, { useState, useEffect } from 'react';
import ReactApexChart from 'react-apexcharts';

const HorizontalBarChart = (props) => {
  const formatNumber = (num) => {
    return num.toFixed(2);
  };

  const nestedCategories = [
    ['Demand Explained by', 'previous Assortment'],
    ['Demand Explained By', 'Couture Assortment', 'Recommendations'],
    ['Total Demand']
  ];
  const colors = ['#fceb85', '#53d175', '#bbbabd'];

  const setOpts = (data, categories) => {
    return {
      series: [
        {
          name: 'Demand',
          data: props.data.map((val, i) => {
            return {
              x: categories[i],
              y: val,
              fillColor: colors[i]
            };
          })
        }
      ],
      chart: {
        type: 'bar',
        height: 350
      },
      plotOptions: {
        bar: {
          borderRadius: 10,
          horizontal: true,
          dataLabels: {
            position: 'top'
          }
        }
      },
      // colors:['#F44336', '#E91E63', '#9C27B0'],
      dataLabels: {
        enabled: true,
        offsetX: 80,
        style: {
          fontSize: '16px',
          colors: ['#222']
        },
        formatter: function (val) {
          return `${val} (${formatNumber((val / data[2]) * 100)}%)`;
        }
      },

      xaxis: {
        categories: nestedCategories
      },
      tooltip: {
        custom: function ({ series, dataPointIndex, w }) {
          // Customize the tooltip content here
          if (w.globals.seriesX[0][dataPointIndex] === 'Total Demand') {
            return `<div class="custom-tooltip">
            <span>${series[0][2]} - </span>
            <span>Actual sales plus bounce</span>
          </div>`;
          } else if (
            w.globals.seriesX[0][dataPointIndex] === 'Demand Explained by previous Assortment'
          ) {
            return `<div class="custom-tooltip">
            <span>${series[0][0]} - </span>
            <span>Demand catered by present product availability(considered actual sales plus bounce as total demand)</span>
          </div>`;
          } else {
            return `<div class="custom-tooltip">
            <span>${series[0][1]} - </span>
            <span>Demand that can be catered if assortment recommendations are considered(considered actual sales plus bounce as total demand)</span>
          </div>`;
          }
        }
      }
    };
  };

  useEffect(() => {
    setOptions(setOpts(props.data, props.categories));
  }, [props.data, props.categories]);

  const [options, setOptions] = useState(setOpts(props.data, props.categories));

  return (
    <div id="chart">
      <ReactApexChart options={options} series={options.series} type="bar" height={200} />
    </div>
  );
};

export default HorizontalBarChart;
