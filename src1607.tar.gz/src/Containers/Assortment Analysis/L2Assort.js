import { Box, Flex, Text, useTheme } from '@chakra-ui/react';
import PieeChart from '../../Artifactory/Charts/PieChart';
import { Skeleton } from '@mui/material';
import { Tab } from '@mui/material';
import { useState } from 'react';
import { TabPanel, TabContext, TabList } from '@mui/lab';
import AssortmentTable from '../../components/Table';

const L2Assort = (props) => {
  const chakratheme = useTheme();
  const [selectedTab, setSelectedTab] = useState(0);
  const [selectedTabL3, setSelectedTabL3] = useState(0);
  return (
    <>
      <Text mb={6} ml={0} mt={2} fontWeight={'bold'} fontSize="16px" textAlign="left">
        Category Overview - Class and Segment Assortments
      </Text>
      <Text mb={4} mt={2} fontWeight={'bold'} fontSize="14px" textAlign="left">
        Assortment Composition and Missed Opportunities -
        <span
          style={{
            color: `${chakratheme.colors.primary.main}`,
            fontWeight: 'bold',
            backgroundColor: `${chakratheme.colors.primary.lighter}`,
            padding: '2px 3px',
            borderRadius: '4px'
          }}>
          Class
        </span>{' '}
        category
      </Text>
      <TabContext value={selectedTab}>
        <TabList
          textColor="black"
          indicatorColor={'black'}
          // backgroundColor="primary"
          onChange={(event, value) => {
            setSelectedTab(value);
          }}>
          <Tab
            label="Top 10"
            value={0}
            sx={{
              '&:hover': {
                backgroundColor:
                  selectedTab === 0
                    ? `${chakratheme.colors.primary.lighter}`
                    : `${chakratheme.colors.gray[500]}`
              },
              backgroundColor:
                selectedTab === 0
                  ? `${chakratheme.colors.primary.lighter}`
                  : `${chakratheme.colors.gray.lighter}`
            }}
          />
          <Tab
            label="All"
            value={1}
            sx={{
              '&:hover': {
                backgroundColor:
                  selectedTab === 1
                    ? `${chakratheme.colors.primary.lighter}`
                    : `${chakratheme.colors.gray[500]}`
              },
              backgroundColor:
                selectedTab === 1
                  ? `${chakratheme.colors.primary.lighter}`
                  : `${chakratheme.colors.gray.lighter}`
            }}
          />
        </TabList>
        <TabPanel style={{ paddingLeft: 0, paddingRight: 0, paddingTop: 0 }} value={0}>
          <Flex w="100%" mt={0} gap={'10px'}>
            <Box
              w="50%"
              style={{
                boxShadow: `${chakratheme.colors.shadow} 0px 0px 20px 10px`
              }}>
              <Text ml={2} mt={2} p="3" fontWeight={'bold'} fontSize="15px" textAlign="left">
                Assortment Composition
              </Text>
              <Text
                ml={5}
                style={{
                  color: `${chakratheme.colors.black[400]}`,
                  fontSize: '15px',
                  fontFamily: 'sans-serif'
                }}>
                Assortment composition of top 10 Class categories to identify key performers.
              </Text>
              {!props.loading ? (
                <PieeChart
                  label="L2"
                  value="COUNT_DISTINCT(sap_id)"
                  data={props.l2data}></PieeChart>
              ) : (
                <Skeleton
                  variant="rectangular"
                  width="100%"
                  height="400px"
                  style={{ margin: '10px', borderRadius: '20px' }}
                />
              )}
            </Box>
            <Box
              w="50%"
              style={{
                boxShadow: `${chakratheme.colors.shadow} 0px 0px 20px 10px`
              }}
              ml={2}>
              <Text ml={2} mt={2} p="3" fontWeight={'bold'} fontSize="15px" textAlign="left">
                Distribution of Missed Opportunities
              </Text>
              <Text
                ml={6}
                style={{
                  color: `${chakratheme.colors.black[400]}`,
                  fontSize: '15px',
                  fontFamily: 'sans-serif'
                }}>
                Class&apos;s top 10 missed opportunities for strategy refinement.
              </Text>
              {!props.loading ? (
                <PieeChart
                  label="L2"
                  value="COUNT_DISTINCT(sap_id)"
                  data={props.l2missdata}></PieeChart>
              ) : (
                <Skeleton
                  variant="rectangular"
                  width="100%"
                  height="400px"
                  style={{ margin: '10px', borderRadius: '20px' }}
                />
              )}
            </Box>
          </Flex>
        </TabPanel>
        <TabPanel style={{ paddingLeft: 0, paddingRight: 0, paddingTop: 0 }} value={1}>
          <AssortmentTable
            data={props.l2tabledata}
            handlePagination={props.handlePagination4}
            sortBy={props.sortBy4}
            setSortBy={props.setSortBy4}
            sortOrder={props.sortOrder4}
            setSortOrder={props.setSortOrder4}
            totalProductsCount={props.l2count}
            page={props.page4}
            setPage={props.setPage4}
            headers={[
              {
                name: 'Class',
                id: 'L2',
                sort: '',
                colSpan: 5
              },
              {
                name: 'Number of Products in Assortment',
                id: 'count_comp',
                sort: 'desc',
                colSpan: 3,
                type: 'text'
              },
              {
                name: 'Number of Missed Opportunities',
                id: 'count_miss',
                sort: '',
                colSpan: 3
              },
              {
                name: 'Ratio',
                id: 'ratio',
                sort: '',
                colSpan: 3,
                toolTip: true,
                toolTipText: 'No. of missed opportunities / No. of products in assortment'
              }
            ]}
          />
        </TabPanel>
      </TabContext>
      <Text mb={4} mt={2} fontWeight={'bold'} fontSize="14px" textAlign="left">
        Assortment Composition and Missed Opportunities -
        <span
          style={{
            color: `${chakratheme.colors.primary.main}`,
            fontWeight: 'bold',
            backgroundColor: `${chakratheme.colors.primary.lighter}`,
            padding: '2px 3px',
            borderRadius: '4px'
          }}>
          Segment
        </span>{' '}
        category
      </Text>
      <TabContext value={selectedTabL3}>
        <TabList
          textColor="black"
          indicatorColor="black"
          // backgroundColor="secondary"
          onChange={(event, value) => {
            setSelectedTabL3(value);
          }}>
          <Tab
            label="Top 10"
            value={0}
            sx={{
              '&:hover': {
                backgroundColor:
                  selectedTabL3 === 0
                    ? `${chakratheme.colors.primary.lighter}`
                    : `${chakratheme.colors.gray[500]}`
              },
              backgroundColor:
                selectedTabL3 === 0
                  ? `${chakratheme.colors.primary.lighter}`
                  : `${chakratheme.colors.gray.lighter}`
            }}
          />
          <Tab
            label="All"
            value={1}
            sx={{
              '&:hover': {
                backgroundColor:
                  selectedTabL3 === 1
                    ? `${chakratheme.colors.primary.lighter}`
                    : `${chakratheme.colors.gray[500]}`
              },
              backgroundColor:
                selectedTabL3 === 1
                  ? `${chakratheme.colors.primary.lighter}`
                  : `${chakratheme.colors.gray.lighter}`
            }}
          />
        </TabList>
        <TabPanel style={{ paddingLeft: 0, paddingRight: 0, paddingTop: 0 }} value={0}>
          <Flex w="100%" gap="10px">
            <Box
              w="50%"
              style={{
                boxShadow: `${chakratheme.colors.shadow} 0px 0px 20px 10px`
              }}>
              <Text ml={2} mt={2} fontWeight={'bold'} p="3" fontSize="15px" textAlign="left">
                Assortment Composition
              </Text>
              <Text
                ml={5}
                style={{
                  color: `${chakratheme.colors.black[400]}`,
                  fontSize: '15px',
                  fontFamily: 'sans-serif'
                }}>
                Assortment composition of top 10 Segment categories to identify key performers.
              </Text>
              {!props.loading ? (
                <PieeChart
                  label="L3"
                  value="COUNT_DISTINCT(sap_id)"
                  data={props.l3data}></PieeChart>
              ) : (
                <Skeleton
                  variant="rectangular"
                  width="100%"
                  height="400px"
                  style={{ margin: '10px', borderRadius: '20px' }}
                />
              )}
            </Box>
            <Box
              w="50%"
              ml={2}
              style={{
                boxShadow: `${chakratheme.colors.shadow} 0px 0px 20px 10px`
              }}>
              <Text ml={2} mt={2} fontWeight={'bold'} fontSize="15px" p="3" textAlign="left">
                Distribution of Missed Opportunities
              </Text>
              <Text
                ml={6}
                style={{
                  color: `${chakratheme.colors.black[400]}`,
                  fontSize: '15px',
                  fontFamily: 'sans-serif'
                }}>
                Segment&apos;s top 10 missed opportunities for strategy refinement.
              </Text>
              {!props.loading ? (
                <PieeChart
                  label="L3"
                  value="COUNT_DISTINCT(sap_id)"
                  data={props.l3missdata}></PieeChart>
              ) : (
                <Skeleton
                  variant="rectangular"
                  width="100%"
                  height="400px"
                  style={{ margin: '10px', borderRadius: '20px' }}
                />
              )}
            </Box>
          </Flex>
        </TabPanel>
        <TabPanel style={{ paddingLeft: 0, paddingRight: 0, paddingTop: 0 }} value={1}>
          <AssortmentTable
            data={props.l3tabledata}
            handlePagination={props.handlePagination5}
            sortBy={props.sortBy5}
            setSortBy={props.setSortBy5}
            sortOrder={props.sortOrder5}
            setSortOrder={props.setSortOrder5}
            totalProductsCount={props.l3count}
            page={props.page5}
            setPage={props.setPage5}
            headers={[
              {
                name: 'Segment',
                id: 'L3',
                sort: '',
                colSpan: 5
              },
              {
                name: 'Number of Products in Assortment',
                id: 'count_comp',
                sort: 'desc',
                colSpan: 3,
                type: 'text'
              },
              {
                name: 'Number of Missed Opportunities',
                id: 'count_miss',
                sort: '',
                colSpan: 3
              },
              {
                name: 'Ratio',
                id: 'ratio',
                sort: '',
                colSpan: 3,
                toolTip: true,
                toolTipText: 'No. of missed opportunities / No. of products in assortment'
              }
            ]}
          />
        </TabPanel>
      </TabContext>
    </>
  );
};
export default L2Assort;
