import { Flex, Text } from '@chakra-ui/layout';
import React, { useContext } from 'react';
import { Box, useTheme } from '@chakra-ui/react';
import IconButton from '@mui/material/IconButton';
import { Tooltip } from '@mui/material';
import DownloadIcon from '@mui/icons-material/Download';
import { ToggleButton, ToggleButtonGroup } from '@mui/material';
import AssortmentTable from '../../components/Table';
import MarginAnalysis from '../../components/MarginAnalysis';
import { LocationContext } from '../../Contexts/LocationContext';

export default function ProductsAssortment({
  assortmentTableState,
  setAssortmentTableState,

  // selectedRegions,
  alignment,
  downloadLoad3,
  hits_misses_data,
  handlePagination2,
  totalProductsCount,
  page1,
  hitsMissesLoading,
  setPage1,
  // sortBy1,
  // setSortBy1,
  // sortOrder1,
  // setSortOrder1,
  headersnew,
  fetchBulkData,
  uploadedFile,
  setUploadedFile,
  pinFilters,
  setPinFilters,
  // categoryNested,
  categoryLevelNames,
  selectedCategories2,
  setSelectedCategories2,
  // regions_nested,
  levelNames,
  selectedRegions2,
  setSelectedRegions2,
  searchData,
  setSearchData,
  bucketsData,
  set_hits_misses_data,
  downloadCSV3,
  setAlignment,
  // capitalizeFirstLetter,
  lastIndex
}) {
  console.log('sortdata__', assortmentTableState);
  const chakratheme = useTheme();
  const { globalFiltersLevelNames, filterIDs, consoleState } = useContext(LocationContext);
  const _lastIndex = lastIndex(consoleState.state.globalFilters['region'].selected);
  const _name = globalFiltersLevelNames('region')[_lastIndex];
  const _value = consoleState.state.globalFilters['region'].selected[_lastIndex];

  return (
    <>
      <Flex
        mt={4}
        w="100%"
        h="100%"
        style={{
          fontFamily: 'Poppins'
        }}>
        <Box w="100%">
          <Text mb={0} fontWeight={'bold'} fontSize="15px" textAlign="left">
            {consoleState.state.constants.assortmentAnalysis.TABLE_HEADER_PREFIX}
            {filterIDs.includes('region') &&
            consoleState.state.globalFilters['region'].selected.some((f) => f) ? (
              <>
                ({' '}
                <span
                  style={{
                    color: 'green',
                    fontWeight: 'bold',
                    backgroundColor: `${chakratheme.colors.success.light}`,
                    padding: '2px 3px',
                    borderRadius: '4px'
                  }}>
                  {_value}
                </span>{' '}
                {_name})
              </>
            ) : null}
          </Text>
          <Box w="100%">
            <Flex
              style={{ cursor: 'pointer' }}
              justifyContent="space-between"
              alignItems={'center'}
              marginTop="20px"
              mb={6}>
              <Flex>
                <ToggleButtonGroup
                  sx={{
                    marginRight: '10px',
                    '& .MuiToggleButton-root ': {
                      fontSize: '12px'
                    },
                    '& .MuiToggleButton-root.Mui-selected, & .MuiToggleButton-root.Mui-selected:hover':
                      {
                        backgroundColor: 'white',
                        borderBottom: `4px solid ${consoleState.state.assortmentTable.types[alignment].color}`,
                        color: consoleState.state.assortmentTable.types[alignment].color
                      }
                  }}
                  value={alignment}
                  exclusive
                  onChange={(event, newAlignment) => {
                    if (newAlignment == null) return;
                    setAlignment(newAlignment);
                  }}
                  aria-label="text alignment">
                  {Object.keys(consoleState.state.assortmentTable.types).map((filter) => {
                    const Icon = consoleState.state.assortmentTable.types[filter].icon;
                    return (
                      <ToggleButton key={filter} value={filter} aria-label="left aligned">
                        <Icon style={{ marginRight: '10px' }} />
                        {consoleState.state.assortmentTable.types[filter].name}
                      </ToggleButton>
                    );
                  })}
                </ToggleButtonGroup>
              </Flex>
              <Flex>
                <Flex>
                  <Text mr={2} marginTop="5px">
                    {downloadLoad3 && 'Downloading...'}
                  </Text>
                  <Tooltip title="Download assortment" placement="top" arrow>
                    <IconButton
                      variant="contained"
                      sx={{
                        cursor: 'pointer',
                        backgroundColor: 'white',
                        color: `${chakratheme.colors.primary.main}`,
                        transition: 'color 0.1s',
                        boxShadow: `0 0 20px 0 ${chakratheme.colors.shadow}`,
                        borderRadius: '50px',
                        width: '35px',
                        height: '35px',
                        '&:hover': {
                          backgroundColor: `${chakratheme.colors.primary.main}`,
                          color: 'white'
                        }
                      }}
                      onClick={() => downloadCSV3()}>
                      <DownloadIcon sx={{ fontSize: '22px' }} />
                    </IconButton>
                  </Tooltip>
                </Flex>
              </Flex>
            </Flex>
            {alignment === 'assortment' ? (
              <AssortmentTable
                assortmentTableState={assortmentTableState}
                setAssortmentTableState={setAssortmentTableState}
                data={hits_misses_data}
                setData={set_hits_misses_data}
                handlePagination={handlePagination2}
                totalProductsCount={totalProductsCount}
                page={page1}
                loading={hitsMissesLoading}
                setPage={setPage1}
                // sortBy={sortBy1}
                // setSortBy={setSortBy1}
                // sortOrder={sortOrder1}
                // setSortOrder={setSortOrder1}
                headers={headersnew}
                fetchBulkData={fetchBulkData}
                uploadedFile={uploadedFile}
                setUploadedFile={setUploadedFile}
                pinFilters={pinFilters}
                setPinFilters={setPinFilters}
                // categoryNested={categoryNested}
                categoryLevelNames={categoryLevelNames}
                selectedCategories={selectedCategories2}
                setSelectedCategories={setSelectedCategories2}
                // regions_nested={regions_nested}
                levelNames={levelNames}
                selectedRegions={selectedRegions2}
                setSelectedRegions={setSelectedRegions2}
                searchData={searchData}
                setSearchData={setSearchData}
              />
            ) : (
              <AssortmentTable
                assortmentTableState={assortmentTableState}
                setAssortmentTableState={setAssortmentTableState}
                data={hits_misses_data}
                handlePagination={handlePagination2}
                totalProductsCount={totalProductsCount}
                page={page1}
                loading={hitsMissesLoading}
                setPage={setPage1}
                // sortBy={sortBy1}
                // setSortBy={setSortBy1}
                // sortOrder={sortOrder1}
                // setSortOrder={setSortOrder1}
                headers={headersnew}
                searchData={searchData}
                setSearchData={setSearchData}
                // defaultSort={"num_qty_sold"}
              />
            )}
          </Box>
        </Box>
      </Flex>
      {consoleState.state.features.assortmentAnalysisTable.productSpread ? (
        <Box w="100%">
          <MarginAnalysis fullData={bucketsData} consoleState={consoleState}></MarginAnalysis>
        </Box>
      ) : null}
    </>
  );
}
