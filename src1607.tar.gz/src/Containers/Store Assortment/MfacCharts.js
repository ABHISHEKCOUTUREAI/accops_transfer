import { Flex, Text } from '@chakra-ui/layout';
import React, { useContext, useEffect, useState } from 'react';
import { Box, useTheme, ChakraProvider } from '@chakra-ui/react';
import { InfoOutlined } from '@mui/icons-material';
import TopManufacturers from '../../components/TopManufacturers';
import PastSales from '../../components/PastSales';
import { Tooltip } from '@mui/material';
import { LocationContext } from '../../Contexts/LocationContext';
import { DemandSurgeTable } from '../../components/DemandSurgeTable';
import { DemandDipTable } from '../../components/DemandDipTable';
import { CriticalLowStockCategoriesTable } from '../../components/CriticalLowStockCategoriesTable';
import { CriticalReplenishmentCategoriesTable } from '../../components/CriticalReplenishmentCategories';
import { CategoryTreeMapView } from '../../components/CategoryTreeMapView';
import theme from '../../theme';

export default function MfacCharts(props) {
  const { filterIDs, consoleState } = useContext(LocationContext);
  const chakratheme = useTheme();
  const [storeId, setStoreId] = useState(consoleState?.state?.globalFilters?.region?.selected[3]);

  useEffect(() => {
    setStoreId(consoleState?.state?.globalFilters?.region?.selected[3]);
  }, [...filterIDs.map((filter) => consoleState.state.globalFilters[filter].selected)]);

  return (
    <>
      <ChakraProvider theme={theme}>
        {/* Demand Surge and dip tables */}
        {!props.hideActionableItems && (
          <>
            <Flex>
              <CategoryTreeMapView filterData={props.filterDataForCategoryAnalytics} />
            </Flex>
            <Flex direction={'column'}>
              <Flex gap={5}>
                <CriticalLowStockCategoriesTable
                  filterData={props.filterDataForCategoryAnalytics}
                  w={'50%'}
                />
                <CriticalReplenishmentCategoriesTable
                  filterData={props.filterDataForCategoryAnalytics}
                  w={'50%'}
                />
              </Flex>
            </Flex>

            {storeId && (
              <Flex gap={5} direction={'column'}>
                <DemandSurgeTable />
                <DemandDipTable />
              </Flex>
            )}
          </>
        )}

        <Flex direction="column">
          <Flex alignItems={'center'} flexDir={'row'} w="100%" mt="10" fontFamily="Poppins">
            {props.selectedBrands[0] || props.selectedBrands[1] ? (
              <Text fontWeight={'bold'} fontSize="16px" textAlign="left">
                {consoleState.state.constants.storeAssortment.ANALYTICS_SUBHEADER_TITLE_PREFIX}
                {props.selectedBrands[0] ? (
                  <span>
                    {' '}
                    Manufacturer{' '}
                    <span
                      style={{
                        color: `${chakratheme.colors.gray.darker}`,
                        fontWeight: 'bold',
                        padding: '2px 3px',
                        borderRadius: '4px'
                      }}>
                      {props.selectedBrands[0]}
                    </span>{' '}
                  </span>
                ) : null}
                {props.selectedBrands[0] && props.selectedBrands[1] ? ' and ' : null}
                {props.selectedBrands[1] ? (
                  <span>
                    {' '}
                    Brand{' '}
                    <span
                      style={{
                        color: `${chakratheme.colors.gray.darker}`,
                        fontWeight: 'bold',
                        padding: '2px 3px',
                        borderRadius: '4px'
                      }}>
                      {props.selectedBrands[1]}
                    </span>{' '}
                  </span>
                ) : null}
              </Text>
            ) : (
              <Text fontWeight={'bold'} fontSize="16px" textAlign="left">
                {consoleState.state.constants.storeAssortment.ANALYTICS_SUBHEADER_TITLE}
              </Text>
            )}
            <Tooltip title="Stats for the previous week as per assortment for the stores in selected demographic filters">
              <InfoOutlined
                style={{
                  width: '15px',
                  height: '15px'
                }}
                cursor={'pointer'}
              />
            </Tooltip>
          </Flex>
          <Box
            w="100px"
            bg={`${chakratheme.colors.primary.main}`}
            h="5px"
            borderRadius={'5px'}
            mt="10px"></Box>
          <Text
            mt="2"
            mb="5"
            style={{
              color: `${chakratheme.colors.black[400]}`,
              fontWeight: 'normal',
              fontSize: '15px'
            }}>
            {/* Change Filters to look for particular manufacture and/or brand. Historical duration is
          (Aug&apos;22 - Jul&apos;23) */}
            {consoleState.state.constants.storeAssortment.ANALYTICS_SUBHEADER_SUBTITLE}
          </Text>
        </Flex>
        {consoleState.state.features.manufacturerCharts.topMfacs ? (
          <Box w="100%">
            <TopManufacturers
              loading={props.topMfacLoading}
              // brandData={props.brandData}
              brandLevelNames={props.brandLevelNames}
              selectedBrands={props.selectedBrands}
              setSelectedBrands={props.setSelectedBrands}
              stats={props.stats}
              formatNumber={props.formatNumber}
              number_style={props.number_style}
              horizontalStackData={props.horizontalStackData}
              brandStackData={props.brandStackData}
              brandCategoryNames={props.brandCategoryNames}
              categoryNames={props.categoryNames}></TopManufacturers>
          </Box>
        ) : null}
        <Flex width="100%">
          {consoleState.state.features.manufacturerCharts.pastSales ? (
            <PastSales salesData={props.salesData}></PastSales>
          ) : null}
        </Flex>
      </ChakraProvider>
    </>
  );
}
