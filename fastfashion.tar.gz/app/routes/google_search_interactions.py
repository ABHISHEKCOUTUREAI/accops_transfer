from asyncio import gather

from db import psql_session
from fastapi import APIRouter, Depends
from models import AjioBestSellers, SearchInteractions
from settings import settings
from sqlalchemy.sql import func, select

SearchInteractionRouter = APIRouter(
    prefix=settings.api_prefix,
    tags=["Google Search Interaction"],
    responses={404: {"description": "Not found"}},
)


@SearchInteractionRouter.post("/top-search-interactions")
async def get_top_search_interactions(
    request_data: dict,
    postgres_db=Depends(psql_session),
):
    # cache_key = f"top_search_interactions_{json.dumps(request_data)}"
    # cached_data = await redis_db.get(cache_key)
    # if cached_data:
    #     return json.loads(cached_data)

    # Define the query to fetch data from the database
    query = (
        select(
            SearchInteractions.category,
            func.array_agg(SearchInteractions.related_top_searches).label(
                "related_top_searches"
            ),
            func.array_agg(SearchInteractions.related_rising_searches).label(
                "related_rising_searches"
            ),
        ).group_by(SearchInteractions.category)  # Group by category
    )

    # count the total number of rows
    total_count_query = select(func.count()).select_from(query)
    count = await postgres_db.fetch_val(total_count_query)

    page_no = request_data.get("page_no", 1)
    page_count = request_data.get("page_count", 50)
    offset = (page_no - 1) * page_count
    query = query.limit(page_count).offset(offset)

    # Execute the query
    result = await postgres_db.fetch_all(query)

    category_query_list = []
    for category in result:
        category_query_list.append(
            select(
                AjioBestSellers.brickname,
                AjioBestSellers.brandname,
                AjioBestSellers.image_url,
                AjioBestSellers.productid,
            )
            .where(AjioBestSellers.brickname.ilike(f"%{category.category}%"))
            .limit(5)
        )

    # Execute all the queries at once
    category_results = await gather(
        *[postgres_db.fetch_all(query) for query in category_query_list]
    )

    # Prepare response data
    response_data = []

    for index, row in enumerate(result):
        category = row.category
        related_top_searches = row.related_top_searches
        related_rising_searches = row.related_rising_searches
        category_rows = category_results[index]

        # Add category data to response
        category_data = {
            "category": category,
            "related_top_searches": related_top_searches,
            "related_rising_searches": related_rising_searches,
            "products": category_rows,
        }
        response_data.append(category_data)

    result = {"count": count, "data": response_data}

    # Serialize the data using the custom serializer
    # serialized_data = json.dumps(result)
    # await redis_db.set(cache_key, serialized_data)
    return result
