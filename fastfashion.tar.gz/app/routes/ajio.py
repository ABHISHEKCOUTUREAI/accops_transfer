import asyncio
import json
from collections import defaultdict

from db import check_in_redis, psql_execute_multiple, psql_execute_single, redis_db
from fastapi import APIRouter
from models import (
    AjioBestSellers,
    AjioBrickDetails,
    AjioDemographicDetails,
    AjioProductAttributes,
    Calenderyearmonthweekinfo,
)
from settings import settings
from sqlalchemy import Numeric, and_, cast, func, select
from static import REDIS_CONNECT_ERROR, REDIS_WRITE_ERROR, indian_states
from utils import (
    build_filter_condition,
    create_ajio_filters_query,
    create_ajio_filters_response,
    get_attributes_bestsellers_ajio,
    sort_and_paginate,
    sort_response_using_cache,
)

AjioRouter = APIRouter(
    prefix=settings.api_prefix,
    tags=["Ajio"],
    responses={404: {"description": "Not found"}},
)


@AjioRouter.post("/ajio-filters")
async def get_ajio_filters(
    request_data: dict,
    api_contract_flag: bool = False,
):
    cache_key = f"ajio_filters{json.dumps(request_data)}"
    cached_data = await check_in_redis(cache_key)
    if cached_data:
        return json.loads(cached_data)

    query = await create_ajio_filters_query(request_data)

    if api_contract_flag:
        return query

    result = await psql_execute_single(query)

    response = await create_ajio_filters_response(result)

    cache_response = await check_in_redis("ajio_filters_cache")
    if cache_response:
        cache_response = json.loads(cache_response)
    else:
        cache_response = defaultdict(dict)

    # Sort the response using the cache_response
    response = await sort_response_using_cache(response, cache_response)

    try:
        await redis_db.set(cache_key, json.dumps(response, default=str))
    except Exception as e:
        print(REDIS_WRITE_ERROR, e)

    return response


@AjioRouter.post("/bestsellers-products-ajio")
async def bestseller_ajio(request_data: dict):
    cache_key = f"sale_trends_ajio_{json.dumps(request_data)}"
    cached_data = await check_in_redis(cache_key)
    if cached_data:
        return json.loads(cached_data)

    (
        bestseller_filter,
        demographic_filter,
        product_filter,
        brick_filter,
        calender_filter,
    ) = await asyncio.gather(
        build_filter_condition(request_filters=request_data, filter_flag="bestsellers"),
        build_filter_condition(request_filters=request_data, filter_flag="demographic"),
        build_filter_condition(request_filters=request_data, filter_flag="products"),
        build_filter_condition(request_filters=request_data, filter_flag="brick"),
        build_filter_condition(
            request_filters=request_data, filter_flag="calender", type="calender"
        ),
    )

    bestseller_query = (
        select(
            AjioBestSellers.productid,
            AjioBestSellers.week_of_year,
            AjioBestSellers.year,
            AjioBestSellers.mrp,
            AjioBestSellers.sold_quantity_in_a_week,
            AjioBestSellers.pincode,
        )
        .where(and_(*bestseller_filter))
        .subquery()
    )

    demographic_query = (
        select(
            AjioDemographicDetails.pincode,
        )
        .where(and_(*demographic_filter))
        .subquery()
    )

    calender_query = (
        select(
            Calenderyearmonthweekinfo.year,
            Calenderyearmonthweekinfo.week_of_year,
            func.sum(Calenderyearmonthweekinfo.num_days_in_week).label(
                "total_days_count_across_week"
            ),
        )
        .where(and_(*calender_filter))
        .group_by(
            Calenderyearmonthweekinfo.year,
            Calenderyearmonthweekinfo.week_of_year,
        )
        .subquery()
    )

    ros_query = (
        select(
            bestseller_query.c.productid,
            bestseller_query.c.week_of_year,
            bestseller_query.c.year,
            func.avg(bestseller_query.c.mrp).label("mrp"),
            func.sum(bestseller_query.c.sold_quantity_in_a_week).label(
                "sold_quantity_across_each_week"
            ),
        )
        .join(
            demographic_query, demographic_query.c.pincode == bestseller_query.c.pincode
        )
        .group_by(
            bestseller_query.c.productid,
            bestseller_query.c.week_of_year,
            bestseller_query.c.year,
        )
        .subquery()
    )

    # join ros and calender query
    ros_query = (
        select(
            ros_query.c.productid,
            ros_query.c.year,
            ros_query.c.mrp,
            ros_query.c.sold_quantity_across_each_week,
            calender_query.c.total_days_count_across_week,
        )
        .join(
            calender_query,
            and_(
                ros_query.c.week_of_year == calender_query.c.week_of_year,
                ros_query.c.year == calender_query.c.year,
            ),
        )
        .subquery()
    )

    ros_query = (
        select(
            ros_query.c.productid,
            ros_query.c.year,
            func.sum(ros_query.c.sold_quantity_across_each_week).label(
                "total_qty_sold"
            ),
            func.round(cast(func.avg(ros_query.c.mrp), Numeric), 2).label("mrp"),
            func.round(
                cast(
                    (
                        (
                            func.sum(ros_query.c.sold_quantity_across_each_week)
                            / func.sum(ros_query.c.total_days_count_across_week)
                        )
                        * 7
                    ),
                    Numeric,
                ),
                2,
            ).label("weekly_rate_of_sale"),
        )
        .group_by(ros_query.c.productid, ros_query.c.year)
        .subquery()
    )

    product_query = (
        select(
            AjioProductAttributes.productid,
            AjioProductAttributes.similargrouplevel,
            AjioProductAttributes.title,
            AjioProductAttributes.brandname,
            AjioProductAttributes.imgcode,
            AjioProductAttributes.styletype,
            AjioProductAttributes.colorfamily,
            AjioProductAttributes.pattern,
            AjioProductAttributes.neckline,
        )
        .where(and_(*product_filter))
        .subquery()
    )

    brick_query = (
        select(
            AjioBrickDetails.similargrouplevel,
            AjioBrickDetails.l1name,
            AjioBrickDetails.l2name,
            AjioBrickDetails.brickname,
        )
        .where(and_(*brick_filter))
        .subquery()
    )

    query = (
        select(
            product_query.c.productid,
            product_query.c.title,
            product_query.c.brandname,
            product_query.c.imgcode,
            product_query.c.styletype,
            product_query.c.colorfamily,
            product_query.c.pattern,
            product_query.c.neckline,
            brick_query.c.l1name,
            brick_query.c.l2name,
            brick_query.c.brickname,
            ros_query.c.total_qty_sold,
            ros_query.c.mrp,
            ros_query.c.weekly_rate_of_sale,
        )
        .join(ros_query, ros_query.c.productid == product_query.c.productid)
        .join(
            brick_query,
            brick_query.c.similargrouplevel == product_query.c.similargrouplevel,
        )
    )

    # count the total number of rows
    total_count_query = select(func.count()).select_from(query)
    query = await sort_and_paginate(
        query, request_data, default_sort_param="weekly_rate_of_sale"
    )

    query_list = [query, total_count_query]

    result = await psql_execute_multiple(query_list)

    result = {
        "total_count": result[1][0][0],
        "rows": [
            {
                "productid": row[0],
                "title": row[1],
                "brandname": row[2],
                "imgcode": row[3],
                "styletype": row[4],
                "colorfamily": row[5],
                "pattern": row[6],
                "neckline": row[7],
                "l1name": row[8],
                "l2name": row[9],
                "brickname": row[10],
                "total_qty_sold": row[11],
                "mrp": row[12],
                "weekly_rate_of_sale": row[13],
            }
            for row in result[0]
        ],
    }

    try:
        await redis_db.set(cache_key, json.dumps(result, default=str))
    except Exception as e:
        print(REDIS_WRITE_ERROR, e)

    return result


@AjioRouter.post("/statewise-sales-ajio")
async def get_statewise_sales(
    request_data: dict,
):
    cache_key = f"statewise_sales_{json.dumps(request_data)}"
    try:
        cached_data = await redis_db.get(cache_key)
    except Exception as e:
        print(REDIS_CONNECT_ERROR, e)
        cached_data = None
    if cached_data:
        return json.loads(cached_data)

    sold_in_week_query = (
        select(
            AjioDemographicDetails.state,
            func.sum(AjioBestSellers.sold_quantity_in_a_week).label("quantity"),
        )
        .join(
            AjioDemographicDetails,
            AjioDemographicDetails.pincode == AjioBestSellers.pincode,
        )
        .group_by(
            AjioDemographicDetails.state,
        )
    )

    maps_rows_state = await psql_execute_single(sold_in_week_query)

    map_data = [
        {
            "state": row[0],
            "statecode": indian_states.get(row[0].lower(), {}).get(
                "statecode", "Not Found"
            ),
            "quantity_sold": row[1],
        }
        for row in maps_rows_state
    ]

    try:
        await redis_db.set(cache_key, json.dumps(map_data, default=str))
    except Exception as e:
        print(REDIS_WRITE_ERROR, e)

    return map_data


@AjioRouter.post("/fabric-bestsellers-ajio")
async def get_fabric_bestsellers_ajio(
    request_data: dict,
):
    cache_key = f"fabric_bestsellers_ajio_{json.dumps(request_data)}"
    try:
        cached_data = await redis_db.get(cache_key)
    except Exception as e:
        print(REDIS_CONNECT_ERROR, e)
        cached_data = None

    if cached_data:
        return json.loads(cached_data)

    result = await get_attributes_bestsellers_ajio(
        request_data,
        attribute="fabrictype",
    )

    try:
        await redis_db.set(cache_key, json.dumps(result, default=str))
    except Exception as e:
        print(REDIS_WRITE_ERROR, e)

    return result


@AjioRouter.post("/brandnames-bestsellers-ajio")
async def brandnames_bestsellers_ajio(
    request_data: dict,
):
    cache_key = f"brandnames_bestsellers_ajio_{json.dumps(request_data)}"
    try:
        cached_data = await redis_db.get(cache_key)
    except Exception as e:
        print(REDIS_CONNECT_ERROR, e)
        cached_data = None

    if cached_data:
        return json.loads(cached_data)

    result = await get_attributes_bestsellers_ajio(
        request_data,
        attribute="brandname",
    )

    try:
        await redis_db.set(cache_key, json.dumps(result, default=str))
    except Exception as e:
        print(REDIS_WRITE_ERROR, e)

    return result


@AjioRouter.post("/styletype-bestsellers-ajio")
async def styletype_bestsellers_ajio(
    request_data: dict,
):
    cache_key = f"styletype_bestsellers_ajio_{json.dumps(request_data)}"
    try:
        cached_data = await redis_db.get(cache_key)
    except Exception as e:
        print(REDIS_CONNECT_ERROR, e)
        cached_data = None

    if cached_data:
        return json.loads(cached_data)

    result = await get_attributes_bestsellers_ajio(
        request_data,
        attribute="styletype",
    )

    try:
        await redis_db.set(cache_key, json.dumps(result, default=str))
    except Exception as e:
        print(REDIS_WRITE_ERROR, e)

    return result


@AjioRouter.post("/neckline-bestsellers-ajio")
async def neckline_bestsellers_ajio(
    request_data: dict,
):
    cache_key = f"neckline_bestsellers_ajio_{json.dumps(request_data)}"
    try:
        cached_data = await redis_db.get(cache_key)
    except Exception as e:
        print(REDIS_CONNECT_ERROR, e)
        cached_data = None

    if cached_data:
        return json.loads(cached_data)

    result = await get_attributes_bestsellers_ajio(
        request_data,
        attribute="neckline",
    )

    try:
        await redis_db.set(cache_key, json.dumps(result, default=str))
    except Exception as e:
        print(REDIS_WRITE_ERROR, e)

    return result


@AjioRouter.post("/pattern-bestsellers-ajio")
async def pattern_bestsellers_ajio(
    request_data: dict,
):
    cache_key = f"pattern_bestsellers_ajio_{json.dumps(request_data)}"
    try:
        cached_data = await redis_db.get(cache_key)
    except Exception as e:
        print(REDIS_CONNECT_ERROR, e)
        cached_data = None

    if cached_data:
        return json.loads(cached_data)

    result = await get_attributes_bestsellers_ajio(
        request_data,
        attribute="pattern",
    )

    try:
        await redis_db.set(cache_key, json.dumps(result, default=str))
    except Exception as e:
        print(REDIS_WRITE_ERROR, e)
    return result


@AjioRouter.post("/color-bestsellers-ajio")
async def color_bestsellers_ajio(
    request_data: dict,
):
    cache_key = f"color_bestsellers_ajio_{json.dumps(request_data)}"
    try:
        cached_data = await redis_db.get(cache_key)
    except Exception as e:
        print(REDIS_CONNECT_ERROR, e)
        cached_data = None

    if cached_data:
        return json.loads(cached_data)

    result = await get_attributes_bestsellers_ajio(
        request_data,
        attribute="colorfamily",
    )

    try:
        await redis_db.set(cache_key, json.dumps(result, default=str))
    except Exception as e:
        print(REDIS_WRITE_ERROR, e)

    return result


@AjioRouter.post("/sleevelength-bestsellers-ajio")
async def sleevelength_bestsellers_ajio(
    request_data: dict,
):
    cache_key = f"sleevelength_bestsellers_ajio_{json.dumps(request_data)}"
    try:
        cached_data = await redis_db.get(cache_key)
    except Exception as e:
        print(REDIS_CONNECT_ERROR, e)
        cached_data = None

    if cached_data:
        return json.loads(cached_data)

    result = await get_attributes_bestsellers_ajio(
        request_data,
        attribute="sleevelength",
    )

    try:
        await redis_db.set(cache_key, json.dumps(result, default=str))
    except Exception as e:
        print(REDIS_WRITE_ERROR, e)

    return result
