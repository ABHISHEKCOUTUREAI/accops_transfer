from fastapi import APIRouter
from settings import settings

HealthCheckRouter = APIRouter(
    prefix=settings.api_prefix,
    tags=["HealthCheck"],
    responses={404: {"description": "Not found"}},
)


@HealthCheckRouter.get("/_healthz")
async def healthz():
    return {"success": True}


@HealthCheckRouter.get("/_readyz")
async def readyz():
    return {"success": True}
