from sqlalchemy import select, func, cast, Numeric
from models import Orders, Store





indian_states = {
    "Jammu and Kashmir": {"statecode": "JK", "zone": "North"},
    "andhra pradesh": {"statecode": "AP", "zone": "South"},
    "arunachal pradesh": {"statecode": "AR", "zone": "East"},
    "assam": {"statecode": "AS", "zone": "East"},
    "bihar": {"statecode": "BR", "zone": "East"},
    "chhattisgarh": {"statecode": "CT", "zone": "West"},
    "goa": {"statecode": "GA", "zone": "West"},
    "gujarat": {"statecode": "GJ", "zone": "West"},
    "haryana": {"statecode": "HR", "zone": "North"},
    "himachal pradesh": {"statecode": "HP", "zone": "North"},
    "jharkhand": {"statecode": "JH", "zone": "East"},
    "karnataka": {"statecode": "KA", "zone": "South"},
    "kerala": {"statecode": "KL", "zone": "South"},
    "madhya pradesh": {"statecode": "MP", "zone": "West"},
    "maharashtra": {"statecode": "MH", "zone": "West"},
    "manipur": {"statecode": "MN", "zone": "East"},
    "meghalaya": {"statecode": "ML", "zone": "East"},
    "mizoram": {"statecode": "MZ", "zone": "East"},
    "nagaland": {"statecode": "NL", "zone": "East"},
    "odisha": {"statecode": "OR", "zone": "East"},
    "punjab": {"statecode": "PB", "zone": "North"},
    "rajasthan": {"statecode": "RJ", "zone": "North"},
    "sikkim": {"statecode": "SK", "zone": "East"},
    "tamil nadu": {"statecode": "TN", "zone": "South"},
    "telangana": {"statecode": "TG", "zone": "South"},
    "tripura": {"statecode": "TR", "zone": "East"},
    "uttar pradesh": {"statecode": "UP", "zone": "North"},
    "uttarakhand": {"statecode": "UT", "zone": "North"},
    "west bengal": {"statecode": "WB", "zone": "East"},
    "andaman and nicobar islands": {"statecode": "AN", "zone": "South"},
    "chandigarh": {"statecode": "CH", "zone": "North"},
    "dadra and nagar haveli and daman and diu": {"statecode": "DN", "zone": "West"},
    "delhi": {"statecode": "DL", "zone": "North"},
    "lakshadweep": {"statecode": "LD", "zone": "South"},
    "puducherry": {"statecode": "PY", "zone": "South"},
}


async def get_state_map_data(
    postgres_db
):
    
    map_query_state = (
        select([
            Store.state,
            func.round(cast(func.sum(Orders.total_revenue), Numeric), 2).label('revenue'),
            func.round(cast(func.sum(Orders.quantity_sold), Numeric), 2).label('quantity_sold'),
            (func.round(cast(func.sum(Orders.total_revenue), Numeric), 2) - func.round(cast(func.sum(Orders.total_cost), Numeric), 2)).label('margin'),
        ])
        .join(Store, Orders.br_code == Store.br_code)
        .group_by(Store.state)
    )

    maps_rows_state = await postgres_db.fetch_all(map_query_state)
    assortment_state = [
        {
            'state': row['state'],
            'statecode': indian_states.get(row['state'].lower(), {}).get('statecode', 'Not Found'),
            'zone': indian_states.get(row['state'].lower(), {}).get('zone', 'Not Found'),
            'revenue': row['revenue'],
            'quantity_sold': row['quantity_sold'],
            'margin': row['margin']
        }
        for row in maps_rows_state
    ]

    # Include states with 0 revenue
    for state_name, state_info in indian_states.items():
        state_code = state_info["statecode"]
        zone = state_info.get("zone", "")  # Assuming "zone" is included in the state_info dictionary
        # Check if the state is not in the assortment_state list
        if state_name.lower() not in [state['state'].lower() for state in assortment_state]:
            assortment_state.append({'state': state_name, 'statecode': state_code, 'zone': zone, 'revenue': 0})

    total_revenue = sum(row['revenue'] for row in maps_rows_state)
    total_margin = sum(row['margin'] for row in maps_rows_state)
    total_quantity_sold = sum(row['quantity_sold'] for row in maps_rows_state)

    return assortment_state, total_revenue, total_margin, total_quantity_sold


async def get_zone_map_data(
    postgres_db
):
    # Group by zone
    map_query_zone = (
        select([
            Store.zone,
            func.round(cast(func.sum(Orders.total_revenue), Numeric), 2).label('revenue'),
            func.round(cast(func.sum(Orders.quantity_sold), Numeric), 2).label('quantity_sold'),            
            (func.round(cast(func.sum(Orders.total_revenue), Numeric), 2) - func.round(cast(func.sum(Orders.total_cost), Numeric), 2)).label('margin'),
        ])
        .join(Store, Orders.br_code == Store.br_code)
        .group_by(Store.zone)
    )

    
    maps_rows_zone = await postgres_db.fetch_all(map_query_zone)
    assortment_zone = [dict(row) for row in maps_rows_zone]
    zones = ['east', 'west', 'north', 'south']
    # Include zones with 0 revenue
    for zone in zones:
        if zone.lower() not in [row['zone'].lower() for row in assortment_zone]:
            assortment_zone.append({'zone': zone.capitalize(), 'revenue': 0})
    
    return assortment_zone
