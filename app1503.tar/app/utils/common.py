
from models import AssortmentOutput
from decimal import Decimal



def build_condition(region_type=None, region_name=None, L0=None, L1=None, L2=None, L3=None, mfac_name=None, brand=None):
    
    condition = []

    if region_type == "Zone":
        condition.append(AssortmentOutput.zone == region_name)
    elif region_type == "State":
        condition.append(AssortmentOutput.state == region_name)
    elif region_type == "City":
        condition.append(AssortmentOutput.city == region_name)
    elif region_type == "Branch":
        condition.append(AssortmentOutput.br_code == region_name)

    if L0 is not None:
        condition.append(AssortmentOutput.L0 == L0)
    if L1 is not None:
        condition.append(AssortmentOutput.L1 == L1)
    if L2 is not None:
        condition.append(AssortmentOutput.L2 == L2)
    if L3 is not None:
        condition.append(AssortmentOutput.L3 == L3)

    if mfac_name is not None:
        condition.append(AssortmentOutput.mfac_name == mfac_name)
    if brand is not None:
        condition.append(AssortmentOutput.brand_name == brand)

    return condition


def decimal_serializer(obj):
    if isinstance(obj, Decimal):
        return str(obj)
    raise TypeError("Object of type {} is not JSON serializable".format(type(obj).__name__))


