from sqlalchemy import case, cast, func, select, Integer, and_
from fastapi.responses import JSONResponse
import pandas as pd 

async def group_hit_and_miss(
        request,
        query,
        flag = False,

):
    # Check if the request URL contains "dev.api.couture.ai"
    condition = (
     and_(
        0.7 * query.c.mrp * query.c.num_qty_sold <= query.c.total_amount,
        query.c.mrp * query.c.num_qty_sold >= query.c.total_amount
     ) if request.client.host == '172.18.0.2' else True
    )
    query = (
        (
            select(
                [
                    query.c.sap_id,
                    query.c.item_name,
                    query.c.L0,
                    query.c.L3,
                    query.c.mrp,
                    query.c.molecule,
                    query.c.br_code,
                    query.c.probability,
                    func.sum(query.c.curr_inv).label("current_inventory"),
                    func.sum(query.c.min_qty).label("min_qty"),
                    func.sum(query.c.max_qty).label("max_qty"),
                    cast(func.sum(query.c.num_qty_sold), Integer).label("num_qty_sold"),
                    func.sum(query.c.total_amount).label("total_amount"),
                    func.sum(query.c.total_margin).label("total_margin"),
                ]
            )
        )
        .where(condition)
        .group_by(
            query.c.sap_id,
            query.c.item_name,
            query.c.mrp,
            query.c.L0,
            query.c.L3,
            query.c.molecule,
            query.c.br_code,
            query.c.probability,
        )
        .subquery()
    )


    if request.client.host == '172.18.0.2':

        new_query = select(
            [
                query,
                case(
                [
                    (
                        and_(
                            query.c.current_inventory <= query.c.min_qty,
                            (query.c.max_qty - query.c.current_inventory > -16) & (query.c.max_qty - query.c.current_inventory < 16)
                        ),
                        query.c.max_qty - query.c.current_inventory,
                    ),
                    (
                        and_(
                            query.c.current_inventory < query.c.max_qty,
                            query.c.current_inventory > query.c.min_qty
                        ),
                        0,
                    ),
                    (
                        and_(
                            query.c.current_inventory >= query.c.max_qty,
                            (query.c.max_qty - query.c.current_inventory > -16) & (query.c.max_qty - query.c.current_inventory < 16)
                        ),
                        query.c.max_qty - query.c.current_inventory,
                    ),
                ]
                ).label("minimum_replenishment"),
                # status_label
                case(
                    [
                        (
                            (query.c.current_inventory == 0) & (query.c.min_qty > 0),
                            "0_new",
                        ),
                        (
                            (query.c.current_inventory > 0) & (query.c.current_inventory < query.c.min_qty),
                            "1_replenish",
                        ),
                        (
                            (query.c.current_inventory > 0)
                            & (query.c.current_inventory >= query.c.min_qty)
                            & (query.c.current_inventory <= query.c.max_qty),
                            "2_no_replenishment",
                        ),
                        (
                            (query.c.current_inventory == 0) & (query.c.max_qty == 0),
                            "8_dead",
                        ),
                        (
                            (query.c.current_inventory > query.c.max_qty),
                            "9_excess",
                        ),
                        # else 'unidentified
                    ],
                ).label("status_label"),
            ]
            ).subquery()

        if flag:
            new_query = select([new_query]).where(and_(new_query.c.minimum_replenishment >= -15, new_query.c.minimum_replenishment <= 15))
        else:
            new_query = select([new_query])

    else:

        new_query = select(
            [
                query,
                case(
                    [
                        (
                            query.c.current_inventory <= query.c.min_qty,
                            query.c.max_qty - query.c.current_inventory,
                        ),
                        (
                            (query.c.current_inventory < query.c.max_qty)
                            & (query.c.current_inventory > query.c.min_qty),
                            0,
                        ),
                        (
                            query.c.current_inventory >= query.c.max_qty,
                            query.c.max_qty - query.c.current_inventory,
                        ),
                    ]
                ).label("minimum_replenishment"),
                # status_label
                case(
                    [
                        (
                            (query.c.current_inventory == 0) & (
                                query.c.min_qty > 0),
                            "0_new",
                        ),
                        (
                            (query.c.current_inventory > 0)
                            & (query.c.current_inventory < query.c.min_qty),
                            "1_replenish",
                        ),
                        (
                            (query.c.current_inventory > 0)
                            & (query.c.current_inventory >= query.c.min_qty)
                            & (query.c.current_inventory <= query.c.max_qty),
                            "2_no_replenishment",
                        ),
                        (
                            (query.c.current_inventory == 0) & (
                                query.c.max_qty == 0),
                            "8_dead",
                        ),
                        (
                            (query.c.current_inventory > query.c.max_qty),
                            "9_excess",
                        ),
                        # else 'unidentified
                    ],
                ).label("status_label"),
            ]
        )


    return new_query


async def get_status_count(
    assortment_query,
    postgres_db
):
    total_assortment_query = select(
        [func.count().label("total_assortment_count")]
    ).select_from(assortment_query)
    total_assortment_count = await postgres_db.fetch_val(total_assortment_query)

    # count rows where query.status_label = 'new_count'
    new_count_query = (
        select([func.count().label("0_new")])
        .select_from(assortment_query)
        .where(assortment_query.c.status_label == "0_new")
    )
    new_count = await postgres_db.fetch_val(new_count_query)

    # count rows where query.status_label = '1_replenish'
    replenish_count_query = (
        select([func.count().label("1_replenish")])
        .select_from(assortment_query)
        .where(assortment_query.c.status_label == "1_replenish")
    )
    replenish_count = await postgres_db.fetch_val(replenish_count_query)

    # count rows where query.status_label = 'optimal'
    no_replenishment_count_query = (
        select([func.count().label("2_no_replenishment")])
        .select_from(assortment_query)
        .where(assortment_query.c.status_label == "2_no_replenishment")
    )
    optimal_count = await postgres_db.fetch_val(no_replenishment_count_query)

    # count rows where query.status_label = 'excess_count'
    excess_count_query = (
        select([func.count().label("9_excess")])
        .select_from(assortment_query)
        .where(assortment_query.c.status_label == "9_excess")
    )
    excess_count = await postgres_db.fetch_val(excess_count_query)

    return new_count, replenish_count, optimal_count, excess_count, total_assortment_count


async def get_hit_results(
    request,
    query,
    order_by_clause,
    offset,
    postgres_db,
    request_df=None,
    page_count=100,

):
    hit_query = select([query]).where(
        and_(query.c.exist_in_model_output == 1, query.c.is_sold == 1)
    )
    hit_query = await group_hit_and_miss(request, hit_query.subquery(), flag = True)

    hit_count_query = select(
        [func.count().label("hit_count")]).select_from(hit_query)
    hit_count = await postgres_db.fetch_val(hit_count_query)

    hit_query = hit_query.order_by(
        order_by_clause).limit(page_count).offset(offset)
    hit_rows = await postgres_db.fetch_all(hit_query)
    hits = [dict(rows) for rows in hit_rows]
    for hit in hits:
        hit["total_amount"] = (
            round(hit["total_amount"],
                  2) if hit["total_amount"] is not None else None
        )
        if hit["total_amount"] is not None and hit["total_margin"] is not None:
            hit["total_margin"] = round(hit["total_margin"], 2)
        else:
            hit["total_margin"] = None
    if request_df is not None:
        result_df = pd.DataFrame(hits)
        if not hits:
            return JSONResponse(content=[], status_code=200)
        merged_df = pd.merge(result_df, request_df, on=["sap_id", "br_code"], how="left")
        merged_df = merged_df[["sap_id", "item_name", "br_code", "probability"]]
        hits = merged_df.to_dict(orient="records")
    return hits, hit_count


async def get_miss_results(
    request,
    query, 
    order_by_clause, 
    offset, 
    postgres_db,
    request_df=None,
    page_count=100, 

):
    miss_query = select([query]).where(
        and_(query.c.exist_in_model_output == 0, query.c.is_sold == 1)
    )
    miss_query = await group_hit_and_miss(request, miss_query.subquery(), flag = False)

    miss_count_query = select([func.count().label("miss_count")]).select_from(
        miss_query
    )
    miss_count = await postgres_db.fetch_val(miss_count_query)

    miss_query = miss_query.order_by(
        order_by_clause).limit(page_count).offset(offset)
    miss_rows = await postgres_db.fetch_all(miss_query)
    misses = [dict(rows) for rows in miss_rows]
    for miss in misses:
        miss["total_amount"] = (
            round(miss["total_amount"],
                  2) if miss["total_amount"] is not None else None
        )
        if miss["total_amount"] is not None and miss["total_margin"] is not None:
            miss["total_margin"] = round(miss["total_margin"], 2)
        else:
            miss["total_margin"] = None

    if request_df is not None:
        result_df = pd.DataFrame(misses)
        if not misses:
            return JSONResponse(content=[], status_code=200)
        merged_df = pd.merge(result_df, request_df, on=["sap_id", "br_code"], how="left")
        merged_df = merged_df[["sap_id", "item_name", "br_code", "probability"]]
        misses = merged_df.to_dict(orient="records")
    return misses, miss_count


async def get_assortment_results(
    request,
    query,
    order_by_clause,
    offset,
    postgres_db,
    request_df=None,
    page_count=100,
    filter_params=None,
    filter_type=None,
):
    assortment_query = select([query]).where(
        and_(query.c.exist_in_model_output == 1))

    assortment_query = await group_hit_and_miss(request, assortment_query.subquery(), flag = True)

    if filter_params and filter_type:
        if filter_type == "status_label":
            assortment_query_table = assortment_query.subquery()
            # filter params is an array. check if status_label is in filter_params
            assortment_query_table = select([assortment_query_table]).where(
                assortment_query_table.c.status_label.in_(filter_params)
            )
    else:
        assortment_query_table = assortment_query

    assortment_count_query = select(
        [func.count().label("assortment_count")]
    ).select_from(assortment_query_table)
    assortment_count = await postgres_db.fetch_val(assortment_count_query)

    assortment_query_paginated_response = (
        assortment_query_table.order_by(order_by_clause).limit(
            page_count).offset(offset)
    )
    assortment_rows = await postgres_db.fetch_all(assortment_query_paginated_response)
    assortment = [dict(rows) for rows in assortment_rows]
    for assort in assortment:
        assort["total_amount"] = (
            round(assort["total_amount"], 2)
            if assort["total_amount"] is not None
            else None
        )
        if assort["total_amount"] is not None and assort["total_margin"] is not None and assort["total_amount"] != 0:
            assort["total_margin"] = round(assort["total_margin"], 2)
        else:
            assort["total_margin"] = None

    if request_df is not None:
        result_df = pd.DataFrame(assortment)
        if not assortment:
            return JSONResponse(content=[], status_code=200)
        merged_df = pd.merge(result_df, request_df, on=["sap_id", "br_code"], how="inner")
        merged_df = merged_df[["sap_id", "item_name", "br_code", "probability"]]
        assortment = merged_df.to_dict(orient="records")
    return assortment, assortment_count, assortment_query
