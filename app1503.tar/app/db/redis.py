
from redis import asyncio as aioredis
from settings import settings

redis_db = aioredis.from_url(f'redis://{settings.redis_service}:6379/{settings.redis_db}')
