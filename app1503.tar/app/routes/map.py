import json
from fastapi import APIRouter, Depends
from models import  Store
from routes import get_postgres_db
from sqlalchemy import func, select
from db import redis_db
from utils import decimal_serializer, get_state_map_data, get_zone_map_data


map = APIRouter(prefix="/couture/assortment", tags=["manufacture"])





@map.get("/map", operation_id="fetch-map-results")   
async def fetch_map_data(
    postgres_db = Depends(get_postgres_db),
):
    cache_key = "map"
    response =  await redis_db.get(cache_key)
    if response:
        print('map', cache_key)
        result = json.loads(response)
        return result


    # get state data 
    assortment_state, total_revenue, total_margin, total_quantity_sold = await get_state_map_data(postgres_db)

    # get zone data
    assortment_zone = await get_zone_map_data(postgres_db)

    #  get all stores count
    store_count_query = select([func.count(Store.br_code)])
    store_count = await postgres_db.fetch_one(store_count_query)


    # Response
    result = {
        'state': assortment_state,
        'zone': assortment_zone,
        'total_revenue': total_revenue,
        'total_quantity_sold': total_quantity_sold,
        'total_margin': total_margin,
        'total_store': store_count[0]
    }

    serialized_data = json.dumps(result, default=decimal_serializer)
    await redis_db.set(cache_key, serialized_data)

    return result

