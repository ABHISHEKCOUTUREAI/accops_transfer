import json
from fastapi import APIRouter, Form, HTTPException, Depends
from models import AssortmentOutput
from sqlalchemy import and_, insert, update, select, Numeric, String, cast, func
from fastapi.responses import JSONResponse
from pydantic import BaseModel
from typing import List, Dict, Any
from sqlalchemy.exc import IntegrityError
from db import redis_db
from routes import get_postgres_db
from utils import  decimal_serializer


crud = APIRouter(prefix="/couture/assortment", tags=["crud"])

class CustomForm(BaseModel):
    zone: str  
    state: str
    city: str
    br_code: str
    L0: str 
    L1: str 
    L2: str 
    L3: str 
    request_data: List[Dict[str, Any]]



@crud.post("/append", operation_id="add-assortment")
async def append_asssortment(
    request: CustomForm,
    postgres_db = Depends(get_postgres_db)
):
    try:  
        form_data = request
        # Get the column names from the model and  set all columns to None)
        column_names = [column.name for column in AssortmentOutput.__table__.columns]
        default_values = {column: None for column in column_names}

        # Initialize an empty list to store the processed dictionaries
        processed_data = []
        for data_dict in form_data.request_data:
            # Convert specific fields to integers
            for field in ['sap_id', 'total_amount', 'total_margin', 'num_qty_sold', 'min_qty', 'max_qty']:
                if field in data_dict and data_dict[field] is not None:
                    if data_dict[field] != '':
                       data_dict[field] = int(float(data_dict[field]))
                    else:
                       data_dict[field] = 0

            data_dict = {column: data_dict.get(column, default_values[column]) for column in column_names}

            # Update data_dict with common values
            data_dict.update({
                "zone": form_data.zone,
                "state": form_data.state,
                "city": form_data.city,
                "br_code": form_data.br_code,
                "L0": form_data.L0,
                "L1": form_data.L1,
                "L2": form_data.L2,
                "L3": form_data.L3,
                "exist_in_model_output": 1,
                'del_flag': 0
            })

            # Append the updated dictionary to the list
            processed_data.append(data_dict)
        
        status_messages = []
        # Check if the combination of sap_id and br_code already exists
        for data_dict in processed_data:
            existing_row = await postgres_db.fetch_one(
                select([AssortmentOutput]).where(
                    (AssortmentOutput.sap_id == data_dict['sap_id']) &
                    (AssortmentOutput.br_code == data_dict['br_code'])
                )
            )

            if existing_row:
                # Update the existing row
                await postgres_db.execute(
                    update(AssortmentOutput).where(
                        (AssortmentOutput.sap_id == data_dict['sap_id']) &
                        (AssortmentOutput.br_code == data_dict['br_code'])
                    ).values(data_dict)
                )
                status_messages.append(f"Sap_id {data_dict['sap_id']} updated successfully")
            else:
                # Insert a new row
                await postgres_db.execute(
                    insert(AssortmentOutput).values(data_dict)
                )
                status_messages.append(f"Sap_id {data_dict['sap_id']} added successfully")

        # Delete all Redis keys starting with 'hit-and-miss:'
        keys_to_delete = await redis_db.keys("hit-and-miss:*")
        if keys_to_delete:
            await redis_db.delete(*keys_to_delete)
       
        # Construct the final response message
        response_message = ", ".join(status_messages)
        return JSONResponse(content={"message": response_message}, status_code=201)



    except IntegrityError as e:
        # Handle duplicate key violation
        return HTTPException(status_code=400, detail=f"Duplicate key violation: {str(e)}")


    except Exception as e:
        return HTTPException(status_code=400,  detail=f"Error in adding file to db {str(e)}")  



@crud.delete("/delete", operation_id="delete-assortment")
async def delete_asssortment(
    br_code: str = Form(None),
    sap_ids: list[int] = Form([]),
    postgres_db = Depends(get_postgres_db)
):

    try:
        if br_code is None or sap_ids is None:
            raise HTTPException(status_code=400, detail={"message": "Either br_code or sap_id must be provided for deletion"})
        condition = []
        if br_code is not None:
            condition.append(AssortmentOutput.br_code == br_code)
        if sap_ids:
            condition.append(AssortmentOutput.sap_id.in_(sap_ids))

        if not condition:
            raise HTTPException(status_code=400, detail="No conditions provided for deletion")

        # Update the rows matching the conditions
        query = update(AssortmentOutput).where(and_(*condition)).values(del_flag=1, exist_in_model_output=0)
        await postgres_db.execute(query)

        # Delete all Redis keys starting with 'hit-and-miss:'
        keys_to_delete = await redis_db.keys("hit-and-miss:*")
        if keys_to_delete:
            await redis_db.delete(*keys_to_delete)

        return JSONResponse(content={"message": "Data deleted successfully"}, status_code=201)
    
    except HTTPException as http_exception:
        raise http_exception   
     
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Error updating rows: {str(e)}")
    

@crud.post("/autocomplete-sap-id")  
async def fetch_sap_id(
    br_code: str = Form(None),
    L0: str = Form(None),
    L1: str = Form(None),
    L2: str = Form(None),
    L3: str = Form(None),
    sap_id: int = Form(None),
    flag: bool = Form(True),
    postgres_db = Depends(get_postgres_db)
):
    cache_key = f"hit_and_miss:{br_code}:{L0}:{L1}:{L2}:{L3}:{sap_id}"
    response =  await redis_db.get(cache_key)
    if response:
        print(cache_key)
        result = json.loads(response)
        return result

    condition = []

    if L0 is not None:
        condition.append(AssortmentOutput.L0 == L0)
    if L1 is not None:
        condition.append(AssortmentOutput.L1 == L1)
    if L2 is not None:
        condition.append(AssortmentOutput.L2 == L2)
    if L3 is not None:
        condition.append(AssortmentOutput.L3 == L3) 
    if br_code is not None:
        condition.append(AssortmentOutput.br_code == br_code)      
    if sap_id is not None :
        if flag:
            condition.append(cast(AssortmentOutput.sap_id, String).startswith(str(sap_id)))
        else:
            condition.append(AssortmentOutput.sap_id == sap_id)    
       

    # Build the filter 
    if flag:
        query = ( 
            select([
            AssortmentOutput.sap_id,
        ])
        .group_by(AssortmentOutput.sap_id, AssortmentOutput.item_name)  # Add more columns if needed
        )
    else:
        query = ( 
            select([
            AssortmentOutput.sap_id,
            AssortmentOutput.item_name,
            func.round(func.sum(cast(AssortmentOutput.total_amount, Numeric)), 2).label('total_amount'),
            func.round(func.sum(cast(AssortmentOutput.total_margin, Numeric)), 2).label('total_margin'),
            func.round(func.sum(cast(AssortmentOutput.num_qty_sold, Numeric)), 2).label('num_qty_sold'),
        ])
        .group_by(AssortmentOutput.sap_id, AssortmentOutput.item_name)  # Add more columns if needed
        )

    # Assortment
    assortment_condition = and_(*condition, AssortmentOutput.exist_in_model_output == 0)
    assortment_query = query.where(assortment_condition)

    assortment_rows = await postgres_db.fetch_all(assortment_query)
    result = [dict(rows) for rows in assortment_rows]
    if not flag:
        for assort in result:
            assort["total_amount"] = round(assort["total_amount"], 2) if assort["total_amount"] is not None else None
            assort["total_margin"] = round(assort["total_margin"], 2) if assort["total_margin"] is not None else None

    serialized_data = json.dumps(result, default=decimal_serializer)
    await redis_db.set(cache_key, serialized_data)
    return result
