import csv
import math
from collections import defaultdict
from io import StringIO
import pandas as pd
from fastapi import APIRouter, File, Form, UploadFile, Depends
from fastapi.responses import JSONResponse,  StreamingResponse
from sqlalchemy import  and_, asc, case, desc, func, join, or_, select, cast, Numeric, String
from routes.common import get_postgres_db
from models import AssortmentOutput,  Product
from utils import build_condition
from db import redis_db
from typing import List, Optional
import json
from asyncio import gather
from utils import  get_status_count, get_hit_results, get_assortment_results, get_miss_results
from fastapi import Request

prediction = APIRouter(prefix="/couture/assortment", tags=["prediction"])

@prediction.post("/hit-and-miss", operation_id="fetch-products-info")
async def fetch_hit_and_miss(
    request: Request,
    request_csv: Optional[UploadFile] = File(None),
    region_type: str = Form(None),
    region_name: str = Form(None),
    L0: str = Form(None),
    L1: str = Form(None),
    L2: str = Form(None),
    L3: str = Form(None),
    mfac_name: str = Form(None),
    brand_name: str = Form(None),
    page_no: int = Form(1),
    page_count: int = Form(100),
    sort_param: str = Form("num_qty_sold"),
    sort_type: str = Form("desc"),
    filter_params: List[str] = Form([]),
    molecule: str = Form(None),
    sap_id: int = Form(None),
    filter_type: str = Form(None),
    counts_flag: bool = Form(False),
    postgres_db=Depends(get_postgres_db),
):

    request_df = None
    if request_csv is not None:
        request_df = pd.read_csv(request_csv.file)
        if request_df.empty:
            return JSONResponse(
                content={"message": "Request data is empty."}, status_code=200
            )
    else:  
        cache_key = f"hit-and-miss:{region_type}:{region_name}:{L0}:{L1}:{L2}:{L3}:{mfac_name}:{brand_name}:{page_no}:{page_count}:{sort_param}:{sort_type}:{filter_params}:{molecule}:{sap_id}:{filter_type}:{counts_flag}"
        response = await redis_db.get(cache_key)
        if response:
            result = json.loads(response)
            return result
    
    condition = build_condition(
        region_type, region_name, L0, L1, L2, L3, mfac_name, brand=brand_name
    )

    query = select([AssortmentOutput]).where(and_(*condition)).subquery()
    
    # update query to filter by molecule
    if molecule:
        query = (
            select([query, Product.mrp, Product.molecule.label('molecule')])
            .select_from(join(query, Product, query.c.sap_id == Product.sap_id))
            .where(Product.molecule.ilike(f"{molecule}%"))
            .subquery()
        )
    else:
        query = (
            select([query, Product.mrp, Product.molecule.label('molecule')])
            .select_from(join(query, Product, query.c.sap_id == Product.sap_id))
            .subquery()
        )
    if sap_id is not None:
        query = select([query]).where(cast(query.c.sap_id, String).ilike(f"{sap_id}%")).subquery()


    result = {
        "assortment": [],
        "hits": [],
        "misses": [],
        "hit_count": 0,
        "miss_count": 0,
        "assortment_count": 0
    }

    # sort and limit the query results
    order_by_clause = (desc(f"{sort_param}") if sort_type == "desc" else asc(f"{sort_param}")) 
    offset = (page_no - 1) * page_count

    # Hits
    hit_response = await get_hit_results(request, query, order_by_clause, offset, postgres_db, request_df, page_count=100)
    hits, hit_count = hit_response
    result["hits"] = hits
    result["hit_count"] = hit_count
    
    # Misses
    miss_response = await get_miss_results(request, query, order_by_clause, offset, postgres_db, request_df, page_count=100)
    misses, miss_count = miss_response
    result["misses"] = misses
    result["miss_count"] = miss_count

    # Assortment
    assortment_response = await get_assortment_results(request, query, order_by_clause, offset, postgres_db, request_df, page_count=100, filter_params=filter_params, filter_type=filter_type)
    assortment, assortment_count, assortment_query = assortment_response
    result["assortment"] = assortment
    result["assortment_count"] = assortment_count

    if counts_flag:
    # Status count
        response = await get_status_count(assortment_query, postgres_db)
        new_count, replenish_count, optimal_count, excess_count, total_assortment_count = response
        result['new_count'] = new_count
        result['replenish_count'] = replenish_count
        result['optimal_count'] = optimal_count
        result['excess_count'] = excess_count
        result['total_assortment_count'] = total_assortment_count

    if request_csv is None:  
        serialized_data = json.dumps(result, default=str)
        await redis_db.set(cache_key, serialized_data)

    return result

@prediction.post("/hit-miss-csv", operation_id="fetch-hit-miss-csv")  # done
async def fetch_hit_and_miss_csv(
    request_csv: Optional[UploadFile] = File(None),  
    region_type: str = Form(None),
    region_name: str = Form(None),
    L0: str = Form(None),
    L1: str = Form(None),
    L2: str = Form(None),
    L3: str = Form(None),
    sort_param: str = Form("num_qty_sold"),
    sort_type: str = Form("desc"),
    csv_flag: str = Form("recommended"),
    postgres_db=Depends(get_postgres_db),
):

    request_df = None
    if request_csv is not None:
        request_df = pd.read_csv(request_csv.file)
        if request_df.empty:
            return JSONResponse(
                content={"message": "Request data is empty."}, status_code=200
            )

    condition = build_condition(region_type, region_name, L0, L1, L2, L3)

    query = (
        select(
            AssortmentOutput.sap_id,
            AssortmentOutput.br_code,
            AssortmentOutput.item_name.label("Item Name"),
            Product.molecule,
            AssortmentOutput.total_amount,
            (case([(AssortmentOutput.total_amount != 0, func.round(cast((AssortmentOutput.total_margin / AssortmentOutput.total_amount) * 100, Numeric), 2))])
 ).label('margin_percentage'),
            AssortmentOutput.num_qty_sold.label("qty_sold"),
            AssortmentOutput.min_qty,
            AssortmentOutput.max_qty,
            AssortmentOutput.aiocd_sales_2022,
            AssortmentOutput.iqvia_revenue.label("iqvia_east_JanToJun2023"),
            AssortmentOutput.num_bounce_train.label("qty_bounce_train"),
            AssortmentOutput.num_bounce_test.label("qty_bounce_test"),
            AssortmentOutput.det_cogs_amt.label("br_cogs_amt"),
            AssortmentOutput.qty_sold_online,
            AssortmentOutput.L0,
            AssortmentOutput.L1,
            AssortmentOutput.L2,
            AssortmentOutput.L3,
            AssortmentOutput.br_code.label("Branch Code"),
            AssortmentOutput.num_qty_sold_train.label("qty_sold_train"),
            Product.mrp,
        )
        .select_from(AssortmentOutput)
        .join(Product, AssortmentOutput.sap_id == Product.sap_id)
    )

    # Dynamically adjust the order_by clause based on sorting_parameter and sorting_type
    if sort_param == "num_qty_sold":
        order_by_clause = (
            desc(AssortmentOutput.num_qty_sold)
            if sort_type == "desc"
            else asc(AssortmentOutput.num_qty_sold)
        )
    elif sort_param == "total_amount":
        order_by_clause = (
            desc(AssortmentOutput.total_amount)
            if sort_type == "desc"
            else asc(AssortmentOutput.total_amount)
        )
    elif sort_param == "total_margin":
        order_by_clause = (
            desc(AssortmentOutput.total_margin)
            if sort_type == "desc"
            else asc(AssortmentOutput.total_margin)
        )
    elif sort_param == "sap_id":
        order_by_clause = (
            desc(AssortmentOutput.sap_id)
            if sort_type == "desc"
            else asc(AssortmentOutput.sap_id)
        )
    elif sort_param == "item_name":
        order_by_clause = (
            desc(AssortmentOutput.item_name)
            if sort_type == "desc"
            else asc(AssortmentOutput.item_name)
        )
    elif sort_param == "min_qty":
        order_by_clause = (
            desc(AssortmentOutput.min_qty)
            if sort_type == "desc"
            else asc(AssortmentOutput.min_qty)
        )
    elif sort_param == "max_qty":
        order_by_clause = (
            desc(AssortmentOutput.max_qty)
            if sort_type == "desc"
            else asc(AssortmentOutput.max_qty)
        )
    elif sort_param == "mrp":
        order_by_clause = desc(Product.mrp) if sort_type == "desc" else asc(Product.mrp)
    elif sort_param == "num_stores_product_part_of_assortment":
        order_by_clause = (
            desc("num_stores_product_part_of_assortment")
            if sort_type == "desc"
            else asc("num_stores_product_part_of_assortment")
        )
    elif sort_param == "current_inventory":
        order_by_clause = (
            desc("current_inventory")
            if sort_type == "desc"
            else asc("current_inventory")
        )
    elif sort_param == "minimum_replenishment":
        order_by_clause = (
            desc("minimum_replenishment")
            if sort_type == "desc"
            else asc("minimum_replenishment")
        )
    elif sort_param == "molecule":
        order_by_clause = desc(Product.molecule) if sort_type == "desc" else asc(Product.molecule)
    else:
        order_by_clause = desc(AssortmentOutput.num_qty_sold)

    query = query.order_by(order_by_clause)

    # Hits
    if csv_flag == "hits":
        hit_condition = and_(
            *condition,
            AssortmentOutput.exist_in_model_output == 1,
            AssortmentOutput.is_sold == 1,
        )
        hit_query = query.where(hit_condition)

        hit_rows = await postgres_db.fetch_all(hit_query)
        result = [dict(rows) for rows in hit_rows]
        for hit in result:
            hit["total_amount"] = (
                round(hit["total_amount"], 2)
                if hit["total_amount"] is not None
                else None
            )
            hit["total_margin"] = (
                round(hit["total_margin"], 2)
                if hit["total_margin"] is not None
                else None
            )
            hit["br_cogs_amt"] = (
                round(hit["br_cogs_amt"], 2) if hit["br_cogs_amt"] is not None else None
            )

    # Misses
    elif csv_flag == "misses":
        miss_condition = and_(
            *condition,
            AssortmentOutput.exist_in_model_output == 0,
            AssortmentOutput.is_sold == 1,
        )
        miss_query = query.where(miss_condition)

        miss_rows = await postgres_db.fetch_all(miss_query)
        result = [dict(rows) for rows in miss_rows]
        for miss in result:
            miss["total_amount"] = (
                round(miss["total_amount"], 2)
                if miss["total_amount"] is not None
                else None
            )
            miss["total_margin"] = (
                round(miss["total_margin"], 2)
                if miss["total_margin"] is not None
                else None
            )
            miss["br_cogs_amt"] = (
                round(miss["br_cogs_amt"], 2)
                if miss["br_cogs_amt"] is not None
                else None
            )

    # Assortment
    else:
        assortment_condition = and_(
            *condition, AssortmentOutput.exist_in_model_output == 1
        )
        assortment_query = query.where(assortment_condition)

        assortment_rows = await postgres_db.fetch_all(assortment_query)
        result = [dict(rows) for rows in assortment_rows]
        for assort in result:
            assort["total_amount"] = (
                round(assort["total_amount"], 2)
                if assort["total_amount"] is not None
                else None
            )
            assort["margin_percentage"] = (
                round(assort["margin_percentage"], 2)
                if assort["margin_percentage"] is not None
                else None
            )
            assort["qty_sold_train"] = (
                round(assort["qty_sold_train"], 2)
                if assort["qty_sold_train"] is not None
                else None
            )
            assort["br_cogs_amt"] = (
                round(assort["br_cogs_amt"], 2)
                if assort["br_cogs_amt"] is not None
                else None
            )
    
    if request_df is not None:
        result_df = pd.DataFrame(result)
        print('request_df:', request_df.shape)
        print('result_df:', result_df.shape)
        if not result:
            return JSONResponse(content=[], status_code=200)
        merged_df = pd.merge(result_df, request_df, on=["sap_id", "br_code"], how="left")
        result = merged_df.to_dict(orient="records")   
        print('merged_df:', merged_df.shape) 

    if result:
        # Create a CSV string
        csv_content = StringIO()
        csv_writer = csv.DictWriter(csv_content, fieldnames=result[0].keys())
        csv_writer.writeheader()
        csv_writer.writerows(result)

        # Convert the CSV string to bytes
        csv_bytes = csv_content.getvalue().encode("utf-8")

        # Return the response as a streaming response with content type "text/csv"
        return StreamingResponse(
            iter([csv_bytes]),
            media_type="text/csv",
            headers={"Content-Disposition": "attachment;filename=response.csv"},
        )
    else:
        # If there are no rows, return an empty response
        return StreamingResponse(
            iter([]),
            media_type="text/csv",
            headers={"Content-Disposition": "attachment;filename=products.csv"},
        )

@prediction.post("/margin-buckets", operation_id="fetch-margin-buckets")  # done
async def fetch_margin_buckets(
    region_type: str = Form(None),
    region_name: str = Form(None),
    L0: str = Form(None),
    L1: str = Form(None),
    L2: str = Form(None),
    L3: str = Form(None),
    postgres_db=Depends(get_postgres_db),
):

    # Build the filter
    condition = build_condition(region_type, region_name, L0, L1, L2, L3)
    # Hits
    hit_condition = and_(
        *condition,
        AssortmentOutput.exist_in_model_output == 1,
        AssortmentOutput.is_sold == 1,
    )
    miss_condition = and_(
        *condition,
        AssortmentOutput.exist_in_model_output == 0,
        AssortmentOutput.is_sold == 1,
    )
    base_margin_query = select(
        [
            # Calculate the derived 'margin' column with a case statement to handle division by zero
            case(
                [
                    (
                        AssortmentOutput.total_amount - AssortmentOutput.total_margin
                        != 0,
                        (
                            AssortmentOutput.total_margin
                            / (
                                AssortmentOutput.total_amount
                                - AssortmentOutput.total_margin
                            )
                        )
                        * 100,
                    )
                ],
                else_=0,
            ).label("margin")
        ]
    )

    hit_query = base_margin_query.where(hit_condition)
    miss_query = base_margin_query.where(miss_condition)

    hit_ranges = await postgres_db.fetch_all(hit_query)
    miss_ranges = await postgres_db.fetch_all(miss_query)
    hit_bucket = defaultdict(int)
    miss_bucket = defaultdict(int)

    for row in hit_ranges:
        hit_bucket[math.ceil(row["margin"] / 5)] += 1
    for row in miss_ranges:
        miss_bucket[math.ceil(row["margin"] / 5)] += 1

    hit_bucket_list = []
    miss_bucket_list = []
    for bucket_index in range(21):
        hit_bucket_list.append(hit_bucket[bucket_index])
        miss_bucket_list.append(miss_bucket[bucket_index])

    return {"hit_bucket": hit_bucket_list, "miss_bucket": miss_bucket_list}

# Take a csv file with fields br_code, sap_id, min_qty, max_qty as column names
@prediction.post("/bulk-assortment", operation_id="fetch-bulk-assortment")
async def fetch_bulk_assortment(
    region_type: str = Form(None),
    region_name: str = Form(None),
    file: UploadFile = File(...),
    postgres_db=Depends(get_postgres_db),
):
    # read csv file
    csv_data = pd.read_csv(file.file)

    # get column names
    column_names = csv_data.columns.tolist()

    # get index of column name sap_id
    sap_id_index = column_names.index("sap_id")

    # get index of column name br_code
    # br_code_index = column_names.index("br_code")

    tuple_list = []
    # create  list of tuples of form (br_code, sap_id)
    # for index, row in csv_data.iterrows():
    #     tuple_list.append((row[br_code_index], row[sap_id_index]))
    for index, row in csv_data.iterrows():
        tuple_list.append(row[sap_id_index])

    region_conditions = []
    if region_type == "Zone":
        region_conditions.append(AssortmentOutput.zone == region_name)
    elif region_type == "State":
        region_conditions.append(AssortmentOutput.state == region_name)
    elif region_type == "City":
        region_conditions.append(AssortmentOutput.city == region_name)
    elif region_type == "Branch":
        region_conditions.append(AssortmentOutput.br_code == region_name)

    br_sap_conditions = [
        AssortmentOutput.sap_id == int(sap_id) for sap_id in tuple_list
    ]

    query = select(
        # AssortmentOutput.br_code,
        AssortmentOutput.sap_id,
        AssortmentOutput.item_name,
        # AssortmentOutput.total_amount,
        func.sum(AssortmentOutput.total_amount).label(
            "total_amount"
        ),  # Actual past sales
        func.sum(AssortmentOutput.total_margin).label(
            "total_margin"
        ),  # Actual past margin
        func.sum(AssortmentOutput.num_qty_sold).label("num_qty_sold"),
        func.sum(AssortmentOutput.total_amount_train).label("total_amount_train"),
        func.sum(AssortmentOutput.total_margin_train).label("total_margin_train"),
        func.sum(AssortmentOutput.num_qty_sold_train).label("num_qty_sold_train"),
        # AssortmentOutput.total_margin,    # Actual past margin
        # AssortmentOutput.num_qty_sold ,
        # AssortmentOutput.total_amount_train,
        # AssortmentOutput.total_margin_train,
        # AssortmentOutput.exist_in_model_output,
        # AssortmentOutput.is_sold,
    )
    query = query.group_by(
        AssortmentOutput.sap_id,
        AssortmentOutput.item_name,
    )
    if br_sap_conditions:
        query = query.filter(or_(*br_sap_conditions))

    if region_conditions:
        query = query.where(or_(*region_conditions))

    rows = await postgres_db.fetch_all(query)
    return rows

@prediction.post("/fetch-filters", operation_id="fetch-filters")   
async def fetch_filters(
    request_csv: Optional[UploadFile] = File(None),
    region_type: str = Form(None),
    region_name: str = Form(None),
    L0: str = Form(None),
    L1: str = Form(None),
    L2: str = Form(None),
    L3: str = Form(None),
    mfac_name: str = Form(None),
    brand_name: str = Form(None),
    postgres_db = Depends(get_postgres_db)
):

    request_df = None
    if request_csv is not None:
        request_df = pd.read_csv(request_csv.file)
        if request_df.empty:
            return JSONResponse(
                content={"message": "Request data is empty."}, status_code=200
            )
    else:
        cache_key = f"fetch-filters:{region_type}:{region_name}:{L0}:{L1}:{L2}:{L3}:{mfac_name}:{brand_name}"
        response =  await redis_db.get(cache_key)
        if response:
            print('Hit', cache_key)
            result = json.loads(response)
            return result
    
    condition = build_condition(region_type, region_name, L0, L1, L2, L3, mfac_name=mfac_name, brand=brand_name)

    query = select(
    [
        AssortmentOutput.br_code,
        AssortmentOutput.state,
        AssortmentOutput.city,
        AssortmentOutput.zone,
        AssortmentOutput.L0,
        AssortmentOutput.L1,
        AssortmentOutput.L2,
        AssortmentOutput.L3,
        AssortmentOutput.mfac_name,
        AssortmentOutput.brand_name,
        AssortmentOutput.sap_id
    ]
    ).where(and_(AssortmentOutput.exist_in_model_output == 1, *condition)).subquery()

    L0_query = select([query.c.L0, func.count(func.distinct(query.c.sap_id))]).group_by(query.c.L0)

    L1_query = select([query.c.L1, func.count(func.distinct(query.c.sap_id))]).group_by(query.c.L1)

    L2_query = select([query.c.L2, func.count(func.distinct(query.c.sap_id))]).group_by(query.c.L2)

    L3_query = select([query.c.L3, func.count(func.distinct(query.c.sap_id))]).group_by(query.c.L3)
    
    queries = [postgres_db.fetch_all(query) for query in [L0_query, L1_query, L2_query, L3_query, query]]

    result = await gather(*queries)

    L0_rows, L1_rows, L2_rows, L3_rows, rows = result

    filters_count = {
        'L0': {row[0]: row[1] for row in L0_rows},
        'L1': {row[0]: row[1] for row in L1_rows},
        'L2': {row[0]: row[1] for row in L2_rows},
        'L3': {row[0]: row[1] for row in L3_rows}
    }


    if request_df is not None:
        rows = [dict(row) for row in rows]
        result_df = pd.DataFrame(rows)
        if not result:
            return JSONResponse(content=[], status_code=200)
        # TODO: right join
        merged_df = pd.merge(result_df, request_df, on=["sap_id", "br_code"], how="left")

        # merged_df = merged_df[
        # ["br_code", "state", "city", "zone", "L0", "L1", "L2", "L3", "mfac_name", "brand_name"]
        # ].fillna({'br_code': 'NA', 'state': 'NA', 'city': 'NA', 'zone': 'NA', 'L0': 'NA', 'L1': 'NA', 'L2': 'NA', 'L3': 'NA', 'mfac_name': 'NA', 'brand_name': 'NA'})
        rows = merged_df.to_dict(orient="records")   


    # Organize data into a nested dictionary
    filters_data = defaultdict(lambda: defaultdict(lambda: defaultdict(lambda: defaultdict(dict))))

    for row in rows:
        br_code = row['br_code']
        state = row['state']
        city = row['city']
        zone = row['zone']
        local_L0 = row['L0']
        local_L1 = row['L1']
        local_L2 = row['L2']
        local_L3 = row['L3']
        mfac = row['mfac_name']
        brand = row['brand_name']

        filters_data['location'][zone][state][city][br_code] = {}
        filters_data['category'][local_L0][local_L1][local_L2][local_L3] = {}
        filters_data['mfac'][mfac][brand] = {}

    filters_data['filters_count'] = filters_count


    if request_csv is None:
        serialized_data = json.dumps(filters_data)
        await redis_db.set(cache_key, serialized_data)
        
    return filters_data

# API to search molecule from product table
@prediction.get("/molecule-autocomplete")
async def fetch_molecule(
    molecule: str = None,
    postgres_db = Depends(get_postgres_db)
):
    cache_key = f"molecule-autocomplete:{molecule}"
    response =  await redis_db.get(cache_key)
    if response:
        print('Hit', cache_key)
        result = json.loads(response)
        return result

    # do prefix search of molecule in product table
    query = select([Product.molecule]).where(Product.molecule.ilike(f'%{molecule}%')).distinct()
    rows = await postgres_db.fetch_all(query)
    result = [row[0] for row in rows]

    serialized_data = json.dumps(result)
    await redis_db.set(cache_key, serialized_data)
    return result
