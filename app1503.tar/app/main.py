import uvicorn
from routes import prediction, sales, manufacture, newproduct, L2L3, map, crud, store_assortment, custom_assortment
from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from fastapi.openapi.utils import get_openapi
from fastapi.security import OAuth2PasswordRequestForm
from contextlib import asynccontextmanager
from auth_commons.src.dependencies import UserDependency
from auth_commons.src.schemas import  Token
from db import PostgresDatabase
from utils import load_aiocd_analysis, load_assortment_output, load_product, load_store, load_bounce, load_orders, load_inventory, load_probability, load_aiocd_sales, load_iqvia_sales, load_msa_all_cats, load_new_store_assortment  # noqa: F401
from settings import settings

@asynccontextmanager
async def lifespan(app: FastAPI):
   
    print(
        "================================ Starting up ================================================="
    )
    app.state.db = PostgresDatabase(settings)
    app.state.db.create_tables()
    await app.state.db.connect()
    # await load_aiocd_analysis(postgres_db=app.state.db.database)
    # await load_assortment_output(postgres_db=app.state.db.database)
    # await load_product(postgres_db=app.state.db.database)
    # await load_store(postgres_db=app.state.db.database)
    # await load_bounce(postgres_db=app.state.db.database)
    # await load_orders(postgres_db=app.state.db.database)
    # await load_inventory(postgres_db=app.state.db.database)
    # await load_probability(postgres_db=app.state.db.database)
    # await load_aiocd_sales(postgres_db=app.state.db.database)
    # await load_iqvia_sales(postgres_db=app.state.db.database)
    # await load_msa_all_cats(postgres_db=app.state.db.database)
    # await load_new_store_assortment(postgres_db=app.state.db.database)



    # Add other startup items here
    print("Loading Completed !")
    yield

    print(
        "================================ Shutting down ================================================="
    )




app = FastAPI(
    title="assortment-api",
    docs_url="/docs",
    redoc_url=None,
    lifespan=lifespan,
    root_path='/assortment-backend'
)




def custom_openapi():
    if app.openapi_schema:
        return app.openapi_schema
    openapi_schema = get_openapi(
        title=app.title, version=app.version, routes=app.routes
    )
    app.openapi_schema = openapi_schema
    return app.openapi_schema


app.openapi = custom_openapi




# app.add_middleware(RedisMiddleware, redis_db=redis_db)
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)



  ### AUTHENTICATION MIDDLEWARE ###  

# Add it to auth directory to get JWT token (Login Router)

# user_dependency = UserDependency()
# app.add_middleware(AuthenticationMiddleware, user_dependency=user_dependency)

# @app.post(
#     "/auth/token", response_model=Token, summary="Authenticate via JWT Bearer scheme"
# )
# async def get_access_token(
#     request: Request, form_data: OAuth2PasswordRequestForm = Depends()
# ):
#     return await user_dependency.login_for_access_token(request, form_data)






@app.get("/")
async def home():
    return {"Welcome": "To Assortment Planning"}

app.include_router(prediction)
app.include_router(sales)
app.include_router(manufacture)
app.include_router(newproduct)
app.include_router(L2L3)
app.include_router(map)
app.include_router(crud)
app.include_router(store_assortment)
app.include_router(custom_assortment)


if __name__ == "__main__":
    uvicorn.run(app, host="0.0.0.0", port=8000)



