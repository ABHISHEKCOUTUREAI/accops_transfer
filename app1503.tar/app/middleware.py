from starlette.middleware.base import BaseHTTPMiddleware, RequestResponseEndpoint
from starlette.requests import Request
from starlette.responses import Response, StreamingResponse
from typing import Any, Coroutine


# Write redis middleware  to get and set data
class RedisMiddleware(BaseHTTPMiddleware):
    def __init__(self, app, redis_db):
        super().__init__(app)
        self.redis_db = redis_db
        self.excluded_paths = ['/couture/assortment/new-products-bounce-csv', '/couture/assortment/new-products-csv', '/couture/assortment/hit_and_miss', '/couture/assortment/hit-miss-csv', '/couture/assortment/probability-csv']
    async def dispatch(self, request: Request, call_next: RequestResponseEndpoint) -> Coroutine[Any, Any, Response]:
        print("Dispatching")
        path = request.scope['path']
        if path in self.excluded_paths:
            print(f"Skipping cache for excluded path: {path}")
            return await call_next(request)
        redis_db = self.redis_db
        form = await request.form()
        cache_key = f"{request.method}:{request.url}:{str(sorted(dict(form).items()))}"
        if await redis_db.get(cache_key) is not None:
            print("Found cache")
            result = (await redis_db.get(cache_key)).decode('utf-8')
            return StreamingResponse(content=result, media_type="application/json", headers={'Content-Type': 'application/json'})
        print("No cache found")
    
        res = await call_next(request)
        response_content =(b"".join([chunk async for chunk in res.body_iterator])).decode('utf-8')
        await redis_db.set(cache_key, response_content)
        return StreamingResponse(content=response_content, media_type="application/json", headers={'Content-Type': 'application/json'})
