import asyncio
import json
from collections import defaultdict

from db import psql_execute_multiple, psql_execute_single, redis_db
from models import (
    AjioBestSellersMonth,
    AjioBestSellersWeek,
    AjioBrickDetails,
    AjioDemographicDetails,
    AjioProductAttributes,
)
from sqlalchemy import Numeric, and_, cast, func, select
from static import indian_states, month_mapping, product_columns

from .common_utils import (
    build_filter_condition,
    construct_filtered_query,
    sort_and_paginate,
)


async def calculate_time_delta_week():
    cache_key = "min_max_bestseller_week"
    cached_data = await redis_db.get(cache_key)
    if not cached_data:
        week_query = select(func.max(AjioBestSellersWeek.week_of_year))
        week_result = await psql_execute_single(week_query)
        max_week = week_result[0][0]

        # Query to select the minimum week from the database
        min_week_query = select(func.min(AjioBestSellersWeek.week_of_year))
        min_week_result = await psql_execute_single(min_week_query)
        min_week = min_week_result[0][0]

        await redis_db.set(cache_key, json.dumps([min_week, max_week]))

    print("time-delta loaded")


async def filter_values(result, index):
    values = list({val[index] for val in result if val[index] not in ["nan", None]})
    return sorted(values)


async def create_duration_filters_response(request_data):
    if request_data.get("nested_data", {}).get("duration", {}).get("week"):
        duration_filter_flag = "bestsellers_week"
    else:
        duration_filter_flag = "bestsellers_month"

    duration_filter = await build_filter_condition(
        request_filters=request_data, filter_flag=duration_filter_flag, type="ajio"
    )

    if request_data.get("nested_data", {}).get("duration", {}).get("week"):
        duration_query = (
            select(
                AjioBestSellersWeek.week_of_year,
            )
            .distinct()
            .where(and_(*duration_filter))
        )
    else:
        duration_query = (
            select(
                AjioBestSellersMonth.month_of_year,
            )
            .distinct()
            .where(and_(*duration_filter))
        )

    result = await psql_execute_single(duration_query)

    cache_key_min_max = "min_max_bestseller_week"
    min_max_week = await redis_db.get(cache_key_min_max)
    if min_max_week:
        min_week, max_week = json.loads(min_max_week)
    else:
        await calculate_time_delta_week()
        min_max_week = await redis_db.get(cache_key_min_max)
        min_week, max_week = json.loads(min_max_week)

    if request_data.get("nested_data", {}).get("duration", {}).get("week"):
        return {
            "duration": {
                "month": [],
                "week": list(range(min_week, max_week + 1)),
            }
        }
    else:
        # Sort the month values before mapping them
        sorted_month_values = sorted(
            set(val[0] for val in result if val[0] not in ["nan", None])
        )

        # Map the sorted month values
        mapped_month_values = [month_mapping[month] for month in sorted_month_values]
        return {
            "duration": {
                "month": mapped_month_values,
                "week": list(range(min_week, max_week + 1)),
            }
        }


async def create_demography_filters_response(nested_data):
    demographic_filter = await build_filter_condition(
        request_filters=nested_data, filter_flag="demographic"
    )

    demographic_query = select(
        AjioDemographicDetails.zone,
        AjioDemographicDetails.state,
        AjioDemographicDetails.city,
        AjioDemographicDetails.districtsname,
    ).where(and_(*demographic_filter))

    result = await psql_execute_single(demographic_query)

    return {
        "demographic": {
            "zone": await filter_values(result, 0),
            "state": await filter_values(result, 1),
            "city": await filter_values(result, 2),
            "district": await filter_values(result, 3),
        }
    }


async def create_brick_filters_query(nested_data):
    brick_filter = await build_filter_condition(
        request_filters=nested_data, filter_flag="brick"
    )
    brick_query = select(
        AjioBrickDetails.l1name,
        AjioBrickDetails.l2name,
        AjioBrickDetails.brickname,
    ).where(and_(*brick_filter))

    result = await psql_execute_single(brick_query)

    return {
        "brick_filters": {
            "l1_name": await filter_values(result, 0),
            "l2_name": await filter_values(result, 1),
            "brick_name": await filter_values(result, 2),
        }
    }


async def create_attributes_filters_query(nested_data):
    product_filter = await build_filter_condition(
        request_filters=nested_data, filter_flag="products"
    )
    brick_filter = await build_filter_condition(
        request_filters=nested_data, filter_flag="brick"
    )

    query_list = []

    for column in product_columns:
        query = (
            select(getattr(AjioProductAttributes, column))
            .join(
                AjioBrickDetails,
                AjioBrickDetails.similargrouplevel
                == AjioProductAttributes.similargrouplevel,
            )
            .distinct()
            .where(and_(*product_filter, *brick_filter))
        )
        query_list.append(query)

    results = await psql_execute_multiple(query_list)

    final_result = {"attributes": defaultdict(list)}
    for idx, result in enumerate(results):
        final_result["attributes"][product_columns[idx]] = []
        for val in result:
            if val[0] not in ["nan", None]:
                final_result["attributes"][product_columns[idx]].append(val[0])

    return final_result

    # return {"attributes": attributes}


async def create_brand_filter_response():
    brand_query = select(
        AjioProductAttributes.brandname,
    ).distinct()

    result = await psql_execute_single(brand_query)
    response = {
        "brandname": {
            "brandname": [row[0] for row in result if row[0] not in ["nan", None]]
        }
    }
    return response


async def get_ajio_filters_service(request_data: dict):
    nested_data = request_data.get("nested_data", {})

    if "duration" in nested_data and nested_data["duration"]:
        result = await create_duration_filters_response(request_data)
    elif "demographic" in nested_data and nested_data["demographic"]:
        result = await create_demography_filters_response(request_data)
    elif "attributes" in nested_data and nested_data["attributes"]:
        result = await create_attributes_filters_query(request_data)
    elif "brick_filters" in nested_data and nested_data["brick_filters"]:
        result = await create_brick_filters_query(request_data)
    elif "brandname" in nested_data:
        result = await create_brand_filter_response()

    return result


# bestseller count utils


async def get_ajio_bestseller_count(request_data: dict):
    if request_data.get("nested_data", {}).get("duration", {}).get("week"):
        bestseller_filter = await build_filter_condition(
            request_filters=request_data, filter_flag="bestsellers_week", type="ajio"
        )
        bestseller_query = await construct_filtered_query(
            AjioBestSellersWeek,
            bestseller_filter,
            ["productid" "districtsname"],
        )
    else:
        bestseller_filter = await build_filter_condition(
            request_filters=request_data, filter_flag="bestsellers_month", type="ajio"
        )
        bestseller_query = await construct_filtered_query(
            AjioBestSellersMonth, bestseller_filter, ["productid", "districtsname"]
        )

    demographic_query = await build_filter_condition(
        request_filters=request_data, filter_flag="demographic"
    )
    demographic_query = await construct_filtered_query(
        AjioDemographicDetails,
        demographic_query,
        ["districtsname"],
    )

    product_filter = await build_filter_condition(
        request_filters=request_data, filter_flag="products"
    )
    product_query = await construct_filtered_query(
        AjioProductAttributes,
        product_filter,
        ["productid", "similargrouplevel"],
    )

    brick_filter = await build_filter_condition(
        request_filters=request_data, filter_flag="brick"
    )
    brick_query = await construct_filtered_query(
        AjioBrickDetails, brick_filter, ["similargrouplevel"]
    )

    query = (
        select(
            bestseller_query.c.productid,
        )
        .select_from(bestseller_query)
        .join(
            demographic_query,
            demographic_query.c.districtsname == bestseller_query.c.districtsname,
        )
        .join(
            product_query,
            product_query.c.productid == bestseller_query.c.productid,
        )
        .join(
            brick_query,
            brick_query.c.similargrouplevel == product_query.c.similargrouplevel,
        )
        .group_by(bestseller_query.c.productid)
    )

    count_query = select(func.count()).select_from(query)

    result = await psql_execute_single(count_query)
    return {"total_count": result[0][0]}


# bestseller utils


async def create_ajio_ros_query(bestseller_query, demographic_query, metadata):
    ros_query = (
        select(
            bestseller_query.c.productid,
            getattr(bestseller_query.c, metadata["duration_col"]),
            bestseller_query.c.year,
            func.sum(getattr(bestseller_query.c, metadata["sold_quantity_col"])).label(
                metadata["sold_quantity_col"]
            ),
            func.avg(
                getattr(bestseller_query.c, metadata["healthy_live_days_col"])
            ).label(metadata["healthy_live_days_col"]),
        )
        .join(
            demographic_query,
            demographic_query.c.districtsname == bestseller_query.c.districtsname,
        )
        .group_by(
            bestseller_query.c.productid,
            getattr(bestseller_query.c, metadata["duration_col"]),
            bestseller_query.c.year,
        )
        .cte()
    )

    ros_query = (
        select(
            ros_query.c.productid,
            ros_query.c.year,
            func.sum(ros_query.c[metadata["sold_quantity_col"]]).label(
                "total_sold_quantity"
            ),
            func.round(
                cast(
                    (
                        (
                            func.sum(ros_query.c[metadata["sold_quantity_col"]])
                            / func.sum(ros_query.c[metadata["healthy_live_days_col"]])
                        )
                        * 7
                    ),
                    Numeric,
                ),
                2,
            ).label("weekly_rate_of_sale"),
        )
        .group_by(ros_query.c.productid, ros_query.c.year)
        .cte()
    )

    return ros_query


async def create_ajio_bestseller_query(request_data: dict):
    if request_data.get("nested_data", {}).get("duration", {}).get("week"):
        metadata = {
            "model": AjioBestSellersWeek,
            "filter_flag": "bestsellers_week",
            "duration_col": "week_of_year",
            "sold_quantity_col": "sold_quantity_in_a_week",
            "healthy_live_days_col": "healthy_live_days_in_a_week",
        }
    else:
        metadata = {
            "model": AjioBestSellersMonth,
            "filter_flag": "bestsellers_month",
            "duration_col": "month_of_year",
            "sold_quantity_col": "sold_quantity_in_a_month",
            "healthy_live_days_col": "healthy_live_days_in_a_month",
        }

    bestseller_filter = await build_filter_condition(
        request_filters=request_data, filter_flag=metadata["filter_flag"], type="ajio"
    )
    bestseller_columns = [
        "productid",
        metadata["duration_col"],
        "year",
        metadata["sold_quantity_col"],
        "districtsname",
        metadata["healthy_live_days_col"],
    ]
    bestseller_query = await construct_filtered_query(
        metadata["model"], bestseller_filter, bestseller_columns
    )

    demographic_filter = await build_filter_condition(
        request_filters=request_data, filter_flag="demographic"
    )
    demographic_query = await construct_filtered_query(
        AjioDemographicDetails, demographic_filter, ["districtsname"]
    )

    ros_query = await create_ajio_ros_query(
        bestseller_query, demographic_query, metadata
    )

    product_filter = await build_filter_condition(
        request_filters=request_data, filter_flag="products"
    )
    product_columns = [
        "productid",
        "similargrouplevel",
        "title",
        "brandname",
        "imgcode",
        "styletype",
        "colorfamily",
        "pattern",
        "neckline",
        "mrp",
    ]
    product_query = await construct_filtered_query(
        AjioProductAttributes, product_filter, product_columns
    )

    brick_filter = await build_filter_condition(
        request_filters=request_data, filter_flag="brick"
    )
    brick_columns = [
        "similargrouplevel",
        "l1name",
        "l2name",
        "brickname",
    ]
    brick_query = await construct_filtered_query(
        AjioBrickDetails, brick_filter, brick_columns
    )

    query = (
        select(
            product_query.c.productid,
            product_query.c.title,
            product_query.c.brandname,
            product_query.c.imgcode,
            product_query.c.styletype,
            product_query.c.colorfamily,
            product_query.c.pattern,
            product_query.c.neckline,
            brick_query.c.l1name,
            brick_query.c.l2name,
            brick_query.c.brickname,
            ros_query.c.total_sold_quantity,
            product_query.c.mrp,
            ros_query.c.weekly_rate_of_sale,
        )
        .join(ros_query, ros_query.c.productid == product_query.c.productid)
        .join(
            brick_query,
            brick_query.c.similargrouplevel == product_query.c.similargrouplevel,
        )
    )

    return query


async def get_ajio_bestseller_service(
    request_data: dict,
):
    bestseller_query = await create_ajio_bestseller_query(request_data)

    paginated_bestseller_query = await sort_and_paginate(
        bestseller_query, request_data, default_sort_param="weekly_rate_of_sale"
    )

    # try:
    result = await psql_execute_single(paginated_bestseller_query)

    result = {
        "rows": [
            {
                "productid": row[0],
                "title": row[1],
                "brandname": row[2],
                "imgcode": row[3],
                "styletype": row[4],
                "colorfamily": row[5],
                "pattern": row[6],
                "neckline": row[7],
                "l1name": row[8],
                "l2name": row[9],
                "brickname": row[10],
                "total_qty_sold": int(row[11]),
                "mrp": row[12],
                "weekly_rate_of_sale": int(row[13]),
            }
            for row in result
        ],
    }

    return result


# attributes utils
async def get_attributes_bestsellers_ajio(request_data, attribute: str):
    # Determine which schema to use based on the presence of 'week' in the request data
    if request_data.get("nested_data", {}).get("duration", {}).get("week"):
        duration_filter_flag = "bestsellers_week"
        best_sellers_schema = AjioBestSellersWeek
        quantity_column = AjioBestSellersWeek.sold_quantity_in_a_week
    else:
        duration_filter_flag = "bestsellers_month"
        best_sellers_schema = AjioBestSellersMonth
        quantity_column = AjioBestSellersMonth.sold_quantity_in_a_month

    (
        product_filter,
        brick_filter,
        demographic_filter,
        bestseller_filter,
    ) = await asyncio.gather(
        build_filter_condition(request_filters=request_data, filter_flag="products"),
        build_filter_condition(request_filters=request_data, filter_flag="brick"),
        build_filter_condition(request_filters=request_data, filter_flag="demographic"),
        build_filter_condition(
            request_filters=request_data, filter_flag=duration_filter_flag, type="ajio"
        ),
    )

    sold_in_week_query = (
        select(
            quantity_column.label("quantity_column"),
            best_sellers_schema.productid,
            best_sellers_schema.districtsname,
        )
        .where(and_(*bestseller_filter))
        .subquery()
    )

    product_query = (
        select(
            AjioProductAttributes.__dict__[attribute],
            AjioProductAttributes.productid,
            AjioProductAttributes.similargrouplevel,
        )
        .where(
            and_(*product_filter, AjioProductAttributes.__dict__[attribute].isnot(None))
        )
        .subquery()
    )

    brick_query = (
        select(AjioBrickDetails.brickname, AjioBrickDetails.similargrouplevel)
        .where(and_(*brick_filter))
        .subquery()
    )

    demographic_query = (
        select(
            AjioDemographicDetails.districtsname,
        )
        .where(and_(*demographic_filter))
        .subquery()
    )

    query = (
        select(
            product_query.c[attribute],
            brick_query.c.brickname,
            func.sum(sold_in_week_query.c.quantity_column).label("quantity"),
        )
        .join(
            brick_query,
            product_query.c.similargrouplevel == brick_query.c.similargrouplevel,
        )
        .join(
            sold_in_week_query,
            product_query.c.productid == sold_in_week_query.c.productid,
        )
        .join(
            demographic_query,
            demographic_query.c.districtsname == sold_in_week_query.c.districtsname,
        )
        .group_by(
            product_query.c[attribute],
            brick_query.c.brickname,
        )
        .order_by(func.sum(sold_in_week_query.c.quantity_column).desc())
    )

    rows = await psql_execute_single(query)

    result = defaultdict(dict)
    for row in rows:
        if row[0] and row[0] != "nan":
            result[row[1]][row[0]] = float(row[2])

    return result


# statewise sales ajio
async def get_statewise_sales_ajio(request_data: dict):
    # Determine which schema to use based on the presence of 'week' in the request data
    if request_data.get("nested_data", {}).get("duration", {}).get("week"):
        best_sellers_schema = AjioBestSellersWeek
        quantity_column = AjioBestSellersWeek.sold_quantity_in_a_week
    else:
        best_sellers_schema = AjioBestSellersMonth
        quantity_column = AjioBestSellersMonth.sold_quantity_in_a_month

    # Now, use the selected schema in your query
    sold_in_week_query = (
        select(
            AjioDemographicDetails.state,
            func.sum(quantity_column).label("quantity"),
        )
        .join(
            AjioDemographicDetails,
            AjioDemographicDetails.districtsname == best_sellers_schema.districtsname,
        )
        .group_by(
            AjioDemographicDetails.state,
        )
    )

    maps_rows_state = await psql_execute_single(sold_in_week_query)

    map_data = [
        {
            "state": row[0],
            "statecode": indian_states.get(row[0].lower(), {}).get(
                "statecode", "Not Found"
            ),
            "quantity_sold": row[1],
        }
        for row in maps_rows_state
    ]

    return map_data
