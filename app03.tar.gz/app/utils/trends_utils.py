import asyncio
import json
from collections import defaultdict

from db import psql_execute_multiple, psql_execute_single, redis_db
from models import (
    TrendsBestSellersMonth,
    TrendsBestSellersWeek,
    TrendsBrickDetails,
    TrendsProductAttributes,
    TrendsStoreDetails,
)
from sqlalchemy import Numeric, and_, cast, func, select
from static import month_mapping

from .common_utils import (
    build_filter_condition,
    sort_and_paginate,
)

# filters utils


async def get_initial_filter_data_trends():
    # get all distinct month from the database
    month_query = select(TrendsBestSellersMonth.month_of_year).distinct()
    month_result = await psql_execute_single(month_query)
    # Sort the month values before mapping them
    sorted_month_values = sorted(
        set(val[0] for val in month_result if val[0] not in ["nan", None])
    )

    # Map the sorted month values
    mapped_month_values = [month_mapping[month] for month in sorted_month_values]

    result = {
        "demographic": {
            "zone_desc": [],
            "state": [],
            "city": [],
            "district": [],
        },
        "category": {
            "category_family": [],
            "category_class": [],
            "category": [],
        },
        "attributes": {
            "styletype": [],
            "brandname": [],
            "fabric_type": [],
            "neckline": [],
            "pattern": [],
            "sleeve": [],
            "fit": [],
            "color": [],
        },
        "duration": {
            "month": mapped_month_values,
            "week": [],
        },
        "store_filters": {
            "pincode": [],
            "store_id": [],
        },
    }
    return result


async def determine_filter_type_trends(nested_data):
    if "duration" in nested_data and nested_data["duration"]:
        return "duration"
    elif "demographic" in nested_data and nested_data["demographic"]:
        return "demography"
    elif "store_filters" in nested_data and nested_data["store_filters"]:
        return "store_filters"
    elif "attributes" in nested_data and nested_data["attributes"]:
        return "attributes"
    elif "category" in nested_data and nested_data["category"]:
        return "category"
    return None


def filter_non_null(result, index):
    values = list(
        set(
            val[index]
            for val in result
            if val[index] != "nan" and val[index] is not None
        )
    )
    return sorted(values)


async def calculate_time_delta_week_trends():
    cache_key = "min_max_bestseller_week_trends"
    cached_data = await redis_db.get(cache_key)
    if not cached_data:
        week_query = select(func.max(TrendsBestSellersWeek.week_of_year))
        week_result = await psql_execute_single(week_query)
        max_week = week_result[0][0]

        # Query to select the minimum week from the database
        min_week_query = select(func.min(TrendsBestSellersWeek.week_of_year))
        min_week_result = await psql_execute_single(min_week_query)
        min_week = min_week_result[0][0]

        await redis_db.set(cache_key, json.dumps([min_week, max_week]))

    print("time-delta loaded")


async def create_duration_filter_response_trends(request_data):
    # Determine the appropriate filter flag based on the presence of 'week' in the request data
    if request_data.get("nested_data", {}).get("duration", {}).get("week"):
        duration_filter_flag = "bestsellers_week"
    else:
        duration_filter_flag = "bestsellers_month"

    duration_filter = await build_filter_condition(
        type="trends",
        request_filters=request_data,
        filter_flag=duration_filter_flag,
    )

    if request_data.get("nested_data", {}).get("duration", {}).get("week"):
        duration_query = (
            select(TrendsBestSellersWeek.week_of_year)
            .distinct()
            .where(and_(*duration_filter))
        )
    else:
        duration_query = (
            select(TrendsBestSellersMonth.month_of_year)
            .distinct()
            .where(and_(*duration_filter))
        )

    duration_result = await psql_execute_single(duration_query)

    cache_key_min_max = "min_max_bestseller_week_trends"
    min_max_week = await redis_db.get(cache_key_min_max)
    if min_max_week:
        min_week, max_week = json.loads(min_max_week)
    else:
        await calculate_time_delta_week_trends()
        min_max_week = await redis_db.get(cache_key_min_max)
        min_week, max_week = json.loads(min_max_week)

    if request_data.get("nested_data", {}).get("duration", {}).get("week"):
        return {
            "duration": {
                "months": [],
                "week": list(range(min_week, max_week + 1)),
            }
        }
    else:
        # Sort the month values before mapping them
        sorted_month_values = sorted(
            set(val[0] for val in duration_result if val[0] not in ["nan", None])
        )

        # Map the sorted month values
        mapped_month_values = [month_mapping[month] for month in sorted_month_values]
        return {
            "duration": {
                "month": mapped_month_values,
                "week": list(range(min_week, max_week + 1)),
            }
        }


async def create_demographic_filter_response_trends(request_data):
    demographic_filter = await build_filter_condition(
        type="trends", request_filters=request_data, filter_flag="store_filters"
    )

    demographic_query = select(
        TrendsStoreDetails.zone_desc,
        TrendsStoreDetails.state,
        TrendsStoreDetails.city,
        TrendsStoreDetails.districtsname,
    ).where(and_(*demographic_filter))

    demographic_result = await psql_execute_single(demographic_query)

    return {
        "demographic": {
            "zone_desc": filter_non_null(demographic_result, 0),
            "state": filter_non_null(demographic_result, 1),
            "city": filter_non_null(demographic_result, 2),
            "district": filter_non_null(demographic_result, 3),
        }
    }


async def create_store_filter_response_trends(request_data):
    store_filter = await build_filter_condition(
        type="trends", request_filters=request_data, filter_flag="category"
    )

    store_query = select(
        TrendsStoreDetails.pin_code,
        TrendsStoreDetails.store_id,
    ).where(and_(*store_filter))

    store_result = await psql_execute_single(store_query)

    return {
        "store_filters": {
            "pincode": filter_non_null(store_result, 0),
            "store_id": filter_non_null(store_result, 1),
        }
    }


async def create_attributes_filter_response_trends(request_data):
    attribute_filter = await build_filter_condition(
        type="trends", request_filters=request_data, filter_flag="products"
    )

    attribute_query = select(
        TrendsProductAttributes.styletype,
        TrendsProductAttributes.neckline,
        TrendsProductAttributes.pattern,
        TrendsProductAttributes.fabrictype,
        TrendsProductAttributes.sleeve,
        TrendsProductAttributes.fit,
        TrendsProductAttributes.primarycolor,
        TrendsProductAttributes.brandname,
    ).where(and_(*attribute_filter))

    attribute_result = await psql_execute_single(attribute_query)

    return {
        "attributes": {
            "styletype": filter_non_null(attribute_result, 0),
            "neckline": filter_non_null(attribute_result, 1),
            "pattern": filter_non_null(attribute_result, 2),
            "fabric_type": filter_non_null(attribute_result, 3),
            "sleeve": filter_non_null(attribute_result, 4),
            "fit": filter_non_null(attribute_result, 5),
            "color": filter_non_null(attribute_result, 6),
            "brandname": filter_non_null(attribute_result, 7),
        }
    }


async def create_category_filter_response_trends(request_data):
    category_filter = await build_filter_condition(
        type="trends", request_filters=request_data, filter_flag="category"
    )

    category_query = select(
        TrendsBrickDetails.mh_family_desc,
        TrendsBrickDetails.mh_class_desc,
        TrendsBrickDetails.brickname,
    ).where(and_(*category_filter))

    category_result = await psql_execute_single(category_query)

    return {
        "category": {
            "category_family": filter_non_null(category_result, 0),
            "category_class": filter_non_null(category_result, 1),
            "category": filter_non_null(category_result, 2),
        }
    }


async def create_trends_filters_response(request_data):
    filter_type = await determine_filter_type_trends(
        request_data.get("nested_data", {})
    )

    if filter_type == "duration":
        result = await create_duration_filter_response_trends(request_data)
    elif filter_type == "demography":
        result = await create_demographic_filter_response_trends(request_data)
    elif filter_type == "store_filters":
        result = await create_store_filter_response_trends(request_data)
    elif filter_type == "attributes":
        result = await create_attributes_filter_response_trends(request_data)
    elif filter_type == "category":
        result = await create_category_filter_response_trends(request_data)
    else:
        result = {}

    return result


async def get_trends_filters_service(
    request_data: dict,
    caching_flag: bool = False,
):
    # Check if the "month" list is empty
    if request_data.get("nested_data", {}).get("duration", {}).get("month") == []:
        response = await get_initial_filter_data_trends()
    else:
        response = await create_trends_filters_response(request_data)

    if caching_flag:
        print("Trends filters loaded successfully")
    else:
        return response


# attrtibutes utils


async def get_attributes_bestsellers_trends(request_data, attribute: str):
    # Determine which schema to use based on the presence of "week" in the request data
    if request_data.get("nested_data", {}).get("duration", {}).get("week"):
        duration_filter_flag = "bestsellers_week"
        best_sellers_schema = TrendsBestSellersWeek
        quantity_column = TrendsBestSellersWeek.sold_quantity_in_a_week
    else:
        duration_filter_flag = "bestsellers_month"
        best_sellers_schema = TrendsBestSellersMonth
        quantity_column = TrendsBestSellersMonth.sold_quantity_in_a_month

    (
        product_filter,
        brick_filter,
        duration_filter,
        demographic_filter,
    ) = await asyncio.gather(
        build_filter_condition(
            type="trends", request_filters=request_data, filter_flag="products"
        ),
        build_filter_condition(
            type="trends", request_filters=request_data, filter_flag="category"
        ),
        build_filter_condition(
            type="trends",
            request_filters=request_data,
            filter_flag=duration_filter_flag,
        ),
        build_filter_condition(
            type="trends", request_filters=request_data, filter_flag="store_filters"
        ),
    )

    product_query = (
        select(
            getattr(TrendsProductAttributes, attribute),
            TrendsProductAttributes.itemid,
            TrendsProductAttributes.similargrouplevel,
        )
        .where(
            and_(
                *product_filter, getattr(TrendsProductAttributes, attribute) is not None
            )
        )
        .subquery()
    )

    brick_query = (
        select(TrendsBrickDetails.brickname, TrendsBrickDetails.similargrouplevel)
        .where(and_(*brick_filter))
        .subquery()
    )

    sold_in_week_query = (
        select(
            quantity_column.label("quantity_column"),
            best_sellers_schema.itemid,
            best_sellers_schema.store_id,
        )
        .where(and_(*duration_filter))
        .subquery()
    )

    store_query = (
        select(
            TrendsStoreDetails.store_id,
        )
        .where(and_(*demographic_filter))
        .subquery()
    )

    # join all three queries
    query = (
        select(
            getattr(product_query.c, attribute),
            brick_query.c.brickname,
            func.sum(sold_in_week_query.c.quantity_column).label("quantity"),
        )
        .join(
            brick_query,
            product_query.c.similargrouplevel == brick_query.c.similargrouplevel,
        )
        .join(sold_in_week_query, product_query.c.itemid == sold_in_week_query.c.itemid)
        .join(store_query, sold_in_week_query.c.store_id == store_query.c.store_id)
        .group_by(
            getattr(product_query.c, attribute),
            brick_query.c.brickname,
        )
        .order_by(func.sum(sold_in_week_query.c.quantity_column).desc())
    )

    rows = await psql_execute_single(query)
    result = defaultdict(dict)
    for row in rows:
        if row[0] and row[0] != "nan":
            result[row[1]][row[0]] = float(row[2])

    return result


# bestsellers utils


async def get_trends_bestseller_week_level(request_data: dict):
    (
        bestseller_filter,
        product_filter,
        store_filter,
        brick_filter,
    ) = await asyncio.gather(
        build_filter_condition(
            type="trends", request_filters=request_data, filter_flag="bestsellers_week"
        ),
        build_filter_condition(
            type="trends", request_filters=request_data, filter_flag="products"
        ),
        build_filter_condition(
            type="trends", request_filters=request_data, filter_flag="store_filters"
        ),
        build_filter_condition(
            type="trends", request_filters=request_data, filter_flag="category"
        ),
    )

    bestseller_query = (
        select(
            TrendsBestSellersWeek.itemid,
            TrendsBestSellersWeek.week_of_year,
            TrendsBestSellersWeek.year,
            TrendsBestSellersWeek.store_id,
            TrendsBestSellersWeek.sold_quantity_in_a_week,
            TrendsBestSellersWeek.healthy_live_days_in_a_week,
        )
        .where(and_(*bestseller_filter))
        .subquery()
    )

    store_query = (
        select(
            TrendsStoreDetails.store_id,
        )
        .where(and_(*store_filter))
        .subquery()
    )

    ros_query = (
        select(
            bestseller_query.c.itemid,
            bestseller_query.c.week_of_year,
            bestseller_query.c.year,
            func.sum(bestseller_query.c.sold_quantity_in_a_week).label(
                "sold_quantity_across_each_week"
            ),
            func.avg(bestseller_query.c.healthy_live_days_in_a_week).label(
                "total_days_count_across_week"
            ),
        )
        .join(store_query, store_query.c.store_id == bestseller_query.c.store_id)
        .group_by(
            bestseller_query.c.itemid,
            bestseller_query.c.week_of_year,
            bestseller_query.c.year,
        )
        .subquery()
    )

    ros_query = (
        select(
            ros_query.c.itemid,
            ros_query.c.year,
            func.sum(ros_query.c.sold_quantity_across_each_week).label(
                "total_sold_quantity"
            ),
            func.sum(ros_query.c.total_days_count_across_week).label(
                "total_active_days"
            ),
            func.round(
                cast(
                    (
                        (
                            func.sum(ros_query.c.sold_quantity_across_each_week)
                            / func.sum(ros_query.c.total_days_count_across_week)
                        )
                        * 7
                    ),
                    Numeric,
                ),
                2,
            ).label("weekly_rate_of_sale"),
        )
        .group_by(ros_query.c.itemid, ros_query.c.year)
        .subquery()
    )

    product_query = (
        select(
            TrendsProductAttributes.itemid,
            TrendsProductAttributes.brandname,
            TrendsProductAttributes.styletype,
            TrendsProductAttributes.primarycolor,
            TrendsProductAttributes.pattern,
            TrendsProductAttributes.fabrictype,
            TrendsProductAttributes.materialtype,
            TrendsProductAttributes.sleeve,
            TrendsProductAttributes.fit,
            TrendsProductAttributes.neckline,
            TrendsProductAttributes.imgcode,
            TrendsProductAttributes.extension,
            TrendsProductAttributes.mrp,
            TrendsProductAttributes.similargrouplevel,
        )
        .where(and_(*product_filter))
        .subquery()
    )

    brick_query = (
        select(
            TrendsBrickDetails.mh_family_desc,
            TrendsBrickDetails.mh_class_desc,
            TrendsBrickDetails.brickname,
            TrendsBrickDetails.similargrouplevel,
        )
        .where(and_(*brick_filter))
        .subquery()
    )

    query = (
        select(
            product_query.c.itemid,
            product_query.c.brandname,
            product_query.c.styletype,
            product_query.c.primarycolor,
            product_query.c.pattern,
            product_query.c.fabrictype,
            product_query.c.materialtype,
            product_query.c.sleeve,
            product_query.c.fit,
            product_query.c.neckline,
            product_query.c.imgcode,
            product_query.c.extension,
            brick_query.c.mh_family_desc,
            brick_query.c.mh_class_desc,
            brick_query.c.brickname,
            product_query.c.mrp,
            ros_query.c.total_sold_quantity,
            ros_query.c.weekly_rate_of_sale,
            ros_query.c.total_active_days,
        )
        .join(ros_query, ros_query.c.itemid == product_query.c.itemid)
        .join(
            brick_query,
            brick_query.c.similargrouplevel == product_query.c.similargrouplevel,
        )
    )
    # count the total number of rows
    total_count_query = select(func.count()).select_from(query)
    bestseller_query = await sort_and_paginate(
        query, request_data, "weekly_rate_of_sale"
    )

    query_list = [bestseller_query, total_count_query]

    result = await psql_execute_multiple(query_list)
    result = {
        "total_count": result[1][0][0],
        "rows": [
            {
                "itemid": row[0],
                "brandname": row[1],
                "styletype": row[2],
                "primarycolor": row[3],
                "pattern": row[4],
                "fabrictype": row[5],
                "materialtype": row[6],
                "sleeve": row[7],
                "fit": row[8],
                "neckline": row[9],
                "imgcode": row[10],
                "extension": row[11],
                "mh_family_desc": row[12],
                "mh_class_desc": row[13],
                "brickname": row[14],
                "mrp": round(float(row[15]), 2),
                "total_qty": int(row[16]),
                "weekly_rate_of_sale": int(row[17]),
                "total_active_days": round(row[18], 2),
            }
            for row in result[0]
        ],
    }
    return result


async def get_trends_bestseller_month_level(request_data: dict):
    (
        bestseller_filter,
        product_filter,
        store_filter,
        brick_filter,
    ) = await asyncio.gather(
        build_filter_condition(
            type="trends", request_filters=request_data, filter_flag="bestsellers_month"
        ),
        build_filter_condition(
            type="trends", request_filters=request_data, filter_flag="products"
        ),
        build_filter_condition(
            type="trends", request_filters=request_data, filter_flag="store_filters"
        ),
        build_filter_condition(
            type="trends", request_filters=request_data, filter_flag="category"
        ),
    )

    bestseller_query = (
        select(
            TrendsBestSellersMonth.itemid,
            TrendsBestSellersMonth.month_of_year,
            TrendsBestSellersMonth.year,
            TrendsBestSellersMonth.store_id,
            TrendsBestSellersMonth.sold_quantity_in_a_month,
            TrendsBestSellersMonth.healthy_live_days_in_a_month,
        )
        .where(and_(*bestseller_filter))
        .subquery()
    )

    store_query = (
        select(
            TrendsStoreDetails.store_id,
        )
        .where(and_(*store_filter))
        .subquery()
    )

    ros_query = (
        select(
            bestseller_query.c.itemid,
            bestseller_query.c.month_of_year,
            bestseller_query.c.year,
            func.sum(bestseller_query.c.sold_quantity_in_a_month).label(
                "sold_quantity_across_each_month"
            ),
            func.avg(bestseller_query.c.healthy_live_days_in_a_month).label(
                "total_days_count_across_month"
            ),
        )
        .join(store_query, store_query.c.store_id == bestseller_query.c.store_id)
        .group_by(
            bestseller_query.c.itemid,
            bestseller_query.c.month_of_year,
            bestseller_query.c.year,
        )
        .subquery()
    )

    ros_query = (
        select(
            ros_query.c.itemid,
            ros_query.c.year,
            func.sum(ros_query.c.sold_quantity_across_each_month).label(
                "total_sold_quantity"
            ),
            func.sum(ros_query.c.total_days_count_across_month).label(
                "total_active_days"
            ),
            func.round(
                cast(
                    (
                        (
                            func.sum(ros_query.c.sold_quantity_across_each_month)
                            / func.sum(ros_query.c.total_days_count_across_month)
                        )
                        * 7
                    ),
                    Numeric,
                ),
                2,
            ).label("weekly_rate_of_sale"),
        )
        .group_by(ros_query.c.itemid, ros_query.c.year)
        .subquery()
    )

    product_query = (
        select(
            TrendsProductAttributes.itemid,
            TrendsProductAttributes.brandname,
            TrendsProductAttributes.styletype,
            TrendsProductAttributes.primarycolor,
            TrendsProductAttributes.pattern,
            TrendsProductAttributes.fabrictype,
            TrendsProductAttributes.materialtype,
            TrendsProductAttributes.sleeve,
            TrendsProductAttributes.fit,
            TrendsProductAttributes.neckline,
            TrendsProductAttributes.imgcode,
            TrendsProductAttributes.extension,
            TrendsProductAttributes.mrp,
            TrendsProductAttributes.similargrouplevel,
        )
        .where(and_(*product_filter))
        .subquery()
    )

    brick_query = (
        select(
            TrendsBrickDetails.mh_family_desc,
            TrendsBrickDetails.mh_class_desc,
            TrendsBrickDetails.brickname,
            TrendsBrickDetails.similargrouplevel,
        )
        .where(and_(*brick_filter))
        .subquery()
    )

    query = (
        select(
            product_query.c.itemid,
            product_query.c.brandname,
            product_query.c.styletype,
            product_query.c.primarycolor,
            product_query.c.pattern,
            product_query.c.fabrictype,
            product_query.c.materialtype,
            product_query.c.sleeve,
            product_query.c.fit,
            product_query.c.neckline,
            product_query.c.imgcode,
            product_query.c.extension,
            brick_query.c.mh_family_desc,
            brick_query.c.mh_class_desc,
            brick_query.c.brickname,
            product_query.c.mrp,
            ros_query.c.total_sold_quantity,
            ros_query.c.weekly_rate_of_sale,
            ros_query.c.total_active_days,
        )
        .join(ros_query, ros_query.c.itemid == product_query.c.itemid)
        .join(
            brick_query,
            brick_query.c.similargrouplevel == product_query.c.similargrouplevel,
        )
    )
    # count the total number of rows
    total_count_query = select(func.count()).select_from(query)
    bestseller_query = await sort_and_paginate(
        query, request_data, "weekly_rate_of_sale"
    )

    query_list = [bestseller_query, total_count_query]

    result = await psql_execute_multiple(query_list)

    result = {
        "total_count": result[1][0][0],
        "rows": [
            {
                "itemid": row[0],
                "brandname": row[1],
                "styletype": row[2],
                "primarycolor": row[3],
                "pattern": row[4],
                "fabrictype": row[5],
                "materialtype": row[6],
                "sleeve": row[7],
                "fit": row[8],
                "neckline": row[9],
                "imgcode": row[10],
                "extension": row[11],
                "mh_family_desc": row[12],
                "mh_class_desc": row[13],
                "brickname": row[14],
                "mrp": round(float(row[15]), 2),
                "total_qty": int(row[16]),
                "weekly_rate_of_sale": int(row[17]),
                "total_active_days": round(row[18], 2),
            }
            for row in result[0]
        ],
    }
    return result
