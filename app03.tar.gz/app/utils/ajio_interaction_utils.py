from db import psql_execute_single
from models import (
    AjioBrickDetails,
    AjioProductAttributes,
    AjioSearchQueriesTopInteractedProducts,
)
from sqlalchemy import select
from static import month_mapping

from .common_utils import (
    build_filter_condition,
)


async def get_initial_filter_data_interaction():
    # get all distinct month from the database
    month_query = select(
        AjioSearchQueriesTopInteractedProducts.month_of_year
    ).distinct()
    month_result = await psql_execute_single(month_query)

    # Sort the month values before mapping them
    sorted_month_values = sorted(
        set(val[0] for val in month_result if val[0] not in ["nan", None])
    )

    # Map the sorted month values
    mapped_month_values = [month_mapping[month] for month in sorted_month_values]

    result = {
        "search_filters": {
            "search_type": [],
            "search_query": [],
        },
        "brick_filters": {
            "l1_name": [],
            "l2_name": [],
            "brick_name": [],
        },
        "attributes": {
            "brandname": [],
        },
        "duration": {
            "month": mapped_month_values,
            "week": [],
        },
    }
    return result


async def determine_filter_type(nested_data):
    if "duration" in nested_data and nested_data["duration"]:
        return "duration"
    elif "brick_filters" in nested_data and nested_data["brick_filters"]:
        return "brick_filters"
    elif "attributes" in nested_data and nested_data["attributes"]:
        return "attributes"
    elif "search_filters" in nested_data and nested_data["search_filters"]:
        return "search_filters"
    return None


async def get_initial_filter_duration_interaction(request_data):
    duration_filter = await build_filter_condition(
        filter_flag="duration", request_filters=request_data, type="ajio-search"
    )

    duration_query = select(
        AjioSearchQueriesTopInteractedProducts.month_of_year,
        AjioSearchQueriesTopInteractedProducts.week_of_year,
    ).where(*list(duration_filter))
    result = await psql_execute_single(duration_query)
    sorted_month_values = sorted(
        set(row[0] for row in result if row[0] != "nan" and row[0] is not None)
    )
    mapped_month_values = [month_mapping[month] for month in sorted_month_values]

    return {
        "duration": {
            "month": mapped_month_values,
            "week": sorted(
                list(
                    set(
                        [
                            row[1]
                            for row in result
                            if row[1] != "nan" and row[1] is not None
                        ]
                    )
                )
            ),
        }
    }


async def get_initial_filter_brick_interaction(request_data):
    brick_filter = await build_filter_condition(
        filter_flag="brick", request_filters=request_data, type="ajio-search"
    )

    brick_query = select(
        AjioBrickDetails.l1name,
        AjioBrickDetails.l2name,
        AjioBrickDetails.brickname,
        AjioBrickDetails.similargrouplevel,
    ).where(*list(brick_filter))
    result = await psql_execute_single(brick_query)

    return {
        "brick_filters": {
            "l1_name": sorted(
                list(
                    set(
                        [
                            row[0]
                            for row in result
                            if row[0] != "nan" and row[0] is not None
                        ]
                    )
                )
            ),
            "l2_name": sorted(
                list(
                    set(
                        [
                            row[1]
                            for row in result
                            if row[1] != "nan" and row[1] is not None
                        ]
                    )
                )
            ),
            "brick_name": sorted(
                list(
                    set(
                        [
                            row[2]
                            for row in result
                            if row[2] != "nan" and row[2] is not None
                        ]
                    )
                )
            ),
        }
    }


async def get_initial_filter_attributes_interaction(request_data):
    product_filter = await build_filter_condition(
        filter_flag="attributes", request_filters=request_data, type="ajio-search"
    )

    product_query = select(
        AjioProductAttributes.brandname,
    ).where(*list(product_filter))
    result = await psql_execute_single(product_query)

    return {
        "attributes": {
            "brandname": sorted(
                list(
                    set(
                        [
                            row[0]
                            for row in result
                            if row[0] != "nan" and row[0] is not None
                        ]
                    )
                )
            ),
        }
    }


async def get_initial_filter_search_interaction(request_data):
    search_filter = await build_filter_condition(
        filter_flag="search", request_filters=request_data, type="ajio-search"
    )

    search_query = select(
        AjioSearchQueriesTopInteractedProducts.search_type,
        AjioSearchQueriesTopInteractedProducts.normalized_search_term,
    ).where(*list(search_filter))
    result = await psql_execute_single(search_query)

    return {
        "search_filters": {
            "search_type": sorted(
                list(
                    set(
                        [
                            row[0]
                            for row in result
                            if row[0] != "nan" and row[0] is not None
                        ]
                    )
                )
            ),
            "search_query": sorted(
                list(
                    set(
                        [
                            row[1]
                            for row in result
                            if row[1] != "nan" and row[1] is not None
                        ]
                    )
                )
            ),
        }
    }


async def get_search_interaction_filters_response(request_data):
    filter_type = await determine_filter_type(request_data.get("nested_data", {}))

    if filter_type == "duration":
        result = await get_initial_filter_duration_interaction(request_data)
    elif filter_type == "brick_filters":
        result = await get_initial_filter_brick_interaction(request_data)
    elif filter_type == "attributes":
        result = await get_initial_filter_attributes_interaction(request_data)
    elif filter_type == "search_filters":
        result = await get_initial_filter_search_interaction(request_data)
    else:
        result = {}

    return result


async def get_search_interaction_filters_service(
    request_data: dict,
    caching_flag: bool = False,
):
    # Check if the "month" list is empty
    if request_data.get("nested_data", {}).get("duration", {}).get("month") == []:
        response = await get_initial_filter_data_interaction()
    else:
        response = await get_search_interaction_filters_response(request_data)

    if caching_flag:
        print("Ajio-Search-Interaction filters loaded successfully")
    else:
        return response
