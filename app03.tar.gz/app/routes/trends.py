from db import psql_execute_single
from fastapi import APIRouter, Depends
from fastapi.responses import JSONResponse
from models import (
    TrendsBestSellersMonth,
    TrendsBestSellersWeek,
    TrendsStoreDetails,
)
from sqlalchemy import func, select
from static import indian_states, setup_logging
from utils import (
    get_attributes_bestsellers_trends,
    get_trends_bestseller_month_level,
    get_trends_bestseller_week_level,
    get_trends_filters_service,
)

TrendsRouter = APIRouter(tags=["Trends"])


@TrendsRouter.post("/trends-filters")
async def get_trends_filters(
    request_data: dict,
    logger=Depends(setup_logging),
):
    try:
        return await get_trends_filters_service(request_data, caching_flag=False)
    except Exception as e:
        logger.error(e, exc_info=True)
        return JSONResponse(content={"error": "Internal Server Error"}, status_code=500)


@TrendsRouter.post("/bestsellers-products-trends")
async def bestsellers_products_trends(
    request_data: dict,
):
    if request_data.get("nested_data", {}).get("duration", {}).get("week"):
        result = await get_trends_bestseller_week_level(request_data)
    else:
        result = await get_trends_bestseller_month_level(request_data)

    return result


@TrendsRouter.post("/statewise-sales-trends")
async def get_statewise_sales(
    request_data: dict,
):
    if request_data.get("nested_data", {}).get("duration", {}).get("week"):
        best_sellers_schema = TrendsBestSellersWeek
        quantity_column = TrendsBestSellersWeek.sold_quantity_in_a_week
    else:
        best_sellers_schema = TrendsBestSellersMonth
        quantity_column = TrendsBestSellersMonth.sold_quantity_in_a_month

    sold_in_week_query = (
        select(
            TrendsStoreDetails.state,
            func.sum(quantity_column).label("quantity"),
        )
        .join(
            TrendsStoreDetails,
            TrendsStoreDetails.store_id == best_sellers_schema.store_id,
        )
        .group_by(TrendsStoreDetails.state)
    )

    maps_rows_state = await psql_execute_single(sold_in_week_query)
    map_data = [
        {
            "state": row[0],
            "statecode": indian_states.get(row[0].lower(), {}).get(
                "statecode", "Not Found"
            ),
            "quantity_sold": float(row[1]),
        }
        for row in maps_rows_state
    ]

    return map_data


@TrendsRouter.post("/fabric-bestsellers-trends")
async def get_fabric_bestsellers_trends(
    request_data: dict,
):
    result = await get_attributes_bestsellers_trends(
        request_data,
        "fabrictype",
    )

    return result


@TrendsRouter.post("/brandnames-bestsellers-trends")
async def brandnames_bestsellers_trends(
    request_data: dict,
):
    result = await get_attributes_bestsellers_trends(
        request_data,
        "brandname",
    )

    return result


@TrendsRouter.post("/neckline-bestsellers-trends")
async def neckline_bestsellers_trends(
    request_data: dict,
):
    result = await get_attributes_bestsellers_trends(
        request_data,
        "neckline",
    )

    return result


@TrendsRouter.post("/styletype-bestsellers-trends")
async def styletype_bestsellers_trends(
    request_data: dict,
):
    result = await get_attributes_bestsellers_trends(
        request_data,
        "styletype",
    )

    return result


@TrendsRouter.post("/sleevelength-bestsellers-trends")
async def sleevelength_bestsellers_trends(
    request_data: dict,
):
    result = await get_attributes_bestsellers_trends(
        request_data,
        "sleeve",
    )

    return result


@TrendsRouter.post("/pattern-bestsellers-trends")
async def pattern_bestsellers_trends(
    request_data: dict,
):
    result = await get_attributes_bestsellers_trends(
        request_data,
        "pattern",
    )

    return result


@TrendsRouter.post("/color-bestsellers-trends")
async def color_bestsellers_trends(
    request_data: dict,
):
    result = await get_attributes_bestsellers_trends(
        request_data,
        "primarycolor",
    )

    return result
