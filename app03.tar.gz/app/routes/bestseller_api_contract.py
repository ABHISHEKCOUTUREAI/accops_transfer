import json
from datetime import datetime

from db import check_in_redis, redis_db
from fastapi import APIRouter, Depends, FastAPI
from models import (
    AttributeQueryParams,
    CategoryQueryParams,
    FilterQuery,
    ProductQueryParams,
    SearchParams,
    SearchTrends,
)
from static import REDIS_WRITE_ERROR
from utils import (
    calculate_time_delta,
    execute_attribute_query,
    execute_category_query,
    execute_filters_query,
    execute_most_searched_attributes_query,
    execute_most_searched_trends_query,
    execute_products_query,
    load_attributes_images,
    load_category_images,
)

app = FastAPI()


BestSellerAPIContractRouter = APIRouter(
    tags=["API Contract"],
    responses={404: {"description": "Not found"}},
)


@BestSellerAPIContractRouter.get("/products")
async def get_bestseller_products(
    query_params: ProductQueryParams = Depends(),
):
    result = await execute_products_query(query_params=query_params)

    return result


@BestSellerAPIContractRouter.get("/category")
async def get_category(
    query_params: CategoryQueryParams = Depends(),
):
    # load the category images
    category_images = await redis_db.get("category_images")
    if category_images:
        category_images = json.loads(category_images)
    else:
        await load_category_images()
        category_images = await redis_db.get("category_images")
        category_images = json.loads(category_images)

    result = await execute_category_query(
        query_params=query_params, category_images=category_images
    )

    return result


@BestSellerAPIContractRouter.get("/attributes")
async def get_bestseller_attributes(
    query_params: AttributeQueryParams = Depends(),
):
    # get attributes images
    attributes_images = await redis_db.get("attributes_images")
    if attributes_images:
        attributes_images = json.loads(attributes_images)
    else:
        await load_attributes_images()
        attributes_images = await redis_db.get("attributes_images")
        attributes_images = json.loads(attributes_images)

    result = await execute_attribute_query(
        query_params=query_params, attributes_images=attributes_images
    )

    return result


@BestSellerAPIContractRouter.get("/most-searched-trends")
async def get_most_searched_trends(
    query_params: SearchTrends = Depends(),
):
    cache_key = (
        f"api_contract_most_searched_trends{json.dumps(query_params.model_dump())}"
    )
    cached_data = await check_in_redis(cache_key)

    if cached_data:
        data = json.loads(cached_data)
        current_week = datetime.now().isocalendar()[1]
        for item in data:
            item["last_searched_timestamp"] = (
                current_week - item["last_searched_timestamp"]
            ) * 7

        return data
    cache_key_min_max = "min_max_week"
    min_max_week = await redis_db.get(cache_key_min_max)
    if min_max_week:
        min_week, max_week = json.loads(min_max_week)
    else:
        await calculate_time_delta()
        min_max_week = await redis_db.get(cache_key_min_max)
        min_week, max_week = json.loads(min_max_week)

    result = await execute_most_searched_trends_query(
        query_params=query_params,
        min_week=min_week,
        max_week=max_week,
    )
    try:
        await redis_db.set(cache_key, json.dumps(result, default=str))
    except Exception as e:
        print(REDIS_WRITE_ERROR, e)

    return result


@BestSellerAPIContractRouter.get("/most-searched-attributes")
async def get_most_searched_attributes(
    query_params: SearchParams = Depends(),
):
    # start_week, latest_week = await calculate_time_delta(query_params)
    cache_key_min_max = "min_max_week"
    min_max_week = await redis_db.get(cache_key_min_max)
    if min_max_week:
        min_week, max_week = json.loads(min_max_week)
    else:
        await calculate_time_delta()
        min_max_week = await redis_db.get(cache_key_min_max)
        min_week, max_week = json.loads(min_max_week)

    data = await execute_most_searched_attributes_query(
        query_params=query_params, min_week=min_week, max_week=max_week
    )

    return data


@BestSellerAPIContractRouter.get("/filters")
async def get_api_contract_filters(
    query_params: FilterQuery = Depends(),
):
    response = await execute_filters_query(query_params=query_params)

    return response
